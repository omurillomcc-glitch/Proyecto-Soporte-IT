/* =====================================================
   1. BLOQUEOS DE SEGURIDAD GENERALES
====================================================== */
// Bloquear el menú del clic derecho
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Bloquear atajos de teclado comunes para herramientas de desarrollo
document.addEventListener('keydown', function(e) {
    // Bloquear F12
    if (e.code === 'F12') {
        e.preventDefault();
    }
    // Bloquear Ctrl + Shift + I (Inspector), Ctrl + Shift + C (Elementos), Ctrl + Shift + J (Consola)
    if (e.ctrlKey && e.shiftKey && (e.code === 'KeyI' || e.code === 'KeyC' || e.code === 'KeyJ')) {
        e.preventDefault();
    }
    // Bloquear Ctrl + U (Ver código fuente)
    if (e.ctrlKey && e.code === 'KeyU') {
        e.preventDefault();
    }
});


/* =====================================================
   2. LÓGICA DE MENÚ DE NAVEGACIÓN (ORBIT MENU)
====================================================== */
document.addEventListener('DOMContentLoaded', function () {

    // Evita registrar los eventos dos veces si alguna página antigua
    // también carga menu.js manualmente.
    if (window.__orbitMenuInitialized) {
        return;
    }
    window.__orbitMenuInitialized = true;

    const body = document.body;
    const navMenu = document.getElementById('navmenu');
    const mobileToggle = document.querySelector('.mobile-nav-toggle');
    const backdrop = document.getElementById('mobileNavBackdrop');

    if (!navMenu) return;
    
    navMenu.addEventListener('click', function (e) {
        
        if (e.target.closest('a')) {
            return; 
        }

        // Buscar si el elemento cliqueado es un botón disparador de menú o submenú
        const trigger = e.target.closest('.navmenu-trigger, .nested-trigger');
        if (!trigger) return;

        e.preventDefault();
        e.stopPropagation();

        const isMainMenu = trigger.classList.contains('navmenu-trigger');

        if (isMainMenu) {
            /* --- Nivel 1: Menú Principal --- */
            const currentDropdown = trigger.closest('.dropdown');
            if (!currentDropdown) return;

            const isOpen = currentDropdown.classList.contains('open');

            // 1. Cerrar todos los demás menús principales y sus submenús internos
            document.querySelectorAll('.navmenu-root > .dropdown.open').forEach(function (item) {
                if (item !== currentDropdown) {
                    item.classList.remove('open');
                    item.querySelector('.navmenu-trigger')?.setAttribute('aria-expanded', 'false');
                    item.querySelectorAll('.nested-dropdown.open').forEach(sub => {
                        sub.classList.remove('open');
                        sub.querySelector('.nested-trigger')?.setAttribute('aria-expanded', 'false');
                    });
                }
            });

            // 2. Alternar el menú seleccionado
            if (!isOpen) {
                currentDropdown.classList.add('open');
                trigger.setAttribute('aria-expanded', 'true');
            } else {
                currentDropdown.classList.remove('open');
                trigger.setAttribute('aria-expanded', 'false');
                // Al cerrar el padre, cerramos sus submenús
                currentDropdown.querySelectorAll('.nested-dropdown.open').forEach(sub => {
                    sub.classList.remove('open');
                    sub.querySelector('.nested-trigger')?.setAttribute('aria-expanded', 'false');
                });
            }

        } else {
            /* --- Nivel 2: Submenú Interno (Nested) --- */
            const currentNested = trigger.closest('.nested-dropdown');
            if (!currentNested) return;

            const isOpen = currentNested.classList.contains('open');
            const parentList = currentNested.parentElement;

            // 1. Cerrar submenús hermanos dentro del mismo contenedor
            if (parentList) {
                parentList.querySelectorAll(':scope > .nested-dropdown.open').forEach(function (sibling) {
                    if (sibling !== currentNested) {
                        sibling.classList.remove('open');
                        sibling.querySelector('.nested-trigger')?.setAttribute('aria-expanded', 'false');
                    }
                });
            }

            // 2. Alternar el submenú actual (MANTIENE EL PADRE ABIERTO)
            if (!isOpen) {
                currentNested.classList.add('open');
                trigger.setAttribute('aria-expanded', 'true');
            } else {
                currentNested.classList.remove('open');
                trigger.setAttribute('aria-expanded', 'false');
            }
        }
    });


    /* =====================================================
       3. CERRAR MENÚS AL HACER CLIC FUERA DE #NAVMENU
    ====================================================== */
    document.addEventListener('click', function (e) {
        // Evita interferencias si el usuario presiona el botón del menú móvil
        if (e.target.closest('.mobile-nav-toggle')) return;

        if (!e.target.closest('#navmenu')) {
            document.querySelectorAll('.dropdown.open, .nested-dropdown.open').forEach(function (el) {
                el.classList.remove('open');
                const btn = el.querySelector('.navmenu-trigger, .nested-trigger');
                if (btn) btn.setAttribute('aria-expanded', 'false');
            });
            // Cierra también el contenedor móvil si haces clic afuera
            closeMobileMenu(); 
        }
    });


    /* =====================================================
       4. MENÚ MÓVIL Y TECLA ESCAPE
    ====================================================== */
    function closeMobileMenu() {
        body.classList.remove('mobile-nav-active');
        mobileToggle?.setAttribute('aria-expanded', 'false');
        const icon = mobileToggle?.querySelector('i');
        if (icon) icon.className = 'bi bi-list';
    }

    if (mobileToggle) {
        mobileToggle.addEventListener('click', function (e) {
            e.stopPropagation();
            const active = body.classList.toggle('mobile-nav-active');
            mobileToggle.setAttribute('aria-expanded', active ? 'true' : 'false');
            const icon = mobileToggle.querySelector('i');
            if (icon) icon.className = active ? 'bi bi-x-lg' : 'bi bi-list';
        });
    }

    backdrop?.addEventListener('click', closeMobileMenu);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.dropdown.open, .nested-dropdown.open').forEach(function (el) {
                el.classList.remove('open');
                const btn = el.querySelector('.navmenu-trigger, .nested-trigger');
                if (btn) btn.setAttribute('aria-expanded', 'false');
            });
            closeMobileMenu();
        }
    });
});
