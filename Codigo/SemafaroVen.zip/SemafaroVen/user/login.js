document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('loginForm');
    const usuario = document.getElementById('usuario');
    const password = document.getElementById('password');
    const remember = document.getElementById('remember');
    const toggle = document.getElementById('togglePassword');

    if (usuario && remember) {
        const recordado = localStorage.getItem('semafaro_usuario_recordado');

        if (recordado) {
            usuario.value = recordado;
            remember.checked = true;
        }
    }

    if (form && usuario && remember) {
        form.addEventListener('submit', function () {
            if (remember.checked) {
                localStorage.setItem(
                    'semafaro_usuario_recordado',
                    usuario.value.trim()
                );
            } else {
                localStorage.removeItem('semafaro_usuario_recordado');
            }
        });
    }

    if (toggle && password) {
        toggle.addEventListener('click', function () {
            const visible = password.type === 'text';

            password.type = visible ? 'password' : 'text';

            const icon = toggle.querySelector('i');

            if (icon) {
                icon.className = visible
                    ? 'fa-solid fa-eye'
                    : 'fa-solid fa-eye-slash';
            }

            toggle.title = visible
                ? 'Mostrar contraseña'
                : 'Ocultar contraseña';
        });
    }
});