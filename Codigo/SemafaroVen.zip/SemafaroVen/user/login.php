<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.use_trans_sid', '0');

$https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';

session_name('APP_SEMAFARO');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/conexion.php';

$error = $_SESSION['login_error'] ?? '';
$usuarioGuardado = $_SESSION['login_usuario'] ?? '';
unset($_SESSION['login_error'], $_SESSION['login_usuario']);

function volverLogin(string $mensaje, string $usuario = ''): void {
    $_SESSION['login_error'] = $mensaje;
    $_SESSION['login_usuario'] = $usuario;

    $ruta = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: 'index.php';
    header('Location: ' . $ruta, true, 303);
    exit;
}

function auditoria(
    mysqli $conn,
    string $nombre,
    string $usuario,
    string $accion,
    string $detalle
): void {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA';

        $stmt = $conn->prepare("
            INSERT INTO auditoria
            (nombre_completo, usuario, accion, ip, fecha, detalle)
            VALUES (?, ?, ?, ?, NOW(), ?)
        ");

        if (!$stmt) return;

        $stmt->bind_param('sssss', $nombre, $usuario, $accion, $ip, $detalle);
        $stmt->execute();
        $stmt->close();

    } catch (Throwable $e) {
        error_log('Error auditoría login: ' . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario = trim((string)($_POST['usuario'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ]{3,50}$/u', $usuario)) {
        volverLogin('El usuario solo permite letras y espacios.', $usuario);
    }

    if (!preg_match('/^\S{6,30}$/u', $password)) {
        volverLogin(
            'La contraseña debe tener entre 6 y 30 caracteres y no contener espacios.',
            $usuario
        );
    }

    $stmt = $conn->prepare("
        SELECT id, usuario, nombre_completo, password, rol, estado,
               foto_perfil, COALESCE(intentos,0) AS intentos
        FROM usuarios
        WHERE usuario = ?
        LIMIT 1
    ");

    if (!$stmt) volverLogin('No fue posible validar el usuario.', $usuario);

    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$user) {
        volverLogin('Usuario o contraseña incorrectos.', $usuario);
    }

    if ((int)$user['estado'] !== 1) {
        volverLogin('Usuario bloqueado.', $usuario);
    }

    if (!password_verify($password, (string)$user['password'])) {

        $intentos = (int)$user['intentos'] + 1;
        $estado = $intentos >= 5 ? 0 : 1;
        $usuarioId = (int)$user['id'];

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET intentos = ?, estado = ?
            WHERE id = ?
        ");

        if ($stmt) {
            $stmt->bind_param('iii', $intentos, $estado, $usuarioId);
            $stmt->execute();
            $stmt->close();
        }

        auditoria(
            $conn,
            (string)($user['nombre_completo'] ?? ''),
            (string)$user['usuario'],
            'LOGIN_FALLIDO',
            $intentos >= 5
                ? 'Intento fallido 5 de 5. Usuario bloqueado.'
                : "Intento fallido {$intentos} de 5."
        );

        if ($intentos >= 5) {
            volverLogin('Usuario bloqueado tras 5 intentos incorrectos.', $usuario);
        }

        $restantes = 5 - $intentos;

        volverLogin(
            "Usuario o contraseña incorrectos. Le quedan {$restantes} intentos.",
            $usuario
        );
    }

    $usuarioId = (int)$user['id'];

    $stmt = $conn->prepare("
        UPDATE usuarios
        SET ultimo_login = NOW(), intentos = 0
        WHERE id = ?
    ");

    if (!$stmt) volverLogin('No fue posible actualizar el acceso.', $usuario);

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $stmt->close();

    session_regenerate_id(true);

    $_SESSION['usuario_id'] = $usuarioId;
    $_SESSION['usuario'] = (string)$user['usuario'];
    $_SESSION['nombre_completo'] = (string)$user['nombre_completo'];
    $_SESSION['rol'] = (string)$user['rol'];
    $_SESSION['foto_perfil'] = $user['foto_perfil'] ?? null;
    $_SESSION['login_time'] = time();
    $_SESSION['tiendas'] = [];

    if ((string)$user['rol'] !== 'administrador') {

        $stmt = $conn->prepare("
            SELECT codalmacen
            FROM usuario_tienda
            WHERE usuario_id = ?
            ORDER BY codalmacen
        ");

        if ($stmt) {
            $stmt->bind_param('i', $usuarioId);
            $stmt->execute();
            $resultado = $stmt->get_result();

            while ($fila = $resultado->fetch_assoc()) {
                $codigo = trim((string)($fila['codalmacen'] ?? ''));

                if ($codigo !== '') {
                    $_SESSION['tiendas'][] = $codigo;
                }
            }

            $stmt->close();
            $_SESSION['tiendas'] = array_values(array_unique($_SESSION['tiendas']));
        }
    }

    header('Location: ../index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semafaro | Grupo MCC</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="style.css?v=<?= time() ?>">
    <link rel="shortcut icon" type="image/png" href="/SemafaroVen/img/sv.png">

</head>

<body>

<div class="container">

    <div class="login-side">
        <div class="wrapper">

            <div class="logo-login">
                <img src="img/logo.png" alt="Grupo MCC">
            </div>

            <h2>Bienvenidos</h2>

            <p class="subtitle">
                Ingresa tus credenciales para continuar.
            </p>

            <?php if ($error !== ''): ?>
                <div class="login-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></span>
                </div>
            <?php endif; ?>

            <form id="loginForm" method="POST" autocomplete="on">

                <div class="input-field">
                    <i class="fa-solid fa-user"></i>

                    <input
                        type="text"
                        id="usuario"
                        name="usuario"
                        value="<?= htmlspecialchars($usuarioGuardado, ENT_QUOTES, 'UTF-8') ?>"
                        autocomplete="username"
                        maxlength="50"
                        required
                    >

                    <label for="usuario">Usuario</label>
                </div>

                <div class="input-field">
                    <i class="fa-solid fa-lock"></i>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        autocomplete="current-password"
                        minlength="6"
                        maxlength="30"
                        required
                    >

                    <label for="password">Contraseña</label>

                    <span
                        class="toggle-password"
                        id="togglePassword"
                        title="Mostrar contraseña"
                    >
                        <i class="fa-solid fa-eye"></i>
                    </span>
                </div>

                <div class="forget">
                    <label class="remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <span>Recordar</span>
                    </label>
                </div>

                <button type="submit">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Ingresar
                </button>

                <div class="footer">
                    © <?= date('Y') ?> GRUPO MCC
                </div>

            </form>
        </div>
    </div>

    <div class="image-side">
        <div class="overlay">
            <div class="content">
                <h1></h1>
                <p>Integridad, Innovación, Pasión, Unión y Perseverancia.</p>
            </div>
        </div>
    </div>

</div>

<script src="/SemafaroVen/user/login.js?v=<?= time() ?>"></script>

</body>
</html>