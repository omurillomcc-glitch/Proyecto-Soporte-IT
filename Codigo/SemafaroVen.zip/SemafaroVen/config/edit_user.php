<?php
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

session_name('APP_SEMAFARO');
session_start();

$baseUrl = $baseUrl ?? '/SemafaroVen';

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$permitidos = [100, 200, 500];
$porPagina = (int)($_GET['por_pagina'] ?? 100);
if (!in_array($porPagina, $permitidos, true)) $porPagina = 100;

$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$buscar = trim((string)($_GET['buscar'] ?? ''));

$where = '';
$params = [];
$types = '';

if ($buscar !== '') {
    $where = 'WHERE usuario LIKE ? OR nombre_completo LIKE ? OR rol LIKE ?';
    $like = "%{$buscar}%";
    $params = [$like, $like, $like];
    $types = 'sss';
}

$stmt = $conn->prepare("SELECT COUNT(*) total FROM usuarios {$where}");
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$totalRegistros = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
$stmt->close();

$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
if ($pagina > $totalPaginas) $pagina = $totalPaginas;

$offset = ($pagina - 1) * $porPagina;

$stmt = $conn->prepare("
    SELECT id, usuario, nombre_completo, rol, estado, creado_en
    FROM usuarios
    {$where}
    ORDER BY nombre_completo
    LIMIT ? OFFSET ?
");

if ($types) {
    $tipos = $types . 'ii';
    $datos = array_merge($params, [$porPagina, $offset]);
    $stmt->bind_param($tipos, ...$datos);
} else {
    $stmt->bind_param('ii', $porPagina, $offset);
}

$stmt->execute();
$res = $stmt->get_result();

$usuarios = [];
$ids = [];

while ($row = $res->fetch_assoc()) {
    $row['tiendas'] = [];
    $usuarios[] = $row;
    $ids[] = (int)$row['id'];
}

$stmt->close();

$asignaciones = [];

if ($ids) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $tiposIds = str_repeat('i', count($ids));

    $stmt = $conn->prepare("
        SELECT usuario_id, codalmacen
        FROM usuario_tienda
        WHERE usuario_id IN ({$placeholders})
        ORDER BY codalmacen
    ");

    if ($stmt) {
        $stmt->bind_param($tiposIds, ...$ids);
        $stmt->execute();
        $r = $stmt->get_result();

        while ($fila = $r->fetch_assoc()) {
            $asignaciones[(int)$fila['usuario_id']][] =
                trim((string)$fila['codalmacen']);
        }

        $stmt->close();
    }
}

foreach ($usuarios as &$u) {
    $u['tiendas'] = $asignaciones[(int)$u['id']] ?? [];
}
unset($u);

$tiendas = [];

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion !== false) {

    $sqlTiendas = "
        SELECT
            LTRIM(RTRIM(CODALMACEN)) CODALMACEN,
            LTRIM(RTRIM(NOMBREALMACEN)) NOMBREALMACEN,
            LTRIM(RTRIM(ISNULL(POBLACION,''))) POBLACION
        FROM MENDELS.dbo.ALMACEN
        WHERE CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(LTRIM(RTRIM(NOMBREALMACEN))) NOT IN (
            'MENDEL´S CENTRO NI',
            'MENDEL´S CENTRO S.P.S',
            'MENDELS CENTRO NI',
            'MENDELS CENTRO SPS',
            'MENDEL´S CENTRO TGU',
            'MENDELS CENTRO TGU',
            'MENDEL´S CENTRO TEGUCIGALPA',
            'MENDELS CENTRO TEGUCIGALPA'
          )
        ORDER BY CODALMACEN
    ";

    $st = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlTiendas);

    if ($st !== false) {
        while ($t = sqlsrv_fetch_array($st, SQLSRV_FETCH_ASSOC)) {
            $tiendas[] = $t;
        }
        sqlsrv_free_stmt($st);
    }
}

function urlEditar(array $extra = []): string {
    return '/SemafaroVen/config/edit_user.php?' .
        http_build_query(array_merge($_GET, $extra));
}

require_once dirname(__DIR__) . '/layout_menu.php';
?>

<link rel="stylesheet" href="<?= $baseUrl ?>/config/useredit.css?v=<?= time() ?>">

<div class="user-page edit-page">

<?php if (isset($_GET['ok_edit'])): ?>
    <div class="alert success">
        <i class="bi bi-check-circle-fill"></i>
        <strong>Usuario editado con éxito.</strong>
        Los cambios han sido registrados.
    </div>
<?php endif; ?>

<?php
if (isset($_GET['error'])):
    $mensajeError = match($_GET['error']) {
        'no_quitar_admin'  => 'No puedes quitarte el rol de Administrador a ti mismo.',
        'usuario_invalido' => 'El usuario seleccionado no es válido.',
        'nombre_invalido'  => 'El nombre completo no es válido.',
        'password_invalido'=> 'La contraseña debe tener entre 6 y 30 caracteres y no contener espacios.',
        'rol_invalido'     => 'El rol seleccionado no es válido.',
        'tienda_requerida' => 'Debe asignar al menos una tienda al Gerente Comercial.',
        'una_sola_tienda'  => 'El Gerente de Tienda debe tener exactamente una tienda.',
        'tienda_invalida'  => 'Una de las tiendas seleccionadas no es válida.',
        'no_existe'        => 'El usuario seleccionado no existe.',
        'csrf'             => 'La sesión del formulario expiró. Actualice la página.',
        default            => 'No se pudieron guardar las modificaciones.'
    };
?>
    <div class="alert danger">
        <?= htmlspecialchars($mensajeError, ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>

<div class="edit-layout">

<aside class="panel user-list-panel">

    <div class="panel-head compact">
        <div><span class="eyebrow">Usuarios registrados</span></div>
        <span class="count-pill"><?= $totalRegistros ?></span>
    </div>

    <form method="GET" class="search-row">

        <div class="search-box">
            <input
                type="text"
                name="buscar"
                value="<?= htmlspecialchars($buscar, ENT_QUOTES, 'UTF-8') ?>"
                placeholder="Buscar por usuario o nombre..."
                autocomplete="off"
            >
        </div>

        <select name="por_pagina">
            <option value="100" <?= $porPagina === 100 ? 'selected' : '' ?>>100</option>
            <option value="200" <?= $porPagina === 200 ? 'selected' : '' ?>>200</option>
            <option value="500" <?= $porPagina === 500 ? 'selected' : '' ?>>500</option>
        </select>

        <button type="submit" class="icon-button">⌕</button>
        <a href="<?= $baseUrl ?>/config/edit_user.php" class="icon-button clear">↻</a>

    </form>

    <div class="user-list">

        <?php foreach ($usuarios as $index => $u): ?>

            <button
                type="button"
                class="user-row <?= $index === 0 ? 'selected' : '' ?>"
                data-id="<?= (int)$u['id'] ?>"
                data-usuario="<?= htmlspecialchars($u['usuario'], ENT_QUOTES, 'UTF-8') ?>"
                data-nombre="<?= htmlspecialchars($u['nombre_completo'], ENT_QUOTES, 'UTF-8') ?>"
                data-rol="<?= htmlspecialchars($u['rol'], ENT_QUOTES, 'UTF-8') ?>"
                data-estado="<?= (int)$u['estado'] ?>"
                data-tiendas='<?= htmlspecialchars(
                    json_encode($u['tiendas'], JSON_UNESCAPED_UNICODE),
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>'
            >

                <span class="avatar">
                    <?= htmlspecialchars(strtoupper(substr($u['usuario'], 0, 1))) ?>
                </span>

                <span class="user-copy">
                    <strong><?= htmlspecialchars($u['usuario']) ?></strong>
                    <small><?= htmlspecialchars($u['nombre_completo']) ?></small>
                </span>

                <span class="status-badge <?= (int)$u['estado'] === 1 ? 'active' : 'blocked' ?>">
                    <?= (int)$u['estado'] === 1 ? 'Activo' : 'Bloqueado' ?>
                </span>

                <span class="chevron">›</span>

            </button>

        <?php endforeach; ?>

        <?php if (!$usuarios): ?>
            <div class="empty-users">No hay usuarios registrados.</div>
        <?php endif; ?>

    </div>

    <div class="pagination-wrap">

        <span>Página <?= $pagina ?> de <?= $totalPaginas ?></span>

        <div class="pagination">

            <?php if ($pagina > 1): ?>
                <a href="<?= htmlspecialchars(urlEditar(['pagina' => $pagina - 1])) ?>">‹</a>
            <?php endif; ?>

            <?php for ($p = 1; $p <= $totalPaginas; $p++): ?>
                <a
                    href="<?= htmlspecialchars(urlEditar(['pagina' => $p])) ?>"
                    class="<?= $p === $pagina ? 'active' : '' ?>"
                ><?= $p ?></a>
            <?php endfor; ?>

            <?php if ($pagina < $totalPaginas): ?>
                <a href="<?= htmlspecialchars(urlEditar(['pagina' => $pagina + 1])) ?>">›</a>
            <?php endif; ?>

        </div>
    </div>

</aside>

<section class="panel edit-form-panel">

    <div class="panel-head form-title">
        <div>
            <h2>Información del usuario</h2>
            <p>Seleccione un usuario y modifique sus datos, rol y tiendas.</p>
        </div>

        <span id="selectedStatus" class="status-badge active">Activo</span>
    </div>

<?php if ($usuarios): $primero = $usuarios[0]; ?>

<form
    method="POST"
    action="<?= $baseUrl ?>/config/guardar_editar.php"
    autocomplete="off"
    class="user-form"
    id="editForm"
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
    >

    <input
        type="hidden"
        name="usuario_original"
        id="usuario_original"
        value="<?= htmlspecialchars($primero['usuario'], ENT_QUOTES, 'UTF-8') ?>"
    >

    <div class="form-grid">

        <div class="form-group">
            <label>Usuario</label>
            <input
                id="usuario_visual"
                type="text"
                value="<?= htmlspecialchars($primero['usuario']) ?>"
                readonly
            >
        </div>

        <div class="form-group">
            <label for="nombre_completo">Nombre completo <span>*</span></label>
            <input
                id="nombre_completo"
                type="text"
                name="nombre_completo"
                value="<?= htmlspecialchars($primero['nombre_completo']) ?>"
                maxlength="100"
                required
            >
        </div>

        <div class="form-group">
            <label for="rol">Rol <span>*</span></label>

            <select id="rol" name="rol" required>
                <option value="administrador" <?= $primero['rol'] === 'administrador' ? 'selected' : '' ?>>
                    Administrador
                </option>

                <option value="gerente_comercial" <?= $primero['rol'] === 'gerente_comercial' ? 'selected' : '' ?>>
                    Gerente Comercial
                </option>

                <option value="gerente_tienda" <?= $primero['rol'] === 'gerente_tienda' ? 'selected' : '' ?>>
                    Gerente de Tienda
                </option>
            </select>
        </div>

        <div class="form-group">

            <label for="password">Nueva contraseña</label>

            <div class="password-box">

                <input
                    id="password"
                    type="password"
                    name="password"
                    minlength="6"
                    maxlength="30"
                    placeholder="Dejar en blanco para mantener la actual"
                    autocomplete="new-password"
                >

                <button
                    type="button"
                    class="eye-btn"
                    id="toggleEditPass"
                >
                    Ver
                </button>

            </div>

        </div>

    </div>

    <div
        class="form-group"
        id="grupoTiendas"
        style="display:none; margin-top:20px;"
    >

        <label>Tiendas asignadas <span>*</span></label>

        <div class="tiendas-container">

        <?php if (empty($tiendas)): ?>

            <div class="alert danger" style="margin:0;">
                No se encontraron tiendas MENDELS.
            </div>

        <?php else: ?>

            <div class="tiendas-toolbar">

                <div class="tiendas-toolbar-copy">
                    <strong>Seleccionar tiendas</strong>
                    <small>Elija las tiendas que tendrá disponibles este usuario.</small>
                </div>

                <span class="tiendas-count">
                    <strong id="numeroTiendas">0</strong>
                    <span>seleccionadas</span>
                </span>

            </div>

            <div class="tiendas-header">

                <div class="tiendas-search-box">
                    <i class="bi bi-search"></i>

                    <input
                        type="text"
                        id="buscarTienda"
                        class="search-tienda"
                        placeholder="Buscar por tienda, código o ciudad..."
                        autocomplete="off"
                    >
                </div>

            </div>

            <div class="lista-tiendas">

            <?php foreach ($tiendas as $tienda):
                $codigo = trim((string)$tienda['CODALMACEN']);
                $nombreTienda = trim((string)$tienda['NOMBREALMACEN']);
                $poblacion = trim((string)$tienda['POBLACION']);
            ?>

                <label class="tienda-card">

                    <input
                        type="checkbox"
                        name="tiendas[]"
                        value="<?= htmlspecialchars($codigo) ?>"
                        class="check-tienda"
                    >

                    <span class="tienda-check-ui">
                        <i class="bi bi-check-lg"></i>
                    </span>

                    <span class="tienda-main">

                        <span class="tienda-topline">

                            <span class="tienda-codigo">
                                Tienda <?= htmlspecialchars($codigo) ?>
                            </span>

                            <?php if ($poblacion !== ''): ?>
                                <span class="tienda-poblacion">
                                    <i class="bi bi-geo-alt-fill"></i>
                                    <?= htmlspecialchars($poblacion) ?>
                                </span>
                            <?php endif; ?>

                        </span>

                        <span class="tienda-nombre">
                            <?= htmlspecialchars($nombreTienda) ?>
                        </span>

                    </span>

                </label>

            <?php endforeach; ?>

            </div>

        <?php endif; ?>

        </div>

        <small id="textoTienda" class="tienda-helper"></small>

    </div>

    <div class="form-note" style="margin-top:15px;">
        <span class="note-icon">i</span>
        El estado se administra desde <strong>Bloquear usuario</strong>.
    </div>

    <div class="actions" style="margin-top:15px;">
        <button type="reset" class="btn-secondary">Cancelar</button>
        <button type="submit" class="btn-primary">Guardar</button>
    </div>

</form>

<?php else: ?>

    <div class="empty-form">
        No hay usuarios disponibles para editar.
    </div>

<?php endif; ?>

</section>
</div>
</div>

<script>
const rows = document.querySelectorAll('.user-row');
const original = document.getElementById('usuario_original');
const usuarioVisual = document.getElementById('usuario_visual');
const nombre = document.getElementById('nombre_completo');
const rol = document.getElementById('rol');
const status = document.getElementById('selectedStatus');
const password = document.getElementById('password');
const grupoTiendas = document.getElementById('grupoTiendas');
const textoTienda = document.getElementById('textoTienda');
const checks = document.querySelectorAll('.check-tienda');
const buscarTienda = document.getElementById('buscarTienda');
const numeroTiendas = document.getElementById('numeroTiendas');

function seleccionVisual() {
    let total = 0;

    checks.forEach(c => {
        c.closest('.tienda-card')?.classList.toggle('selected', c.checked);
        if (c.checked) total++;
    });

    if (numeroTiendas) numeroTiendas.textContent = total;
}

if (buscarTienda) {
    buscarTienda.addEventListener('input', function () {
        const texto = this.value.toLowerCase().trim();

        document.querySelectorAll('.tienda-card').forEach(card => {
            card.style.display =
                card.textContent.toLowerCase().includes(texto)
                    ? 'flex'
                    : 'none';
        });
    });
}

function actualizarRol() {

    if (!rol || !grupoTiendas) return;

    if (rol.value === 'administrador') {
        grupoTiendas.style.display = 'none';
        checks.forEach(c => c.checked = false);
        if (textoTienda) textoTienda.textContent = '';
    }

    else if (rol.value === 'gerente_comercial') {
        grupoTiendas.style.display = 'block';
        if (textoTienda) {
            textoTienda.textContent =
                'Puede seleccionar una o varias tiendas.';
        }
    }

    else if (rol.value === 'gerente_tienda') {

        grupoTiendas.style.display = 'block';

        if (textoTienda) {
            textoTienda.textContent =
                'Debe seleccionar solamente una tienda.';
        }

        let encontrada = false;

        checks.forEach(c => {
            if (c.checked) {
                if (!encontrada) encontrada = true;
                else c.checked = false;
            }
        });

    } else {
        grupoTiendas.style.display = 'none';
    }

    seleccionVisual();
}

function cargarTiendas(lista) {
    checks.forEach(c => c.checked = lista.includes(c.value));
    actualizarRol();
}

rows.forEach(row => {

    row.addEventListener('click', () => {

        rows.forEach(r => r.classList.remove('selected'));
        row.classList.add('selected');

        original.value = row.dataset.usuario;
        usuarioVisual.value = row.dataset.usuario;
        nombre.value = row.dataset.nombre;
        rol.value = row.dataset.rol;
        password.value = '';

        const activo = row.dataset.estado === '1';

        status.textContent =
            activo ? 'Activo' : 'Bloqueado';

        status.className =
            'status-badge ' +
            (activo ? 'active' : 'blocked');

        let lista = [];

        try {
            lista = JSON.parse(row.dataset.tiendas || '[]');
        } catch (e) {}

        cargarTiendas(lista);
    });

});

rol?.addEventListener('change', actualizarRol);

checks.forEach(check => {

    check.addEventListener('change', function () {

        if (
            rol.value === 'gerente_tienda' &&
            this.checked
        ) {

            checks.forEach(otro => {
                if (otro !== this) otro.checked = false;
            });
        }

        seleccionVisual();
    });

});

document.getElementById('editForm')
?.addEventListener('submit', function (e) {

    const seleccionadas =
        document.querySelectorAll('.check-tienda:checked');

    if (
        rol.value === 'gerente_comercial' &&
        seleccionadas.length === 0
    ) {
        e.preventDefault();
        alert('Debe seleccionar al menos una tienda para el Gerente Comercial.');
        return;
    }

    if (
        rol.value === 'gerente_tienda' &&
        seleccionadas.length !== 1
    ) {
        e.preventDefault();
        alert('El Gerente de Tienda debe tener exactamente una tienda.');
    }
});

nombre?.addEventListener('input', function () {
    this.value =
        this.value.replace(
            /[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g,
            ''
        );
});

/* NO FILTRAR PASSWORD:
   permite @ * # ! $ % & _ - ? + etc */

document.getElementById('toggleEditPass')
?.addEventListener('click', function () {

    const visible =
        password.type === 'text';

    password.type =
        visible ? 'password' : 'text';

    this.textContent =
        visible ? 'Ver' : 'Ocultar';
});

<?php if ($usuarios): ?>
cargarTiendas(
    <?= json_encode(
        $primero['tiendas'],
        JSON_UNESCAPED_UNICODE
    ) ?>
);
<?php endif; ?>

seleccionVisual();
</script>

<?php require_once dirname(__DIR__) . '/layout_footer.php'; ?>