<?php

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

session_name('APP_SEMAFARO');
session_start();

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php'; 

$baseUrl = $baseUrl ?? '/SemafaroVen';

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit();
}

/*
 SOLO POST
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: {$baseUrl}/config/agregar_user.php?error=metodo_invalido");
    exit();
}

$csrfToken = (string)($_POST['csrf_token'] ?? '');
if (empty($_SESSION['csrf_token']) || $csrfToken === '' || !hash_equals((string)$_SESSION['csrf_token'], $csrfToken)) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=csrf");
    exit();
}

/*
DATOS
*/

$usuario = trim($_POST['usuario'] ?? '');
$nombreCompleto = trim($_POST['nombre_completo'] ?? '');
$password = $_POST['password'] ?? '';
$rol = trim($_POST['rol'] ?? '');
$tiendas = $_POST['tiendas'] ?? [];

/*VALIDAR USUARIOS*/

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ]{3,50}$/u', $usuario)) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=usuario_invalido");
    exit();
}

/*VALIDAR NOMBRES*/

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/u', $nombreCompleto)) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=nombre_invalido");
    exit();
}

/*CONTRASEÑA*/

if (!preg_match('/^[A-Za-z0-9.]{6,30}$/', $password)) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=password_invalido");
    exit();
}

/*ROLES*/

$rolesPermitidos = [
    'administrador',
    'gerente_comercial',
    'gerente_tienda'
];

if (!in_array($rol, $rolesPermitidos, true)) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=rol_invalido");
    exit();
}

/*
|--------------------------------------------------------------------------
| NORMALIZAR TIENDAS
|--------------------------------------------------------------------------
*/

if (!is_array($tiendas)) {
    $tiendas = [];
}

$tiendas = array_map(static fn($valor) => trim((string)$valor), $tiendas);
$tiendas = array_filter($tiendas, static fn($valor) => $valor !== '');
$tiendas = array_values(array_unique($tiendas));

/*VALIDACION SEGUIN ROL*/

if ($rol === 'administrador') {
    $tiendas = [];
}

if ($rol === 'gerente_comercial' && count($tiendas) < 1) {
    header("Location: {$baseUrl}/config/agregar_user.php?error=tienda_requerida");
    exit();
}

if ($rol === 'gerente_tienda') {
    if (count($tiendas) !== 1) {
        header("Location: {$baseUrl}/config/agregar_user.php?error=una_sola_tienda");
        exit();
    }
}

/*
 VALIDAR Y OBTENER DATOS DE TIENDAS DESDE MENDELS (SQL SERVER)
*/

$infoTiendas = [];

if (!empty($tiendas)) {

    if (!isset($sqlsrv_conn_exhibicion) || $sqlsrv_conn_exhibicion === false) {
        header("Location: {$baseUrl}/config/agregar_user.php?error=guardar");
        exit();
    }

    $sqlValidarTienda = "
        SELECT TOP 1
            LTRIM(RTRIM(CODALMACEN)) AS CODALMACEN,
            LTRIM(RTRIM(NOMBREALMACEN)) AS NOMBREALMACEN,
            LTRIM(RTRIM(ISNULL(POBLACION, ''))) AS POBLACION
        FROM MENDELS.dbo.ALMACEN
        WHERE LTRIM(RTRIM(CODALMACEN)) = ?
          AND CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%SPS%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%S.P.S%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TGU%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TEGUCIGALPA%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%NI%'
    ";

    foreach ($tiendas as $codigoTienda) {

        $stmtTienda = sqlsrv_query(
            $sqlsrv_conn_exhibicion,
            $sqlValidarTienda,
            [$codigoTienda]
        );

        if ($stmtTienda === false) {
            header("Location: {$baseUrl}/config/agregar_user.php?error=guardar");
            exit();
        }

        $filaTienda = sqlsrv_fetch_array(
            $stmtTienda,
            SQLSRV_FETCH_ASSOC
        );

        sqlsrv_free_stmt($stmtTienda);

        // Si la tienda no existe o cae en los NOT LIKE (Centro SPS/TGU), detiene el proceso
        if (!$filaTienda) {
            header("Location: {$baseUrl}/config/agregar_user.php?error=tienda_invalida");
            exit();
        }

        $infoTiendas[] = [
            'codalmacen'    => $filaTienda['CODALMACEN'],
            'nombre_tienda' => $filaTienda['NOMBREALMACEN'],
            'poblacion'     => $filaTienda['POBLACION']
        ];
    }
}


        

/*
|--------------------------------------------------------------------------
| VERIFICAR USUARIO DUPLICADO
|--------------------------------------------------------------------------
*/

$stmtDuplicado = $conn->prepare("
    SELECT id
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

$stmtDuplicado->bind_param('s', $usuario);
$stmtDuplicado->execute();
$resultadoDuplicado = $stmtDuplicado->get_result();

if ($resultadoDuplicado->num_rows > 0) {
    $stmtDuplicado->close();
    header("Location: {$baseUrl}/config/agregar_user.php?error=usuario_duplicado");
    exit();
}

$stmtDuplicado->close();

/*
 HASH PASSWORD
*/

$passwordHash = password_hash($password, PASSWORD_DEFAULT);

/*
 TRANSACCIÓN MYSQL
*/

$conn->begin_transaction();

try {

    $estado = 1;

    $stmtUsuario = $conn->prepare("
        INSERT INTO usuarios
        (
            usuario,
            nombre_completo,
            password,
            rol,
            estado
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    if (!$stmtUsuario) {
        throw new Exception('No se pudo preparar usuario.');
    }

    $stmtUsuario->bind_param(
        'ssssi',
        $usuario,
        $nombreCompleto,
        $passwordHash,
        $rol,
        $estado
    );

    if (!$stmtUsuario->execute()) {
        throw new Exception('No se pudo crear el usuario.');
    }

    $usuarioId = $stmtUsuario->insert_id;
    $stmtUsuario->close();

    if (!empty($infoTiendas)) {

        $stmtInsertTienda = $conn->prepare("
            INSERT INTO usuario_tienda
            (
                usuario_id,
                codalmacen,
                nombre_tienda,
                poblacion
            )
            VALUES (?, ?, ?, ?)
        ");

        if (!$stmtInsertTienda) {
            throw new Exception('No se pudo preparar la asignación de tiendas.');
        }

        foreach ($infoTiendas as $tiendaData) {

            $stmtInsertTienda->bind_param(
                'isss',
                $usuarioId,
                $tiendaData['codalmacen'],
                $tiendaData['nombre_tienda'],
                $tiendaData['poblacion']
            );

            if (!$stmtInsertTienda->execute()) {
                throw new Exception('No se pudo asignar la tienda.');
            }
        }

        $stmtInsertTienda->close();
    }

        $conn->commit();
    // Auditoría
    try {
        $actor = (string)($_SESSION['usuario'] ?? 'DESCONOCIDO');
        $actorNombre = (string)($_SESSION['nombre_completo'] ?? $actor);
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA');

        $nombreRoles = [
            'administrador'      => 'Administrador',
            'gerente_comercial'  => 'Gerente Comercial',
            'gerente_tienda'     => 'Gerente de Tienda'
        ];
        $rolLegible = $nombreRoles[$rol] ?? $rol;

        if (!empty($infoTiendas)) {
            $listaTiendasAudit = [];
            foreach ($infoTiendas as $t) {
                $codigoAudit = trim((string)$t['codalmacen']);
                $nombreAudit = trim((string)$t['nombre_tienda']);
                $poblacionAudit = trim((string)$t['poblacion']);
                $ubicacionAudit = $poblacionAudit !== '' ? " ({$poblacionAudit})" : '';
                // Formateamos cada tienda con un salto de línea y sangría para la lista
                $listaTiendasAudit[] = "\n   • {$codigoAudit} - {$nombreAudit}{$ubicacionAudit}";
            }

            // Estructura limpia usando saltos de línea (\n) nativos
            $detalle = "Se creó un nuevo usuario en la aplicación.\n"
                     . "• Usuario: {$usuario}\n"
                     . "• Nombre: {$nombreCompleto}\n"
                     . "• Rol asignado: {$rolLegible}\n"
                     . "• Tiendas asignadas:" . implode('', $listaTiendasAudit);
        } else {
            // Estructura limpia para administradores
            $detalle = "Se creó un nuevo usuario en el sistema.\n"
                     . "• Usuario: «{$usuario}»\n"
                     . "• Nombre: {$nombreCompleto}\n"
                     . "• Rol asignado: {$rolLegible}\n"
                     . "• Tiendas asignadas: Sin tiendas asignadas por tratarse de un Administrador.";
        }

        $stmtAudit = $conn->prepare("
            INSERT INTO auditoria (nombre_completo, usuario, accion, ip, fecha, detalle)
            VALUES (?, ?, 'USUARIO_CREADO', ?, NOW(), ?)
        ");

        if ($stmtAudit) {
            $stmtAudit->bind_param('ssss', $actorNombre, $actor, $ip, $detalle);
            $stmtAudit->execute();
            $stmtAudit->close();
        }
    } catch (Throwable $auditError) {
        error_log('Auditoría crear usuario: ' . $auditError->getMessage());
    }

    header("Location: {$baseUrl}/config/agregar_user.php?ok=1");
    exit();

} catch (Throwable $e) {

    $conn->rollback();
    header("Location: {$baseUrl}/config/agregar_user.php?error=guardar_fallo");
    exit();
}
