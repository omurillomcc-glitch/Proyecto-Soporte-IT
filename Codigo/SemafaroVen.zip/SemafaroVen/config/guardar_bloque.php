<?php
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

session_name('APP_SEMAFARO');
session_start();

$baseUrl = $baseUrl ?? '/SemafaroVen';

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: {$baseUrl}/config/block.php");
    exit;
}

$csrfToken = (string)($_POST['csrf_token'] ?? '');

if (
    empty($_SESSION['csrf_token']) ||
    $csrfToken === '' ||
    !hash_equals((string)$_SESSION['csrf_token'], $csrfToken)
) {
    header("Location: {$baseUrl}/config/block.php?error=csrf");
    exit;
}

$usuario = trim((string)($_POST['usuario'] ?? ''));

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ]{3,50}$/u', $usuario)) {
    header("Location: {$baseUrl}/config/block.php?error=usuario_invalido");
    exit;
}

if ($usuario === (string)($_SESSION['usuario'] ?? '')) {
    header("Location: {$baseUrl}/config/block.php?error=no_bloquearse");
    exit;
}

$stmt = $conn->prepare("
    SELECT id, nombre_completo, estado
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

if (!$stmt) {
    header("Location: {$baseUrl}/config/block.php?error=guardar");
    exit;
}

$stmt->bind_param('s', $usuario);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    header("Location: {$baseUrl}/config/block.php?error=no_existe");
    exit;
}

$id = (int)$row['id'];
$nuevoEstado = (int)$row['estado'] === 1 ? 0 : 1;

if ($nuevoEstado === 1) {
    $up = $conn->prepare("
        UPDATE usuarios
        SET estado = 1, intentos = 0
        WHERE id = ?
    ");

    if ($up) $up->bind_param('i', $id);
} else {
    $up = $conn->prepare("
        UPDATE usuarios
        SET estado = 0
        WHERE id = ?
    ");

    if ($up) $up->bind_param('i', $id);
}

if (!$up || !$up->execute()) {
    if ($up) $up->close();

    header("Location: {$baseUrl}/config/block.php?error=guardar");
    exit;
}

$up->close();

try {
    $actor = (string)($_SESSION['usuario'] ?? 'DESCONOCIDO');
    $actorNombre = (string)($_SESSION['nombre_completo'] ?? $actor);
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA');
    $nombreObjetivo = trim((string)($row['nombre_completo'] ?? ''));

    $accion = $nuevoEstado === 1
        ? 'USUARIO_DESBLOQUEADO'
        : 'USUARIO_BLOQUEADO';

    $detalle = $nuevoEstado === 1
        ? "Se modificó el estado de acceso del usuario.\n"
          . "• Usuario: {$usuario}\n"
          . "• Nombre: {$nombreObjetivo}\n"
          . "• Estado: Activado (Acceso al sistema permitido)."
        : "Se modificó el estado de acceso del usuario.\n"
          . "• Usuario: {$usuario}\n"
          . "• Nombre: {$nombreObjetivo}\n"
          . "• Estado: Bloqueado (Acceso al sistema revocado).";

    $a = $conn->prepare("
        INSERT INTO auditoria
        (nombre_completo, usuario, accion, ip, fecha, detalle)
        VALUES (?, ?, ?, ?, NOW(), ?)
    ");

    if ($a) {
        $a->bind_param(
            'sssss',
            $actorNombre,
            $actor,
            $accion,
            $ip,
            $detalle
        );

        $a->execute();
        $a->close();
    }

} catch (Throwable $e) {
    error_log('Auditoría bloqueo: ' . $e->getMessage());
}

header("Location: {$baseUrl}/config/block.php?ok_estado=1");
exit;