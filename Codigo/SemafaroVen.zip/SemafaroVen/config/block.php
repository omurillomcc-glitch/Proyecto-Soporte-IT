<?php
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

session_name('APP_SEMAFARO');
session_start();

$baseUrl = $baseUrl ?? '/SemafaroVen';

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$permitidos = [100, 200, 500];
$porPagina = (int)($_GET['por_pagina'] ?? 100);

if (!in_array($porPagina, $permitidos, true)) {
    $porPagina = 100;
}

$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$buscar = trim((string)($_GET['buscar'] ?? ''));

$where = '';
$params = [];
$types = '';

if ($buscar !== '') {
    $where = 'WHERE usuario LIKE ? OR nombre_completo LIKE ? OR rol LIKE ?';
    $like = "%{$buscar}%";
    $params = [$like, $like, $like];
    $types = 'sss';
}

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM usuarios {$where}");

if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();

$totalRegistros = (int)(
    $stmt->get_result()->fetch_assoc()['total'] ?? 0
);

$stmt->close();

$totalPaginas = max(
    1,
    (int)ceil($totalRegistros / $porPagina)
);

if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}

$offset = ($pagina - 1) * $porPagina;

$stmt = $conn->prepare("
    SELECT usuario, nombre_completo, rol, estado, creado_en
    FROM usuarios
    {$where}
    ORDER BY nombre_completo ASC
    LIMIT ? OFFSET ?
");

if ($types !== '') {
    $tipos = $types . 'ii';
    $datos = array_merge($params, [$porPagina, $offset]);
    $stmt->bind_param($tipos, ...$datos);
} else {
    $stmt->bind_param('ii', $porPagina, $offset);
}

$stmt->execute();
$res = $stmt->get_result();

$usuarios = [];

while ($row = $res->fetch_assoc()) {
    $usuarios[] = $row;
}

$stmt->close();

function urlBloquear(array $extra = []): string {
    return '/SemafaroVen/config/block.php?' .
        http_build_query(array_merge($_GET, $extra));
}

require_once dirname(__DIR__) . '/layout_menu.php';
?>

<link rel="stylesheet" href="<?= $baseUrl ?>/config/useredit.css?v=<?= time() ?>">
<link rel="stylesheet" href="<?= $baseUrl ?>/config/block.css?v=<?= time() ?>">

<div class="user-page block-page">

<?php if (isset($_GET['ok_estado'])): ?>
    <div class="alert success">
        <i class="bi bi-check-circle-fill"></i>
        <div>
            <strong>Estado actualizado correctamente.</strong>
            <span>Los cambios han sido registrados en la auditoría.</span>
        </div>
    </div>
<?php endif; ?>

<?php
if (isset($_GET['error'])):

    $mensajeError = match ($_GET['error']) {
        'no_bloquearse' =>
            'Eres administrador. No puedes bloquear tu propio usuario.',

        'csrf' =>
            'La sesión del formulario expiró. Actualice la página e inténtelo nuevamente.',

        'usuario_invalido' =>
            'El nombre de usuario seleccionado no es válido.',

        'no_existe' =>
            'El usuario seleccionado no existe en el sistema.',

        'guardar' =>
            'No se pudieron guardar los cambios en la base de datos.',

        default =>
            'No se pudo actualizar el estado del usuario.'
    };
?>
    <div class="alert danger">
        <i class="bi bi-exclamation-triangle-fill"></i>

        <div>
            <strong>No se pudo actualizar el usuario.</strong>

            <span>
                <?= htmlspecialchars(
                    $mensajeError,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </span>
        </div>
    </div>
<?php endif; ?>

<div class="edit-layout block-layout">

    <aside class="panel user-list-panel">

        <div class="panel-head compact">
            <div>
                <span class="eyebrow">
                    Usuarios registrados
                </span>
            </div>

            <span class="count-pill">
                <?= $totalRegistros ?>
            </span>
        </div>

        <form method="GET" class="search-row">

            <div class="search-box">
                <i class="bi bi-search"></i>

                <input
                    type="text"
                    name="buscar"
                    value="<?= htmlspecialchars(
                        $buscar,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                    placeholder="Buscar usuario..."
                    autocomplete="off"
                >
            </div>

            <select
                name="por_pagina"
                aria-label="Usuarios por página"
            >
                <option
                    value="100"
                    <?= $porPagina === 100 ? 'selected' : '' ?>
                >
                    100
                </option>

                <option
                    value="200"
                    <?= $porPagina === 200 ? 'selected' : '' ?>
                >
                    200
                </option>

                <option
                    value="500"
                    <?= $porPagina === 500 ? 'selected' : '' ?>
                >
                    500
                </option>
            </select>

            <button
                type="submit"
                class="icon-button"
                title="Buscar"
            >
                <i class="bi bi-search"></i>
            </button>

            <a
                href="<?= $baseUrl ?>/config/block.php"
                class="icon-button clear"
                title="Limpiar"
            >
                <i class="bi bi-arrow-counterclockwise"></i>
            </a>

        </form>

        <div
            class="user-list"
            id="blockUserList"
        >

        <?php foreach ($usuarios as $index => $u): ?>

            <button
                type="button"
                class="user-row <?= $index === 0 ? 'selected' : '' ?>"
                data-usuario="<?= htmlspecialchars(
                    $u['usuario'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                data-nombre="<?= htmlspecialchars(
                    $u['nombre_completo'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                data-rol="<?= htmlspecialchars(
                    $u['rol'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                data-estado="<?= (int)$u['estado'] ?>"
            >

                <span class="avatar">
                    <?= htmlspecialchars(
                        strtoupper(
                            substr(
                                $u['usuario'],
                                0,
                                1
                            )
                        ),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </span>

                <span class="user-copy">
                    <strong>
                        <?= htmlspecialchars($u['usuario']) ?>
                    </strong>

                    <small>
                        <?= htmlspecialchars(
                            $u['nombre_completo']
                        ) ?>
                    </small>
                </span>

                <span
                    class="status-badge <?= (int)$u['estado'] === 1
                        ? 'active'
                        : 'blocked' ?>"
                >
                    <?= (int)$u['estado'] === 1
                        ? 'Activo'
                        : 'Bloqueado' ?>
                </span>

                <span class="chevron">›</span>

            </button>

        <?php endforeach; ?>

        <?php if (!$usuarios): ?>

            <div class="empty-users">
                No hay usuarios registrados.
            </div>

        <?php endif; ?>

        </div>

        <div class="pagination-wrap">

            <span>
                Página <?= $pagina ?>
                de <?= $totalPaginas ?>
            </span>

            <div class="pagination">

                <?php if ($pagina > 1): ?>

                    <a href="<?= htmlspecialchars(
                        urlBloquear([
                            'pagina' => $pagina - 1
                        ]),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>">
                        ‹
                    </a>

                <?php endif; ?>

                <?php for (
                    $p = 1;
                    $p <= $totalPaginas;
                    $p++
                ): ?>

                    <a
                        href="<?= htmlspecialchars(
                            urlBloquear([
                                'pagina' => $p
                            ]),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        class="<?= $p === $pagina
                            ? 'active'
                            : '' ?>"
                    >
                        <?= $p ?>
                    </a>

                <?php endfor; ?>

                <?php if ($pagina < $totalPaginas): ?>

                    <a href="<?= htmlspecialchars(
                        urlBloquear([
                            'pagina' => $pagina + 1
                        ]),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>">
                        ›
                    </a>

                <?php endif; ?>

            </div>

        </div>

    </aside>


    <section class="panel edit-form-panel">

        <div class="panel-head form-title">

            <div>
                <h2>Estado del usuario</h2>

                <p>
                    Seleccione un usuario y cambie
                    únicamente su estado de acceso.
                </p>
            </div>

            <?php if ($usuarios): ?>

                <span
                    id="blockSelectedStatus"
                    class="status-badge <?= (int)$usuarios[0]['estado'] === 1
                        ? 'active'
                        : 'blocked' ?>"
                >
                    <?= (int)$usuarios[0]['estado'] === 1
                        ? 'Activo'
                        : 'Bloqueado' ?>
                </span>

            <?php endif; ?>

        </div>

        <?php if ($usuarios):
            $primero = $usuarios[0];

            $rolPrimero = match ($primero['rol']) {
                'administrador' => 'Administrador',
                'gerente_comercial' => 'Gerente Comercial',
                'gerente_tienda' => 'Gerente de Tienda',
                default => $primero['rol']
            };
        ?>

        <form
            method="POST"
            action="<?= $baseUrl ?>/config/guardar_bloque.php"
            class="user-form block-detail-form"
            id="blockForm"
            onsubmit="return confirmBlockAction(this)"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars(
                    $_SESSION['csrf_token'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
            >

            <input
                type="hidden"
                name="usuario"
                id="block_usuario"
                value="<?= htmlspecialchars(
                    $primero['usuario'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
            >

            <input
                type="hidden"
                name="estado_actual"
                id="block_estado_actual"
                value="<?= (int)$primero['estado'] ?>"
            >

            <div class="form-grid">

                <div class="form-group">
                    <label>Usuario</label>

                    <input
                        id="block_usuario_visual"
                        type="text"
                        value="<?= htmlspecialchars(
                            $primero['usuario']
                        ) ?>"
                        readonly
                    >
                </div>

                <div class="form-group">
                    <label>Nombre completo</label>

                    <input
                        id="block_nombre"
                        type="text"
                        value="<?= htmlspecialchars(
                            $primero['nombre_completo']
                        ) ?>"
                        readonly
                    >
                </div>

                <div class="form-group">
                    <label>Rol</label>

                    <input
                        id="block_rol"
                        type="text"
                        value="<?= htmlspecialchars($rolPrimero) ?>"
                        readonly
                    >
                </div>

                <div class="form-group">
                    <label>Estado actual</label>

                    <input
                        id="block_estado_visual"
                        type="text"
                        value="<?= (int)$primero['estado'] === 1
                            ? 'Activo'
                            : 'Bloqueado' ?>"
                        readonly
                    >
                </div>

            </div>

            <div
                id="blockMessage"
                class="security-state <?= (int)$primero['estado'] === 1
                    ? 'is-active'
                    : 'is-blocked' ?>"
            >

                <span class="security-icon">
                    <?= (int)$primero['estado'] === 1
                        ? '✓'
                        : '!' ?>
                </span>

                <div>

                    <strong>
                        <?= (int)$primero['estado'] === 1
                            ? 'El usuario tiene acceso al sistema'
                            : 'El usuario está bloqueado' ?>
                    </strong>

                    <small>
                        <?= (int)$primero['estado'] === 1
                            ? 'Puede iniciar sesión normalmente.'
                            : 'No puede iniciar sesión hasta que sea activado.' ?>
                    </small>

                </div>

            </div>

            <div class="form-note">
                <span class="note-icon">i</span>

                Esta opción no elimina el usuario
                ni modifica sus demás datos.
            </div>

            <div class="actions">

                <button
                    type="button"
                    class="btn-secondary"
                    onclick="window.location.reload()"
                >
                    <i class="bi bi-x-circle"></i>
                    Cancelar
                </button>

                <button
                    type="submit"
                    id="blockActionButton"
                    class="btn-primary block-action-button"
                >

                    <i
                        class="bi <?= (int)$primero['estado'] === 1
                            ? 'bi-lock-fill'
                            : 'bi-unlock-fill' ?>"
                    ></i>

                    <span class="btn-text">
                        <?= (int)$primero['estado'] === 1
                            ? 'Bloquear'
                            : 'Activar' ?>
                    </span>

                </button>

            </div>

        </form>

        <?php else: ?>

            <div class="empty-form">
                No hay usuarios disponibles.
            </div>

        <?php endif; ?>

    </section>

</div>
</div>

<script>
(function () {

    const rows =
        document.querySelectorAll('#blockUserList .user-row');

    const hiddenUsuario =
        document.getElementById('block_usuario');

    const hiddenEstado =
        document.getElementById('block_estado_actual');

    const usuarioVisual =
        document.getElementById('block_usuario_visual');

    const nombre =
        document.getElementById('block_nombre');

    const rol =
        document.getElementById('block_rol');

    const estadoVisual =
        document.getElementById('block_estado_visual');

    const status =
        document.getElementById('blockSelectedStatus');

    const actionButton =
        document.getElementById('blockActionButton');

    const message =
        document.getElementById('blockMessage');

    if (!hiddenUsuario) return;

    const roles = {
        administrador: 'Administrador',
        gerente_comercial: 'Gerente Comercial',
        gerente_tienda: 'Gerente de Tienda'
    };

    rows.forEach(row => {

        row.addEventListener('click', function () {

            rows.forEach(r =>
                r.classList.remove('selected')
            );

            this.classList.add('selected');

            const usuario = this.dataset.usuario;
            const nombreValue = this.dataset.nombre;
            const rolValue = this.dataset.rol;
            const estado = this.dataset.estado;

            const activo = estado === '1';

            hiddenUsuario.value = usuario;
            hiddenEstado.value = estado;

            usuarioVisual.value = usuario;
            nombre.value = nombreValue;

            rol.value =
                roles[rolValue] ?? rolValue;

            estadoVisual.value =
                activo
                    ? 'Activo'
                    : 'Bloqueado';

            status.textContent =
                activo
                    ? 'Activo'
                    : 'Bloqueado';

            status.className =
                'status-badge ' +
                (activo
                    ? 'active'
                    : 'blocked');

            actionButton.innerHTML =
                '<i class="bi ' +
                (activo
                    ? 'bi-lock-fill'
                    : 'bi-unlock-fill') +
                '"></i>' +
                '<span class="btn-text">' +
                (activo
                    ? 'Bloquear'
                    : 'Activar') +
                '</span>';

            message.className =
                'security-state ' +
                (activo
                    ? 'is-active'
                    : 'is-blocked');

            message.querySelector(
                '.security-icon'
            ).textContent =
                activo
                    ? '✓'
                    : '!';

            message.querySelector(
                'strong'
            ).textContent =
                activo
                    ? 'El usuario tiene acceso al sistema'
                    : 'El usuario está bloqueado';

            message.querySelector(
                'small'
            ).textContent =
                activo
                    ? 'Puede iniciar sesión normalmente.'
                    : 'No puede iniciar sesión hasta que sea activado.';

        });

    });

})();

function confirmBlockAction(form) {

    const estado =
        form.querySelector(
            '[name="estado_actual"]'
        ).value;

    const usuario =
        form.querySelector(
            '[name="usuario"]'
        ).value;

    const accion =
        estado === '1'
            ? '¿Bloquear a '
            : '¿Activar a ';

    return window.confirm(
        accion + usuario + '?'
    );
}
</script>

<?php
require_once dirname(__DIR__) . '/layout_footer.php';
?>