<?php
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

session_name('APP_SEMAFARO');
session_start();

$baseUrl = $baseUrl ?? '/SemafaroVen';

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';

if ($conn instanceof mysqli) $conn->set_charset('utf8mb4');

function volver(string $error): never {
    global $baseUrl;
    header("Location: {$baseUrl}/config/edit_user.php?error={$error}");
    exit;
}

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: {$baseUrl}/config/edit_user.php");
    exit;
}

$csrf = (string)($_POST['csrf_token'] ?? '');

if (
    empty($_SESSION['csrf_token']) ||
    $csrf === '' ||
    !hash_equals((string)$_SESSION['csrf_token'], $csrf)
) {
    volver('csrf');
}

$usuarioOriginal = trim((string)($_POST['usuario_original'] ?? ''));
$nombreCompleto = trim((string)($_POST['nombre_completo'] ?? ''));
$rol = trim((string)($_POST['rol'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$tiendas = $_POST['tiendas'] ?? [];

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ]{3,50}$/u', $usuarioOriginal)) {
    volver('usuario_invalido');
}

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/u', $nombreCompleto)) {
    volver('nombre_invalido');
}

if ($password !== '' && !preg_match('/^\S{6,30}$/u', $password)) {
    volver('password_invalido');
}

$roles = ['administrador', 'gerente_comercial', 'gerente_tienda'];

if (!in_array($rol, $roles, true)) {
    volver('rol_invalido');
}

if (!is_array($tiendas)) $tiendas = [];

$tiendas = array_values(array_unique(array_filter(
    array_map(static fn($v) => trim((string)$v), $tiendas),
    static fn($v) => $v !== ''
)));

if ($rol === 'administrador') $tiendas = [];

if ($rol === 'gerente_comercial' && count($tiendas) < 1) {
    volver('tienda_requerida');
}

if ($rol === 'gerente_tienda' && count($tiendas) !== 1) {
    volver('una_sola_tienda');
}

if (
    $usuarioOriginal === (string)($_SESSION['usuario'] ?? '') &&
    $rol !== 'administrador'
) {
    volver('no_quitar_admin');
}

if ($tiendas) {

    if (
        !isset($sqlsrv_conn_exhibicion) ||
        $sqlsrv_conn_exhibicion === false
    ) {
        volver('tienda_invalida');
    }

    $sqlT = "
        SELECT TOP 1 CODALMACEN
        FROM MENDELS.dbo.ALMACEN
        WHERE LTRIM(RTRIM(CODALMACEN)) = ?
          AND CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%SPS%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%S.P.S%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TGU%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TEGUCIGALPA%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%NI%'
    ";

    foreach ($tiendas as $codigo) {

        $st = sqlsrv_query(
            $sqlsrv_conn_exhibicion,
            $sqlT,
            [$codigo]
        );

        if (
            $st === false ||
            !sqlsrv_fetch_array($st, SQLSRV_FETCH_ASSOC)
        ) {
            if ($st !== false) sqlsrv_free_stmt($st);
            volver('tienda_invalida');
        }

        sqlsrv_free_stmt($st);
    }
}

$stmt = $conn->prepare("
    SELECT id, nombre_completo, rol
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

if (!$stmt) volver('error_guardar');

$stmt->bind_param('s', $usuarioOriginal);
$stmt->execute();
$actual = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$actual) volver('no_existe');

$usuarioId = (int)$actual['id'];
$nombreAnterior = (string)$actual['nombre_completo'];
$rolAnterior = (string)$actual['rol'];

$tiendasAnteriores = [];

$stmt = $conn->prepare("
    SELECT codalmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY codalmacen
");

if ($stmt) {
    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $res = $stmt->get_result();

    while ($fila = $res->fetch_assoc()) {
        $tiendasAnteriores[] = trim((string)$fila['codalmacen']);
    }

    $stmt->close();
}

$infoTiendas = [];

if (
    $tiendas &&
    isset($sqlsrv_conn_exhibicion) &&
    $sqlsrv_conn_exhibicion !== false
) {

    $placeholders = implode(',', array_fill(0, count($tiendas), '?'));

    $sqlInfo = "
        SELECT
            LTRIM(RTRIM(CODALMACEN)) AS CODALMACEN,
            LTRIM(RTRIM(NOMBREALMACEN)) AS NOMBREALMACEN,
            LTRIM(RTRIM(ISNULL(POBLACION,''))) AS POBLACION
        FROM MENDELS.dbo.ALMACEN
        WHERE LTRIM(RTRIM(CODALMACEN)) IN ({$placeholders})
          AND CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%SPS%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%S.P.S%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TGU%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TEGUCIGALPA%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%NI%'
    ";

    $st = sqlsrv_query(
        $sqlsrv_conn_exhibicion,
        $sqlInfo,
        $tiendas
    );

    if ($st !== false) {

        while ($fila = sqlsrv_fetch_array($st, SQLSRV_FETCH_ASSOC)) {

            $codigo = trim((string)$fila['CODALMACEN']);
            $nombre = trim((string)$fila['NOMBREALMACEN']);
            $poblacion = trim((string)$fila['POBLACION']);

            if (!mb_detect_encoding($nombre, 'UTF-8', true)) {
                $nombre = mb_convert_encoding(
                    $nombre,
                    'UTF-8',
                    'ISO-8859-1'
                );
            }

            if (!mb_detect_encoding($poblacion, 'UTF-8', true)) {
                $poblacion = mb_convert_encoding(
                    $poblacion,
                    'UTF-8',
                    'ISO-8859-1'
                );
            }

            $infoTiendas[$codigo] = [
                'nombre' => $nombre,
                'poblacion' => $poblacion
            ];
        }

        sqlsrv_free_stmt($st);
    }
}

$conn->begin_transaction();

try {

    if ($password !== '') {

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET nombre_completo = ?, rol = ?, password = ?
            WHERE id = ?
        ");

        if (!$stmt) throw new Exception('update');

        $stmt->bind_param(
            'sssi',
            $nombreCompleto,
            $rol,
            $hash,
            $usuarioId
        );

    } else {

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET nombre_completo = ?, rol = ?
            WHERE id = ?
        ");

        if (!$stmt) throw new Exception('update');

        $stmt->bind_param(
            'ssi',
            $nombreCompleto,
            $rol,
            $usuarioId
        );
    }

    if (!$stmt->execute()) throw new Exception('update');
    $stmt->close();

    $stmt = $conn->prepare("
        DELETE FROM usuario_tienda
        WHERE usuario_id = ?
    ");

    if (!$stmt) throw new Exception('delete');

    $stmt->bind_param('i', $usuarioId);

    if (!$stmt->execute()) throw new Exception('delete');

    $stmt->close();

    if ($tiendas) {

        $stmt = $conn->prepare("
            INSERT INTO usuario_tienda
            (usuario_id, codalmacen, nombre_tienda, poblacion)
            VALUES (?, ?, ?, ?)
        ");

        if (!$stmt) throw new Exception('insert');

        foreach ($tiendas as $codigo) {

            $nombreTienda =
                $infoTiendas[$codigo]['nombre'] ?? 'MENDELS';

            $poblacion =
                $infoTiendas[$codigo]['poblacion'] ?? '';

            $stmt->bind_param(
                'isss',
                $usuarioId,
                $codigo,
                $nombreTienda,
                $poblacion
            );

            if (!$stmt->execute()) {
                throw new Exception('insert');
            }
        }

        $stmt->close();
    }

    $conn->commit();

    try {

        $actor = (string)($_SESSION['usuario'] ?? 'DESCONOCIDO');

        $actorNombre = (string)(
            $_SESSION['nombre_completo'] ?? $actor
        );

        $ip = (string)(
            $_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA'
        );

        $nombreRoles = [
            'administrador' => 'Administrador',
            'gerente_comercial' => 'Gerente Comercial',
            'gerente_tienda' => 'Gerente de Tienda'
        ];

        $sqlsrvAudit =
            $sqlsrv_conn_exhibicion ?? false;

        $formatearTiendasAudit = function(array $codigos)
            use ($sqlsrvAudit): string {

            if (!$codigos) return ' ninguna';

            if ($sqlsrvAudit === false) {
                return ' ' . implode(', ', $codigos);
            }

            $placeholders =
                implode(',', array_fill(0, count($codigos), '?'));

            $sql = "
                SELECT
                    LTRIM(RTRIM(CODALMACEN)) AS CODALMACEN,
                    LTRIM(RTRIM(NOMBREALMACEN)) AS NOMBREALMACEN,
                    LTRIM(RTRIM(ISNULL(POBLACION,''))) AS POBLACION
                FROM MENDELS.dbo.ALMACEN
                WHERE LTRIM(RTRIM(CODALMACEN))
                      IN ({$placeholders})
            ";

            $st = sqlsrv_query(
                $sqlsrvAudit,
                $sql,
                $codigos
            );

            $resultado = [];

            if ($st !== false) {

                while (
                    $fila = sqlsrv_fetch_array(
                        $st,
                        SQLSRV_FETCH_ASSOC
                    )
                ) {

                    $cod = trim((string)$fila['CODALMACEN']);
                    $nom = trim((string)$fila['NOMBREALMACEN']);
                    $pob = trim((string)$fila['POBLACION']);

                    if (!mb_detect_encoding($nom, 'UTF-8', true)) {
                        $nom = mb_convert_encoding(
                            $nom,
                            'UTF-8',
                            'ISO-8859-1'
                        );
                    }

                    if (!mb_detect_encoding($pob, 'UTF-8', true)) {
                        $pob = mb_convert_encoding(
                            $pob,
                            'UTF-8',
                            'ISO-8859-1'
                        );
                    }

                    $ubicacion =
                        $pob !== ''
                        ? " ({$pob})"
                        : '';

                    $resultado[] =
                        "\n     • {$cod} - {$nom}{$ubicacion}";
                }

                sqlsrv_free_stmt($st);
            }

            return $resultado
                ? implode('', $resultado)
                : ' ' . implode(', ', $codigos);
        };

        $cambios = [];

        if ($nombreAnterior !== $nombreCompleto) {
            $cambios[] =
                "• Nombre: «{$nombreAnterior}» A «{$nombreCompleto}»";
        }

        if ($rolAnterior !== $rol) {

            $rolAnteriorLegible =
                $nombreRoles[$rolAnterior] ?? $rolAnterior;

            $rolNuevoLegible =
                $nombreRoles[$rol] ?? $rol;

            $cambios[] =
                "• Rol: {$rolAnteriorLegible} A {$rolNuevoLegible}";
        }

        if ($password !== '') {
            $cambios[] =
                '• Contraseña: Actualizada';
        }

        $anteriores = $tiendasAnteriores;
        $nuevas = $tiendas;

        sort($anteriores);
        sort($nuevas);

        $agregadas = array_values(
            array_diff($nuevas, $anteriores)
        );

        $retiradas = array_values(
            array_diff($anteriores, $nuevas)
        );

        if ($agregadas) {
            $cambios[] =
                '• Tiendas agregadas:'
                . $formatearTiendasAudit($agregadas);
        }

        if ($retiradas) {
            $cambios[] =
                '• Tiendas retiradas:'
                . $formatearTiendasAudit($retiradas);
        }

        if ($cambios) {

            $detalle =
                "Se modificaron los datos del usuario.\n"
                . "Objetivo: {$usuarioOriginal} ({$nombreCompleto})\n"
                . "Cambios realizados:\n"
                . implode("\n", $cambios);

        } else {

            $detalle =
                "Se revisó el usuario «{$usuarioOriginal}» "
                . "({$nombreCompleto}).\n"
                . "Resultado: Sin modificaciones realizadas.";
        }

        if (!mb_detect_encoding($detalle, 'UTF-8', true)) {
            $detalle = mb_convert_encoding(
                $detalle,
                'UTF-8',
                'ISO-8859-1'
            );
        }

        $stmt = $conn->prepare("
            INSERT INTO auditoria
            (nombre_completo, usuario, accion, ip, fecha, detalle)
            VALUES (?, ?, 'USUARIO_EDITADO', ?, NOW(), ?)
        ");

        if ($stmt) {

            $stmt->bind_param(
                'ssss',
                $actorNombre,
                $actor,
                $ip,
                $detalle
            );

            $stmt->execute();
            $stmt->close();
        }

    } catch (Throwable $e) {
        error_log(
            'Auditoría editar usuario: '
            . $e->getMessage()
        );
    }

    header(
        "Location: {$baseUrl}/config/edit_user.php?ok_edit=1"
    );
    exit;

} catch (Throwable $e) {

    $conn->rollback();

    error_log(
        'Guardar editar: '
        . $e->getMessage()
    );

    volver('error_guardar');
}