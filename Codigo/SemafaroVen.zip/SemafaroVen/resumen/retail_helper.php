<?php

declare(strict_types=1);

function retail_h(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');
}

function retail_fecha_es($fecha): string
{
    if ($fecha instanceof DateTimeInterface) {
        return $fecha->format('d/m/Y');
    }

    if (is_string($fecha) && $fecha !== '') {
        try {
            return (new DateTimeImmutable($fecha))->format('d/m/Y');
        } catch (Throwable $e) {
            return $fecha;
        }
    }

    return '';
}

function retail_mes_nombre(int $mes): string
{
    $meses = [
        1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
        5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
        9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre',
    ];

    return $meses[$mes] ?? '';
}

function retail_meta_formato(float $meta): string
{
    return 'L ' . number_format($meta, 2, '.', ',');
}

function retail_normalizar_meta(string $valor): ?float
{
    $valor = trim($valor);

    if ($valor === '' || !preg_match('/^\d{1,12}$/', $valor)) {
        return null;
    }

    $numero = (float)$valor;

    // La meta siempre debe ser mayor que cero.
    return (is_finite($numero) && $numero > 0 && $numero <= 999999999999)
        ? $numero
        : null;
}

function retail_archivo_config(): string
{
    return __DIR__ . '/config/retail_years.json';
}

function retail_leer_config(): array
{
    $archivo = retail_archivo_config();

    if (!is_file($archivo)) {
        return [];
    }

    $json = file_get_contents($archivo);
    if ($json === false || trim($json) === '') {
        return [];
    }

    $data = json_decode($json, true);
    return is_array($data) ? $data : [];
}

/**
 
 * Regla MCC usada por el sistema: la Semana Retail 1 inicia el primer lunes
 * de enero. Para 2026 esto produce 05/01/2026, igual al calendario base.
 */
function retail_inicio_automatico_anio(int $anio): DateTimeImmutable
{
    $tz = new DateTimeZone('America/Tegucigalpa');
    $primero = new DateTimeImmutable(sprintf('%04d-01-01', $anio), $tz);

    if ($primero->format('N') === '1') {
        return $primero;
    }

    return $primero->modify('next monday');
}

/**
 * Devuelve la configuración de un año.
 * se calculan solos los años, sin intervención del administrador.
 */
function retail_config_anio(int $anio): array
{
    $config = retail_leer_config();

    if (isset($config[(string)$anio]) && is_array($config[(string)$anio])) {
        $dato = $config[(string)$anio];
        $inicioTexto = (string)($dato['inicio_semana_1'] ?? '');
        $semanas = (int)($dato['semanas'] ?? 0);

        if ($inicioTexto !== '' && in_array($semanas, [52, 53], true)) {
            return [
                'inicio_semana_1' => $inicioTexto,
                'semanas' => $semanas,
                'protegido' => (bool)($dato['protegido'] ?? false),
                'automatico' => false,
            ];
        }
    }

    $inicio = retail_inicio_automatico_anio($anio);
    $inicioSiguiente = retail_inicio_automatico_anio($anio + 1);
    $dias = (int)$inicio->diff($inicioSiguiente)->format('%a');
    $semanas = intdiv($dias, 7);

    if (!in_array($semanas, [52, 53], true)) {
        $semanas = 52;
    }

    return [
        'inicio_semana_1' => $inicio->format('Y-m-d'),
        'semanas' => $semanas,
        'protegido' => true,
        'automatico' => true,
    ];
}

function retail_fin_config(array $dato): ?DateTimeImmutable
{
    try {
        $tz = new DateTimeZone('America/Tegucigalpa');
        $inicio = new DateTimeImmutable((string)$dato['inicio_semana_1'], $tz);
        $semanas = (int)($dato['semanas'] ?? 52);

        if (!in_array($semanas, [52, 53], true)) {
            return null;
        }

        return $inicio->modify('+' . (($semanas * 7) - 1) . ' days');
    } catch (Throwable $e) {
        return null;
    }
}

function retail_semana_por_fecha(DateTimeImmutable $fecha): ?array
{
    $tz = new DateTimeZone('America/Tegucigalpa');
    $fecha = $fecha->setTimezone($tz)->setTime(0, 0, 0);

    // Una semana de enero puede pertenecer al año Retail anterior.
    $anioCalendario = (int)$fecha->format('Y');

    foreach ([$anioCalendario - 1, $anioCalendario, $anioCalendario + 1] as $anio) {
        $dato = retail_config_anio($anio);

        try {
            $inicio = new DateTimeImmutable((string)$dato['inicio_semana_1'], $tz);
        } catch (Throwable $e) {
            continue;
        }

        $semanas = (int)$dato['semanas'];
        $fin = $inicio->modify('+' . (($semanas * 7) - 1) . ' days');

        if ($fecha < $inicio || $fecha > $fin) {
            continue;
        }

        $dias = (int)$inicio->diff($fecha)->format('%a');
        $semana = intdiv($dias, 7) + 1;
        $fechaInicio = $inicio->modify('+' . (($semana - 1) * 7) . ' days');

        return [
            'anio' => $anio,
            'semana' => $semana,
            'fecha_inicio' => $fechaInicio,
            'fecha_fin' => $fechaInicio->modify('+6 days'),
        ];
    }

    return null;
}

function retail_obtener_semana_actual($sqlsrvConn = null, ?DateTimeImmutable $fecha = null): ?array
{
    $tz = new DateTimeZone('America/Tegucigalpa');
    $fecha = $fecha
        ? $fecha->setTimezone($tz)->setTime(0, 0, 0)
        : new DateTimeImmutable('today', $tz);

    return retail_semana_por_fecha($fecha);
}

/**
 * Semanas Retail que tocan el mes seleccionado.
 * Esto incluye una semana que haya comenzado al final del mes anterior o que
 * termine al inicio del mes siguiente, evitando ocultar la semana actual.
 */
function retail_obtener_semanas_mes(int $anioCalendario, int $mes): array
{
    if ($anioCalendario < 2026 || $mes < 1 || $mes > 12) {
        return [];
    }

    $tz = new DateTimeZone('America/Tegucigalpa');
    $inicioMes = new DateTimeImmutable(sprintf('%04d-%02d-01', $anioCalendario, $mes), $tz);
    $finMes = $inicioMes->modify('last day of this month');

    $cursor = $inicioMes;
    $semanas = [];
    $vistos = [];

    while ($cursor <= $finMes) {
        $semana = retail_semana_por_fecha($cursor);

        if ($semana) {
            $clave = $semana['anio'] . '-' . $semana['semana'];
            if (!isset($vistos[$clave])) {
                $vistos[$clave] = true;
                $semanas[] = $semana;
            }
        }

        $cursor = $cursor->modify('+1 day');
    }

    usort($semanas, static function (array $a, array $b): int {
        return $a['fecha_inicio'] <=> $b['fecha_inicio'];
    });

    return $semanas;
}

function retail_obtener_tiendas_permitidas(mysqli $conn, $sqlsrvConn, string $rol, int $usuarioId): array
{
    if ($sqlsrvConn === false || $sqlsrvConn === null) {
        return [];
    }

    $sqlBase = "
        SELECT
            LTRIM(RTRIM(CODALMACEN)) AS CODALMACEN,
            LTRIM(RTRIM(NOMBREALMACEN)) AS NOMBREALMACEN,
            LTRIM(RTRIM(ISNULL(POBLACION, ''))) AS POBLACION
        FROM MENDELS.dbo.ALMACEN
        WHERE CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%SPS%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%S.P.S%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TGU%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TEGUCIGALPA%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%NI%'
    ";

    $params = [];

    if ($rol !== 'administrador') {
        $codigos = [];
        $stmt = $conn->prepare('SELECT codalmacen FROM usuario_tienda WHERE usuario_id = ? ORDER BY codalmacen');

        if (!$stmt) {
            return [];
        }

        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $res = $stmt->get_result();

        while ($fila = $res->fetch_assoc()) {
            $codigo = trim((string)($fila['codalmacen'] ?? ''));
            if ($codigo !== '') {
                $codigos[] = $codigo;
            }
        }

        $stmt->close();
        $codigos = array_values(array_unique($codigos));

        if (empty($codigos)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($codigos), '?'));
        $sqlBase .= " AND LTRIM(RTRIM(CODALMACEN)) IN ({$placeholders})";
        $params = $codigos;
    }

    $sqlBase .= ' ORDER BY TRY_CONVERT(INT, CODALMACEN), CODALMACEN';
    $stmtSql = sqlsrv_query($sqlsrvConn, $sqlBase, $params);

    if ($stmtSql === false) {
        return [];
    }

    $tiendas = [];

    while ($fila = sqlsrv_fetch_array($stmtSql, SQLSRV_FETCH_ASSOC)) {
        $codigo = trim((string)$fila['CODALMACEN']);
        $nombre = trim((string)$fila['NOMBREALMACEN']);
        $poblacion = trim((string)$fila['POBLACION']);

        if (!mb_detect_encoding($nombre, 'UTF-8', true)) {
            $nombre = mb_convert_encoding($nombre, 'UTF-8', 'ISO-8859-1');
        }
        if (!mb_detect_encoding($poblacion, 'UTF-8', true)) {
            $poblacion = mb_convert_encoding($poblacion, 'UTF-8', 'ISO-8859-1');
        }

        $tiendas[$codigo] = [
            'codigo' => $codigo,
            'nombre' => $nombre,
            'poblacion' => $poblacion,
        ];
    }

    sqlsrv_free_stmt($stmtSql);
    return $tiendas;
}

/**
 * Obtiene las metas actuales de una tienda para varias semanas.
 * La llave  es "ANIO-SEMANA".
 */
function retail_obtener_metas_tienda($sqlsrvConn, string $codigo, array $semanas): array
{
    if ($sqlsrvConn === false || $sqlsrvConn === null || $codigo === '' || empty($semanas)) {
        return [];
    }

    $condiciones = [];
    $params = [$codigo];

    foreach ($semanas as $semana) {
        $condiciones[] = '(ANIO = ? AND SEMANA = ?)';
        $params[] = (int)$semana['anio'];
        $params[] = (int)$semana['semana'];
    }

    $sql = "
        SELECT
            ANIO,
            SEMANA,
            META
        FROM vistasMCC.dbo.TB_SMF_METAS_SEMANALES
        WHERE LTRIM(RTRIM(CAST(TIENDA AS varchar(50)))) = ?
          AND (" . implode(' OR ', $condiciones) . ")
    ";

    $stmt = sqlsrv_query($sqlsrvConn, $sql, $params);
    if ($stmt === false) {
        return [];
    }

    $metas = [];

    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $clave = (int)$fila['ANIO'] . '-' . (int)$fila['SEMANA'];
        $metas[$clave] = (float)$fila['META'];
    }

    sqlsrv_free_stmt($stmt);
    return $metas;
}

/**
 * Obtiene desde MySQL la última meta anterior registrada en auditoría para
 * cada semana de la tienda seleccionada.
 */
function retail_obtener_metas_anteriores_auditoria(mysqli $conn, string $codigo, array $semanas): array
{
    if ($codigo === '' || empty($semanas)) {
        return [];
    }

    /*
     * El guardar actual registra:
     *
     * • Tienda: 25 · Nombre
     * • Temporalidad: Semana Retail 36 del año 2026 (...)
     * • Cambio: L 20,000 A L 25,000.
     *
     * También conservamos compatibilidad con registros viejos
     * que pudieran venir sin ":" después de Tienda.
     */
    $patronTiendaActual = '%Tienda: ' . $codigo . ' ·%';
    $patronTiendaAnterior = '%Tienda ' . $codigo . ' ·%';

    $sql = "
        SELECT usuario, fecha, detalle
        FROM auditoria
        WHERE accion = 'META_SEMANAL_ACTUALIZADA'
          AND (
                detalle LIKE ?
                OR detalle LIKE ?
              )
        ORDER BY fecha DESC
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param(
        'ss',
        $patronTiendaActual,
        $patronTiendaAnterior
    );

    if (!$stmt->execute()) {
        $stmt->close();
        return [];
    }

    $res = $stmt->get_result();

    if (!$res) {
        $stmt->close();
        return [];
    }

    $permitidas = [];

    foreach ($semanas as $semana) {
        $permitidas[
            (int)$semana['anio']
            . '-'
            . (int)$semana['semana']
        ] = true;
    }

    $anteriores = [];

    while ($fila = $res->fetch_assoc()) {

        $detalle = (string)($fila['detalle'] ?? '');

        /*
         * Validación exacta de tienda para evitar que el código
         * de una tienda coincida accidentalmente con otro número.
         */
        $regexTienda =
            '/Tienda\s*:?\s*'
            . preg_quote($codigo, '/')
            . '\s*·/iu';

        if (!preg_match($regexTienda, $detalle)) {
            continue;
        }

        /*
         * Semana y año del registro auditado.
         */
        if (
            !preg_match(
                '/Semana\s+Retail\s+(\d+)\s+del\s+a(?:ñ|n)o\s+(\d+)/iu',
                $detalle,
                $mSemana
            )
        ) {
            continue;
        }

        $clave =
            (int)$mSemana[2]
            . '-'
            . (int)$mSemana[1];

        /*
         * Como viene ORDER BY fecha DESC, el primer cambio encontrado
         * para esa semana es el último cambio realizado.
         */
        if (
            !isset($permitidas[$clave])
            || isset($anteriores[$clave])
        ) {
            continue;
        }

        $numeroTexto = null;

        /*
         * FORMATO ACTUAL:
         * Cambio: L 20,000 A L 25,000.
         *
         * El primer número es justamente la Meta anterior.
         */
        if (
            preg_match(
                '/Cambio\s*:\s*L\s*([0-9,.]+)\s+A\s+L\s*[0-9,.]+/iu',
                $detalle,
                $mCambio
            )
        ) {
            $numeroTexto = $mCambio[1];

        /*
         * FORMATO VIEJO:
         * Meta anterior: L 20,000
         */
        } elseif (
            preg_match(
                '/Meta\s+anterior\s*:\s*L\s*([0-9,.]+)/iu',
                $detalle,
                $mMeta
            )
        ) {
            $numeroTexto = $mMeta[1];
        }

        if ($numeroTexto === null) {
            continue;
        }

        $numeroTexto = str_replace(',', '', $numeroTexto);

        if (!is_numeric($numeroTexto)) {
            continue;
        }

        $anteriores[$clave] = [
            'meta' => (float)$numeroTexto,
            'usuario' => (string)($fila['usuario'] ?? ''),
            'fecha' => (string)($fila['fecha'] ?? ''),
        ];
    }

    $stmt->close();

    return $anteriores;
}

function retail_registrar_auditoria(mysqli $conn, string $accion, string $detalle): bool
{
    try {
        $nombre = (string)($_SESSION['nombre_completo'] ?? '');
        $usuario = (string)($_SESSION['usuario'] ?? '');
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA');
        $stmt = $conn->prepare('INSERT INTO auditoria (nombre_completo, usuario, accion, ip, fecha, detalle) VALUES (?, ?, ?, ?, NOW(), ?)');

        if (!$stmt) {
            return false;
        }

        $stmt->bind_param('sssss', $nombre, $usuario, $accion, $ip, $detalle);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    } catch (Throwable $e) {
        error_log('Error auditoría Retail: ' . $e->getMessage());
        return false;
    }
}
