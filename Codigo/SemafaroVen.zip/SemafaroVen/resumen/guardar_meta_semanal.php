<?php

declare(strict_types=1);

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

session_name('APP_SEMAFARO');
session_start();

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/retail_helper.php';

$baseUrl = $baseUrl ?? '/SemafaroVen';
$volverBase = "{$baseUrl}/resumen/meta_semanal.php";

$rolesPermitidos = [
    'administrador',
    'gerente_comercial',
    'gerente_tienda'
];

$rol = (string)($_SESSION['rol'] ?? '');
$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);

if (!in_array($rol, $rolesPermitidos, true) || $usuarioId <= 0) {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: {$volverBase}");
    exit();
}

/*
VALIDAR CSRF STRING DE SESION
*/

$csrfToken = (string)($_POST['csrf_token'] ?? '');

if (
    empty($_SESSION['csrf_token']) ||
    $csrfToken === '' ||
    !hash_equals((string)$_SESSION['csrf_token'], $csrfToken)
) {
    header("Location: {$volverBase}?error=csrf");
    exit();
}

/*
 VALIDAR CONEXIÓN SQL SERVER
*/

if (
    !isset($sqlsrv_conn_exhibicion) ||
    $sqlsrv_conn_exhibicion === false
) {
    header("Location: {$volverBase}?error=guardar");
    exit();
}


$codigo = trim((string)($_POST['tienda'] ?? ''));

$tz = new DateTimeZone('America/Tegucigalpa');
$hoy = new DateTimeImmutable('today', $tz);

// Año y mes SIEMPRE automáticos no los toca usuarios.
// No se acepta año ni mes enviados por el navegador.
$anioVista = (int)$hoy->format('Y');
$mesVista = (int)$hoy->format('n');

/*
URL DE REGRESO
*/

$parametrosVolver = [];

if ($codigo !== '') {
    $parametrosVolver['tienda'] = $codigo;
}

$volver = $volverBase;

if (!empty($parametrosVolver)) {
    $volver .= '?' . http_build_query($parametrosVolver);
}

/*
TIENDAS PERMITIDAS  SOLO MENDELS
*/

$tiendasPermitidas = retail_obtener_tiendas_permitidas(
    $conn,
    $sqlsrv_conn_exhibicion,
    $rol,
    $usuarioId
);

if (empty($tiendasPermitidas)) {
    $separador = str_contains($volver, '?') ? '&' : '?';
    header("Location: {$volver}{$separador}error=sin_tiendas");
    exit();
}

if (
    $codigo === '' ||
    !isset($tiendasPermitidas[$codigo])
) {
    $separador = str_contains($volver, '?') ? '&' : '?';
    header("Location: {$volver}{$separador}error=tienda_invalida");
    exit();
}

/*
SEMANAS DEL MES ACTUAL
*/

$semanasMes = retail_obtener_semanas_mes(
    $anioVista,
    $mesVista
);

$semanasPermitidas = [];

foreach ($semanasMes as $semana) {
    $clave =
        (int)$semana['anio']
        . '-'
        . (int)$semana['semana'];

    $semanasPermitidas[$clave] = $semana;
}

/* RECIBIR METAS
*/

$metasPost = $_POST['metas'] ?? [];

if (!is_array($metasPost)) {
    $separador = str_contains($volver, '?') ? '&' : '?';
    header("Location: {$volver}{$separador}error=meta_invalida");
    exit();
}

$metasProcesar = [];

foreach ($metasPost as $clave => $valor) {

    $clave = trim((string)$clave);
    $valor = trim((string)$valor);

    /*
     CAMPO VACÍO = NO HACER NADA
    */

    if ($valor === '') {
        continue;
    }

    /*
     VALIDAR SEMANA
    */

    if (!isset($semanasPermitidas[$clave])) {
        $separador = str_contains($volver, '?') ? '&' : '?';
        header("Location: {$volver}{$separador}error=semana_invalida");
        exit();
    }

    /* VALIDAR META
    */

    $meta = retail_normalizar_meta($valor);

    if ($meta === null) {
        $separador = str_contains($volver, '?') ? '&' : '?';
        header("Location: {$volver}{$separador}error=meta_invalida");
        exit();
    }

    $metasProcesar[$clave] = $meta;
}

/*
 NO ESCRIBIÓ NINGUNA META
ENTONCES NO REALIAZAMOS NADA DE INSERT, UPDATE NI AUDITORIA

*/

if (empty($metasProcesar)) {

    $separador = str_contains($volver, '?') ? '&' : '?';

    header(
        "Location: {$volver}{$separador}info=sin_cambios"
    );

    exit();
}

/*
 PREPARAR TRANSACCIÓN
*/

$auditoriasPendientes = [];

/*
 CONTADOR REAL DE CAMBIOS
 Solo aumenta cuando realmente se hace INSERT o UPDATE.
*/

$cambiosRealizados = 0;

if (!sqlsrv_begin_transaction($sqlsrv_conn_exhibicion)) {

    $separador = str_contains($volver, '?') ? '&' : '?';

    header(
        "Location: {$volver}{$separador}error=guardar"
    );

    exit();
}

try {

    foreach ($metasProcesar as $clave => $metaNueva) {

        $semanaInfo = $semanasPermitidas[$clave];

        $anio = (int)$semanaInfo['anio'];
        $semana = (int)$semanaInfo['semana'];

        $fechaInicio = retail_fecha_es(
            $semanaInfo['fecha_inicio']
        );

        $fechaFin = retail_fecha_es(
            $semanaInfo['fecha_fin']
        );

        /*
        BUSCAR META EXISTENTE PARA NO DUPLICAR 
        */

        $sqlExiste = "
            SELECT META
            FROM vistasMCC.dbo.TB_SMF_METAS_SEMANALES
                 WITH (UPDLOCK, HOLDLOCK)
            WHERE LTRIM(RTRIM(CAST(TIENDA AS varchar(50)))) = ?
              AND ANIO = ?
              AND SEMANA = ?
        ";

        $stmtExiste = sqlsrv_query(
            $sqlsrv_conn_exhibicion,
            $sqlExiste,
            [
                $codigo,
                $anio,
                $semana
            ]
        );

        if ($stmtExiste === false) {
            throw new RuntimeException(
                'No fue posible consultar la meta existente.'
            );
        }

        $filasExistentes = [];

        while (
            $fila = sqlsrv_fetch_array(
                $stmtExiste,
                SQLSRV_FETCH_ASSOC
            )
        ) {
            $filasExistentes[] = $fila;
        }

        sqlsrv_free_stmt($stmtExiste);

        /*
         SEGURIDAD CONTRA DUPLICADOS PARA  NO GUARDAR 2 MISMOS
        
        */

        if (count($filasExistentes) > 1) {
            throw new DomainException('DUPLICADOS_BD');
        }

        $tienda = $tiendasPermitidas[$codigo];

        $nombreTienda = (string)$tienda['nombre'];

        $ubicacion =
            (string)$tienda['poblacion'] !== ''
                ? ' (' . (string)$tienda['poblacion'] . ')'
                : '';

        /*
        UPDATE
        */

        if (count($filasExistentes) === 1) {

            $metaAnterior =
                (float)$filasExistentes[0]['META'];

            /*
             MISMO VALOR = NO ACTUALIZAR
            No hace UPDATE, NI AUDITORIA ETC.
            */

            if (
                abs($metaAnterior - $metaNueva) < 0.005
            ) {
                continue;
            }

            $sqlUpdate = "
                UPDATE vistasMCC.dbo.TB_SMF_METAS_SEMANALES
                   SET META = ?
                 WHERE LTRIM(RTRIM(CAST(TIENDA AS varchar(50)))) = ?
                   AND ANIO = ?
                   AND SEMANA = ?
            ";

            $stmtUpdate = sqlsrv_query(
                $sqlsrv_conn_exhibicion,
                $sqlUpdate,
                [
                    $metaNueva,
                    $codigo,
                    $anio,
                    $semana
                ]
            );

            if ($stmtUpdate === false) {
                throw new RuntimeException(
                    'No fue posible actualizar la meta.'
                );
            }

            sqlsrv_free_stmt($stmtUpdate);

            /*
            CAMBIO REAL CUANDO SE GUARDA 
         
            */

             $cambiosRealizados++;

            // ESCTRUCTURA con puntos y saltos de línea nativos
            $auditoriasPendientes[] = [
                'accion' => 'META_SEMANAL_ACTUALIZADA',

                'detalle' =>
                    "Se actualizó la meta semanal.\n"
                    . "• Tienda: {$codigo} · {$nombreTienda}{$ubicacion}\n"
                    . "• Temporalidad: Semana Retail {$semana} del año {$anio} ({$fechaInicio} al {$fechaFin})\n"
                    . "• Cambio: " . retail_meta_formato($metaAnterior) . " A " . retail_meta_formato($metaNueva) . ".",
            ];

        /*
         INSERT SI NO HAY REGISTOROS GUARDADOS INSERTA POR PRIMERA VEZ
       
        */

        } else {

            $sqlInsert = "
                INSERT INTO vistasMCC.dbo.TB_SMF_METAS_SEMANALES
                    (
                        TIENDA,
                        ANIO,
                        SEMANA,
                        META
                    )
                VALUES (?, ?, ?, ?)
            ";

            $stmtInsert = sqlsrv_query(
                $sqlsrv_conn_exhibicion,
                $sqlInsert,
                [
                    $codigo,
                    $anio,
                    $semana,
                    $metaNueva
                ]
            );

            if ($stmtInsert === false) {
                throw new RuntimeException(
                    'No fue posible insertar la meta.'
                );
            }

            sqlsrv_free_stmt($stmtInsert);

            /*
             CAMBIO REAL EN EL SQL
           
            */

           
            $cambiosRealizados++;

            // estructurado el bloque de CREADA con puntos y saltos de línea nativos
            $auditoriasPendientes[] = [
                'accion' => 'META_SEMANAL_CREADA',

                'detalle' =>
                    "Se registró la meta semanal.\n"
                    . "• Tienda: {$codigo} · {$nombreTienda}{$ubicacion}\n"
                    . "• Temporalidad: Semana Retail {$semana} del año {$anio} ({$fechaInicio} al {$fechaFin})\n"
                    . "• Meta registrada: " . retail_meta_formato($metaNueva) . ".",
            ];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | SI NO HUBO NINGÚN CAMBIO REAL
    |--------------------------------------------------------------------------
    |
    | Por ejemplo:
    | - escribió exactamente el mismo valor existente.
    |
    | No necesitamos confirmar un guardado sin cambios.
    |--------------------------------------------------------------------------
    */

    if ($cambiosRealizados === 0) {

        sqlsrv_rollback(
            $sqlsrv_conn_exhibicion
        );

        $separador =
            str_contains($volver, '?')
                ? '&'
                : '?';

        header(
            "Location: {$volver}"
            . "{$separador}info=sin_cambios"
        );

        exit();
    }

    /*
     CONFIRMAR
    */

    if (!sqlsrv_commit($sqlsrv_conn_exhibicion)) {
        throw new RuntimeException(
            'No fue posible confirmar la transacción.'
        );
    }

} catch (DomainException $e) {

    sqlsrv_rollback(
        $sqlsrv_conn_exhibicion
    );

    $error =
        $e->getMessage() === 'DUPLICADOS_BD'
            ? 'duplicados_bd'
            : 'guardar';

    $separador =
        str_contains($volver, '?')
            ? '&'
            : '?';

    header(
        "Location: {$volver}"
        . "{$separador}error={$error}"
    );

    exit();

} catch (Throwable $e) {

    sqlsrv_rollback(
        $sqlsrv_conn_exhibicion
    );

    error_log(
        'Error guardando Meta Semanal: '
        . $e->getMessage()
    );

    $separador =
        str_contains($volver, '?')
            ? '&'
            : '?';

    header(
        "Location: {$volver}"
        . "{$separador}error=guardar"
    );

    exit();
}

/*
 AUDITORÍA
 si realmente hubo INSERT o UPDATE.
*/

$auditoriaOk = true;

foreach ($auditoriasPendientes as $audit) {

    if (
        !retail_registrar_auditoria(
            $conn,
            (string)$audit['accion'],
            (string)$audit['detalle']
        )
    ) {
        $auditoriaOk = false;
    }
}

/*
 ÉXITO
*/

$separador =
    str_contains($volver, '?')
        ? '&'
        : '?';

header(
    "Location: {$volver}"
    . "{$separador}ok=1"
    . "&cambios={$cambiosRealizados}"
    . "&audit="
    . ($auditoriaOk ? '1' : '0')
);

exit();