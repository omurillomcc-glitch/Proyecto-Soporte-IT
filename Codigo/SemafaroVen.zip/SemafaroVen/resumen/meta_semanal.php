<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
session_name('APP_SEMAFARO');
session_start();

require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/retail_helper.php';

$baseUrl = $baseUrl ?? '/SemafaroVen';
$rolesPermitidos = ['administrador', 'gerente_comercial', 'gerente_tienda'];
$rol = (string)($_SESSION['rol'] ?? '');
$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);

if (!in_array($rol, $rolesPermitidos, true) || $usuarioId <= 0) {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$tz = new DateTimeZone('America/Tegucigalpa');
$hoy = new DateTimeImmutable('today', $tz);
$anioVista = (int)$hoy->format('Y');
$mesVista = (int)$hoy->format('n');

$tiendas = retail_obtener_tiendas_permitidas(
    $conn,
    $sqlsrv_conn_exhibicion ?? false,
    $rol,
    $usuarioId
);

$codigoSeleccionado = trim((string)($_GET['tienda'] ?? ''));

if ($rol === 'gerente_tienda' && count($tiendas) === 1) {
    $codigoSeleccionado = (string)array_key_first($tiendas);
} elseif ($codigoSeleccionado === '' || !isset($tiendas[$codigoSeleccionado])) {
    $codigoSeleccionado = !empty($tiendas) ? (string)array_key_first($tiendas) : '';
}

$tiendaSeleccionada =
    $codigoSeleccionado !== '' && isset($tiendas[$codigoSeleccionado])
        ? $tiendas[$codigoSeleccionado]
        : null;

$semanasMes = retail_obtener_semanas_mes($anioVista, $mesVista);
$metasActuales = [];
$metasAnteriores = [];

if ($tiendaSeleccionada && $semanasMes) {
    $metasActuales = retail_obtener_metas_tienda(
        $sqlsrv_conn_exhibicion ?? false,
        $codigoSeleccionado,
        $semanasMes
    );

    $metasAnteriores = retail_obtener_metas_anteriores_auditoria(
        $conn,
        $codigoSeleccionado,
        $semanasMes
    );
}

/* Historial desde agosto 2026 */
$inicioHistorial = new DateTimeImmutable('2026-08-01', $tz);
$inicioMesActual = new DateTimeImmutable(
    sprintf('%04d-%02d-01', $anioVista, $mesVista),
    $tz
);
$ultimoMesHistorico = $inicioMesActual->modify('-1 month');
$mesesHistorial = [];

if ($ultimoMesHistorico >= $inicioHistorial) {
    for (
        $cursor = $ultimoMesHistorico;
        $cursor >= $inicioHistorial;
        $cursor = $cursor->modify('-1 month')
    ) {
        $a = (int)$cursor->format('Y');
        $m = (int)$cursor->format('n');

        $mesesHistorial["{$a}-{$m}"] = [
            'anio' => $a,
            'mes' => $m,
            'nombre' => retail_mes_nombre($m) . ' ' . $a,
        ];
    }
}

$historialAbierto = (string)($_GET['historial'] ?? '') === '1';
$histAnio = 0;
$histMes = 0;

if ($mesesHistorial) {
    $primero = reset($mesesHistorial);
    $histAnio = (int)($_GET['hist_anio'] ?? $primero['anio']);
    $histMes = (int)($_GET['hist_mes'] ?? $primero['mes']);

    if (!isset($mesesHistorial["{$histAnio}-{$histMes}"])) {
        $histAnio = (int)$primero['anio'];
        $histMes = (int)$primero['mes'];
    }
}

$claveHistorial = "{$histAnio}-{$histMes}";
$semanasHistorial = [];
$metasHistorial = [];
$metasAnterioresHistorial = [];

if ($tiendaSeleccionada && isset($mesesHistorial[$claveHistorial])) {
    $semanasHistorial = retail_obtener_semanas_mes($histAnio, $histMes);

    $metasHistorial = retail_obtener_metas_tienda(
        $sqlsrv_conn_exhibicion ?? false,
        $codigoSeleccionado,
        $semanasHistorial
    );

    $metasAnterioresHistorial = retail_obtener_metas_anteriores_auditoria(
        $conn,
        $codigoSeleccionado,
        $semanasHistorial
    );
}

$esGerenteTienda = $rol === 'gerente_tienda';
$semanasConMeta = count($metasActuales);


require_once dirname(__DIR__) . '/layout_menu.php';
?>

<link rel="stylesheet" href="<?= retail_h($baseUrl) ?>/resumen/meta_semanal.css?v=<?= time() ?>">

<main class="meta2-page">
<div class="meta2-wrap">

    <header class="meta-style2-head">
        <div class="meta-style2-title">
            <h1></h1>
            <p>Ingreso de metas por Semana Retail.</p>
        </div>

        <div class="meta-style2-period">
            <span><?= retail_h(retail_mes_nombre($mesVista)) ?></span>
            <strong><?= $anioVista ?></strong>
        </div>
    </header>

    <?php if (isset($_GET['ok'])): ?>
        <div class="meta2-alert success">
            <i class="bi bi-check-circle-fill"></i>
            <div>
                <strong>Metas guardadas correctamente.</strong>
                <span>
                    <?= isset($_GET['cambios']) ? 'Registros modificados: ' . (int)$_GET['cambios'] . '. ' : '' ?>
                    <?= (($_GET['audit'] ?? '') === '0') ? 'Una entrada de auditoría no pudo registrarse.' : 'Cambios registrados en auditoría.' ?>
                </span>
            </div>
        </div>
    <?php endif; ?>

    <?php if (($_GET['info'] ?? '') === 'sin_cambios'): ?>
        <div class="meta2-alert warning">
            <i class="bi bi-info-circle-fill"></i>
            <div><strong>Sin cambios.</strong><span>No ingresó ninguna meta nueva.</span></div>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])):
        $mensajeError = match ((string)$_GET['error']) {
            'csrf' => 'La sesión expiró. Actualice la página.',
            'periodo' => 'El periodo solicitado no es válido.',
            'sin_tiendas' => 'No existen tiendas autorizadas.',
            'meta_invalida' => 'La meta debe ser numérica y mayor que L 0.',
            'tienda_invalida' => 'La tienda no está autorizada.',
            'semana_invalida' => 'La semana no pertenece al periodo actual.',
            'duplicados_bd' => 'Hay registros duplicados en la base.',
            'guardar' => 'Ocurrió un error al guardar.',
            default => 'Ocurrió un error al procesar la solicitud.'
        };
    ?>
        <div class="meta2-alert danger">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <div><strong>Atención</strong><span><?= retail_h($mensajeError) ?></span></div>
        </div>
    <?php endif; ?>

    <?php if (!$tiendas): ?>
        <div class="meta2-empty">
            <i class="bi bi-shop-window"></i>
            <h3>Sin tiendas disponibles</h3>
            <p>No hay tiendas asociadas a esta cuenta.</p>
        </div>
    <?php else: ?>

        <section class="meta-style2-toolbar simple">
            <div class="meta-style2-store-title no-icon">
                <div>
                    <small>Tienda activa</small>

                    <strong>
                        <?= retail_h(
                            $codigoSeleccionado
                            . ' - '
                            . (string)($tiendaSeleccionada['nombre'] ?? '')
                        ) ?>
                    </strong>

                    <?php if (!empty($tiendaSeleccionada['poblacion'])): ?>
                        <span>
                            <?= retail_h(
                                (string)$tiendaSeleccionada['poblacion']
                            ) ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="meta-style2-toolbar-actions">
                <?php if (!$esGerenteTienda || count($tiendas) > 1): ?>
                    <form method="GET" class="meta-style2-store-form">
                        <div class="meta-style2-select-box">
                            <span class="meta-style2-select-icon selector-only">
                                <i class="bi bi-shop"></i>
                            </span>

                            <select name="tienda" aria-label="Tienda">
                                <?php foreach ($tiendas as $codigo => $tienda): ?>
                                    <option
                                        value="<?= retail_h((string)$codigo) ?>"
                                        <?= (string)$codigo === $codigoSeleccionado ? 'selected' : '' ?>
                                    >
                                        <?= retail_h(
                                            (string)$codigo
                                            . ' - '
                                            . (string)$tienda['nombre']
                                        ) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <button type="submit" class="meta-style2-btn primary">
                            <i class="bi bi-arrow-repeat"></i>
                            Cambiar
                        </button>
                    </form>
                <?php endif; ?>

                <button
                    type="button"
                    class="meta-style2-btn history"
                    id="btnVerHistorial"
                >
                    <i class="bi <?= $historialAbierto ? 'bi-x-lg' : 'bi-clock-history' ?>"></i>
                    <span>
                        <?= $historialAbierto
                            ? 'Cerrar historial'
                            : 'Historial' ?>
                    </span>
                </button>
            </div>
        </section>

        <?php if ($tiendaSeleccionada): ?>

            <?php if (!$semanasMes): ?>
                <div class="meta2-empty">
                    <i class="bi bi-calendar-x"></i>
                    <h3>Sin semanas disponibles</h3>
                    <p>No se pudo construir el calendario Retail.</p>
                </div>
            <?php else: ?>

                <div class="meta2-section-head meta-editable-only">
                    <span class="meta-editable-text">
                        <svg class="meta-pencil-svg" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M4 20h4l11-11-4-4L4 16v4Z"></path>
                            <path d="m13.5 6.5 4 4"></path>
                        </svg>
                        META EDITABLE
                    </span>
                    <p>Ingresa solamente las metas que deseas crear o modificar.</p>
                </div>

                <form method="POST" action="<?= retail_h($baseUrl) ?>/resumen/guardar_meta_semanal.php" id="formMetas" autocomplete="off">
                    <input type="hidden" name="csrf_token" value="<?= retail_h((string)$_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="tienda" value="<?= retail_h($codigoSeleccionado) ?>">

                    <div class="meta2-week-grid">
                        <?php foreach ($semanasMes as $semana):
                            $clave = (int)$semana['anio'] . '-' . (int)$semana['semana'];
                            $metaActual = array_key_exists($clave, $metasActuales) ? (float)$metasActuales[$clave] : null;
                            $auditAnterior = $metasAnteriores[$clave] ?? null;
                            $metaAnterior = is_array($auditAnterior) ? (float)$auditAnterior['meta'] : null;
                            $esActual = $hoy >= $semana['fecha_inicio'] && $hoy <= $semana['fecha_fin'];
                        ?>
                            <article class="meta2-week-card <?= $esActual ? 'current' : '' ?>">
                                <div class="meta2-week-top">
                                    <div>
                                        <small>SEMANA RETAIL</small>
                                        <h3>Semana <?= (int)$semana['semana'] ?></h3>
                                    </div>
                                    <?php if ($esActual): ?><span class="meta2-current-badge">Actual</span><?php endif; ?>
                                </div>

                                <div class="meta2-date">
                                    <i class="bi bi-calendar3"></i>
                                    <?= retail_h(retail_fecha_es($semana['fecha_inicio'])) ?>
                                    <span>al</span>
                                    <?= retail_h(retail_fecha_es($semana['fecha_fin'])) ?>
                                </div>

                                <div class="meta2-values">
                                    <div>
                                        <span>Meta anterior</span>
                                        <strong class="old">
                                            <?= $metaAnterior !== null ? retail_h(retail_meta_formato($metaAnterior)) : 'Sin cambios' ?>
                                        </strong>
                                    </div>
                                    <div>
                                        <span>Meta actual</span>
                                        <strong>
                                            <?= $metaActual !== null ? retail_h(retail_meta_formato($metaActual)) : 'Sin registrar' ?>
                                        </strong>
                                    </div>
                                </div>

                                <label for="meta_<?= retail_h($clave) ?>">Nueva meta</label>
                                <div class="meta2-money">
                                    <span>L</span>
                                    <input
                                        type="text"
                                        id="meta_<?= retail_h($clave) ?>"
                                        name="metas[<?= retail_h($clave) ?>]"
                                        inputmode="numeric"
                                        pattern="[0-9]{1,12}"
                                        maxlength="12"
                                        placeholder="Ej. 2500000"
                                        autocomplete="off"
                                    >
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <div class="meta2-savebar">
                        <span><i class="bi bi-info-circle"></i> Solo se guardan las semanas modificadas.</span>
                        <button type="submit" class="meta2-save"><i class="bi bi-floppy"></i> Guardar metas</button>
                    </div>
                </form>

                <section
                    id="historialMetas"
                    class="meta-history <?= $historialAbierto ? 'is-visible' : '' ?>"
                >
                    <div class="meta-history-head">
                        <div class="meta-history-title">
                            <div class="meta-history-icon">
                                <i class="bi bi-clock-history"></i>
                            </div>

                            <div>
                                <span>HISTORIAL</span>
                                <h2>Semanas ingresadas</h2>
                                <p>Metas registradas para la tienda seleccionada.</p>
                            </div>
                        </div>

                        <div class="meta-history-controls">
                            <?php if ($mesesHistorial): ?>
                                <form method="GET" class="meta-history-filter">
                                    <input type="hidden" name="tienda" value="<?= retail_h($codigoSeleccionado) ?>">
                                    <input type="hidden" name="historial" value="1">
                                    <input type="hidden" name="hist_anio" id="hist_anio" value="<?= $histAnio ?>">
                                    <input type="hidden" name="hist_mes" id="hist_mes" value="<?= $histMes ?>">

                                    <select id="hist_periodo" aria-label="Mes histórico">
                                        <?php foreach ($mesesHistorial as $claveMes => $periodo): ?>
                                            <option
                                                value="<?= (int)$periodo['anio'] ?>-<?= (int)$periodo['mes'] ?>"
                                                <?= $claveMes === $claveHistorial ? 'selected' : '' ?>
                                            >
                                                <?= retail_h($periodo['nombre']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <button type="submit">
                                        <i class="bi bi-search"></i>
                                        Ver
                                    </button>
                                </form>
                            <?php endif; ?>

                            <span class="meta-history-badge">
                                <i class="bi bi-lock"></i>
                                Solo lectura
                            </span>
                        </div>
                    </div>

                    <div class="meta-history-body">

                        <?php if (!$mesesHistorial): ?>

                            <div class="meta-history-empty">
                                <i class="bi bi-clock-history"></i>
                                <strong>Aún no hay meses anteriores</strong>
                                <span>El historial comienza en agosto 2026.</span>
                            </div>

                        <?php else: ?>

                            <div class="meta-history-period">
                                <?= retail_h($mesesHistorial[$claveHistorial]['nombre']) ?>
                            </div>

                            <?php $hayHistorial = false; ?>

                            <div class="meta-history-grid">

                                <?php foreach ($semanasHistorial as $semana):

                                    $claveHistorialSemana =
                                        (int)$semana['anio']
                                        . '-'
                                        . (int)$semana['semana'];

                                    if (!array_key_exists($claveHistorialSemana, $metasHistorial)) {
                                        continue;
                                    }

                                    $hayHistorial = true;

                                    $metaActualHistorial =
                                        (float)$metasHistorial[$claveHistorialSemana];

                                    $auditAnteriorHistorial =
                                        $metasAnterioresHistorial[$claveHistorialSemana]
                                        ?? null;

                                    $metaAnteriorHistorial =
                                        is_array($auditAnteriorHistorial)
                                            ? (float)$auditAnteriorHistorial['meta']
                                            : null;
                                ?>

                                    <article class="meta-history-card">
                                        <div class="meta-history-card-head">
                                            <div>
                                                <span class="meta-history-week-label">
                                                    SEMANA RETAIL
                                                </span>

                                                <h3>
                                                    Semana
                                                    <?= (int)$semana['semana'] ?>
                                                </h3>
                                            </div>
                                        </div>

                                        <div class="meta-history-date">
                                            <i class="bi bi-calendar3"></i>

                                            <?= retail_h(
                                                retail_fecha_es(
                                                    $semana['fecha_inicio']
                                                )
                                            ) ?>

                                            <span>al</span>

                                            <?= retail_h(
                                                retail_fecha_es(
                                                    $semana['fecha_fin']
                                                )
                                            ) ?>
                                        </div>

                                        <div class="meta-history-value">
                                            <div>
                                                <span>Meta registrada</span>
                                                <small>Valor actual de la semana</small>
                                            </div>

                                            <strong>
                                                <?= retail_h(
                                                    retail_meta_formato(
                                                        $metaActualHistorial
                                                    )
                                                ) ?>
                                            </strong>
                                        </div>

                                        <?php if ($metaAnteriorHistorial !== null): ?>
                                            <div class="meta-history-previous">
                                                <span>Meta anterior</span>

                                                <strong>
                                                    <?= retail_h(
                                                        retail_meta_formato(
                                                            $metaAnteriorHistorial
                                                        )
                                                    ) ?>
                                                </strong>
                                            </div>
                                        <?php endif; ?>
                                    </article>

                                <?php endforeach; ?>

                            </div>

                            <?php if (!$hayHistorial): ?>
                                <div class="meta-history-empty">
                                    <i class="bi bi-clock-history"></i>
                                    <strong>Sin historial</strong>
                                    <span>
                                        No existen metas registradas para este mes.
                                    </span>
                                </div>
                            <?php endif; ?>

                        <?php endif; ?>

                    </div>
                </section>

            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>

</div>
</main>

<script>
(() => {
    const btnHistorial = document.getElementById('btnVerHistorial');
    const historial = document.getElementById('historialMetas');
    const saveBar = document.querySelector('.meta2-savebar');

    if (btnHistorial && historial) {
        btnHistorial.addEventListener('click', () => {
            const visible = historial.classList.toggle('is-visible');
            if (saveBar) saveBar.style.display = visible ? 'none' : '';

            const texto = btnHistorial.querySelector('span');
            const icono = btnHistorial.querySelector('i');

            if (texto) texto.textContent = visible ? 'Cerrar historial' : 'Historial';
            if (icono) icono.className = visible ? 'bi bi-x-lg' : 'bi bi-clock-history';

            if (visible) historial.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    }

    if (historial?.classList.contains('is-visible') && saveBar) {
        saveBar.style.display = 'none';
    }

    const periodo = document.getElementById('hist_periodo');
    const histAnio = document.getElementById('hist_anio');
    const histMes = document.getElementById('hist_mes');

    periodo?.addEventListener('change', () => {
        const [anio, mes] = periodo.value.split('-');
        if (histAnio) histAnio.value = anio || '';
        if (histMes) histMes.value = mes || '';
    });

    const inputs = Array.from(
        document.querySelectorAll('.meta2-money input[name^="metas["]')
    );

    inputs.forEach(input => {
        const limpiar = () => {
            input.value = input.value.replace(/\D/g, '').slice(0, 12);
        };

        input.addEventListener('input', limpiar);
        input.addEventListener('paste', () => setTimeout(limpiar, 0));
    });

    const form = document.getElementById('formMetas');
    if (!form) return;

    form.addEventListener('submit', event => {
        const llenos = inputs.filter(input => input.value.trim() !== '');

        if (!llenos.length) {
            event.preventDefault();
            alert('Ingrese al menos una meta mayor que L 0.');
            return;
        }

        const invalido = llenos.some(input => {
            const valor = Number(input.value);
            return !Number.isInteger(valor) || valor <= 0;
        });

        if (invalido) {
            event.preventDefault();
            alert('Todas las metas deben ser números mayores que L 0.');
        }
    });
})();
</script>

<?php require_once dirname(__DIR__) . '/layout_footer.php'; ?>
