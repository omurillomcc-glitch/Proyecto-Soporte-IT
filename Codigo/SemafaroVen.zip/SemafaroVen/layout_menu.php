<?php

require_once __DIR__ . '/user/auth.php';
require_login();


$pagina_actual = basename($_SERVER['PHP_SELF']);

$esAdmin = es_admin();

$baseUrl = '/SemafaroVen';



$nombreUsuario =
    $_SESSION['nombre_completo']
    ?? ($_SESSION['usuario'] ?? 'Usuario');

$rolUsuario =
    $_SESSION['rol']
    ?? 'Invitado';




$fotoPerfil =
    $_SESSION['foto_perfil']
    ?? null;

$fotoRutaHeader = null;


if (
    !empty($fotoPerfil)
    &&
    is_string($fotoPerfil)
) {

    $rutaFisica =
        $_SERVER['DOCUMENT_ROOT']
        . '/SemafaroVen/uploads/avatars/'
        . $fotoPerfil;


    if (file_exists($rutaFisica)) {

        $fotoRutaHeader =
            $baseUrl
            . '/uploads/avatars/'
            . $fotoPerfil;
    }
}


/*
INICIALES
*/

$palabras =
    preg_split(
        '/\s+/',
        trim((string)$nombreUsuario)
    );

$iniciales = '';


foreach ($palabras as $palabra) {

    if ($palabra !== '') {

        $iniciales .= strtoupper(
            mb_substr(
                $palabra,
                0,
                1,
                'UTF-8'
            )
        );
    }
}


$iniciales =
    mb_substr(
        $iniciales,
        0,
        2,
        'UTF-8'
    );


if (empty($iniciales)) {
    $iniciales = 'US';
}


/*
USUARIOS AUTORIZADOS Y PERMISOS
*/

$usuarioSesion =
    $_SESSION['usuario']
    ?? '';


// Usuarios autorizados para gestionar Control de Usuarios
$admins_usuarios = [
    'admin'
];


// Usuarios autorizados para ver Auditoría
$admins_auditoria = [
    'admin',
    'emejia'
];


// Permisos
$puede_ver_control_usuarios =
    in_array(
        $usuarioSesion,
        $admins_usuarios,
        true
    )
    || $esAdmin;


$puede_ver_auditoria =
    in_array(
        $usuarioSesion,
        $admins_auditoria,
        true
    )
    || $esAdmin;


$puede_ver_usuarios =
    $puede_ver_control_usuarios;


$puede_ver_administracion =
    $puede_ver_control_usuarios
    ||
    $puede_ver_auditoria;


/*
|--------------------------------------------------------------------------
| PÁGINAS ACTIVAS
|--------------------------------------------------------------------------
*/

$paginasControl = [

    'meta_semanal.php',
    'dias_trabajados.php',
    'metas.php',
    'inventariopormeta.php'

];


$controlActivo =
    in_array(
        $pagina_actual,
        $paginasControl,
        true
    );


$paginasConfigurarMetas = [

    'config_retail.php'

];


$configurarMetasActivo =
    in_array(
        $pagina_actual,
        $paginasConfigurarMetas,
        true
    );


$paginasUsuarios = [

    'agregar_user.php',
    'edit_user.php',
    'block.php'

];


$usuariosActivo =
    in_array(
        $pagina_actual,
        $paginasUsuarios,
        true
    );


$administracionActivo =
    $usuariosActivo
    ||
    $pagina_actual === 'auditoria.php';


$cuentaActivo =
    $pagina_actual === 'perfil.php';


$principalActivo =
    $pagina_actual === 'index.php';


/*
 ROL LEGIBLE PARA DROPDOWN

*/

$rolHeader = match (
    strtolower(
        trim(
            (string)$rolUsuario
        )
    )
) {

    'administrador',
    'admin'
        => 'Administrador',

    'gerente_comercial'
        => 'Gerente Comercial',

    'gerente_tienda'
        => 'Gerente de Tienda',

    default
        => ucfirst(
            str_replace(
                '_',
                ' ',
                (string)$rolUsuario
            )
        )

};

?>

<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Semafaro | Grupo MCC
    </title>


    <!-- FUENTES -->
    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Lato:wght@400;500;600;700&family=Raleway:wght@500;600;700&family=Roboto:wght@400;500;600;700&display=swap"
        rel="stylesheet"
    >
	<link rel="shortcut icon" type="image/png" href="/SemafaroVen/img/sv.png">


    <!-- BOOTSTRAP ICONS -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >
	

    <!-- CSS MENÚ -->
    <link
        rel="stylesheet"
        href="<?= $baseUrl ?>/css/menu.css?v=<?= time() ?>"
    >

    <!-- JS MENÚ -->
    <script
        src="<?= $baseUrl ?>/js/menu.js?v=<?= time() ?>"
        defer
    ></script>

</head>


<body>


<header
    id="header"
    class="orbit-header"
>

    <div class="orbit-container">


        <!-- =====================================================
             LOGO
        ====================================================== -->

        <a
            href="<?= $baseUrl ?>/index.php"
            class="orbit-logo"
            aria-label="Grupo MCC"
        >

            <img
                src="<?= $baseUrl ?>/img/logo.png"
                alt="Grupo MCC"
            >

        </a>


   
        <nav
            id="navmenu"
            class="navmenu"
            aria-label="Navegación principal"
        >

            <ul class="navmenu-root">


               

                <li>

                    <a
                        href="<?= $baseUrl ?>/index.php"
                        class="<?= $principalActivo ? 'active' : '' ?>"
                    >
                        Dashboard
                    </a>

                </li>


         

                <li class="dropdown">

                    <button
                        type="button"
                        class="navmenu-trigger <?= $controlActivo ? 'active' : '' ?>"
                        aria-expanded="false"
                    >

                        <span>
                            Resumen
                        </span>

                        <i class="bi bi-chevron-down"></i>

                    </button>


                    <ul class="dropdown-menu">


                        <li>

                            <a
                                href="<?= $baseUrl ?>/resumen/meta_semanal.php"
                                class="<?= $pagina_actual === 'meta_semanal.php' ? 'active' : '' ?>"
                            >
                                Meta Semanal
                            </a>

                        </li>


                        <li>

                            <a
                                href="<?= $baseUrl ?>/vendedores/dias_trabajados.php"
                                class="<?= $pagina_actual === 'dias_trabajados.php' ? 'active' : '' ?>"
                            >
                                Días Laborales
                            </a>

                        </li>


                    </ul>

                </li>


                <!-- =================================================
                     CONFIGURACIÓN RETAIL
                ================================================== -->

                <?php if ($puede_ver_usuarios): ?>

                    <li class="dropdown">

                        <!--

                        <button
                            type="button"
                            class="navmenu-trigger <?= $configurarMetasActivo ? 'active' : '' ?>"
                            aria-expanded="false"
                        >

                            <span>
                                Configurar Semana Retail
                            </span>

                            <i class="bi bi-chevron-down"></i>

                        </button>


                        <ul class="dropdown-menu dropdown-menu-small">

                            <li>

                                <a
                                    href="<?= $baseUrl ?>/resumen/config_retail.php"
                                    class="<?= $pagina_actual === 'config_retail.php' ? 'active' : '' ?>"
                                >
                                    Configurar Año
                                </a>

                            </li>

                        </ul>

                        -->

                    </li>

                <?php endif; ?>


                <!-- 
                     ADMINISTRACIÓN
                 -->

                <?php if ($puede_ver_administracion): ?>

                    <li class="dropdown">

                        <button
                            type="button"
                            class="navmenu-trigger <?= $administracionActivo ? 'active' : '' ?>"
                            aria-expanded="false"
                        >

                            <span>
                                Administración
                            </span>

                            <i class="bi bi-chevron-down"></i>

                        </button>


                        <ul class="dropdown-menu">


                            <!-- CONTROL USUARIOS -->

                            <?php if ($puede_ver_control_usuarios): ?>

                                <li class="dropdown nested-dropdown">

                                    <button
                                        type="button"
                                        class="nested-trigger <?= $usuariosActivo ? 'active' : '' ?>"
                                        aria-expanded="false"
                                    >

                                        <span>
                                            Control de Usuarios
                                        </span>

                                        <i class="bi bi-chevron-right"></i>

                                    </button>


                                    <ul class="dropdown-menu nested-menu">


                                        <li>

                                            <a
                                                href="<?= $baseUrl ?>/config/agregar_user.php"
                                                class="<?= $pagina_actual === 'agregar_user.php' ? 'active' : '' ?>"
                                            >
                                                Crear Usuario
                                            </a>

                                        </li>


                                        <li>

                                            <a
                                                href="<?= $baseUrl ?>/config/edit_user.php"
                                                class="<?= $pagina_actual === 'edit_user.php' ? 'active' : '' ?>"
                                            >
                                                Editar Usuario
                                            </a>

                                        </li>


                                        <li>

                                            <a
                                                href="<?= $baseUrl ?>/config/block.php"
                                                class="<?= $pagina_actual === 'block.php' ? 'active' : '' ?>"
                                            >
                                                Bloquear Usuario
                                            </a>

                                        </li>


                                    </ul>

                                </li>

                            <?php endif; ?>


                            <!-- AUDITORÍA -->

                            <?php if ($puede_ver_auditoria): ?>

                                <li>

                                    <a
                                        href="<?= $baseUrl ?>/auditoria/auditoria.php"
                                        class="<?= $pagina_actual === 'auditoria.php' ? 'active' : '' ?>"
                                    >
                                        Auditoría
                                    </a>

                                </li>

                            <?php endif; ?>


                        </ul>

                    </li>

                <?php endif; ?>


                <!-- =================================================
                     CUENTA
                ================================================== -->

                <li class="dropdown">

                    <button
                        type="button"
                        class="navmenu-trigger <?= $cuentaActivo ? 'active' : '' ?>"
                        aria-expanded="false"
                    >

                        <span>
                            Cuenta
                        </span>

                        <i class="bi bi-chevron-down"></i>

                    </button>


                    <ul class="dropdown-menu account-dropdown">


                        <!-- USUARIO -->

                        <li class="account-info">


                            <div class="account-avatar">

                                <?php if ($fotoRutaHeader): ?>

                                    <img
                                        src="<?= htmlspecialchars(
                                            $fotoRutaHeader,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        alt="Foto de perfil"
                                    >

                                <?php else: ?>

                                    <span>
                                        <?= htmlspecialchars(
                                            $iniciales,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                <?php endif; ?>

                            </div>


                            <div class="account-copy">

                                <strong>
                                    <?= htmlspecialchars(
                                        $nombreUsuario,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </strong>

                                <small>
                                    <?= htmlspecialchars(
                                        $rolHeader,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </small>

                            </div>

                        </li>


                        <!-- PERFIL -->

                        <li>

                            <a
                                href="<?= $baseUrl ?>/perfil/perfil.php"
                                class="<?= $pagina_actual === 'perfil.php' ? 'active' : '' ?>"
                            >
                                Mi Perfil
                            </a>

                        </li>


                    </ul>

                </li>


            </ul>


            <!-- 
                 BOTÓN MÓVIL
        -->

            <button
                type="button"
                class="mobile-nav-toggle"
                aria-label="Abrir menú"
                aria-expanded="false"
            >

                <i class="bi bi-list"></i>

            </button>

        </nav>


        <!-- 
             PERFIL + SALIR
    -->

        <div class="header-actions">


            <!-- PERFIL -->

            <a
                href="<?= $baseUrl ?>/perfil/perfil.php"
                class="header-profile <?= $cuentaActivo ? 'active' : '' ?>"
                title="Mi Perfil"
            >


                <!-- FOTO -->

                <span class="header-profile-avatar">

                    <?php if ($fotoRutaHeader): ?>

                        <img
                            src="<?= htmlspecialchars(
                                $fotoRutaHeader,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt="Foto de perfil"
                        >

                    <?php else: ?>

                        <span>
                            <?= htmlspecialchars(
                                $iniciales,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>

                    <?php endif; ?>

                </span>


                <!-- NOMBRE -->

                <span class="header-profile-name">

                    <?= htmlspecialchars(
                        $nombreUsuario,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>

                </span>


            </a>


            <!-- SALIR -->

            <a
                href="<?= $baseUrl ?>/user/logout.php"
                class="orbit-logout"
            >
                Salir
            </a>


        </div>


    </div>

</header>


<!-- 
     OVERLAY MÓVIL
-->

<div
    class="mobile-nav-backdrop"
    id="mobileNavBackdrop"
></div>


<!-- 
     CONTENIDO
-->

<div class="app-layout">

    <main class="main-content">

        <div class="page-content">