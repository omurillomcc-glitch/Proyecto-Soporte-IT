<?php
require_once dirname(__DIR__) . '/user/auth.php';
require_login();
require_once dirname(__DIR__) . '/user/conexion.php';

$usuarioSesion = $_SESSION['usuario'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    $archivo = $_FILES['foto'];

    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        die("Error al subir el archivo.");
    }

    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];
    $nombreOriginal = $archivo['name'];
    $ext = strtolower(pathinfo($nombreOriginal, PATHINFO_EXTENSION));

    if (!in_array($ext, $extensionesPermitidas)) {
        die("Formato no permitido. Usa JPG, PNG o WEBP.");
    }

    if ($archivo['size'] > 2 * 1024 * 1024) {
        die("El archivo debe pesar menos de 2MB.");
    }

    $directorioDestino = dirname(__DIR__) . '/uploads/avatars/';
    if (!file_exists($directorioDestino)) {
        mkdir($directorioDestino, 0777, true);
    }

    $nuevoNombre = 'avatar_' . md5($usuarioSesion . time()) . '.' . $ext;
    $rutaFinal = $directorioDestino . $nuevoNombre;

    if (move_uploaded_file($archivo['tmp_name'], $rutaFinal)) {
        $stmt = $conn->prepare("UPDATE usuarios SET foto_perfil = ? WHERE usuario = ?");
        $stmt->bind_param("ss", $nuevoNombre, $usuarioSesion);
        $stmt->execute();

   header("Location: perfil.php?tab=cuenta&status=success");
exit;

    } else {
        die("Error al guardar la imagen en el servidor.");
    }
}