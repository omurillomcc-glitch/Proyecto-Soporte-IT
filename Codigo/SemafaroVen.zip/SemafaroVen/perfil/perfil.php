<?php

require_once dirname(__DIR__) . '/user/auth.php';
require_login();

require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/layout_menu.php';

$usuarioSesion = $_SESSION['usuario'] ?? '';


/*
 OBTENER USUARIO
*/

$stmt = $conn->prepare("
    SELECT
        id,
        usuario,
        nombre_completo,
        rol,
        estado,
        foto_perfil,
        creado_en,
        ultimo_login
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

if (!$stmt) {
    die("Error en prepare: " . $conn->error);
}

$stmt->bind_param("s", $usuarioSesion);
$stmt->execute();

$resultado = $stmt->get_result();
$perfil = $resultado->fetch_assoc();

$stmt->close();


if (!$perfil) {

    echo "
        <div style='padding:30px;'>
            No se encontró la información del perfil.
        </div>
    ";

    require_once dirname(__DIR__) . '/layout_footer.php';

    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
 DATOS PRINCIPALES
*/

$usuarioId = (int)$perfil['id'];

$usuario = trim(
    (string)($perfil['usuario'] ?? '')
);

$nombre = trim(
    (string)($perfil['nombre_completo'] ?? '')
);

if ($nombre === '') {
    $nombre = $usuario;
}


/*
 INICIALES
*/

$partesNombre = array_values(
    array_filter(
        preg_split('/\s+/', trim($nombre))
    )
);

if (count($partesNombre) >= 2) {

    $iniciales = mb_strtoupper(

        mb_substr(
            $partesNombre[0],
            0,
            1,
            'UTF-8'
        )

        .

        mb_substr(
            $partesNombre[1],
            0,
            1,
            'UTF-8'
        ),

        'UTF-8'
    );

} else {

    $iniciales = mb_strtoupper(
        mb_substr(
            $nombre,
            0,
            2,
            'UTF-8'
        ),
        'UTF-8'
    );
}


/*
 ROL
*/

$rolRaw = strtolower(
    trim(
        (string)($perfil['rol'] ?? '')
    )
);

$rolTexto = match ($rolRaw) {

    'administrador',
    'admin'
        => 'Administrador',

    'gerente_comercial'
        => 'Gerente Comercial',

    'gerente_tienda'
        => 'Gerente de Tienda',

    default
        => ucfirst(
            str_replace(
                '_',
                ' ',
                $rolRaw ?: 'Usuario'
            )
        )

};


/*
ESTADO
*/

$estadoActivo =
    ((int)$perfil['estado'] === 1);

$estadoTexto =
    $estadoActivo
        ? 'Cuenta Activa'
        : 'Cuenta Bloqueada';


/*
 FECHAS

*/

$fechaCreacion =
    !empty($perfil['creado_en'])
        ? date(
            'd/m/Y h:i A',
            strtotime($perfil['creado_en'])
        )
        : 'No disponible';


$ultimoLogin =
    !empty($perfil['ultimo_login'])
        ? date(
            'd/m/Y h:i A',
            strtotime($perfil['ultimo_login'])
        )
        : 'No disponible';


/*
 FOTO
*/

$rutaFisica =
    $_SERVER['DOCUMENT_ROOT']
    . '/SemafaroVen/uploads/avatars/'
    . ($perfil['foto_perfil'] ?? '');


$fotoRuta = (

    !empty($perfil['foto_perfil'])
    &&
    file_exists($rutaFisica)

)
    ? $baseUrl
        . '/uploads/avatars/'
        . $perfil['foto_perfil']

    : null;


/*
TIENDAS ASIGNADAS

*/

$tiendasAsignadas = [];


$stmtTiendas = $conn->prepare("
    SELECT
        codalmacen,
        nombre_tienda,
        poblacion
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY codalmacen ASC
");


if ($stmtTiendas) {

    $stmtTiendas->bind_param(
        "i",
        $usuarioId
    );

    $stmtTiendas->execute();

    $resultadoTiendas =
        $stmtTiendas->get_result();


    while (
        $tienda =
        $resultadoTiendas->fetch_assoc()
    ) {

        $tiendasAsignadas[] = [

            'codigo' =>
                trim(
                    (string)$tienda['codalmacen']
                ),

            'nombre' =>
                trim(
                    (string)$tienda['nombre_tienda']
                ),

            'poblacion' =>
                trim(
                    (string)$tienda['poblacion']
                )

        ];
    }


    $stmtTiendas->close();
}


/*
 EMPRESA
  Actualmente las tiendas del sistema provienen de MENDELS.

*/

$empresaTexto = 'Mendels';


/*
 TEXTO DE TIENDA SEGÚN ROL

*/

if ($rolRaw === 'administrador') {

    $tituloTienda = 'Acceso a tiendas';

} elseif ($rolRaw === 'gerente_comercial') {

    $tituloTienda =
        count($tiendasAsignadas) === 1
            ? 'Tienda asignada'
            : 'Tiendas asignadas';

} else {

    $tituloTienda = 'Tienda asignada';

}

?>


<link
    rel="stylesheet"
    href="<?= $baseUrl ?>/perfil/perfil.css?v=<?= time() ?>"
>


<div class="account-page">

    <div class="account-wrapper">




        <section class="account-card">



            <div class="profile-top">


                <!-- FOTO -->

                <div class="profile-avatar">

                    <div class="profile-avatar-image">

                        <?php if ($fotoRuta): ?>

                            <img
                                src="<?= h($fotoRuta) ?>"
                                alt="Foto de <?= h($nombre) ?>"
                            >

                        <?php else: ?>

                            <span>
                                <?= h($iniciales) ?>
                            </span>

                        <?php endif; ?>

                    </div>


                    <!-- CÁMARA -->

                    <button
                        type="button"
                        class="profile-camera"
                        onclick="abrirModalFoto()"
                        title="Cambiar foto"
                        aria-label="Cambiar foto de perfil"
                    >

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                        >
                            <path d="
                                M23 19
                                a2 2 0 0 1-2 2
                                H3
                                a2 2 0 0 1-2-2
                                V8
                                a2 2 0 0 1 2-2
                                h4
                                l2-3
                                h6
                                l2 3
                                h4
                                a2 2 0 0 1 2 2
                                z
                            "/>

                            <circle
                                cx="12"
                                cy="13"
                                r="4"
                            />

                        </svg>

                    </button>

                </div>


                <!-- INFORMACIÓN -->

                <div class="profile-main-info">

                    <span class="profile-caption">
                        PERFIL DE USUARIO
                    </span>

                    <h2>
                        <?= h($nombre) ?>
                    </h2>


                    <span class="profile-username">
                        @<?= h($usuario) ?>
                    </span>


                    <div class="profile-meta">


                        <!-- ROL -->

                        <span class="profile-role">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                            >

                                <path
                                    d="M12 3l7 3v5c0 4.5-2.9 8.6-7 10-4.1-1.4-7-5.5-7-10V6l7-3z"
                                />

                                <path
                                    d="M9.5 12l1.7 1.7 3.5-3.7"
                                />

                            </svg>

                            <?= h($rolTexto) ?>

                        </span>


                        <!-- ESTADO -->

                        <span
                            class="
                                profile-status
                                <?= $estadoActivo
                                    ? 'active'
                                    : 'blocked'
                                ?>
                            "
                        >

                            <span class="profile-status-dot"></span>

                            <?= h($estadoTexto) ?>

                        </span>


                    </div>

                </div>

            </div>


            <!--
                 INFORMACIÓN PERSONAL
          -->

            <div class="profile-section">

                <div class="profile-section-header">

                    <span class="section-icon">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <circle
                                cx="12"
                                cy="8"
                                r="4"
                            />

                            <path
                                d="M4 21a8 8 0 0 1 16 0"
                            />

                        </svg>

                    </span>


                    <div>

                        <h3>
                            Información personal
                        </h3>

                        <p>
                            Datos principales del usuario
                        </p>

                    </div>

                </div>


                <div class="profile-list">


                    <!-- USUARIO -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Usuario
                        </div>

                        <div class="profile-value username-value">
                            <?= h($usuario) ?>
                        </div>

                    </div>


                    <!-- NOMBRE -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Nombre completo
                        </div>

                        <div class="profile-value">
                            <?= h($nombre) ?>
                        </div>

                    </div>


                </div>

            </div>


            <!-- =================================================
                 ACCESO AL SISTEMA
            ================================================== -->

            <div class="profile-section">

                <div class="profile-section-header">

                    <span class="section-icon">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <rect
                                x="3"
                                y="4"
                                width="18"
                                height="17"
                                rx="2"
                            />

                            <path d="M3 9h18"/>

                            <path d="M8 4v5"/>

                            <path d="M16 4v5"/>

                        </svg>

                    </span>


                    <div>

                        <h3>
                            Acceso al sistema
                        </h3>

                        <p>
                            Rol y alcance asignado
                        </p>

                    </div>

                </div>


                <div class="profile-list">


                    <!-- ROL -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Rol
                        </div>

                        <div class="profile-value">
                            <?= h($rolTexto) ?>
                        </div>

                    </div>


                    <!-- EMPRESA -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Empresa
                        </div>

                        <div class="profile-value company-value">

                            <span class="company-dot"></span>

                            <?= h($empresaTexto) ?>

                        </div>

                    </div>


                    <!-- TIENDA -->

                    <div class="profile-row profile-row-store">

                        <div class="profile-label">
                            <?= h($tituloTienda) ?>
                        </div>


                        <div class="profile-value">


                            <?php if ($rolRaw === 'administrador'): ?>


                                <div class="store-access-all">

                                    <span class="store-icon">

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.8"
                                        >

                                            <path d="M3 10h18"/>

                                            <path
                                                d="M5 10V21H19V10"
                                            />

                                            <path
                                                d="M3 10L5 4H19L21 10"
                                            />

                                            <path
                                                d="M9 21V15H15V21"
                                            />

                                        </svg>

                                    </span>

                                    <div>

                                        <strong>
                                            Todas las tiendas
                                        </strong>

                                        <small>
                                            Acceso administrativo
                                        </small>

                                    </div>

                                </div>


                            <?php elseif (empty($tiendasAsignadas)): ?>


                                <span class="store-empty">
                                    Sin tienda asignada
                                </span>


                            <?php elseif (count($tiendasAsignadas) === 1): ?>


                                <?php
                                    $tiendaActual =
                                        $tiendasAsignadas[0];
                                ?>


                                <div class="store-single">

                                    <span class="store-icon">

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.8"
                                        >

                                            <path d="M3 10h18"/>

                                            <path
                                                d="M5 10V21H19V10"
                                            />

                                            <path
                                                d="M3 10L5 4H19L21 10"
                                            />

                                            <path
                                                d="M9 21V15H15V21"
                                            />

                                        </svg>

                                    </span>


                                    <div class="store-copy">

                                        <strong>
                                            <?= h(
                                                $tiendaActual['nombre']
                                            ) ?>
                                        </strong>


                                        <div class="store-extra">

                                            <?php
                                            if (
                                                $tiendaActual['codigo']
                                                !== ''
                                            ):
                                            ?>

                                                <span>
                                                    Tienda
                                                    <?= h(
                                                        $tiendaActual['codigo']
                                                    ) ?>
                                                </span>

                                            <?php endif; ?>


                                            <?php
                                            if (
                                                $tiendaActual['poblacion']
                                                !== ''
                                            ):
                                            ?>

                                                <span class="store-city">

                                                    <svg
                                                        viewBox="0 0 24 24"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        stroke-width="2"
                                                    >

                                                        <path
                                                            d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z"
                                                        />

                                                        <circle
                                                            cx="12"
                                                            cy="10"
                                                            r="2.5"
                                                        />

                                                    </svg>

                                                    <?= h(
                                                        $tiendaActual['poblacion']
                                                    ) ?>

                                                </span>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </div>


                            <?php else: ?>


                                <div class="store-multiple">


                                    <div class="store-count">

                                        <?= count(
                                            $tiendasAsignadas
                                        ) ?>

                                        tiendas asignadas

                                    </div>


                                    <div class="store-tags">

                                        <?php
                                        foreach (
                                            $tiendasAsignadas
                                            as $tienda
                                        ):
                                        ?>

                                            <span class="store-tag">

                                                <?= h(
                                                    $tienda['nombre']
                                                ) ?>

                                            </span>

                                        <?php endforeach; ?>

                                    </div>


                                </div>


                            <?php endif; ?>


                        </div>

                    </div>


                    <!-- ESTADO -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Estado
                        </div>


                        <div
                            class="
                                profile-value
                                row-status
                                <?= $estadoActivo
                                    ? 'active'
                                    : 'blocked'
                                ?>
                            "
                        >

                            <span></span>

                            <?= h($estadoTexto) ?>

                        </div>

                    </div>


                </div>

            </div>


            <!-- 
                 ACTIVIDAD DE LA CUENTA
          -->

            <div class="profile-section">

                <div class="profile-section-header">

                    <span class="section-icon">

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >

                            <circle
                                cx="12"
                                cy="12"
                                r="9"
                            />

                            <path
                                d="M12 7v5l3 2"
                            />

                        </svg>

                    </span>


                    <div>

                        <h3>
                            Actividad de la cuenta
                        </h3>

                        <p>
                            Información de acceso y registro
                        </p>

                    </div>

                </div>


                <div class="profile-list">


                    <!-- ÚLTIMO ACCESO -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Último acceso
                        </div>

                        <div class="profile-value">

                            <span class="date-value">

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >

                                    <circle
                                        cx="12"
                                        cy="12"
                                        r="9"
                                    />

                                    <path
                                        d="M12 7v5l3 2"
                                    />

                                </svg>

                                <?= h($ultimoLogin) ?>

                            </span>

                        </div>

                    </div>


                    <!-- FECHA REGISTRO -->

                    <div class="profile-row">

                        <div class="profile-label">
                            Fecha de registro
                        </div>

                        <div class="profile-value">

                            <span class="date-value">

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >

                                    <rect
                                        x="3"
                                        y="5"
                                        width="18"
                                        height="16"
                                        rx="2"
                                    />

                                    <path
                                        d="M16 3v4M8 3v4M3 10h18"
                                    />

                                </svg>

                                <?= h($fechaCreacion) ?>

                            </span>

                        </div>

                    </div>


                </div>

            </div>


            <!-- =================================================
                 NOTA
            ================================================== -->

            <div class="profile-note">

                <span class="profile-note-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="9"
                        />

                        <path d="M12 11v6"/>

                        <path d="M12 7h.01"/>

                    </svg>

                </span>


                <div>

                    <strong>
                        Importante
                    </strong>

                    <p>
                        Si necesitas actualizar algún dato
                        de tu cuenta, contacta al administrador.
                    </p>

                </div>

            </div>


        </section>

    </div>

</div>


<!-- =========================================================
     CROPPER JS
========================================================= -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css"
>

<script
    src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"
></script>


<!-- =========================================================
     MODAL FOTO
========================================================= -->

<div
    id="modalFoto"
    class="app-modal"
    style="display:none;"
>

    <div class="modal-box">


        <div class="modal-header">

            <h3>
                Actualizar foto de perfil
            </h3>

            <button
                type="button"
                class="close-btn"
                onclick="cerrarModalFoto()"
                aria-label="Cerrar"
            >
                &times;
            </button>

        </div>


        <form id="formCropper">


            <div class="modal-body">

                <input
                    type="file"
                    id="inputFotoPerfil"
                    accept="
                        image/png,
                        image/jpeg,
                        image/jpg,
                        image/webp
                    "
                    class="file-input"
                >


                <small>
                    Formatos admitidos:
                    JPG, PNG y WEBP.
                    Máximo 2MB.
                </small>


                <div class="cropper-wrapper">

                    <img
                        id="imageToCrop"
                        src=""
                        alt="Previsualización"
                    >

                </div>

            </div>


            <div class="modal-footer">

                <button
                    type="button"
                    class="btn-secondary"
                    onclick="cerrarModalFoto()"
                >
                    Cancelar
                </button>


                <button
                    type="button"
                    id="btnGuardarFoto"
                    class="btn-primary"
                    style="display:none;"
                >
                    Guardar Foto
                </button>

            </div>

        </form>

    </div>

</div>


<script>

let cropper = null;

const modalFoto =
    document.getElementById('modalFoto');

const inputFotoPerfil =
    document.getElementById('inputFotoPerfil');

const imageToCrop =
    document.getElementById('imageToCrop');

const cropperWrapper =
    document.querySelector('.cropper-wrapper');

const btnGuardarFoto =
    document.getElementById('btnGuardarFoto');


/*
|--------------------------------------------------------------------------
| ABRIR MODAL
|--------------------------------------------------------------------------
*/

function abrirModalFoto()
{
    modalFoto.style.display = 'flex';
}


/*
|--------------------------------------------------------------------------
| SELECCIONAR FOTO
|--------------------------------------------------------------------------
*/

inputFotoPerfil.addEventListener(
    'change',
    function(e)
    {

        const files = e.target.files;

        if (!files || files.length === 0) {
            return;
        }


        const file = files[0];


        /*
        |--------------------------------------------------------------
        | VALIDAR TAMAÑO
        |--------------------------------------------------------------
        */

        if (
            file.size >
            2 * 1024 * 1024
        ) {

            alert(
                'La imagen debe pesar menos de 2MB.'
            );

            this.value = '';

            return;
        }


        /*
        VALIDAR TIPO
        */

        const permitidos = [
            'image/jpeg',
            'image/png',
            'image/webp'
        ];


        if (
            !permitidos.includes(
                file.type
            )
        ) {

            alert(
                'Formato no permitido. Usa JPG, PNG o WEBP.'
            );

            this.value = '';

            return;
        }


        const reader =
            new FileReader();


        reader.onload =
            function(event)
            {

                imageToCrop.src =
                    event.target.result;


                cropperWrapper.style.display =
                    'block';


                btnGuardarFoto.style.display =
                    'inline-flex';


                if (cropper) {

                    cropper.destroy();

                }


                cropper =
                    new Cropper(
                        imageToCrop,
                        {

                            aspectRatio: 1,

                            viewMode: 1,

                            autoCropArea: 0.9,

                            responsive: true,

                            restore: false,

                            background: false

                        }
                    );

            };


        reader.readAsDataURL(file);

    }
);


/*
 GUARDAR FOTO

*/

btnGuardarFoto.addEventListener(
    'click',
    function()
    {

        if (!cropper) {
            return;
        }


        btnGuardarFoto.disabled =
            true;

        btnGuardarFoto.textContent =
            'Guardando...';


        const canvas =
            cropper.getCroppedCanvas(
                {
                    width: 400,
                    height: 400
                }
            );


        if (!canvas) {

            alert(
                'No se pudo procesar la imagen.'
            );

            btnGuardarFoto.disabled =
                false;

            btnGuardarFoto.textContent =
                'Guardar Foto';

            return;
        }


        canvas.toBlob(
            function(blob)
            {

                if (!blob) {

                    alert(
                        'No se pudo procesar la imagen.'
                    );

                    btnGuardarFoto.disabled =
                        false;

                    btnGuardarFoto.textContent =
                        'Guardar Foto';

                    return;
                }


                const formData =
                    new FormData();


                formData.append(
                    'foto',
                    blob,
                    'avatar.jpg'
                );


                fetch(
                    '<?= $baseUrl ?>/perfil/subir_foto.php',
                    {

                        method: 'POST',

                        body: formData

                    }
                )

                .then(
                    response =>
                    {

                        if (
                            response.redirected
                        ) {

                            window.location.href =
                                response.url;

                        } else {

                            window.location.reload();

                        }

                    }
                )

                .catch(
                    error =>
                    {

                        console.error(
                            'Error:',
                            error
                        );


                        alert(
                            'Ocurrió un error al guardar la imagen.'
                        );


                        btnGuardarFoto.disabled =
                            false;


                        btnGuardarFoto.textContent =
                            'Guardar Foto';

                    }
                );

            },

            'image/jpeg',

            0.90

        );

    }
);


/*
CERRAR MODAL

*/

function cerrarModalFoto()
{

    modalFoto.style.display =
        'none';


    if (cropper) {

        cropper.destroy();

        cropper = null;

    }


    inputFotoPerfil.value = '';

    imageToCrop.src = '';

    cropperWrapper.style.display =
        'none';

    btnGuardarFoto.style.display =
        'none';

    btnGuardarFoto.disabled =
        false;

    btnGuardarFoto.textContent =
        'Guardar Foto';

}


/*
 CERRAR HACIENDO CLICK FUERA

*/

modalFoto.addEventListener(
    'click',
    function(e)
    {

        if (
            e.target === modalFoto
        ) {

            cerrarModalFoto();

        }

    }
);


/*
 ESC

*/

document.addEventListener(
    'keydown',
    function(e)
    {

        if (
            e.key === 'Escape'
            &&
            modalFoto.style.display ===
            'flex'
        ) {

            cerrarModalFoto();

        }

    }
);

</script>


<?php

require_once dirname(__DIR__) . '/layout_footer.php';

?>