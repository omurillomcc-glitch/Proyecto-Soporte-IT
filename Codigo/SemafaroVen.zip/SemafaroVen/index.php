<?php
require_once __DIR__ . '/user/auth.php';
require_login();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Semafaro | Grupo MCC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/css/menu.css?v=<?= time() ?>">
<link rel="shortcut icon" type="image/png" href="/SemafaroVen/img/sv.png">

</head>
<body>
<?php require __DIR__ . '/layout_menu.php'; ?>

<h1></h1>
<p></p>


<?php require __DIR__ . '/layout_footer.php'; ?>
</body>
</html>
