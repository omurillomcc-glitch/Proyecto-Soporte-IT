<?php

declare(strict_types=1);

if (!function_exists('dias_normalizar_dni')) {
    function dias_normalizar_dni(string $dni): string
    {
        $dni = strtoupper(trim($dni));
        $dni = preg_replace('/[^A-Z0-9]/', '', $dni) ?? '';
        return substr($dni, 0, 20);
    }
}

if (!function_exists('dias_normalizar_nombre_tienda')) {
    function dias_normalizar_nombre_tienda(string $texto): string
    {
        $texto = trim($texto);
        if ($texto === '') {
            return '';
        }

        if (function_exists('iconv')) {
            $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texto);
            if ($tmp !== false) {
                $texto = $tmp;
            }
        }

        $texto = strtolower($texto);
        $texto = str_replace(["mendel's", "mendel’s", 'mendels', 'mendel'], '', $texto);
        return preg_replace('/[^a-z0-9]+/', '', $texto) ?? '';
    }
}

if (!function_exists('dias_score_tienda')) {
    function dias_score_tienda(string $almacen, string $front): float
    {
        $a = dias_normalizar_nombre_tienda($almacen);
        $b = dias_normalizar_nombre_tienda($front);

        if ($a === '' || $b === '') return 0.0;
        if ($a === $b) return 1.0;
        if (str_contains($a, $b) || str_contains($b, $a)) return 0.96;

        similar_text($a, $b, $pct);
        $sim = $pct / 100;
        $maxLen = max(strlen($a), strlen($b));
        $lev = $maxLen > 0 ? 1 - (levenshtein($a, $b) / $maxLen) : 0.0;

        return max($sim, $lev);
    }
}

if (!function_exists('dias_consultar_vendedores_mendels')) {
    /**
     * Devuelve TODOS los vendedores de la consulta confirmada por el usuario,
     * incluso si IDENTIDAD viene NULL.
     *
     * @return array<int,array{codvendedor:string,dni:string,nombre:string,tienda:string}>
     */
    function dias_consultar_vendedores_mendels($sqlsrv): array
    {
        if (!$sqlsrv) return [];

        $sql = "
          SELECT DISTINCT
    A.CODVENDEDOR,
    COALESCE(NULLIF(A.DNI, ''), NULLIF(A.NUMSSOCIAL, '')) AS IDENTIDAD,
    A.NOMVENDEDOR,
    A.TIPOUSUARIO,
    C.TITULO AS NOMBRE_TIENDA
FROM MENDELS.dbo.VENDEDORES A
INNER JOIN MENDELS.dbo.REM_LISTASFRONTS B
    ON A.CODVENDEDOR = B.CODIGO
INNER JOIN MENDELS.dbo.REM_FRONTS C
    ON B.IDFRONT = C.IDFRONT
LEFT JOIN MENDELS.dbo.TIPOEMPLEADOS TE
    ON A.TIPOUSUARIO = TE.CODTIPOEMPLEADO
WHERE A.DESCATALOGADO = 'F'
  AND A.TIPOUSUARIO IN (111, 112, 104, 119,116)
  AND B.TIPO = 2
  AND C.IDFRONT IN (
      2,   -- Mendels Plaza Miraflores
      12,  -- Mendels Mall Dorado
      28,  -- Mendels Galerías
      36,  -- Mendels Choluteca
      44,  -- Mendels Citymall
      53,  -- Mendels Metromall
      70,  -- Mendels Multiplaza S.P.S
      78,  -- Mendels Siguatepeque
      85,  -- Mendels Comayagua
      92,  -- Mendels La Ceiba
      99,  -- Mendels Tela
      104, -- Mendels Santa Rosa
      110, -- Mendels Juticalpa
      115, -- Mendels Danli
      183, -- Mendels Mall Premier
      192  --Mendels Megamall
  )
ORDER BY
    C.TITULO ASC,
    A.CODVENDEDOR ASC;
        ";

        $stmt = sqlsrv_query($sqlsrv, $sql);
        if ($stmt === false) {
            error_log('DIAS: error consulta vendedores: ' . print_r(sqlsrv_errors(), true));
            return [];
        }

        $filas = [];
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $filas[] = [
                'codvendedor' => trim((string)($row['CODVENDEDOR'] ?? '')),
                'dni' => dias_normalizar_dni((string)($row['IDENTIDAD'] ?? '')),
                'nombre' => trim((string)($row['NOMVENDEDOR'] ?? '')) ?: 'Vendedor',
                'tienda' => trim((string)($row['NOMBRE_TIENDA'] ?? '')),
            ];
        }
        sqlsrv_free_stmt($stmt);

        return $filas;
    }
}


if (!function_exists('dias_obtener_vendedores_tienda')) {
    /**
     * La llave del arreglo es CODVENDEDOR, NO DNI.
     * Así no desaparecen vendedores con DNI NULL ni vendedores con DNI repetido.
     *
     * @return array<string,array{codvendedor:string,dni:string,nombre:string,tienda:string,dni_duplicado:bool}>
     */
    function dias_obtener_vendedores_tienda($sqlsrv, string $nombreTienda): array
    {
        $filas = dias_consultar_vendedores_mendels($sqlsrv);
        if (!$filas || trim($nombreTienda) === '') return [];

        $titulos = [];
        foreach ($filas as $fila) {
            if ($fila['tienda'] !== '') {
                $titulos[$fila['tienda']] = true;
            }
        }

        $mejorTitulo = '';
        $mejorScore = 0.0;

        foreach (array_keys($titulos) as $titulo) {
            $score = dias_score_tienda($nombreTienda, $titulo);
            if ($score > $mejorScore) {
                $mejorScore = $score;
                $mejorTitulo = $titulo;
            }
        }

        if ($mejorTitulo === '' || $mejorScore < 0.58) {
            error_log(sprintf(
                'DIAS: no se pudo mapear tienda "%s". Mejor="%s" score=%.3f',
                $nombreTienda,
                $mejorTitulo,
                $mejorScore
            ));
            return [];
        }

        $seleccionados = [];
        $conteoDni = [];

        foreach ($filas as $fila) {
            if ($fila['tienda'] !== $mejorTitulo) continue;

            $cod = (string)$fila['codvendedor'];
            if ($cod === '') continue;

            $seleccionados[$cod] = $fila;

            if ($fila['dni'] !== '') {
                $conteoDni[$fila['dni']] = ($conteoDni[$fila['dni']] ?? 0) + 1;
            }
        }

        foreach ($seleccionados as $cod => &$fila) {
            $fila['dni_duplicado'] = $fila['dni'] !== '' && (($conteoDni[$fila['dni']] ?? 0) > 1);
        }
        unset($fila);

        uasort($seleccionados, static function (array $a, array $b): int {
            $cmp = strcasecmp((string)$a['nombre'], (string)$b['nombre']);
            if ($cmp !== 0) return $cmp;
            return strnatcasecmp((string)$a['codvendedor'], (string)$b['codvendedor']);
        });

        error_log(sprintf(
            'DIAS: tienda "%s" -> "%s" (score %.3f), vendedores=%d',
            $nombreTienda,
            $mejorTitulo,
            $mejorScore,
            count($seleccionados)
        ));

        return $seleccionados;
    }
}

if (!function_exists('dias_buscar_vendedor_por_dni')) {
    /** @return array{codvendedor:string,dni:string,nombre:string,tienda:string,dni_duplicado:bool}|null */
    function dias_buscar_vendedor_por_dni($sqlsrv, string $dniBuscado, string $nombreTienda): ?array
    {
        $dniBuscado = dias_normalizar_dni($dniBuscado);
        if ($dniBuscado === '') return null;

        foreach (dias_obtener_vendedores_tienda($sqlsrv, $nombreTienda) as $vendedor) {
            if ($vendedor['dni'] === $dniBuscado) {
                return $vendedor;
            }
        }

        return null;
    }
}


if (!function_exists('dias_normalizar_busqueda')) {
    function dias_normalizar_busqueda(string $texto): string
    {
        $texto = trim($texto);
        if ($texto === '') return '';

        if (function_exists('iconv')) {
            $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texto);
            if ($tmp !== false) {
                $texto = $tmp;
            }
        }

        $texto = mb_strtolower($texto, 'UTF-8');
        return preg_replace('/[^a-z0-9]+/i', '', $texto) ?? '';
    }
}

if (!function_exists('dias_buscar_vendedores_en_tienda')) {
    /**
     * Busca únicamente dentro de los vendedores que ya pertenecen a la tienda.
     * Prioriza coincidencia exacta por código o DNI; por nombre permite coincidencia parcial.
     *
     * @param array<string,array<string,mixed>> $vendedores
     * @return array<string,array<string,mixed>>
     */
    function dias_buscar_vendedores_en_tienda(array $vendedores, string $busqueda): array
    {
        $busquedaOriginal = trim($busqueda);
        if ($busquedaOriginal === '') return [];

        $dniBuscado = dias_normalizar_dni($busquedaOriginal);
        $textoBuscado = dias_normalizar_busqueda($busquedaOriginal);

        $exactos = [];
        $parciales = [];

        foreach ($vendedores as $cod => $vendedor) {
            $codigo = trim((string)$cod);
            $dni = dias_normalizar_dni((string)($vendedor['dni'] ?? ''));
            $nombreNormalizado = dias_normalizar_busqueda((string)($vendedor['nombre'] ?? ''));

            if (
                strcasecmp($codigo, $busquedaOriginal) === 0 ||
                ($dniBuscado !== '' && $dni !== '' && $dni === $dniBuscado)
            ) {
                $exactos[$codigo] = $vendedor;
                continue;
            }

            if ($textoBuscado !== '' && $nombreNormalizado !== '' && str_contains($nombreNormalizado, $textoBuscado)) {
                $parciales[$codigo] = $vendedor;
            }
        }

        return $exactos ?: $parciales;
    }
}

if (!function_exists('dias_obtener_registrados_mes')) {
    /**
     * @param array<int,array<string,mixed>> $semanasMes
     * @return array<string,array<string,int>>  clave anio-semana => dni => dias
     */
    function dias_obtener_registrados_mes($sqlsrv, string $tienda, array $semanasMes): array
    {
        if (!$sqlsrv || $tienda === '' || empty($semanasMes)) return [];

        $salida = [];

        foreach ($semanasMes as $semana) {
            $anio = (int)($semana['anio'] ?? 0);
            $num = (int)($semana['semana'] ?? 0);
            if ($anio <= 0 || $num < 1 || $num > 53) continue;

            $clave = $anio . '-' . $num;
            $salida[$clave] = [];

            $sql = "
                SELECT DNI, DIAS_TRABAJADOS
                FROM [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]
                WHERE TIENDA = ? AND ANIO = ? AND SEMANA = ?
            ";
            $stmt = sqlsrv_query($sqlsrv, $sql, [$tienda, $anio, $num]);
            if ($stmt === false) {
                error_log('DIAS: error leyendo registros: ' . print_r(sqlsrv_errors(), true));
                continue;
            }

            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $dni = dias_normalizar_dni((string)($row['DNI'] ?? ''));
                if ($dni !== '') {
                    $salida[$clave][$dni] = (float)($row['DIAS_TRABAJADOS'] ?? 0);
                }
            }
            sqlsrv_free_stmt($stmt);
        }

        return $salida;
    }
}

if (!function_exists('dias_registrar_auditoria')) {
    function dias_registrar_auditoria(mysqli $conn, string $accion, string $detalle): bool
    {
        try {
            $usuario = trim((string)($_SESSION['usuario'] ?? 'DESCONOCIDO')) ?: 'DESCONOCIDO';
            $nombre = trim((string)($_SESSION['nombre_completo'] ?? $_SESSION['nombre'] ?? $usuario)) ?: $usuario;
            $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? '-')) ?: '-';

            $sql = "
                INSERT INTO auditoria
                    (nombre_completo, usuario, accion, ip, fecha, detalle)
                VALUES (?, ?, ?, ?, NOW(), ?)
            ";

            $stmt = $conn->prepare($sql);
            if (!$stmt) return false;

            $stmt->bind_param('sssss', $nombre, $usuario, $accion, $ip, $detalle);
            $ok = $stmt->execute();
            $stmt->close();

            return $ok;
        } catch (Throwable $e) {
            error_log('DIAS: auditoría: ' . $e->getMessage());
            return false;
        }
    }
}
