<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}
session_name('APP_SEMAFARO');
session_start();
require_once dirname(__DIR__) . '/user/auth.php';
require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';
require_once dirname(__DIR__) . '/resumen/retail_helper.php';
require_once __DIR__ . '/dias_helper.php';
$baseUrl = $baseUrl ?? '/SemafaroVen';
$rolesPermitidos = ['administrador', 'gerente_comercial', 'gerente_tienda'];
$rol = (string)($_SESSION['rol'] ?? '');
$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
if (!in_array($rol, $rolesPermitidos, true) || $usuarioId <= 0) {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$tz = new DateTimeZone('America/Tegucigalpa');
$hoy = new DateTimeImmutable('today', $tz);
$anioVista = (int)$hoy->format('Y');
$mesVista = (int)$hoy->format('n');
$semanasMes = retail_obtener_semanas_mes($anioVista, $mesVista);
/*
TIENDAS PERMITIDAS
*/
$tiendas = retail_obtener_tiendas_permitidas(
    $conn,
    $sqlsrv_conn_exhibicion ?? false,
    $rol,
    $usuarioId
);
$codigoSeleccionado = trim((string)($_GET['tienda'] ?? $_POST['tienda'] ?? ''));
if ($rol === 'gerente_tienda' && count($tiendas) === 1) {
    $codigoSeleccionado = (string)array_key_first($tiendas);
} elseif ($codigoSeleccionado === '' || !isset($tiendas[$codigoSeleccionado])) {
    $codigoSeleccionado = !empty($tiendas) ? (string)array_key_first($tiendas) : '';
}
$tiendaSeleccionada = (
    $codigoSeleccionado !== '' && isset($tiendas[$codigoSeleccionado])
) ? $tiendas[$codigoSeleccionado] : null;
/*
|--------------------------------------------------------------------------
| SEMANA SELECCIONADA
|--------------------------------------------------------------------------
| Por defecto SIEMPRE se selecciona la semana Retail actual.
| El usuario puede elegir otra semana del mes desde el select.
*/
$semanasDisponibles = [];
$claveSemanaActual = '';
foreach ($semanasMes as $semana) {
    $anioSemana = (int)($semana['anio'] ?? 0);
    $numeroSemana = (int)($semana['semana'] ?? 0);
    if ($anioSemana <= 0 || $numeroSemana < 1 || $numeroSemana > 53) {
        continue;
    }
    $clave = $anioSemana . '-' . $numeroSemana;
    $semanasDisponibles[$clave] = $semana;
    if ($hoy >= $semana['fecha_inicio'] && $hoy <= $semana['fecha_fin']) {
        $claveSemanaActual = $clave;
    }
}
if ($claveSemanaActual === '' && !empty($semanasDisponibles)) {
    $claveSemanaActual = (string)array_key_first($semanasDisponibles);
}
$claveSemanaSeleccionada = trim((string)($_GET['semana'] ?? $_POST['semana'] ?? ''));
if ($claveSemanaSeleccionada === '' || !isset($semanasDisponibles[$claveSemanaSeleccionada])) {
    $claveSemanaSeleccionada = $claveSemanaActual;
}
$semanaSeleccionada = $claveSemanaSeleccionada !== ''
    ? ($semanasDisponibles[$claveSemanaSeleccionada] ?? null)
    : null;
/*
 VENDEDORES + ADMINISTRACIÓN VISUAL
 Quitar/agregar NO modifica ICG. Los vendedores quitados se guardan en
 MySQL por tienda para que permanezcan ocultos para todos los usuarios aunque cierren sesión.
*/
$vendedores = [];
$vendedoresBase = [];
$registrosMes = [];
$errorLocal = '';
$codigosOcultos = [];
if ($tiendaSeleccionada && !empty($semanasMes)) {
    $vendedoresBase = dias_obtener_vendedores_tienda(
        $sqlsrv_conn_exhibicion ?? false,
        (string)($tiendaSeleccionada['nombre'] ?? '')
    );
    $identidadesManuales = [];
    $stmtIdentidades = $conn->prepare(
        "SELECT codvendedor, dni
         FROM dias_trabajados_identidades_manual
         WHERE tienda = ?"
    );
    if ($stmtIdentidades) {
        $stmtIdentidades->bind_param('s', $codigoSeleccionado);
        if ($stmtIdentidades->execute()) {
            $stmtIdentidades->bind_result($codIdentidad, $dniIdentidad);
            while ($stmtIdentidades->fetch()) {
                $codIdentidad = trim((string)$codIdentidad);
                $dniIdentidad = dias_normalizar_dni((string)$dniIdentidad);
                if ($codIdentidad !== '' && $dniIdentidad !== '') {
                    $identidadesManuales[$codIdentidad] = $dniIdentidad;
                }
            }
        }
        $stmtIdentidades->close();
    }
    foreach ($identidadesManuales as $codIdentidad => $dniIdentidad) {
        if (isset($vendedoresBase[$codIdentidad]) && dias_normalizar_dni((string)($vendedoresBase[$codIdentidad]['dni'] ?? '')) === '') {
            $vendedoresBase[$codIdentidad]['dni_manual'] = $dniIdentidad;
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = (string)($_POST['csrf_token'] ?? '');
        if (!hash_equals((string)$_SESSION['csrf_token'], $token)) {
            $errorLocal = 'La sesión expiró. Actualice la página.';
        } elseif (isset($_POST['quitar_codigo'])) {
            $codigoQuitar = trim((string)$_POST['quitar_codigo']);
            if ($codigoQuitar === '' || !isset($vendedoresBase[$codigoQuitar])) {
                $errorLocal = 'No se pudo identificar el vendedor que desea quitar.';
            } else {
                $stmtOcultar = $conn->prepare(
                    "INSERT INTO dias_trabajados_vendedores_ocultos
                        (usuario_id, tienda, codvendedor)
                     VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE fecha_quitado = CURRENT_TIMESTAMP"
                );
                if (!$stmtOcultar) {
                    $errorLocal = 'No se pudo preparar el guardado del vendedor quitado.';
                } else {
                    $stmtOcultar->bind_param('iss', $usuarioId, $codigoSeleccionado, $codigoQuitar);
                    if (!$stmtOcultar->execute()) {
                        $errorLocal = 'No se pudo guardar el vendedor quitado.';
                    } else {
                        $stmtOcultar->close();
                        $pp = (int)($_POST['per_page'] ?? 100);
                        if (!in_array($pp, [100, 200, 500], true)) $pp = 100;
                        $pg = max(1, (int)($_POST['pagina'] ?? 1));
                        header(
                            'Location: ' . $baseUrl
                            . '/vendedores/dias_trabajados.php?tienda=' . rawurlencode($codigoSeleccionado)
                            . '&semana=' . rawurlencode($claveSemanaSeleccionada)
                            . '&pagina=' . $pg
                            . '&per_page=' . $pp
                            . '&info=quitado'
                        );
                        exit();
                    }
                    if ($stmtOcultar instanceof mysqli_stmt) {
                        $stmtOcultar->close();
                    }
                }
            }
        } elseif (isset($_POST['mostrar_todos'])) {
            $stmtRestaurar = $conn->prepare(
                "DELETE FROM dias_trabajados_vendedores_ocultos
                 WHERE tienda = ?"
            );
            if (!$stmtRestaurar) {
                $errorLocal = 'No se pudo preparar la restauración de vendedores.';
            } else {
                $stmtRestaurar->bind_param('s', $codigoSeleccionado);
                if (!$stmtRestaurar->execute()) {
                    $errorLocal = 'No se pudieron restaurar los vendedores quitados.';
                } else {
                    $stmtRestaurar->close();
                    $pp = (int)($_POST['per_page'] ?? 100);
                    if (!in_array($pp, [100, 200, 500], true)) $pp = 100;
                    $pg = max(1, (int)($_POST['pagina'] ?? 1));
                    header(
                        'Location: ' . $baseUrl
                        . '/vendedores/dias_trabajados.php?tienda=' . rawurlencode($codigoSeleccionado)
                        . '&semana=' . rawurlencode($claveSemanaSeleccionada)
                        . '&pagina=' . $pg
                        . '&per_page=' . $pp
                        . '&info=restaurados'
                    );
                    exit();
                }
                if ($stmtRestaurar instanceof mysqli_stmt) {
                    $stmtRestaurar->close();
                }
            }
        } elseif (isset($_POST['agregar_busqueda'])) {
            $busqueda = trim((string)($_POST['agregar_busqueda'] ?? ''));
            $coincidencias = dias_buscar_vendedores_en_tienda($vendedoresBase, $busqueda);
            if ($busqueda === '') {
                $errorLocal = 'Escriba el DNI, código o nombre del vendedor.';
            } elseif (empty($coincidencias)) {
                $errorLocal = 'No se encontró un vendedor de esta tienda con ese DNI, código o nombre.';
            } elseif (count($coincidencias) > 1) {
                $errorLocal = 'Hay varios vendedores con ese nombre. Escriba el nombre más completo, el código o el DNI.';
            } else {
                $codigoAgregar = (string)array_key_first($coincidencias);
                $stmtAgregar = $conn->prepare(
                    "DELETE FROM dias_trabajados_vendedores_ocultos
                     WHERE tienda = ? AND codvendedor = ?"
                );
                if (!$stmtAgregar) {
                    $errorLocal = 'No se pudo preparar la restauración del vendedor.';
                } else {
                    $stmtAgregar->bind_param('ss', $codigoSeleccionado, $codigoAgregar);
                    if (!$stmtAgregar->execute()) {
                        $errorLocal = 'No se pudo agregar nuevamente el vendedor.';
                    } else {
                        $stmtAgregar->close();
                        $pp = (int)($_POST['per_page'] ?? 100);
                        if (!in_array($pp, [100, 200, 500], true)) $pp = 100;
                        $pg = max(1, (int)($_POST['pagina'] ?? 1));
                        header(
                            'Location: ' . $baseUrl
                            . '/vendedores/dias_trabajados.php?tienda=' . rawurlencode($codigoSeleccionado)
                            . '&semana=' . rawurlencode($claveSemanaSeleccionada)
                            . '&pagina=' . $pg
                            . '&per_page=' . $pp
                            . '&info=agregado'
                        );
                        exit();
                    }
                    if ($stmtAgregar instanceof mysqli_stmt) {
                        $stmtAgregar->close();
                    }
                }
            }
        }
    }
    $vendedores = $vendedoresBase;
    /*
    | VENDEDORES OCULTOS PERSISTENTES (MYSQL) CUANDO SE LE DA OCULTAR A LOS VENDEDORES
    */
    $stmtOcultos = $conn->prepare(
        "SELECT DISTINCT codvendedor
         FROM dias_trabajados_vendedores_ocultos
         WHERE tienda = ?"
    );
    if (!$stmtOcultos) {
        $errorLocal = $errorLocal !== ''
            ? $errorLocal
            : 'No se pudo consultar la lista de vendedores quitados.';
    } else {
        $stmtOcultos->bind_param('s', $codigoSeleccionado);
        if (!$stmtOcultos->execute()) {
            $errorLocal = $errorLocal !== ''
                ? $errorLocal
                : 'No se pudo consultar la lista de vendedores quitados.';
        } else {
            $stmtOcultos->bind_result($codigoOcultoDb);
            while ($stmtOcultos->fetch()) {
                $codigoOculto = trim((string)$codigoOcultoDb);
                if ($codigoOculto !== '') {
                    $codigosOcultos[$codigoOculto] = true;
                    unset($vendedores[$codigoOculto]);
                }
            }
        }
        $stmtOcultos->close();
    }
    $registrosMes = dias_obtener_registrados_mes(
        $sqlsrv_conn_exhibicion ?? false,
        $codigoSeleccionado,
        $semanasMes
    );
}
$totalOcultos = count($codigosOcultos);
/*
BUSCADOR SERVIDOR
Enter hace búsqueda completa. JS además filtra instantáneamente la página.
*/
$buscar = trim((string)($_GET['q'] ?? ''));
$vendedoresFiltrados = $vendedores;
if ($buscar !== '') {
    $textoBuscar = dias_normalizar_busqueda($buscar);
    $dniBuscar = dias_normalizar_dni($buscar);
    $vendedoresFiltrados = array_filter(
        $vendedores,
        static function (array $vendedor, string $codigo) use ($buscar, $textoBuscar, $dniBuscar): bool {
            $nombre = dias_normalizar_busqueda((string)($vendedor['nombre'] ?? ''));
            $dni = dias_normalizar_dni((string)($vendedor['dni'] ?? ''));
            if ($dni === '') $dni = dias_normalizar_dni((string)($vendedor['dni_manual'] ?? ''));
            $codigoNorm = dias_normalizar_busqueda($codigo);
            $buscarCodigo = dias_normalizar_busqueda($buscar);
            return ($textoBuscar !== '' && $nombre !== '' && str_contains($nombre, $textoBuscar))
                || ($dniBuscar !== '' && $dni !== '' && str_contains($dni, $dniBuscar))
                || ($buscarCodigo !== '' && $codigoNorm !== '' && str_contains($codigoNorm, $buscarCodigo));
        },
        ARRAY_FILTER_USE_BOTH
    );
}
/*
PAGINACIÓN
*/
$opcionesPermitidas = [100, 200, 500];
$perPage = (int)($_GET['per_page'] ?? 100);
if (!in_array($perPage, $opcionesPermitidas, true)) {
    $perPage = 100;
}
$totalVendedores = count($vendedoresFiltrados);
$totalVendedoresTienda = count($vendedores);
$totalPaginas = max(1, (int)ceil($totalVendedores / $perPage));
$pagina = max(1, (int)($_GET['pagina'] ?? 1));
if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}
$offset = ($pagina - 1) * $perPage;
$vendedoresPagina = array_slice($vendedoresFiltrados, $offset, $perPage, true);
$desde = $totalVendedores > 0 ? $offset + 1 : 0;
$hasta = min($offset + $perPage, $totalVendedores);
$esGerenteTienda = $rol === 'gerente_tienda';
if (!function_exists('dias_formatear_decimal')) {
    function dias_formatear_decimal(float $valor): string
    {
        return rtrim(
            rtrim(
                number_format($valor, 2, '.', ''),
                '0'
            ),
            '.'
        );
    }
}
function dias_url_pagina(
    string $baseUrl,
    string $tienda,
    string $semana,
    int $pagina,
    int $perPage,
    string $buscar = ''
): string {
    $url = $baseUrl
        . '/vendedores/dias_trabajados.php?tienda=' . rawurlencode($tienda)
        . '&semana=' . rawurlencode($semana)
        . '&pagina=' . $pagina
        . '&per_page=' . $perPage;
    if ($buscar !== '') {
        $url .= '&q=' . rawurlencode($buscar);
    }
    return $url;
}
/*
 HISTORIAL - SOLO LECTURA
*/
$historialSemanas = [];
$historialSeleccionado = trim((string)($_GET['hist'] ?? ''));
$historialRegistros = [];
$historialInfo = null;
$anioActualRetail = $anioVista;
$semanaActualRetail = 0;
foreach ($semanasMes as $semanaActualInfo) {
    if ($hoy >= $semanaActualInfo['fecha_inicio'] && $hoy <= $semanaActualInfo['fecha_fin']) {
        $anioActualRetail = (int)$semanaActualInfo['anio'];
        $semanaActualRetail = (int)$semanaActualInfo['semana'];
        break;
    }
}
if (!function_exists('dias_fechas_semana_retail')) {
    function dias_fechas_semana_retail(int $anio, int $numeroSemana): ?array
    {
        for ($mes = 1; $mes <= 12; $mes++) {
            foreach (retail_obtener_semanas_mes($anio, $mes) as $semana) {
                if ((int)($semana['anio'] ?? 0) === $anio && (int)($semana['semana'] ?? 0) === $numeroSemana) {
                    return [
                        'fecha_inicio' => $semana['fecha_inicio'],
                        'fecha_fin' => $semana['fecha_fin'],
                    ];
                }
            }
        }
        return null;
    }
}
if ($tiendaSeleccionada && isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion !== false) {
    $sqlHistorialSemanas = "
        SELECT TOP 52 H.ANIO, H.SEMANA
        FROM (
            SELECT DISTINCT ANIO, SEMANA
            FROM [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]
            WHERE TIENDA = ?
        ) H
        ORDER BY H.ANIO DESC, H.SEMANA DESC
    ";
    $stmtHistorial = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlHistorialSemanas, [$codigoSeleccionado]);
    if ($stmtHistorial !== false) {
        while ($filaHistorial = sqlsrv_fetch_array($stmtHistorial, SQLSRV_FETCH_ASSOC)) {
            $histAnio = (int)($filaHistorial['ANIO'] ?? 0);
            $histSemana = (int)($filaHistorial['SEMANA'] ?? 0);
            if ($histAnio <= 0 || $histSemana <= 0) continue;
            if (
                $semanaActualRetail > 0
                && (
                    $histAnio > $anioActualRetail
                    || ($histAnio === $anioActualRetail && $histSemana > $semanaActualRetail)
                )
            ) {
                continue;
            }
            $claveHistorial = $histAnio . '-' . $histSemana;
            $fechasHistorial = dias_fechas_semana_retail($histAnio, $histSemana);
            $historialSemanas[$claveHistorial] = [
                'anio' => $histAnio,
                'semana' => $histSemana,
                'fecha_inicio' => $fechasHistorial['fecha_inicio'] ?? null,
                'fecha_fin' => $fechasHistorial['fecha_fin'] ?? null,
            ];
        }
        sqlsrv_free_stmt($stmtHistorial);
    }
}
if ($historialSeleccionado !== '' && isset($historialSemanas[$historialSeleccionado])) {
    $historialInfo = $historialSemanas[$historialSeleccionado];
    $histAnio = (int)$historialInfo['anio'];
    $histSemana = (int)$historialInfo['semana'];
    $vendedoresPorDni = [];
    foreach ($vendedoresBase as $codigoVendedorHist => $vendedorHist) {
        $dniHist = dias_normalizar_dni((string)($vendedorHist['dni'] ?? ''));
        if ($dniHist === '') $dniHist = dias_normalizar_dni((string)($vendedorHist['dni_manual'] ?? ''));
        if ($dniHist !== '' && !isset($vendedoresPorDni[$dniHist])) {
            $vendedoresPorDni[$dniHist] = [
                'codigo' => (string)$codigoVendedorHist,
                'nombre' => (string)($vendedorHist['nombre'] ?? 'Vendedor'),
            ];
        }
    }
    $sqlHistorialDatos = "
        SELECT DNI, DIAS_TRABAJADOS
        FROM [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]
        WHERE TIENDA = ? AND ANIO = ? AND SEMANA = ?
        ORDER BY DNI ASC
    ";
    $stmtHistorialDatos = sqlsrv_query(
        $sqlsrv_conn_exhibicion,
        $sqlHistorialDatos,
        [$codigoSeleccionado, $histAnio, $histSemana]
    );
    if ($stmtHistorialDatos !== false) {
        while ($filaHistorica = sqlsrv_fetch_array($stmtHistorialDatos, SQLSRV_FETCH_ASSOC)) {
            $dniHistorico = dias_normalizar_dni((string)($filaHistorica['DNI'] ?? ''));
            $vendedorHistorico = $vendedoresPorDni[$dniHistorico] ?? null;
            $historialRegistros[] = [
                'dni' => $dniHistorico,
                'dias' => (float)($filaHistorica['DIAS_TRABAJADOS'] ?? 0),
                'codigo' => $vendedorHistorico['codigo'] ?? '—',
                'nombre' => $vendedorHistorico['nombre'] ?? 'Vendedor histórico',
            ];
        }
        sqlsrv_free_stmt($stmtHistorialDatos);
    }
}
require_once dirname(__DIR__) . '/layout_menu.php';
?>
<link rel="stylesheet" href="<?= retail_h((string)$baseUrl) ?>/vendedores/dias_trabajados.css?v=<?= time() ?>" >
<main class="dt-page">
<div class="dt-container">
    <header class="dt-heading">
        <div class="dt-heading-main">
            <div class="dt-heading-icon">
                <i class="bi bi-calendar2-check"></i>
            </div>
            <div class="dt-heading-text">
                <h1>Días trabajados</h1>
                <p>Registro de jornadas por vendedor y Semana Retail.</p>
            </div>
        </div>
        <div class="dt-heading-period">
            <strong>
                <?= retail_h( retail_mes_nombre($mesVista) ) ?>
                <?= (int)$anioVista ?>
            </strong>
            <span>
                Semana
                <?= (int)$semanaSeleccionada['semana'] ?>
            </span>
        </div>
    </header>
    <?php if (isset($_GET['ok'])): ?>
        <div class="dt-alert success">
            <i class="bi bi-check-circle-fill"></i>
            <span>
                <strong>Guardado correctamente.</strong>
                <?= (int)($_GET['cambios'] ?? 0) ?>
                registro(s) modificado(s).
            </span>
        </div>
    <?php endif; ?>
    <?php if ( ($_GET['info'] ?? '') === 'sin_cambios' ): ?>
        <div class="dt-alert">
            <i class="bi bi-info-circle-fill"></i>
            <span>No hay cambios nuevos para guardar.</span>
        </div>
    <?php elseif ( ($_GET['info'] ?? '') === 'agregado' ): ?>
        <div class="dt-alert success">
            <i class="bi bi-person-check-fill"></i>
            <span>Vendedor agregado nuevamente.</span>
        </div>
    <?php elseif ( ($_GET['info'] ?? '') === 'quitado' ): ?>
        <div class="dt-alert">
            <i class="bi bi-person-dash-fill"></i>
            <span>Vendedor quitado correctamente.</span>
        </div>
    <?php elseif ( ($_GET['info'] ?? '') === 'restaurados' ): ?>
        <div class="dt-alert success">
            <i class="bi bi-arrow-counterclockwise"></i>
            <span>Todos los vendedores fueron restaurados.</span>
        </div>
    <?php endif; ?>
    <?php if ( isset($_GET['error']) || $errorLocal !== '' ): ?>
        <?php
        $mensajeError = $errorLocal !== ''
            ? $errorLocal
            : match (
                (string)($_GET['error'] ?? '')
            ) {
                'csrf' =>
                    'La sesión expiró. Actualice la página.',
                'tienda_invalida' =>
                    'La tienda no está autorizada.',
                'periodo' =>
                    'No se pudo construir el calendario Retail.',
                'dias_invalidos' =>
                    'Los días trabajados deben ser un número de 0 a 7; se permiten decimales.',
                'vendedor_invalido' =>
                    'El vendedor no pertenece a la tienda.',
                'identidad_requerida' =>
                    'Debe ingresar la identidad del vendedor.',
                'identidad_invalida' =>
                    'La identidad ingresada no es válida.',
                'identidad_duplicada' =>
                    'La identidad ya pertenece a otro vendedor.',
                'dni_conflicto' =>
                    'Dos vendedores intentan usar la misma identidad en la misma semana.',
                'semana_invalida' =>
                    'La Semana Retail recibida no es válida.',
                'guardar' =>
                    'Ocurrió un error al guardar.',
                default =>
                    'Ocurrió un error al procesar la solicitud.'
            };
        ?>
        <div class="dt-alert danger">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <span>
                <?= retail_h( (string)$mensajeError ) ?>
            </span>
        </div>
    <?php endif; ?>
    <?php if (empty($tiendas)): ?>
        <section class="dt-panel">
            <div class="dt-empty">
                <i class="bi bi-shop"></i>
                <strong>Sin tiendas disponibles</strong>
                <span>
                    No se encontraron tiendas asociadas
                    a su usuario.
                </span>
            </div>
        </section>
    <?php else: ?>
        <?php if ( $tiendaSeleccionada && $semanaSeleccionada ): ?>
            <!-- BARRA DE FILTROS
               -->
            <section class="dt-panel dt-toolbar">
                <!-- TIENDA -->
                <?php if ( in_array( $rol, [ 'administrador', 'gerente_comercial' ], true ) ): ?>
                    <form method="get">
                        <div class="dt-field">
                            <label for="tienda">Tienda</label>
                            <select name="tienda" id="tienda" class="dt-control" onchange="this.form.submit()" >
                                <?php foreach ( $tiendas as $codigo => $tiendaItem ): ?>
                                    <option value="<?= retail_h( (string)$codigo ) ?>" <?= (string)$codigo === $codigoSeleccionado ? 'selected' : '' ?> >
                                        <?= retail_h( (string)$codigo . ' - ' . (string)$tiendaItem['nombre'] ) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="dt-field">
                        <label>Tienda</label>
                        <div class="dt-control" style=" display:flex; align-items:center; " >
                            <?= retail_h( (string)$codigoSeleccionado . ' - ' . (string)$tiendaSeleccionada['nombre'] ) ?>
                        </div>
                    </div>
                <?php endif; ?>
                <!--
                     SEMANA
                 -->
                <form method="get">
                    <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                    <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                    <?php if ($buscar !== ''): ?>
                        <input type="hidden" name="q" value="<?= retail_h($buscar) ?>" >
                    <?php endif; ?>
                    <div class="dt-field">
                        <label for="semana">Semana Retail</label>
                        <select name="semana" id="semana" class="dt-control" onchange="this.form.submit()" >
                            <?php foreach ( $semanasDisponibles as $claveSemana => $semana ): ?>
                                <?php
                                $esActual =
                                    $claveSemana
                                    === $claveSemanaActual;
                                ?>
                                <option value="<?= retail_h( $claveSemana ) ?>" <?= $claveSemana === $claveSemanaSeleccionada ? 'selected' : '' ?> >
                                    Semana
                                    <?= (int)$semana['semana'] ?>
                                    ·
                                    <?= retail_h( $semana['fecha_inicio'] ->format('d/m/Y') ) ?>
                                    al
                                    <?= retail_h( $semana['fecha_fin'] ->format('d/m/Y') ) ?>
                                    <?= $esActual ? ' · Actual' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
                <!--
                     BUSCAR
                 -->
                <form method="get" id="sellerSearchForm" autocomplete="off" >
                    <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                    <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                    <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                    <div class="dt-field">
                        <label for="sellerSearch">Buscar vendedor</label>
                        <div class="dt-search">
                            <i class="bi bi-search"></i>
                            <input type="search" name="q" id="sellerSearch" class="dt-control" value="<?= retail_h($buscar) ?>" placeholder="Nombre, DNI o código..." autocomplete="off" >
                        </div>
                    </div>
                </form>
                <!--MOSTRAR
                   -->
                <form method="get">
                    <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                    <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                    <?php if ($buscar !== ''): ?>
                        <input type="hidden" name="q" value="<?= retail_h($buscar) ?>" >
                    <?php endif; ?>
                    <div class="dt-field">
                        <label for="per_page">Mostrar</label>
                        <select name="per_page" id="per_page" class="dt-control" onchange="this.form.submit()" >
                            <?php foreach ( $opcionesPermitidas as $opcion ): ?>
                                <option value="<?= (int)$opcion ?>" <?= $opcion === $perPage ? 'selected' : '' ?> >
                                    <?= (int)$opcion ?>
                                    vendedores
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
                <!-- ADMINISTRAR
                     -->
                <details class="dt-manage" <?= $errorLocal !== '' ? 'open' : '' ?> >
                    <summary class="dt-btn dt-btn-light" >
                        <i class="bi bi-people"></i>
                        Administrar vendedores
                    </summary>
                    <div class="dt-manage-panel">
                        <div class="dt-manage-title">
                            <strong>Administrar vendedores</strong>
                            <span>Agregue nuevamente vendedores quitados.</span>
                        </div>
                        <form method="post" autocomplete="off" >
                            <input type="hidden" name="csrf_token" value="<?= retail_h( (string)$_SESSION['csrf_token'] ) ?>" >
                            <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                            <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                            <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                            <input type="hidden" name="pagina" value="<?= (int)$pagina ?>" >
                            <div class="dt-add-row">
                                <input type="text" name="agregar_busqueda" maxlength="80" placeholder="DNI, nombre o código" required >
                                <button type="submit" class="dt-btn dt-btn-primary" >
                                    <i class="bi bi-plus-lg"></i>
                                    Agregar
                                </button>
                            </div>
                        </form>
                        <?php if ( $totalOcultos > 0 ): ?>
                            <form method="post" class="dt-restore" >
                                <input type="hidden" name="csrf_token" value="<?= retail_h( (string)$_SESSION['csrf_token'] ) ?>" >
                                <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                                <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                                <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                                <input type="hidden" name="pagina" value="<?= (int)$pagina ?>" >
                                <button type="submit" name="mostrar_todos" value="1" class="dt-btn dt-btn-light" >
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                    Restaurar
                                    <?= (int)$totalOcultos ?>
                                    vendedor(es)
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </details>
            </section>
            <!-- =================================================
                 INFORMACIÓN COMPACTA
                 ================================================= -->
            <div class="dt-info-line">
                <div class="dt-info-chip">
                    <i class="bi bi-people"></i>
                    <strong>
                        <?= (int)$totalVendedores ?>
                    </strong>
                    vendedores
                </div>
                <div class="dt-info-chip">
                    <i class="bi bi-calendar-week"></i>
                    Semana
                    <strong>
                        <?= (int)$semanaSeleccionada['semana'] ?>
                    </strong>
                </div>
                <div class="dt-info-chip">
                    <i class="bi bi-clock-history"></i>
                    <?= retail_h( $semanaSeleccionada['fecha_inicio'] ->format('d/m/Y') ) ?>
                    al
                    <?= retail_h( $semanaSeleccionada['fecha_fin'] ->format('d/m/Y') ) ?>
                </div>
            </div>
            <!--
                 VENDEDORES
                -->
            <section class="dt-panel dt-workspace">
                <!-- ENCABEZADOS -->
                <div class="dt-list-head">
                    <div>Vendedor</div>
                    <div>Código</div>
                    <div>DNI / Identidad</div>
                    <div class="dt-center">Días actuales</div>
                    <div class="dt-center">Nuevo</div>
                    <div class="dt-center">Quitar</div>
                </div>
                <?php if ( empty($vendedoresPagina) ): ?>
                    <div class="dt-empty">
                        <i class="bi bi-search"></i>
                        <strong>Sin resultados</strong>
                        <span>
                            No existen vendedores que coincidan
                            con la búsqueda.
                        </span>
                    </div>
                <?php else: ?>
                    <form method="post" action="<?= retail_h( (string)$baseUrl ) ?>/vendedores/guardar_dias.php" id="formDias" autocomplete="off" >
                        <input type="hidden" name="csrf_token" value="<?= retail_h( (string)$_SESSION['csrf_token'] ) ?>" >
                        <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                        <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                        <input type="hidden" name="pagina" value="<?= (int)$pagina ?>" >
                        <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                        <input type="hidden" name="q" value="<?= retail_h($buscar) ?>" >
                        <input type="hidden" name="registro" id="registroVolver" value="" >
                        <div class="dt-sellers" id="sellerList" >
                            <?php foreach ( $vendedoresPagina as $codVendedor => $vendedor ): ?>
                                <?php
                                $dniBase = dias_normalizar_dni((string)($vendedor['dni'] ?? ''));
                                $dniManualGuardado = dias_normalizar_dni((string)($vendedor['dni_manual'] ?? ''));
                                $dni = $dniBase !== '' ? $dniBase : $dniManualGuardado;
                                $sinDni = $dniBase === '';
                                $actual = (
                                    $dni !== ''
                                    && isset(
                                        $registrosMes[
                                            $claveSemanaSeleccionada
                                        ]
                                    )
                                    && array_key_exists(
                                        $dni,
                                        $registrosMes[
                                            $claveSemanaSeleccionada
                                        ]
                                    )
                                )
                                    ? (float)$registrosMes[
                                        $claveSemanaSeleccionada
                                    ][$dni]
                                    : null;
                                $nombreVendedor =
                                    trim(
                                        (string)(
                                            $vendedor['nombre']
                                            ?? ''
                                        )
                                    );
                                $partesNombre =
                                    preg_split(
                                        '/\s+/',
                                        $nombreVendedor
                                    );
                                $iniciales = '';
                                if (
                                    is_array($partesNombre)
                                    && isset($partesNombre[0])
                                ) {
                                    $iniciales .=
                                        mb_substr(
                                            $partesNombre[0],
                                            0,
                                            1,
                                            'UTF-8'
                                        );
                                }
                                if (
                                    is_array($partesNombre)
                                    && isset($partesNombre[1])
                                ) {
                                    $iniciales .=
                                        mb_substr(
                                            $partesNombre[1],
                                            0,
                                            1,
                                            'UTF-8'
                                        );
                                }
                                $iniciales =
                                    mb_strtoupper(
                                        $iniciales,
                                        'UTF-8'
                                    );
                                $textoFila =
                                    dias_normalizar_busqueda(
                                        (string)$codVendedor
                                        . ' '
                                        . $dni
                                        . ' '
                                        . $nombreVendedor
                                    );
                                ?>
                                <article id="vendedor-<?= retail_h((string)$codVendedor) ?>" class="dt-seller-row seller-row" data-codigo="<?= retail_h((string)$codVendedor) ?>" data-search="<?= retail_h($textoFila) ?>" >
                                    <!-- VENDEDOR -->
                                    <div class="dt-seller-person">
                                        <div class="dt-avatar">
                                            <?= retail_h( $iniciales !== '' ? $iniciales : '?' ) ?>
                                        </div>
                                        <div class="dt-seller-name">
                                            <strong>
                                                <?= retail_h( $nombreVendedor ) ?>
                                            </strong>
                                            <span>Vendedor de tienda</span>
                                        </div>
                                    </div>
                                    <!-- CÓDIGO -->
                                    <div class="dt-code">
                                        <?= retail_h( (string)$codVendedor ) ?>
                                    </div>
                                    <!-- IDENTIDAD -->
                                    <div>
                                        <?php if (!$sinDni): ?>
                                            <div class="dt-dni">
                                                <i class="bi bi-file-earmark-person"></i>
                                                <span>
                                                    <?= retail_h( $dni ) ?>
                                                </span>
                                            </div>
                                        <?php else: ?>
                                            <input type="text" class="dt-dni-input" name="identidad_manual[<?= retail_h((string)$codVendedor) ?>]" value="<?= retail_h($dniManualGuardado) ?>" data-original="<?= retail_h($dniManualGuardado) ?>" data-codigo="<?= retail_h((string)$codVendedor) ?>" maxlength="20" minlength="5" pattern="[A-Za-z0-9]{5,20}" title="Solo letras y números, de 5 a 20 caracteres." inputmode="text" placeholder="Ingresar identidad" autocomplete="off" autocapitalize="characters" spellcheck="false">
                                        <?php endif; ?>
                                    </div>
                                    <!-- ACTUAL -->
                                    <div class="dt-center">
                                        <span class="dt-current">
                                            <?= $actual !== null ? retail_h( dias_formatear_decimal( (float)$actual ) ) : '—' ?>
                                        </span>
                                    </div>
                                    <!-- NUEVO -->
                                    <div class="dt-center">
                                        <input class="dt-day-input" type="number" min="0" max="7" step="0.01" inputmode="decimal" data-codigo="<?= retail_h((string)$codVendedor) ?>" name="dias[<?= retail_h( $claveSemanaSeleccionada ) ?>][<?= retail_h( (string)$codVendedor ) ?>]" placeholder="—" aria-label="Días trabajados" >
                                    </div>
                                    <!-- QUITAR -->
                                    <div class="dt-center">
                                        <button type="submit" name="quitar_codigo" value="<?= retail_h( (string)$codVendedor ) ?>" formaction="<?= retail_h( (string)$baseUrl ) ?>/vendedores/dias_trabajados.php?tienda=<?= rawurlencode( $codigoSeleccionado ) ?>&semana=<?= rawurlencode( $claveSemanaSeleccionada ) ?>" formmethod="post" class="dt-remove" title="Quitar vendedor" >
                                            <i class="bi bi-trash3"></i>
                                        </button>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                        <div class="dt-empty" id="liveEmpty" hidden >
                            <i class="bi bi-search"></i>
                            <strong>Sin coincidencias</strong>
                            <span>
                                No existen coincidencias
                                en esta página.
                            </span>
                        </div>
                    </form>
                <?php endif; ?>
                <!-- =================================================
                     PIE / PAGINACIÓN
                     ================================================= -->
                <div class="dt-list-footer">
                    <span>
                        Mostrando
                        <strong>
                            <?= (int)$desde ?>
                        </strong>
                        a
                        <strong>
                            <?= (int)$hasta ?>
                        </strong>
                        de
                        <strong>
                            <?= (int)$totalVendedores ?>
                        </strong>
                        vendedores
                    </span>
                    <?php if ($totalPaginas > 1): ?>
                        <nav class="dt-pagination" aria-label="Paginación vendedores" >
                            <a class="<?= $pagina <= 1 ? 'disabled' : '' ?>" href="<?= $pagina > 1 ? retail_h( dias_url_pagina( $baseUrl, $codigoSeleccionado, $claveSemanaSeleccionada, $pagina - 1, $perPage, $buscar ) ) : '#' ?>" >
                                <i class="bi bi-chevron-left"></i>
                            </a>
                            <?php
                            $inicioPag =
                                max(
                                    1,
                                    $pagina - 2
                                );
                            $finPag =
                                min(
                                    $totalPaginas,
                                    $pagina + 2
                                );
                            ?>
                            <?php for ( $p = $inicioPag; $p <= $finPag; $p++ ): ?>
                                <a class="<?= $p === $pagina ? 'active' : '' ?>" href="<?= retail_h( dias_url_pagina( $baseUrl, $codigoSeleccionado, $claveSemanaSeleccionada, $p, $perPage, $buscar ) ) ?>" >
                                    <?= (int)$p ?>
                                </a>
                            <?php endfor; ?>
                            <a class="<?= $pagina >= $totalPaginas ? 'disabled' : '' ?>" href="<?= $pagina < $totalPaginas ? retail_h( dias_url_pagina( $baseUrl, $codigoSeleccionado, $claveSemanaSeleccionada, $pagina + 1, $perPage, $buscar ) ) : '#' ?>" >
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </nav>
                    <?php endif; ?>
                </div>
            </section>
            <!--
                 HISTORIAL
            -->
            <details class="dt-history" <?= $historialSeleccionado !== '' ? 'open' : '' ?> >
                <summary>
                    <div class="dt-history-heading">
                        <div class="dt-history-icon">
                            <i class="bi bi-clock-history"></i>
                        </div>
                        <div>
                            <strong>Semanas anteriores</strong>
                            <span>Consulte registros de semanas previas.</span>
                        </div>
                    </div>
                    <i class="bi bi-chevron-down"></i>
                </summary>
                <div class="dt-history-body">
                    <?php if ( empty($historialSemanas) ): ?>
                        <div class="dt-empty">
                            <i class="bi bi-clock"></i>
                            <strong>Sin historial</strong>
                            <span>
                                No existen semanas anteriores
                                guardadas para esta tienda.
                            </span>
                        </div>
                    <?php else: ?>
                        <form method="get" class="dt-history-select" >
                            <input type="hidden" name="tienda" value="<?= retail_h( (string)$codigoSeleccionado ) ?>" >
                            <input type="hidden" name="semana" value="<?= retail_h( $claveSemanaSeleccionada ) ?>" >
                            <input type="hidden" name="per_page" value="<?= (int)$perPage ?>" >
                            <div class="dt-field">
                                <label for="hist">Consultar semana</label>
                                <select name="hist" id="hist" class="dt-control" onchange="this.form.submit()" >
                                    <option value="">Seleccione...</option>
                                    <?php foreach ( $historialSemanas as $claveHist => $semHist ): ?>
                                        <option value="<?= retail_h( $claveHist ) ?>" <?= $historialSeleccionado === $claveHist ? 'selected' : '' ?> >
                                            Semana
                                            <?= (int)$semHist['semana'] ?>
                                            ·
                                            <?= (int)$semHist['anio'] ?>
                                            <?php if ( $semHist['fecha_inicio'] && $semHist['fecha_fin'] ): ?>
                                                ·
                                                <?= retail_h( $semHist['fecha_inicio'] ->format('d/m') ) ?>
                                                al
                                                <?= retail_h( $semHist['fecha_fin'] ->format('d/m') ) ?>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </form>
                        <?php if ($historialInfo): ?>
                            <div class="dt-history-info">
                                <strong>
                                    Semana
                                    <?= (int)$historialInfo['semana'] ?>
                                    ·
                                    <?= (int)$historialInfo['anio'] ?>
                                </strong>
                                <span>
                                    <i class="bi bi-lock"></i>
                                    Solo lectura
                                </span>
                            </div>
                            <?php if ( empty($historialRegistros) ): ?>
                                <div class="dt-empty">
                                    <strong>Sin registros</strong>
                                    <span>
                                        No existen datos guardados
                                        para esta semana.
                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="dt-history-table-wrap">
                                    <table class="dt-history-table">
                                        <thead>
                                            <tr>
                                                <th>Código</th>
                                                <th>Identidad</th>
                                                <th>Vendedor</th>
                                                <th>Días</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ( $historialRegistros as $regHist ): ?>
                                                <tr>
                                                    <td>
                                                        <?= retail_h( (string)$regHist['codigo'] ) ?>
                                                    </td>
                                                    <td>
                                                        <?= retail_h( (string)$regHist['dni'] ) ?>
                                                    </td>
                                                    <td>
                                                        <?= retail_h( (string)$regHist['nombre'] ) ?>
                                                    </td>
                                                    <td>
                                                        <strong>
                                                            <?= retail_h( dias_formatear_decimal( (float)$regHist['dias'] ) ) ?>
                                                        </strong>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </details>
            <!--
                GUARDAR FLOTANTE-->
            <?php if ( !empty($vendedoresPagina) ): ?>
                <div class="dt-floating-save">
                    <div class="dt-floating-info">
                        <i class="bi bi-info-circle-fill"></i>
                        <span>
                            Solo se guardarán los cambios.
                            <strong>Días: 0 a 7</strong>
                        </span>
                    </div>
                    <button type="submit" form="formDias" class="dt-floating-button" >
                        <i class="bi bi-floppy-fill"></i>
                        Guardar cambios
                    </button>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>
</main>
<script>
(() => {
    /*
       BÚSQUEDA EN VIVO
    */
    const searchInput =
        document.getElementById(
            'sellerSearch'
        );
    const rows =
        Array.from(
            document.querySelectorAll(
                '.seller-row'
            )
        );
    const liveEmpty =
        document.getElementById(
            'liveEmpty'
        );
    const normalize =
        value => {
            return String(
                value || ''
            )
                .normalize('NFD')
                .replace(
                    /[\u0300-\u036f]/g,
                    ''
                )
                .toLowerCase()
                .replace(
                    /[^a-z0-9]+/g,
                    ''
                );
        };
    if (
        searchInput
        && rows.length
    ) {
        searchInput.addEventListener(
            'input',
            () => {
                const query =
                    normalize(
                        searchInput.value
                    );
                let visible = 0;
                rows.forEach(
                    row => {
                        const texto =
                            normalize(
                                row.dataset.search
                                || row.textContent
                            );
                        const coincide =
                            query === ''
                            || texto.includes(
                                query
                            );
                        row.hidden =
                            !coincide;
                        if (coincide) {
                            visible++;
                        }
                    }
                );
                if (liveEmpty) {
                    liveEmpty.hidden =
                        visible !== 0;
                }
            }
        );
    }
    /*
       FORMULARIO
       */
    const form =
        document.getElementById(
            'formDias'
        );
    if (!form) {
        return;
    }
    const dayInputs =
        Array.from(
            form.querySelectorAll(
                'input[name^="dias["]'
            )
        );

    // Recordar el último vendedor editado para volver al mismo registro.
    const registroVolver = document.getElementById('registroVolver');
    dayInputs.forEach(input => {
        input.addEventListener('input', () => {
            if (registroVolver && input.dataset.codigo) {
                registroVolver.value = input.dataset.codigo;
            }
        });
    });
    /* =====================================================
       DNI MANUAL: SOLO LETRAS Y NÚMEROS
       ===================================================== */
    const dniInputs =
        Array.from(
            form.querySelectorAll(
                'input[name^="identidad_manual["]'
            )
        );
    dniInputs.forEach(input => {
        input.addEventListener('input', () => {
            input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 20);
            if (registroVolver && input.dataset.codigo) registroVolver.value = input.dataset.codigo;
        });
    });
    /* =====================================================
       DECIMALES ENTRE 1 Y 7
       Ejemplos permitidos: 1, 1.5, 2.25, 6.5, 7
       ===================================================== */
    dayInputs.forEach(
        input => {
            input.addEventListener(
                'input',
                () => {
                    /*
                     * type="number" ya controla gran parte del formato.
                     * Aquí solo impedimos valores fuera del rango.
                     */
                    if (input.value === '') {
                        return;
                    }
                    const valor = Number(input.value);
                    if (!Number.isFinite(valor)) {
                        input.setCustomValidity(
                            'Ingrese un número válido.'
                        );
                        return;
                    }
                    if (valor < 0 || valor > 7) {
                        input.setCustomValidity(
                            'Los días deben estar entre 0 y 7.'
                        );
                    } else {
                        input.setCustomValidity('');
                    }
                }
            );
        }
    );
    /* =====================================================
       VALIDAR GUARDADO
       ===================================================== */
    // Si venimos de guardar, regresar visualmente al mismo vendedor.
    const registroGuardado = new URLSearchParams(window.location.search).get('registro');
    if (registroGuardado) {
        const filaGuardada = Array.from(document.querySelectorAll('.seller-row'))
            .find(row => row.dataset.codigo === registroGuardado);
        if (filaGuardada) {
            requestAnimationFrame(() => {
                filaGuardada.scrollIntoView({behavior: 'instant', block: 'center'});
            });
        }
    }

    form.addEventListener(
        'submit',
        event => {
            /*
             * QUITAR VENDEDOR
             */
            if (
                event.submitter
                && event.submitter.name
                === 'quitar_codigo'
            ) {
                return;
            }
            const llenos =
                dayInputs.filter(
                    input =>
                        input.value.trim()
                        !== ''
                );
            const dniCambiados = dniInputs.filter(input =>
                input.value.trim() !== String(input.dataset.original || '').trim()
            );
            if (llenos.length === 0 && dniCambiados.length === 0) {
                event.preventDefault();
                alert('No hay cambios nuevos para guardar.');
                return;
            }
            if (dniCambiados.some(input => !/^[A-Z0-9]{5,20}$/.test(input.value.trim()))) {
                event.preventDefault();
                const invalido = dniCambiados.find(input => !/^[A-Z0-9]{5,20}$/.test(input.value.trim()));
                if (invalido) invalido.focus();
                alert('La identidad debe tener de 5 a 20 letras o números.');
                return;
            }
            if (
                llenos.some(
                    input => {
                        const valor = Number(input.value);
                        return (
                            !Number.isFinite(valor)
                            || valor < 0
                            || valor > 7
                            || !/^\d+(?:\.\d{1,2})?$/.test(
                                input.value
                            )
                        );
                    }
                )
            ) {
                event.preventDefault();
                alert(
                    'Los días trabajados deben ser un número de 0 a 7. Puede usar hasta 2 decimales, por ejemplo 0, 0.5, 5.5 o 6.25.'
                );
                return;
            }
            /* =================================================
               IDENTIDAD MANUAL
               ================================================= */
            for (
                const input
                of llenos
            ) {
                const match =
                    input.name.match(
                        /^dias\[[^\]]+\]\[([^\]]+)\]$/
                    );
                if (!match) {
                    continue;
                }
                const codigo =
                    match[1];
                const selector =
                    'input[name="identidad_manual['
                    + CSS.escape(codigo)
                    + ']"]';
                const dniManual =
                    form.querySelector(
                        selector
                    );
                if (
                    dniManual
                    && dniManual.value.trim()
                    === ''
                ) {
                    event.preventDefault();
                    dniManual.focus();
                    alert(
                        'Ingrese la identidad del vendedor antes de guardar sus días.'
                    );
                    return;
                }
            }
        }
    );
})();
</script>
<?php
require_once dirname(__DIR__) . '/layout_footer.php';
?>
