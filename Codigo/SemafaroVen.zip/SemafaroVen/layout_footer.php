<?php
/*
|--------------------------------------------------------------------------
| CIERRE DEL LAYOUT PRINCIPAL
|--------------------------------------------------------------------------
*/
?>

        </div>
    </main>

    <footer class="mcc-footer">
        <div class="mcc-footer-inner">
            © 2026 Grupo MCC
        </div>
    </footer>
</div>

<style>
.mcc-footer {
    width: 100%;
    margin-top: 28px;

    border-top: 1px solid #e2e8f0;

    background: #ffffff;
}

.mcc-footer-inner {
    width: 100%;

    padding: 16px 20px;

    color: #64748b;

    font-family:
        "Roboto",
        "Segoe UI",
        Arial,
        sans-serif;

    font-size: 13px;
    font-weight: 500;

    text-align: center;
}
</style>

<script
    src="<?= $baseUrl ?>/js/menu.js?v=<?= time() ?>"
></script>

</body>
</html>
