<?php

declare(strict_types=1);

if (!function_exists('obtener_conexion_auditoria')) {

    function obtener_conexion_auditoria(): mysqli
    {
        static $conexionAuditoria = null;

        if ($conexionAuditoria instanceof mysqli) {
            return $conexionAuditoria;
        }

        /*
        |--------------------------------------------------------------------------
        | REUTILIZAR $conn CUANDO SEA MYSQL
        |--------------------------------------------------------------------------
        */

        global $conn;

        if (isset($conn) && $conn instanceof mysqli) {

            $conn->set_charset('utf8mb4');

            $conexionAuditoria = $conn;

            return $conexionAuditoria;
        }

        /*
        |--------------------------------------------------------------------------
        | CARGAR CONEXIÓN MYSQL EN ALCANCE AISLADO
        |--------------------------------------------------------------------------
        */

        $archivoDb = __DIR__ . '/../user/conexion.php';

        if (!is_file($archivoDb)) {

            throw new RuntimeException(
                'No existe la conexión MySQL: ' . $archivoDb
            );
        }

        $conexionAuditoria = (
            static function (string $archivo): mysqli {

                $conn = null;

                require $archivo;

                if (!($conn instanceof mysqli)) {

                    throw new RuntimeException(
                        'user/conexion.php debe crear una conexión mysqli en $conn.'
                    );
                }

                $conn->set_charset('utf8mb4');

                return $conn;
            }
        )($archivoDb);

        return $conexionAuditoria;
    }
}


if (!function_exists('registrar_auditoria')) {

    function registrar_auditoria(
        string $accion,
        string $detalle
    ): bool {

        $accion = strtoupper(trim($accion));
        $detalle = trim($detalle);

        /*
        |--------------------------------------------------------------------------
        | ACCIONES PERMITIDAS
        |--------------------------------------------------------------------------
        */

        $accionesPermitidas = [

            /*
            |----------------------------------------------------------------------
            | USUARIOS
            |----------------------------------------------------------------------
            */

            'USUARIO_CREADO',
            'USUARIO_EDITADO',
            'USUARIO_BLOQUEADO',
            'USUARIO_DESBLOQUEADO',

            /*
            |----------------------------------------------------------------------
            | META SEMANAL
            |----------------------------------------------------------------------
            */

            'META_SEMANAL_CREADA',
            'META_SEMANAL_ACTUALIZADA',
        ];

        /*
        |--------------------------------------------------------------------------
        | NO REGISTRAR ACCIONES DESCONOCIDAS
        |--------------------------------------------------------------------------
        */

        if (!in_array($accion, $accionesPermitidas, true)) {

            error_log(
                'Acción de auditoría no permitida: ' . $accion
            );

            return false;
        }

        if ($detalle === '') {
            $detalle = 'Cambio realizado correctamente.';
        }

        try {

            $db = obtener_conexion_auditoria();

            /*
            |--------------------------------------------------------------------------
            | USUARIO
            |--------------------------------------------------------------------------
            */

            $usuario = trim(
                (string)(
                    $_SESSION['usuario']
                    ?? 'DESCONOCIDO'
                )
            );

            if ($usuario === '') {
                $usuario = 'DESCONOCIDO';
            }

            /*
            |--------------------------------------------------------------------------
            | NOMBRE COMPLETO
            |--------------------------------------------------------------------------
            */

            $nombreCompleto = trim(
                (string)(
                    $_SESSION['nombre_completo']
                    ?? $_SESSION['nombre']
                    ?? ''
                )
            );

            /*
            |--------------------------------------------------------------------------
            | BUSCAR NOMBRE SI NO ESTÁ EN SESIÓN
            |--------------------------------------------------------------------------
            */

            if (
                $nombreCompleto === '' &&
                $usuario !== 'DESCONOCIDO'
            ) {

                $sqlNombre = "
                    SELECT nombre_completo
                    FROM usuarios
                    WHERE usuario = ?
                    LIMIT 1
                ";

                $stmtNombre = $db->prepare($sqlNombre);

                if ($stmtNombre) {

                    $stmtNombre->bind_param(
                        's',
                        $usuario
                    );

                    if ($stmtNombre->execute()) {

                        $stmtNombre->bind_result(
                            $nombreEncontrado
                        );

                        if ($stmtNombre->fetch()) {

                            $nombreCompleto = trim(
                                (string)$nombreEncontrado
                            );
                        }
                    }

                    $stmtNombre->close();
                }
            }

            if ($nombreCompleto === '') {
                $nombreCompleto = $usuario;
            }

            /*
            |--------------------------------------------------------------------------
            | IP
            |--------------------------------------------------------------------------
            */

            $ip = trim(
                (string)(
                    $_SERVER['REMOTE_ADDR']
                    ?? '-'
                )
            );

            if ($ip === '') {
                $ip = '-';
            }

            /*
            |--------------------------------------------------------------------------
            | INSERTAR AUDITORÍA
            |--------------------------------------------------------------------------
            */

            $sql = "
                INSERT INTO auditoria (
                    usuario,
                    nombre_completo,
                    accion,
                    detalle,
                    ip
                )
                VALUES (?, ?, ?, ?, ?)
            ";

            $stmt = $db->prepare($sql);

            if (!$stmt) {

                throw new RuntimeException(
                    $db->error
                );
            }

            $stmt->bind_param(
                'sssss',
                $usuario,
                $nombreCompleto,
                $accion,
                $detalle,
                $ip
            );

            if (!$stmt->execute()) {

                throw new RuntimeException(
                    $stmt->error
                );
            }

            $stmt->close();

            return true;

        } catch (Throwable $error) {

            error_log(
                'Error al registrar auditoría: '
                . $error->getMessage()
            );

            return false;
        }
    }
}