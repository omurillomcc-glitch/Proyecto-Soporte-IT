<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/user/auth.php';
require_login();
require_once dirname(__DIR__) . '/user/conexion.php';

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

function limpiar($valor): string { return trim((string)$valor); }
function h($valor): string { return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8'); }

/** @return array{tipo:'pdo'|'mysqli',db:PDO|mysqli} */
function detectar_conexion(): array
{
    global $pdo, $conn, $mysqli, $conexion;
    foreach ([$pdo ?? null, $conn ?? null, $mysqli ?? null, $conexion ?? null] as $db) {
        if ($db instanceof PDO) {
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return ['tipo' => 'pdo', 'db' => $db];
        }
        if ($db instanceof mysqli) {
            $db->set_charset('utf8mb4');
            return ['tipo' => 'mysqli', 'db' => $db];
        }
    }
    throw new RuntimeException('No se encontró la conexión MySQL.');
}

/** @param array<int,string|int|float|null> $params */
function db_fetch_all(array $conexionDb, string $sql, array $params = [], string $types = ''): array
{
    if ($conexionDb['tipo'] === 'pdo') {
        $stmt = $conexionDb['db']->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** @var mysqli $db */
    $db = $conexionDb['db'];
    $stmt = $db->prepare($sql);
    if (!$stmt) throw new RuntimeException($db->error);

    if ($params !== []) {
        if ($types === '') $types = str_repeat('s', count($params));
        $args = [$types];
        foreach ($params as $i => $value) $args[] = &$params[$i];
        $stmt->bind_param(...$args);
    }

    if (!$stmt->execute()) throw new RuntimeException($stmt->error);
    $result = $stmt->get_result();
    $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
    return $rows;
}

/** @param array<int,string|int|float|null> $params */
function db_fetch_value(array $conexionDb, string $sql, array $params = [], string $types = '')
{
    $rows = db_fetch_all($conexionDb, $sql, $params, $types);
    return $rows === [] ? null : (array_values($rows[0])[0] ?? null);
}

function fecha_legible(string $fecha): string
{
    $t = strtotime($fecha);
    return $t ? date('d/m/Y H:i:s', $t) : $fecha;
}

function url_pagina(int $pagina): string
{
    $query = $_GET;
    $query['pagina'] = $pagina;
    return '?' . http_build_query($query);
}

/** @return array{clase:string,corto:string,largo:string} */
function datos_accion(string $accion): array
{
    $accionNormalizada = strtoupper(limpiar($accion));

    return match ($accionNormalizada) {
        'CREATE', 'CREAR', 'USUARIO_CREADO', 'USUARIO_AGREGADO' => [
            'clase' => 'create',
            'corto' => 'AGREGADO',
            'largo' => 'Usuario agregado',
        ],

        'EDIT', 'EDITAR', 'USUARIO_EDITADO', 'USUARIO_ACTUALIZADO' => [
            'clase' => 'edit',
            'corto' => 'EDITADO',
            'largo' => 'Usuario editado',
        ],

        'BLOCK', 'BLOQUEAR', 'USUARIO_BLOQUEADO' => [
            'clase' => 'block',
            'corto' => 'BLOQUEADO',
            'largo' => 'Usuario bloqueado',
        ],

        'UNLOCK', 'DESBLOQUEAR', 'USUARIO_DESBLOQUEADO' => [
            'clase' => 'unlock',
            'corto' => 'DESBLOQUEADO',
            'largo' => 'Usuario desbloqueado',
        ],

        'META_SEMANAL_CREADA', 'METACREADA' => [
            'clase' => 'metacreada',
            'corto' => 'META CREADA',
            'largo' => 'Meta semanal creada',
        ],

        'META_SEMANAL_ACTUALIZADA', 'METACTUALIZADA', 'METAACTUALIZADA' => [
            'clase' => 'metaactualizada',
            'corto' => 'META ACTUALIZADA',
            'largo' => 'Meta semanal actualizada',
        ],

        'DIAS_TRABAJADOS_CREADO', 'DIAS_TRABAJADOS_CREADOS', 'DIASCREADO' => [
            'clase' => 'diascreado',
            'corto' => 'DIAS CREADO',
            'largo' => 'Los días trabajados se crearon correctamente',
        ],

        'DIAS_TRABAJADOS_ACTUALIZADO', 'DIAS_TRABAJADOS_ACTUALIZADOS', 'DIASACTUALIZADO', 'DIASCTUALIZADO' => [
            'clase' => 'diasactualizado',
            'corto' => 'DIAS ACTUALIZADO',
            'largo' => 'Los días trabajados se actualizaron correctamente',
        ],

        default => [
            'clase' => 'info',
            'corto' => str_replace('_', ' ', $accionNormalizada !== '' ? $accionNormalizada : 'EVENTO'),
            'largo' => str_replace('_', ' ', $accionNormalizada !== '' ? $accionNormalizada : 'Evento'),
        ],
    };
}

function modulo_accion(string $accion): string
{
    $accionNormalizada = strtoupper(limpiar($accion));

    if (str_starts_with($accionNormalizada, 'META_SEMANAL_') || in_array($accionNormalizada, ['METACREADA', 'METACTUALIZADA', 'METAACTUALIZADA'], true)) {
        return 'Meta Semanal';
    }
    if (str_starts_with($accionNormalizada, 'DIAS_TRABAJADOS') || in_array($accionNormalizada, ['DIASCREADO', 'DIASACTUALIZADO', 'DIASCTUALIZADO'], true)) {
        return 'Dias trabajados';
    }

    return 'Usuarios';
}

function icono_accion_svg(string $clase): string
{
    return match ($clase) {
        'create' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 19a6 6 0 0 0-12 0"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/></svg>',
        'edit' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>',
        'block' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><path d="M9 15h6"/></svg>',
        'unlock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2"/><path d="M12 14v3"/></svg>',
        'metacreada', 'metaactualizada', 'diascreado', 'diasactualizado' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
        default => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
    };
}

function iniciales(string $nombre, string $usuario): string
{
    $texto = trim($nombre) !== '' ? trim($nombre) : trim($usuario);
    if ($texto === '') return 'U';
    $partes = preg_split('/\s+/u', $texto) ?: [];
    $ini = '';
    foreach (array_slice($partes, 0, 2) as $p) {
        $ini .= function_exists('mb_substr') ? mb_substr($p, 0, 1, 'UTF-8') : substr($p, 0, 1);
    }
    return strtoupper($ini ?: 'U');
}

/** @return array{afectado:string,resultado:string,cambios:array<int,array{campo:string,anterior:string,nuevo:string}>} */
function interpretar_detalle(string $detalle): array
{
    $afectado = '';
    $resultado = '';
    $cambios = [];

    if (preg_match('/Usuario\s+afectado\s*:\s*([^|.;]+)/iu', $detalle, $m)) $afectado = trim($m[1]);
    elseif (preg_match('/usuario\s*:\s*([^|.;]+)/iu', $detalle, $m)) $afectado = trim($m[1]);

    if (preg_match('/Resultado\s*:\s*(.+?)(?:\||$)/iu', $detalle, $m)) $resultado = trim($m[1]);

    if (preg_match('/CAMPOS?\s+MODIFICADOS?\s*:\s*(.+?)(?:Resultado\s*:|$)/iu', $detalle, $m)) {
        $bloque = trim($m[1]);
        $partes = preg_split('/\s*(?:,|;|\|)\s*/u', $bloque) ?: [];
        foreach ($partes as $parte) {
            if (preg_match('/^([^:\[]+)\s*(?::|\[)\s*([^\]\-=>]+?)\s*(?:->|=>|→)\s*([^\]]+?)\]?$/u', trim($parte), $cm)) {
                $cambios[] = ['campo'=>trim($cm[1]), 'anterior'=>trim($cm[2]), 'nuevo'=>trim($cm[3])];
            }
        }
    }

    return ['afectado'=>$afectado, 'resultado'=>$resultado, 'cambios'=>$cambios];
}

try { $db = detectar_conexion(); }
catch (Throwable $e) {
    http_response_code(500);
    exit('<div style="padding:20px;font-family:Arial;color:#842029;background:#f8d7da">'.h($e->getMessage()).'</div>');
}

$buscar = limpiar($_GET['buscar'] ?? '');
$accion = limpiar($_GET['accion'] ?? '');
$desde = limpiar($_GET['desde'] ?? '');
$hasta = limpiar($_GET['hasta'] ?? '');
$opcionesPermitidas = [100, 300, 500];
$porPagina = (int)($_GET['por_pagina'] ?? 100);
if (!in_array($porPagina, $opcionesPermitidas, true)) $porPagina = 100;
$pagina = max(1, (int)($_GET['pagina'] ?? 1));

$where = [
    "UPPER(TRIM(accion)) NOT IN ('LOGIN','LOGIN_EXITOSO','LOGOUT','CIERRE_SESION','LOGIN_FALLIDO','LOGIN_FAIL','LOGIN_FAILED','LOGIN_ERROR')",
    "UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FAIL%'",
    "UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FALL%'"
];
$params = [];
$types = '';

if ($buscar !== '') {
    $where[] = '(usuario LIKE ? OR nombre_completo LIKE ? OR detalle LIKE ? OR ip LIKE ?)';
    $q = '%'.$buscar.'%';
    array_push($params, $q, $q, $q, $q);
    $types .= 'ssss';
}
if ($accion !== '') { $where[] = 'accion = ?'; $params[] = $accion; $types .= 's'; }
if ($desde !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) { $where[] = 'fecha >= ?'; $params[] = $desde.' 00:00:00'; $types .= 's'; }
if ($hasta !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) { $where[] = 'fecha < DATE_ADD(?, INTERVAL 1 DAY)'; $params[] = $hasta; $types .= 's'; }

$sqlWhere = ' WHERE '.implode(' AND ', $where);
$totalRegistros = (int)db_fetch_value($db, "SELECT COUNT(*) FROM auditoria {$sqlWhere}", $params, $types);
$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
$pagina = min($pagina, $totalPaginas);
$offset = max(0, ($pagina - 1) * $porPagina);

$registros = db_fetch_all(
    $db,
    "SELECT usuario, nombre_completo, accion, detalle, ip, fecha
     FROM auditoria {$sqlWhere}
     ORDER BY fecha DESC, usuario ASC
     LIMIT {$porPagina} OFFSET {$offset}",
    $params,
    $types
);

$accionesDisponibles = db_fetch_all(
    $db,
    "SELECT DISTINCT accion FROM auditoria
     WHERE accion IS NOT NULL AND accion <> ''
       AND UPPER(TRIM(accion)) NOT IN ('LOGIN','LOGIN_EXITOSO','LOGOUT','CIERRE_SESION','LOGIN_FALLIDO','LOGIN_FAIL','LOGIN_FAILED','LOGIN_ERROR')
       AND UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FAIL%'
       AND UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FALL%'
     ORDER BY accion ASC"
);

require_once __DIR__ . '/../layout_menu.php';
?>
<link rel="stylesheet" href="<?= h(dirname($_SERVER['SCRIPT_NAME'])) ?>/auditoria.css?v=<?= time() ?>">

<main class="audit-page">
    <header class="audit-page-head"></header>

    <section class="audit-workspace">
        <aside class="audit-master-card">
            <div class="audit-master-tools">
                <form method="get" class="audit-search-form" autocomplete="off">
                    <div class="audit-search-box">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 21-4.35-4.35m2.35-5.15a7.5 7.5 0 1 1-15 0 7.5 7.5 0 0 1 15 0Z"/></svg>
                        <input type="search" name="buscar" value="<?= h($buscar) ?>" placeholder="Buscar registros...">
                    </div>
                    <button class="audit-filter-toggle" type="button" id="auditFilterToggle" title="Filtros" aria-expanded="false">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16l-6.2 7.1v5.4l-3.6 1.8v-7.2L4 5Z"/></svg>
                    </button>
                    <input type="hidden" name="pagina" value="1">
                </form>

                <form method="get" class="audit-filter-panel" id="auditFilterPanel">
                    <input type="hidden" name="buscar" value="<?= h($buscar) ?>">
                    <label>Acción
                        <select name="accion">
                            <option value="">Todas</option>
                            <?php foreach ($accionesDisponibles as $op): $v = (string)($op['accion'] ?? ''); ?>
                                <option value="<?= h($v) ?>" <?= $accion === $v ? 'selected' : '' ?>><?= h(str_replace('_',' ', $v)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Desde<input type="date" name="desde" value="<?= h($desde) ?>"></label>
                    <label>Hasta<input type="date" name="hasta" value="<?= h($hasta) ?>"></label>
                    <label>Mostrar
                        <select name="por_pagina">
                            <?php foreach ($opcionesPermitidas as $op): ?>
                                <option value="<?= $op ?>" <?= $porPagina === $op ? 'selected' : '' ?>><?= $op ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <div class="audit-filter-actions">
                        <a href="?" class="audit-btn ghost">Limpiar</a>
                        <button type="submit" class="audit-btn primary">Aplicar</button>
                    </div>
                </form>
            </div>

            <div class="audit-list-title">Fecha y hora</div>

            <div class="audit-record-list" id="auditRecordList">
                <?php if ($registros === []): ?>
                    <div class="audit-empty">No hay registros con los filtros seleccionados.</div>
                <?php else: ?>
                    <?php foreach ($registros as $i => $r):
                        $a = datos_accion((string)$r['accion']);
                        $modulo = modulo_accion((string)$r['accion']);
                        $fecha = fecha_legible((string)$r['fecha']);
                        $nombre = limpiar($r['nombre_completo'] ?? '') ?: limpiar($r['usuario'] ?? '') ?: 'Usuario';
                        $detalle = limpiar($r['detalle'] ?? '') ?: 'Sin descripción registrada.';
                        $interpretado = interpretar_detalle($detalle);
                        $payload = [
                            'usuario'=>(string)$r['usuario'],
                            'nombre'=>(string)$r['nombre_completo'],
                            'fecha'=>$fecha,
                            'ip'=>limpiar($r['ip'] ?? '') ?: 'No registrada',
                            'detalle'=>$detalle,
                            'accion'=>$a['corto'],
                            'accionLarga'=>$a['largo'],
                            'accionClase'=>$a['clase'],
                            'modulo'=>$modulo,
                            'afectado'=>$interpretado['afectado'],
                            'resultado'=>$interpretado['resultado'],
                            'cambios'=>$interpretado['cambios']
                        ];
                    ?>
                    <button type="button" class="audit-record <?= $i === 0 ? 'is-active' : '' ?>" data-record='<?= h(json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>'>
                        <span class="audit-record-left">
                            <span class="audit-record-date"><?= h($fecha) ?></span>
                            <span class="audit-record-module"><?= h($modulo) ?></span>
                        </span>
                        <span class="audit-action-pill <?= h($a['clase']) ?>"><?= icono_accion_svg($a['clase']) ?><?= h($a['corto']) ?></span>
                    </button>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="audit-list-footer">
                <span>Mostrando <?= $totalRegistros ? $offset + 1 : 0 ?> a <?= min($offset + $porPagina, $totalRegistros) ?> de <?= number_format($totalRegistros) ?> registros</span>
                <?php if ($totalPaginas > 1): ?>
                    <div class="audit-pager">
                        <?php if ($pagina > 1): ?><a href="<?= h(url_pagina($pagina - 1)) ?>">‹</a><?php else: ?><span>‹</span><?php endif; ?>
                        <b><?= $pagina ?></b>
                        <?php if ($pagina < $totalPaginas): ?><a href="<?= h(url_pagina($pagina + 1)) ?>">›</a><?php else: ?><span>›</span><?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </aside>

        <article class="audit-detail-card">
            <?php if ($registros === []): ?>
                <div class="audit-detail-empty">Selecciona un registro para ver el detalle.</div>
            <?php else: ?>
                <div class="audit-detail-head">
                    <h2>Detalle del registro</h2>
                    <button type="button" class="audit-back-btn" id="auditBackBtn">← Volver al listado</button>
                </div>

                <div class="audit-detail-body">
                    <section class="audit-detail-meta">
                        <div class="audit-meta-row">
                            <span class="audit-meta-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg></span>
                            <div><small>Fecha y hora</small><strong id="detailDate">—</strong></div>
                        </div>
                        <div class="audit-meta-row">
                            <span class="audit-meta-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>
                            <div><small>Usuario</small><strong id="detailUser">—</strong><span id="detailName">—</span></div>
                        </div>
                        <div class="audit-meta-row">
                            <span class="audit-meta-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0M14 15a5 5 0 0 1 7 4.5"/></svg></span>
                            <div><small>Módulo</small><strong id="detailModule">—</strong></div>
                        </div>
                        <div class="audit-meta-row">
                            <span class="audit-meta-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.4 8 8 9 4.6-1 8-4 8-9V7Z"/><path d="M9 12l2 2 4-4"/></svg></span>
                            <div><small>Acción</small><span id="detailAction" class="audit-action-pill info"><span id="detailActionIcon"></span><span id="detailActionText">—</span></span></div>
                        </div>
                        <div class="audit-meta-row">
                            <span class="audit-meta-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg></span>
                            <div><small>IP</small><strong id="detailIp">—</strong></div>
                        </div>
                    </section>

                    <section class="audit-detail-info">
                        <div class="audit-description-block">
                            <small>Descripción</small>
                            <p id="detailDescription">—</p>
                        </div>
                    </section>
                </div>
            <?php endif; ?>
        </article>
    </section>
</main>

<script>
(() => {
    const filterToggle = document.getElementById('auditFilterToggle');
    const filterPanel = document.getElementById('auditFilterPanel');
    if (filterToggle && filterPanel) {
        filterToggle.addEventListener('click', () => {
            const open = filterPanel.classList.toggle('is-open');
            filterToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    const records = Array.from(document.querySelectorAll('.audit-record'));
    if (!records.length) return;

    const $ = id => document.getElementById(id);
    const fields = {
        date: $('detailDate'),
        user: $('detailUser'),
        name: $('detailName'),
        module: $('detailModule'),
        action: $('detailAction'),
        actionIcon: $('detailActionIcon'),
        actionText: $('detailActionText'),
        ip: $('detailIp'),
        description: $('detailDescription')
    };

    function render(btn) {
        let d = {};
        try { d = JSON.parse(btn.dataset.record || '{}'); } catch (e) { return; }
        records.forEach(r => r.classList.toggle('is-active', r === btn));

        fields.date.textContent = d.fecha || '—';
        fields.user.textContent = d.usuario || '—';
        fields.name.textContent = d.nombre ? `(${d.nombre})` : '';
        fields.module.textContent = d.modulo || 'Usuarios';
        fields.action.className = `audit-action-pill ${d.accionClase || 'info'}`;
        fields.actionText.textContent = d.accion || '—';

        const icons = {
            create: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 19a6 6 0 0 0-12 0"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/></svg>',
            edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>',
            block: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><path d="M9 15h6"/></svg>',
            unlock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2"/><path d="M12 14v3"/></svg>',
            info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
            metacreada: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            metaactualizada: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            diascreado: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            diasactualizado: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>'
        };

        fields.actionIcon.innerHTML = icons[d.accionClase] || icons.info;
        fields.ip.textContent = d.ip || '—';
        fields.description.textContent = d.detalle || 'Sin descripción registrada.';

        if (window.innerWidth <= 900) document.querySelector('.audit-workspace')?.classList.add('show-detail-mobile');
    }

    records.forEach(btn => btn.addEventListener('click', () => render(btn)));
    render(records[0]);

    document.getElementById('auditBackBtn')?.addEventListener('click', () => {
        document.querySelector('.audit-workspace')?.classList.remove('show-detail-mobile');
    });
})();
</script>

<?php require_once __DIR__ . '/../layout_footer.php'; ?>