-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-09-2026 a las 19:52:02
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `semafaroventas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `usuario` varchar(50) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `detalle` text NOT NULL,
  `ip` varchar(45) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dias_trabajados_identidades_manual`
--

CREATE TABLE `dias_trabajados_identidades_manual` (
  `tienda` varchar(50) NOT NULL,
  `codvendedor` varchar(50) NOT NULL,
  `dni` varchar(20) NOT NULL,
  `actualizado_por` int(11) NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dias_trabajados_vendedores_ocultos`
--

CREATE TABLE `dias_trabajados_vendedores_ocultos` (
  `usuario_id` int(11) NOT NULL,
  `tienda` varchar(20) NOT NULL,
  `codvendedor` varchar(30) NOT NULL,
  `fecha_quitado` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('administrador','gerente_comercial','gerente_tienda') NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `foto_perfil` varchar(255) DEFAULT NULL,
  `intentos` int(11) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `nombre_completo`, `password`, `rol`, `estado`, `foto_perfil`, `intentos`, `creado_en`, `ultimo_login`) VALUES
(1, 'admin', 'Lina Valladares', '$2y$10$gFsL3R/jdzYvfaMt8a3ex.uqXIfLeCp/tyUwqgk1gt8/CVrepcx6O', 'administrador', 1, 'avatar_06f484fd864d15340b018112c5df1edd.jpg', 0, '2026-08-20 14:39:23', '2026-09-11 09:26:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_tienda`
--

CREATE TABLE `usuario_tienda` (
  `usuario_id` int(11) NOT NULL,
  `codalmacen` varchar(20) NOT NULL,
  `nombre_tienda` varchar(100) DEFAULT NULL,
  `poblacion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `dias_trabajados_identidades_manual`
--
ALTER TABLE `dias_trabajados_identidades_manual`
  ADD PRIMARY KEY (`tienda`,`codvendedor`),
  ADD UNIQUE KEY `uq_dias_identidad_tienda_dni` (`tienda`,`dni`);

--
-- Indices de la tabla `dias_trabajados_vendedores_ocultos`
--
ALTER TABLE `dias_trabajados_vendedores_ocultos`
  ADD PRIMARY KEY (`usuario_id`,`tienda`,`codvendedor`),
  ADD KEY `idx_dias_ocultos_tienda` (`tienda`),
  ADD KEY `idx_dias_ocultos_vendedor` (`codvendedor`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_usuario` (`usuario`);

--
-- Indices de la tabla `usuario_tienda`
--
ALTER TABLE `usuario_tienda`
  ADD PRIMARY KEY (`usuario_id`,`codalmacen`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
