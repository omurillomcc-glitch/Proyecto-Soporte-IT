<?php
/*
|--------------------------------------------------------------------------
| ARCHIVO: dashboard.php
|--------------------------------------------------------------------------
| 
| - Mostrar un panel administrativo con estadísticas del sistema.
| - Validar que el usuario tenga una sesión activa.
| - Consultar usuarios locales, auditoría, descuentos y actividad reciente.
| - Mostrar gráficos con Chart.js.
| - Mostrar los últimos cambios de descuentos.
| - Mostrar de forma bonita los últimos usuarios creados en ICG.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: VALIDAR SESIÓN
|--------------------------------------------------------------------------
| Este archivo está en la raíz de app_descuento.
| validar_sesion.php se encarga de verificar si el usuario inició sesión.
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/usuarios/validar_sesion.php';

/*
|--------------------------------------------------------------------------
| PASO 2: EVITAR QUE WARNINGS ROMPAN EL DISEÑO
|--------------------------------------------------------------------------
| En producción no queremos warnings visibles dentro del HTML.
|--------------------------------------------------------------------------
*/
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR CONEXIÓN MYSQL LOCAL
|--------------------------------------------------------------------------
| Este archivo debe crear la variable $conn como conexión mysqli.
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/usuarios/conexion.php';

/*
|--------------------------------------------------------------------------
| PASO 4: FUNCIÓN PARA CONTAR REGISTROS
|--------------------------------------------------------------------------
| Ejecuta un SELECT COUNT(*) y devuelve un entero.
| Si falla la consulta, devuelve 0 para no romper el dashboard.
|--------------------------------------------------------------------------
*/
function count_query(mysqli $conn, string $sql): int {
    $r = $conn->query($sql);

    if (!$r) {
        return 0;
    }

    $row = $r->fetch_row();
    return $row ? (int)$row[0] : 0;
}

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIÓN PARA TRAER VARIOS REGISTROS
|--------------------------------------------------------------------------
| Ejecuta un SELECT normal y devuelve un array asociativo.
| Si falla, devuelve un array vacío.
|--------------------------------------------------------------------------
*/
function fetch_all_assoc(mysqli $conn, string $sql): array {
    $r = $conn->query($sql);
    return $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
}

/*
|--------------------------------------------------------------------------
| PASO 6: FORMATEAR IP
|--------------------------------------------------------------------------
| Si la IP es ::1 se muestra LOCALHOST.
|--------------------------------------------------------------------------
*/
function ip_label($ip): string {
    if (!$ip) {
        return '';
    }

    return ($ip === '::1') ? 'LOCALHOST' : htmlspecialchars((string)$ip);
}

/*
|--------------------------------------------------------------------------
| PASO 7: EXTRAER VALORES DE DETALLE DE AUDITORÍA
|--------------------------------------------------------------------------
| La auditoría se guarda así:
| ICG_USUARIO=SI | EMPRESA=Mendels | CODCLIENTE=810675 | NOMBRE=Lina | IDENTIDAD=0601-2000-01767
|
| Esta función extrae por llave:
| extraer_auditoria_valor($detalle, 'CODCLIENTE') => 810675
|--------------------------------------------------------------------------
*/
function extraer_auditoria_valor(string $detalle, string $key): string {
    if (preg_match('/\b' . preg_quote($key, '/') . '=([^|]+)(?:\||$)/i', $detalle, $m)) {
        return trim($m[1]);
    }

    return '';
}

/*
|--------------------------------------------------------------------------
| PASO 8: BADGE DE ACCIÓN
|--------------------------------------------------------------------------
| Convierte acciones técnicas en etiquetas visuales.
|--------------------------------------------------------------------------
*/
function badge_accion(string $accion): string {
    $a = htmlspecialchars($accion);

    return match ($accion) {
        'DESCUENTO_ASIGNADO'    => "<span class='badge text-bg-success'>ASIGNADO</span>",
        'DESCUENTO_CAMBIADO'    => "<span class='badge text-bg-warning text-dark'>CAMBIADO</span>",
        'DESCUENTO_ELIMINADO'   => "<span class='badge text-bg-secondary'>ELIMINADO</span>",
        'DESCUENTO_MASIVO'      => "<span class='badge text-bg-success'>MASIVO</span>",

        'USUARIO_AGREGADO'      => "<span class='badge text-bg-success'>AGREGADO</span>",
        'USUARIO_EDITADO'       => "<span class='badge text-bg-warning text-dark'>EDITADO</span>",
        'USUARIO_BLOQUEADO'     => "<span class='badge text-bg-danger'>BLOQUEADO</span>",
        'USUARIO_DESBLOQUEADO'  => "<span class='badge text-bg-info text-dark'>DESBLOQUEADO</span>",

        'ICG_USUARIO_CREADO'    => "<span class='badge text-bg-primary'>ICG CREADO</span>",

        'LOGIN_FAIL'            => "<span class='badge text-bg-danger'>LOGIN_FAIL</span>",
        'LOGIN_OK'              => "<span class='badge text-bg-success'>LOGIN_OK</span>",

        default                 => "<span class='badge text-bg-primary'>{$a}</span>",
    };
}

/*
|--------------------------------------------------------------------------
| PASO 9: FORMATEAR DETALLE DE AUDITORÍA
|--------------------------------------------------------------------------
| texto guardado en auditoría en una vista bonita.
| Aplica para usuarios, descuentos y usuarios ICG creados.
|--------------------------------------------------------------------------
*/
function fmt_detalle_auditoria(string $detalle): string {
    $d = trim($detalle);

    if ($d === '') {
        return '<div class="small text-muted">Sin detalle</div>';
    }

    /*
    |----------------------------------------------------------------------
    | PASO 9.1: DETALLE DE USUARIO ICG CREADO
    |----------------------------------------------------------------------
    */
    if (stripos($d, 'ICG_USUARIO=SI') !== false) {
        $empresa    = htmlspecialchars(extraer_auditoria_valor($d, 'EMPRESA') ?: '-');
        $codcliente = htmlspecialchars(extraer_auditoria_valor($d, 'CODCLIENTE') ?: '-');
        $nombre     = htmlspecialchars(extraer_auditoria_valor($d, 'NOMBRE') ?: '-');
        $identidad  = htmlspecialchars(extraer_auditoria_valor($d, 'IDENTIDAD') ?: '-');

        return "
            <div class='aud-det'>
                <div class='aud-row'><span class='aud-lbl'>Empresa</span><span class='aud-val mono'>{$empresa}</span></div>
                <div class='aud-row'><span class='aud-lbl'>CODCLIENTE</span><span class='aud-val mono'>{$codcliente}</span></div>
                <div class='aud-row'><span class='aud-lbl'>Nombre</span><span class='aud-val'>{$nombre}</span></div>
                <div class='aud-row'><span class='aud-lbl'>Identidad</span><span class='aud-val mono'>{$identidad}</span></div>
            </div>
        ";
    }

    /*
    |----------------------------------------------------------------------
    | PASO 9.2: DETALLE DE USUARIOS DEL SISTEMA
    |----------------------------------------------------------------------
    */
    if (stripos($d, 'USUARIO=') !== false) {
        $usuario = htmlspecialchars(extraer_auditoria_valor($d, 'USUARIO') ?: '-');
        $id      = htmlspecialchars(extraer_auditoria_valor($d, 'ID') ?: '-');
        $nombre  = htmlspecialchars(extraer_auditoria_valor($d, 'NOMBRE') ?: '');
        $rol     = htmlspecialchars(extraer_auditoria_valor($d, 'ROL') ?: '');
        $estado  = htmlspecialchars(extraer_auditoria_valor($d, 'ESTADO') ?: '');

        return "
            <div class='aud-det'>
                <div class='aud-row'><span class='aud-lbl'>Usuario</span><span class='aud-val mono'>{$usuario}</span></div>
                <div class='aud-row'><span class='aud-lbl'>ID</span><span class='aud-val mono'>{$id}</span></div>
                " . ($nombre !== '' ? "<div class='aud-row'><span class='aud-lbl'>Nombre</span><span class='aud-val'>{$nombre}</span></div>" : "") . "
                " . ($rol !== '' ? "<div class='aud-row'><span class='aud-lbl'>Rol</span><span class='aud-val'>{$rol}</span></div>" : "") . "
                " . ($estado !== '' ? "<div class='aud-row'><span class='aud-lbl'>Estado</span><span class='aud-val mono'>{$estado}</span></div>" : "") . "
            </div>
        ";
    }

    /*
    |----------------------------------------------------------------------
    | PASO 9.3: SI NO ES DETALLE DE DESCUENTO, MOSTRAR TEXTO NORMAL
    |----------------------------------------------------------------------
    */
    if (stripos($d, 'ICG=') === false) {
        return '<div class="small text-muted" style="white-space:pre-wrap;">' . htmlspecialchars($d) . '</div>';
    }

    /*
    |----------------------------------------------------------------------
    | PASO 9.4: DETALLE DE DESCUENTO
    |----------------------------------------------------------------------
    */
    $empresa    = extraer_auditoria_valor($d, 'ICG');
    $codcliente = extraer_auditoria_valor($d, 'CODCLIENTE');
    $idgrupo    = extraer_auditoria_valor($d, 'IDGRUPO');
    $identidad  = extraer_auditoria_valor($d, 'IDENTIDAD');
    $masivo     = extraer_auditoria_valor($d, 'MASIVO');

    $map = [
        '12' => '10%',
        '13' => '20%',
        '14' => '50%',
        '15' => '10%',
        '16' => '20%',
        '17' => '40%',
        '18' => '50%',
        '0'  => 'Sin descuento',
    ];

    $desc = $map[$idgrupo] ?? ($idgrupo !== '' ? $idgrupo : '-');

    $badge = in_array($desc, ['10%', '20%', '40%', '50%'], true)
        ? "<span class='badge text-bg-success'>{$desc}</span>"
        : "<span class='badge text-bg-secondary'>{$desc}</span>";

    $empresaSafe   = htmlspecialchars($empresa ?: '-');
    $codSafe       = htmlspecialchars($codcliente ?: '-');
    $identidadSafe = htmlspecialchars($identidad ?: '-');
    $masivoSafe    = htmlspecialchars($masivo ?: '');

    return "
        <div class='aud-det'>
            <div class='aud-row'><span class='aud-lbl'>Empresa</span><span class='aud-val mono'>{$empresaSafe}</span></div>
            <div class='aud-row'><span class='aud-lbl'>Código</span><span class='aud-val mono'>{$codSafe}</span></div>
            <div class='aud-row'><span class='aud-lbl'>Descuento</span><span class='aud-val'>{$badge}</span></div>
            <div class='aud-row'><span class='aud-lbl'>Identidad</span><span class='aud-val mono'>{$identidadSafe}</span></div>
            " . ($masivoSafe !== '' ? "<div class='aud-row'><span class='aud-lbl'>Masivo</span><span class='aud-val mono'>{$masivoSafe}</span></div>" : "") . "
        </div>
    ";
}

/*
|--------------------------------------------------------------------------
| PASO 10: CONTADORES DE USUARIOS DEL SISTEMA
|--------------------------------------------------------------------------
*/
$totalUsuarios = count_query($conn, "SELECT COUNT(*) FROM usuarios");
$usuariosBloqueados = count_query($conn, "SELECT COUNT(*) FROM usuarios WHERE estado='bloqueado'");
$activos = max(0, $totalUsuarios - $usuariosBloqueados);

/*
|--------------------------------------------------------------------------
| PASO 11: DATOS DE SESIÓN
|--------------------------------------------------------------------------
*/
$nombreSesion = $_SESSION['nombre'] ?? ($_SESSION['usuario'] ?? 'Usuario');
$rolSesion    = $_SESSION['rol'] ?? 'usuario';

/*
|--------------------------------------------------------------------------
| PASO 12: AUDITORÍA DE DESCUENTOS DE HOY
|--------------------------------------------------------------------------
*/
$asigHoy = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE accion='DESCUENTO_ASIGNADO' AND DATE(created_at)=CURDATE()");
$cambHoy = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE accion='DESCUENTO_CAMBIADO' AND DATE(created_at)=CURDATE()");
$elimHoy = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE accion='DESCUENTO_ELIMINADO' AND DATE(created_at)=CURDATE()");
$masivoHoy = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE accion='DESCUENTO_MASIVO' AND DATE(created_at)=CURDATE()");
$descuentosHoy = (int)($asigHoy + $cambHoy + $elimHoy + $masivoHoy);

/*
|--------------------------------------------------------------------------
| PASO 13: USUARIOS ICG CREADOS HOY
|--------------------------------------------------------------------------
*/
$icgUsuariosHoy = count_query($conn, "
    SELECT COUNT(*)
    FROM auditoria
    WHERE accion='ICG_USUARIO_CREADO'
      AND DATE(created_at)=CURDATE()
");

/*
|--------------------------------------------------------------------------
| PASO 14: ÚLTIMOS USUARIOS ICG CREADOS
|--------------------------------------------------------------------------
| Se mostrarán en tarjetas buenas.
|--------------------------------------------------------------------------
*/
$ultimosUsuariosICG = fetch_all_assoc($conn, "
    SELECT a.created_at, a.detalle, a.ip, u.nombre, u.usuario
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.accion='ICG_USUARIO_CREADO'
    ORDER BY a.created_at DESC
    LIMIT 8
");

/*
|--------------------------------------------------------------------------
| PASO 15: ACCIONES 24 HORAS Y 7 DÍAS
|--------------------------------------------------------------------------
*/
$acciones24h = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE created_at >= (NOW() - INTERVAL 1 DAY)");
$acciones7d = count_query($conn, "SELECT COUNT(*) FROM auditoria WHERE created_at >= (NOW() - INTERVAL 7 DAY)");
$promAcciones7d = (int)round($acciones7d / 7);

$varAcc = ($promAcciones7d > 0)
    ? (int)round((($acciones24h - $promAcciones7d) / $promAcciones7d) * 100)
    : 0;

/*
|--------------------------------------------------------------------------
| PASO 16: BADGE DE VARIACIÓN
|--------------------------------------------------------------------------
*/
function badge_var($v): string {
    $v = (int)$v;

    if ($v > 0) {
        return "<span class='badge text-bg-success'>+{$v}%</span>";
    }

    if ($v < 0) {
        return "<span class='badge text-bg-danger'>{$v}%</span>";
    }

    return "<span class='badge text-bg-secondary'>0%</span>";
}

/*
|--------------------------------------------------------------------------
| PASO 17: TOP EMPRESAS EN 7 DÍAS
|--------------------------------------------------------------------------
*/
$topEmpresas = fetch_all_assoc($conn, "
    SELECT
        LOWER(TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(a.detalle,'ICG=',-1),'|',1))) AS empresa,
        COUNT(*) AS total
    FROM auditoria a
    WHERE a.created_at >= (NOW() - INTERVAL 7 DAY)
      AND a.accion IN ('DESCUENTO_ASIGNADO','DESCUENTO_CAMBIADO','DESCUENTO_ELIMINADO','DESCUENTO_MASIVO')
      AND a.detalle LIKE '%ICG=%'
    GROUP BY empresa
    ORDER BY total DESC
    LIMIT 8
");

/*
|--------------------------------------------------------------------------
| PASO 18: ACCIONES POR DÍA PARA GRÁFICO
|--------------------------------------------------------------------------
*/
$accionesPorDia = fetch_all_assoc($conn, "
    SELECT DATE(created_at) AS dia, COUNT(*) AS total
    FROM auditoria
    WHERE created_at >= (CURDATE() - INTERVAL 6 DAY)
    GROUP BY DATE(created_at)
    ORDER BY dia ASC
");

$dias = [];
$vals = [];

for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i day"));
    $dias[] = $d;
    $vals[$d] = 0;
}

foreach ($accionesPorDia as $r) {
    $d = $r['dia'];

    if (isset($vals[$d])) {
        $vals[$d] = (int)$r['total'];
    }
}

$valList = [];

foreach ($dias as $d) {
    $valList[] = $vals[$d];
}

/*
|--------------------------------------------------------------------------
| PASO 19: DATA PARA GRÁFICO DE TOP EMPRESAS
|--------------------------------------------------------------------------
*/
$topEmpLabels = [];
$topEmpVals = [];

foreach ($topEmpresas as $e) {
    $topEmpLabels[] = $e['empresa'] ?: '(sin empresa)';
    $topEmpVals[] = (int)$e['total'];
}

/*
|--------------------------------------------------------------------------
| PASO 20: ÚLTIMOS CAMBIOS DE DESCUENTO
|--------------------------------------------------------------------------
*/
$ultimosDesc = fetch_all_assoc($conn, "
    SELECT a.created_at, a.accion, a.detalle, a.ip, u.nombre, u.usuario
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.accion IN ('DESCUENTO_ASIGNADO','DESCUENTO_CAMBIADO','DESCUENTO_ELIMINADO','DESCUENTO_MASIVO')
    ORDER BY a.created_at DESC
    LIMIT 10
");

/*
|--------------------------------------------------------------------------
| PASO 21: ÚLTIMOS LOGIN FALLIDOS
|--------------------------------------------------------------------------
*/
$ultimosFail = fetch_all_assoc($conn, "
    SELECT created_at, detalle, ip
    FROM auditoria
    WHERE accion='LOGIN_FAIL'
    ORDER BY created_at DESC
    LIMIT 8
");

/*
|--------------------------------------------------------------------------
| PASO 22: RANKING DE ADMINISTRADORES
|--------------------------------------------------------------------------
*/
$ranking = fetch_all_assoc($conn, "
    SELECT COALESCE(u.nombre,'(Sin nombre)') AS nombre, COALESCE(u.usuario,'') AS usuario, COUNT(*) AS total
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.accion IN ('DESCUENTO_ASIGNADO','DESCUENTO_CAMBIADO','DESCUENTO_MASIVO')
      AND a.created_at >= (NOW() - INTERVAL 7 DAY)
    GROUP BY a.usuario_id
    ORDER BY total DESC
    LIMIT 8
");
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>

    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- ICONOS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- ESTILOS DEL DASHBOARD -->
    <link rel="stylesheet" href="dashboard.css">
</head>

<body>
<div class="container-fluid wrap">

    <!-- HEADER -->
    <div class="tile tile-h mb-3">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="d-flex align-items-center gap-2">
                <div class="head-ico"><i class="bi bi-speedometer2 fs-5"></i></div>
                <div>
                    <div class="title fs-4">Dashboard</div>
                    <div class="muted">Bienvenido, <b><?= htmlspecialchars($nombreSesion) ?></b></div>
                </div>
            </div>

            <div class="d-flex gap-2 flex-wrap">
                <span class="badge text-bg-dark">Rol: <?= htmlspecialchars($rolSesion) ?></span>
                <span class="badge text-bg-secondary">Hoy: <?= date('Y-m-d') ?></span>
                <a class="btn btn-outline-primary btn-sm" href="#" data-page="/app_descuento/auditoria/auditoria.php">
                    <i class="bi bi-clipboard-data"></i> Auditoría
                </a>
            </div>
        </div>
    </div>

    <!-- ACCIONES Y GRÁFICOS -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-6">
            <div class="tile tile-h">
                <div class="d-flex justify-content-between align-items-start gap-3">
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="title"><i class="bi bi-activity"></i> Acciones</div>
                                <div class="muted small">Hoy vs Promedio diario (7 días)</div>
                            </div>
                            <?= badge_var($varAcc) ?>
                        </div>

                        <div class="d-flex gap-2 flex-wrap mt-2">
                            <span class="chip">Hoy: <?= (int)$acciones24h ?></span>
                            <span class="chip">Prom 7d: <?= (int)$promAcciones7d ?></span>
                            <span class="chip">Total 7d: <?= (int)$acciones7d ?></span>
                        </div>
                    </div>

                    <div style="width:180px; height:78px;">
                        <canvas id="sparkAcciones"
                            data-labels='<?= htmlspecialchars(json_encode($dias), ENT_QUOTES, "UTF-8") ?>'
                            data-values='<?= htmlspecialchars(json_encode($valList), ENT_QUOTES, "UTF-8") ?>'></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-6">
            <div class="tile tile-h">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <div class="title"><i class="bi bi-bar-chart"></i> Acciones por día</div>
                        <div class="muted small">Últimos 7 días</div>
                    </div>
                    <span class="badge text-bg-dark">7d</span>
                </div>

                <div class="chartBox">
                    <canvas id="barAcciones7d"
                        data-labels='<?= htmlspecialchars(json_encode($dias), ENT_QUOTES, "UTF-8") ?>'
                        data-values='<?= htmlspecialchars(json_encode($valList), ENT_QUOTES, "UTF-8") ?>'></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- USUARIOS ICG CREADOS -->
    <div class="tile tile-h mb-3">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <div>
                <div class="title">
                    <i class="bi bi-person-fill-add"></i> Últimos usuarios ICG creados
                </div>
                <div class="muted small"></div>
            </div>

            <span class="badge text-bg-primary fs-6">
                Hoy: <?= (int)$icgUsuariosHoy ?>
            </span>
        </div>

        <div class="row g-3">
            <?php if (!$ultimosUsuariosICG): ?>
                <div class="col-12">
                    <div class="text-center py-4 muted">
                        <i class="bi bi-info-circle"></i> Aún no hay usuarios ICG creados.
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($ultimosUsuariosICG as $r):
                    $detalle = (string)($r['detalle'] ?? '');

                    $empresaICG = extraer_auditoria_valor($detalle, 'EMPRESA') ?: '-';
                    $codcliente = extraer_auditoria_valor($detalle, 'CODCLIENTE') ?: '-';
                    $nombreICG  = extraer_auditoria_valor($detalle, 'NOMBRE') ?: '-';
                    $identidad  = extraer_auditoria_valor($detalle, 'IDENTIDAD') ?: '-';
                    $creadoPor  = $r['nombre'] ?: ($r['usuario'] ?: 'Desconocido');
                ?>
                    <div class="col-12 col-md-6 col-xl-3">
                        <div class="card border-0 shadow-sm rounded-4 h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge text-bg-primary">
                                        <?= htmlspecialchars($empresaICG) ?>
                                    </span>
                                    <small class="text-muted">
                                        <?= htmlspecialchars((string)($r['created_at'] ?? '')) ?>
                                    </small>
                                </div>

                                <div class="fw-bold mb-1">
                                    <i class="bi bi-person-circle"></i>
                                    <?= htmlspecialchars($nombreICG) ?>
                                </div>

                                <div class="small text-muted mb-3">
                                    Creado por:
                                    <b><?= htmlspecialchars($creadoPor) ?></b>
                                </div>

                                <div class="aud-det">
                                    <div class="aud-row">
                                        <span class="aud-lbl">CODCLIENTE</span>
                                        <span class="aud-val mono"><?= htmlspecialchars($codcliente) ?></span>
                                    </div>

                                    <div class="aud-row">
                                        <span class="aud-lbl">Identidad</span>
                                        <span class="aud-val mono"><?= htmlspecialchars($identidad) ?></span>
                                    </div>

                                    <div class="aud-row">
                                        <span class="aud-lbl">IP</span>
                                        <span class="aud-val mono"><?= ip_label($r['ip'] ?? '') ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- DESCUENTOS Y TOP EMPRESAS -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-6">
            <div class="tile tile-h">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                    <div>
                        <div class="title"><i class="bi bi-cash-coin"></i> Descuentos (hoy)</div>
                        <div class="muted small"></div>
                    </div>

                    <div class="d-flex gap-2 flex-wrap">
                        <span class="chip">Asignados: <?= (int)$asigHoy ?></span>
                        <span class="chip">Cambiados: <?= (int)$cambHoy ?></span>
                        <span class="chip">Eliminados: <?= (int)$elimHoy ?></span>
                        <span class="chip">Masivos: <?= (int)$masivoHoy ?></span>
                    </div>
                </div>

                <div class="donutBox">
                    <canvas id="donutDescuentos"
                        data-asig="<?= (int)$asigHoy ?>"
                        data-camb="<?= (int)$cambHoy ?>"
                        data-elim="<?= (int)$elimHoy ?>"
                        data-masivo="<?= (int)$masivoHoy ?>"
                        data-total="<?= (int)$descuentosHoy ?>"></canvas>

                    <div class="donutCenter">
                        <div class="text-center">
                            <div class="big"><?= (int)$descuentosHoy ?></div>
                            <div class="sm">Total hoy</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-6">
            <div class="tile tile-h h-100">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <div class="title"><i class="bi bi-building"></i> Top empresas</div>
                        <div class="muted small">Cambios de descuento (7 días)</div>
                    </div>
                    <span class="badge text-bg-dark">7d</span>
                </div>

                <?php if (!$topEmpresas): ?>
                    <div class="text-center py-4 muted">Sin datos</div>
                <?php else: ?>
                    <div class="chartBox" style="height:240px;">
                        <canvas id="barTopEmpresas"
                            data-labels='<?= htmlspecialchars(json_encode($topEmpLabels), ENT_QUOTES, "UTF-8") ?>'
                            data-values='<?= htmlspecialchars(json_encode($topEmpVals), ENT_QUOTES, "UTF-8") ?>'></canvas>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- USUARIOS, RANKING Y LOGIN FAIL -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-4">
            <div class="tile tile-h h-100">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <div class="title"><i class="bi bi-people"></i> Usuarios</div>
                        <div class="muted small">Activos vs Bloqueados</div>
                    </div>
                </div>

                <div class="d-flex gap-2 flex-wrap mb-2">
                    <span class="chip">Activos: <?= (int)$activos ?></span>
                    <span class="chip">Bloqueados: <?= (int)$usuariosBloqueados ?></span>
                    <span class="chip">Total: <?= (int)$totalUsuarios ?></span>
                </div>

                <div class="donutBox" style="height:220px;">
                    <canvas id="donutUsuarios"
                        data-activos="<?= (int)$activos ?>"
                        data-bloq="<?= (int)$usuariosBloqueados ?>"></canvas>

                    <div class="donutCenter">
                        <div class="text-center">
                            <div class="big"><?= (int)$totalUsuarios ?></div>
                            <div class="sm">Total</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-lg-4">
            <div class="tile tile-h h-100">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div class="title"><i class="bi bi-trophy"></i> Ranking admins</div>
                    <div class="muted small">7 días</div>
                </div>

                <?php if (!$ranking): ?>
                    <div class="text-center py-4 muted">Sin actividad reciente</div>
                <?php else: ?>
                    <?php $i = 1; foreach ($ranking as $r): ?>
                        <div class="list-row">
                            <div class="d-flex align-items-center gap-2">
                                <div class="rank-badge"><?= $i++ ?></div>
                                <div>
                                    <div class="fw-bold"><?= htmlspecialchars($r['nombre']) ?></div>
                                    <div class="muted small">@<?= htmlspecialchars($r['usuario']) ?></div>
                                </div>
                            </div>
                            <span class="badge text-bg-dark"><?= (int)$r['total'] ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-12 col-lg-4">
            <div class="tile tile-h h-100">
                <div class="title mb-2"><i class="bi bi-shield-x"></i> Últimos LOGIN_FAIL</div>

                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Fecha</th><th>Usuario</th><th>IP</th></tr>
                        </thead>
                        <tbody>
                            <?php if (!$ultimosFail): ?>
                                <tr><td colspan="3" class="muted">No hay intentos fallidos recientes.</td></tr>
                            <?php else: ?>
                                <?php foreach ($ultimosFail as $r):
                                    $detalle = $r['detalle'] ?? '';
                                    $user = 'Desconocido';

                                    if (preg_match('/usuario:\s*([^\s]+)/i', $detalle, $m)) {
                                        $user = $m[1];
                                    }
                                ?>
                                    <tr>
                                        <td><?= htmlspecialchars($r['created_at'] ?? '') ?></td>
                                        <td class="fw-semibold"><?= htmlspecialchars($user) ?></td>
                                        <td><?= ip_label($r['ip'] ?? '') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ÚLTIMOS CAMBIOS DE DESCUENTO -->
    <div class="tile tile-h">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <div class="title"><i class="bi bi-arrow-repeat"></i> Últimos cambios de descuento</div>
            <a class="btn btn-outline-primary btn-sm" href="#" data-page="/app_descuento/auditoria/auditoria.php">Ver auditoría</a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Fecha</th>
                        <th>Usuario</th>
                        <th>Acción</th>
                        <th>IP</th>
                        <th>Detalle</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (!$ultimosDesc): ?>
                        <tr><td colspan="5" class="muted">Aún no hay cambios de descuento.</td></tr>
                    <?php else: ?>
                        <?php foreach ($ultimosDesc as $r): ?>
                            <tr>
                                <td><?= htmlspecialchars($r['created_at']) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= htmlspecialchars($r['nombre'] ?? 'Desconocido') ?></div>
                                    <div class="muted small">@<?= htmlspecialchars($r['usuario'] ?? '') ?></div>
                                </td>
                                <td><?= badge_accion((string)($r['accion'] ?? '')) ?></td>
                                <td><?= ip_label($r['ip'] ?? '') ?></td>
                                <td style="max-width:520px;"><?= fmt_detalle_auditoria((string)($r['detalle'] ?? '')) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- CHART JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<script>
/*
|--------------------------------------------------------------------------
| PASO 23: FUNCIÓN PARA CREAR GRADIENTE
|--------------------------------------------------------------------------
*/
function makeGradient(ctx, h) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "rgba(37,99,235,.95)");
    g.addColorStop(1, "rgba(37,99,235,.12)");
    return g;
}

/*
|--------------------------------------------------------------------------
| PASO 24: INICIALIZAR GRÁFICOS DEL DASHBOARD
|--------------------------------------------------------------------------
*/
window.initDashboardCharts = function () {
    if (!window.Chart) return;

    const sp = document.getElementById("sparkAcciones");

    if (sp) {
        const labels = JSON.parse(sp.dataset.labels || "[]");
        const values = JSON.parse(sp.dataset.values || "[]");
        const ctx = sp.getContext("2d");

        const grad = ctx.createLinearGradient(0, 0, 0, 80);
        grad.addColorStop(0, "rgba(37,99,235,.55)");
        grad.addColorStop(1, "rgba(37,99,235,.05)");

        if (sp._chart) sp._chart.destroy();

        sp._chart = new Chart(sp, {
            type: "line",
            data: {
                labels,
                datasets: [{
                    data: values,
                    borderColor: "rgba(37,99,235,1)",
                    backgroundColor: grad,
                    fill: true,
                    tension: 0.35,
                    pointRadius: 0,
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { display: false },
                    y: { display: false, beginAtZero: true }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: { displayColors: false }
                }
            }
        });
    }

    const u = document.getElementById("donutUsuarios");

    if (u) {
        const activos = parseInt(u.dataset.activos || "0", 10);
        const bloq = parseInt(u.dataset.bloq || "0", 10);

        if (u._chart) u._chart.destroy();

        u._chart = new Chart(u, {
            type: "doughnut",
            data: {
                labels: ["Activos", "Bloqueados"],
                datasets: [{
                    data: [activos, bloq],
                    backgroundColor: ["#2563eb", "#64748b"],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "74%",
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: { usePointStyle: true, boxWidth: 10, padding: 14 }
                    }
                }
            }
        });
    }

    const d1 = document.getElementById("donutDescuentos");

    if (d1) {
        const asig = parseInt(d1.dataset.asig || "0", 10);
        const camb = parseInt(d1.dataset.camb || "0", 10);
        const elim = parseInt(d1.dataset.elim || "0", 10);
        const masivo = parseInt(d1.dataset.masivo || "0", 10);

        if (d1._chart) d1._chart.destroy();

        d1._chart = new Chart(d1, {
            type: "doughnut",
            data: {
                labels: ["Asignados", "Cambiados", "Eliminados", "Masivos"],
                datasets: [{
                    data: [asig, camb, elim, masivo],
                    backgroundColor: ["#22c55e", "#f59e0b", "#ef4444", "#2563eb"],
                    borderWidth: 0,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "74%",
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: { usePointStyle: true, boxWidth: 10, padding: 14 }
                    }
                }
            }
        });
    }

    const b1 = document.getElementById("barAcciones7d");

    if (b1) {
        const labels = JSON.parse(b1.dataset.labels || "[]");
        const values = JSON.parse(b1.dataset.values || "[]");
        const ctx = b1.getContext("2d");
        const grad = makeGradient(ctx, 220);

        if (b1._chart) b1._chart.destroy();

        b1._chart = new Chart(b1, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: grad,
                    borderRadius: 10,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { callback: (v, i) => (labels[i] || "").slice(5) }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: "rgba(15,23,42,.08)" },
                        ticks: { precision: 0 }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    const b2 = document.getElementById("barTopEmpresas");

    if (b2) {
        const labels = JSON.parse(b2.dataset.labels || "[]");
        const values = JSON.parse(b2.dataset.values || "[]");

        if (b2._chart) b2._chart.destroy();

        b2._chart = new Chart(b2, {
            type: "bar",
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: "rgba(14,165,233,.85)",
                    borderRadius: 10,
                    borderSkipped: false
                }]
            },
            options: {
                indexAxis: "y",
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: { color: "rgba(15,23,42,.08)" },
                        ticks: { precision: 0 }
                    },
                    y: {
                        grid: { display: false }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
};

/*
|--------------------------------------------------------------------------
| PASO 25: EJECUTAR GRÁFICOS CUANDO CARGA LA PÁGINA
|--------------------------------------------------------------------------
*/
document.addEventListener("DOMContentLoaded", function () {
    window.initDashboardCharts && window.initDashboardCharts();
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
