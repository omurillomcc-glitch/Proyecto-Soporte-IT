<?php
/*
|--------------------------------------------------------------------------
| ARCHIVO: vista_agregar_usuario.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Mostrar el formulario para agregar usuarios.
| - Esta vista se carga dentro de index.php usando AJAX.
| - NO debe tener <!DOCTYPE html>, <html>, <head> ni <body>.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: VALIDAR SESIÓN
|--------------------------------------------------------------------------
| validar_sesion.php ya debe tener:
|
| session_name('SESION_DESCUENTOS');
| if (session_status() === PHP_SESSION_NONE) {
|     session_start();
| }
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/validar_sesion.php";

/*
|--------------------------------------------------------------------------
| PASO 2: VALIDAR PERMISO
|--------------------------------------------------------------------------
| Solo admin o super_admin pueden ver esta vista.
|--------------------------------------------------------------------------
*/
$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin", "super_admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para agregar usuarios.</div>';
    exit;
}
?>

<!--
|--------------------------------------------------------------------------
| PASO 3: CSS DE ESTA VISTA
|--------------------------------------------------------------------------
| Como esta vista se carga dentro del index.php, el CSS puede cargarse aquí.
|--------------------------------------------------------------------------
-->
<link rel="stylesheet" href="/app_descuento/usuarios/agregar_usuario.css">

<!--
|--------------------------------------------------------------------------
| PASO 4: CONTENEDOR PRINCIPAL DE LA VISTA
|--------------------------------------------------------------------------
-->
<div class="section-wrap">

    <!-- HEADER COMO CARD -->
    <div class="section-head-card">
        <div class="section-head">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-person-plus me-2"></i>Agregar usuario
                </h4>

                <p class="section-sub">
                    Crea usuarios para el sistema y asigna su rol.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-gear-fill"></i> Configuración
            </span>
        </div>
    </div>

    <!-- CARD DEL FORMULARIO -->
    <div class="card section-card mt-3">
        <div class="card-body section-card-body">

            <div class="section-divider">Datos del usuario</div>

            <form id="formAgregarUsuario" autocomplete="off">
                <div class="row g-3">

                    <!-- USUARIO -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Usuario</label>

                        <input
                            type="text"
                            class="form-control"
                            name="usuario"
                            maxlength="30"
                            required
                        >

                        <div class="form-hint">
                            Solo letras, máximo 30 caracteres.
                        </div>
                    </div>

                    <!-- NOMBRE COMPLETO -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Nombre completo</label>

                        <input
                            type="text"
                            class="form-control"
                            name="nombre"
                            maxlength="60"
                            required
                        >

                        <div class="form-hint">
                            Solo letras y espacios.
                        </div>
                    </div>

                    <!-- CONTRASEÑA -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Contraseña</label>

                        <div class="input-group">
                            <input
                                type="password"
                                class="form-control"
                                name="password"
                                maxlength="20"
                                required
                            >

                            <button
                                class="btn btn-outline-secondary"
                                type="button"
                                id="btnTogglePass"
                                aria-label="Ver contraseña"
                            >
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>

                        <div class="form-hint">
                            Mínimo 6 caracteres. Letras, números y punto.
                        </div>
                    </div>

                    <!-- ROL -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Rol</label>

                        <select class="form-select" name="rol" required>
                            <option value="usuario" selected>Usuario</option>
                            <option value="admin">Administrador</option>
                        </select>

                        <div class="form-hint">
                            Define permisos del usuario.
                        </div>
                    </div>

                </div>

                <!-- BOTONES -->
                <div class="section-actions mt-4">
                    <button type="submit" class="btn btn-main">
                        <i class="bi bi-check2-circle me-1"></i> Guardar
                    </button>

                    <button type="reset" class="btn btn-soft">
                        <i class="bi bi-x-circle me-1"></i> Cancelar
                    </button>
                </div>

                <!-- MENSAJE -->
                <div id="msgAddUser" class="mt-3"></div>

            </form>

        </div>
    </div>

</div>

<script>
(function () {

    /*
    |--------------------------------------------------------------------------
    | PASO 5: OBTENER ELEMENTOS
    |--------------------------------------------------------------------------
    */
    const form = document.getElementById("formAgregarUsuario");

    if (!form) {
        return;
    }

    const msg          = document.getElementById("msgAddUser");
    const toggle       = document.getElementById("btnTogglePass");
    const passInput    = form.querySelector('input[name="password"]');
    const inputUsuario = form.querySelector('input[name="usuario"]');
    const inputNombre  = form.querySelector('input[name="nombre"]');
    const btnSubmit    = form.querySelector('button[type="submit"]');
    const btnReset     = form.querySelector('button[type="reset"]');

    /*
    |--------------------------------------------------------------------------
    | PASO 6: VALIDAR USUARIO EN VIVO
    |--------------------------------------------------------------------------
    | Solo permite letras.
    |--------------------------------------------------------------------------
    */
    inputUsuario.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 7: VALIDAR NOMBRE EN VIVO
    |--------------------------------------------------------------------------
    | Solo permite letras y espacios.
    |--------------------------------------------------------------------------
    */
    inputNombre.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 8: VALIDAR CONTRASEÑA EN VIVO
    |--------------------------------------------------------------------------
    | Solo letras, números y punto.
    |--------------------------------------------------------------------------
    */
    passInput.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 9: VER / OCULTAR CONTRASEÑA
    |--------------------------------------------------------------------------
    */
    toggle.addEventListener("click", function () {
        const isPass = passInput.type === "password";

        passInput.type = isPass ? "text" : "password";

        toggle.innerHTML = isPass
            ? '<i class="bi bi-eye-slash"></i>'
            : '<i class="bi bi-eye"></i>';
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 10: ENVIAR FORMULARIO POR AJAX
    |--------------------------------------------------------------------------
    | Este formulario envía los datos al backend:
    | usuarios/agregar_usuario.php
    |--------------------------------------------------------------------------
    */
    form.addEventListener("submit", async function (e) {
        e.preventDefault();

        msg.innerHTML = "";

        /*
        |--------------------------------------------------------------------------
        | VALIDAR CONTRASEÑA ANTES DE ENVIAR
        |--------------------------------------------------------------------------
        */
        if ((passInput.value || "").length < 6) {
            showMessage("La contraseña debe tener mínimo 6 caracteres.", "danger");
            return;
        }

        const originalBtn = btnSubmit.innerHTML;

        try {
            btnSubmit.disabled = true;
            btnReset.disabled = true;

            btnSubmit.innerHTML =
                '<span class="spinner-border spinner-border-sm me-2"></span>Guardando...';

            const fd = new FormData(form);

            /*
            |--------------------------------------------------------------------------
            | IMPORTANTE:
            | Usamos ruta absoluta para evitar errores cuando la vista se carga por AJAX.
            |--------------------------------------------------------------------------
            */
            const res = await fetch("/app_descuento/usuarios/agregar_usuario.php", {
                method: "POST",
                body: fd,
                credentials: "same-origin"
            });

            const data = await res.json();

            if (data.ok) {
                showMessage(data.msg || "Usuario agregado correctamente.", "success");
                form.reset();
                inputUsuario.focus();
            } else {
                showMessage(data.msg || "No se pudo guardar el usuario.", "danger");
            }

        } catch (err) {
            showMessage("No se pudo conectar con el servidor.", "danger");
        } finally {
            btnSubmit.disabled = false;
            btnReset.disabled = false;
            btnSubmit.innerHTML = originalBtn;
        }
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 11: MOSTRAR MENSAJES
    |--------------------------------------------------------------------------
    */
    function showMessage(text, type) {
        msg.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0 fade show">
                <i class="bi ${
                    type === "success"
                    ? "bi-check-circle"
                    : "bi-exclamation-triangle"
                } me-1"></i>
                ${text}
            </div>
        `;

        if (type === "success") {
            setTimeout(() => {
                msg.innerHTML = "";
            }, 4000);
        }
    }

})();
</script>