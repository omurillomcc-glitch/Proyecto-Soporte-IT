<?php
require_once __DIR__ . "/validar_sesion.php";

/*
|--------------------------------------------------------------------------
| PASO 2: VALIDAR PERMISO
|--------------------------------------------------------------------------
| Solo admin o super_admin pueden ver esta vista.
|--------------------------------------------------------------------------
*/
$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin", "super_admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para bloquear o desbloquear usuarios.</div>';
    exit;
}
?>

<!--
|--------------------------------------------------------------------------
| PASO 3: CSS DE ESTA VISTA
|--------------------------------------------------------------------------
| Bootstrap ya se carga en index.php, aquí solo cargamos tu CSS propio.
|--------------------------------------------------------------------------
-->
<link rel="stylesheet" href="/app_descuento/usuarios/agregar_usuario.css">

<style>
    /*
    |--------------------------------------------------------------------------
    | AJUSTES DE DISEÑO PARA ESTA VISTA
    |--------------------------------------------------------------------------
    */
    .section-wrap {
        max-width: 920px;
    }

    .section-card > .card-body {
        padding: 28px;
    }

    .table-responsive {
        padding-right: 10px;
    }

    .table {
        min-width: 820px;
    }

    .table thead th {
        padding: 16px 18px !important;
        white-space: nowrap;
    }

    .table tbody td {
        padding: 18px 18px !important;
        vertical-align: middle;
    }

    .table th.text-end,
    .table td.text-end {
        padding-right: 18px !important;
        min-width: 160px;
    }

    #selLimit {
        min-width: 160px;
    }

    .btn-action {
        border-radius: 14px !important;
        padding: 10px 14px !important;
        font-weight: 900 !important;
        white-space: nowrap;
    }

    @media (max-width: 768px) {
        .section-wrap {
            max-width: 560px;
        }

        .table {
            min-width: 760px;
        }

        .section-card > .card-body {
            padding: 18px;
        }
    }
</style>

<!--
|--------------------------------------------------------------------------
| PASO 4: CONTENIDO PRINCIPAL DE LA VISTA
|--------------------------------------------------------------------------
-->
<div class="section-wrap">

    <!-- ENCABEZADO -->
    <div class="section-head-card">
        <div class="section-head d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-lock me-2"></i>Bloquear / Desbloquear
                </h4>

                <p class="section-sub">
                    Controla el acceso del usuario: activo o bloqueado.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-shield-lock"></i> Solo Admin
            </span>
        </div>
    </div>

    <!-- CARD PRINCIPAL -->
    <div class="card section-card mt-3">
        <div class="card-body">

            <!-- BUSCADOR -->
            <div class="section-divider">
                <i class="bi bi-search me-2"></i>Buscar
            </div>

            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Buscar por usuario o nombre</label>

                    <input
                        id="txtBuscar"
                        type="text"
                        class="form-control"
                        placeholder="Escriba para buscar..."
                    >
                </div>
            </div>

            <!-- MENSAJE -->
            <div id="msgList" class="mt-3"></div>

            <!-- TABLA -->
            <div class="table-responsive mt-3">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Rol</th>
                            <th>Estado</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>

                    <tbody id="tbodyUsuarios">
                        <tr>
                            <td colspan="6" class="text-muted">Cargando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN -->
            <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">
                <div class="text-muted small" id="lblPagerInfo"></div>

                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <select id="selLimit" class="form-select">
                        <option value="100" selected>100 por página</option>
                        <option value="150">150 por página</option>
                        <option value="200">200 por página</option>
                    </select>

                    <nav>
                        <ul class="pagination mb-0" id="pagination"></ul>
                    </nav>
                </div>
            </div>

        </div>
    </div>
</div>

<!--
|--------------------------------------------------------------------------
| PASO 5: MODAL DE CONFIRMACIÓN
|--------------------------------------------------------------------------
-->
<div class="modal fade" id="modalConfirm" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-exclamation-triangle me-2"></i>Confirmar acción
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div id="confirmText" class="mb-2"></div>

                <div class="small text-muted">
                    Esto afectará el acceso del usuario al sistema.
                </div>

                <div id="msgConfirm" class="mt-3"></div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-soft" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>

                <button class="btn btn-main" id="btnConfirm">
                    <i class="bi bi-check2-circle me-1"></i> Confirmar
                </button>
            </div>

        </div>
    </div>
</div>

<script>
(function () {

    /*
    |--------------------------------------------------------------------------
    | PASO 6: OBTENER ELEMENTOS
    |--------------------------------------------------------------------------
    */
    const tbody       = document.getElementById("tbodyUsuarios");
    const txtBuscar   = document.getElementById("txtBuscar");
    const msgList     = document.getElementById("msgList");
    const selLimit    = document.getElementById("selLimit");
    const lblPagerInfo = document.getElementById("lblPagerInfo");
    const pagination  = document.getElementById("pagination");

    const modalConfirmEl = document.getElementById("modalConfirm");
    const confirmText    = document.getElementById("confirmText");
    const msgConfirm     = document.getElementById("msgConfirm");
    const btnConfirm     = document.getElementById("btnConfirm");

    if (!tbody || !txtBuscar || !modalConfirmEl) {
        return;
    }

    const modalConfirm = new bootstrap.Modal(modalConfirmEl);

    let cacheUsuarios = [];
    let page = 1;
    let limit = parseInt(selLimit.value || "100", 10);

    let pendingId = null;
    let pendingAccion = null;

    /*
    |--------------------------------------------------------------------------
    | PASO 7: BUSCAR CON ESPERA
    |--------------------------------------------------------------------------
    */
    let timerBusqueda = null;

    txtBuscar.addEventListener("input", function () {
        clearTimeout(timerBusqueda);

        timerBusqueda = setTimeout(function () {
            page = 1;
            cargarUsuarios();
        }, 250);
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 8: CAMBIAR CANTIDAD POR PÁGINA
    |--------------------------------------------------------------------------
    */
    selLimit.addEventListener("change", function () {
        limit = parseInt(selLimit.value || "100", 10);
        page = 1;
        cargarUsuarios();
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 9: CONFIRMAR ACCIÓN
    |--------------------------------------------------------------------------
    */
    btnConfirm.addEventListener("click", async function () {
        if (!pendingId || !pendingAccion) {
            return;
        }

        await toggleEstado(pendingId, pendingAccion);
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 10: CARGAR USUARIOS DESDE BACKEND
    |--------------------------------------------------------------------------
    */
    async function cargarUsuarios() {
        msgList.innerHTML = "";
        lblPagerInfo.textContent = "";
        pagination.innerHTML = "";

        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-muted">Cargando...</td>
            </tr>
        `;

        try {
            const q = encodeURIComponent((txtBuscar.value || "").trim());

            const url = `/app_descuento/usuarios/bloquear_usuario.php?action=list&page=${page}&limit=${limit}&q=${q}`;

            const res = await fetch(url, {
                cache: "no-store",
                credentials: "same-origin"
            });

            const data = await res.json();

            if (!res.ok || !data.ok) {
                throw new Error(data.msg || `HTTP ${res.status}`);
            }

            cacheUsuarios = data.usuarios || [];

            const total = parseInt(data.total || 0, 10);
            const pages = parseInt(data.pages || 1, 10);

            if (page > pages) {
                page = pages;
            }

            const from = total === 0 ? 0 : ((page - 1) * limit + 1);
            const to = Math.min(page * limit, total);

            lblPagerInfo.textContent =
                `Mostrando ${from}-${to} de ${total} (página ${page} de ${pages})`;

            renderTabla();
            renderPaginacion(pages);

        } catch (e) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-danger">No se pudo cargar.</td>
                </tr>
            `;

            showAlert(msgList, "danger", e.message);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 11: RENDERIZAR TABLA
    |--------------------------------------------------------------------------
    */
    function renderTabla() {
        if (cacheUsuarios.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-muted">Sin resultados.</td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = cacheUsuarios.map(function (u) {
            const estadoTexto = String(u.estado || "").toLowerCase();

            const esBloqueado =
                estadoTexto === "bloqueado" ||
                estadoTexto === "0" ||
                estadoTexto === "inactivo";

            const badgeEstado = esBloqueado
                ? `
                    <span class="estado-badge estado-bloqueado">
                        <i class="bi bi-lock-fill"></i> Bloqueado
                    </span>
                `
                : `
                    <span class="estado-badge estado-activo">
                        <i class="bi bi-check-circle-fill"></i> Activo
                    </span>
                `;

            const btnAccion = esBloqueado
                ? `
                    <button class="btn btn-soft btn-action btn-sm" data-id="${u.id}" data-act="desbloquear">
                        <i class="bi bi-unlock-fill me-1"></i> Desbloquear
                    </button>
                `
                : `
                    <button class="btn btn-main btn-action btn-sm" data-id="${u.id}" data-act="bloquear">
                        <i class="bi bi-lock-fill me-1"></i> Bloquear
                    </button>
                `;

            return `
                <tr>
                    <td class="fw-semibold">${escapeHtml(u.id)}</td>
                    <td class="fw-semibold">${escapeHtml(u.usuario)}</td>
                    <td>${escapeHtml(u.nombre)}</td>
                    <td>${escapeHtml(u.rol)}</td>
                    <td>${badgeEstado}</td>
                    <td class="text-end">${btnAccion}</td>
                </tr>
            `;
        }).join("");

        tbody.querySelectorAll("button[data-id]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                const id = btn.getAttribute("data-id");
                const accion = btn.getAttribute("data-act");

                abrirConfirmacion(id, accion);
            });
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 12: ABRIR MODAL DE CONFIRMACIÓN
    |--------------------------------------------------------------------------
    */
    function abrirConfirmacion(id, accion) {
        pendingId = id;
        pendingAccion = accion;

        msgConfirm.innerHTML = "";

        const u = cacheUsuarios.find(function (x) {
            return String(x.id) === String(id);
        });

        const nombre = u ? `${u.usuario} (ID ${u.id})` : `ID ${id}`;

        if (accion === "bloquear") {
            confirmText.innerHTML =
                `¿Seguro que deseas <b>bloquear</b> a <b>${escapeHtml(nombre)}</b>?`;
        } else {
            confirmText.innerHTML =
                `¿Seguro que deseas <b>desbloquear</b> a <b>${escapeHtml(nombre)}</b>?`;
        }

        btnConfirm.disabled = false;
        btnConfirm.innerHTML = `<i class="bi bi-check2-circle me-1"></i> Confirmar`;

        modalConfirm.show();
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 13: BLOQUEAR / DESBLOQUEAR EN BACKEND
    |--------------------------------------------------------------------------
    */
    async function toggleEstado(id, accion) {
        try {
            btnConfirm.disabled = true;
            btnConfirm.innerHTML =
                `<span class="spinner-border spinner-border-sm me-2"></span>Procesando...`;

            const fd = new FormData();
            fd.append("id", id);
            fd.append("accion", accion);

            const res = await fetch("/app_descuento/usuarios/bloquear_usuario.php?action=toggle", {
                method: "POST",
                body: fd,
                credentials: "same-origin"
            });

            const data = await res.json();

            if (res.ok && data.ok) {
                showAlert(msgConfirm, "success", data.msg || "Actualizado correctamente.");

                await cargarUsuarios();

                setTimeout(function () {
                    modalConfirm.hide();
                }, 450);
            } else {
                showAlert(msgConfirm, "danger", data.msg || "No se pudo actualizar.");
            }

        } catch (e) {
            showAlert(msgConfirm, "danger", "No se pudo conectar con el servidor.");
        } finally {
            btnConfirm.disabled = false;
            btnConfirm.innerHTML = `<i class="bi bi-check2-circle me-1"></i> Confirmar`;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 14: RENDERIZAR PAGINACIÓN
    |--------------------------------------------------------------------------
    */
    function renderPaginacion(pages) {
        pagination.innerHTML = "";

        if (pages <= 1) {
            return;
        }

        const maxBtns = 7;
        const half = Math.floor(maxBtns / 2);

        let start = Math.max(1, page - half);
        let end = Math.min(pages, start + maxBtns - 1);

        start = Math.max(1, end - maxBtns + 1);

        pagination.appendChild(pageItem("«", page - 1, page === 1));

        if (start > 1) {
            pagination.appendChild(pageItem("1", 1, false, page === 1));

            if (start > 2) {
                pagination.appendChild(ellipsisItem());
            }
        }

        for (let p = start; p <= end; p++) {
            pagination.appendChild(pageItem(String(p), p, false, p === page));
        }

        if (end < pages) {
            if (end < pages - 1) {
                pagination.appendChild(ellipsisItem());
            }

            pagination.appendChild(pageItem(String(pages), pages, false, page === pages));
        }

        pagination.appendChild(pageItem("»", page + 1, page === pages));
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 15: CREAR BOTÓN DE PÁGINA
    |--------------------------------------------------------------------------
    */
    function pageItem(label, target, disabled = false, active = false) {
        const li = document.createElement("li");
        li.className = `page-item ${disabled ? "disabled" : ""} ${active ? "active" : ""}`;

        const a = document.createElement("a");
        a.className = "page-link";
        a.href = "#";
        a.textContent = label;

        a.addEventListener("click", function (e) {
            e.preventDefault();

            if (disabled) {
                return;
            }

            page = target;
            cargarUsuarios();
        });

        li.appendChild(a);

        return li;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 16: CREAR PUNTOS SUSPENSIVOS
    |--------------------------------------------------------------------------
    */
    function ellipsisItem() {
        const li = document.createElement("li");
        li.className = "page-item disabled";

        const span = document.createElement("span");
        span.className = "page-link";
        span.textContent = "...";

        li.appendChild(span);

        return li;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 17: MOSTRAR ALERTAS
    |--------------------------------------------------------------------------
    */
    function showAlert(el, type, text) {
        el.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0">
                <i class="bi ${type === "success" ? "bi-check-circle" : "bi-exclamation-triangle"} me-1"></i>
                ${escapeHtml(text)}
            </div>
        `;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 18: ESCAPAR HTML
    |--------------------------------------------------------------------------
    */
    function escapeHtml(str) {
        return String(str ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 19: CARGA INICIAL
    |--------------------------------------------------------------------------
    */
    cargarUsuarios();

})();
</script>