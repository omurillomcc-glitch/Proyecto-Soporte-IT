<?php
/*
|--------------------------------------------------------------------------
| ARCHIVO: vista_modificar_usuario.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Mostrar la pantalla para modificar usuarios.
| - Esta vista se carga dentro de index.php usando AJAX.
| - NO debe tener <!doctype html>, <html>, <head> ni <body>.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: VALIDAR SESIÓN
|--------------------------------------------------------------------------
| validar_sesion.php ya debe tener:
|
| session_name('SESION_DESCUENTOS');
| if (session_status() === PHP_SESSION_NONE) {
|     session_start();
| }
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/validar_sesion.php";

/*
|--------------------------------------------------------------------------
| PASO 2: VALIDAR PERMISO
|--------------------------------------------------------------------------
| Solo admin o super_admin pueden ver esta vista.
|--------------------------------------------------------------------------
*/
$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin", "super_admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para modificar usuarios.</div>';
    exit;
}
?>

<!--
|--------------------------------------------------------------------------
| PASO 3: CSS DE ESTA VISTA
|--------------------------------------------------------------------------
| Bootstrap ya se carga en index.php.
| Aquí solo cargamos tu CSS propio.
|--------------------------------------------------------------------------
-->
<link rel="stylesheet" href="/app_descuento/usuarios/agregar_usuario.css">

<style>
    /*
    |--------------------------------------------------------------------------
    | AJUSTES DE DISEÑO PARA MODIFICAR USUARIO
    |--------------------------------------------------------------------------
    */
    .section-wrap {
        max-width: 920px;
    }

    .section-card > .card-body {
        padding: 28px;
    }

    .table-responsive {
        padding-right: 10px;
    }

    .table {
        min-width: 760px;
    }

    .table thead th {
        padding: 16px 18px !important;
        white-space: nowrap;
    }

    .table tbody td {
        padding: 18px 18px !important;
        vertical-align: middle;
    }

    .table th.text-end,
    .table td.text-end {
        padding-right: 18px !important;
        min-width: 140px;
    }

    #selLimit {
        min-width: 160px;
    }

    .btn-action {
        border-radius: 14px !important;
        padding: 10px 14px !important;
        font-weight: 900 !important;
        white-space: nowrap;
    }

    @media (max-width: 768px) {
        .section-wrap {
            max-width: 560px;
        }

        .table {
            min-width: 720px;
        }

        .section-card > .card-body {
            padding: 18px;
        }
    }
</style>

<!--
|--------------------------------------------------------------------------
| PASO 4: CONTENIDO PRINCIPAL
|--------------------------------------------------------------------------
-->
<div class="section-wrap">

    <!-- ENCABEZADO -->
    <div class="section-head-card">
        <div class="section-head d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-pencil-square me-2"></i>Modificar usuario
                </h4>

                <p class="section-sub">
                    Edita usuario, nombre, rol y contraseña opcional.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-shield-lock"></i> Solo Admin
            </span>
        </div>
    </div>

    <!-- CARD PRINCIPAL -->
    <div class="card section-card mt-3">
        <div class="card-body">

            <!-- BUSCADOR -->
            <div class="section-divider">
                <i class="bi bi-search me-2"></i>Buscar
            </div>

            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Buscar por usuario o nombre</label>

                    <input
                        id="txtBuscar"
                        type="text"
                        class="form-control"
                        placeholder="Escriba para buscar..."
                    >
                </div>
            </div>

            <!-- MENSAJE -->
            <div id="msgList" class="mt-3"></div>

            <!-- TABLA -->
            <div class="table-responsive mt-3">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Rol</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>

                    <tbody id="tbodyUsuarios">
                        <tr>
                            <td colspan="5" class="text-muted">Cargando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN -->
            <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">

                <div class="text-muted small" id="lblPagerInfo"></div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <select id="selLimit" class="form-select">
                        <option value="100" selected>100 por página</option>
                        <option value="150">150 por página</option>
                        <option value="200">200 por página</option>
                    </select>

                    <nav>
                        <ul class="pagination mb-0" id="pagination"></ul>
                    </nav>

                </div>
            </div>

        </div>
    </div>
</div>

<!--
|--------------------------------------------------------------------------
| PASO 5: MODAL EDITAR
|--------------------------------------------------------------------------
-->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-person-gear me-2"></i>Editar usuario
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="formEditar" autocomplete="off">

                    <input type="hidden" name="id" id="editId">

                    <div class="row g-3">

                        <!-- ID -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">ID</label>

                            <input
                                type="text"
                                class="form-control"
                                id="editIdShow"
                                readonly
                            >
                        </div>

                        <!-- USUARIO -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Usuario</label>

                            <input
                                type="text"
                                class="form-control"
                                name="usuario"
                                id="editUsuario"
                                maxlength="30"
                                required
                            >

                            <div class="form-hint">
                                Solo letras. Debe ser único.
                            </div>
                        </div>

                        <!-- NOMBRE -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Nombre</label>

                            <input
                                type="text"
                                class="form-control"
                                name="nombre"
                                id="editNombre"
                                maxlength="100"
                                required
                            >

                            <div class="form-hint">
                                Solo letras y espacios.
                            </div>
                        </div>

                        <!-- ROL -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Rol</label>

                            <select class="form-select" name="rol" id="editRol" required>
                                <option value="usuario">Usuario</option>
                                <option value="admin">Administrador</option>
                            </select>
                        </div>

                        <!-- CONTRASEÑA -->
                        <div class="col-12">
                            <label class="form-label">Nueva contraseña opcional</label>

                            <div class="input-group">
                                <input
                                    type="password"
                                    class="form-control"
                                    name="password"
                                    id="editPass"
                                    placeholder="Deja vacío para no cambiar"
                                >

                                <button
                                    class="btn btn-outline-secondary"
                                    type="button"
                                    id="btnTogglePass"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>

                            <div class="form-hint">
                                Si la llenas: mínimo 6 caracteres. Letras, números y punto.
                            </div>
                        </div>

                    </div>

                    <!-- MENSAJE MODAL -->
                    <div id="msgEdit" class="mt-3"></div>

                </form>
            </div>

            <div class="modal-footer">
                <button class="btn btn-soft" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>

                <button class="btn btn-main" form="formEditar" type="submit">
                    <i class="bi bi-check2-circle me-1"></i> Guardar cambios
                </button>
            </div>

        </div>
    </div>
</div>

<script>
(function () {

    /*
    |--------------------------------------------------------------------------
    | PASO 6: OBTENER ELEMENTOS
    |--------------------------------------------------------------------------
    */
    const tbody        = document.getElementById("tbodyUsuarios");
    const txtBuscar    = document.getElementById("txtBuscar");
    const msgList      = document.getElementById("msgList");
    const selLimit     = document.getElementById("selLimit");
    const lblPagerInfo = document.getElementById("lblPagerInfo");
    const pagination   = document.getElementById("pagination");

    const modalEditarEl = document.getElementById("modalEditar");
    const formEditar    = document.getElementById("formEditar");
    const msgEdit       = document.getElementById("msgEdit");

    const editId       = document.getElementById("editId");
    const editIdShow   = document.getElementById("editIdShow");
    const editUsuario  = document.getElementById("editUsuario");
    const editNombre   = document.getElementById("editNombre");
    const editRol      = document.getElementById("editRol");
    const editPass     = document.getElementById("editPass");
    const btnTogglePass = document.getElementById("btnTogglePass");

    if (!tbody || !txtBuscar || !modalEditarEl || !formEditar) {
        return;
    }

    const modalEditar = new bootstrap.Modal(modalEditarEl);

    let cacheUsuarios = [];
    let page = 1;
    let limit = parseInt(selLimit.value || "100", 10);

    /*
    |--------------------------------------------------------------------------
    | PASO 7: VALIDAR USUARIO EN VIVO
    |--------------------------------------------------------------------------
    */
    editUsuario.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 8: VALIDAR NOMBRE EN VIVO
    |--------------------------------------------------------------------------
    */
    editNombre.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ\s]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 9: VALIDAR CONTRASEÑA EN VIVO
    |--------------------------------------------------------------------------
    */
    editPass.addEventListener("input", function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, "");
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 10: VER / OCULTAR CONTRASEÑA
    |--------------------------------------------------------------------------
    */
    btnTogglePass.addEventListener("click", function () {
        const isPass = editPass.type === "password";

        editPass.type = isPass ? "text" : "password";

        btnTogglePass.innerHTML = isPass
            ? '<i class="bi bi-eye-slash"></i>'
            : '<i class="bi bi-eye"></i>';
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 11: BUSCAR CON ESPERA
    |--------------------------------------------------------------------------
    */
    let timerBusqueda = null;

    txtBuscar.addEventListener("input", function () {
        clearTimeout(timerBusqueda);

        timerBusqueda = setTimeout(function () {
            page = 1;
            cargarUsuarios();
        }, 250);
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 12: CAMBIAR CANTIDAD POR PÁGINA
    |--------------------------------------------------------------------------
    */
    selLimit.addEventListener("change", function () {
        limit = parseInt(selLimit.value || "100", 10);
        page = 1;
        cargarUsuarios();
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 13: CARGAR USUARIOS
    |--------------------------------------------------------------------------
    */
    async function cargarUsuarios() {
        msgList.innerHTML = "";
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-muted">Cargando...</td>
            </tr>
        `;

        try {
            const q = encodeURIComponent((txtBuscar.value || "").trim());

            const url =
                `/app_descuento/usuarios/modificar_usuario.php?action=list&page=${page}&limit=${limit}&q=${q}`;

            const res = await fetch(url, {
                cache: "no-store",
                credentials: "same-origin"
            });

            const data = await res.json();

            if (!res.ok || !data.ok) {
                throw new Error(data.msg || `HTTP ${res.status}`);
            }

            cacheUsuarios = data.usuarios || [];

            const total = parseInt(data.total || 0, 10);
            const pages = parseInt(data.pages || 1, 10);

            if (page > pages) {
                page = pages;
                return cargarUsuarios();
            }

            const from = total === 0 ? 0 : ((page - 1) * limit + 1);
            const to = Math.min(page * limit, total);

            lblPagerInfo.textContent =
                `Mostrando ${from}-${to} de ${total} (página ${page} de ${pages})`;

            renderTabla();
            renderPagination(pages);

        } catch (e) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-danger">No se pudo cargar.</td>
                </tr>
            `;

            showAlert(msgList, "danger", e.message);
            lblPagerInfo.textContent = "";
            pagination.innerHTML = "";
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 14: MOSTRAR TABLA
    |--------------------------------------------------------------------------
    */
    function renderTabla() {
        if (cacheUsuarios.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-muted">Sin resultados.</td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = cacheUsuarios.map(function (u) {
            return `
                <tr>
                    <td>${escapeHtml(u.id)}</td>
                    <td class="fw-semibold">${escapeHtml(u.usuario)}</td>
                    <td>${escapeHtml(u.nombre)}</td>
                    <td>${escapeHtml(u.rol)}</td>
                    <td class="text-end">
                        <button class="btn btn-soft btn-sm btn-action" data-id="${escapeHtml(u.id)}">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                    </td>
                </tr>
            `;
        }).join("");

        tbody.querySelectorAll("button[data-id]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                abrirEditar(btn.getAttribute("data-id"));
            });
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 15: PAGINACIÓN
    |--------------------------------------------------------------------------
    */
    function renderPagination(pages) {
        pagination.innerHTML = "";

        if (pages <= 1) {
            return;
        }

        pagination.appendChild(makeItem("«", page - 1, false, page === 1));

        let start = Math.max(1, page - 3);
        let end = Math.min(pages, page + 3);

        if (page <= 4) {
            end = Math.min(pages, 7);
        }

        if (page >= pages - 3) {
            start = Math.max(1, pages - 6);
        }

        for (let i = start; i <= end; i++) {
            pagination.appendChild(makeItem(String(i), i, i === page, false));
        }

        pagination.appendChild(makeItem("»", page + 1, false, page === pages));
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 16: CREAR BOTÓN DE PÁGINA
    |--------------------------------------------------------------------------
    */
    function makeItem(label, targetPage, active = false, disabled = false) {
        const li = document.createElement("li");
        li.className = `page-item ${active ? "active" : ""} ${disabled ? "disabled" : ""}`;

        const a = document.createElement("a");
        a.className = "page-link";
        a.href = "#";
        a.textContent = label;

        if (!disabled) {
            a.addEventListener("click", function (e) {
                e.preventDefault();
                page = targetPage;
                cargarUsuarios();
            });
        }

        li.appendChild(a);

        return li;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 17: ABRIR MODAL EDITAR
    |--------------------------------------------------------------------------
    */
    async function abrirEditar(id) {
        msgEdit.innerHTML = "";
        editPass.value = "";

        try {
            const res = await fetch(
                `/app_descuento/usuarios/modificar_usuario.php?action=get&id=${encodeURIComponent(id)}`,
                {
                    cache: "no-store",
                    credentials: "same-origin"
                }
            );

            const data = await res.json();

            if (!res.ok || !data.ok) {
                throw new Error(data.msg || "Error");
            }

            const u = data.usuario;

            editId.value = u.id;
            editIdShow.value = u.id;
            editUsuario.value = u.usuario;
            editNombre.value = u.nombre;
            editRol.value = u.rol;

            modalEditar.show();

        } catch (e) {
            showAlert(msgList, "danger", "No se pudo abrir el usuario.");
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 18: GUARDAR CAMBIOS
    |--------------------------------------------------------------------------
    */
    formEditar.addEventListener("submit", async function (e) {
        e.preventDefault();

        msgEdit.innerHTML = "";

        const p = (editPass.value || "").trim();

        if (p.length > 0) {
            if (p.length < 6) {
                showAlert(msgEdit, "danger", "La contraseña debe tener al menos 6 caracteres.");
                return;
            }

            if (!/^[A-Za-z0-9.]+$/.test(p)) {
                showAlert(msgEdit, "danger", "La contraseña solo permite letras, números y punto.");
                return;
            }
        }

        try {
            const fd = new FormData(formEditar);

            const res = await fetch("/app_descuento/usuarios/modificar_usuario.php?action=update", {
                method: "POST",
                body: fd,
                credentials: "same-origin"
            });

            const data = await res.json();

            if (res.ok && data.ok) {
                showAlert(msgEdit, "success", data.msg || "Actualizado correctamente.");

                await cargarUsuarios();

                setTimeout(function () {
                    modalEditar.hide();
                }, 450);

            } else {
                showAlert(msgEdit, "danger", data.msg || "No se pudo actualizar.");
            }

        } catch (e) {
            showAlert(msgEdit, "danger", "No se pudo conectar con el servidor.");
        }
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 19: MOSTRAR ALERTAS
    |--------------------------------------------------------------------------
    */
    function showAlert(el, type, text) {
        el.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0">
                <i class="bi ${type === "success" ? "bi-check-circle" : "bi-exclamation-triangle"} me-1"></i>
                ${escapeHtml(text)}
            </div>
        `;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 20: ESCAPAR HTML
    |--------------------------------------------------------------------------
    */
    function escapeHtml(str) {
        return String(str ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 21: CARGA INICIAL
    |--------------------------------------------------------------------------
    */
    cargarUsuarios();

})();
</script>