<?php
header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| VALIDAR SESIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/validar_sesion.php";

/*
|--------------------------------------------------------------------------
| CONEXIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/conexion.php";

$response = ["ok" => false, "msg" => ""];

function is_admin(): bool {
  return isset($_SESSION['usuario_id'], $_SESSION['rol']) && $_SESSION['rol'] === 'admin';
}

function auditoria(mysqli $conn, int $usuario_id, string $accion, string $detalle): void {
  $ip = $_SERVER['REMOTE_ADDR'] ?? null;

  $stmt = $conn->prepare("INSERT INTO auditoria (usuario_id, accion, detalle, ip) VALUES (?, ?, ?, ?)");
  if ($stmt) {
    $stmt->bind_param("isss", $usuario_id, $accion, $detalle, $ip);
    $stmt->execute();
    $stmt->close();
  }
}

try {
  if (!isset($_SESSION['usuario_id'])) {
    throw new Exception("No autenticado.");
  }
  if (!is_admin()) {
    throw new Exception("No autorizado.");
  }

  $action = $_GET['action'] ?? '';

  // =========================
  // LISTAR (GET)
  // =========================
  if ($action === 'list') {

    $page  = max(1, (int)($_GET['page'] ?? 1));
    $limit = (int)($_GET['limit'] ?? 50);
    if (!in_array($limit, [50,100,150], true)) $limit = 50;

    $q = trim($_GET['q'] ?? '');
    $offset = ($page - 1) * $limit;

    // TOTAL
    if ($q !== "") {
      $like = "%{$q}%";
      $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM usuarios WHERE usuario LIKE ? OR nombre LIKE ?");
      $stmt->bind_param("ss", $like, $like);
    } else {
      $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM usuarios");
    }

    $stmt->execute();
    $total = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();

    $pages = max(1, (int)ceil($total / $limit));
    if ($page > $pages) $page = $pages;

    // DATA
    if ($q !== "") {
      $like = "%{$q}%";
      $sql = "SELECT id, usuario, nombre, rol, estado
              FROM usuarios
              WHERE usuario LIKE ? OR nombre LIKE ?
              ORDER BY id DESC
              LIMIT ? OFFSET ?";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("ssii", $like, $like, $limit, $offset);
    } else {
      $sql = "SELECT id, usuario, nombre, rol, estado
              FROM usuarios
              ORDER BY id DESC
              LIMIT ? OFFSET ?";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("ii", $limit, $offset);
    }

    $stmt->execute();
    $res = $stmt->get_result();

    $usuarios = [];
    while ($row = $res->fetch_assoc()) {
      $usuarios[] = [
        "id" => (int)$row["id"],
        "usuario" => $row["usuario"],
        "nombre" => $row["nombre"],
        "rol" => $row["rol"],
        "estado" => $row["estado"] ?? "activo",
      ];
    }
    $stmt->close();

    $response["ok"] = true;
    $response["usuarios"] = $usuarios;
    $response["total"] = $total;
    $response["page"] = $page;
    $response["pages"] = $pages;

    echo json_encode($response);
    exit;
  }

  // =========================
  // TOGGLE (POST)
  // =========================
  if ($action === 'toggle') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      throw new Exception("Método no permitido.");
    }

    $id = (int)($_POST['id'] ?? 0);
    $accion = trim($_POST['accion'] ?? ''); // bloquear | desbloquear

    if ($id <= 0) throw new Exception("ID inválido.");
    if ($accion !== 'bloquear' && $accion !== 'desbloquear') throw new Exception("Acción inválida.");

    // No permitir bloquearse a sí mismo
    if ((int)$_SESSION['usuario_id'] === $id) {
      throw new Exception("No puedes bloquear tu propio usuario.");
    }

    // Buscar usuario objetivo
    $stmt = $conn->prepare("SELECT id, usuario, estado FROM usuarios WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result();
    if (!$r || $r->num_rows === 0) {
      $stmt->close();
      throw new Exception("Usuario no encontrado.");
    }
    $u = $r->fetch_assoc();
    $stmt->close();

    $nuevoEstado = ($accion === 'bloquear') ? 'bloqueado' : 'activo';

    // Update estado
    $stmt = $conn->prepare("UPDATE usuarios SET estado = ? WHERE id = ? LIMIT 1");
    $stmt->bind_param("si", $nuevoEstado, $id);
    if (!$stmt->execute()) {
      $stmt->close();
      throw new Exception("No se pudo actualizar el estado.");
    }
    $stmt->close();

// Auditoría
$adminId = (int)$_SESSION['usuario_id'];

$accionAud = ($accion === 'bloquear')
  ? "USUARIO_BLOQUEADO"
  : "USUARIO_DESBLOQUEADO";

$detalle = "USUARIO={$u['usuario']} | ID={$id} | ESTADO={$nuevoEstado}";

auditoria($conn, $adminId, $accionAud, $detalle);

    $response["ok"] = true;
    $response["msg"] = ($accion === 'bloquear')
      ? "Usuario bloqueado correctamente."
      : "Usuario desbloqueado correctamente.";

    echo json_encode($response);
    exit;
  }

  throw new Exception("Acción inválida.");

} catch (Exception $e) {
  $response["msg"] = $e->getMessage();
  echo json_encode($response);
}
