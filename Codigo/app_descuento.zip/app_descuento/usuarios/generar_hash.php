<?php
echo password_hash("adminmcc.10", PASSWORD_BCRYPT);

