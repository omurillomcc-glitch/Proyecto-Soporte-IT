<?php
/*
|--------------------------------------------------------------------------
| 1) INDICAR QUE LA RESPUESTA SERÁ JSON
|--------------------------------------------------------------------------
*/
header('Content-Type: application/json; charset=utf-8');
/*
|--------------------------------------------------------------------------
| 2) INICIAR SESIÓN
|--------------------------------------------------------------------------
*/
session_name('APP_DESCUENTO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| 3) CONEXIÓN A LA BASE DE DATOS
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/conexion.php";

/*
|--------------------------------------------------------------------------
| 4) RESPUESTA INICIAL
|--------------------------------------------------------------------------
*/
$response = [
    "ok"  => false,
    "msg" => ""
];


/*
|--------------------------------------------------------------------------
| 5) FUNCIÓN PARA REGISTRAR AUDITORÍA
|--------------------------------------------------------------------------
*/
function registrar_auditoria(mysqli $conn, int $usuario_id, string $accion, string $detalle): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    $stmt = $conn->prepare(
        "INSERT INTO auditoria (usuario_id, accion, detalle, ip)
         VALUES (?, ?, ?, ?)"
    );

    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $accion, $detalle, $ip);
        $stmt->execute();
        $stmt->close();
    }
}


/*
|--------------------------------------------------------------------------
| 6) PROCESO PRINCIPAL DEL LOGIN
|--------------------------------------------------------------------------
*/
try {

    /*
    |--------------------------------------------------------------------------
    | Validar que la petición sea POST
    |--------------------------------------------------------------------------
    */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método no permitido.");
    }


    /*
    |--------------------------------------------------------------------------
    | Recibir usuario y contraseña
    |--------------------------------------------------------------------------
    */
    $usuario  = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');


    /*
    |--------------------------------------------------------------------------
    | Validar campos vacíos
    |--------------------------------------------------------------------------
    */
    if ($usuario === "" || $password === "") {
        throw new Exception("Usuario y contraseña son obligatorios.");
    }


    /*
    |--------------------------------------------------------------------------
    | Validar largo máximo del usuario
    |--------------------------------------------------------------------------
    */
    if (mb_strlen($usuario, 'UTF-8') > 30) {
        throw new Exception("El usuario no puede tener más de 30 letras.");
    }


    /*
    |--------------------------------------------------------------------------
    | Validar que el usuario solo tenga letras
    |--------------------------------------------------------------------------
    */
    if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$/u', $usuario)) {
        throw new Exception("El usuario solo puede contener letras.");
    }


    /*
    |--------------------------------------------------------------------------
    | Validar mínimo de contraseña
    |--------------------------------------------------------------------------
    | No mostramos mensajes específicos por seguridad.
    |--------------------------------------------------------------------------
    */
    if (strlen($password) < 6) {
        throw new Exception("Usuario o contraseña incorrectos.");
    }


    /*
    |--------------------------------------------------------------------------
    | Buscar usuario en la base de datos
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare(
        "SELECT id, usuario, password, nombre, rol, estado
         FROM usuarios
         WHERE usuario = ?
         LIMIT 1"
    );

    if (!$stmt) {
        throw new Exception("Error preparando consulta.");
    }

    $stmt->bind_param("s", $usuario);
    $stmt->execute();

    $result = $stmt->get_result();


    /*
    |--------------------------------------------------------------------------
    | Validar si el usuario existe
    |--------------------------------------------------------------------------
    */
    if (!$result || $result->num_rows === 0) {
        $stmt->close();
        throw new Exception("Usuario o contraseña incorrectos.");
    }


    /*
    |--------------------------------------------------------------------------
    | Obtener datos del usuario
    |--------------------------------------------------------------------------
    */
    $row = $result->fetch_assoc();
    $stmt->close();

    $userId = (int)$row['id'];


    /*
    |--------------------------------------------------------------------------
    | Validar si el usuario está bloqueado
    |--------------------------------------------------------------------------
    */
    if ($row['estado'] === 'bloqueado') {
        registrar_auditoria(
            $conn,
            $userId,
            "LOGIN_BLOQUEADO",
            "Intento de login con usuario bloqueado: {$row['usuario']}"
        );

        throw new Exception("Usuario bloqueado. Contacte al administrador.");
    }


    /*
    |--------------------------------------------------------------------------
    | Validar contraseña encriptada
    |--------------------------------------------------------------------------
    */
    if (!password_verify($password, $row['password'])) {
        registrar_auditoria(
            $conn,
            $userId,
            "LOGIN_FAIL",
            "Contraseña incorrecta para usuario: {$row['usuario']}"
        );

        throw new Exception("Usuario o contraseña incorrectos.");
    }


    /*
    |--------------------------------------------------------------------------
    | Regenerar ID de sesión por seguridad
    |--------------------------------------------------------------------------
    */
    session_regenerate_id(true);


    /*
    |--------------------------------------------------------------------------
    | Guardar datos del usuario en sesión
    |--------------------------------------------------------------------------
    */
    $_SESSION['usuario_id'] = $userId;
    $_SESSION['usuario']    = $row['usuario'];
    $_SESSION['nombre']     = $row['nombre'];
    $_SESSION['rol']        = $row['rol'];


    /*
    |--------------------------------------------------------------------------
    | Guardar tiempo de sesión
    |--------------------------------------------------------------------------
    | CREATED:
    | - Momento exacto en que inició sesión.
    |
    | LAST_ACTIVITY:
    | - Última actividad del usuario.
    |
    | Esto se usa con validar_sesion.php.
    |--------------------------------------------------------------------------
    */
  $_SESSION['CREATED'] = time();
  $_SESSION['LAST_ACTIVITY'] = time();


    /*
    |--------------------------------------------------------------------------
    | Registrar login correcto en auditoría
    |--------------------------------------------------------------------------
    */
    registrar_auditoria(
        $conn,
        $userId,
        "LOGIN_OK",
        "Inicio de sesión correcto: {$row['usuario']}"
    );


    /*
    |--------------------------------------------------------------------------
    | Respuesta correcta al frontend
    |--------------------------------------------------------------------------
    */
    $response["ok"]  = true;
    $response["msg"] = "Login correcto.";


} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | Respuesta si ocurre error
    |--------------------------------------------------------------------------
    */
    $response["msg"] = $e->getMessage();
}


/*
|--------------------------------------------------------------------------
| 7) DEVOLVER RESPUESTA JSON
|--------------------------------------------------------------------------
*/
echo json_encode($response);