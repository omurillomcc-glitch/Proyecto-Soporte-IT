<?php
/*
|--------------------------------------------------------------------------
| ARCHIVO: agregar_usuario.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Validar sesión
| - Validar que solo admin pueda agregar usuarios
| - Validar datos del formulario
| - Guardar usuario
| - Guardar auditoría
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| 1) RESPUESTA JSON
|--------------------------------------------------------------------------
*/
header("Content-Type: application/json; charset=utf-8");

/*
|--------------------------------------------------------------------------
| 2) VALIDAR SESIÓN
|--------------------------------------------------------------------------
| validar_sesion.php ya hace:
| - session_start()
| - validación de login
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/validar_sesion.php';

/*
|--------------------------------------------------------------------------
| 3) CONEXIÓN MYSQL
|--------------------------------------------------------------------------
*/
require_once __DIR__. "/conexion.php";

/*
|--------------------------------------------------------------------------
| 4) RESPUESTA BASE
|--------------------------------------------------------------------------
*/
$response = [
    "ok"  => false,
    "msg" => ""
];

try {

    /*
    |--------------------------------------------------------------------------
    | 5) VALIDAR MÉTODO POST
    |--------------------------------------------------------------------------
    */
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        throw new Exception("Método no permitido.");
    }

    /*
    |--------------------------------------------------------------------------
    | 6) VALIDAR SESIÓN ADMIN
    |--------------------------------------------------------------------------
    */
    if (!isset($_SESSION["usuario_id"]) || !isset($_SESSION["rol"])) {
        throw new Exception("No autorizado. Inicia sesión.");
    }

    if ($_SESSION["rol"] !== "admin") {
        throw new Exception("No autorizado. Solo administradores pueden agregar usuarios.");
    }

    /*
    |--------------------------------------------------------------------------
    | 7) DATOS DEL ADMIN
    |--------------------------------------------------------------------------
    */
    $admin_id = (int)$_SESSION["usuario_id"];

    /*
    |--------------------------------------------------------------------------
    | 8) RECIBIR DATOS
    |--------------------------------------------------------------------------
    */
    $usuario  = trim($_POST["usuario"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $nombre   = trim($_POST["nombre"] ?? "");
    $rol      = trim($_POST["rol"] ?? "usuario");

    /*
    |--------------------------------------------------------------------------
    | 9) VALIDAR CAMPOS VACÍOS
    |--------------------------------------------------------------------------
    */
    if ($usuario === "" || $password === "" || $nombre === "") {
        throw new Exception("Todos los campos son obligatorios.");
    }

    /*
    |--------------------------------------------------------------------------
    | 10) VALIDAR USUARIO
    |--------------------------------------------------------------------------
    | - máximo 30 letras
    | - solo letras
    |--------------------------------------------------------------------------
    */
    if (mb_strlen($usuario, "UTF-8") > 30) {
        throw new Exception("El usuario no puede tener más de 30 letras.");
    }

    if (!preg_match("/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$/u", $usuario)) {
        throw new Exception("El usuario solo puede contener letras.");
    }

    /*
    |--------------------------------------------------------------------------
    | 11) VALIDAR NOMBRE
    |--------------------------------------------------------------------------
    */
    $nombre = preg_replace('/\s+/', ' ', $nombre);

    if (!preg_match("/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]+$/u", $nombre)) {
        throw new Exception("El nombre solo puede contener letras y espacios.");
    }

    /*
    |--------------------------------------------------------------------------
    | 12) VALIDAR CONTRASEÑA
    |--------------------------------------------------------------------------
    */
    if (strlen($password) < 6) {
        throw new Exception("La contraseña debe tener al menos 6 caracteres.");
    }

    if (!preg_match("/^[A-Za-z0-9.]+$/", $password)) {
        throw new Exception("La contraseña solo puede contener letras, números y punto (.)");
    }

    /*
    |--------------------------------------------------------------------------
    | 13) VALIDAR ROL
    |--------------------------------------------------------------------------
    */
    if ($rol !== "admin" && $rol !== "usuario") {
        throw new Exception("Rol inválido.");
    }

    /*
    |--------------------------------------------------------------------------
    | 14) VALIDAR USUARIO ÚNICO
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare("
        SELECT id 
        FROM usuarios 
        WHERE usuario = ? 
        LIMIT 1
    ");

    if (!$stmt) {
        throw new Exception("Error preparando consulta.");
    }

    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        throw new Exception("El usuario ya existe.");
    }

    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | 15) ENCRIPTAR CONTRASEÑA
    |--------------------------------------------------------------------------
    */
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    /*
    |--------------------------------------------------------------------------
    | 16) INICIAR TRANSACCIÓN
    |--------------------------------------------------------------------------
    */
    $conn->begin_transaction();

    /*
    |--------------------------------------------------------------------------
    | 17) INSERTAR USUARIO
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare("
        INSERT INTO usuarios 
            (usuario, password, nombre, rol) 
        VALUES 
            (?, ?, ?, ?)
    ");

    if (!$stmt) {
        $conn->rollback();
        throw new Exception("Error preparando inserción.");
    }

    $stmt->bind_param(
        "ssss",
        $usuario,
        $passwordHash,
        $nombre,
        $rol
    );

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        throw new Exception("Error al guardar el usuario.");
    }

    /*
    |--------------------------------------------------------------------------
    | 18) OBTENER ID NUEVO
    |--------------------------------------------------------------------------
    */
    $nuevoUsuarioId = (int)$conn->insert_id;

    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | 19) AUDITORÍA
    |--------------------------------------------------------------------------
    */
    $accion = "USUARIO_AGREGADO";

    $detalle = "USUARIO={$usuario} | ID={$nuevoUsuarioId} | NOMBRE={$nombre} | ROL={$rol}";

    $ip = $_SERVER["REMOTE_ADDR"] ?? null;

    /*
    |--------------------------------------------------------------------------
    | 20) INSERTAR AUDITORÍA
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare("
        INSERT INTO auditoria
            (usuario_id, accion, detalle, ip)
        VALUES
            (?, ?, ?, ?)
    ");

    if (!$stmt) {
        $conn->rollback();
        throw new Exception("Usuario creado, pero falló auditoría.");
    }

    $stmt->bind_param(
        "isss",
        $admin_id,
        $accion,
        $detalle,
        $ip
    );

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        throw new Exception("Usuario creado, pero falló auditoría.");
    }

    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | 21) CONFIRMAR TRANSACCIÓN
    |--------------------------------------------------------------------------
    */
    $conn->commit();

    /*
    |--------------------------------------------------------------------------
    | 22) RESPUESTA EXITOSA
    |--------------------------------------------------------------------------
    */
    $response["ok"] = true;
    $response["msg"] = "Usuario agregado correctamente.";

} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | 23) ROLLBACK
    |--------------------------------------------------------------------------
    */
    if (isset($conn) && $conn instanceof mysqli) {
        @ $conn->rollback();
    }

    /*
    |--------------------------------------------------------------------------
    | 24) RESPUESTA ERROR
    |--------------------------------------------------------------------------
    */
    $response["msg"] = $e->getMessage();
}

/*
|--------------------------------------------------------------------------
| 25) DEVOLVER JSON
|--------------------------------------------------------------------------
*/
echo json_encode(
    $response,
    JSON_UNESCAPED_UNICODE
);