<?php
declare(strict_types=1);

/*

|--------------------------------------------------------------------------
| 1) INICIAR SESIÓN SI NO ESTÁ INICIADA
|--------------------------------------------------------------------------
*/
session_name('APP_DESCUENTO');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| 2) DEFINIR TIEMPO MÁXIMO DE SESIÓN
|--------------------------------------------------------------------------
| 86400 segundos = 24 horas = 1 día
|--------------------------------------------------------------------------
*/
define('SESSION_TIMEOUT', 86400);


/*
|--------------------------------------------------------------------------
| 3) FUNCIÓN PARA CERRAR SESIÓN COMPLETAMENTE
|--------------------------------------------------------------------------
| Esta función:
| - Limpia variables de sesión
| - Elimina cookie de sesión
| - Destruye la sesión
| - Redirige al login
|--------------------------------------------------------------------------
*/
function cerrar_sesion(): void
{
    /*
    |--------------------------------------------------------------------------
    | LIMPIAR VARIABLES DE SESIÓN
    |--------------------------------------------------------------------------
    */
    $_SESSION = [];


    /*
    |--------------------------------------------------------------------------
    | ELIMINAR COOKIE DE SESIÓN
    |--------------------------------------------------------------------------
    */
    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }


    /*
    |--------------------------------------------------------------------------
    | DESTRUIR SESIÓN
    |--------------------------------------------------------------------------
    */
    session_destroy();


    /*
    |--------------------------------------------------------------------------
    | REDIRIGIR AL LOGIN
    |--------------------------------------------------------------------------
    */
    header('Location: /app_descuento/usuarios/login.html?expired=1');
    exit;
}


/*
|--------------------------------------------------------------------------
| 4) VALIDAR SI EL USUARIO INICIÓ SESIÓN
|--------------------------------------------------------------------------
| Si no existe usuario_id:
| - Redirigir al login
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['usuario_id'])) {

   header('Location: /app_descuento/usuarios/login.html');
    exit;
}


/*
|--------------------------------------------------------------------------
| 5) CREAR FECHA DE INICIO DE SESIÓN
|--------------------------------------------------------------------------
| CREATED:
| Guarda la hora exacta en que inició sesión.
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['CREATED'])) {

    $_SESSION['CREATED'] = time();
}


/*
|--------------------------------------------------------------------------
| 6) CREAR ÚLTIMA ACTIVIDAD
|--------------------------------------------------------------------------
| LAST_ACTIVITY:
| Guarda la última vez que el usuario utilizó el sistema.
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['LAST_ACTIVITY'])) {

    $_SESSION['LAST_ACTIVITY'] = time();
}


/*
|--------------------------------------------------------------------------
| 7) VALIDAR TIEMPO TOTAL DE SESIÓN
|--------------------------------------------------------------------------
| Si ya pasó 1 día desde el login:
| - Cerrar sesión automáticamente
|--------------------------------------------------------------------------
*/
if ((time() - (int) $_SESSION['CREATED']) > SESSION_TIMEOUT) {

    cerrar_sesion();
}


/*
|--------------------------------------------------------------------------
| 8) VALIDAR INACTIVIDAD
|--------------------------------------------------------------------------
| Si el usuario estuvo inactivo más de 1 día:
| - Cerrar sesión automáticamente
|--------------------------------------------------------------------------
*/
if ((time() - (int) $_SESSION['LAST_ACTIVITY']) > SESSION_TIMEOUT) {

    cerrar_sesion();
}


/*
|--------------------------------------------------------------------------
| 9) ACTUALIZAR ÚLTIMA ACTIVIDAD
|--------------------------------------------------------------------------
| Cada vez que el usuario entra a una página protegida,
| se actualiza el tiempo de actividad.
|--------------------------------------------------------------------------
*/
$_SESSION['LAST_ACTIVITY'] = time();
?>