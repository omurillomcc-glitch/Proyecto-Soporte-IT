<?php
header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| VALIDAR SESIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/validar_sesion.php';

/*
|--------------------------------------------------------------------------
| CONEXIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/conexion.php";

/*
|--------------------------------------------------------------------------
| RESPUESTA BASE
|--------------------------------------------------------------------------
*/
$response = [
    "ok" => false,
    "msg" => ""
];

/*
|--------------------------------------------------------------------------
| 1) VALIDAR ADMIN
|--------------------------------------------------------------------------
*/
function require_admin(): void
{
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode(["ok" => false, "msg" => "No autorizado. Inicia sesión."]);
        exit;
    }

    if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
        http_response_code(403);
        echo json_encode(["ok" => false, "msg" => "Acceso denegado. Solo admin."]);
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| 2) LIMPIAR TEXTO
|--------------------------------------------------------------------------
*/
function clean(string $s): string
{
    return trim($s);
}

/*
|--------------------------------------------------------------------------
| 3) GUARDAR AUDITORÍA
|--------------------------------------------------------------------------
*/
function auditoria(mysqli $conn, int $usuario_id, string $accion, string $detalle): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    if ($ip === '::1') {
        $ip = 'LOCALHOST';
    }

    $stmt = $conn->prepare("
        INSERT INTO auditoria (usuario_id, accion, detalle, ip)
        VALUES (?, ?, ?, ?)
    ");

    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $accion, $detalle, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

try {

    /*
    |--------------------------------------------------------------------------
    | 4) PROTEGER ARCHIVO
    |--------------------------------------------------------------------------
    */
    require_admin();

    $action = $_GET['action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | 5) LISTAR USUARIOS
    |--------------------------------------------------------------------------
    */
    if ($action === 'list') {

        $page  = max(1, (int)($_GET['page'] ?? 1));
        $limit = (int)($_GET['limit'] ?? 50);
        $limit = max(1, min(200, $limit));
        $offset = ($page - 1) * $limit;

        $q = clean($_GET['q'] ?? '');

        /*
        |--------------------------------------------------------------------------
        | 5.1) CONTAR TOTAL
        |--------------------------------------------------------------------------
        */
        if ($q !== '') {
            $like = "%{$q}%";

            $stmt = $conn->prepare("
                SELECT COUNT(*) total 
                FROM usuarios 
                WHERE usuario LIKE ? OR nombre LIKE ?
            ");

            if (!$stmt) {
                throw new Exception("Error preparando COUNT.");
            }

            $stmt->bind_param("ss", $like, $like);
            $stmt->execute();
            $total = (int)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
            $stmt->close();

            /*
            |--------------------------------------------------------------------------
            | 5.2) LISTAR CON BÚSQUEDA
            |--------------------------------------------------------------------------
            */
            $stmt = $conn->prepare("
                SELECT id, usuario, nombre, rol, created_at
                FROM usuarios
                WHERE usuario LIKE ? OR nombre LIKE ?
                ORDER BY id DESC
                LIMIT ? OFFSET ?
            ");

            if (!$stmt) {
                throw new Exception("Error preparando LIST.");
            }

            $stmt->bind_param("ssii", $like, $like, $limit, $offset);
            $stmt->execute();
            $res = $stmt->get_result();

        } else {

            /*
            |--------------------------------------------------------------------------
            | 5.3) CONTAR SIN BÚSQUEDA
            |--------------------------------------------------------------------------
            */
            $totalRes = $conn->query("SELECT COUNT(*) total FROM usuarios");

            if (!$totalRes) {
                throw new Exception("Error en COUNT total.");
            }

            $total = (int)($totalRes->fetch_assoc()['total'] ?? 0);

            /*
            |--------------------------------------------------------------------------
            | 5.4) LISTAR SIN BÚSQUEDA
            |--------------------------------------------------------------------------
            */
            $stmt = $conn->prepare("
                SELECT id, usuario, nombre, rol, created_at
                FROM usuarios
                ORDER BY id DESC
                LIMIT ? OFFSET ?
            ");

            if (!$stmt) {
                throw new Exception("Error preparando LIST.");
            }

            $stmt->bind_param("ii", $limit, $offset);
            $stmt->execute();
            $res = $stmt->get_result();
        }

        /*
        |--------------------------------------------------------------------------
        | 5.5) ARMAR RESPUESTA
        |--------------------------------------------------------------------------
        */
        $usuarios = [];

        while ($row = $res->fetch_assoc()) {
            $usuarios[] = $row;
        }

        $stmt->close();

        $pages = (int)ceil(($total > 0 ? $total : 1) / $limit);

        echo json_encode([
            "ok"       => true,
            "usuarios" => $usuarios,
            "page"     => $page,
            "limit"    => $limit,
            "total"    => $total,
            "pages"    => $pages
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | 6) OBTENER UN USUARIO
    |--------------------------------------------------------------------------
    */
    if ($action === 'get') {

        $id = (int)($_GET['id'] ?? 0);

        if ($id <= 0) {
            throw new Exception("ID inválido.");
        }

        $stmt = $conn->prepare("
            SELECT id, usuario, nombre, rol 
            FROM usuarios 
            WHERE id = ? 
            LIMIT 1
        ");

        if (!$stmt) {
            throw new Exception("Error preparando GET.");
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $r = $stmt->get_result();

        if (!$r || $r->num_rows === 0) {
            $stmt->close();
            throw new Exception("Usuario no encontrado.");
        }

        $usuario = $r->fetch_assoc();
        $stmt->close();

        echo json_encode([
            "ok"      => true,
            "usuario" => $usuario
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | 7) ACTUALIZAR USUARIO
    |--------------------------------------------------------------------------
    */
    if ($action === 'update') {

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new Exception("Método no permitido.");
        }

        /*
        |--------------------------------------------------------------------------
        | 7.1) RECIBIR DATOS
        |--------------------------------------------------------------------------
        */
        $id       = (int)($_POST['id'] ?? 0);
        $usuario  = clean($_POST['usuario'] ?? '');
        $nombre   = clean($_POST['nombre'] ?? '');
        $rol      = clean($_POST['rol'] ?? 'usuario');
        $password = clean($_POST['password'] ?? '');

        /*
        |--------------------------------------------------------------------------
        | 7.2) VALIDACIONES BÁSICAS
        |--------------------------------------------------------------------------
        */
        if ($id <= 0) {
            throw new Exception("ID inválido.");
        }

        if ($usuario === "" || $nombre === "") {
            throw new Exception("Usuario y nombre son obligatorios.");
        }

        /*
        |--------------------------------------------------------------------------
        | 7.3) VALIDAR USUARIO
        |--------------------------------------------------------------------------
        */
        if (mb_strlen($usuario, 'UTF-8') > 30) {
            throw new Exception("El usuario no puede tener más de 30 letras.");
        }

        if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$/u', $usuario)) {
            throw new Exception("El usuario solo puede contener letras.");
        }

        /*
        |--------------------------------------------------------------------------
        | 7.4) VALIDAR NOMBRE
        |--------------------------------------------------------------------------
        */
        if (mb_strlen($nombre, 'UTF-8') > 100) {
            throw new Exception("El nombre no puede tener más de 100 caracteres.");
        }

        if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ\s]+$/u', $nombre)) {
            throw new Exception("El nombre solo puede contener letras y espacios.");
        }

        /*
        |--------------------------------------------------------------------------
        | 7.5) VALIDAR ROL
        |--------------------------------------------------------------------------
        */
        if ($rol !== "admin" && $rol !== "usuario") {
            throw new Exception("Rol inválido.");
        }

        /*
        |--------------------------------------------------------------------------
        | 7.6) VALIDAR QUE EL USUARIO NO EXISTA EN OTRO REGISTRO
        |--------------------------------------------------------------------------
        */
        $stmt = $conn->prepare("
            SELECT id 
            FROM usuarios 
            WHERE usuario = ? 
              AND id <> ? 
            LIMIT 1
        ");

        if (!$stmt) {
            throw new Exception("Error preparando verificación usuario.");
        }

        $stmt->bind_param("si", $usuario, $id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->close();
            throw new Exception("Ese usuario ya existe. Usa otro.");
        }

        $stmt->close();

        /*
        |--------------------------------------------------------------------------
        | 7.7) ACTUALIZAR CON O SIN CONTRASEÑA
        |--------------------------------------------------------------------------
        */
        if ($password !== "") {

            if (strlen($password) < 6) {
                throw new Exception("La contraseña debe tener al menos 6 caracteres.");
            }

            if (!preg_match('/^[A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ.]+$/u', $password)) {
                throw new Exception("La contraseña solo permite letras, números y punto (.).");
            }

            $hash = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $conn->prepare("
                UPDATE usuarios 
                SET usuario = ?, nombre = ?, rol = ?, password = ? 
                WHERE id = ?
            ");

            if (!$stmt) {
                throw new Exception("Error preparando UPDATE.");
            }

            $stmt->bind_param("ssssi", $usuario, $nombre, $rol, $hash, $id);

        } else {

            $stmt = $conn->prepare("
                UPDATE usuarios 
                SET usuario = ?, nombre = ?, rol = ? 
                WHERE id = ?
            ");

            if (!$stmt) {
                throw new Exception("Error preparando UPDATE.");
            }

            $stmt->bind_param("sssi", $usuario, $nombre, $rol, $id);
        }

        /*
        |--------------------------------------------------------------------------
        | 7.8) EJECUTAR ACTUALIZACIÓN
        |--------------------------------------------------------------------------
        */
        if (!$stmt->execute()) {
            $err = $stmt->error;
            $stmt->close();
            throw new Exception("No se pudo actualizar: " . $err);
        }

        $stmt->close();

        /*
        |--------------------------------------------------------------------------
        | 7.9) GUARDAR AUDITORÍA
        |--------------------------------------------------------------------------
        */
        $adminId = (int)$_SESSION['usuario_id'];

        $accionAud = "USUARIO_EDITADO";

        $detalle = "USUARIO={$usuario} | ID={$id} | NOMBRE={$nombre} | ROL={$rol}";

        auditoria($conn, $adminId, $accionAud, $detalle);

        /*
        |--------------------------------------------------------------------------
        | 7.10) RESPUESTA FINAL
        |--------------------------------------------------------------------------
        */
        echo json_encode([
            "ok"  => true,
            "msg" => "Usuario actualizado correctamente."
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | 8) ACCIÓN NO VÁLIDA
    |--------------------------------------------------------------------------
    */
    throw new Exception("Acción inválida.");

} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | 9) RESPUESTA DE ERROR
    |--------------------------------------------------------------------------
    */
    echo json_encode([
        "ok"  => false,
        "msg" => $e->getMessage()
    ]);
}