<div class="card shadow-sm border-0 rounded-4">
  <div class="card-body">
    <h4>Bienvenidos</h4>
    <p class="text-muted mb-0">Selecciona una opción del menú.</p>
  </div>
</div>