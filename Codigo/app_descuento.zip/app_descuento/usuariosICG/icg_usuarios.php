<?php
declare(strict_types=1);

require_once dirname(__DIR__) . "/usuarios/validar_sesion.php";
?>

<style>
/*
|--------------------------------------------------------------------------
| PASO 3: AJUSTAR TABLA RESULTADO A PANTALLA
|--------------------------------------------------------------------------
*/
#respuestaICG .table-responsive{
    width:100%;
    overflow-x:auto;
    border-radius:14px;
}

#respuestaICG table{
    width:100%;
    min-width:1100px;
    font-size:13px;
    white-space:nowrap;
}

#respuestaICG th,
#respuestaICG td{
    vertical-align:middle;
    padding:8px 10px;
}

#respuestaICG td{
    max-width:220px;
    overflow:hidden;
    text-overflow:ellipsis;
}

@media (max-width:768px){
    #respuestaICG table{
        font-size:11px;
        min-width:950px;
    }

    #respuestaICG th,
    #respuestaICG td{
        padding:6px;
    }
}
</style>

<div class="container-fluid mt-4">

    <div class="card shadow-sm border-0 rounded-4">


 <!--|--------------------------------------------------------------------------
| PASO 0: ESCRIBIR TITULO EN I ABAJO
|----------------------------------------------------------------------->

        <div class="card-header bg-primary text-white rounded-top-4">
            <h5 class="mb-0">
                <i class="bi bi-person-fill-check"></i>
            </h5>
        </div>

        <div class="card-body">

            <!-- PASO 4: BOTONES PRINCIPALES -->
            <div class="d-flex gap-2 flex-wrap mb-4">

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalUsuarioUno">
                    <i class="bi bi-person-fill-add"></i>
                    Crear un usuario
                </button>

                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalUsuariosVarios">
                    <i class="bi bi-people-fill"></i>
                    Crear varios usuarios
                </button>

            </div>

            <!-- PASO 5: RESULTADO GENERAL -->
            <div id="respuestaICG"></div>

        </div>
    </div>
</div>


<!--
|--------------------------------------------------------------------------
| PASO 6: MODAL CREAR UN USUARIO
|--------------------------------------------------------------------------
-->
<div class="modal fade" id="modalUsuarioUno" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header bg-primary text-white rounded-top-4">
                <h5 class="modal-title">
                    <i class="bi bi-person-plus"></i>
                    Crear usuario en ICG
                </h5>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="formUno" autocomplete="off">

                <div class="modal-body">

                    <!-- Mensaje dentro del modal -->
                    <div id="msgModalUno" class="alert d-none"></div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label">Empresa</label>
                            <select name="empresa" class="form-select" required>
                                <option value="">Seleccione empresa</option>
                                <option value="detodo">Detodo</option>
                                <option value="mendels">Mendels</option>
                                <option value="acajoe">Acajoe</option>
                                <option value="chesters">Chesters</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Nombre completo</label>
                            <input
                                type="text"
                                name="nombrecliente"
                                class="form-control validar-letras"
                                maxlength="200"
                                required
                            >
                        </div>

                    <!--
|--------------------------------------------------------------------------
|IDENTIDAD EN SMALL SE ESCRIBE TEXTO
|--------------------------------------------------------------------------
-->


                        <div class="col-md-6">
                            <label class="form-label">Identidad</label>
                            <input
                                type="text"
                                name="nif20"
                                class="form-control validar-documento"
                                placeholder="0801-2000-12345"
                                maxlength="50"
                                required
                            >
                            <small class="text-muted">
                            
                            </small>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Provincia</label>
                            <input
                                type="text"
                                name="provincia"
                                class="form-control validar-letras"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">País</label>
                            <input
                                type="text"
                                name="pais"
                                class="form-control validar-letras"
                                value="HONDURAS"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Población</label>
                            <input
                                type="text"
                                name="poblacion"
                                class="form-control validar-letras"
                                maxlength="100"
                                required
                            >
                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-warning" onclick="limpiarFormularioUno()">
                        <i class="bi bi-eraser"></i>
                        Limpiar
                    </button>

                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
    <i class="bi bi-x-circle"></i>
    Cancelar
</button>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i>
                        Guardar usuario
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>


<!--
|--------------------------------------------------------------------------
| PASO 7: MODAL CREAR VARIOS USUARIOS
|--------------------------------------------------------------------------
-->
<div class="modal fade" id="modalUsuariosVarios" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header bg-primary text-white rounded-top-4">
                <h5 class="modal-title">
                    <i class="bi bi-people"></i>
                    Crear varios usuarios en ICG
                </h5>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="formVarios" autocomplete="off">

                <div class="modal-body">

                    <!-- Mensaje dentro del modal -->
                    <div id="msgModalVarios" class="alert d-none"></div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Empresa</label>
                            <select name="empresa" class="form-select" required>
                                <option value="">Seleccione empresa</option>
                                <option value="detodo">Detodo</option>
                                <option value="mendels">Mendels</option>
                                <option value="acajoe">Acajoe</option>
                                <option value="chesters">Chesters</option>
                            </select>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                            <thead class="table-primary">
                                <tr>
                                    <th>Nombre completo</th>
                                    <th>Identidad</th>
                                    <th>Provincia</th>
                                    <th>País</th>
                                    <th>Población</th>
                                    <th width="70">Quitar</th>
                                </tr>
                            </thead>

                            <tbody id="tbodyUsuarios">
                                <tr>
                                    <td>
                                        <input type="text" name="nombrecliente[]" class="form-control validar-letras" maxlength="200" required>
                                    </td>
                                    <td>
                                        <input type="text" name="nif20[]" class="form-control validar-documento" maxlength="50" placeholder="0801-2000-12345" required>
                                    </td>
                                    <td>
                                        <input type="text" name="provincia[]" class="form-control validar-letras" maxlength="100" required>
                                    </td>
                                    <td>
                                        <input type="text" name="pais[]" class="form-control validar-letras" value="HONDURAS" maxlength="100" required>
                                    </td>
                                    <td>
                                        <input type="text" name="poblacion[]" class="form-control validar-letras" maxlength="100" required>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>

                    <button type="button" class="btn btn-outline-primary" onclick="agregarFila()">
                        <i class="bi bi-plus-circle"></i>
                        Agregar fila
                    </button>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-warning" onclick="limpiarFormularioVarios()">
                        <i class="bi bi-eraser"></i>
                        Limpiar
                    </button>

                   <button type="button" class="btn btn-light" data-bs-dismiss="modal">
    <i class="bi bi-x-circle"></i>
    Cancelar
</button>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i>
                        Guardar todos
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>


<script>
/*
|--------------------------------------------------------------------------
| PASO 8: LIMPIAR TEXTO
|--------------------------------------------------------------------------
| Permite letras, acentos, ñ y espacios.
|--------------------------------------------------------------------------
*/
function limpiarSoloLetras(valor) {
    return valor.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, '');
}

/*
|--------------------------------------------------------------------------
| PASO 9: FORMATEAR DOCUMENTO
|--------------------------------------------------------------------------
| Honduras:
| - Si tiene exactamente 13 números, lo formatea como 0000-0000-00000.
|
| Otros países:
| - Permite letras, números y guiones.
| - Ejemplo Nicaragua: 001-010101-0001A
|--------------------------------------------------------------------------
*/
function formatearDocumento(valor) {
    let limpio = valor.toUpperCase().replace(/[^A-Z0-9\-]/g, '');

    let soloNumeros = limpio.replace(/\D/g, '');

    // HONDURAS: máximo 13 dígitos
    if (/^[0-9\-]*$/.test(limpio)) {

        soloNumeros = soloNumeros.substring(0, 13);

        if (soloNumeros.length > 8) {
            return soloNumeros.substring(0, 4) + '-' +
                   soloNumeros.substring(4, 8) + '-' +
                   soloNumeros.substring(8);
        }

        if (soloNumeros.length > 4) {
            return soloNumeros.substring(0, 4) + '-' +
                   soloNumeros.substring(4);
        }

        return soloNumeros;
    }

    return limpio;
}

/*
|--------------------------------------------------------------------------
| PASO 10: VALIDAR DOCUMENTO FLEXIBLE
|--------------------------------------------------------------------------
| Acepta:
| - Honduras: 13 números con o sin guiones
| - Nicaragua: letras/números/guiones
| - Otros países: letras/números/guiones
|--------------------------------------------------------------------------
*/
function documentoValido(valor) {
    const limpio = valor.trim().toUpperCase();

    if (limpio === '') {
        return false;
    }

    const soloNumeros = limpio.replace(/\D/g, '');

    /*
    | Honduras válido: exactamente 13 números.
    */
    if (soloNumeros.length === 13 && /^[0-9\-]+$/.test(limpio)) {
        return true;
    }

    /*
    | Otros países: mínimo 5 caracteres, máximo 50,
    | solo letras, números y guiones.
    */
    return /^[A-Z0-9\-]{5,50}$/.test(limpio);
}

/*
|--------------------------------------------------------------------------
| PASO 11: MOSTRAR MENSAJE EN MODAL
|--------------------------------------------------------------------------
*/
function mostrarMsgModal(id, tipo, mensaje) {
    const box = document.getElementById(id);

    if (!box) return;

    box.className = `alert alert-${tipo}`;
    box.innerHTML = mensaje;
    box.classList.remove('d-none');
}

/*
|--------------------------------------------------------------------------
| PASO 12: OCULTAR MENSAJE EN MODAL
|--------------------------------------------------------------------------
*/
function ocultarMsgModal(id) {
    const box = document.getElementById(id);

    if (!box) return;

    box.className = 'alert d-none';
    box.innerHTML = '';
}

/*
|--------------------------------------------------------------------------
| PASO 13: APLICAR VALIDACIONES AL TECLADO
|--------------------------------------------------------------------------
*/
function aplicarValidacionesICG() {

    /*
    | Textos: permite letras y espacios.
    */
   document.querySelectorAll('.validar-letras').forEach(input => {

    input.addEventListener('keydown', function(e) {
        const tecla = e.key;

        // teclas permitidas
        const especiales = [
            'Backspace','Delete','Tab','ArrowLeft','ArrowRight','Home','End'
        ];

        if (especiales.includes(tecla)) return;

        // SOLO letras y espacio
        if (!/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]$/.test(tecla)) {
            e.preventDefault();
        }
    });

    // 🔒 FILTRO FINAL (IMPORTANTE)
    input.addEventListener('input', function() {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, '');
    });

    // ✅ permitir pegar pero limpio
    input.addEventListener('paste', function() {
        setTimeout(() => {
            this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, '');
        }, 0);
    });

});

    /*
    | Documento: permite letras, números y guiones.
    */
    document.querySelectorAll('.validar-documento').forEach(input => {

    input.addEventListener('keydown', function(e) {
        const tecla = e.key;

        const especiales = [
            'Backspace','Delete','Tab','ArrowLeft','ArrowRight','Home','End'
        ];

        if (especiales.includes(tecla)) return;

        // SOLO letras, números y guion
        if (!/^[A-Za-z0-9-]$/.test(tecla)) {
            e.preventDefault();
            return;
        }

        // HONDURAS: si ya tiene 13 números, no permitir más letras ni números
        const valorActual = this.value.toUpperCase();
        const soloNumeros = valorActual.replace(/\D/g, '');

        if (/^[0-9-]*$/.test(valorActual) && soloNumeros.length >= 13) {
            e.preventDefault();
            return;
        }
    });

    // 🔒 FILTRO FUERTE
    input.addEventListener('input', function() {
        this.value = this.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
        this.value = formatearDocumento(this.value);
    });

    input.addEventListener('paste', function() {
        setTimeout(() => {
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
            this.value = formatearDocumento(this.value);
        }, 0);
   });

});
}

aplicarValidacionesICG();

/*
|--------------------------------------------------------------------------
| PASO 14: FILA BASE MASIVA
|--------------------------------------------------------------------------
*/
function filaMasivaHtml() {
    return `
        <tr>
            <td>
                <input type="text" name="nombrecliente[]" class="form-control validar-letras" maxlength="200" required>
            </td>
            <td>
                <input type="text" name="nif20[]" class="form-control validar-documento" maxlength="50" placeholder="0801-2000-12345" required>
            </td>
            <td>
                <input type="text" name="provincia[]" class="form-control validar-letras" maxlength="100" required>
            </td>
            <td>
                <input type="text" name="pais[]" class="form-control validar-letras" value="HONDURAS" maxlength="100" required>
            </td>
            <td>
                <input type="text" name="poblacion[]" class="form-control validar-letras" maxlength="100" required>
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `;
}

/*
|--------------------------------------------------------------------------
| PASO 15: AGREGAR FILA
|--------------------------------------------------------------------------
*/
function agregarFila() {
    const tbody = document.getElementById('tbodyUsuarios');

    tbody.insertAdjacentHTML('beforeend', filaMasivaHtml());

    aplicarValidacionesICG();

    mostrarMsgModal(
        'msgModalVarios',
        'info',
        '<i class="bi bi-plus-circle"></i> Se agregó una nueva fila.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 16: ELIMINAR FILA
|--------------------------------------------------------------------------
*/
function eliminarFila(btn) {
    const tbody = document.getElementById('tbodyUsuarios');

    if (tbody.rows.length <= 1) {
        mostrarMsgModal(
            'msgModalVarios',
            'warning',
            '<i class="bi bi-exclamation-triangle"></i> Debe quedar al menos una fila.'
        );
        return;
    }

    btn.closest('tr').remove();

    mostrarMsgModal(
        'msgModalVarios',
        'secondary',
        '<i class="bi bi-trash"></i> Fila eliminada.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 17: LIMPIAR FORMULARIO UN USUARIO
|--------------------------------------------------------------------------
*/
function limpiarFormularioUno() {
    const form = document.getElementById('formUno');

    form.reset();

    mostrarMsgModal(
        'msgModalUno',
        'warning',
        '<i class="bi bi-eraser"></i> Formulario limpiado.'
    );

    aplicarValidacionesICG();
}

/*
|--------------------------------------------------------------------------
| PASO 19: LIMPIAR FORMULARIO VARIOS
|--------------------------------------------------------------------------
*/
function limpiarFormularioVarios() {
    const form = document.getElementById('formVarios');
    const tbody = document.getElementById('tbodyUsuarios');

    form.reset();
    tbody.innerHTML = filaMasivaHtml();

    aplicarValidacionesICG();

    mostrarMsgModal(
        'msgModalVarios',
        'warning',
        '<i class="bi bi-eraser"></i> Formulario masivo limpiado.'
    );
}


function limpiarBootstrapModal() {
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
}

function cancelarModalUno() {
    limpiarFormularioUno();

    const modalEl = document.getElementById('modalUsuarioUno');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

    modal.hide();

    setTimeout(limpiarBootstrapModal, 300);
}

function cancelarModalVarios() {
    limpiarFormularioVarios();

    const modalEl = document.getElementById('modalUsuariosVarios');
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

    modal.hide();

    setTimeout(limpiarBootstrapModal, 300);
}

/*
|--------------------------------------------------------------------------
| PASO 21: PINTAR RESPUESTA GENERAL
|--------------------------------------------------------------------------
*/
function pintarRespuesta(data) {
    const respuesta = document.getElementById('respuestaICG');

    if (!data.ok) {
        respuesta.innerHTML = `
            <div class="alert alert-danger">
                ${data.msg}
            </div>
        `;
        return;
    }

    let html = `
        <div class="alert alert-success">
            <h6 class="fw-bold mb-2">
                <i class="bi bi-check-circle"></i>
                Proceso finalizado
            </h6>

            <div><strong>Empresa:</strong> ${data.empresa ?? '-'}</div>
            <div><strong>Insertados:</strong> ${data.insertados}</div>
            <div><strong>Duplicados:</strong> ${data.duplicados}</div>
            <div><strong>Errores:</strong> ${data.errores}</div>
        </div>

        <div class="table-responsive shadow-sm rounded-4">
            <table class="table table-bordered table-sm align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Estado</th>
                        <th>Empresa</th>
                        <th>CODCLIENTE</th>
                       <!-- <th>CODCONTABLE</th> -->
                        <th>Nombre</th>
                        <th>Identidad</th>
                        <th>Provincia</th>
                        <th>País</th>
                        <th>Población</th>
                        <th>Mensaje</th>
                    </tr>
                </thead>
                <tbody>
    `;

    data.detalle.forEach(row => {
        html += `
            <tr>
                <td>${row.estado ?? '-'}</td>
                <td>${row.empresa ?? '-'}</td>
                <td>${row.codcliente ?? '-'}</td>
              <!-- <td>${row.codcontable ?? '-'}</td> -->
                <td>${row.nombrecliente ?? '-'}</td>
                <td>${row.nif20 ?? '-'}</td>
                <td>${row.provincia ?? '-'}</td>
                <td>${row.pais ?? '-'}</td>
                <td>${row.poblacion ?? '-'}</td>
                <td>${row.msg ?? '-'}</td>
            </tr>
        `;
    });

    html += `
                </tbody>
            </table>
        </div>
    `;

    respuesta.innerHTML = html;
}

/*
|--------------------------------------------------------------------------
| PASO 22: RESULTADO MODAL UNO
|--------------------------------------------------------------------------
*/
function pintarResultadoModalUno(data) {
    if (!data.ok) {
        mostrarMsgModal('msgModalUno', 'danger', '<i class="bi bi-x-circle"></i> ' + (data.msg ?? 'Error.'));
        return;
    }

    if (data.insertados > 0) {
        mostrarMsgModal('msgModalUno', 'success', '<i class="bi bi-check-circle"></i> Usuario guardado exitosamente.');
        return;
    }

    if (data.duplicados > 0) {
        mostrarMsgModal('msgModalUno', 'warning', '<i class="bi bi-exclamation-triangle"></i> El usuario ya existe en ICG.');
        return;
    }

    if (data.errores > 0) {
        mostrarMsgModal('msgModalUno', 'danger', '<i class="bi bi-x-circle"></i> No se pudo guardar el usuario.');
    }
}

/*
|--------------------------------------------------------------------------
| PASO 23: RESULTADO MODAL VARIOS
|--------------------------------------------------------------------------
*/
function pintarResultadoModalVarios(data) {
    if (!data.ok) {
        mostrarMsgModal('msgModalVarios', 'danger', '<i class="bi bi-x-circle"></i> ' + (data.msg ?? 'Error.'));
        return;
    }

    mostrarMsgModal(
        'msgModalVarios',
        data.errores > 0 ? 'warning' : 'success',
        `
        <i class="bi bi-check-circle"></i>
        Proceso finalizado.
        Insertados: ${data.insertados},
        Duplicados: ${data.duplicados},
        Errores: ${data.errores}.
        `
    );
}

/*
|--------------------------------------------------------------------------
| PASO 24: GUARDAR UN USUARIO
|--------------------------------------------------------------------------
*/
document.getElementById('formUno').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = this;
    const doc = form.querySelector('input[name="nif20"]');

    ocultarMsgModal('msgModalUno');

    doc.value = formatearDocumento(doc.value);

    if (!documentoValido(doc.value)) {
        mostrarMsgModal(
            'msgModalUno',
            'danger',
            '<i class="bi bi-x-circle"></i> Documento inválido. Use identidad hondureña, DNI, cédula o pasaporte válido.'
        );
        doc.focus();
        return;
    }

    mostrarMsgModal('msgModalUno', 'info', '<i class="bi bi-hourglass-split"></i> Guardando usuario...');

    const datos = new FormData(form);
    datos.append('modo', 'uno');

   fetch('/app_descuento/usuariosICG/guardar_icg_usuario.php', {
    method: 'POST',
    body: datos,
    credentials: 'same-origin'
})

    .then(res => res.text())
    .then(texto => {
        const data = JSON.parse(texto);

        pintarRespuesta(data);
        pintarResultadoModalUno(data);

        if (data.ok && data.insertados > 0) {
            setTimeout(() => {
                form.reset();
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalUsuarioUno'));
                modal.hide();
            }, 900);
        }
    })
    .catch(error => {
        console.error(error);
        mostrarMsgModal('msgModalUno', 'danger', '<i class="bi bi-x-circle"></i> Error al conectar con el servidor.');
    });
});

/*
|--------------------------------------------------------------------------
| PASO 25: GUARDAR VARIOS USUARIOS
|--------------------------------------------------------------------------
*/
document.getElementById('formVarios').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = this;
    const docs = form.querySelectorAll('input[name="nif20[]"]');

    ocultarMsgModal('msgModalVarios');

    for (const input of docs) {
        input.value = formatearDocumento(input.value);

        if (!documentoValido(input.value)) {
            mostrarMsgModal(
                'msgModalVarios',
                'danger',
                '<i class="bi bi-x-circle"></i> Hay un documento inválido. Revise identidades, DNI, cédulas o pasaportes.'
            );
            input.focus();
            return;
        }
    }

    mostrarMsgModal('msgModalVarios', 'info', '<i class="bi bi-hourglass-split"></i> Guardando usuarios...');

    const datos = new FormData(form);
    datos.append('modo', 'varios');

   
    fetch('/app_descuento/usuariosICG/guardar_icg_usuario.php', {
    method: 'POST',
    body: datos,
    credentials: 'same-origin'
})

    .then(res => res.text())
    .then(texto => {
        const data = JSON.parse(texto);

        pintarRespuesta(data);
        pintarResultadoModalVarios(data);

        if (data.ok && data.insertados > 0) {
            setTimeout(() => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalUsuariosVarios'));
                modal.hide();
            }, 1200);
        }
    })
    .catch(error => {
        console.error(error);
        mostrarMsgModal('msgModalVarios', 'danger', '<i class="bi bi-x-circle"></i> Error al conectar con el servidor.');
    });
});

/*
|--------------------------------------------------------------------------
| PASO 26: LIMPIAR MENSAJES AL ABRIR MODALES
|--------------------------------------------------------------------------
*/
document.getElementById('modalUsuarioUno').addEventListener('show.bs.modal', function() {
    ocultarMsgModal('msgModalUno');
});

document.getElementById('modalUsuariosVarios').addEventListener('show.bs.modal', function() {
    ocultarMsgModal('msgModalVarios');
});

/*
|--------------------------------------------------------------------------
| MODALES MOVIBLES CORREGIDOS SIN ACUMULAR EVENTOS
|--------------------------------------------------------------------------
*/

let modalMoviendo = null;
let modalDialog = null;
let inicioX = 0;
let inicioY = 0;
let moverX = 0;
let moverY = 0;

document.addEventListener('mousedown', function(e) {
    const header = e.target.closest('.modal-header');

    if (!header) return;

    const modal = header.closest('.modal');
    const dialog = modal.querySelector('.modal-dialog');

    if (!modal || !dialog) return;

    modalMoviendo = modal;
    modalDialog = dialog;

    inicioX = e.clientX - moverX;
    inicioY = e.clientY - moverY;

    document.addEventListener('mousemove', moverModal);
    document.addEventListener('mouseup', detenerModal);
});

function moverModal(e) {
    if (!modalMoviendo || !modalDialog) return;

    moverX = e.clientX - inicioX;
    moverY = e.clientY - inicioY;

    modalDialog.style.transform = `translate(${moverX}px, ${moverY}px)`;
}

function detenerModal() {
    document.removeEventListener('mousemove', moverModal);
    document.removeEventListener('mouseup', detenerModal);

    modalMoviendo = null;
    modalDialog = null;
}

document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('hidden.bs.modal', function() {
        const dialog = modal.querySelector('.modal-dialog');

        if (dialog) {
            dialog.style.transform = '';
        }

        moverX = 0;
        moverY = 0;

        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
    });
});

</script>