<?php



require_once __DIR__ . "/../usuarios/validar_sesion.php";
require_once __DIR__ . "/../usuarios/conexion.php";


$rolActual = $_SESSION['rol'] ?? '';

if (!in_array($rolActual, ['admin'], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger m-3">Acceso denegado. Solo administradores.</div>';
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 3: FUNCIONES BÁSICAS
|--------------------------------------------------------------------------
*/
function limpiar($v): string {
    return trim((string)$v);
}

function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| PASO 4: FORMATEAR IP
|--------------------------------------------------------------------------
*/
function ip_label_html(?string $ip): string {
    $ip = (string)($ip ?? '');

    if ($ip === '') {
        return '<span class="ip-badge">-</span>';
    }

    if ($ip === '::1') {
        return '<span class="ip-badge">LOCALHOST</span>';
    }

    return '<span class="ip-badge mono">' . h($ip) . '</span>';
}

/*
|--------------------------------------------------------------------------
| PASO 5: EXTRAER VALOR DEL DETALLE
|--------------------------------------------------------------------------
| Ejemplo:
| EMPRESA=Mendels | CODCLIENTE=810675 | NOMBRE=Lina | IDENTIDAD=0601
|--------------------------------------------------------------------------
*/
function aud_get_value(string $detalle, string $key): string {
    if (preg_match('/\b' . preg_quote($key, '/') . '=([^|]+)(?:\||$)/i', $detalle, $m)) {
        return trim($m[1]);
    }

    return '';
}

/*
|--------------------------------------------------------------------------
| PASO 6: BADGES DE ACCIONES
|--------------------------------------------------------------------------
*/
function badge_accion_html(?string $accion, ?string $detalle = ''): string {
    if (!$accion) {
        return "<span class='badge bg-secondary'><i class='bi bi-question-circle'></i> N/A</span>";
    }

    $detalle = (string)($detalle ?? '');
    $esMasivo = stripos($detalle, 'MASIVO=SI') !== false;

    /*
    |--------------------------------------------------------------------------
    | DESCUENTOS
    |--------------------------------------------------------------------------
    | El masivo se identifica por la acción o por MASIVO=SI en el detalle.
    | Así podemos distinguir incluso DESCUENTO_ELIMINADO individual vs masivo.
    |--------------------------------------------------------------------------
    */
    if ($accion === 'DESCUENTO_MASIVO') {
        return "<span class='badge bg-success'><i class='bi bi-people-fill'></i> Descuento masivo asignado</span>";
    }

    if ($accion === 'DESCUENTO_CAMBIADO_MASIVO') {
        return "<span class='badge bg-warning text-dark'><i class='bi bi-arrow-repeat'></i> Descuento masivo cambiado</span>";
    }

    if ($accion === 'DESCUENTO_ELIMINADO_MASIVO' || ($accion === 'DESCUENTO_ELIMINADO' && $esMasivo)) {
        return "<span class='badge bg-danger'><i class='bi bi-people-fill'></i><i class='bi bi-trash3'></i> Descuento masivo eliminado</span>";
    }

    if ($accion === 'DESCUENTO_ASIGNADO') {
        return "<span class='badge bg-success'><i class='bi bi-plus-circle-fill'></i> Descuento asignado</span>";
    }

    if ($accion === 'DESCUENTO_CAMBIADO') {
        return "<span class='badge bg-warning text-dark'><i class='bi bi-pencil-square'></i> Descuento cambiado</span>";
    }

    if ($accion === 'DESCUENTO_ELIMINADO') {
        return "<span class='badge bg-danger'><i class='bi bi-trash3-fill'></i> Descuento eliminado</span>";
    }

    /*
    |--------------------------------------------------------------------------
    | USUARIOS
    |--------------------------------------------------------------------------
    */
    return match ($accion) {
        'USUARIO_AGREGADO'      => "<span class='badge bg-success'><i class='bi bi-person-plus-fill'></i> Usuario agregado</span>",
        'USUARIO_EDITADO'       => "<span class='badge bg-info text-dark'><i class='bi bi-person-gear'></i> Usuario editado</span>",
        'USUARIO_BLOQUEADO'     => "<span class='badge bg-secondary'><i class='bi bi-person-lock'></i> Usuario bloqueado</span>",
        'USUARIO_DESBLOQUEADO'  => "<span class='badge bg-info text-dark'><i class='bi bi-unlock-fill'></i> Usuario desbloqueado</span>",
        'ICG_USUARIO_CREADO'    => "<span class='badge bg-primary'><i class='bi bi-person-fill-add'></i> ICG creado</span>",
        default                 => "<span class='badge bg-primary'><i class='bi bi-info-circle'></i> " . h($accion) . "</span>",
    };
}

/*
|--------------------------------------------------------------------------
| PASO 7: RENDERIZAR PARA QUE EL DETALLE SE VEA BONITO
|--------------------------------------------------------------------------
*/
function render_detalle_bonito(?string $detalleRaw): string {
    $detalleRaw = trim((string)($detalleRaw ?? ''));

    if ($detalleRaw === '') {
        return '<span class="text-muted">Sin detalle</span>';
    }

    /*
    |----------------------------------------------------------------------
    | PASO 7.1: USUARIO ICG CREADO
    |----------------------------------------------------------------------
    */
    if (stripos($detalleRaw, 'ICG_USUARIO=SI') !== false) {
        $empresa    = h(aud_get_value($detalleRaw, 'EMPRESA') ?: '-');
        $codcliente = h(aud_get_value($detalleRaw, 'CODCLIENTE') ?: '-');
        $nombre     = h(aud_get_value($detalleRaw, 'NOMBRE') ?: '-');
        $identidad  = h(aud_get_value($detalleRaw, 'IDENTIDAD') ?: '-');

        return "
            <div class='detail-box detail-icg'>
                <div class='detail-head'>
                    <strong><i class='bi bi-person-fill-add'></i> Usuario ICG</strong>
                    <span>{$empresa}</span>
                </div>
                <div class='detail-grid'>
                    <div><small>Nombre</small><b>{$nombre}</b></div>
                    <div><small>CODCLIENTE</small><b class='mono'>{$codcliente}</b></div>
                    <div><small>Identidad</small><b class='mono'>{$identidad}</b></div>
                </div>
            </div>
        ";
    }

    /*
    |----------------------------------------------------------------------
    | PASO 7.2: USUARIO DEL SISTEMA
    |----------------------------------------------------------------------
    */
    if (stripos($detalleRaw, 'USUARIO=') !== false) {
        $usuario = h(aud_get_value($detalleRaw, 'USUARIO') ?: '-');
        $id      = h(aud_get_value($detalleRaw, 'ID') ?: '-');
        $nombre  = h(aud_get_value($detalleRaw, 'NOMBRE') ?: '');
        $rol     = h(aud_get_value($detalleRaw, 'ROL') ?: '');
        $estado  = h(aud_get_value($detalleRaw, 'ESTADO') ?: '');

        /*
        |------------------------------------------------------------------
        | IMPORTANTE:
        |  ESTADO aquí porque ya aparece en la columna ACCIÓN.
        | Así se evita  repetir "bloqueado" o "activo" en el detalle.
        |------------------------------------------------------------------
        */
        return "
            <div class='detail-box detail-user simple-detail'>
                <div class='detail-line'>
                    <span><i class='bi bi-person-circle'></i> Usuario</span>
                    <b>{$usuario}</b>
                </div>

                 <!-- OcultadO
                <div class='detail-line'>
                    <span>ID</span>
                    <b class='mono'>{$id}</b>
                </div>
                -->

                " . ($nombre !== '' ? "
                <div class='detail-line'>
                    <span>Nombre</span>
                    <b>{$nombre}</b>
                </div>" : "") . "

                " . ($rol !== '' ? "
                <div class='detail-line'>
                    <span>Rol</span>
                    <b>{$rol}</b>
                </div>" : "") . "
            </div>
        ";
    }

    /*
    |----------------------------------------------------------------------
    | PASO 7.3: DESCUENTOS
    |----------------------------------------------------------------------
    */
    if (
        stripos($detalleRaw, 'ICG=') !== false ||
        stripos($detalleRaw, 'CODCLIENTE=') !== false ||
        stripos($detalleRaw, 'IDGRUPO=') !== false ||
        stripos($detalleRaw, 'MASIVO=') !== false
    ) {
        $empresa    = h(aud_get_value($detalleRaw, 'ICG') ?: '-');
        $codigo     = h(aud_get_value($detalleRaw, 'CODCLIENTE') ?: '-');
        $idgrupoRaw = aud_get_value($detalleRaw, 'IDGRUPO');
        $idgrupo    = (int)($idgrupoRaw !== '' ? $idgrupoRaw : 0);
        $identidad  = h(aud_get_value($detalleRaw, 'IDENTIDAD') ?: '-');
        $masivo     = h(aud_get_value($detalleRaw, 'MASIVO') ?: '');

        $porcentaje = match ($idgrupo) {
            12, 15  => '10%',
            13, 16  => '20%',
            17      => '40%',
            14, 18  => '50%',
            0       => 'Sin descuento',
            default => (string)$idgrupo,
        };

        return "
            <div class='detail-box detail-discount'>
                <div class='detail-head'>
                    <strong><i class='bi bi-cash-coin'></i> Descuento</strong>
                    <span>{$porcentaje}</span>
                </div>
                <div class='detail-grid'>
                    <div><small>Empresa</small><b class='mono'>{$empresa}</b></div>
                    <div><small>Código</small><b class='mono'>{$codigo}</b></div>
                    <div><small>Identidad</small><b class='mono'>{$identidad}</b></div>
                    " . ($masivo !== '' ? "<div><small>Masivo</small><b class='mono'>{$masivo}</b></div>" : "") . "
                </div>
            </div>
        ";
    }

    return '<div class="small text-muted" style="white-space:pre-wrap;">' . h($detalleRaw) . '</div>';
}

/*
|--------------------------------------------------------------------------
| PASO 8: RECIBIR FILTROS
|--------------------------------------------------------------------------
| Se eliminó el filtro ID usuario porque no lo necesitás.
|--------------------------------------------------------------------------
*/
$desde   = limpiar($_GET['desde'] ?? '');
$hasta   = limpiar($_GET['hasta'] ?? '');
$accion  = limpiar($_GET['accion'] ?? '');
$q       = limpiar($_GET['q'] ?? '');

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = max(10, min((int)($_GET['perPage'] ?? 100), 200));
$offset  = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| PASO 9: ARMAR SQL DINÁMICO
|--------------------------------------------------------------------------
*/
$where = ["a.accion NOT IN ('LOGIN_OK','LOGIN_FAIL')"];
$params = [];
$types = "";

if ($desde) {
    $where[] = "a.created_at >= CONCAT(?,' 00:00:00')";
    $params[] = $desde;
    $types .= "s";
}

if ($hasta) {
    $where[] = "a.created_at <= CONCAT(?,' 23:59:59')";
    $params[] = $hasta;
    $types .= "s";
}

if ($accion) {
    $where[] = "a.accion = ?";
    $params[] = $accion;
    $types .= "s";
}

if ($q) {
    $where[] = "(a.detalle LIKE ? OR a.ip LIKE ? OR a.accion LIKE ? OR u.nombre LIKE ? OR u.usuario LIKE ?)";
    $params = array_merge($params, ["%$q%", "%$q%", "%$q%", "%$q%", "%$q%"]);
    $types .= "sssss";
}

$whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

/*
|--------------------------------------------------------------------------
| PASO 10: TOTAL DE REGISTROS
|--------------------------------------------------------------------------
*/
$sqlCount = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    $whereSql
";

$stmt = $conn->prepare($sqlCount);

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$total = (int)($result->fetch_assoc()['total'] ?? 0);
$stmt->close();

$totalPages = max(1, (int)ceil($total / $perPage));

/*
|--------------------------------------------------------------------------
| PASO 11: PAGINACIÓN
|--------------------------------------------------------------------------
*/
$range = 2;
$start = max(1, $page - $range);
$end   = min($totalPages, $page + $range);

/*
|--------------------------------------------------------------------------
| PASO 12: CONSULTAR REGISTROS
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT
        a.id,
        a.usuario_id,
        u.nombre,
        u.usuario,
        a.accion,
        a.detalle,
        a.ip,
        a.created_at
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    $whereSql
    ORDER BY a.created_at DESC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

$types2 = $types . "ii";
$params2 = array_merge($params, [$perPage, $offset]);

$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/*
|--------------------------------------------------------------------------
| PASO 13: ACCIONES PARA SELECT
|--------------------------------------------------------------------------
*/
$acciones = [];
$rAcc = $conn->query("
    SELECT DISTINCT accion
    FROM auditoria
    WHERE accion NOT IN ('LOGIN_OK','LOGIN_FAIL')
    ORDER BY accion ASC
");

if ($rAcc) {
    while ($a = $rAcc->fetch_assoc()) {
        $acciones[] = $a['accion'];
    }
}

/*
|--------------------------------------------------------------------------
| PASO 14: RENDERIZAR FILAS
|--------------------------------------------------------------------------
*/
function render_auditoria_rows(array $rows): string {
    if (!$rows) {
        return "<tr><td colspan='6' class='text-center text-muted py-4'>No hay registros para mostrar.</td></tr>";
    }

    ob_start();

    foreach ($rows as $r) {
        $fecha = (string)($r['created_at'] ?? '');
        $fechaDia = $fecha ? date('Y-m-d', strtotime($fecha)) : '-';
        $fechaHora = $fecha ? date('H:i:s', strtotime($fecha)) : '-';
        $usuarioNombre = $r['nombre'] ?? 'Desconocido';
        $usuarioLogin = $r['usuario'] ?? '';
        ?>
        <tr>
            <td data-label="ID" class="mono id-cell">#<?= h((string)$r['id']) ?></td>

            <td data-label="Fecha">
                <div class="date-cell">
                    <i class="bi bi-clock"></i>
                    <div>
                        <b><?= h($fechaDia) ?></b>
                        <small><?= h($fechaHora) ?></small>
                    </div>
                </div>
            </td>

            <td data-label="Usuario">
                <div class="user-cell">
                    <div class="user-avatar"><i class="bi bi-person-fill"></i></div>
                    <div>
                        <b><?= h($usuarioNombre) ?></b>
                        <?= $usuarioLogin !== '' ? '<small>@' . h($usuarioLogin) . '</small>' : '' ?>
                    </div>
                </div>
            </td>

            <td data-label="Acción" class="action-cell"><?= badge_accion_html($r['accion'] ?? '', $r['detalle'] ?? '') ?></td>
            <td data-label="IP"><?= ip_label_html($r['ip'] ?? '') ?></td>
            <td data-label="Detalle" class="detail-td"><?= render_detalle_bonito($r['detalle'] ?? '') ?></td>
        </tr>
        <?php
    }

    return ob_get_clean();
}

/*
|--------------------------------------------------------------------------
| PASO 15: RESPUESTA AJAX
|--------------------------------------------------------------------------
*/
if (isset($_GET['ajax'])) {
    $tbody = render_auditoria_rows($rows);

    ob_start();
    ?>

    <?php if ($page > 1): ?>
        <li class="page-item">
            <button class="page-link" data-page="<?= $page - 1 ?>">Anterior</button>
        </li>
    <?php endif; ?>

    <?php if ($start > 1): ?>
        <li class="page-item">
            <button class="page-link" data-page="1">1</button>
        </li>
        <li class="page-item disabled"><span class="page-link">...</span></li>
    <?php endif; ?>

    <?php for ($p = $start; $p <= $end; $p++): ?>
        <li class="page-item <?= $p == $page ? 'active' : '' ?>">
            <button class="page-link" data-page="<?= $p ?>"><?= $p ?></button>
        </li>
    <?php endfor; ?>

    <?php if ($end < $totalPages): ?>
        <li class="page-item disabled"><span class="page-link">...</span></li>
        <li class="page-item">
            <button class="page-link" data-page="<?= $totalPages ?>"><?= $totalPages ?></button>
        </li>
    <?php endif; ?>

    <?php if ($page < $totalPages): ?>
        <li class="page-item">
            <button class="page-link" data-page="<?= $page + 1 ?>">Siguiente</button>
        </li>
    <?php endif; ?>

    <?php
    $pagination = ob_get_clean();

    echo json_encode([
        'tbody' => $tbody,
        'pagination' => $pagination,
        'total' => $total
    ], JSON_UNESCAPED_UNICODE);

    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Auditoría</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        /*
        |----------------------------------------------------------------------
        | PASO 16: ESTILOS GENERALES
        |----------------------------------------------------------------------
        */
        body{
            background:#f5f7fb;
            font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
            overflow-x:hidden;
        }

        .audit-wrap{
            max-width:1450px;
            margin:auto;
            padding:12px;
        }

        .audit-card{
            background:#fff;
            border:1px solid #e5e7eb;
            border-radius:18px;
            box-shadow:0 6px 20px rgba(15,23,42,.06);
            overflow:hidden;
        }

        .audit-header{
            padding:18px;
            border-bottom:1px solid #e5e7eb;
            background:#fff;
        }

        .header-icon{
            width:44px;
            height:44px;
            border-radius:12px;
            background:#eef2ff;
            color:#2563eb;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:22px;
        }

        .total-box{
            background:#f8fafc;
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:10px 14px;
            font-weight:800;
            color:#1e293b;
        }

        /*
        |----------------------------------------------------------------------
        | PASO 17: FILTROS
        |----------------------------------------------------------------------
        */
        .filter-box{
            background:#f8fafc;
            border:1px solid #e5e7eb;
            border-radius:16px;
            padding:14px;
            margin-bottom:14px;
        }

        .form-control,
        .form-select{
            border-radius:10px;
            min-height:42px;
            border:1px solid #dbe3ee;
            font-size:.92rem;
        }

        .btn{
            border-radius:10px;
            min-height:42px;
            font-weight:700;
        }

        /*
        |----------------------------------------------------------------------
        | PASO 18: TABLA
        |----------------------------------------------------------------------
        */
        .table-box{
            border:1px solid #e5e7eb;
            border-radius:16px;
            overflow:hidden;
        }

        .table{
            margin:0;
        }

        .table thead th{
            background:#f8fafc;
            color:#334155;
            font-size:.76rem;
            text-transform:uppercase;
            letter-spacing:.04em;
            border-bottom:1px solid #e5e7eb;
            padding:13px;
            white-space:nowrap;
        }

        .table tbody td{
            padding:13px;
            vertical-align:middle;
            border-color:#edf2f7;
        }

        .id-cell{
            font-weight:800;
            color:#475569;
        }

        .date-cell,
        .user-cell{
            display:flex;
            align-items:center;
            gap:9px;
        }

        .date-cell i{
            color:#2563eb;
        }

        .date-cell small,
        .user-cell small{
            display:block;
            color:#64748b;
        }

        .user-avatar{
            width:34px;
            height:34px;
            border-radius:50%;
            background:#eef2ff;
            color:#2563eb;
            display:flex;
            align-items:center;
            justify-content:center;
            flex:0 0 auto;
        }

        .badge{
            border-radius:999px;
            padding:7px 10px;
            font-size:.72rem;
            font-weight:800;
            display:inline-flex;
            gap:5px;
            align-items:center;
            white-space:nowrap;
        }

        .ip-badge{
            background:#f1f5f9;
            color:#334155;
            border-radius:999px;
            padding:6px 10px;
            font-size:.72rem;
            font-weight:800;
            display:inline-flex;
            white-space:nowrap;
        }

        .mono{
            font-family:Consolas,Monaco,monospace;
        }

        /*
        |----------------------------------------------------------------------
        | PASO 19: DETALLE COMPACTO
        |----------------------------------------------------------------------
        */
        .detail-td{
            width:40%;
        }

        .detail-box{
            border:1px solid #e5e7eb;
            border-radius:12px;
            padding:9px 10px;
            background:#fff;
            max-width:460px;
            font-size:.88rem;
        }

        .simple-detail{
            max-width:360px;
        }

        .detail-line{
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:12px;
            padding:3px 0;
        }

        .detail-line span{
            color:#64748b;
            font-size:.72rem;
            font-weight:800;
            text-transform:uppercase;
            letter-spacing:.03em;
        }

        .detail-line b{
            color:#0f172a;
            font-size:.86rem;
            text-align:right;
            word-break:break-word;
        }

        .detail-icg{
            border-left:4px;
            background: #fbfbfa;
        }

        .detail-discount{
            border-left:4px;
            background: #fbfbfa;
        }

        .detail-user{
            border-left:4px;
            background: #fbfbfa;
        }

        /* Detalle de usuario más sencillo: sin badge de estado */
        .detail-user .detail-head{
            display:none;
        }

        .detail-head{
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:8px;
            margin-bottom:8px;
        }

        .detail-head span{
            background:#e5e7eb;
            color:#111827;
            border-radius:999px;
            padding:4px 8px;
            font-size:.68rem;
            font-weight:800;
        }

        .detail-grid{
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:7px;
        }

        .detail-grid small{
            display:block;
            color:#64748b;
            font-size:.66rem;
            text-transform:uppercase;
            letter-spacing:.04em;
        }

        .detail-grid b{
            display:block;
            color:#0f172a;
            font-size:.86rem;
            word-break:break-word;
        }

        /*
        |----------------------------------------------------------------------
        | PASO 20: PAGINACIÓN
        |----------------------------------------------------------------------
        */
        .pagination .page-link{
            border-radius:9px;
            margin:0 2px;
            color:#1e293b;
        }

        .pagination .active .page-link{
            background:#2563eb;
            border-color:#2563eb;
            color:#fff;
        }

        /*
        |----------------------------------------------------------------------
        | PASO 21: RESPONSIVE TABLET/CELULAR
        |----------------------------------------------------------------------
        */
        @media(max-width:992px){
            .table-box{
                border:none;
                overflow:visible;
            }

            .table thead{
                display:none;
            }

            .table,
            .table tbody,
            .table tr,
            .table td{
                display:block;
                width:100%;
            }

            .table tr{
                background:#fff;
                border:1px solid #e5e7eb;
                border-radius:14px;
                margin-bottom:12px;
                overflow:hidden;
                box-shadow:0 4px 14px rgba(15,23,42,.04);
            }

            .table tbody td{
                border:none;
                padding:10px 12px;
            }

            .table td::before{
                content:attr(data-label);
                display:block;
                font-size:.66rem;
                color:#64748b;
                font-weight:800;
                text-transform:uppercase;
                letter-spacing:.04em;
                margin-bottom:4px;
            }

            .table td[data-label="Acción"]{
                display:flex;
                align-items:center;
                justify-content:space-between;
                gap:10px;
            }

            .table td[data-label="Acción"]::before{
                margin-bottom:0;
            }

            .table td[data-label="Detalle"]{
                padding-top:4px;
            }

            .detail-td{
                width:100%;
            }

            .detail-box{
                max-width:100%;
            }
        }

        @media(max-width:576px){
            body{
                padding:6px !important;
            }

            .audit-wrap{
                padding:0;
            }

            .audit-header{
                padding:14px;
            }

            .filter-box{
                padding:12px;
            }

            .detail-grid{
                grid-template-columns:1fr;
            }

            .detail-line{
                align-items:flex-start;
            }

            .detail-line b{
                max-width:65%;
            }

            .action-cell{
                background:#f8fafc;
            }

            .pagination{
                justify-content:center !important;
            }
        }
    </style>
</head>

<body class="p-4">

<div class="audit-wrap">
    <div class="audit-card">

        <!--
        |----------------------------------------------------------------------
        | PASO 22: ENCABEZADO
        |----------------------------------------------------------------------
        -->
        <div class="audit-header">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="header-icon">
                        <i class="bi bi-clipboard-data"></i>
                    </div>
                    <div>
                        <h4 class="mb-0 fw-bold"></h4>
                        <div class="text-muted small">Registro de acciones del sistema</div>
                    </div>
                </div>

                <div class="total-box" id="total-badge">
                    <?= (int)$total ?> registros
                </div>
            </div>
        </div>

        <div class="p-3 p-md-4">

            <!--
            |------------------------------------------------------------------
            | PASO 23: FILTROS
            |------------------------------------------------------------------
            | Se quitó el filtro ID Usuario.
            |------------------------------------------------------------------
            -->
            <form class="filter-box row g-2 align-items-end" id="form-auditoria">
                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Desde</label>
                    <input type="date" name="desde" class="form-control" value="<?= h($desde) ?>">
                </div>

                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Hasta</label>
                    <input type="date" name="hasta" class="form-control" value="<?= h($hasta) ?>">
                </div>

                <div class="col-12 col-md-3">
                    <label class="form-label small text-muted">Acción</label>
                    <select name="accion" class="form-select">
                        <option value="">Todas</option>

                        <?php foreach ($acciones as $ac): ?>
                            <option value="<?= h($ac) ?>" <?= $accion === $ac ? 'selected' : '' ?>>
                                <?= h($ac) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-md-3">
                    <label class="form-label small text-muted">Buscar</label>
                    <input type="text" name="q" class="form-control" placeholder="Nombre, identidad, código..." value="<?= h($q) ?>">
                </div>

                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Por página</label>
                    <select name="perPage" class="form-select">
                        <?php foreach ([10, 25, 50, 100, 200] as $n): ?>
                            <option value="<?= $n ?>" <?= (int)$perPage === $n ? 'selected' : '' ?>><?= $n ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 d-flex gap-2 flex-wrap mt-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i> Filtrar
                    </button>

                    <button class="btn btn-outline-secondary" type="button" id="btn-limpiar">
                        <i class="bi bi-x-circle"></i> Limpiar
                    </button>
                </div>

                <input type="hidden" name="page" value="<?= (int)$page ?>">
            </form>

            <!--
            |------------------------------------------------------------------
            | PASO 24: TABLA
            |------------------------------------------------------------------
            -->
            <div class="table-box table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>IP</th>
                            <th>Detalle</th>
                        </tr>
                    </thead>

                    <tbody id="auditoria-tbody-wrap">
                        <?= render_auditoria_rows($rows) ?>
                    </tbody>
                </table>
            </div>

            <!--
            |------------------------------------------------------------------
            | PASO 25: PAGINACIÓN
            |------------------------------------------------------------------
            -->
            <nav class="mt-3">
                <ul class="pagination justify-content-end flex-wrap" id="aud-pagination"></ul>
            </nav>

        </div>
    </div>
</div>

<script>
/*
|--------------------------------------------------------------------------
| PASO 26: AJAX PARA FILTROS Y PAGINACIÓN
|--------------------------------------------------------------------------
*/
(function () {
    const form = document.getElementById("form-auditoria");
    const tbody = document.getElementById("auditoria-tbody-wrap");
    const btnLimpiar = document.getElementById("btn-limpiar");
    const pagination = document.getElementById("aud-pagination");
    const totalBadge = document.getElementById("total-badge");

    const AUDITORIA_URL = window.location.origin + "/app_descuento/auditoria/auditoria.php";

    function buildUrl(page = 1) {
        const fd = new FormData(form);

        fd.set("page", page);
        fd.set("ajax", 1);

        return AUDITORIA_URL + "?" + new URLSearchParams(fd).toString();
    }

    function attachPaginationEvents() {
        document.querySelectorAll("#aud-pagination button").forEach(btn => {
            btn.onclick = () => {
                const p = parseInt(btn.dataset.page, 10);

                if (!isNaN(p)) {
                    load(p);
                }
            };
        });
    }

    function load(page = 1) {
        form.querySelector('[name="page"]').value = page;

        tbody.innerHTML = "<tr><td colspan='6' class='text-center py-4 text-muted'><i class='bi bi-hourglass-split'></i> Cargando...</td></tr>";

        fetch(buildUrl(page))
            .then(r => r.json())
            .then(data => {
                tbody.innerHTML = data.tbody;
                pagination.innerHTML = data.pagination;

                if (totalBadge && typeof data.total !== "undefined") {
                    totalBadge.innerHTML = data.total + " registros";
                }

                attachPaginationEvents();
            })
            .catch(err => {
                console.error("Error:", err);
                tbody.innerHTML = "<tr><td colspan='6' class='text-center text-danger py-4'>Error cargando datos.</td></tr>";
            });
    }

    form.addEventListener("submit", e => {
        e.preventDefault();
        load(1);
    });

    btnLimpiar.addEventListener("click", () => {
        form.reset();
        form.querySelector('[name="page"]').value = 1;
        load(1);
    });

    load(<?= (int)$page ?>);
})();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
