<?php
// /api/config.php
return [
  // ===== EVOLUTION =====
  'evolution' => [
    'server' => '192.168.3.27',
    'db'     => 'EvoDb',
    'user'   => 'Consulta',
    'pass'   => 'Csa.2026',
  ],

  // ===== ICG =====
  'icg' => [
    'server' => '10.0.1.157',
    'user'   => 'icgadmin',
    'pass'   => 'masterkey',

  /*
    |--------------------------------------------------------------------------
    | MAPA DE BASES POR EMPRESA
    |--------------------------------------------------------------------------
    | IMPORTANTE:
    | - Acajoe NO va aquí porque usa la misma base que Mendels
    | - El alias se maneja en db_icg.php
    |--------------------------------------------------------------------------
    */
    'db_map' => [

      // Mendels (y Acajoe usan esta misma base)
      'mendels'  => 'MENDELS',

      // Detodo
      'detodo'   => 'DETODO',

      // Chesters
      'chesters' => 'CHESTERS',

    ],
  ],
];