<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

session_name('APP_DESCUENTO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        'ok' => false,
        'msg' => 'Sesión expirada. Inicie sesión nuevamente.',
        'data' => [],
        'total' => 0,
        'total_pages' => 1
    ], JSON_UNESCAPED_UNICODE);
    exit;
}


/*
|--------------------------------------------------------------------------
| OBJETIVO:
| - Consultar empleados desde Evolution
| - Cruzarlos con ICG por identidad
| - Manejar descuentos por empresa sin mezclar grupos
| - Corregir casos donde una misma identidad tiene varios CODCLIENTE en ICG
| - Priorizar el CODCLIENTE que sí tiene descuento válido
|--------------------------------------------------------------------------
*/
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
set_time_limit(300);

ob_start();


function jfail(string $msg, array $extra = []): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    http_response_code(500);

    echo json_encode(
        ["ok" => false, "msg" => $msg] + $extra,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}


function limpiar_nif($s): string
{
    return preg_replace('/\D+/', '', trim((string)($s ?? '')));
}


function formatear_identidad_hn(string $id): string
{
    $id = limpiar_nif($id);

    if (strlen($id) === 13) {
        return substr($id, 0, 4) . '-' .
               substr($id, 4, 4) . '-' .
               substr($id, 8, 5);
    }

    return $id;
}


function norm_filtro_ui($f): string
{
    $f = strtolower(trim((string)($f ?? '')));

    if ($f === 'con') {
        return 'con';
    }

    if ($f === 'sin') {
        return 'sin';
    }

    return 'todos';
}


function norm_modo($m): string
{
    $m = strtolower(trim((string)($m ?? 'normal')));

    if ($m === 'auditoria_icg') {
        return 'auditoria_icg';
    }

    if ($m === 'auditoria_evolution') {
        return 'auditoria_evolution';
    }

    if ($m === 'solo_evolution') {
        return 'solo_evolution';
    }

    if ($m === 'solo_icg') {
        return 'solo_icg';
    }

    return 'normal';
}


function norm_debug($d): bool
{
    $d = strtolower(trim((string)($d ?? '0')));
    return in_array($d, ['1', 'true', 'si', 'sí', 'yes', 'on'], true);
}

/*
|--------------------------------------------------------------------------
| FUNCIONES DE DESCUENTO POR EMPRESA
|--------------------------------------------------------------------------
*/
function grupos_validos_empresa(string $empresa, array $cfg): array
{
    return $cfg[$empresa]['grupos_validos'] ?? [];
}

function map_pct_empresa(string $empresa, array $cfg): array
{
    return $cfg[$empresa]['map_pct'] ?? [];
}

function tiene_descuento_valido(string $empresa, int $idgrupo, array $cfg): bool
{
    return in_array($idgrupo, grupos_validos_empresa($empresa, $cfg), true);
}

function porcentaje_descuento(string $empresa, int $idgrupo, array $cfg): string
{
    $map = map_pct_empresa($empresa, $cfg);
    return $map[$idgrupo] ?? '';
}


function normalizar_empresa_param(string $empresa, array $empresasPermitidas): string
{
    $empresa = strtolower(trim($empresa));
    return in_array($empresa, $empresasPermitidas, true) ? $empresa : '';
}

function fila_respuesta(
    string $empresa,
    string $codigo,
    string $identidadNum,
    string $nombre,
    bool $tieneValido,
    string $tipoDescuento,
    string $estado,
    int $idgrupo,
    bool $debug
): array {
    $row = [
        "empresa"         => $empresa,
        "codigo"          => $codigo,
        "identidad"       => formatear_identidad_hn($identidadNum),
        "identidad_num"   => $identidadNum,
        "nombre"          => $nombre,
        "tiene_descuento" => $tieneValido,
        "tipo_descuento"  => $tipoDescuento,
        "estado"          => $estado,
    ];

    if ($debug) {
        $row["idgrupo_encontrado"] = $idgrupo;
        $row["grupo_valido_empresa"] = $tieneValido;
        $row["empresa_consultada"] = $empresa;
    }

    return $row;
}

try {
   
    require_once __DIR__ . "/db_icg.php";
    require_once __DIR__. "/db_evolution.php";

    $BUILD = "empleados_all.php build 2026-08-15 v26.1 (optimizado sin cambiar lógica original)";

    if (!function_exists('obtener_empleados_evolution')) {
        jfail("No existe obtener_empleados_evolution()");
    }

    if (!function_exists('icg_pdo')) {
        jfail("No existe icg_pdo()");
    }

    /*
    |--------------------------------------------------------------------------
    | DESCUENTOS POR EMPRESA
    |--------------------------------------------------------------------------
    | IMPORTANTE:
    | - Mendels y Acajoe pueden compartir base
    | - Pero los grupos son separados
    |--------------------------------------------------------------------------
    */
    $DESCUENTOS_EMPRESA = [
        'mendels' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'acajoe' => [
            'grupos_validos' => [15, 16, 17, 18],
            'map_pct' => [
                15 => '10%',
                16 => '20%',
                17 => '40%',
                18 => '50%',
            ],
        ],
        'detodo' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'chesters' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
    ];

    $empresasPermitidas = ['mendels', 'acajoe', 'detodo', 'chesters'];

    $modo         = norm_modo($_GET['modo'] ?? 'normal');
    $filtro       = norm_filtro_ui($_GET['filtro'] ?? 'todos');
    $q            = trim((string)($_GET['q'] ?? ''));
    $page         = (int)($_GET['page'] ?? 1);
    $perPage      = (int)($_GET['per_page'] ?? 100);
    $maxEvo       = (int)($_GET['max_evo'] ?? 50000);
    $empresaParam = normalizar_empresa_param((string)($_GET['empresa'] ?? ''), $empresasPermitidas);
    $debug        = norm_debug($_GET['debug'] ?? '0');

    if ($page < 1) {
        $page = 1;
    }

    if ($perPage < 1) {
        $perPage = 100;
    }

    if ($perPage > 200) {
        $perPage = 200;
    }

    if ($maxEvo < 1) {
        $maxEvo = 50000;
    }

   
    $empleados = obtener_empleados_evolution($maxEvo);

    if (!is_array($empleados)) {
        $empleados = [];
    }

   
    if ($q !== '' && in_array($modo, ['normal', 'auditoria_evolution', 'solo_evolution'], true)) {
        $qLower = mb_strtolower($q, 'UTF-8');
        $qNum   = preg_replace('/\D+/', '', $qLower);

        $empleados = array_values(array_filter($empleados, function ($e) use ($qLower, $qNum) {
            $nom = mb_strtolower((string)($e['nombre'] ?? ''), 'UTF-8');
            $idV = (string)($e['identidad'] ?? '');
            $idN = limpiar_nif($e['identidad_num'] ?? '');

            if ($idN === '') {
                $idN = limpiar_nif($idV);
            }

            return
                (strpos($nom, $qLower) !== false) ||
                (strpos(mb_strtolower($idV, 'UTF-8'), $qLower) !== false) ||
                ($qNum !== '' && $idN !== '' && strpos($idN, $qNum) !== false);
        }));
    }

    /*
    |--------------------------------------------------------------------------
    | MAPA DE EVOLUTION POR IDENTIDAD LIMPIA
    |--------------------------------------------------------------------------
    */
    $evoMap = [];

    foreach ($empleados as $e) {
        $idVisual = trim((string)($e['identidad'] ?? ''));
        $idNum    = limpiar_nif($e['identidad_num'] ?? '');

        if ($idNum === '') {
            $idNum = limpiar_nif($idVisual);
        }

        if ($idNum === '') {
            continue;
        }

        $nombre = preg_replace('/\s+/', ' ', trim((string)($e['nombre'] ?? '')));

        $evoMap[$idNum] = [
            "identidad"     => $idVisual !== '' ? $idVisual : formatear_identidad_hn($idNum),
            "identidad_num" => $idNum,
            "nombre"        => $nombre,
        ];
    }

    $idsAll = array_keys($evoMap);

    if ($empresaParam !== '') {
        $empresas = [$empresaParam];
    } else {
        $empresas = $empresasPermitidas;
    }

    $rows = [];

    $descuentos_por_empresa = [
        "mendels"  => 0,
        "acajoe"   => 0,
        "detodo"   => 0,
        "chesters" => 0,
    ];

    $cruce_por_empresa = [
        "mendels"  => 0,
        "acajoe"   => 0,
        "detodo"   => 0,
        "chesters" => 0,
    ];

    $debug_info = [
        "parametros" => [
            "modo" => $modo,
            "filtro" => $filtro,
            "q" => $q,
            "page" => $page,
            "per_page" => $perPage,
            "max_evo" => $maxEvo,
            "empresa" => $empresaParam !== '' ? $empresaParam : 'todas',
            "debug" => $debug,
        ],
        "empresas_consultadas" => $empresas,
        "descuentos_empresa" => $debug ? $DESCUENTOS_EMPRESA : null,
        "conteo_evolution" => count($evoMap),
    ];

    /*
    |--------------------------------------------------------------------------
    | CONSULTAR ICG COMPLETO
    |--------------------------------------------------------------------------
    */
    $queryICGAll = function (string $empresa) use ($DESCUENTOS_EMPRESA): array {
        $pdo = icg_pdo($empresa);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $grupos = grupos_validos_empresa($empresa, $DESCUENTOS_EMPRESA);

        if (!$grupos) {
            $grupos = [0];
        }

        $gruposSql = implode(',', array_map('intval', $grupos));

        $sql = "
            WITH grp_valid AS (
                SELECT
                    TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                    MAX(IDGRUPO) AS IDGRUPO
                FROM CONDICIONESGRUPOSCLIENTES
                WHERE CAMPO = 'CODCLIENTE'
                  AND IDGRUPO IN ($gruposSql)
                  AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
                GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
            )
            SELECT TOP 5000
                c.CODCLIENTE,
                LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE, ''))) AS nombre_icg,
                LTRIM(RTRIM(ISNULL(c.NIF20, ''))) AS identidad_icg,
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20, ''))), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '') AS identidad_num_icg,
                LTRIM(RTRIM(ISNULL(c.BLOQUEADO, ''))) AS BLOQUEADO,
                ISNULL(gv.IDGRUPO, 0) AS IDGRUPO
            FROM CLIENTES c
            LEFT JOIN grp_valid gv
                ON gv.CODCLIENTE = c.CODCLIENTE
            WHERE LTRIM(RTRIM(ISNULL(c.NIF20, ''))) <> ''
              AND ISNULL(c.BLOQUEADO, 'F') <> 'T'
            ORDER BY
                CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
                CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
                c.CODCLIENTE DESC
        ";

        $st = $pdo->query($sql);
        $out = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $pdo = null;

        return $out;
    };

    /*
    |--------------------------------------------------------------------------
    | CONSULTAR ICG POR IDENTIDAD EXACTA
    |--------------------------------------------------------------------------
    */
    $queryICGByIdentidad = function (string $empresa, string $identidadNum) use ($DESCUENTOS_EMPRESA): ?array {
        $pdo = icg_pdo($empresa);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $grupos = grupos_validos_empresa($empresa, $DESCUENTOS_EMPRESA);

        if (!$grupos) {
            $grupos = [0];
        }

        $gruposSql = implode(',', array_map('intval', $grupos));

        $sql = "
            WITH grp_valid AS (
                SELECT
                    TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                    MAX(IDGRUPO) AS IDGRUPO
                FROM CONDICIONESGRUPOSCLIENTES
                WHERE CAMPO = 'CODCLIENTE'
                  AND IDGRUPO IN ($gruposSql)
                  AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
                GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
            )
            SELECT TOP 1
                c.CODCLIENTE,
                LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE, ''))) AS nombre_icg,
                LTRIM(RTRIM(ISNULL(c.NIF20, ''))) AS identidad_icg,
                REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20, ''))), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '') AS identidad_num_icg,
                LTRIM(RTRIM(ISNULL(c.BLOQUEADO, ''))) AS BLOQUEADO,
                ISNULL(gv.IDGRUPO, 0) AS IDGRUPO
            FROM CLIENTES c
            LEFT JOIN grp_valid gv
                ON gv.CODCLIENTE = c.CODCLIENTE
            WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20, ''))), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '') = ?
              AND ISNULL(c.BLOQUEADO, 'F') <> 'T'
            ORDER BY
                CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
                CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
                c.CODCLIENTE DESC
        ";

        $st = $pdo->prepare($sql);
        $st->execute([$identidadNum]);
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: null;

        $pdo = null;

        return $row;
    };

   
    $icgMap = [];
    $icgMapByKey = [];

    $necesitaICGCompleto = in_array($modo, ['auditoria_icg', 'auditoria_evolution'], true);

    if ($necesitaICGCompleto) {
        $seenMap = [];

        foreach ($empresas as $empresa) {
            $icgRows = $queryICGAll($empresa);

            foreach ($icgRows as $r) {
                $idNumICG = limpiar_nif($r['identidad_num_icg'] ?? '');

                if ($idNumICG === '') {
                    continue;
                }

                $key = $empresa . '|' . $idNumICG;

                $idgrupo = (int)($r['IDGRUPO'] ?? 0);
                $tieneValido = tiene_descuento_valido($empresa, $idgrupo, $DESCUENTOS_EMPRESA);
                $bloqueadoRaw = strtoupper(trim((string)($r['BLOQUEADO'] ?? '')));
                $esActivo = ($bloqueadoRaw !== 'T');

                $nuevoItem = [
                    "key"              => $key,
                    "codigo"           => (string)($r['CODCLIENTE'] ?? ''),
                    "nombre"           => preg_replace('/\s+/', ' ', trim((string)($r['nombre_icg'] ?? ''))),
                    "idgrupo"          => $idgrupo,
                    "empresa"          => $empresa,
                    "identidad_num"    => $idNumICG,
                    "tiene_descuento"  => $tieneValido,
                    "activo"           => $esActivo,
                    "bloqueado"        => $bloqueadoRaw,
                ];

                if (isset($seenMap[$key])) {
                    $idx = $seenMap[$key];
                    $actualItem = $icgMap[$idx];

                    $reemplazar = false;

                    // BLOQUEADO='T' ya fue excluido por SQL; se conserva esta prioridad por seguridad.
                    if ($nuevoItem["activo"] && empty($actualItem["activo"])) {
                        $reemplazar = true;
                    }
                    // Si ambas tienen el mismo estado, gana la que tiene grupo válido.
                    elseif (
                        $nuevoItem["activo"] === (bool)($actualItem["activo"] ?? false)
                        && $nuevoItem["tiene_descuento"]
                        && empty($actualItem["tiene_descuento"])
                    ) {
                        $reemplazar = true;
                    }

                    if ($reemplazar) {
                        $icgMap[$idx] = $nuevoItem;
                    }

                    continue;
                }

                $seenMap[$key] = count($icgMap);
                $icgMap[] = $nuevoItem;
            }
        }

        if ($modo === 'auditoria_evolution') {
            foreach ($icgMap as $item) {
                $icgMapByKey[$item['key']] = $item;
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MODO NORMAL
    |--------------------------------------------------------------------------
    */
    if ($modo === 'normal') {
        if (!count($idsAll)) {
            while (ob_get_level() > 0) {
                ob_end_clean();
            }

            $resp = [
                "ok" => true,
                "msg" => "No existe en Evolution o no hay datos para cruzar",
                "build" => $BUILD,
                "modo" => $modo,
                "empresa" => $empresaParam !== '' ? $empresaParam : 'todas',
                "page" => $page,
                "per_page" => $perPage,
                "total" => 0,
                "total_pages" => 1,
                "data" => [],
                "total_cruce" => 0,
                "total_con_descuento" => 0,
                "total_sin_descuento" => 0,
                "descuentos_por_empresa" => $descuentos_por_empresa,
                "cruce_por_empresa" => $cruce_por_empresa,
            ];

            if ($debug) {
                $resp["debug_info"] = $debug_info;
            }

            echo json_encode($resp, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
            exit;
        }

        $chunkSize = 50000;

        /*
        |--------------------------------------------------------------------------
        | CONSULTA ICG POR BLOQUES
        |--------------------------------------------------------------------------
        | Esta consulta ordena primero los CODCLIENTE que sí tienen descuento.
        |--------------------------------------------------------------------------
        */
        $queryICG = function (string $empresa, array $idsChunk) use ($DESCUENTOS_EMPRESA): array {
            $pdo = icg_pdo($empresa);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $json = json_encode(array_values($idsChunk), JSON_UNESCAPED_UNICODE);

            if ($json === false) {
                throw new RuntimeException("No se pudo convertir idsChunk a JSON");
            }

            $grupos = grupos_validos_empresa($empresa, $DESCUENTOS_EMPRESA);

            if (!$grupos) {
                $grupos = [0];
            }

            $gruposSql = implode(',', array_map('intval', $grupos));

            $sql = "
                WITH ids AS (
                    SELECT LTRIM(RTRIM([value])) AS identidad_num
                    FROM OPENJSON(?)
                    WHERE LTRIM(RTRIM([value])) <> ''
                ),
                grp_valid AS (
                    SELECT
                        TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                        MAX(IDGRUPO) AS IDGRUPO
                    FROM CONDICIONESGRUPOSCLIENTES
                    WHERE CAMPO = 'CODCLIENTE'
                      AND IDGRUPO IN ($gruposSql)
                      AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
                    GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
                )
                SELECT
                    i.identidad_num,
                    c.CODCLIENTE,
                    LTRIM(RTRIM(ISNULL(c.BLOQUEADO, ''))) AS BLOQUEADO,
                    ISNULL(gv.IDGRUPO, 0) AS IDGRUPO
                FROM CLIENTES c
                INNER JOIN ids i
                    ON i.identidad_num =
                        REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                            LTRIM(RTRIM(ISNULL(c.NIF20,''))),
                        '-',''),' ',''),'.',''),'/',''), CHAR(9), '')
                LEFT JOIN grp_valid gv
                    ON gv.CODCLIENTE = c.CODCLIENTE
                WHERE ISNULL(c.BLOQUEADO, 'F') <> 'T'
                ORDER BY
                    CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
                    CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
                    c.CODCLIENTE DESC
            ";

            $st = $pdo->prepare($sql);
            $st->execute([$json]);

            $out = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $pdo = null;

            return $out;
        };

        /*
        |--------------------------------------------------------------------------
        | BEST ROWS
        |--------------------------------------------------------------------------
        | Aquí guardamos la mejor fila por empresa + identidad.
        | Si hay duplicados, gana el CODCLIENTE con descuento válido.
        |--------------------------------------------------------------------------
        */
        $bestRows = [];

        foreach ($empresas as $empresa) {
            for ($i = 0; $i < count($idsAll); $i += $chunkSize) {
                $chunk = array_slice($idsAll, $i, $chunkSize);
                $icgRows = $queryICG($empresa, $chunk);

                foreach ($icgRows as $r) {
                    $idNumICG = limpiar_nif($r['identidad_num'] ?? '');

                    if ($idNumICG === '' || !isset($evoMap[$idNumICG])) {
                        continue;
                    }

                    $key = $empresa . '|' . $idNumICG;

                    $cod = (string)($r['CODCLIENTE'] ?? '');
                    $idgrupo = (int)($r['IDGRUPO'] ?? 0);
                    $tieneValido = tiene_descuento_valido($empresa, $idgrupo, $DESCUENTOS_EMPRESA);
                    $bloqueadoRaw = strtoupper(trim((string)($r['BLOQUEADO'] ?? '')));
                    $esActivo = ($bloqueadoRaw !== 'T');

                    $candidate = [
                        "empresa"         => $empresa,
                        "codigo"          => $cod,
                        "identidad_num"   => $idNumICG,
                        "nombre"          => $evoMap[$idNumICG]['nombre'],
                        "tiene_descuento" => $tieneValido,
                        "idgrupo"         => $idgrupo,
                        "activo"          => $esActivo,
                        "bloqueado"       => $bloqueadoRaw,
                    ];

                    if (!isset($bestRows[$key])) {
                        $bestRows[$key] = $candidate;
                        continue;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | ELEGIR LA MEJOR FICHA
                    |--------------------------------------------------------------------------
                    | 1) Una ficha activa (F o NULL) siempre gana sobre una T.
                    | 2) Si ambas tienen el mismo estado, gana la que tiene descuento
                    |    válido para la empresa.
                    |--------------------------------------------------------------------------
                    */
                    $actual = $bestRows[$key];

                    if ($candidate["activo"] && !$actual["activo"]) {
                        $bestRows[$key] = $candidate;
                    } elseif (
                        $candidate["activo"] === $actual["activo"]
                        && $candidate["tiene_descuento"]
                        && !$actual["tiene_descuento"]
                    ) {
                        $bestRows[$key] = $candidate;
                    }
                }
            }
        }

        /*
        |--------------------------------------------------------------------------
        | APLICAR FILTROS Y ARMAR RESPUESTA FINAL
        |--------------------------------------------------------------------------
        */
        foreach ($bestRows as $item) {
            $empresa = $item["empresa"];
            $tieneValido = (bool)$item["tiene_descuento"];
            $idgrupo = (int)$item["idgrupo"];

            $cruce_por_empresa[$empresa]++;

            if ($tieneValido) {
                $descuentos_por_empresa[$empresa]++;
            }

            if ($filtro === 'con' && !$tieneValido) {
                continue;
            }

            if ($filtro === 'sin' && $tieneValido) {
                continue;
            }

            $rows[] = fila_respuesta(
                $empresa,
                (string)$item["codigo"],
                (string)$item["identidad_num"],
                (string)$item["nombre"],
                $tieneValido,
                $tieneValido ? porcentaje_descuento($empresa, $idgrupo, $DESCUENTOS_EMPRESA) : "",
                "CRUCE_OK",
                $idgrupo,
                $debug
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MODO AUDITORIA_ICG
    |--------------------------------------------------------------------------
    */
    if ($modo === 'auditoria_icg') {
        $seen = [];

        foreach ($icgMap as $item) {
            $empresa = $item['empresa'];
            $idNumICG = $item['identidad_num'];
            $key = $item['key'];

            if (isset($seen[$key])) {
                continue;
            }

            $seen[$key] = true;

            if (isset($evoMap[$idNumICG])) {
                continue;
            }

            if ($q !== '') {
                $qLower = mb_strtolower($q, 'UTF-8');
                $qNum = preg_replace('/\D+/', '', $qLower);
                $nomICG = mb_strtolower((string)($item['nombre'] ?? ''), 'UTF-8');

                $match =
                    ($nomICG !== '' && strpos($nomICG, $qLower) !== false) ||
                    ($qNum !== '' && strpos($idNumICG, $qNum) !== false);

                if (!$match) {
                    continue;
                }
            }

            $idgrupo = (int)$item['idgrupo'];
            $tieneValido = tiene_descuento_valido($empresa, $idgrupo, $DESCUENTOS_EMPRESA);

            if ($filtro === 'con' && !$tieneValido) {
                continue;
            }

            if ($filtro === 'sin' && $tieneValido) {
                continue;
            }

            $rows[] = fila_respuesta(
                $empresa,
                (string)$item['codigo'],
                $idNumICG,
                $item['nombre'] !== '' ? $item['nombre'] : 'SIN NOMBRE EN ICG',
                $tieneValido,
                $tieneValido ? porcentaje_descuento($empresa, $idgrupo, $DESCUENTOS_EMPRESA) : "",
                "SOLO_ICG",
                $idgrupo,
                $debug
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MODO AUDITORIA_EVOLUTION
    |--------------------------------------------------------------------------
    */
    if ($modo === 'auditoria_evolution') {
        $seen = [];

        foreach ($evoMap as $idNum => $evo) {
            if ($q !== '') {
                $qLower = mb_strtolower($q, 'UTF-8');
                $qNum   = preg_replace('/\D+/', '', $qLower);
                $nomEvo = mb_strtolower((string)($evo['nombre'] ?? ''), 'UTF-8');
                $idVEvo = mb_strtolower((string)($evo['identidad'] ?? ''), 'UTF-8');

                $match =
                    ($nomEvo !== '' && strpos($nomEvo, $qLower) !== false) ||
                    ($idVEvo !== '' && strpos($idVEvo, $qLower) !== false) ||
                    ($qNum !== '' && strpos($idNum, $qNum) !== false);

                if (!$match) {
                    continue;
                }
            }

            foreach ($empresas as $empresa) {
                $key = $empresa . '|' . $idNum;

                if (isset($seen[$key])) {
                    continue;
                }

                $seen[$key] = true;

                if (isset($icgMapByKey[$key])) {
                    continue;
                }

                $rows[] = fila_respuesta(
                    $empresa,
                    "",
                    $idNum,
                    $evo['nombre'],
                    false,
                    "",
                    "SOLO_EVOLUTION",
                    0,
                    $debug
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MODO SOLO_EVOLUTION
    |--------------------------------------------------------------------------
    */
    if ($modo === 'solo_evolution') {
        foreach ($evoMap as $idNum => $evo) {
            if ($q !== '') {
                $qLower = mb_strtolower($q, 'UTF-8');
                $qNum   = preg_replace('/\D+/', '', $qLower);

                $nomEvo = mb_strtolower((string)($evo['nombre'] ?? ''), 'UTF-8');
                $idVEvo = mb_strtolower((string)($evo['identidad'] ?? ''), 'UTF-8');

                $match =
                    ($nomEvo !== '' && strpos($nomEvo, $qLower) !== false) ||
                    ($idVEvo !== '' && strpos($idVEvo, $qLower) !== false) ||
                    ($qNum !== '' && strpos($idNum, $qNum) !== false);

                if (!$match) {
                    continue;
                }
            }

            $codigoICG = "";
            $tieneValido = false;
            $existeEnICG = false;
            $empresaICG = "";
            $idgrupo = 0;

            foreach ($empresas as $empresa) {
                $rowICG = $queryICGByIdentidad($empresa, $idNum);

                if ($rowICG) {
                    $existeEnICG = true;
                    $empresaICG = $empresa;
                    $codigoICG = (string)($rowICG['CODCLIENTE'] ?? '');
                    $idgrupo = (int)($rowICG['IDGRUPO'] ?? 0);
                    $tieneValido = tiene_descuento_valido($empresa, $idgrupo, $DESCUENTOS_EMPRESA);
                    break;
                }
            }

            if ($filtro === 'con' && !$tieneValido) {
                continue;
            }

            if ($filtro === 'sin' && $tieneValido) {
                continue;
            }

            $rows[] = fila_respuesta(
                $empresaICG !== '' ? $empresaICG : ($empresaParam !== '' ? $empresaParam : 'sin_empresa_icg'),
                $codigoICG,
                $idNum,
                $evo['nombre'],
                $tieneValido,
                ($existeEnICG && $empresaICG !== '' && $tieneValido)
                    ? porcentaje_descuento($empresaICG, $idgrupo, $DESCUENTOS_EMPRESA)
                    : "",
                $existeEnICG ? "CRUCE_OK" : "SOLO_EVOLUTION",
                $idgrupo,
                $debug
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MODO SOLO_ICG
    |--------------------------------------------------------------------------
    */
    if ($modo === 'solo_icg') {
        if ($q === '') {
            jfail("Debes enviar ?q=IDENTIDAD en modo solo_icg");
        }

        $idNum = limpiar_nif($q);

        if ($idNum === '') {
            jfail("Identidad inválida");
        }

        $encontrado = false;

        foreach ($empresas as $empresa) {
            $rowICG = $queryICGByIdentidad($empresa, $idNum);

            if (!$rowICG) {
                continue;
            }

            $encontrado = true;

            $cod = (string)($rowICG['CODCLIENTE'] ?? '');
            $nombreICG = preg_replace('/\s+/', ' ', trim((string)($rowICG['nombre_icg'] ?? '')));
            $idgrupo = (int)($rowICG['IDGRUPO'] ?? 0);
            $tieneValido = tiene_descuento_valido($empresa, $idgrupo, $DESCUENTOS_EMPRESA);

            $existeEnEvolution = isset($evoMap[$idNum]);

            if ($filtro === 'con' && !$tieneValido) {
                continue;
            }

            if ($filtro === 'sin' && $tieneValido) {
                continue;
            }

            $rows[] = fila_respuesta(
                $empresa,
                $cod,
                $idNum,
                $existeEnEvolution ? $evoMap[$idNum]['nombre'] : ($nombreICG !== '' ? $nombreICG : 'SIN NOMBRE EN ICG'),
                $tieneValido,
                $tieneValido ? porcentaje_descuento($empresa, $idgrupo, $DESCUENTOS_EMPRESA) : "",
                $existeEnEvolution ? "CRUCE_OK" : "SOLO_ICG",
                $idgrupo,
                $debug
            );
        }

        if (!$encontrado) {
            $rows = [];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PAGINACIÓN
    |--------------------------------------------------------------------------
    */
    $total = count($rows);
    $totalPages = max(1, (int)ceil($total / max(1, $perPage)));

    if ($page > $totalPages) {
        $page = $totalPages;
    }

    $offset = ($page - 1) * $perPage;
    $dataPage = array_slice($rows, $offset, $perPage);

    /*
    |--------------------------------------------------------------------------
    | RESUMEN
    |--------------------------------------------------------------------------
    */
    $total_cruce = array_sum($cruce_por_empresa);
    $total_con_descuento = array_sum($descuentos_por_empresa);
    $total_sin_descuento = max(0, $total_cruce - $total_con_descuento);

    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    $response = [
        "ok" => true,
        "msg" => $total > 0
            ? "Datos encontrados correctamente"
            : (
                $modo === 'solo_icg'
                    ? "No existe en ICG"
                    : (
                        $modo === 'solo_evolution'
                            ? "No existe en Evolution"
                            : (
                                $modo === 'normal'
                                    ? "No hay cruce entre Evolution e ICG"
                                    : "No se encontraron resultados"
                            )
                    )
            ),
        "build" => $BUILD,
        "modo" => $modo,
        "empresa" => $empresaParam !== '' ? $empresaParam : 'todas',
        "page" => $page,
        "per_page" => $perPage,
        "total" => $total,
        "total_pages" => $totalPages,
        "data" => $dataPage,
        "total_cruce" => $total_cruce,
        "total_con_descuento" => $total_con_descuento,
        "total_sin_descuento" => $total_sin_descuento,
        "descuentos_por_empresa" => $descuentos_por_empresa,
        "cruce_por_empresa" => $cruce_por_empresa,
    ];

    if ($debug) {
        $debug_info["conteo_icg_map"] = count($icgMap);
        $debug_info["conteo_rows_total"] = $total;
        $response["debug_info"] = $debug_info;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

} catch (Throwable $e) {
    jfail("Error en empleados_all.php", [
        "detail" => $e->getMessage(),
        "file"   => $e->getFile(),
        "line"   => $e->getLine(),
    ]);
}