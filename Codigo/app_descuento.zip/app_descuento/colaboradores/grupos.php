<?php
/*
|--------------------------------------------------------------------------
| ARCHIVO: /api/descuento.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Consultar si un cliente tiene descuento en ICG.
| - Recibe empresa e identidad por GET.
| - Devuelve JSON.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: RESPUESTA JSON
|--------------------------------------------------------------------------
*/
header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| PASO 2: INICIAR LA MISMA SESIÓN DE LA APP
|--------------------------------------------------------------------------
*/
session_name('APP_DESCUENTO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| PASO 3: VALIDAR SESIÓN PARA AJAX
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        "ok" => false,
        "msg" => "Sesión expirada. Inicie sesión nuevamente.",
        "tiene_descuento" => false,
        "data" => null
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 4: CONEXIÓN A ICG
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/db_icg.php';

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIÓN DE ERROR
|--------------------------------------------------------------------------
*/
function fail($msg, $extra = []) {
    echo json_encode(
        ["ok" => false, "msg" => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 6: LEER PARÁMETROS
|--------------------------------------------------------------------------
*/
$empresa   = strtolower(trim($_GET['empresa'] ?? 'mendels'));
$identidad = trim($_GET['identidad'] ?? '');

/*
|--------------------------------------------------------------------------
| PASO 7: VALIDAR EMPRESA
|--------------------------------------------------------------------------
*/
$empresasPermitidas = ['mendels', 'acajoe', 'detodo', 'chesters'];

if (!in_array($empresa, $empresasPermitidas, true)) {
    fail("Empresa inválida.");
}

/*
|--------------------------------------------------------------------------
| PASO 8: VALIDAR IDENTIDAD
|--------------------------------------------------------------------------
*/
if ($identidad === '') {
    fail("Falta identidad.");
}

/*
|--------------------------------------------------------------------------
| PASO 9: CONECTAR A ICG
|--------------------------------------------------------------------------
| IMPORTANTE:
| Este archivo usa icg_conn($empresa).
| Si tu db_icg.php usa icg_pdo($empresa), avísame porque cambia esta parte.
|--------------------------------------------------------------------------
*/
[$conn, $db] = icg_conn($empresa);

if (!$conn) {
    fail("No conecta a ICG ($db)", ["errors" => sqlsrv_errors()]);
}

/*
|--------------------------------------------------------------------------
| PASO 10: CONSULTA SQL
|--------------------------------------------------------------------------
*/
$sql = "
SELECT TOP 1
  c.CODCLIENTE,
  c.NOMBRECLIENTE,
  c.CIF,
  x.IDGRUPO,
  g.DESCRIPCION AS tipo_descuento
FROM CLIENTES c
INNER JOIN (
  SELECT
    TRY_CAST(d.VALOR AS INT) AS CODCLIENTE,
    d.IDGRUPO
  FROM CONDICIONESGRUPOSCLIENTES d
  WHERE d.CAMPO = 'CODCLIENTE'
) x
  ON x.CODCLIENTE = c.CODCLIENTE
INNER JOIN GRUPOSCLIENTES g
  ON g.IDGRUPO = x.IDGRUPO
WHERE
  REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.CIF,''))), '-', ''), ' ', '') =
  REPLACE(REPLACE(?, '-', ''), ' ', '')
ORDER BY x.IDGRUPO DESC
";

/*
|--------------------------------------------------------------------------
| PASO 11: EJECUTAR CONSULTA
|--------------------------------------------------------------------------
*/
$stmt = sqlsrv_query($conn, $sql, [$identidad]);

if (!$stmt) {
    fail("Error consultando descuento", ["errors" => sqlsrv_errors()]);
}

/*
|--------------------------------------------------------------------------
| PASO 12: OBTENER RESULTADO
|--------------------------------------------------------------------------
*/
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| PASO 13: RESPUESTA FINAL
|--------------------------------------------------------------------------
*/
echo json_encode([
    "ok" => true,
    "empresa" => $empresa,
    "bd" => $db,
    "tiene_descuento" => $row ? true : false,
    "data" => $row ?: null
], JSON_UNESCAPED_UNICODE);

/*
|--------------------------------------------------------------------------
| PASO 14: CERRAR CONEXIÓN
|--------------------------------------------------------------------------
*/
sqlsrv_close($conn);
exit;