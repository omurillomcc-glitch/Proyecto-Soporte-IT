<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

session_name('APP_DESCUENTO');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        "ok" => false,
        "msg" => "Sesión expirada. Inicie sesión nuevamente.",
        "data" => null,
        "extra" => []
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

ob_start();

$DEBUG = isset($_GET['debug']) && $_GET['debug'] === '1';

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting($DEBUG ? E_ALL : 0);
set_time_limit(240);

require_once __DIR__ . "/db_icg.php";

function out(bool $ok, string $msg, $data = null, array $extra = []): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    echo json_encode([
        "ok" => $ok,
        "msg" => $msg,
        "data" => $data,
        "extra" => $extra,
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function norm_text($s): string
{
    return trim((string)($s ?? ''));
}

function norm_id(string $s): string
{
    $v = preg_replace('/\D+/', '', trim($s));
    return $v ?: '';
}

function norm_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));

    $map = [
        'mendels'  => 'mendels',
        'acajoe'   => 'acajoe',
        'detodo'   => 'detodo',
        'de todo'  => 'detodo',
        'de-todo'  => 'detodo',
        'chesters' => 'chesters',
    ];

    return $map[$empresa] ?? $empresa;
}

function descuentos_empresa_config(): array
{
    return [
        'mendels' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'acajoe' => [
            'grupos_validos' => [15, 16, 17, 18],
            'map_pct' => [
                15 => '10%',
                16 => '20%',
                17 => '40%',
                18 => '50%',
            ],
        ],
        'detodo' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'chesters' => [
            'grupos_validos' => [12, 13, 14],
            'map_pct' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
    ];
}

function grupos_validos_por_empresa(string $empresa, array $cfg): array
{
    return $cfg[$empresa]['grupos_validos'] ?? [];
}

function porcentaje_por_empresa(string $empresa, int $idgrupo, array $cfg): string
{
    return $cfg[$empresa]['map_pct'][$idgrupo] ?? '';
}

try {
    $CFG_DESCUENTOS = descuentos_empresa_config();
    $empresasPermitidas = array_keys($CFG_DESCUENTOS);

    $empresaRaw = (string)($_POST['empresa'] ?? $_GET['empresa'] ?? '');
    $empresa = norm_empresa($empresaRaw);

    $identidadRaw = (string)($_POST['identidad'] ?? $_GET['identidad'] ?? '');
    $identidad = norm_id($identidadRaw);

    $idgrupo = (int)($_POST['idgrupo'] ?? $_GET['idgrupo'] ?? 0);

    if (!in_array($empresa, $empresasPermitidas, true)) {
        out(false, "Empresa inválida", null, $DEBUG ? [
            "empresa_recibida" => $empresaRaw,
            "empresa_normalizada" => $empresa,
            "empresas_validas" => $empresasPermitidas,
        ] : []);
    }

    if ($identidad === '') {
        out(false, "Identidad vacía o inválida", null, $DEBUG ? [
            "identidad_recibida" => $identidadRaw,
        ] : []);
    }

    $gruposValidos = grupos_validos_por_empresa($empresa, $CFG_DESCUENTOS);

    if (!$gruposValidos) {
        out(false, "No hay grupos configurados para la empresa", null, $DEBUG ? [
            "empresa" => $empresa,
        ] : []);
    }

    if ($idgrupo !== 0 && !in_array($idgrupo, $gruposValidos, true)) {
        out(false, "El grupo no es válido para esta empresa", null, $DEBUG ? [
            "empresa" => $empresa,
            "idgrupo_recibido" => $idgrupo,
            "grupos_validos_empresa" => $gruposValidos,
        ] : []);
    }

    $pdo = icg_pdo($empresa);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /*
     * IMPORTANTE:
     * La misma lógica de grupos_descuento.php:
     * - NO filtra BLOQUEADO.
     * - Si la identidad tiene varios CODCLIENTE, prioriza el que ya tenga
     *   un grupo válido para la empresa.
     */
    $gruposSql = implode(',', array_map('intval', $gruposValidos));

    $sqlCliente = "
        WITH grp_valid AS (
            SELECT
                TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                MAX(IDGRUPO) AS IDGRUPO
            FROM CONDICIONESGRUPOSCLIENTES
            WHERE CAMPO = 'CODCLIENTE'
              AND IDGRUPO IN ($gruposSql)
              AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
            GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
        )
        SELECT TOP 1
            c.CODCLIENTE,
            LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE, ''))) AS NOMBRECLIENTE,
            LTRIM(RTRIM(ISNULL(c.NIF20, ''))) AS NIF20,
            ISNULL(gv.IDGRUPO, 0) AS IDGRUPO_VALIDO
        FROM CLIENTES c
        LEFT JOIN grp_valid gv
            ON gv.CODCLIENTE = c.CODCLIENTE
        WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                LTRIM(RTRIM(ISNULL(c.NIF20,''))),
                '-',''),' ',''),'.',''),'/',''), CHAR(9), '') = ?
          AND ISNULL(c.BLOQUEADO, 'F') <> 'T'
        ORDER BY
            -- BLOQUEADO='T' está excluido completamente por el WHERE.
            CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
            -- Después, dentro del mismo estado, priorizar descuento válido.
            CASE
                WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0
                ELSE 1
            END,
            c.CODCLIENTE DESC
    ";

    $stCliente = $pdo->prepare($sqlCliente);
    $stCliente->execute([$identidad]);
    $cliente = $stCliente->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$cliente) {
        out(false, "Cliente no existe en ICG", null, $DEBUG ? [
            "empresa" => $empresa,
            "empresa_recibida" => $empresaRaw,
            "identidad_recibida" => $identidadRaw,
            "identidad_limpia" => $identidad,
        ] : []);
    }

    $codcliente = (string)(int)trim((string)($cliente['CODCLIENTE'] ?? '0'));
    $nombreCliente = trim((string)($cliente['NOMBRECLIENTE'] ?? ''));
    $nif20ICG = trim((string)($cliente['NIF20'] ?? ''));

    $stCheck = $pdo->prepare("
        SELECT TOP 1 IDGRUPO
        FROM CONDICIONESGRUPOSCLIENTES
        WHERE CAMPO = 'CODCLIENTE'
          AND LTRIM(RTRIM(VALOR)) = ?
          AND IDGRUPO IN ($gruposSql)
        ORDER BY IDGRUPO DESC
    ");

    $stCheck->execute([$codcliente]);

    $idgrupoAnterior = $stCheck->fetchColumn();
    $yaTenia = $idgrupoAnterior !== false && $idgrupoAnterior !== null;
    $idgrupoAnterior = $yaTenia ? (int)$idgrupoAnterior : 0;

    if ($yaTenia && $idgrupoAnterior === $idgrupo) {
        $pctTexto = porcentaje_por_empresa($empresa, $idgrupoAnterior, $CFG_DESCUENTOS);

        out(false, "Ya existe", [
            "empresa" => $empresa,
            "cliente" => $nombreCliente,
            "codcliente" => $codcliente,
            "nif20_icg" => $nif20ICG,
            "idgrupo" => $idgrupoAnterior,
            "tipo_descuento" => $pctTexto,
            "estado" => "YA_EXISTE"
        ], $DEBUG ? [
            "empresa" => $empresa,
            "identidad_limpia" => $identidad,
            "idgrupo_actual" => $idgrupoAnterior,
            "idgrupo_enviado" => $idgrupo,
            "mensaje" => "El colaborador ya tenía este mismo descuento.",
        ] : []);
    }

    if ($idgrupo === 0) {
        $accionAud = "DESCUENTO_ELIMINADO";
    } else {
        $accionAud = $yaTenia ? "DESCUENTO_CAMBIADO" : "DESCUENTO_ASIGNADO";
    }

    $pdo->beginTransaction();

    $stDel = $pdo->prepare("
        DELETE FROM CONDICIONESGRUPOSCLIENTES
        WHERE CAMPO = 'CODCLIENTE'
          AND LTRIM(RTRIM(VALOR)) = ?
          AND IDGRUPO IN ($gruposSql)
    ");
    $stDel->execute([$codcliente]);

    if ($idgrupo === 0) {
        $pdo->commit();
        $_SESSION['empresa'] = $empresa;

        try {
            require_once __DIR__ . "/../usuarios/conexion.php";

            if (isset($conn) && $conn instanceof mysqli) {
                $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
                $ip = $_SERVER['REMOTE_ADDR'] ?? '';
                if ($ip === '::1') {
                    $ip = 'LOCALHOST';
                }

                $detalle = "ICG={$empresa} | CODCLIENTE={$codcliente} | IDGRUPO=0 | identidad={$identidad}";
                $stmt = $conn->prepare("
                    INSERT INTO auditoria (accion, detalle, usuario_id, ip)
                    VALUES (?,?,?,?)
                ");

                if ($stmt) {
                    $stmt->bind_param("ssis", $accionAud, $detalle, $usuarioId, $ip);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        } catch (Throwable $e) {
            // La auditoría local no rompe el flujo principal.
        }

        $msg = $yaTenia
            ? "Descuento eliminado correctamente"
            : "El cliente ya estaba sin descuento";

        out(true, $msg, [
            "empresa" => $empresa,
            "codcliente" => $codcliente,
            "nombrecliente" => $nombreCliente,
            "nif20_icg" => $nif20ICG,
            "idgrupo" => 0,
            "tipo_descuento" => "",
        ], $DEBUG ? [
            "empresa" => $empresa,
            "grupos_validos" => $gruposValidos,
            "identidad_recibida" => $identidadRaw,
            "identidad_limpia" => $identidad,
            "codcliente" => $codcliente,
            "idgrupo_anterior" => $idgrupoAnterior,
            "idgrupo_nuevo" => 0,
            "accion_auditoria" => $accionAud,
        ] : []);
    }

    $stNext = $pdo->prepare("
        SELECT ISNULL(MAX(GRUPOOR), 0) + 1
        FROM CONDICIONESGRUPOSCLIENTES WITH (UPDLOCK, HOLDLOCK)
        WHERE IDGRUPO = ?
    ");
    $stNext->execute([$idgrupo]);

    $grupoOr = (int)($stNext->fetchColumn() ?? 1);
    if ($grupoOr < 1) {
        $grupoOr = 1;
    }

    $stIns = $pdo->prepare("
        INSERT INTO CONDICIONESGRUPOSCLIENTES
            (IDGRUPO, GRUPOOR, GRUPOAND, INCLUIR, TABLA, CAMPO, OPERADOR, VALOR)
        VALUES
            (?, ?, 0, 'T', 0, 'CODCLIENTE', '=', ?)
    ");
    $stIns->execute([$idgrupo, $grupoOr, $codcliente]);

    $pdo->commit();
    $_SESSION['empresa'] = $empresa;

    try {
        require_once __DIR__ . "/../usuarios/conexion.php";

        if (isset($conn) && $conn instanceof mysqli) {
            $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
            if ($ip === '::1') {
                $ip = 'LOCALHOST';
            }

            $detalle = "ICG={$empresa} | CODCLIENTE={$codcliente} | IDGRUPO={$idgrupo} | GRUPOOR={$grupoOr} | identidad={$identidad}";
            $stmt = $conn->prepare("
                INSERT INTO auditoria (accion, detalle, usuario_id, ip)
                VALUES (?,?,?,?)
            ");

            if ($stmt) {
                $stmt->bind_param("ssis", $accionAud, $detalle, $usuarioId, $ip);
                $stmt->execute();
                $stmt->close();
            }
        }
    } catch (Throwable $e) {
        // La auditoría local no rompe el flujo principal.
    }

    $msgFinal = $yaTenia
        ? "Descuento cambiado correctamente"
        : "Descuento asignado correctamente";

    out(true, $msgFinal, [
        "empresa" => $empresa,
        "codcliente" => $codcliente,
        "nombrecliente" => $nombreCliente,
        "nif20_icg" => $nif20ICG,
        "idgrupo" => $idgrupo,
        "tipo_descuento" => porcentaje_por_empresa($empresa, $idgrupo, $CFG_DESCUENTOS),
        "grupoOr" => $grupoOr,
    ], $DEBUG ? [
        "empresa" => $empresa,
        "empresa_recibida" => $empresaRaw,
        "grupos_validos" => $gruposValidos,
        "identidad_recibida" => $identidadRaw,
        "identidad_limpia" => $identidad,
        "codcliente" => $codcliente,
        "idgrupo_anterior" => $idgrupoAnterior,
        "idgrupo_nuevo" => $idgrupo,
        "grupoOr" => $grupoOr,
        "accion_auditoria" => $accionAud,
    ] : []);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    out(false, "Error al guardar descuento", null, $DEBUG ? [
        "error" => $e->getMessage(),
        "file" => $e->getFile(),
        "line" => $e->getLine(),
    ] : []);
}