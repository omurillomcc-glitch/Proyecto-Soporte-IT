<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: colaboradores/db_evolution.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Cargar la configuración de Evolution desde config.php
| - Validar que la configuración exista
| - Crear una conexión PDO a SQL Server
| - Consultar empleados
| - Devolver la identidad en 2 versiones:
|     1) identidad      => con guiones (visual)
|     2) identidad_num  => sin guiones (para cruce y búsquedas)
|--------------------------------------------------------------------------
*/

$configPath = __DIR__ . "/config.php";

if (!file_exists($configPath)) {
    throw new RuntimeException("Error: config.php no existe en colaboradores/");
}

$cfg = require $configPath;
$e = $cfg['evolution'] ?? null;

if (!is_array($e) || empty($e['server']) || empty($e['db'])) {
    throw new RuntimeException("Error: Configuración de Evolution incompleta en config.php");
}

if (!extension_loaded('pdo_sqlsrv')) {
    throw new RuntimeException("La extensión pdo_sqlsrv no está habilitada.");
}

$pdoEvo = new PDO(
    "sqlsrv:Server={$e['server']};Database={$e['db']};TrustServerCertificate=1",
    $e['user'] ?? '',
    $e['pass'] ?? '',
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
);

function evo_norm(string $s): string
{
    return trim($s);
}

function evo_norm_id(string $s): string
{
    $s = trim($s);
    $s = preg_replace('/\D+/', '', $s);
    return $s ?: '';
}

function evolution_total(string $q = ''): int
{
    global $pdoEvo;

    $where = "WHERE LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) <> ''";
    $params = [];

    $q = trim($q);

    if ($q !== '') {
        $qNum = preg_replace('/\D+/', '', $q);

        $where .= " AND (
            LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) LIKE ?
            OR REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))),'-',''),' ',''),'.',''),'/','') LIKE ?
            OR CONCAT(
                ISNULL(exp_primer_nom,''), ' ',
                ISNULL(exp_segundo_nom,''), ' ',
                ISNULL(exp_primer_ape,''), ' ',
                ISNULL(exp_segundo_ape,''), ' ',
                ISNULL(exp_apellido_cas,'')
            ) LIKE ?
        )";

        $params[] = "%{$q}%";
        $params[] = "%{$qNum}%";
        $params[] = "%{$q}%";
    }

    $sql = "SELECT COUNT(*) AS total FROM exp.exp_expedientes $where";

    $st = $pdoEvo->prepare($sql);
    $st->execute($params);

    return (int)($st->fetchColumn() ?? 0);
}

function obtener_empleados_evolution_paginado(int $page = 1, int $perPage = 100, string $q = ''): array
{
    global $pdoEvo;

    if ($page < 1) {
        $page = 1;
    }

    if ($perPage < 1) {
        $perPage = 100;
    }

    if ($perPage > 2000) {
        $perPage = 2000;
    }

    $offset = ($page - 1) * $perPage;

    $where = "WHERE LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) <> ''";
    $params = [];

    $q = trim($q);

    if ($q !== '') {
        $qNum = preg_replace('/\D+/', '', $q);

        $where .= " AND (
            LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) LIKE ?
            OR REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))),'-',''),' ',''),'.',''),'/','') LIKE ?
            OR CONCAT(
                ISNULL(exp_primer_nom,''), ' ',
                ISNULL(exp_segundo_nom,''), ' ',
                ISNULL(exp_primer_ape,''), ' ',
                ISNULL(exp_segundo_ape,''), ' ',
                ISNULL(exp_apellido_cas,'')
            ) LIKE ?
        )";

        $params[] = "%{$q}%";
        $params[] = "%{$qNum}%";
        $params[] = "%{$q}%";
    }

    $sql = "
        SELECT
            LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) AS identidad,
            REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))),'-',''),' ',''),'.',''),'/','') AS identidad_num,
            LTRIM(RTRIM(
                CONCAT(
                    ISNULL(exp_primer_nom,''), ' ',
                    ISNULL(exp_segundo_nom,''), ' ',
                    ISNULL(exp_primer_ape,''), ' ',
                    ISNULL(exp_segundo_ape,''), ' ',
                    ISNULL(exp_apellido_cas,'')
                )
            )) AS nombre
        FROM exp.exp_expedientes
        $where
        ORDER BY exp_codigo DESC
        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
    ";

    $st = $pdoEvo->prepare($sql);

    $pos = 1;
    foreach ($params as $p) {
        $st->bindValue($pos++, $p, PDO::PARAM_STR);
    }

    $st->bindValue($pos++, (int)$offset, PDO::PARAM_INT);
    $st->bindValue($pos++, (int)$perPage, PDO::PARAM_INT);

    $st->execute();
    $rows = $st->fetchAll() ?: [];

    foreach ($rows as &$r) {
        $r['identidad']     = evo_norm((string)($r['identidad'] ?? ''));
        $r['identidad_num'] = evo_norm_id((string)($r['identidad_num'] ?? ''));
        $r['nombre']        = evo_norm((string)($r['nombre'] ?? ''));
    }
    unset($r);

    return $rows;
}

function obtener_empleados_evolution(int $limit = 0): array
{
    global $pdoEvo;

    $top = '';

    if ($limit > 0) {
        $top = "TOP (" . (int)$limit . ")";
    }

    $sql = "
        SELECT $top
            LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) AS identidad,
            REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))),'-',''),' ',''),'.',''),'/','') AS identidad_num,
            LTRIM(RTRIM(
                CONCAT(
                    ISNULL(exp_primer_nom,''), ' ',
                    ISNULL(exp_segundo_nom,''), ' ',
                    ISNULL(exp_primer_ape,''), ' ',
                    ISNULL(exp_segundo_ape,''), ' ',
                    ISNULL(exp_apellido_cas,'')
                )
            )) AS nombre
        FROM exp.exp_expedientes
        WHERE LTRIM(RTRIM(ISNULL(exp_codigo_alternativo,''))) <> ''
        ORDER BY exp_codigo DESC
    ";

    $st = $pdoEvo->query($sql);
    $rows = $st->fetchAll() ?: [];

    foreach ($rows as &$r) {
        $r['identidad']     = evo_norm((string)($r['identidad'] ?? ''));
        $r['identidad_num'] = evo_norm_id((string)($r['identidad_num'] ?? ''));
        $r['nombre']        = evo_norm((string)($r['nombre'] ?? ''));
    }
    unset($r);

    return $rows;
}