<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: descuento.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Consultar si un cliente tiene descuento en ICG.
| - Recibe empresa e identidad por GET.
| - Devuelve JSON.
|--------------------------------------------------------------------------
*/

header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| SESIÓN PARA AJAX
|--------------------------------------------------------------------------
*/
session_name('APP_DESCUENTO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        "ok" => false,
        "msg" => "Sesión expirada. Inicie sesión nuevamente.",
        "tiene_descuento" => false,
        "data" => null
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/*
|--------------------------------------------------------------------------
| CONEXIÓN ICG
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/db_icg.php';

/*
|--------------------------------------------------------------------------
| FUNCIÓN DE ERROR
|--------------------------------------------------------------------------
*/
function fail(string $msg, array $extra = []): never
{
    echo json_encode(
        ["ok" => false, "msg" => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| LEER PARÁMETROS
|--------------------------------------------------------------------------
*/
$empresa   = strtolower(trim($_GET['empresa'] ?? 'mendels'));
$identidad = trim($_GET['identidad'] ?? '');

$empresasPermitidas = ['mendels', 'acajoe', 'detodo', 'chesters'];

if (!in_array($empresa, $empresasPermitidas, true)) {
    fail("Empresa inválida.");
}

if ($identidad === '') {
    fail("Falta identidad.");
}

/*
|--------------------------------------------------------------------------
| LIMPIAR IDENTIDAD
|--------------------------------------------------------------------------
*/
$identidadLimpia = preg_replace('/\D+/', '', $identidad);

if ($identidadLimpia === '') {
    fail("Identidad inválida.");
}

try {

    /*
    |--------------------------------------------------------------------------
    | CONECTAR CON PDO
    |--------------------------------------------------------------------------
    */
    $pdo = icg_pdo($empresa);

    /*
    |--------------------------------------------------------------------------
    | CONSULTA SQL
    |--------------------------------------------------------------------------
    | IMPORTANTE:
    | En tus otras consultas usas NIF20, no CIF.
    | Por eso aquí también uso NIF20.
    |--------------------------------------------------------------------------
    */
    $sql = "
        SELECT TOP 1
            c.CODCLIENTE,
            c.NOMBRECLIENTE,
            c.NIF20,
            x.IDGRUPO,
            g.DESCRIPCION AS tipo_descuento
        FROM CLIENTES c
        INNER JOIN (
            SELECT
                TRY_CAST(d.VALOR AS INT) AS CODCLIENTE,
                d.IDGRUPO
            FROM CONDICIONESGRUPOSCLIENTES d
            WHERE d.CAMPO = 'CODCLIENTE'
        ) x
            ON x.CODCLIENTE = c.CODCLIENTE
        INNER JOIN GRUPOSCLIENTES g
            ON g.IDGRUPO = x.IDGRUPO
        WHERE
            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20,''))), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '') = ?
        ORDER BY x.IDGRUPO DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$identidadLimpia]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    echo json_encode([
        "ok" => true,
        "empresa" => $empresa,
        "tiene_descuento" => $row ? true : false,
        "data" => $row
    ], JSON_UNESCAPED_UNICODE);

    exit;

} catch (Throwable $e) {

    echo json_encode([
        "ok" => false,
        "msg" => "Error consultando descuento.",
        "error" => $e->getMessage(),
        "tiene_descuento" => false,
        "data" => null
    ], JSON_UNESCAPED_UNICODE);

    exit;
}