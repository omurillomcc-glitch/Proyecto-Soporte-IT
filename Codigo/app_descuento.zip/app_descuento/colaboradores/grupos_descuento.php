<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PASO 1: RESPUESTA JSON
|--------------------------------------------------------------------------
*/
header('Content-Type: application/json; charset=utf-8');


session_name('APP_DESCUENTO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        "ok"    => false,
        "msg"   => "Sesión expirada. Inicie sesión nuevamente.",
        "data"  => null,
        "extra" => []
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 4: CONFIGURACIÓN GENERAL
|--------------------------------------------------------------------------
*/
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
set_time_limit(240);

ob_start();

/*
|--------------------------------------------------------------------------
| PASO 5: CARGAR CONEXIÓN ICG
|--------------------------------------------------------------------------
*/
require_once __DIR__ . "/db_icg.php";

/*
|--------------------------------------------------------------------------
| ERROR JSON
|--------------------------------------------------------------------------
*/
function jfail(string $msg, array $extra = []): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    http_response_code(500);

    echo json_encode(
        [
            "ok"    => false,
            "msg"   => $msg,
            "data"  => null,
            "extra" => $extra
        ],
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| LIMPIAR TEXTO
|--------------------------------------------------------------------------
*/
function norm($s): string
{
    return trim((string)($s ?? ''));
}

/*
|--------------------------------------------------------------------------
| LIMPIAR IDENTIDAD
|--------------------------------------------------------------------------
*/
function norm_id($s): string
{
    return preg_replace('/\D+/', '', norm($s));
}


function norm_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));

    $map = [
        'mendels'  => 'mendels',
        'acajoe'   => 'acajoe',
        'detodo'   => 'detodo',
        'de todo'  => 'detodo',
        'de-todo'  => 'detodo',
        'chesters' => 'chesters',
    ];

    return $map[$empresa] ?? $empresa;
}

/*
|--------------------------------------------------------------------------
| CONFIGURACIÓN DE DESCUENTOS POR EMPRESA
|--------------------------------------------------------------------------
*/
function descuentos_empresa_config(): array
{
    return [
        'mendels' => [
            'grupos_validos' => [12, 13, 14],
            'opciones' => [
                ["idgrupo" => 0,  "label" => "Sin descuento"],
                ["idgrupo" => 12, "label" => "10%"],
                ["idgrupo" => 13, "label" => "20%"],
                ["idgrupo" => 14, "label" => "50%"],
            ],
        ],

        'acajoe' => [
            'grupos_validos' => [15, 16, 17, 18],
            'opciones' => [
                ["idgrupo" => 0,  "label" => "Sin descuento"],
                ["idgrupo" => 15, "label" => "10%"],
                ["idgrupo" => 16, "label" => "20%"],
                ["idgrupo" => 17, "label" => "40%"],
                ["idgrupo" => 18, "label" => "50%"],
            ],
        ],

        'detodo' => [
            'grupos_validos' => [12, 13, 14],
            'opciones' => [
                ["idgrupo" => 0,  "label" => "Sin descuento"],
                ["idgrupo" => 12, "label" => "10%"],
                ["idgrupo" => 13, "label" => "20%"],
                ["idgrupo" => 14, "label" => "50%"],
            ],
        ],

        'chesters' => [
            'grupos_validos' => [12, 13, 14],
            'opciones' => [
                ["idgrupo" => 0,  "label" => "Sin descuento"],
                ["idgrupo" => 12, "label" => "10%"],
                ["idgrupo" => 13, "label" => "20%"],
                ["idgrupo" => 14, "label" => "50%"],
            ],
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| OBTENER GRUPOS VÁLIDOS
|--------------------------------------------------------------------------
*/
function grupos_validos_por_empresa(string $empresa, array $cfg): array
{
    return $cfg[$empresa]['grupos_validos'] ?? [];
}

/*
|--------------------------------------------------------------------------
| OBTENER OPCIONES DEL SELECT
|--------------------------------------------------------------------------
*/
function opciones_por_empresa(string $empresa, array $cfg): array
{
    return $cfg[$empresa]['opciones'] ?? [
        ["idgrupo" => 0,  "label" => "Sin descuento"],
    ];
}

try {
    /*
    |--------------------------------------------------------------------------
    | DEBUG
    |--------------------------------------------------------------------------
    */
    $DEBUG = ((string)($_GET['debug'] ?? '0') === '1');

    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */
    $CFG_DESCUENTOS = descuentos_empresa_config();
    $empresasPermitidas = array_keys($CFG_DESCUENTOS);

    /*
    |--------------------------------------------------------------------------
    | EMPRESA
    |--------------------------------------------------------------------------
    */
    $empresa = norm_empresa((string)($_GET['empresa'] ?? 'mendels'));

    if ($empresa === '') {
        $empresa = 'mendels';
    }

    if (!in_array($empresa, $empresasPermitidas, true)) {
        jfail("Empresa no válida", [
            "empresa_recibida" => $empresa,
            "empresas_validas" => $empresasPermitidas
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | IDENTIDAD
    |--------------------------------------------------------------------------
    */
    $identidadRaw = norm($_GET['identidad'] ?? ($_GET['identidad_num'] ?? ''));
    $identidadNum = norm_id($identidadRaw);

    if ($identidadNum === '') {
        jfail("Falta identidad (envía identidad o identidad_num)");
    }

    /*
    |--------------------------------------------------------------------------
    | GRUPOS Y OPCIONES SEGÚN EMPRESA
    |--------------------------------------------------------------------------
    */
    $gruposValidos = grupos_validos_por_empresa($empresa, $CFG_DESCUENTOS);
    $opciones = opciones_por_empresa($empresa, $CFG_DESCUENTOS);

    if (!$gruposValidos) {
        jfail("No hay grupos configurados para esta empresa", [
            "empresa" => $empresa
        ]);
    }

    $gruposSql = implode(',', array_map('intval', $gruposValidos));

    /*
    |--------------------------------------------------------------------------
    | CONEXIÓN A ICG
    |--------------------------------------------------------------------------
    */
    $pdo = icg_pdo($empresa);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

       $sqlCliente = "
        WITH grp_valid AS (
            SELECT
                TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                MAX(IDGRUPO) AS IDGRUPO
            FROM CONDICIONESGRUPOSCLIENTES
            WHERE CAMPO = 'CODCLIENTE'
              AND IDGRUPO IN ($gruposSql)
              AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
            GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
        )
        SELECT TOP 1
            c.CODCLIENTE,
            LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE, ''))) AS NOMBRECLIENTE,
            LTRIM(RTRIM(ISNULL(c.NIF20, ''))) AS NIF20,
            ISNULL(gv.IDGRUPO, 0) AS IDGRUPO_VALIDO
        FROM CLIENTES c
        LEFT JOIN grp_valid gv
            ON gv.CODCLIENTE = c.CODCLIENTE
        WHERE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20,''))),'-',''),' ',''),'.',''),'/',''), CHAR(9), '') = ?
          AND ISNULL(c.BLOQUEADO, 'F') <> 'T'
        ORDER BY
            -- BLOQUEADO='T' está excluido completamente por el WHERE.
            CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
            -- 2) Entre fichas del mismo estado, priorizar la que tenga
            --    un grupo válido de la empresa actual.
            CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
            c.CODCLIENTE DESC
    ";


    $st = $pdo->prepare($sqlCliente);
    $st->execute([$identidadNum]);
    $cliente = $st->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$cliente) {
        jfail("No existe cliente en ICG con esa identidad", [
            "empresa"       => $empresa,
            "identidad"     => $identidadRaw,
            "identidad_num" => $identidadNum
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | DATOS DEL CLIENTE ELEGIDO
    |--------------------------------------------------------------------------
    */
    $codcliente = (string)(int)trim((string)($cliente['CODCLIENTE'] ?? '0'));
    $nombreCliente = trim((string)($cliente['NOMBRECLIENTE'] ?? ''));
    $nif20 = trim((string)($cliente['NIF20'] ?? ''));
    $idgrupoClienteValido = (int)($cliente['IDGRUPO_VALIDO'] ?? 0);

    /*
    |--------------------------------------------------------------------------
    | 2) VERIFICAR SI EXISTE COLUMNA ID
    |--------------------------------------------------------------------------
    | Esto sirve para ordenar el último registro si la tabla tiene ID.
    |--------------------------------------------------------------------------
    */
    $hasId = false;

    try {
        $chk = $pdo->query("
            SELECT 1
            FROM sys.columns
            WHERE object_id = OBJECT_ID('dbo.CONDICIONESGRUPOSCLIENTES')
              AND name = 'ID'
        ");
        $hasId = (bool)$chk->fetchColumn();
    } catch (Throwable $e) {
        $hasId = false;
    }

    /*
    |--------------------------------------------------------------------------
    | 3) CONSULTAR DESCUENTO ACTUAL DEL CLIENTE
    |--------------------------------------------------------------------------
    | CORRECCIÓN:
    | - Solo se consulta el descuento dentro de los grupos válidos
    |   de la empresa actual.
    |
    | Ejemplos:
    | - Mendels solo mira 12,13,14
    | - Acajoe solo mira 15,16,17,18
    |--------------------------------------------------------------------------
    */
    $orderBy = $hasId ? "ID DESC" : "IDGRUPO DESC";

    $sqlUlt = "
        SELECT TOP 1
            IDGRUPO,
            GRUPOOR,
            GRUPOAND
        FROM CONDICIONESGRUPOSCLIENTES
        WHERE CAMPO = 'CODCLIENTE'
          AND LTRIM(RTRIM(VALOR)) = ?
          AND IDGRUPO IN ($gruposSql)
        ORDER BY $orderBy
    ";

    $stUlt = $pdo->prepare($sqlUlt);
    $stUlt->execute([$codcliente]);
    $ult = $stUlt->fetch(PDO::FETCH_ASSOC) ?: null;

  
    $idgrupoOriginal  = $ult ? (int)($ult['IDGRUPO'] ?? 0) : $idgrupoClienteValido;
    $grupoOrActual    = $ult ? (int)($ult['GRUPOOR'] ?? 0) : 0;
    $grupoAndActual   = $ult ? (int)($ult['GRUPOAND'] ?? 0) : 0;

    /*
    |--------------------------------------------------------------------------
    | 4) NORMALIZAR SEGÚN EMPRESA
    |--------------------------------------------------------------------------
    */
    $grupoValidoEmpresa = in_array($idgrupoOriginal, $gruposValidos, true);
    $idgrupoActual = $grupoValidoEmpresa ? $idgrupoOriginal : 0;

    /*
    |--------------------------------------------------------------------------
    | RESPUESTA EXITOSA
    |--------------------------------------------------------------------------
    */
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    $response = [
        "ok"  => true,
        "msg" => "ok",
        "data" => [
            "empresa"              => $empresa,
            "identidad"            => $identidadRaw,
            "identidad_num"        => $identidadNum,
            "codcliente"           => $codcliente,
            "nombrecliente"        => $nombreCliente,
            "nif20_icg"            => $nif20,
            "idgrupo_actual"       => $idgrupoActual,
            "grupo_or_actual"      => $grupoOrActual,
            "grupo_and_actual"     => $grupoAndActual,
            "opciones"             => $opciones,
        ],
        "extra" => []
    ];

    /*
    |--------------------------------------------------------------------------
    | DEBUG
    |--------------------------------------------------------------------------
    */
    if ($DEBUG) {
        $response["extra"] = [
            "empresa_consultada"      => $empresa,
            "grupos_validos_empresa"  => $gruposValidos,
            "grupos_sql"              => $gruposSql,
            "codcliente_elegido"      => $codcliente,
            "idgrupo_cliente_valido"  => $idgrupoClienteValido,
            "idgrupo_original"        => $idgrupoOriginal,
            "idgrupo_actual"          => $idgrupoActual,
            "grupo_valido_empresa"    => $grupoValidoEmpresa,
            "order_by"                => $orderBy,
            "has_id_column"           => $hasId,
            "cliente_encontrado"      => (bool)$cliente,
        ];
    }

    echo json_encode(
        $response,
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;

} catch (Throwable $e) {
    jfail("Error grupos_descuento.php", [
        "error" => $e->getMessage(),
        "file"  => $e->getFile(),
        "line"  => $e->getLine()
    ]);
}