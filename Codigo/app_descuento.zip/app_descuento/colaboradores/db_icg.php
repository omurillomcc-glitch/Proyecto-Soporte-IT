<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: colaboradores/db_icg.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Cargar la configuración desde config.php
| - Validar que exista la configuración de ICG
| - Crear una conexión PDO hacia SQL Server
| - Elegir la base correcta según la empresa recibida
|
| IMPORTANTE:
| - En este proyecto, Acajoe y Mendels comparten la misma base física
| - Por eso, para CONEXIÓN, "acajoe" se resuelve como "mendels"
| - PERO eso NO significa que usen los mismos grupos de descuento
| - La lógica de descuentos se controla en otros archivos
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: UBICAR EL ARCHIVO config.php
|--------------------------------------------------------------------------
| Se espera que config.php esté dentro de la misma carpeta.
|--------------------------------------------------------------------------
*/
$configPath = __DIR__ . "/config.php";

/*
|--------------------------------------------------------------------------
| PASO 2: VALIDAR QUE EXISTA config.php
|--------------------------------------------------------------------------
*/
if (!file_exists($configPath)) {
    http_response_code(500);
    die("Error: config.php no existe en colaboradores/");
}

/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR CONFIGURACIÓN
|--------------------------------------------------------------------------
| Se espera que retorne un arreglo.
|--------------------------------------------------------------------------
*/
$cfg = require $configPath;

/*
|--------------------------------------------------------------------------
| PASO 4: VALIDAR ESTRUCTURA BÁSICA DE CONFIG
|--------------------------------------------------------------------------
| Debe existir al menos:
| - $cfg['icg']
|--------------------------------------------------------------------------
*/
if (!is_array($cfg) || !isset($cfg['icg']) || !is_array($cfg['icg'])) {
    http_response_code(500);
    die("Error: config.php inválido (falta bloque icg).");
}

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIÓN PARA NORMALIZAR NOMBRE DE EMPRESA
|--------------------------------------------------------------------------
| Convierte:
| - minúsculas
| - trim
| - elimina espacios, guiones y underscores
|
| Ejemplos:
| - " De-Todo " => "detodo"
| - "de_todo"   => "detodo"
|--------------------------------------------------------------------------
*/
function icg_normalizar_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));
    $empresa = preg_replace('/[\s\-_]+/', '', $empresa);
    return $empresa ?? '';
}

/*
|--------------------------------------------------------------------------
| PASO 6: FUNCIÓN PARA RESOLVER ALIAS DE CONEXIÓN
|--------------------------------------------------------------------------
| IMPORTANTE:
| - Aquí solo resolvemos alias para elegir la BASE
| - Acajoe usa la misma base física que Mendels
|--------------------------------------------------------------------------
*/
function icg_resolver_alias_conexion(string $empresa): string
{
    if ($empresa === 'acajoe') {
        return 'mendels';
    }

    return $empresa;
}

/*
|--------------------------------------------------------------------------
| PASO 7: FUNCIÓN PRINCIPAL icg_pdo()
|--------------------------------------------------------------------------
| Recibe una empresa y devuelve una conexión PDO a SQL Server.
|--------------------------------------------------------------------------
*/
function icg_pdo(string $empresa): PDO
{
    /*
    |--------------------------------------------------------------------------
    | PASO 7.1: CARGAR CONFIG YA VALIDADA
    |--------------------------------------------------------------------------
    */
    static $cfg = null;

    if ($cfg === null) {
        $configPath = __DIR__ . "/config.php";

        if (!file_exists($configPath)) {
            throw new Exception("config.php no existe en colaboradores/");
        }

        $cfg = require $configPath;

        if (!is_array($cfg) || !isset($cfg['icg']) || !is_array($cfg['icg'])) {
            throw new Exception("config.php inválido (falta bloque icg).");
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7.2: GUARDAR EMPRESA ORIGINAL
    |--------------------------------------------------------------------------
    | Esto sirve para mensajes de error claros.
    |--------------------------------------------------------------------------
    */
    $empresaOriginal = $empresa;

    /*
    |--------------------------------------------------------------------------
    | PASO 7.3: NORMALIZAR EMPRESA
    |--------------------------------------------------------------------------
    */
    $empresaNormalizada = icg_normalizar_empresa($empresaOriginal);

    if ($empresaNormalizada === '') {
        throw new Exception("Empresa vacía o inválida.");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7.4: RESOLVER ALIAS DE CONEXIÓN
    |--------------------------------------------------------------------------
    | Ejemplo:
    | - acajoe -> mendels
    |--------------------------------------------------------------------------
    */
    $empresaConexion = icg_resolver_alias_conexion($empresaNormalizada);

    /*
    |--------------------------------------------------------------------------
    | PASO 7.5: LEER MAPA DE BASES
    |--------------------------------------------------------------------------
    | Ejemplo esperado:
    | [
    |   'mendels'  => 'MENDELS',
    |   'detodo'   => 'DETODO',
    |   'chesters' => 'CHESTERS'
    | ]
    |--------------------------------------------------------------------------
    */
    $map = $cfg['icg']['db_map'] ?? [];

    if (!is_array($map) || empty($map)) {
        throw new Exception("Config ICG incompleta: falta db_map.");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7.6: VALIDAR EMPRESA EN EL MAPA
    |--------------------------------------------------------------------------
    */
    if (!isset($map[$empresaConexion])) {
        $validas = implode(', ', array_keys($map));

        throw new Exception(
            "Empresa inválida para conexión ICG. " .
            "Original='{$empresaOriginal}', " .
            "normalizada='{$empresaNormalizada}', " .
            "conexion='{$empresaConexion}'. " .
            "Válidas: {$validas}"
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7.7: OBTENER NOMBRE DE BASE DE DATOS
    |--------------------------------------------------------------------------
    */
    $db = (string)($map[$empresaConexion] ?? '');

    /*
    |--------------------------------------------------------------------------
    | PASO 7.8: LEER DATOS DE CONEXIÓN
    |--------------------------------------------------------------------------
    */
    $server = (string)($cfg['icg']['server'] ?? '');
    $user   = (string)($cfg['icg']['user'] ?? '');
    $pass   = (string)($cfg['icg']['pass'] ?? '');

    /*
    |--------------------------------------------------------------------------
    | PASO 7.9: VALIDAR DATOS MÍNIMOS
    |--------------------------------------------------------------------------
    */
    if ($server === '' || $db === '' || $user === '') {
        throw new Exception(
            "Config ICG incompleta (server/db/user). " .
            "server='{$server}', db='{$db}', user='" . ($user !== '' ? '[OK]' : '') . "'"
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7.10: CONSTRUIR DSN PARA SQL SERVER
    |--------------------------------------------------------------------------
    */
    $dsn = "sqlsrv:Server={$server};Database={$db};TrustServerCertificate=1";

    /*
    |--------------------------------------------------------------------------
    | PASO 7.11: CREAR Y RETORNAR CONEXIÓN PDO
    |--------------------------------------------------------------------------
    */
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}