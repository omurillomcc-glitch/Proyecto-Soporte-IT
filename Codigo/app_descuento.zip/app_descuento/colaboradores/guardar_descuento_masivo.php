<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_DESCUENTO');
    session_start();
}

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        'ok'   => false,
        'msg'  => 'Sesión expirada. Inicie sesión nuevamente.',
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
    exit;
}


ob_start();


ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(0);
set_time_limit(300);

/*
|--------------------------------------------------------------------------
| PASO 6: CARGAR CONEXIÓN ICG
|--------------------------------------------------------------------------
*/
require_once __DIR__. "/db_icg.php";


function out(bool $ok, string $msg, $data = null): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    echo json_encode([
        "ok"   => $ok,
        "msg"  => $msg,
        "data" => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 8: NORMALIZAR IDENTIDAD
|--------------------------------------------------------------------------
| Convierte la identidad a solo números.
|--------------------------------------------------------------------------
*/
function norm_id(string $s): string
{
    return preg_replace('/\D+/', '', trim($s)) ?: '';
}

/*
|--------------------------------------------------------------------------
| PASO 9: NORMALIZAR EMPRESA
|--------------------------------------------------------------------------
*/
function norm_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));

    $map = [
        'mendels'  => 'mendels',
        'acajoe'   => 'acajoe',
        'detodo'   => 'detodo',
        'de todo'  => 'detodo',
        'de-todo'  => 'detodo',
        'chesters' => 'chesters',
    ];

    return $map[$empresa] ?? $empresa;
}

/*
|--------------------------------------------------------------------------
| PASO 10: CONFIGURACIÓN DE DESCUENTOS POR EMPRESA
|--------------------------------------------------------------------------
*/
function config_descuentos(): array
{
    return [
        'mendels' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'acajoe' => [
            'grupos' => [15, 16, 17, 18],
            'labels' => [
                15 => '10%',
                16 => '20%',
                17 => '40%',
                18 => '50%',
            ],
        ],
        'detodo' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'chesters' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
    ];
}

/*
|--------------------------------------------------------------------------
| PASO 11: TEXTO DEL DESCUENTO
|--------------------------------------------------------------------------
*/
function label_descuento(string $empresa, int $idgrupo, array $cfg): string
{
    return $cfg[$empresa]['labels'][$idgrupo] ?? '';
}

try {

    /*
    |--------------------------------------------------------------------------
    | PASO 12: CARGAR CONFIGURACIÓN
    |--------------------------------------------------------------------------
    */
    $cfg = config_descuentos();

    /*
    |--------------------------------------------------------------------------
    | PASO 13: RECIBIR EMPRESA
    |--------------------------------------------------------------------------
    */
    $empresaRaw = (string)($_POST['empresa'] ?? '');
    $empresa = norm_empresa($empresaRaw);

    if (!isset($cfg[$empresa])) {
        out(false, "Empresa inválida");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 14: RECIBIR IDGRUPO
    |--------------------------------------------------------------------------
    | idgrupo = 0 significa eliminar descuento.
    |--------------------------------------------------------------------------
    */
    $idgrupo = (int)($_POST['idgrupo'] ?? 0);
    $gruposValidos = $cfg[$empresa]['grupos'];

    if ($idgrupo !== 0 && !in_array($idgrupo, $gruposValidos, true)) {
        out(false, "Grupo de descuento inválido para esta empresa");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 15: RECIBIR IDENTIDADES
    |--------------------------------------------------------------------------
    */
    $identidadesRaw = (string)($_POST['identidades'] ?? '');

    if (trim($identidadesRaw) === '') {
        out(false, "Debes ingresar al menos una identidad");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 16: LIMPIAR LISTA DE IDENTIDADES
    |--------------------------------------------------------------------------
    | Acepta identidades separadas por:
    | - saltos de línea
    | - comas
    | - punto y coma
    |--------------------------------------------------------------------------
    */
    $partes = preg_split('/[\r\n,;]+/', $identidadesRaw);
    $identidades = [];

    foreach ($partes as $p) {
        $id = norm_id((string)$p);

        if ($id !== '') {
            /*
            |--------------------------------------------------------------------------
            | Evita identidades duplicadas en el mismo envío.
            |--------------------------------------------------------------------------
            */
            $identidades[$id] = $id;
        }
    }

    $identidades = array_values($identidades);

    if (!$identidades) {
        out(false, "No se encontraron identidades válidas");
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 17: CONEXIÓN SQL SERVER / ICG
    |--------------------------------------------------------------------------
    */
    $pdo = icg_pdo($empresa);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /*
    |--------------------------------------------------------------------------
    | PASO 18: GRUPOS VÁLIDOS EN SQL
    |--------------------------------------------------------------------------
    */
    $gruposSql = implode(',', array_map('intval', $gruposValidos));

    /*
    |--------------------------------------------------------------------------
    | PASO 19: RESULTADO FINAL
    |--------------------------------------------------------------------------
    */
    $resultado = [
        "empresa"        => $empresa,
        "idgrupo"        => $idgrupo,
        "descuento"      => $idgrupo === 0 ? "" : label_descuento($empresa, $idgrupo, $cfg),
        "procesados"     => 0,
        "aplicados"      => 0,
        "cambiados"      => 0,
        "eliminados"     => 0,
        "ya_existen"     => 0,
        "no_encontrados" => [],
        "errores"        => [],
        "detalle"        => [],
    ];

    /*
    |--------------------------------------------------------------------------
    | PASO 20: INICIAR TRANSACCIÓN
    |--------------------------------------------------------------------------
    */
    $pdo->beginTransaction();

       /*
    |--------------------------------------------------------------------------
    | PASO 21: CONSULTA PARA BUSCAR CLIENTE
    |--------------------------------------------------------------------------
    | Busca el cliente por identidad limpia ignorando fichas inactivas.
    | También trae si ya tiene un descuento válido de esa empresa.
    |--------------------------------------------------------------------------
    */
    $sqlCliente = "
        WITH grp_valid AS (
            SELECT
                TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                MAX(IDGRUPO) AS IDGRUPO
            FROM CONDICIONESGRUPOSCLIENTES
            WHERE CAMPO = 'CODCLIENTE'
              AND IDGRUPO IN ($gruposSql)
              AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
            GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
        )
        SELECT TOP 1
            c.CODCLIENTE,
            LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE,''))) AS NOMBRECLIENTE,
            LTRIM(RTRIM(ISNULL(c.NIF20,''))) AS NIF20,
            ISNULL(gv.IDGRUPO, 0) AS IDGRUPO_VALIDO
        FROM CLIENTES c
        LEFT JOIN grp_valid gv
            ON gv.CODCLIENTE = c.CODCLIENTE
        WHERE REPLACE(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20,''))), '-', ''),
                        ' ', ''),
                    '.', ''),
                '/', ''),
            CHAR(9), '') = ?
          AND ISNULL(c.BLOQUEADO, 'F') <> 'T'
        ORDER BY
            -- BLOQUEADO='T' está excluido completamente por el WHERE.
            CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
            -- Entre fichas del mismo estado, prioriza el grupo válido.
            CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
            c.CODCLIENTE DESC
    ";

    $stCliente = $pdo->prepare($sqlCliente);


    /*
    |--------------------------------------------------------------------------
    | PASO 22: BORRAR DESCUENTOS ANTERIORES DE ESA EMPRESA
    |--------------------------------------------------------------------------
    */
    $stDel = $pdo->prepare("
        DELETE FROM CONDICIONESGRUPOSCLIENTES
        WHERE CAMPO = 'CODCLIENTE'
          AND LTRIM(RTRIM(VALOR)) = ?
          AND IDGRUPO IN ($gruposSql)
    ");

    /*
    |--------------------------------------------------------------------------
    | PASO 23: OBTENER GRUPOOR
    |--------------------------------------------------------------------------
    */
    $stNext = $pdo->prepare("
        SELECT ISNULL(MAX(GRUPOOR), 0) + 1
        FROM CONDICIONESGRUPOSCLIENTES WITH (UPDLOCK, HOLDLOCK)
        WHERE IDGRUPO = ?
    ");

    /*
    |--------------------------------------------------------------------------
    | PASO 24: INSERTAR NUEVO DESCUENTO
    |--------------------------------------------------------------------------
    */
    $stIns = $pdo->prepare("
        INSERT INTO CONDICIONESGRUPOSCLIENTES
            (IDGRUPO, GRUPOOR, GRUPOAND, INCLUIR, TABLA, CAMPO, OPERADOR, VALOR)
        VALUES
            (?, ?, 0, 'T', 0, 'CODCLIENTE', '=', ?)
    ");

    /*
    |--------------------------------------------------------------------------
    | PASO 25: PROCESAR CADA IDENTIDAD
    |--------------------------------------------------------------------------
    */
    foreach ($identidades as $identidadNum) {

        $resultado["procesados"]++;

        /*
        |--------------------------------------------------------------------------
        | PASO 25.1: BUSCAR CLIENTE
        |--------------------------------------------------------------------------
        */
        $stCliente->execute([$identidadNum]);
        $cliente = $stCliente->fetch(PDO::FETCH_ASSOC) ?: null;

        if (!$cliente) {
            $resultado["no_encontrados"][] = $identidadNum;

            $resultado["detalle"][] = [
                "identidad"  => $identidadNum,
                "codcliente" => "",
                "nombre"     => "",
                "accion"     => "NO_ENCONTRADO",
                "mensaje"    => "Cliente no existe en ICG"
            ];

            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 25.2: DATOS DEL CLIENTE
        |--------------------------------------------------------------------------
        */
        $codcliente = (string)(int)trim((string)($cliente['CODCLIENTE'] ?? '0'));
        $nombre     = trim((string)($cliente['NOMBRECLIENTE'] ?? ''));
        $nif20      = trim((string)($cliente['NIF20'] ?? ''));
        $actual     = (int)($cliente['IDGRUPO_VALIDO'] ?? 0);

        /*
        |--------------------------------------------------------------------------
        | PASO 25.3: SI YA TIENE EL MISMO DESCUENTO
        |--------------------------------------------------------------------------
        | No borra.
        | No inserta.
        | No cuenta como aplicado.
        | No se audita.
        |--------------------------------------------------------------------------
        */
        if ($idgrupo !== 0 && $actual === $idgrupo) {

            $resultado["ya_existen"]++;

            $resultado["detalle"][] = [
                "identidad"       => $identidadNum,
                "codcliente"      => $codcliente,
                "nombre"          => $nombre,
                "nif20_icg"       => $nif20,
                "idgrupo_actual"  => $actual,
                "idgrupo_nuevo"   => $idgrupo,
                "tipo_descuento"  => label_descuento($empresa, $idgrupo, $cfg),
                "accion"          => "YA_EXISTE",
                "mensaje"         => "Ya existe"
            ];

            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 25.4: BORRAR DESCUENTO ANTERIOR DE ESA EMPRESA
        |--------------------------------------------------------------------------
        */
        $stDel->execute([$codcliente]);

        /*
        |--------------------------------------------------------------------------
        | PASO 25.5: SI IDGRUPO = 0, SOLO ELIMINAR
        |--------------------------------------------------------------------------
        */
        if ($idgrupo === 0) {

            if ($actual !== 0) {
                $resultado["aplicados"]++;
                $resultado["eliminados"]++;

                $accionDetalle = "ELIMINADO";
                $mensajeDetalle = "Descuento eliminado";
            } else {
                $resultado["ya_existen"]++;

                $accionDetalle = "YA_EXISTE";
                $mensajeDetalle = "Ya existe";
            }

            $resultado["detalle"][] = [
                "identidad"       => $identidadNum,
                "codcliente"      => $codcliente,
                "nombre"          => $nombre,
                "nif20_icg"       => $nif20,
                "idgrupo_actual"  => $actual,
                "idgrupo_nuevo"   => 0,
                "tipo_descuento"  => "",
                "accion"          => $accionDetalle,
                "mensaje"         => $mensajeDetalle
            ];

            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 25.6: OBTENER GRUPOOR ÚNICO
        |--------------------------------------------------------------------------
        */
        $stNext->execute([$idgrupo]);
        $grupoOr = (int)($stNext->fetchColumn() ?? 1);

        if ($grupoOr < 1) {
            $grupoOr = 1;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 25.7: INSERTAR NUEVO DESCUENTO
        |--------------------------------------------------------------------------
        */
        $stIns->execute([$idgrupo, $grupoOr, $codcliente]);

        /*
        |--------------------------------------------------------------------------
        | PASO 25.8: DEFINIR ACCIÓN DEL DETALLE
        |--------------------------------------------------------------------------
        */
        $resultado["aplicados"]++;

        if ($actual !== 0 && $actual !== $idgrupo) {
            $resultado["cambiados"]++;
            $accionDetalle = "CAMBIADO";
            $mensajeDetalle = "Descuento cambiado";
        } else {
            $accionDetalle = "APLICADO";
            $mensajeDetalle = "Descuento aplicado";
        }

        $resultado["detalle"][] = [
            "identidad"       => $identidadNum,
            "codcliente"      => $codcliente,
            "nombre"          => $nombre,
            "nif20_icg"       => $nif20,
            "idgrupo_actual"  => $actual,
            "idgrupo_nuevo"   => $idgrupo,
            "tipo_descuento"  => label_descuento($empresa, $idgrupo, $cfg),
            "grupoOr"         => $grupoOr,
            "accion"          => $accionDetalle,
            "mensaje"         => $mensajeDetalle
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 26: CONFIRMAR TRANSACCIÓN
    |--------------------------------------------------------------------------
    */
    $pdo->commit();

    /*
    |--------------------------------------------------------------------------
    |  AUDITORÍA LOCAL MYSQL
    |--------------------------------------------------------------------------
    | Se registra solo cuando sí hubo cambio:
    | - APLICADO
    | - CAMBIADO
    | - ELIMINADO
    |
    | No se registra:
    | - YA_EXISTE
    | - NO_ENCONTRADO
    |--------------------------------------------------------------------------
    */
    try {
        require_once __DIR__ . "/../usuarios/conexion.php";

        if (isset($conn) && $conn instanceof mysqli) {

            $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';

            if ($ip === '::1' || $ip === '') {
                $ip = 'LOCALHOST';
            }

            $stmt = $conn->prepare("
                INSERT INTO auditoria (accion, detalle, usuario_id, ip)
                VALUES (?, ?, ?, ?)
            ");

            if ($stmt) {

                foreach ($resultado["detalle"] as $d) {

                    $accionItem = strtoupper(trim((string)($d["accion"] ?? '')));

                    /*
                    |--------------------------------------------------------------------------
                    | No auditar si no hubo cambio.
                    |--------------------------------------------------------------------------
                    */
                    if (in_array($accionItem, ['YA_EXISTE', 'NO_ENCONTRADO'], true)) {
                        continue;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Definir acción para auditoría.
                    |--------------------------------------------------------------------------
                    */
                    if ($accionItem === 'ELIMINADO') {
                        $accionAud = "DESCUENTO_ELIMINADO";
                    } elseif ($accionItem === 'CAMBIADO') {
                        $accionAud = "DESCUENTO_CAMBIADO_MASIVO";
                    } else {
                        $accionAud = "DESCUENTO_MASIVO";
                    }

                    $codAud = (string)($d["codcliente"] ?? '');
                    $idAud  = (string)($d["identidad"] ?? '');
                    $grupoAnterior = (int)($d["idgrupo_actual"] ?? 0);
                    $grupoNuevo    = (int)($d["idgrupo_nuevo"] ?? 0);

                    $detalle = "ICG={$empresa}"
                        . " | CODCLIENTE={$codAud}"
                        . " | IDGRUPO={$grupoNuevo}"
                        . " | IDGRUPO_ANTERIOR={$grupoAnterior}"
                        . " | IDGRUPO_NUEVO={$grupoNuevo}"
                        . " | IDENTIDAD={$idAud}"
                        . " | MASIVO=SI";

                    $stmt->bind_param(
                        "ssis",
                        $accionAud,
                        $detalle,
                        $usuarioId,
                        $ip
                    );

                    $stmt->execute();
                }

                $stmt->close();
            }
        }
    } catch (Throwable $e) {
      
    }

   
    $aplicados     = (int)($resultado["aplicados"] ?? 0);
    $cambiados     = (int)($resultado["cambiados"] ?? 0);
    $eliminados    = (int)($resultado["eliminados"] ?? 0);
    $yaExisten     = (int)($resultado["ya_existen"] ?? 0);
    $noEncontrados = count($resultado["no_encontrados"] ?? []);

   
    if ($aplicados === 0 && $cambiados === 0 && $eliminados === 0 && $yaExisten > 0) {
        out(false, "Ya existe", $resultado);
    }

    /*
    |--------------------------------------------------------------------------
    | CASO 2: NO HUBO CAMBIOS Y SOLO HUBO NO ENCONTRADOS
    |--------------------------------------------------------------------------
    */
    if ($aplicados === 0 && $cambiados === 0 && $eliminados === 0 && $yaExisten === 0 && $noEncontrados > 0) {
        out(false, "No se encontraron clientes válidos en ICG", $resultado);
    }

    /*
    |--------------------------------------------------------------------------
    | CASO 3: SÍ HUBO CAMBIOS
    |--------------------------------------------------------------------------
    */
    out(true, "Proceso masivo finalizado", $resultado);

} catch (Throwable $e) {

    /*
    |--------------------------------------------------------------------------
    | PASO 29: ROLLBACK SI FALLA
    |--------------------------------------------------------------------------
    */
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 30: RESPUESTA DE ERROR
    |--------------------------------------------------------------------------
    */
    out(false, "Error al aplicar descuento masivo", [
        "error" => $e->getMessage()
    ]);
}