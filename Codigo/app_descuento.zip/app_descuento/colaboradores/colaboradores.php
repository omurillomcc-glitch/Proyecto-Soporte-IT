<?php
require_once __DIR__ . "/../usuarios/validar_sesion.php";
?>


<link rel="stylesheet" href="/app_descuento/colaboradores/colaboradores.css?v=<?= time() ?>">

<!--
|--------------------------------------------------------------------------
| CONTENEDOR PRINCIPAL
|--------------------------------------------------------------------------
| Aquí empieza toda la vista visual del módulo de colaboradores.
|--------------------------------------------------------------------------
-->
<div class="container py-4">
  <div class="card card-soft p-3 p-md-4">

    <!--
    |--------------------------------------------------------------------------
    | TOPBAR / CABECERA
    |--------------------------------------------------------------------------
    | Muestra:
    | - título principal
    | - subtítulo
    | - estado actual del módulo
    |--------------------------------------------------------------------------
    -->
    <div class="topbar">
      <div class="title-wrap">
        <h4 class="mb-0">Colaboradores</h4>
        <div class="subtitle">Evolution + ICG (Mendels, Acajoe, Detodo y Chesters)</div>
      </div>
      <div class="top-actions">
        <span id="estado" class="badge badge-soft">Listo</span>
      </div>
    </div>

    <div class="split">

      <!--
      |--------------------------------------------------------------------------
      | PANEL IZQUIERDO
      |--------------------------------------------------------------------------
      | Aquí van:
      | - filtros
      | - campo de búsqueda
      | - botón para cargar
      | - paginación
      |--------------------------------------------------------------------------
      -->
      <aside class="side">
        <div class="side-card">
          <div class="side-title">Filtros</div>

          <!-- Selector de filtro -->
          <label class="form-label mt-2">Filtro</label>
          <select id="filtro" class="form-select">
            <option value="todos">Todos</option>
            <option value="con">Con descuento</option>
            <option value="sin">Sin descuento</option>
          </select>

          <!-- Campo de búsqueda -->
          <label class="form-label mt-3">Buscar</label>
          <input id="buscar" class="form-control" placeholder="Ej: Maria o 0801-1990">


          <button id="btnMasivo" type="button" class="btn btn-success w-100 mt-2">
  Asignar masivo
</button>

          <!-- Botón que dispara la carga manual -->
          <button id="btnCargar" type="button" class="btn w-100 mt-3">Cargar</button>

          <!-- Texto de ayuda -->
          <div class="help mt-3">
            Tip: puedes buscar por nombre o identidad con o sin guiones.
          </div>
        </div>

        <!--
        |--------------------------------------------------------------------------
        | PANEL DE PAGINACIÓN
        |--------------------------------------------------------------------------
        -->
        <div class="side-card mt-3">
          <div class="side-title"></div>
          <div id="paginacionInfo" class="small text-muted"></div>

          <div class="pager mt-2">
            <button type="button" class="btn btn-pill" id="btnPrev">Anterior</button>
            <button type="button" class="btn btn-pill" id="btnNext">Siguiente</button>
          </div>

          <div class="mt-2" id="paginacionNumeros"></div>
        </div>
      </aside>

      <!--
      |--------------------------------------------------------------------------
      | PANEL DERECHO / TABLA
      |--------------------------------------------------------------------------
      -->
      <section class="main">
        <div class="table-wrap">
          <div class="table-head">
            <div class="table-title">Listado</div>
            <div class="table-meta" id="tableMeta"></div>
          </div>

          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead>
                <tr>
                  <th class="col-num">N°</th>
                  <th class="col-codigo">Código</th>
                  <th class="col-identidad">Identidad</th>
                  <th class="col-nombre">Nombre</th>
                  <th class="col-empresa">Empresa</th>
                  <th>Desc.</th>
                  <th class="col-tipo">Tipo</th>
                  <th class="col-accion">Acción</th>
                </tr>
              </thead>
              <tbody id="tbody">
                <tr><td colspan="8" class="text-secondary">Presiona <b>Cargar</b>.</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>

  </div>
</div>

<!--
|--------------------------------------------------------------------------
| MODAL PARA ASIGNAR / CAMBIAR DESCUENTO
|--------------------------------------------------------------------------
| Este modal se abre al dar clic en "Asignar o Cambiar".
|--------------------------------------------------------------------------
-->
<div class="modal fade" id="modalGrupo" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border-radius:22px">
      <div class="modal-header">
        <h5 class="modal-title">Asignar o Cambiar</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="mb-2">
          <div class="small text-secondary">Empresa</div>
          <div id="m_empresa_show" class="mono"></div>
        </div>

        <div class="mb-2">
          <div class="small text-secondary">Identidad</div>
          <div id="m_identidad_show" class="mono"></div>
        </div>

        <div class="mb-3">
          <label class="form-label">Tipo de descuento (ICG)</label>
          <select id="m_idgrupo" class="form-select">
            <option value="">Seleccione...</option>
          </select>
          <div class="form-text">Listado desde ICG según la empresa seleccionada.</div>
        </div>

        <div class="mb-2">
          <div class="small text-secondary">Tipo actual</div>
          <div id="m_tipo_actual" class="fw-semibold">-</div>
        </div>

        <div id="m_msg" class="small"></div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" id="m_guardar" class="btn btn-primary">Guardar</button>
      </div>
    </div>
  </div>
</div>


<!-- MODAL MASIVO -->
<div class="modal fade" id="modalMasivo" tabindex="-1">
<div class="modal-dialog modal-dialog-centered modal-lg modal-move">
    <div class="modal-content" style="border-radius:22px">
      <div class="modal-header">
        <h5 class="modal-title">Asignar descuento masivo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <label class="form-label">Empresa</label>
        <select id="masivo_empresa" class="form-select mb-3">
          <option value="mendels">Mendels</option>
          <option value="acajoe">Acajoe</option>
          <option value="detodo">Detodo</option>
          <option value="chesters">Chesters</option>
        </select>

        <label class="form-label">Descuento</label>
        <select id="masivo_idgrupo" class="form-select mb-3">
          <option value="">Seleccione descuento...</option>
        </select>

        <label class="form-label">Identidades</label>
        <textarea id="masivo_identidades" class="form-control" rows="8"
          placeholder="Pegue una identidad por línea&#10;1503-2007-00954&#10;0501-2003-07712"></textarea>

        <div class="form-text">
          Puedes pegar identidades separadas por línea, coma o punto y coma.
        </div>

        <div id="masivo_msg" class="small mt-3"></div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" id="btnAplicarMasivo" class="btn btn-success">Procesar descuento</button>
      </div>
    </div>
  </div>
</div>



<script>
/*
|--------------------------------------------------------------------------
| IIFE
|--------------------------------------------------------------------------
| Esta función autoejecutable evita contaminar el scope global.
|--------------------------------------------------------------------------
*/
(() => {

  /*
  |--------------------------------------------------------------------------
  | DESTRUIR INSTANCIA ANTERIOR SI EXISTE
  |--------------------------------------------------------------------------
  */
  if (window.__COLAB_VIEW__?.destroy) window.__COLAB_VIEW__.destroy();

  /*
  |--------------------------------------------------------------------------
  | OBJETO DE LA VISTA
  |--------------------------------------------------------------------------
  */
  const VIEW = {};
  window.__COLAB_VIEW__ = VIEW;

  /*
  |--------------------------------------------------------------------------
  | CONFIGURACIÓN BASE
  |--------------------------------------------------------------------------
  */
  const BASE = "/app_descuento/colaboradores/";
  const ENDPOINT_LISTA   = "empleados_all.php";
  const ENDPOINT_GUARDAR = "guardar_descuento.php";
  const ENDPOINT_GRUPOS  = "grupos_descuento.php";
  const ENDPOINT_MASIVO = "guardar_descuento_masivo.php";
  const PER_PAGE = 100;

  /*
  |--------------------------------------------------------------------------
  | ATAJO PARA getElementById
  |--------------------------------------------------------------------------
  */
  const $ = (id) => document.getElementById(id);

  /*
  |--------------------------------------------------------------------------
  | REFERENCIAS A ELEMENTOS DEL DOM
  |--------------------------------------------------------------------------
  */
  const $filtro = $("filtro");
  const $btnCargar = $("btnCargar");
  const $tb = $("tbody");
  const $estado = $("estado");
  const $buscar = $("buscar");

  const $pagInfo = $("paginacionInfo");
  const $btnPrev = $("btnPrev");
  const $btnNext = $("btnNext");
  const $pagNums = $("paginacionNumeros");
  const $tableMeta = $("tableMeta");

  const modalEl = $("modalGrupo");
  const modal = modalEl && window.bootstrap ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;

  const $mEmpresaShow = $("m_empresa_show");
  const $mIdentidadShow = $("m_identidad_show");
  const $mIdGrupo = $("m_idgrupo");
  const $mTipoActual = $("m_tipo_actual");
  const $mMsg = $("m_msg");
  const $mGuardar = $("m_guardar");


  const modalMasivoEl = $("modalMasivo");
const modalMasivo = modalMasivoEl && window.bootstrap
  ? bootstrap.Modal.getOrCreateInstance(modalMasivoEl)
  : null;

const $btnMasivo = $("btnMasivo");
const $masivoEmpresa = $("masivo_empresa");
const $masivoIdGrupo = $("masivo_idgrupo");
const $masivoIdentidades = $("masivo_identidades");
const $masivoMsg = $("masivo_msg");
const $btnAplicarMasivo = $("btnAplicarMasivo");

  const $modalHelp = modalEl?.querySelector(".form-text");

  /*
  |--------------------------------------------------------------------------
  | VALIDACIÓN DE ELEMENTOS
  |--------------------------------------------------------------------------
  */
  if(!$tb || !$btnCargar || !$filtro || !$buscar || !$estado) return;
  if(!modal || !$mEmpresaShow || !$mIdentidadShow || !$mIdGrupo || !$mTipoActual || !$mMsg || !$mGuardar) return;

  /*
  |--------------------------------------------------------------------------
  | VARIABLES DE ESTADO
  |--------------------------------------------------------------------------
  */
  let paginaActual = 1;
  let totalPages = 1;
  let totalRegistros = 0;
  let searchTimer = null;

  /*
  |--------------------------------------------------------------------------
  | FUNCIÓN esc()
  |--------------------------------------------------------------------------
  | Escapa caracteres especiales para evitar problemas de HTML.
  |--------------------------------------------------------------------------
  */
  function esc(s){
    return (s ?? '').toString().replace(/[&<>"']/g, m =>
      ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])
    );
  }

  /*
  |--------------------------------------------------------------------------
  | CAMBIAR TEXTO DEL ESTADO
  |--------------------------------------------------------------------------
  */
  function setEstado(t){
    $estado.textContent = t;
  }

  /*
  |--------------------------------------------------------------------------
  | NORMALIZAR EMPRESA
  |--------------------------------------------------------------------------
  | Aquí agregamos Acajoe.
  |--------------------------------------------------------------------------
  */
  function empresaNorm(v){
    v = (v || "").toString().trim().toLowerCase();

    const map = {
      "mendels":"mendels",
      "acajoe":"acajoe",
      "detodo":"detodo",
      "de todo":"detodo",
      "de-todo":"detodo",
      "chesters":"chesters"
    };

    return map[v] || v;
  }

  /*
  |--------------------------------------------------------------------------
  | CONFIGURACIÓN DE DESCUENTOS POR EMPRESA
  |--------------------------------------------------------------------------
  | Aquí se definen:
  | - grupos permitidos
  | - etiquetas visibles
  | - texto de ayuda del modal
  |--------------------------------------------------------------------------
  */
  const DESCUENTOS_EMPRESA = {
    mendels: {
      grupos: [0, 12, 13, 14],
      labels: {
        0: "Sin descuento",
        12: "10%",
        13: "20%",
        14: "50%"
      },
      ayuda: "Listado desde ICG para Mendels (grupos 12, 13 y 14)."
    },
    acajoe: {
      grupos: [0, 15, 16, 17, 18],
      labels: {
        0: "Sin descuento",
        15: "10%",
        16: "20%",
        17: "40%",
        18: "50%"
      },
      ayuda: "Listado desde ICG para Acajoe (grupos 15, 16, 17 y 18)."
    },
    detodo: {
      grupos: [0, 12, 13, 14],
      labels: {
        0: "Sin descuento",
        12: "10%",
        13: "20%",
        14: "50%"
      },
      ayuda: "Listado desde ICG para Detodo."
    },
    chesters: {
      grupos: [0, 12, 13, 14],
      labels: {
        0: "Sin descuento",
        12: "10%",
        13: "20%",
        14: "50%"
      },
      ayuda: "Listado desde ICG para Chesters."
    }
  };

  /*
  |--------------------------------------------------------------------------
  | OBTENER CONFIG DE EMPRESA
  |--------------------------------------------------------------------------
  */
  function empresaCfg(empresa){
    return DESCUENTOS_EMPRESA[empresa] || null;
  }

  /*
  |--------------------------------------------------------------------------
  | TRADUCIR IDGRUPO A ETIQUETA
  |--------------------------------------------------------------------------
  */
  function idgrupoLabel(idgrupo, empresa = ""){
    const n = parseInt(idgrupo, 10);
    const cfg = empresaCfg(empresa);

    if (cfg && cfg.labels && cfg.labels[n] !== undefined) {
      return cfg.labels[n];
    }

    if (n === 0) return "Sin descuento";
    if (n === 12 || n === 15) return "10%";
    if (n === 13 || n === 16) return "20%";
    if (n === 17) return "40%";
    if (n === 14 || n === 18) return "50%";

    return "-";
  }

  /*
  |--------------------------------------------------------------------------
  | CAMBIAR TEXTO DE AYUDA DEL MODAL SEGÚN EMPRESA
  |--------------------------------------------------------------------------
  */
  function actualizarAyudaModal(empresa){
    const cfg = empresaCfg(empresa);
    if ($modalHelp) {
      $modalHelp.textContent = cfg?.ayuda || "Listado desde ICG según la empresa seleccionada.";
    }
  }

  /*
  |--------------------------------------------------------------------------
  | CARGAR DESCUENTOS DESDE ICG
  |--------------------------------------------------------------------------
  | Esta función:
  | 1. llama grupos_descuento.php
  | 2. envía empresa e identidad
  | 3. recibe el grupo actual
  | 4. llena el select del modal
  |--------------------------------------------------------------------------
  */
  async function cargarDescuentosICG(empresa, identidad){
    $mIdGrupo.innerHTML = `<option value="">Cargando...</option>`;
    $mGuardar.disabled = true;
    $mMsg.textContent = "";
    $mMsg.className = "small";

    actualizarAyudaModal(empresa);

    try{
      const url = BASE + ENDPOINT_GRUPOS
        + "?empresa=" + encodeURIComponent(empresa)
        + "&identidad=" + encodeURIComponent(identidad);

      const res = await fetch(url, { cache:"no-store", credentials:"same-origin" });
      const text = await res.text();

      let json = null;
      try { json = JSON.parse(text); } catch(e){}

      if(!json || !json.ok){
  $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
  $mGuardar.disabled = true;
  $mMsg.textContent = json?.msg ? `Error: ${json.msg}` : "No se pudo cargar (respuesta no JSON).";
  $mMsg.className = "small text-danger";
  console.error("URL grupos:", url);
  console.error("Respuesta grupos:", text);
  return false;
}

      const data = json.data || {};
      const opciones = data.opciones || [];
      const actual = Number(data.idgrupo_actual ?? 0);

      $mTipoActual.textContent = idgrupoLabel(actual, empresa);

      $mIdGrupo.innerHTML = `<option value="">Seleccione descuento...</option>`;

      opciones.forEach(op => {
        const idg = Number(op.idgrupo ?? 0);
        const label = op.label ?? idgrupoLabel(idg, empresa);
        const selected = (idg === actual) ? "selected" : "";

        $mIdGrupo.insertAdjacentHTML(
          "beforeend",
          `<option value="${idg}" ${selected}>${esc(label)}</option>`
        );
      });

      $mGuardar.disabled = false;
      return true;

    }catch(e){
  console.error(e);
  $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
  $mGuardar.disabled = true;
  $mMsg.textContent = "Error cargando descuentos desde ICG.";
  $mMsg.className = "small text-danger";
  return false;
}
  }


function llenarMasivoGrupos(){
  const empresa = empresaNorm($masivoEmpresa.value || "");
  const cfg = empresaCfg(empresa);

  $masivoIdGrupo.innerHTML = `<option value="">Seleccione acción...</option>`;

  if(!cfg) return;

  /*
  |--------------------------------------------------------------------------
  | OPCIÓN PARA ELIMINAR DESCUENTO MASIVO
  |--------------------------------------------------------------------------
  | idgrupo = 0 significa eliminar descuento.
  |--------------------------------------------------------------------------
  */
  $masivoIdGrupo.insertAdjacentHTML(
    "beforeend",
    `<option value="0">Eliminar descuento</option>`
  );

  /*
  |--------------------------------------------------------------------------
  | OPCIONES PARA ASIGNAR DESCUENTO MASIVO
  |--------------------------------------------------------------------------
  */
  cfg.grupos.forEach(idg => {
    if(idg === 0) return;

    $masivoIdGrupo.insertAdjacentHTML(
      "beforeend",
      `<option value="${idg}">Asignar ${esc(idgrupoLabel(idg, empresa))}</option>`
    );
  });
}

function abrirMasivo(){
  llenarMasivoGrupos();
  $masivoIdentidades.value = "";
  $masivoMsg.textContent = "";
  modalMasivo.show();
}

async function aplicarMasivo(){

  const empresa = empresaNorm($masivoEmpresa.value || "");
  const idgrupoValor = $masivoIdGrupo.value;
  const idgrupo = parseInt(idgrupoValor || "0", 10);
  const identidades = ($masivoIdentidades.value || "").trim();

  /*
  |--------------------------------------------------------------------------
  | VALIDACIÓN
  |--------------------------------------------------------------------------
  | OJO:
  | No usamos !idgrupo porque idgrupo = 0 significa eliminar descuento.
  |--------------------------------------------------------------------------
  */
  if(!empresa || idgrupoValor === "" || !identidades){
    $masivoMsg.textContent = "Completa todos los campos.";
    $masivoMsg.className = "small text-danger";
    return;
  }

  $btnAplicarMasivo.disabled = true;

  $masivoMsg.textContent = idgrupo === 0
    ? "Eliminando descuentos..."
    : "Aplicando descuentos...";

  $masivoMsg.className = "small text-secondary";

  try{
    const fd = new FormData();
    fd.append("empresa", empresa);
    fd.append("idgrupo", String(idgrupo));
    fd.append("identidades", identidades);

    const res = await fetch(BASE + ENDPOINT_MASIVO, {
      method: "POST",
      body: fd,
      credentials: "same-origin"
    });

    const json = await res.json();

    if(!json.ok){
      throw new Error(json.msg || "Error");
    }

    $masivoMsg.textContent = idgrupo === 0
      ? "Descuentos eliminados correctamente"
      : "Descuentos aplicados correctamente";

    $masivoMsg.className = "small text-success";

    /*
    |--------------------------------------------------------------------------
    | RECARGAR TABLA Y CONTEOS
    |--------------------------------------------------------------------------
    */
    await cargar();

  }catch(e){
    $masivoMsg.textContent = e.message;
    $masivoMsg.className = "small text-danger";
  }finally{
    $btnAplicarMasivo.disabled = false;
  }
}

  /*
  |--------------------------------------------------------------------------
  | RENDERIZAR TABLA
  |--------------------------------------------------------------------------
  */
  function renderTabla(lista){
    if(!lista || !lista.length){
      $tb.innerHTML = `<tr><td colspan="8" class="text-secondary">Sin resultados.</td></tr>`;
      return;
    }

    const baseIndex = ((paginaActual - 1) * PER_PAGE);

    $tb.innerHTML = lista.map((r, idx) => {
      const num = baseIndex + idx + 1;
      const empresa = empresaNorm(r.empresa ?? "");

      const badge = r.tiene_descuento
        ? `<span class="badge bg-success">SI</span>`
        : `<span class="badge bg-secondary">NO</span>`;

      const tipo = (r.tipo_descuento && String(r.tipo_descuento).trim())
        ? esc(r.tipo_descuento)
        : (r.tiene_descuento ? idgrupoLabel(r.idgrupo_encontrado ?? 0, empresa) : 'Sin descuento');

      return `
        <tr>
          <td class="text-muted fw-semibold">${num}</td>
          <td class="mono">${esc(r.codigo ?? '')}</td>
          <td class="mono">${esc(r.identidad ?? '')}</td>
          <td title="${esc(r.nombre ?? '')}">${esc(r.nombre ?? '')}</td>
          <td class="mono">${esc(r.empresa ?? '')}</td>
          <td>${badge}</td>
          <td title="${esc(tipo)}">${esc(tipo)}</td>
          <td class="text-end">
            <button type="button"
              class="btn btn-sm btn-outline-primary btn-abrir-grupo"
              data-identidad="${esc(r.identidad_num ?? '')}"
              data-identidad-show="${esc(r.identidad ?? '')}"
              data-empresa="${esc(r.empresa ?? '')}">
              Asignar o Cambiar
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  /*
  |--------------------------------------------------------------------------
  | RENDERIZAR INFO DE PAGINACIÓN
  |--------------------------------------------------------------------------
  */
  function renderPaginacion(){
    if(totalRegistros <= 0) {
      $pagInfo.textContent = '';
      if ($tableMeta) $tableMeta.textContent = '';
    } else {
      const desde = ((paginaActual - 1) * PER_PAGE) + 1;
      const hasta = Math.min(paginaActual * PER_PAGE, totalRegistros);

      $pagInfo.textContent = `Empleados ${desde}-${hasta} de ${totalRegistros} | Página ${paginaActual} de ${totalPages}`;

      if ($tableMeta) {
        $tableMeta.textContent = `${desde}-${hasta} de ${totalRegistros}`;
      }
    }

    $btnPrev.disabled = paginaActual <= 1;
    $btnNext.disabled = paginaActual >= totalPages;
  }


function makeDraggable(modalId){
  const modal = document.getElementById(modalId);
  const dialog = modal.querySelector(".modal-dialog");
  const header = modal.querySelector(".modal-header");

  let isDown = false;
  let offsetX = 0;
  let offsetY = 0;

  header.style.cursor = "move";

  header.addEventListener("mousedown", (e) => {
    isDown = true;

    const rect = dialog.getBoundingClientRect();

    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;

    dialog.style.position = "fixed";
    dialog.style.margin = "0";
    dialog.style.left = rect.left + "px";
    dialog.style.top = rect.top + "px";
    dialog.style.zIndex = 9999;
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDown) return;

    dialog.style.left = (e.clientX - offsetX) + "px";
    dialog.style.top = (e.clientY - offsetY) + "px";
  });

  document.addEventListener("mouseup", () => {
    isDown = false;
  });
}
  /*
  |--------------------------------------------------------------------------
  | RENDERIZAR BOTONES NUMÉRICOS DE PAGINACIÓN
  |--------------------------------------------------------------------------
  */
  function renderPaginacionNumeros(){
    if(!$pagNums) return;

    if(totalPages <= 1){
      $pagNums.innerHTML = "";
      return;
    }

    const maxBtns = 7;
    let start = Math.max(1, paginaActual - Math.floor(maxBtns/2));
    let end = start + maxBtns - 1;

    if (end > totalPages) {
      end = totalPages;
      start = Math.max(1, end - maxBtns + 1);
    }

    const btn = (p, label=null, active=false) => `
      <button type="button" class="page-pill ${active ? "active" : ""}" data-page="${p}">
        ${label ?? p}
      </button>
    `;

    let html = `<div class="pages">`;

    if(start > 1){
      html += btn(1, "1", paginaActual===1);
      if(start > 2) html += `<span class="dots">…</span>`;
    }

    for(let p=start; p<=end; p++){
      html += btn(p, null, p===paginaActual);
    }

    if(end < totalPages){
      if(end < totalPages - 1) html += `<span class="dots">…</span>`;
      html += btn(totalPages, String(totalPages), paginaActual===totalPages);
    }

    html += `</div>`;
    $pagNums.innerHTML = html;
  }

  /*
  |--------------------------------------------------------------------------
  | EVENTO: CLIC EN NÚMEROS DE PÁGINA
  |--------------------------------------------------------------------------
  */
  VIEW.onPagNumsClick = (e) => {
    const b = e.target.closest(".page-pill");
    if(!b) return;

    const p = parseInt(b.dataset.page || "1", 10);
    if(!p || p===paginaActual) return;

    paginaActual = p;
    cargar();
  };

  /*
  |--------------------------------------------------------------------------
  | FUNCIÓN PRINCIPAL: CARGAR LISTADO
  |--------------------------------------------------------------------------
  */
  async function cargar(){
    setEstado("Cargando...");
    $tb.innerHTML = `<tr><td colspan="8" class="text-secondary">Cargando...</td></tr>`;

    const params = new URLSearchParams();
    params.set("filtro", ($filtro.value || "todos"));
    params.set("page", String(paginaActual));
    params.set("per_page", String(PER_PAGE));
    params.set("max_evo", "150000");

    const q = ($buscar.value || '').trim();
    if (q) params.set("q", q);

    const url = BASE + ENDPOINT_LISTA + "?" + params.toString();

    try{
      const res = await fetch(url, { cache:"no-store", credentials:"same-origin" });
      const data = await res.json();

      if(!data.ok){
        setEstado("Error");
        $tb.innerHTML = `<tr><td colspan="8" class="text-danger">${esc(data.msg || "Error")}</td></tr>`;
        return;
      }

      const lista = data.data || [];
      totalRegistros = Number(data.total ?? 0) || 0;
      totalPages = Number(data.total_pages ?? 1) || 1;
      paginaActual = Number(data.page ?? paginaActual) || paginaActual;

      const filtroActual = $filtro.value || "todos";

let textoEstado = "";

if (filtroActual === "con") {
  textoEstado = `${totalRegistros} con descuento`;
} else if (filtroActual === "sin") {
  textoEstado = `${totalRegistros} sin descuento`;
} else {
  textoEstado = `${totalRegistros} colaboradores`;
}

setEstado(textoEstado);

renderTabla(lista);
renderPaginacion();
renderPaginacionNumeros();

    }catch(e){
      console.error(e);
      setEstado("Error");
      $tb.innerHTML = `<tr><td colspan="8" class="text-danger">No se pudo conectar al backend.</td></tr>`;
    }
  }

/*
|--------------------------------------------------------------------------
| EVENTO GLOBAL: ABRIR MODAL
|--------------------------------------------------------------------------
| 
| - El modal abre rápido.
| - Los descuentos cargan después.
|--------------------------------------------------------------------------
*/
VIEW.onDocClick = async (e) => {
  const btn = e.target.closest(".btn-abrir-grupo");
  if (!btn) return;

  const identidadNum  = (btn.dataset.identidad || "").trim();
  const identidadShow = (btn.dataset.identidadShow || "").trim();
  const empresa = empresaNorm(btn.dataset.empresa || "");

  modalEl.dataset.identidad = identidadNum;
  modalEl.dataset.empresa = empresa;

  $mIdentidadShow.textContent = identidadShow || identidadNum || "-";
  $mEmpresaShow.textContent = empresa || "-";
  $mTipoActual.textContent = "Cargando...";
  $mMsg.textContent = "";
  $mMsg.className = "small";

  actualizarAyudaModal(empresa);

  $mIdGrupo.innerHTML = `<option value="">Cargando descuentos...</option>`;
  $mGuardar.disabled = true;
  // ABRIR MODAL DE INMEDIATO
  modal.show();

  if (!identidadNum) {
    $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
    $mTipoActual.textContent = "-";
    $mMsg.textContent = "Identidad vacía (el botón no trae data-identidad).";
    $mMsg.className = "small text-danger";
    return;
  }

  // CARGAR DESCUENTOS DESPUÉS DE ABRIR EL MODAL
  cargarDescuentosICG(empresa, identidadNum);
};

  /*
  |--------------------------------------------------------------------------
  | GUARDAR DESCUENTO
  |--------------------------------------------------------------------------
  | Aquí enviamos:
  | - empresa
  | - identidad
  | - idgrupo
  |--------------------------------------------------------------------------
  */
  VIEW.onGuardar = async () => {
    const empresa = empresaNorm(modalEl.dataset.empresa || "");
    const identidad = (modalEl.dataset.identidad || "").trim();
    const idgrupo = parseInt(($mIdGrupo.value || "0"), 10);

    const cfg = empresaCfg(empresa);

    if(!empresa || !cfg){
      $mMsg.textContent = "Empresa inválida.";
      $mMsg.className = "small text-danger";
      return;
    }

    if(!identidad){
      $mMsg.textContent = "Identidad vacía.";
      $mMsg.className = "small text-danger";
      return;
    }

    if(!cfg.grupos.includes(idgrupo)){
      $mMsg.textContent = "Selecciona un descuento válido para esta empresa.";
      $mMsg.className = "small text-danger";
      return;
    }

    $mGuardar.disabled = true;
    $mMsg.textContent = "Guardando...";
    $mMsg.className = "small text-secondary";

    try{
      const url = BASE + ENDPOINT_GUARDAR;

      const fd = new FormData();
      fd.append("empresa", empresa);
      fd.append("identidad", identidad);
      fd.append("idgrupo", String(idgrupo));

      const res = await fetch(url, {
        method:"POST",
        credentials:"same-origin",
        body: fd
      });

      const json = await res.json();

      if(!json.ok){
        throw new Error((json.msg || "Error") + (json?.extra?.error ? (" | " + json.extra.error) : ""));
      }

      $mTipoActual.textContent = idgrupoLabel(idgrupo, empresa);
      $mMsg.textContent = json.msg || "Descuento actualizado correctamente";
      $mMsg.className = "small text-success";

      await cargar();

      setTimeout(() => modal.hide(), 650);

    }catch(err){
      $mMsg.textContent = err.message || "Error";
      $mMsg.className = "small text-danger";
    }finally{
      $mGuardar.disabled = false;
    }
  };

  /*
  |--------------------------------------------------------------------------
  | ENLAZAR EVENTOS
  |--------------------------------------------------------------------------
  */
  VIEW.bind = () => {
    $btnCargar.addEventListener("click", () => {
      paginaActual = 1;
      cargar();
    });

    $filtro.addEventListener("change", () => {
      paginaActual = 1;
      cargar();
    });

   $buscar.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    paginaActual = 1;
    cargar();
  }
});

    $btnPrev.addEventListener("click", () => {
      if(paginaActual > 1){
        paginaActual--;
        cargar();
      }
    });

    $btnNext.addEventListener("click", () => {
      if(paginaActual < totalPages){
        paginaActual++;
        cargar();
      }
    });

    document.addEventListener("click", VIEW.onDocClick);
    $pagNums.addEventListener("click", VIEW.onPagNumsClick);
    $mGuardar.addEventListener("click", VIEW.onGuardar);
  };

  /*
  |--------------------------------------------------------------------------
  | DESTRUIR EVENTOS
  |--------------------------------------------------------------------------
  */
  VIEW.destroy = () => {
    try{
      document.removeEventListener("click", VIEW.onDocClick);
      $pagNums.removeEventListener("click", VIEW.onPagNumsClick);
      $mGuardar.removeEventListener("click", VIEW.onGuardar);
    }catch(e){}
  };

  /*
  |--------------------------------------------------------------------------
  | INICIALIZAR LA VISTA
  |--------------------------------------------------------------------------
  */
  VIEW.bind();
if($btnMasivo){
  $btnMasivo.addEventListener("click", abrirMasivo);
}

if($masivoEmpresa){
  $masivoEmpresa.addEventListener("change", llenarMasivoGrupos);
}

if($btnAplicarMasivo){
  $btnAplicarMasivo.addEventListener("click", aplicarMasivo);
}


if (document.getElementById("modalMasivo")) {
  makeDraggable("modalMasivo");
}
})();
</script>