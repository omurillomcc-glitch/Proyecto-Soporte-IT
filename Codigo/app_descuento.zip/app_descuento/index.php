<?php
/*
|--------------------------------------------------------------------------
| PASO 1: VALIDAR SESIÓN
|--------------------------------------------------------------------------
| Este archivo protege el sistema.
| IMPORTANTE:
| En usuarios/validar_sesion.php ya debe ir el session_name()
| antes de session_start().
|
| Ejemplo dentro de validar_sesion.php:
|
| session_name('SESION_DESCUENTOS');
| if (session_status() === PHP_SESSION_NONE) {
|     session_start();
| }
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/usuarios/validar_sesion.php";


/*
|--------------------------------------------------------------------------
| PASO 2: VALIDAR ROL PARA MOSTRAR MENÚ DE ADMINISTRACIÓN
|--------------------------------------------------------------------------
| Aquí definimos quién puede ver el menú de:
| - Auditoría
| - Control de usuarios
|
| Si en tu sistema solo existe "admin", déjalo así.
| Si también tienes "super_admin", ya queda permitido.
|--------------------------------------------------------------------------
*/

$rolUsuario = $_SESSION['rol'] ?? '';

$puedeAdministrar = in_array($rolUsuario, ['admin', 'super_admin'], true);
?>

<!doctype html>
<html lang="es">

<head>
  <!--
  |--------------------------------------------------------------------------
  | PASO 3: CONFIGURACIÓN BÁSICA DEL DOCUMENTO
  |--------------------------------------------------------------------------
  -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Descuento Colaborador</title>

  <!--
  |--------------------------------------------------------------------------
  | PASO 4: CARGAR BOOTSTRAP, ÍCONOS Y ESTILOS
  |--------------------------------------------------------------------------
  | Estos archivos son necesarios para que el diseño se vea bien.
  |--------------------------------------------------------------------------
  -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Tu CSS principal -->
  <link rel="stylesheet" href="/app_descuento/index.css">

  <!-- Fuente -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

  <!-- Icono de la pestaña -->
  <link rel="icon" type="image/png" href="/app_descuento/img/logo.png">
</head>

<body>

<!--
|--------------------------------------------------------------------------
| PASO 5: CONTENEDOR GENERAL
|--------------------------------------------------------------------------
| Aquí empieza toda la estructura principal.
|--------------------------------------------------------------------------
-->
<div class="d-flex">

  <!--
  |--------------------------------------------------------------------------
  | PASO 6: SIDEBAR DESKTOP
  |--------------------------------------------------------------------------
  | Este menú solo aparece en pantallas grandes.
  |--------------------------------------------------------------------------
  -->
  <aside class="sidebar text-white p-3 d-none d-lg-flex flex-column">

    <!-- LOGO -->
    <div class="brand d-flex justify-content-center py-4">
      <img src="/app_descuento/img/logo.png" alt="Logo Corporativo" class="logo-sidebar">
    </div>

    <!-- MENÚ PRINCIPAL DESKTOP -->
    <nav class="d-grid gap-2 d-flex flex-column h-100">

      <!-- INICIO -->
      <a class="menu-link active" href="#" data-page="/app_descuento/dashboard.php">
        <i class="bi bi-house"></i>
        <span>Inicio</span>
      </a>

      <!-- COLABORADORES -->
      <a class="menu-link" href="#" data-page="/app_descuento/colaboradores/colaboradores.php">
        <i class="bi bi-people"></i>
        <span>Colaboradores</span>
      </a>

      <!-- USUARIOS ICG -->
      <a class="menu-link" href="#" data-page="/app_descuento/usuariosICG/icg_usuarios.php">
        <i class="bi bi-person-add"></i>
        <span>Usuarios ICG</span>
      </a>

      <?php if ($puedeAdministrar): ?>

        <!-- AUDITORÍA -->
        <a class="menu-link" href="#" data-page="/app_descuento/auditoria/auditoria.php">
          <i class="bi bi-clipboard-data"></i>
          <span>Auditoría</span>
        </a>

        <!-- BOTÓN PADRE DEL SUBMENÚ USUARIOS -->
        <a
          class="menu-link d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse"
          href="#usersMenuDesk"
          role="button"
          aria-expanded="false"
          aria-controls="usersMenuDesk"
          id="btnUsersDesk"
        >
          <span>
            <i class="bi bi-person-gear"></i>
            Control de usuarios
          </span>
          <i class="bi bi-chevron-down small"></i>
        </a>

        <!-- SUBMENÚ USUARIOS DESKTOP -->
        <div class="collapse submenu" id="usersMenuDesk">

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_agregar_usuario.php">
            <i class="bi bi-person-plus"></i>
            <span>Agregar usuario</span>
          </a>

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_modificar_usuario.php">
            <i class="bi bi-pencil-square"></i>
            <span>Modificar usuario</span>
          </a>

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_bloquear_usuario.php">
            <i class="bi bi-lock"></i>
            <span>Bloquear / Desbloquear</span>
          </a>

        </div>

      <?php endif; ?>

      <hr class="border-light opacity-10">

      <!-- SALIR -->
      <a class="menu-link mt-auto" href="/app_descuento/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Salir</span>
      </a>

    </nav>
  </aside>


  <!--
  |--------------------------------------------------------------------------
  | PASO 7: CONTENIDO PRINCIPAL
  |--------------------------------------------------------------------------
  | Aquí se carga todo lo que viene de dashboard.php, colaboradores.php,
  | vista_agregar_usuario.php, etc.
  |--------------------------------------------------------------------------
  -->
  <div class="flex-grow-1">

    <!-- TOPBAR -->
    <div class="topbar py-2 px-3 d-flex justify-content-between align-items-center">

      <!-- BOTÓN MENÚ MÓVIL -->
      <button
        class="btn btn-primary d-lg-none"
        data-bs-toggle="offcanvas"
        data-bs-target="#mobileSidebar"
        aria-controls="mobileSidebar"
        type="button"
      >
        <i class="bi bi-list"></i>
      </button>

      <!-- TÍTULO -->
      <span class="fw-semibold">Panel Administrativo</span>

      <!-- BOTONES DERECHA -->
      <div class="d-flex align-items-center gap-2 topbar-buttons">
        <a href="#" class="btn btn-primary btn-sm btn-colaboradores d-none d-md-inline-flex" data-page="/app_descuento/colaboradores/colaboradores.php">
          <i class="bi bi-people"></i>
          Colaboradores
        </a>

        <a href="/app_descuento/logout.php" class="btn btn-danger btn-sm btn-salir">
          <i class="bi bi-box-arrow-right"></i>
          Salir
        </a>
      </div>
    </div>

    <!-- CONTENEDOR DINÁMICO -->
    <div class="p-4" id="contenido-principal">

      <!-- CONTENIDO INICIAL MIENTRAS CARGA DASHBOARD -->
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
          <h4>Bienvenidos</h4>
          <p class="text-muted mb-0">Cargando panel...</p>
        </div>
      </div>

    </div>
  </div>
</div>


<!--
|--------------------------------------------------------------------------
| PASO 8: SIDEBAR MÓVIL
|--------------------------------------------------------------------------
| Este menú solo se abre en celular o tablet.
|--------------------------------------------------------------------------
-->
<div
  class="offcanvas offcanvas-start text-white"
  tabindex="-1"
  id="mobileSidebar"
  style="background:#0f172a; width:280px;"
>

  <div class="offcanvas-header">
    <h5 class="mb-0">Mi Sistema</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
  </div>

  <div class="offcanvas-body d-grid gap-2">

    <!-- INICIO MÓVIL -->
    <a class="menu-link" href="#" data-page="/app_descuento/dashboard.php">
      <i class="bi bi-house"></i>
      <span>Inicio</span>
    </a>

    <!-- COLABORADORES MÓVIL -->
    <a class="menu-link" href="#" data-page="/app_descuento/colaboradores/colaboradores.php">
      <i class="bi bi-people"></i>
      <span>Colaboradores</span>
    </a>

    <!-- USUARIOS ICG MÓVIL -->
    <a class="menu-link" href="#" data-page="/app_descuento/usuariosICG/icg_usuarios.php">
      <i class="bi bi-person-add"></i>
      <span>Usuarios ICG</span>
    </a>

    <?php if ($puedeAdministrar): ?>

      <!-- AUDITORÍA MÓVIL -->
      <a class="menu-link" href="#" data-page="/app_descuento/auditoria/auditoria.php">
        <i class="bi bi-clipboard-data"></i>
        <span>Auditoría</span>
      </a>

      <!-- BOTÓN PADRE DEL SUBMENÚ USUARIOS MÓVIL -->
      <a
        class="menu-link d-flex justify-content-between align-items-center"
        data-bs-toggle="collapse"
        href="#usersMenuMob"
        role="button"
        aria-expanded="false"
        aria-controls="usersMenuMob"
        id="btnUsersMob"
      >
        <span>
          <i class="bi bi-person-gear"></i>
          Control de usuarios
        </span>
        <i class="bi bi-chevron-down small"></i>
      </a>

      <!-- SUBMENÚ USUARIOS MÓVIL -->
      <div class="collapse submenu" id="usersMenuMob">

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_agregar_usuario.php">
          <i class="bi bi-person-plus"></i>
          <span>Agregar usuario</span>
        </a>

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_modificar_usuario.php">
          <i class="bi bi-pencil-square"></i>
          <span>Modificar usuario</span>
        </a>

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_bloquear_usuario.php">
          <i class="bi bi-lock"></i>
          <span>Bloquear / Desbloquear</span>
        </a>

      </div>

    <?php endif; ?>

    <hr class="border-light opacity-10">

    <!-- SALIR MÓVIL -->
    <a class="menu-link" href="/app_descuento/logout.php">
      <i class="bi bi-box-arrow-right"></i>
      <span>Salir</span>
    </a>

  </div>
</div>


<!--
|--------------------------------------------------------------------------
| PASO 9: SCRIPTS GENERALES
|--------------------------------------------------------------------------
-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js para gráficos del dashboard -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>


<script>
/*
|--------------------------------------------------------------------------
| PASO 10: ESPERAR A QUE CARGUE EL DOCUMENTO
|--------------------------------------------------------------------------
*/
document.addEventListener("DOMContentLoaded", () => {

  /*
  |--------------------------------------------------------------------------
  | PASO 11: OBTENER EL CONTENEDOR PRINCIPAL
  |--------------------------------------------------------------------------
  | Aquí se cargarán las páginas internas.
  |--------------------------------------------------------------------------
  */
  const contenedor = document.getElementById("contenido-principal");

  if (!contenedor) {
    alert("ERROR: No existe el contenedor #contenido-principal");
    return;
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 12: MOSTRAR LOADER
  |--------------------------------------------------------------------------
  | Este loader aparece mientras se carga una página.
  |--------------------------------------------------------------------------
  */
  function loader() {
    contenedor.innerHTML = `
      <div class="p-3">
        <div class="spinner-border text-primary" role="status" aria-label="Cargando"></div>
        <span class="ms-2">Cargando...</span>
      </div>
    `;
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 13: EVITAR INYECCIÓN VISUAL EN MENSAJES DE ERROR
  |--------------------------------------------------------------------------
  | Convierte caracteres especiales en texto seguro.
  |--------------------------------------------------------------------------
  */
  function escaparHtml(texto) {
    return String(texto ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 14: MOSTRAR ERRORES DE CARGA
  |--------------------------------------------------------------------------
  */
  function mostrarError(pagina, status, statusText, body) {
    contenedor.innerHTML = `
      <div class="alert alert-danger">
        <b>Error cargando:</b> ${escaparHtml(pagina)}<br>
        <b>HTTP:</b> ${escaparHtml(status)} ${escaparHtml(statusText)}
        <hr>
        <pre class="mb-0" style="white-space:pre-wrap;max-height:380px;overflow:auto">${escaparHtml(body || "")}</pre>
      </div>
    `;
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 15: EJECUTAR SCRIPTS DE LAS VISTAS CARGADAS POR AJAX
  |--------------------------------------------------------------------------
  | Cuando cargas un archivo con fetch, los scripts internos no siempre
  | se ejecutan solos. Esta función los vuelve a insertar correctamente.
  |--------------------------------------------------------------------------
  */
  function ejecutarScriptsEn(wrapper) {
    const scripts = wrapper.querySelectorAll("script");

    scripts.forEach(oldScript => {
      const newScript = document.createElement("script");

      [...oldScript.attributes].forEach(attr => {
        newScript.setAttribute(attr.name, attr.value);
      });

      newScript.text = oldScript.textContent;
      oldScript.parentNode.replaceChild(newScript, oldScript);
    });
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 16: LIMPIAR MODALES ABIERTOS
  |--------------------------------------------------------------------------
  | Esto evita que al cambiar de vista quede un modal abierto, fondo negro,
  | body bloqueado o clases pegadas.
  |--------------------------------------------------------------------------
  */
  function limpiarModalesBootstrap() {
    document.querySelectorAll(".modal.show").forEach(modalEl => {
      const modal = bootstrap.Modal.getInstance(modalEl);
      if (modal) {
        modal.hide();
      }
    });

    document.querySelectorAll(".modal-backdrop").forEach(backdrop => backdrop.remove());

    document.body.classList.remove("modal-open");
    document.body.style.overflow = "";
    document.body.style.paddingRight = "";
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 17: MARCAR LINK ACTIVO
  |--------------------------------------------------------------------------
  | Marca en azul o activo la opción que el usuario abrió.
  |--------------------------------------------------------------------------
  */
  function marcarMenuActivo(pagina) {

    // Quitar active de todos los enlaces del menú
    document.querySelectorAll(".menu-link").forEach(link => {
      link.classList.remove("active");
    });

    // Marcar los enlaces que tengan la misma página
    document.querySelectorAll(`a[data-page="${pagina}"]`).forEach(link => {
      link.classList.add("active");
    });
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 18: CONTROLAR SUBMENÚ DE USUARIOS
  |--------------------------------------------------------------------------
  | Si se abre una vista de usuarios, el submenú queda abierto.
  |--------------------------------------------------------------------------
  */
  function controlarSubmenuUsuarios(pagina) {
    const esUsuarios = pagina.includes("/app_descuento/usuarios/");

    // Desktop
    const usersDesk = document.getElementById("usersMenuDesk");
    const btnDesk = document.getElementById("btnUsersDesk");

    if (usersDesk && btnDesk && window.bootstrap) {
      const collapseDesk = bootstrap.Collapse.getOrCreateInstance(usersDesk, { toggle: false });

      if (esUsuarios) {
        collapseDesk.show();
        btnDesk.classList.add("active");
      } else {
        collapseDesk.hide();
        btnDesk.classList.remove("active");
      }
    }

    // Móvil
    const usersMob = document.getElementById("usersMenuMob");
    const btnMob = document.getElementById("btnUsersMob");

    if (usersMob && btnMob && window.bootstrap) {
      const collapseMob = bootstrap.Collapse.getOrCreateInstance(usersMob, { toggle: false });

      if (esUsuarios) {
        collapseMob.show();
        btnMob.classList.add("active");
      } else {
        collapseMob.hide();
        btnMob.classList.remove("active");
      }
    }
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 19: CERRAR SIDEBAR MÓVIL
  |--------------------------------------------------------------------------
  | Cuando el usuario toca una opción en celular, el menú se cierra.
  |--------------------------------------------------------------------------
  */
  function cerrarMenuMovil() {
    const offcanvasEl = document.getElementById("mobileSidebar");

    if (offcanvasEl && offcanvasEl.classList.contains("show") && window.bootstrap) {
      const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasEl);

      if (offcanvas) {
        offcanvas.hide();
      }
    }
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 20: CARGAR PÁGINAS DINÁMICAMENTE
  |--------------------------------------------------------------------------
  | Esta función carga:
  | - dashboard.php
  | - colaboradores.php
  | - icg_usuarios.php
  | - vista_agregar_usuario.php
  | - vista_modificar_usuario.php
  | - vista_bloquear_usuario.php
  |
  | IMPORTANTE:
  | Esas vistas NO deben traer menú completo.
  |--------------------------------------------------------------------------
  */
  async function cargarPagina(pagina) {

    limpiarModalesBootstrap();
    loader();

    try {

      const resp = await fetch(pagina, {
        cache: "no-store",
        credentials: "same-origin"
      });

      const finalUrl = (resp.url || "").toLowerCase();

      /*
      |--------------------------------------------------------------------------
      | PASO 21: SI LA SESIÓN EXPIRÓ Y REDIRIGE AL LOGIN
      |--------------------------------------------------------------------------
      */
      if (
        resp.redirected &&
        (
          finalUrl.includes("/usuarios/login") ||
          finalUrl.includes("login.html") ||
          finalUrl.includes("login.php")
        )
      ) {
        contenedor.innerHTML = `
          <div class="alert alert-warning">
            Sesión expirada o redirección a login.<br>
            <a class="btn btn-primary btn-sm mt-2" href="/app_descuento/usuarios/login.html">
              Ir al login
            </a>
          </div>
        `;
        return;
      }

      /*
      |--------------------------------------------------------------------------
      | PASO 22: SI EL SERVIDOR DEVUELVE 401
      |--------------------------------------------------------------------------
      */
      if (resp.status === 401) {
        contenedor.innerHTML = `
          <div class="alert alert-warning">
            Sesión expirada. Vuelva a iniciar sesión.<br>
            <a class="btn btn-primary btn-sm mt-2" href="/app_descuento/usuarios/login.html">
              Ir al login
            </a>
          </div>
        `;
        return;
      }

      /*
      |--------------------------------------------------------------------------
      | PASO 23: SI EL USUARIO NO TIENE PERMISO
      |--------------------------------------------------------------------------
      */
      if (resp.status === 403) {
        const txt = await resp.text();

        contenedor.innerHTML = `
          <div class="alert alert-danger">
            No tienes permisos para ver esta sección.
            <hr>
            <pre class="mb-0" style="white-space:pre-wrap;max-height:220px;overflow:auto">${escaparHtml(txt || "")}</pre>
          </div>
        `;
        return;
      }

      /*
      |--------------------------------------------------------------------------
      | PASO 24: OBTENER HTML DE LA VISTA
      |--------------------------------------------------------------------------
      */
      const html = await resp.text();

      if (!resp.ok) {
        mostrarError(pagina, resp.status, resp.statusText, html);
        return;
      }

      /*
      |--------------------------------------------------------------------------
      | PASO 25: INSERTAR LA VISTA EN EL CONTENEDOR PRINCIPAL
      |--------------------------------------------------------------------------
      */
      contenedor.innerHTML = html;

      /*
      |--------------------------------------------------------------------------
      | PASO 26: EJECUTAR SCRIPTS INTERNOS DE LA VISTA
      |--------------------------------------------------------------------------
      */
      ejecutarScriptsEn(contenedor);

      /*
      |--------------------------------------------------------------------------
      | PASO 27: SI EL DASHBOARD TIENE GRÁFICOS, INICIARLOS
      |--------------------------------------------------------------------------
      */
      if (typeof window.initDashboardCharts === "function") {
        window.initDashboardCharts();
      }

      /*
      |--------------------------------------------------------------------------
      | PASO 28: MARCAR MENÚ ACTIVO Y CONTROLAR SUBMENÚ
      |--------------------------------------------------------------------------
      */
      marcarMenuActivo(pagina);
      controlarSubmenuUsuarios(pagina);

    } catch (e) {
      mostrarError(pagina, "FETCH", "Failed", e.message);
    }
  }


  /*
  |--------------------------------------------------------------------------
  | PASO 29: DETECTAR CLIC EN CUALQUIER ENLACE CON data-page
  |--------------------------------------------------------------------------
  | Todo enlace que tenga data-page se carga dentro del contenedor.
  |--------------------------------------------------------------------------
  */
  document.addEventListener("click", (e) => {
    const link = e.target.closest("a[data-page]");

    if (!link) {
      return;
    }

    e.preventDefault();

    const pagina = link.getAttribute("data-page");

    if (!pagina) {
      return;
    }

    cargarPagina(pagina);
    cerrarMenuMovil();
  });

	// Bloquear el menú del clic derecho
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // Bloquear atajos de teclado comunes (F12, Ctrl+Shift+I, Ctrl+U)
    document.addEventListener('keydown', function(e) {
        // F12
        if (e.keyCode === 123) {
            e.preventDefault();
        }
        // Ctrl + Shift + I (Inspector) o Ctrl + Shift + C
        if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 67)) {
            e.preventDefault();
        }
        // Ctrl + U (Ver código fuente)
        if (e.ctrlKey && e.keyCode === 85) {
            e.preventDefault();
        }
    });

  /*
  |--------------------------------------------------------------------------
  | PASO 30: CARGA INICIAL DEL DASHBOARD
  |--------------------------------------------------------------------------
  | Al entrar al sistema, se carga el dashboard automáticamente.
  |--------------------------------------------------------------------------
  */
  cargarPagina("/app_descuento/dashboard.php");

});
</script>

</body>
</html>