<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de Firma Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="logo-blanco.png">
     <link rel="stylesheet" href="estilos.css?v=3.0">
</head>
<body>

    <div class="wrapper">
        <div class="side-banner">
            <div>
                <span class="badge">Herramienta</span>
                <h1 style="margin-top: 1.5rem;">Firma Digital Corporativa</h1>
                <p>Genere su archivo PNG oficial para pie de correo electrónico de manera instantánea.</p>
            </div>
            <p style="font-size: 0.8rem; opacity: 0.7;">© Grupo MCC - Todos los derechos reservados</p>
        </div>

        <div class="main-form">
            <div class="form-grid">
                <div class="full-width">
                    <label for="empresa">Empresa *</label>
                    <select id="empresa" name="empresa" required onchange="cargarPlantilla()">
                        <option value="">Seleccione Empresa</option>
                        <option value="img/PIE DE CORREO ACA JOE.jpg">ACA JOE</option>
                        <option value="img/PIE DE CORREO CHESTERS.jpg">CHESTER'S</option>
                        <option value="img/PIE DE CORREO CREDITO MENDELS.jpg">CRÉDITO MENDELS</option>
                        <option value="img/PIE DE CORREO DETODO.jpg">DE TODO</option>
                        <option value="img/PIE DE CORREO MENDELS.jpg">MENDELS</option>
                        <option value="img/PIE DE CORREO UNIMALL.jpg">UNIMALL</option>
                        <option value="img/PIE DE CORREO UNIPLAZA.jpg">UNIPLAZA</option>
                        <option value="img/PIE DE CORREO UNIPLAZA UNIMALL.jpg">UNIPLAZA-UNIMALL</option>
                        <option value="img/PIE DE CORREO VESTIMODA.jpg">VESTIMODA</option>
                        <option value="img/PIE CORPORATIVO.jpg">CORPORATIVO</option>
                        <option value="img/PIE DE CORREO NICARAGUA.jpg">NICARAGUA</option>
                        <option value="img/PIE DE CORREO APROBADO.jpg">APROBADO</option>
                    </select>
                </div>

                <div class="full-width">
                    <label for="nombre">Nombre Completo *</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Ejemplo: Maria Flores" maxlength="50" pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$" required title="Solo se permiten letras y espacios">
                </div>

                <div class="full-width">
                    <label for="cargo">Puesto / Cargo *</label>
                    <input type="text" id="cargo" name="cargo" placeholder="Ejemplo: Gerente de Tienda" maxlength="70" pattern="^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$" required title="Solo se permiten letras y espacios">
                </div>

                <div>
                    <label for="codigo">Código País *</label>
                    <select id="codigo">
                        <option value="504">Honduras (+504)</option>
                        <option value="505">Nicaragua (+505)</option>
                    </select>
                </div>

                <div>
                    <label for="telefono2">Teléfono Móvil *</label>
                    <input type="text" id="telefono2" name="telefono2" placeholder="Número" maxlength="17" required title="Formato válido: +504 9904-9265 o +505 8888-1234">
                </div>

                <div class="full-width">
                    <label for="direccion">Dirección Física</label>
                    <input type="text" id="direccion" name="direccion" placeholder="Ejemplo: Km. 1 Carretera a Valle de Ángeles, Edificio Vestimoda" maxlength="100" oninput="this.value = this.value.replace(/[^a-zA-Z0-9,.;\sáéíóúÁÉÍÓÚñÑ]/g, '')">
                </div>
            </div>

            <div class="actions-group">
                <button class="btn-action btn-ghost" onclick="generarFirma()">Vista Previa</button>
                <button class="btn-action btn-fill" onclick="descargarFirma()">Descargar Firma</button>
            </div>

            <div class="preview-box">
                <canvas id="firmaCanvas" width="1546" height="768" style="display: none;"></canvas>
            </div>
        </div>
    </div>

    <script>
    function cargarPlantilla() {
        generarFirma();
    }

    function generarFirma() {
        const empresaVal = document.getElementById("empresa").value;
        if (!empresaVal) return;

        const canvas = document.getElementById("firmaCanvas");
        const ctx = canvas.getContext("2d");
        const plantilla = new Image();
        plantilla.src = empresaVal;

        canvas.style.display = "inline-block";

        plantilla.onload = function () {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(plantilla, 0, 0, canvas.width, canvas.height);

            ctx.font = "bold 45px Arial";
            ctx.fillStyle = "#FFFFFF";
            ctx.fillText(document.getElementById("nombre").value, 140, 520);

            ctx.font = "30px Arial";
            ctx.fillStyle = "#FFFFFF";
            ctx.fillText(document.getElementById("cargo").value, 145, 570);

            ctx.font = "26px Arial";
            ctx.fillStyle = "#000000";
            ctx.fillText(document.getElementById("telefono2").value, 1080, 210);
            ctx.fillText("+504 2236-7488", 1080, 135);
            ctx.fillText("www.grupomcc.com", 1080, 280);

            wrapText(
                ctx,
                document.getElementById("direccion").value || "KM1, Carretera Valle de Ángeles, Tegucigalpa, D.C.",
                1080, 350, 420, 26
            );

            dibujarIconos(ctx, () => {
                dibujarLogos(ctx, obtenerLogosPorEmpresa());
            });
        };
    }

    function dibujarIconos(ctx, callback) {
        const iconSize = 30;
        const iconX = 1020;
        const iconY = [135, 185, 255, 325];
        const icons = ["img/phone.png", "img/mobile.png", "img/web.png", "img/location.png"];
        let loaded = 0;

        icons.forEach((src, i) => {
            const icon = new Image();
            icon.src = src;
            icon.onload = () => {
                ctx.drawImage(icon, iconX, iconY[i], iconSize, iconSize);
                loaded++;
                if (loaded === icons.length) callback();
            };
        });
    }

    function obtenerLogosPorEmpresa() {
        const empresa = document.getElementById("empresa").value;
        switch (empresa) {
            case "img/mcc.png":
                return [
                    "img/mendels.png", "img/acajoe.png", "img/vestimoda.png", "img/detodo.png",
                    "img/uniplaza.png", "img/unimall.png", "img/chesters.png", "img/credito_mendels.png",
                    "img/corporativo.png", "img/aprobado.png", "img/nicaragua.png", "img/uniplaza_unimall.png"
                ];
            default:
                return [
                    "img/mendels.png", "img/acajoe.png", "img/vestimoda.png", "img/detodo.png",
                    "img/uniplaza.png", "img/chesters", "img/unimall.png", "img/uniplaza_unimall.png",
                    "img/credito_mendels.png", "img/corporativo.png", "img/nicaragua.png"
                ];
        }
    }

    function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
        const words = text.split(' ');
        let line = '';

        for (let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            const testWidth = ctx.measureText(testLine).width;

            if (testWidth > maxWidth && n > 0) {
                ctx.fillText(line, x, y);
                line = words[n] + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        ctx.fillText(line, x, y);
    }

    function descargarFirma() {
        const nombre = document.getElementById('nombre').value.trim();
        const cargo = document.getElementById('cargo').value.trim();
        const telefono = document.getElementById('telefono2').value.trim();

        if (!nombre || !cargo || !telefono) {
            alert("Por favor, complete todos los campos obligatorios antes de descargar la firma.");
            return;
        }

        if (!telefono.match(/^\+(504|505)\s\d{4}-\d{4}$/)) {
            alert("Por favor, escriba un número de teléfono válido en el formato: +504 9902-9989 o +505 8888-1234");
            return;
        }

        generarFirma();

        setTimeout(() => {
            const canvas = document.getElementById("firmaCanvas");
            const enlace = document.createElement('a');
            enlace.download = 'firma_digital.png';
            enlace.href = canvas.toDataURL("image/png");
            enlace.click();
        }, 1000);
    }

    function soloLetras(input) {
        input.value = input.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
    }

    document.getElementById('nombre').addEventListener('input', function () { soloLetras(this); });
    document.getElementById('cargo').addEventListener('input', function () { soloLetras(this); });

    document.getElementById('telefono2').addEventListener('input', function (e) {
        let valor = e.target.value;
        let numeros = valor.replace(/\D/g, '');

        if (numeros.startsWith("504") || numeros.startsWith("505")) {
            numeros = numeros.substring(3);
        }

        numeros = numeros.substring(0, 8);
        let formateado = '';

        if (numeros.length > 0) {
            formateado = numeros.substring(0, 4);
        }
        if (numeros.length >= 5) {
            formateado += '-' + numeros.substring(4);
        }

        const codigoPais = document.getElementById('codigo').value;
        e.target.value = "+" + codigoPais + " " + formateado;
    });

    document.getElementById('codigo').addEventListener('change', function () {
        document.getElementById('telefono2').value = "+" + this.value + " ";
    });
    </script>
</body>
</html>