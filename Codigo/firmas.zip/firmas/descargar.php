<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['imagen'])) {
    $img = $_POST['imagen'];
    // Limpia el encabezado base64 de la imagen
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);

    // Fuerza la descarga directa como archivo PNG real desde el servidor
    header('Content-Description: File Transfer');
    header('Content-Type: image/png');
    header('Content-Disposition: attachment; filename="firma_digital.png"');
    header('Content-Length: ' . strlen($data));
    echo $data;
    exit;
}
?>
