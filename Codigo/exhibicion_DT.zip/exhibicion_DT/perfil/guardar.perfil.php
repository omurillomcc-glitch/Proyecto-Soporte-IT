<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Iniciar sesión si aún no está iniciada
|--------------------------------------------------------------------------
| Esto permite acceder a $_SESSION sin errores.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/*
|--------------------------------------------------------------------------
| Indicar que la respuesta será JSON
|--------------------------------------------------------------------------
| Este archivo no devuelve HTML, sino una respuesta tipo:
| {"ok":true,"msg":"..."}
|--------------------------------------------------------------------------
*/
header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| Cargar archivos necesarios
|--------------------------------------------------------------------------
| auth.php -> funciones de autenticación como require_login() y me()
| db.php   -> conexión a la base de datos ($conn)
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../controlusuarios/auth.php';
require_once __DIR__ . '/../controlusuarios/db.php';

/*
|--------------------------------------------------------------------------
| Función auxiliar para responder en JSON y terminar el script
|--------------------------------------------------------------------------
| Parámetros:
| - $ok: true o false
| - $msg: mensaje principal
| - $extra: datos adicionales opcionales
|--------------------------------------------------------------------------
*/
function json_response(bool $ok, string $msg, array $extra = []): never
{
    echo json_encode(array_merge([
        'ok'  => $ok,
        'msg' => $msg
    ], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    /*
    |--------------------------------------------------------------------------
    | Validar que el usuario haya iniciado sesión
    |--------------------------------------------------------------------------
    */
    require_login();

    /*
    |--------------------------------------------------------------------------
    | Obtener datos del usuario autenticado desde la sesión
    |--------------------------------------------------------------------------
    | Ejemplo:
    | $me['id'], $me['usuario'], $me['rol'], etc.
    |--------------------------------------------------------------------------
    */
    $me = me();

    /*
    |--------------------------------------------------------------------------
    | Verificar que exista conexión a la base de datos
    |--------------------------------------------------------------------------
    */
    if (!isset($conn) || !($conn instanceof mysqli)) {
        json_response(false, 'No hay conexión a la base de datos.');
    }

    /*
    |--------------------------------------------------------------------------
    | Este archivo solo acepta peticiones POST
    |--------------------------------------------------------------------------
    | Si alguien abre este archivo directamente en el navegador, sería GET.
    |--------------------------------------------------------------------------
    */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        json_response(false, 'Método no permitido.');
    }

    /*
    |--------------------------------------------------------------------------
    | Obtener datos necesarios
    |--------------------------------------------------------------------------
    | $id      -> id del usuario autenticado
    | $rol     -> rol del usuario autenticado
    | $usuario -> nuevo usuario enviado por el formulario
    | $pass    -> nueva contraseña enviada por el formulario
    |--------------------------------------------------------------------------
    */
    $id      = (int)($me['id'] ?? 0);
    $rol     = (string)($me['rol'] ?? '');
    $usuario = trim((string)($_POST['usuario'] ?? ''));
    $pass    = trim((string)($_POST['pass'] ?? ''));

    /*
    |--------------------------------------------------------------------------
    | Validar que el id de sesión sea válido
    |--------------------------------------------------------------------------
    */
    if ($id <= 0) {
        json_response(false, 'Sesión inválida.');
    }

    /*
    |--------------------------------------------------------------------------
    | Validar permisos
    |--------------------------------------------------------------------------
    | Solo super_admin y admin_zona pueden editar su perfil.
    | El rol tienda no puede editar.
    |--------------------------------------------------------------------------
    */
    if (!in_array($rol, ['super_admin'], true)) {
        json_response(false, 'No tienes permisos para editar el perfil.');
    }

    /*
    |--------------------------------------------------------------------------
    | Validar que el usuario no venga vacío
    |--------------------------------------------------------------------------
    */
    if ($usuario === '') {
        json_response(false, 'Debes ingresar el usuario.');
    }

    /*
    |--------------------------------------------------------------------------
    | Validar formato del nombre de usuario
    |--------------------------------------------------------------------------
    | Solo letras y espacios, entre 3 y 30 caracteres.
    |--------------------------------------------------------------------------
    */
    if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]{3,30}$/u', $usuario)) {
        json_response(false, 'El usuario solo debe contener letras y espacios.');
    }

    /*
    |--------------------------------------------------------------------------
    | Validar formato de la contraseña
    |--------------------------------------------------------------------------
    | Solo si el usuario escribió una nueva contraseña.
    | Se permiten letras, números y punto, de 4 a 30 caracteres.
    |--------------------------------------------------------------------------
    */
    if ($pass !== '' && !preg_match('/^[A-Za-z0-9.]{6,20}$/', $pass)) {
    json_response(false, 'La contraseña debe tener entre 6 y 20 caracteres, solo letras, números y punto.');
}

    /*
    |--------------------------------------------------------------------------
    | Definir nombres de tabla y columnas
    |--------------------------------------------------------------------------
    | Esto ayuda a tener más claridad si luego cambias nombres.
    |--------------------------------------------------------------------------
    */
    $tabla      = 'usuarios';
    $colId      = 'id';
    $colUsuario = 'usuario';
    $colPass    = 'password_hash';

    /*
    |--------------------------------------------------------------------------
    | Verificar si el nuevo nombre de usuario ya existe en otro registro
    |--------------------------------------------------------------------------
    | Se excluye el usuario actual con:
    | AND id <> ?
    |--------------------------------------------------------------------------
    */
    $sqlCheck = "SELECT {$colId} FROM {$tabla} WHERE {$colUsuario} = ? AND {$colId} <> ? LIMIT 1";
    $stmtCheck = $conn->prepare($sqlCheck);

    /*
    |--------------------------------------------------------------------------
    | Si falla el prepare, devolver error
    |--------------------------------------------------------------------------
    */
    if (!$stmtCheck) {
        json_response(false, 'Error al preparar validación.', [
            'mysql_error' => $conn->error
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Ejecutar validación del usuario repetido
    |--------------------------------------------------------------------------
    */
    $stmtCheck->bind_param('si', $usuario, $id);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    /*
    |--------------------------------------------------------------------------
    | Si ya existe otro usuario con ese nombre, detener proceso
    |--------------------------------------------------------------------------
    */
    if ($resCheck && $resCheck->num_rows > 0) {
        $stmtCheck->close();
        json_response(false, 'Ese nombre de usuario ya está en uso.');
    }

    /*
    |--------------------------------------------------------------------------
    | Cerrar statement de validación
    |--------------------------------------------------------------------------
    */
    $stmtCheck->close();

    /*
    |--------------------------------------------------------------------------
    | Si se escribió una nueva contraseña
    |--------------------------------------------------------------------------
    | 1. Se encripta con password_hash()
    | 2. Se actualiza usuario + contraseña
    |--------------------------------------------------------------------------
    */
    if ($pass !== '') {
        $hash = password_hash($pass, PASSWORD_BCRYPT);

        $sql = "UPDATE {$tabla} SET {$colUsuario} = ?, {$colPass} = ? WHERE {$colId} = ? LIMIT 1";
        $stmt = $conn->prepare($sql);

        /*
        |--------------------------------------------------------------------------
        | Verificar que prepare no falle
        |--------------------------------------------------------------------------
        */
        if (!$stmt) {
            json_response(false, 'Error al preparar actualización con contraseña.', [
                'mysql_error' => $conn->error
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Enlazar parámetros:
        | s -> string (usuario)
        | s -> string (hash)
        | i -> integer (id)
        |--------------------------------------------------------------------------
        */
        $stmt->bind_param('ssi', $usuario, $hash, $id);

    } else {
        /*
        |--------------------------------------------------------------------------
        | Si NO escribió nueva contraseña
        |--------------------------------------------------------------------------
        | Solo se actualiza el usuario.
        |--------------------------------------------------------------------------
        */
        $sql = "UPDATE {$tabla} SET {$colUsuario} = ? WHERE {$colId} = ? LIMIT 1";
        $stmt = $conn->prepare($sql);

        /*
        |--------------------------------------------------------------------------
        | Verificar que prepare no falle
        |--------------------------------------------------------------------------
        */
        if (!$stmt) {
            json_response(false, 'Error al preparar actualización de usuario.', [
                'mysql_error' => $conn->error
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Enlazar parámetros:
        | s -> string (usuario)
        | i -> integer (id)
        |--------------------------------------------------------------------------
        */
        $stmt->bind_param('si', $usuario, $id);
    }

    /*
    |--------------------------------------------------------------------------
    | Ejecutar la actualización
    |--------------------------------------------------------------------------
    */
    if (!$stmt->execute()) {
        $stmtError = $stmt->error;
        $stmt->close();

        json_response(false, 'No se pudo actualizar el perfil.', [
            'stmt_error' => $stmtError
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Cerrar statement después de ejecutar
    |--------------------------------------------------------------------------
    */
    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | Actualizar el usuario en la sesión
    |--------------------------------------------------------------------------
    | Esto hace que el nuevo nombre se refleje sin cerrar sesión.
    |--------------------------------------------------------------------------
    */
    $_SESSION['usuario'] = $usuario;

    /*
    |--------------------------------------------------------------------------
    | Respuesta exitosa
    |--------------------------------------------------------------------------
    */
    json_response(true, 'Perfil actualizado correctamente.');

} catch (Throwable $e) {
    /*
    |--------------------------------------------------------------------------
    | Captura de error general
    |--------------------------------------------------------------------------
    | Si ocurre una excepción o error inesperado, responder en JSON.
    |--------------------------------------------------------------------------
    */
    json_response(false, 'Error interno del servidor.', [
        'error' => $e->getMessage(),
        'line'  => $e->getLine(),
        'file'  => basename($e->getFile())
    ]);
}