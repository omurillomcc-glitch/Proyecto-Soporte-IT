<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PERFIL.PHP
|--------------------------------------------------------------------------
| Vista de perfil del usuario autenticado.
| - super_admin y admin_zona pueden editar usuario y contraseña
| - tienda solo visualiza la información
|--------------------------------------------------------------------------
*/

/* Cargar autenticación y conexión */
require_once __DIR__ . '/../controlusuarios/auth.php';
require_once __DIR__ . '/../controlusuarios/db.php';

/*
|--------------------------------------------------------------------------
| Función para escapar texto en HTML
|--------------------------------------------------------------------------
*/
function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Validar que el usuario haya iniciado sesión */
require_login();

/* Obtener datos del usuario autenticado */
$me = me();

/*
|--------------------------------------------------------------------------
| Datos principales del usuario
|--------------------------------------------------------------------------
*/
$rol = (string)($me['rol'] ?? '');
$puedeEditar = in_array($rol, ['super_admin'], true);

$usuario = (string)($me['usuario'] ?? '-');
$pais    = trim((string)($me['pais'] ?? '')) !== '' ? (string)$me['pais'] : (string)($me['pais_code'] ?? 'No aplica');
$zona    = trim((string)($me['zona'] ?? '')) !== '' ? (string)$me['zona'] : 'No aplica';
$tienda  = trim((string)($me['tienda'] ?? '')) !== '' ? (string)$me['tienda'] : 'No aplica';
$estado  = ((int)($me['estado'] ?? 0) === 1) ? 'Activo' : 'Bloqueado';

/*
|--------------------------------------------------------------------------
| Nombre bonito del rol
|--------------------------------------------------------------------------
*/
$nombreRol = match ($rol) {
    'super_admin' => 'Super administrador',
    'admin_zona'  => 'Administrador de zona',
    'tienda'      => 'Tienda',
    default       => ucfirst($rol ?: 'Usuario'),
};

/*
|--------------------------------------------------------------------------
| URL del backend para guardar el perfil
|--------------------------------------------------------------------------

|--------------------------------------------------------------------------
*/
$baseUrl = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$urlGuardarPerfil = $baseUrl . '/perfil/guardar.perfil.php';

/*
|--------------------------------------------------------------------------
| Inicial del usuario para avatar de respaldo
|--------------------------------------------------------------------------
*/
$inicialUsuario = strtoupper(mb_substr(trim($usuario) !== '' ? $usuario : 'U', 0, 1, 'UTF-8'));
?>

<div class="perfil-v2">
    <!-- Contenedor general -->
    <div class="perfil-v2-shell">

        <!-- Encabezado superior -->
        <div class="perfil-v2-header">
            <div class="perfil-v2-title-block">
                <span class="perfil-v2-kicker"></span>
                <h1></h1>
                <p>
                  
                </p>
            </div>
        </div>

        <!-- Mensajes de éxito o error -->
        <div id="msgPerfil" class="perfil-v2-msg"></div>

        <!-- Estructura principal: sidebar + contenido -->
        <div class="perfil-v2-main">

            <!-- Panel izquierdo -->
            <aside class="perfil-v2-sidebar">

                <!-- Avatar -->
                <div class="perfil-v2-avatar-wrap">
                    <div class="perfil-v2-avatar-outer">
                        <div class="perfil-v2-avatar-inner avatar-con-imagen">
                            <img
                                src="/exhibicion_DT/img/avatart.webp"
                                alt="Avatar del usuario"
                                class="perfil-v2-avatar-img"
                                onerror="this.style.display='none'; this.parentNode.classList.remove('avatar-con-imagen'); this.parentNode.innerHTML='<?= e($inicialUsuario) ?>';"
                            >
                        </div>
                    </div>
                </div>

                <!-- Nombre y rol -->
                <div class="perfil-v2-userbox">
                    
                </div>

                <!-- Resumen -->
                <div class="perfil-v2-summary">
                    <h4>Resumen</h4>

                    <p>
                        Este panel concentra la información principal de tu cuenta dentro del sistema.
                    </p>

                    <?php if ($puedeEditar): ?>
                        <p>
                            Puedes cambiar tu usuario y contraseña desde esta sección.
                        </p>
                    <?php else: ?>
                        <p>
                            Tu cuenta es de solo consulta para edición de credenciales.
                        </p>
                    <?php endif; ?>
                </div>
            </aside>

            <!-- Panel derecho -->
            <section class="perfil-v2-content">

                <!-- Sección de información general -->
                <div class="perfil-v2-section">
                    <div class="perfil-v2-section-head">
                        <h2>Información general</h2>
                    </div>

                    <!-- Tarjetas de información -->
                    <div class="perfil-v2-info-grid">
                        <div class="perfil-v2-info-card">
                            <span class="label">Usuario</span>
                            <span class="value"><?= e($usuario) ?></span>
                        </div>

                        <div class="perfil-v2-info-card">
                            <span class="label">Rol</span>
                            <span class="value"><?= e($nombreRol) ?></span>
                        </div>

                        <div class="perfil-v2-info-card">
                            <span class="label">País</span>
                            <span class="value"><?= e($pais) ?></span>
                        </div>

                        <div class="perfil-v2-info-card">
                            <span class="label">Zona</span>
                            <span class="value"><?= e($zona) ?></span>
                        </div>

                        <div class="perfil-v2-info-card">
                            <span class="label">Tienda</span>
                            <span class="value"><?= e($tienda) ?></span>
                        </div>

                        <div class="perfil-v2-info-card">
                            <span class="label">Estado</span>
                            <span class="value <?= $estado === 'Activo' ? 'is-ok' : 'is-off' ?>">
                                <?= e($estado) ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Sección de seguridad -->
                <div class="perfil-v2-section">
                    <div class="perfil-v2-section-head">
                        <h2>Seguridad y acceso</h2>
                    </div>

                    <?php if ($puedeEditar): ?>
                        <!-- Formulario para editar usuario y contraseña -->
                        <form id="formPerfil" class="perfil-v2-form" autocomplete="off">

                            <div class="perfil-v2-form-grid">
                                <!-- Campo usuario -->
                                <div class="perfil-v2-field">
                                    <label for="p_usuario">Usuario</label>
                                    <input
                                        type="text"
                                        class="form-control perfil-v2-input"
                                        name="usuario"
                                        id="p_usuario"
                                        value="<?= e($usuario) ?>"
                                        maxlength="30"
                                        required
                                    >
                                </div>

                                <!-- Campo contraseña -->
                                <div class="perfil-v2-field">
                                    <label for="p_pass">Nueva contraseña</label>

                                    <div class="perfil-v2-pass-wrap">
                                        <input
                                            type="password"
                                            class="form-control perfil-v2-input"
                                            name="pass"
                                            id="p_pass"
                                            maxlength="30"
                                            placeholder="Opcional"
                                        >

                                        <!-- Botón mostrar/ocultar -->
                                        <button
                                            type="button"
                                            id="togglePass"
                                            class="perfil-v2-eye"
                                            aria-label="Mostrar contraseña"
                                        >
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Botón guardar -->
                            <div class="perfil-v2-actions">
                                <button
                                    type="button"
                                    id="btnGuardarPerfil"
                                    class="btn perfil-v2-save"
                                    onclick="guardarPerfil(event)"
                                    title="Guardar cambios"
                                    aria-label="Guardar cambios"
                                >
                                    <i class="bi bi-floppy-fill"></i>
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <!-- Mensaje para usuarios sin permisos -->
                        <div class="perfil-v2-readonly">
                            Esta cuenta no tiene permisos para modificar usuario o contraseña.
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
</div>

<script>
/*
|--------------------------------------------------------------------------
| Comportamiento visual de campos
|--------------------------------------------------------------------------
| - Usuario: solo letras y espacios
| - Contraseña: solo letras, números y punto
| - Mostrar/ocultar contraseña
|--------------------------------------------------------------------------
*/
(function () {
    const inputUsuario = document.getElementById('p_usuario');
    const inputPass = document.getElementById('p_pass');
    const togglePass = document.getElementById('togglePass');

    if (inputUsuario) {
        inputUsuario.addEventListener('input', function () {
            this.value = this.value
                .replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]/g, '')
                .replace(/\s{2,}/g, ' ')
                .replace(/^\s+/, '')
                .slice(0, 30);
        });
    }

    if (inputPass) {
        inputPass.addEventListener('input', function () {
            this.value = this.value
                .replace(/[^A-Za-z0-9.]/g, '')
                .slice(0, 30);
        });
    }

    if (togglePass && inputPass) {
        togglePass.addEventListener('click', function () {
            const isPassword = inputPass.type === 'password';
            inputPass.type = isPassword ? 'text' : 'password';
            this.innerHTML = isPassword
                ? '<i class="bi bi-eye-slash"></i>'
                : '<i class="bi bi-eye"></i>';
        });
    }
})();

/*
|--------------------------------------------------------------------------
| URL del archivo backend que guarda cambios
|--------------------------------------------------------------------------
*/
const URL_GUARDAR_PERFIL = <?= json_encode($urlGuardarPerfil, JSON_UNESCAPED_SLASHES) ?>;

/*
|--------------------------------------------------------------------------
| Función para guardar perfil con AJAX
|--------------------------------------------------------------------------
*/
async function guardarPerfil(event) {
    if (event) event.preventDefault();

    const box = document.getElementById('msgPerfil');
    const form = document.getElementById('formPerfil');
    const btn = document.getElementById('btnGuardarPerfil');

    if (!form || !btn || !box) return;

    const usuario = document.getElementById('p_usuario').value.trim();
    const pass = document.getElementById('p_pass').value.trim();

    box.innerHTML = '';

    /* Validaciones básicas */
    if (!usuario) {
        box.innerHTML = '<div class="alert alert-danger">Debes ingresar el usuario.</div>';
        return;
    }

    if (!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]{3,30}$/u.test(usuario)) {
        box.innerHTML = '<div class="alert alert-danger">Usuario inválido.</div>';
        return;
    }

    if (pass !== '' && !/^[A-Za-z0-9.]{4,30}$/.test(pass)) {
        box.innerHTML = '<div class="alert alert-danger">Contraseña inválida.</div>';
        return;
    }

    const fd = new FormData(form);
    const originalHTML = btn.innerHTML;

    btn.disabled = true;
    btn.innerHTML = '<i class="bi bi-hourglass-split"></i>';

    try {
        const res = await fetch(URL_GUARDAR_PERFIL, {
            method: 'POST',
            body: fd
        });

        const text = await res.text();
        let data;

        try {
            data = JSON.parse(text);
        } catch (e) {
            box.innerHTML = `<div class="alert alert-danger">Respuesta inválida del servidor.<br><small>${text}</small></div>`;
            return;
        }

        box.innerHTML = `<div class="alert alert-${data.ok ? 'success' : 'danger'}">${data.msg}</div>`;

        if (data.ok) {
            setTimeout(() => location.reload(), 900);
        }
    } catch (error) {
        box.innerHTML = '<div class="alert alert-danger">Error de conexión con el servidor.</div>';
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    }
}
</script>

<style>
/*
|--------------------------------------------------------------------------
| Fondo general
|--------------------------------------------------------------------------
*/
.perfil-v2{
    background:#ffffff;
    padding:0;

}

/*
|--------------------------------------------------------------------------
| Tarjeta principal

|--------------------------------------------------------------------------
*/
.perfil-v2-shell{
    max-width:1120px;
    margin:0 auto;
    background:#ffffff;
    border:none;
    border-radius:24px;
    padding:12px 28px 28px;
}
/*
|--------------------------------------------------------------------------
| Encabezado
|--------------------------------------------------------------------------
*/

.perfil-v2-header{
    margin-bottom:8px;
}
.perfil-v2-kicker{
    display:inline-block;
    font-size:.78rem;
    font-weight:700;
    letter-spacing:.08em;
    text-transform:uppercase;
    color:#2563eb;
    margin-bottom:6px;
}

.perfil-v2-title-block h1{
    margin:0;
    font-size:2.1rem;
    line-height:1.1;
    color:#0f172a;
    font-weight:700;
}

.perfil-v2-title-block p{
    margin:8px 0 0;
    font-size:.94rem;
    color:#64748b;
    max-width:620px;
    line-height:1.65;
}

/*
|--------------------------------------------------------------------------
| Mensajes
|--------------------------------------------------------------------------
*/
.perfil-v2-msg{
    max-width:460px;
    margin:0 0 16px;
}

/*
|--------------------------------------------------------------------------
| Layout principal
|--------------------------------------------------------------------------
*/
.perfil-v2-main{
    display:grid;
    grid-template-columns:280px 1fr;
    gap:24px;
}

/*
|--------------------------------------------------------------------------
| Sidebar
|--------------------------------------------------------------------------
*/
.perfil-v2-sidebar{
    background:#ffffff;
    border:1px solid #e5e7eb;
    border-radius:20px;
    padding:22px 18px;
}

/*
|--------------------------------------------------------------------------
| Avatar
|--------------------------------------------------------------------------
*/
.perfil-v2-avatar-wrap{
    display:flex;
    justify-content:center;
    margin-bottom:16px;
}

.perfil-v2-avatar-outer{
    width:128px;
    height:128px;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
}

.perfil-v2-avatar-inner{
    width:96px;
    height:96px;
    border-radius:50%;
    color:#ffffff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:2rem;
    font-weight:700;
}

/* Avatar con imagen */
.avatar-con-imagen{
    background:#ffffff;
    overflow:hidden;
    padding:0;
}

.perfil-v2-avatar-img{
    width:100%;
    height:100%;
    object-fit:cover;
    display:block;
    border-radius:50%;
}

/*
|--------------------------------------------------------------------------
| Caja de usuario
|--------------------------------------------------------------------------
*/
.perfil-v2-userbox{
    text-align:center;
    margin-bottom:18px;
}

.perfil-v2-userbox h3{
    margin:0;
    font-size:1.1rem;
    font-weight:700;
    color:#0f172a;
}

.perfil-v2-userbox p{
    margin:4px 0 0;
    font-size:.9rem;
    color:#64748b;
}

/*
|--------------------------------------------------------------------------
| Resumen
|--------------------------------------------------------------------------
*/
.perfil-v2-summary h4{
    margin:0 0 10px;
    font-size:.9rem;
    font-weight:700;
    color:#0f172a;
}

.perfil-v2-summary p{
    margin:0 0 10px;
    font-size:.9rem;
    line-height:1.7;
    color:#475569;
}

/*
|--------------------------------------------------------------------------
| Sección de contenido
|--------------------------------------------------------------------------
*/
.perfil-v2-content{
    display:grid;
    gap:18px;
}

.perfil-v2-section{
    background:#ffffff;
    border:1px solid #e5e7eb;
    border-radius:20px;
    padding:20px;
}

.perfil-v2-section-head{
    margin-bottom:14px;
}

.perfil-v2-section-head h2{
    margin:0;
    font-size:1rem;
    font-weight:700;
    color:#0f172a;
}

/*
|--------------------------------------------------------------------------
| Tarjetas de información
|--------------------------------------------------------------------------
*/
.perfil-v2-info-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:12px 14px;
}

.perfil-v2-info-card{
    background:#ffffff;
    border:1px solid #e5e7eb;
    border-radius:16px;
    padding:12px 14px;
}

.perfil-v2-info-card .label{
    display:block;
    font-size:.8rem;
    font-weight:700;
    color:#0f172a;
    margin-bottom:4px;
}

.perfil-v2-info-card .value{
    display:block;
    font-size:.9rem;
    color:#475569;
    line-height:1.5;
}

.perfil-v2-info-card .value.is-ok{
    color:#15803d;
    font-weight:700;
}

.perfil-v2-info-card .value.is-off{
    color:#b91c1c;
    font-weight:700;
}

/*
|--------------------------------------------------------------------------
| Formulario
|--------------------------------------------------------------------------
*/
.perfil-v2-form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:14px;
}

.perfil-v2-field label{
    display:block;
    margin-bottom:6px;
    font-size:.84rem;
    font-weight:700;
    color:#0f172a;
}

.perfil-v2-input{
    min-height:38px;
    padding:7px 11px;
    font-size:.9rem;
    border:1px solid #d1d5db;
    border-radius:12px;
    box-shadow:none;
}

.perfil-v2-input:focus{
    border-color:#94a3b8;
    box-shadow:none;
}

/*
|--------------------------------------------------------------------------
| Caja de contraseña
|--------------------------------------------------------------------------
*/
.perfil-v2-pass-wrap{
    position:relative;
}

.perfil-v2-pass-wrap .perfil-v2-input{
    padding-right:38px;
}

.perfil-v2-eye{
    position:absolute;
    top:50%;
    right:8px;
    transform:translateY(-50%);
    width:24px;
    height:24px;
    border:none;
    background:transparent;
    color:#64748b;
    padding:0;
}

/*
|--------------------------------------------------------------------------
| Acciones
|--------------------------------------------------------------------------
*/
.perfil-v2-actions{
    margin-top:14px;
}

.perfil-v2-save{
    width:44px;
    height:44px;
    border:none;
    border-radius:14px;
    background:#2563eb;
    color:#ffffff;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:0;
}

.perfil-v2-save i{
    font-size:1rem;
}

/*
|--------------------------------------------------------------------------
| Solo lectura
|--------------------------------------------------------------------------
*/
.perfil-v2-readonly{
    font-size:.9rem;
    color:#475569;
    font-weight:600;
}

/*
|--------------------------------------------------------------------------
| Alertas
|--------------------------------------------------------------------------
*/
.alert{
    border-radius:10px;
    font-size:.86rem;
}

/*
|--------------------------------------------------------------------------
| Responsive
|--------------------------------------------------------------------------
*/
@media (max-width: 991px){
    .perfil-v2-shell{
        padding:18px;
    }

    .perfil-v2-main{
        grid-template-columns:1fr;
    }

    .perfil-v2-sidebar{
        order:1;
    }

    .perfil-v2-content{
        order:2;
    }

    .perfil-v2-info-grid,
    .perfil-v2-form-grid{
        grid-template-columns:1fr;
    }
}
</style>