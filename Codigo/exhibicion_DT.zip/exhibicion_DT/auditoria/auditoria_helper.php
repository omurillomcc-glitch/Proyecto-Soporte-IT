<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| 1) INICIAR SESIÓN
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/*
|--------------------------------------------------------------------------
| 2) CARGAR ARCHIVOS
|--------------------------------------------------------------------------
*/
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/*
|--------------------------------------------------------------------------
| 3) OBTENER IP
|--------------------------------------------------------------------------
*/
function auditoria_ip(): string
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';

    if (str_contains($ip, ',')) {
        $parts = explode(',', $ip);
        $ip = trim($parts[0]);
    }

    return trim((string)$ip);
}

/*
|--------------------------------------------------------------------------
| 4) NORMALIZAR REGIÓN
|--------------------------------------------------------------------------
*/
function auditoria_region_label(string $valor): string
{
    $valor = strtoupper(trim($valor));

    return match ($valor) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $valor,
    };
}

/*
|--------------------------------------------------------------------------
| 5) REGISTRAR AUDITORÍA
|--------------------------------------------------------------------------
*/
function registrar_auditoria(
    string $modulo,
    string $accion,
    string $descripcion = '',
    ?string $region = null,
    ?string $zona = null,
    ?string $tienda = null,
    ?string $codalmacen = null
): bool {
    global $conn;

    /*
    |--------------------------------------------------------------------------
    | PASO 1: VALIDAR CONEXIÓN MYSQL
    |--------------------------------------------------------------------------
    */
    if (!isset($conn) || !($conn instanceof mysqli)) {
        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 2: OBTENER USUARIO LOGUEADO
    |--------------------------------------------------------------------------
    */
    $me = function_exists('me') ? me() : [];

    $usuarioId = (int)($me['id'] ?? ($_SESSION['usuario_id'] ?? 0));
    $usuario   = trim((string)($me['usuario'] ?? ($_SESSION['usuario'] ?? 'Sistema')));
    $rol       = trim((string)($me['rol'] ?? ($_SESSION['rol'] ?? '')));

    /*
    |--------------------------------------------------------------------------
    | PASO 3: OBTENER REGIÓN
    |--------------------------------------------------------------------------
    */
    $regionRaw = trim((string)(
        $region
        ?? ($_SESSION['pais'] ?? '')
        ?: ($_SESSION['pais_code'] ?? '')
        ?: ($me['pais_code'] ?? '')
    ));

    $regionVal = auditoria_region_label($regionRaw);

    /*
    |--------------------------------------------------------------------------
    | PASO 4: OBTENER ZONA
    |--------------------------------------------------------------------------
    */
   $zonaVal = trim((string)(
    $zona
    ?? ($_SESSION['zona'] ?? '')
    ?: ($me['zona'] ?? '')
));
    /*
    |--------------------------------------------------------------------------
    | PASO 5: OBTENER CÓDIGO DE ALMACÉN
    |--------------------------------------------------------------------------
    */
    $almacen = trim((string)(
        $codalmacen
        ?? ($_SESSION['codalmacen'] ?? '')
        ?: ($me['codalmacen'] ?? '')
    ));

    /*
    |--------------------------------------------------------------------------
    | PASO 6: OBTENER TIENDA / NOMBRE TIENDA
    |--------------------------------------------------------------------------
    | Si no viene nombre de tienda, guardamos al menos el código.
    |--------------------------------------------------------------------------
    */
    $tiendaVal = trim((string)(
        $tienda
        ?? ($_SESSION['tienda'] ?? '')
        ?: ($me['tienda'] ?? '')
    ));

    if ($tiendaVal === '') {
        $tiendaVal = $almacen;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7: NORMALIZAR VALORES
    |--------------------------------------------------------------------------
    */
    $regionVal = strtoupper(trim($regionVal));
    $zonaVal   = strtoupper(trim($zonaVal));
    $almacen   = strtoupper(trim($almacen));

    /*
    |--------------------------------------------------------------------------
    | PASO 8: AGREGAR DATOS IMPORTANTES A LA DESCRIPCIÓN
    |--------------------------------------------------------------------------
    */
    if ($regionVal !== '' && stripos($descripcion, 'REGION:') === false) {
        $descripcion .= ' | REGION: ' . $regionVal;
    }

    if ($almacen !== '' && stripos($descripcion, 'CODALMACEN:') === false) {
        $descripcion .= ' | CODALMACEN: ' . $almacen;
    }

    if ($tiendaVal !== '' && stripos($descripcion, 'TIENDA:') === false) {
        $descripcion .= ' | TIENDA: ' . $tiendaVal;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 9: OBTENER IP
    |--------------------------------------------------------------------------
    */
    $ip = auditoria_ip();

    /*
    |--------------------------------------------------------------------------
    | PASO 10: INSERTAR EN AUDITORÍA
    |--------------------------------------------------------------------------
    */
    $sql = "
        INSERT INTO auditoria
        (
            usuario_id,
            usuario,
            rol,
            modulo,
            accion,
            descripcion,
            region,
            zona,
            tienda,
            codalmacen,
            ip
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param(
        'issssssssss',
        $usuarioId,
        $usuario,
        $rol,
        $modulo,
        $accion,
        $descripcion,
        $regionVal,
        $zonaVal,
        $tiendaVal,
        $almacen,
        $ip
    );

    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}