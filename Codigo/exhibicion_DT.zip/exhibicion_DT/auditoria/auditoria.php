<?php
declare(strict_types=1);

/* =========================================================
   PASO 1) INICIAR SESIÓN
   ---------------------------------------------------------
   Si ya está iniciada desde index.php/auth.php, no cambiamos
   el nombre de sesión.
   ========================================================= */
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* =========================================================
   PASO 2) CARGAR ARCHIVOS NECESARIOS
   ========================================================= */
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/* =========================================================
   PASO 3) VALIDAR LOGIN
   ========================================================= */
require_login();
$me = me();

/* =========================================================
   PASO 4) DATOS DEL USUARIO LOGUEADO
   ========================================================= */
$miId   = (int)($me['id'] ?? 0);
$miUser = trim((string)($me['usuario'] ?? ''));
$miRol  = (string)($me['rol'] ?? '');
$miZona = trim((string)($me['zona'] ?? ''));
$miPais = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));

if ($miPais === '') {
    $miPais = 'HN';
}

/* =========================================================
   PASO 5) SOLO SUPER ADMIN PUEDE VER AUDITORÍA
   ========================================================= */
if ($miRol !== 'super_admin' &&$miRol !=='admin_zona') {
    http_response_code(403);
    exit('Acceso denegado.');
}

/* =========================================================
   PASO 6) HELPERS GENERALES
   ========================================================= */
function h_aud(mixed $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function aud_clean_text(string $value): string
{
    return trim($value);
}

/* =========================================================
   PASO 7) CONVERTIR PAÍS A REGIÓN
   ========================================================= */
function aud_region_label_from_pais(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        'HONDURAS' => 'HONDURAS',
        'NICARAGUA' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}

/* =========================================================
   PASO 7.1) NORMALIZAR REGIÓN
   ---------------------------------------------------------
   Esto evita que se mezclen registros por diferencias como:
   - HN / Honduras / HONDURAS
   - NI / Nicaragua / NICARAGUA
   ========================================================= */
function aud_normalizar_region(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $region,
    };
}

/* =========================================================
   PASO 7.2) EXTRAER CAMPOS DESDE DESCRIPCIÓN
   ---------------------------------------------------------
   Algunos registros de auditoría pueden traer REGION, ZONA o CODALMACEN
   dentro de la descripción, especialmente guardados masivos o registros viejos.
   ========================================================= */
function aud_extract_field_from_description(string $descripcion, string $field): string
{
    $descripcion = trim($descripcion);
    $field = preg_quote(trim($field), '/');

    if ($descripcion === '' || $field === '') {
        return '';
    }

    if (preg_match('/' . $field . '\s*:\s*([^|]+)/i', $descripcion, $m)) {
        return trim((string)$m[1]);
    }

    return '';
}

function aud_extract_region_from_description(string $descripcion): string
{
    return aud_normalizar_region(aud_extract_field_from_description($descripcion, 'REGION'));
}

function aud_extract_zona_from_description(string $descripcion): string
{
    return strtoupper(trim(aud_extract_field_from_description($descripcion, 'ZONA')));
}

function aud_extract_codalmacen_from_description(string $descripcion): string
{
    $cod = aud_extract_field_from_description($descripcion, 'CODALMACEN');

    if ($cod === '') {
        $cod = aud_extract_field_from_description($descripcion, 'TIENDA');
    }

    return strtoupper(trim($cod));
}

/* =========================================================
   PASO 8) CREAR LLAVE ÚNICA DE TIENDA
   ---------------------------------------------------------
   NO usamos solo codalmacen porque se mezcla.

   Antes:
   05 = puede ser Ceiba o Las Américas

   Ahora:
   HONDURAS-CEIBA-05
   HONDURAS-LAS AMERICAS-05
   ========================================================= */
function aud_store_key(string $region, string $zona, string $codalmacen): string
{
    $region     = strtoupper(trim($region));
    $zona       = strtoupper(trim($zona));
    $codalmacen = strtoupper(trim($codalmacen));

    return $region . '-' . $zona . '-' . $codalmacen;
}

/* =========================================================
   PASO 8.1) LLAVE SIMPLE POR PAÍS + CÓDIGO
   ---------------------------------------------------------
   Esta llave evita mezclar códigos iguales entre países.
   Ejemplo:
   HONDURAS-05  ≠  NICARAGUA-05
   ========================================================= */
function aud_store_country_key(string $region, string $codalmacen): string
{
    return aud_normalizar_region($region) . '-' . strtoupper(trim($codalmacen));
}

/* =========================================================
   PASO 8.2) VALIDAR TABLA MYSQL
   ========================================================= */
function aud_table_exists(mysqli $conn, string $table): bool
{
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");

    return $res instanceof mysqli_result && $res->num_rows > 0;
}


/* =========================================================
   PASO 9) FORMATEAR DESCRIPCIÓN DE AUDITORÍA
   ========================================================= */
function aud_format_descripcion(string $texto): string
{
    $texto = trim($texto);

    if ($texto === '') {
        return '';
    }

    $partes = array_map('trim', explode('|', $texto));

    $html = '<div class="aud-desc-box">';

    if (!empty($partes[0])) {
        $html .= '<div class="aud-desc-main">' . h_aud($partes[0]) . '</div>';
    }

    if (count($partes) > 1) {
        $html .= '<div class="aud-desc-list">';

        foreach (array_slice($partes, 1) as $parte) {
            if ($parte === '') {
                continue;
            }

            $html .= '<div class="aud-desc-line">' . h_aud($parte) . '</div>';
        }

        $html .= '</div>';
    }

    $html .= '</div>';

    return $html;
}

/* =========================================================
   PASO 10) ALCANCE DE AUDITORÍA
   ---------------------------------------------------------
   super_admin:
   - Ve auditoría de su país.

   admin_zona:
   - Ve SOLO auditoría de sus tiendas asignadas.
   - Las tiendas se toman desde usuario_tienda.
   ========================================================= */
function aud_build_scope_sql(
    mysqli $conn,
    int $miId,
    string $miRol,
    string $miPais,
    string $miZona,
    string $miUser
): array {
    $where  = [];
    $params = [];
    $types  = '';

    /*
    |--------------------------------------------------------------------------
    | PASO 10.1: NORMALIZAR ROL Y REGIÓN
    |--------------------------------------------------------------------------
    */
    $miRol = strtolower(trim($miRol));

    $regionLabel = aud_region_label_from_pais($miPais);
    $regionLabel = aud_normalizar_region($regionLabel);

    /*
    |--------------------------------------------------------------------------
    | PASO 10.2: SI NO ES SUPER_ADMIN NI ADMIN_ZONA, NO VE NADA
    |--------------------------------------------------------------------------
    */
    if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 10.3: VALIDAR REGIÓN
    |--------------------------------------------------------------------------
    */
    if ($regionLabel === '') {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 10.4: FILTRO BASE POR PAÍS / REGIÓN
    |--------------------------------------------------------------------------
    | Esto evita mezclar Honduras con Nicaragua.
    |--------------------------------------------------------------------------
    */
    $where[] = "(
        UPPER(TRIM(COALESCE(a.region, ''))) = ?
        OR (
            TRIM(COALESCE(a.region, '')) = ''
            AND UPPER(COALESCE(a.descripcion, '')) LIKE ?
        )
    )";

    $params[] = $regionLabel;
    $params[] = '%REGION: ' . $regionLabel . '%';
    $types   .= 'ss';

    /*
    |--------------------------------------------------------------------------
    | PASO 10.5: SUPER ADMIN
    |--------------------------------------------------------------------------
    | El super_admin ve todo lo de su país.
    |--------------------------------------------------------------------------
    */
    if ($miRol === 'super_admin') {
        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 10.6: ADMIN_ZONA
    |--------------------------------------------------------------------------
    | Buscar las tiendas asignadas al admin_zona.
    |--------------------------------------------------------------------------
    */
    $codigosTiendas = [];

    $sqlTiendas = "
        SELECT DISTINCT
            TRIM(COALESCE(codalmacen, '')) AS codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND TRIM(COALESCE(codalmacen, '')) <> ''
          AND (
                UPPER(TRIM(COALESCE(pais, ''))) = ?
                OR UPPER(TRIM(COALESCE(pais, ''))) = ?
          )
    ";

    $stmtTiendas = $conn->prepare($sqlTiendas);

    if (!$stmtTiendas) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    $paisCorto = strtoupper(trim($miPais));

    $stmtTiendas->bind_param(
        'iss',
        $miId,
        $paisCorto,
        $regionLabel
    );

    $stmtTiendas->execute();
    $resTiendas = $stmtTiendas->get_result();

    if ($resTiendas) {
        while ($t = $resTiendas->fetch_assoc()) {
            $cod = strtoupper(trim((string)($t['codalmacen'] ?? '')));

            if ($cod !== '') {
                $codigosTiendas[] = $cod;
            }
        }
    }

    $stmtTiendas->close();

    /*
    |--------------------------------------------------------------------------
    | PASO 10.7: SI ADMIN_ZONA NO TIENE TIENDAS, NO VE NADA
    |--------------------------------------------------------------------------
    */
    $codigosTiendas = array_values(array_unique($codigosTiendas));

    if (empty($codigosTiendas)) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 10.8: FILTRAR AUDITORÍA POR SUS TIENDAS ASIGNADAS
    |--------------------------------------------------------------------------
    | Caso moderno:
    | - a.codalmacen tiene dato.
    |
    | Caso viejo:
    | - a.codalmacen está vacío.
    | - busca CODALMACEN o TIENDA dentro de descripción.
    |--------------------------------------------------------------------------
    */
    $placeholders = implode(',', array_fill(0, count($codigosTiendas), '?'));

    $whereTienda = "(
        UPPER(TRIM(COALESCE(a.codalmacen, ''))) IN ($placeholders)
        OR (
            TRIM(COALESCE(a.codalmacen, '')) = ''
            AND (
    ";

    /*
    |--------------------------------------------------------------------------
    | Primero se agregan los parámetros del IN (...)
    |--------------------------------------------------------------------------
    */
    foreach ($codigosTiendas as $cod) {
        $params[] = $cod;
        $types   .= 's';
    }

    /*
    |--------------------------------------------------------------------------
    | Luego se agregan las condiciones para buscar en descripción
    |--------------------------------------------------------------------------
    */
    $condicionesDescripcion = [];

    foreach ($codigosTiendas as $cod) {
        $condicionesDescripcion[] = "UPPER(COALESCE(a.descripcion, '')) LIKE ?";
        $params[] = '%CODALMACEN: ' . $cod . '%';
        $types   .= 's';

        $condicionesDescripcion[] = "UPPER(COALESCE(a.descripcion, '')) LIKE ?";
        $params[] = '%TIENDA: ' . $cod . '%';
        $types   .= 's';
    }

    $whereTienda .= implode(' OR ', $condicionesDescripcion);

    $whereTienda .= "
            )
        )
    )";

    $where[] = $whereTienda;

    return [$where, $params, $types];
}

/* =========================================================
   PASO 11) URL DE PAGINACIÓN
   ========================================================= */
function aud_page_url(int $page, string $baseQuery): string
{
    $params = [];

    if ($baseQuery !== '') {
        parse_str($baseQuery, $params);
    }

    $params['vista'] = 'modulo2';
    $params['page']  = $page;

    return 'index.php?' . http_build_query($params);
}

/* =========================================================
   PASO 12) FILTROS DEL USUARIO
   ========================================================= */
$filters = [
    'fecha_inicio' => aud_clean_text((string)($_GET['fecha_inicio'] ?? '')),
    'fecha_fin'    => aud_clean_text((string)($_GET['fecha_fin'] ?? '')),
    'usuario'      => aud_clean_text((string)($_GET['usuario'] ?? '')),
    'modulo'       => aud_clean_text((string)($_GET['modulo'] ?? '')),
    'accion'       => aud_clean_text((string)($_GET['accion'] ?? '')),
];

/* =========================================================
   PASO 13) PAGINACIÓN
   ========================================================= */
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)($_GET['per_page'] ?? 100);

if (!in_array($perPage, [100, 200, 500], true)) {
    $perPage = 100;
}

/* =========================================================
   PASO 14) ARMAR WHERE GENERAL
   ========================================================= */
$where  = [];
$params = [];
$types  = '';

[$scopeWhere, $scopeParams, $scopeTypes] = aud_build_scope_sql(
    $conn,
    $miId,
    $miRol,
    $miPais,
    $miZona,
    $miUser
);

$where  = array_merge($where, $scopeWhere);
$params = array_merge($params, $scopeParams);
$types .= $scopeTypes;

if ($filters['fecha_inicio'] !== '') {
    $where[]  = 'DATE(a.fecha) >= ?';
    $params[] = $filters['fecha_inicio'];
    $types   .= 's';
}

if ($filters['fecha_fin'] !== '') {
    $where[]  = 'DATE(a.fecha) <= ?';
    $params[] = $filters['fecha_fin'];
    $types   .= 's';
}

if ($filters['usuario'] !== '') {
    $where[]  = 'a.usuario LIKE ?';
    $params[] = '%' . $filters['usuario'] . '%';
    $types   .= 's';
}

if ($filters['modulo'] !== '') {
    $where[]  = 'a.modulo = ?';
    $params[] = $filters['modulo'];
    $types   .= 's';
}

if ($filters['accion'] !== '') {
    $where[]  = 'a.accion = ?';
    $params[] = $filters['accion'];
    $types   .= 's';
}

/*
|--------------------------------------------------------------------------
| Mostrar solo auditorías importantes
|--------------------------------------------------------------------------
*/
$where[] = "UPPER(TRIM(a.accion)) IN (
    'CREAR_USUARIO',
    'EDITAR_USUARIO',
    'BLOQUEAR_USUARIO',
    'DESBLOQUEAR_USUARIO',
    'CREAR_EXHIBICION',
    'EDITAR_EXHIBICION',
    'CREAR_EXHIBICION_MASIVO',
    'EDITAR_EXHIBICION_MASIVO',
    'GUARDAR_EXHIBICION_MASIVO',
    'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO'
)";

$whereSql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

/* =========================================================
   PASO 15) SELECT DE MÓDULOS
   ========================================================= */
$modulos = [];

$sqlMod = "
    SELECT DISTINCT a.modulo
    FROM auditoria a
    {$whereSql}
      AND a.modulo <> ''
    ORDER BY a.modulo ASC
";

$stmtMod = $conn->prepare($sqlMod);

if ($stmtMod) {
    if ($types !== '') {
        $stmtMod->bind_param($types, ...$params);
    }

    $stmtMod->execute();
    $resMod = $stmtMod->get_result();

    if ($resMod) {
        while ($r = $resMod->fetch_assoc()) {
            $modulos[] = (string)($r['modulo'] ?? '');
        }
    }

    $stmtMod->close();
}

/* =========================================================
   PASO 16) SELECT DE ACCIONES
   ========================================================= */
$acciones = [];

$sqlAcc = "
    SELECT DISTINCT a.accion
    FROM auditoria a
    {$whereSql}
      AND a.accion <> ''
    ORDER BY a.accion ASC
";

$stmtAcc = $conn->prepare($sqlAcc);

if ($stmtAcc) {
    if ($types !== '') {
        $stmtAcc->bind_param($types, ...$params);
    }

    $stmtAcc->execute();
    $resAcc = $stmtAcc->get_result();

    if ($resAcc) {
        while ($r = $resAcc->fetch_assoc()) {
            $acciones[] = (string)($r['accion'] ?? '');
        }
    }

    $stmtAcc->close();
}

/* =========================================================
   PASO 17) CONTEO TOTAL
   ========================================================= */
$totalRows = 0;

$sqlCount = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    {$whereSql}
";

$stmtCount = $conn->prepare($sqlCount);

if ($stmtCount) {
    if ($types !== '') {
        $stmtCount->bind_param($types, ...$params);
    }

    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $totalRows = (int)($rowCount['total'] ?? 0);
    $stmtCount->close();
}

/* =========================================================
   PASO 18) PAGINACIÓN REAL
   ========================================================= */
$totalPages = max(1, (int)ceil($totalRows / $perPage));

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;

/* =========================================================
   PASO 19) TOTAL DE HOY
   ========================================================= */
$totalHoy  = 0;
$whereHoy  = $where;
$paramsHoy = $params;
$typesHoy  = $types;

$whereHoy[] = 'DATE(a.fecha) = CURDATE()';

$sqlHoy = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    WHERE " . implode(' AND ', $whereHoy);

$stmtHoy = $conn->prepare($sqlHoy);

if ($stmtHoy) {
    if ($typesHoy !== '') {
        $stmtHoy->bind_param($typesHoy, ...$paramsHoy);
    }

    $stmtHoy->execute();
    $resHoy = $stmtHoy->get_result();
    $rowHoy = $resHoy ? $resHoy->fetch_assoc() : null;
    $totalHoy = (int)($rowHoy['total'] ?? 0);
    $stmtHoy->close();
}

/* =========================================================
   PASO 19.1) MAPA DE TIENDAS PARA MOSTRAR NOMBRE CORRECTO
   ---------------------------------------------------------
   El problema era que auditoría guardaba solo código como 05 o 07.
   Como Honduras y Nicaragua pueden tener el mismo código, aquí se arma
   un mapa usando PAÍS + CÓDIGO para mostrar el nombre correcto.
   ========================================================= */
$storeMapAud = [];

if (aud_table_exists($conn, 'usuario_tienda')) {
    $sqlStoresAud = "
        SELECT DISTINCT
            COALESCE(NULLIF(pais, ''), 'HN') AS pais,
            COALESCE(NULLIF(zona, ''), '') AS zona,
            COALESCE(NULLIF(codalmacen, ''), '') AS codalmacen,
            COALESCE(NULLIF(nombrealmacen, ''), '') AS nombrealmacen
        FROM usuario_tienda
        WHERE COALESCE(TRIM(codalmacen), '') <> ''
    ";

    $resStoresAud = $conn->query($sqlStoresAud);

  if ($resStoresAud instanceof mysqli_result) {

    while ($store = $resStoresAud->fetch_assoc()) {

        /*
        |--------------------------------------------------------------------------
        | NORMALIZAR DATOS
        |--------------------------------------------------------------------------
        */
        $regionStore = aud_region_label_from_pais(
            (string)($store['pais'] ?? '')
        );

        $regionStore = aud_normalizar_region($regionStore);

        $codStore = strtoupper(
            trim((string)($store['codalmacen'] ?? ''))
        );

        $zonaStore = strtoupper(
            trim((string)($store['zona'] ?? ''))
        );

        $nomStore = trim(
            (string)($store['nombrealmacen'] ?? '')
        );

        /*
        |--------------------------------------------------------------------------
        | VALIDAR
        |--------------------------------------------------------------------------
        */
        if ($regionStore === '' || $codStore === '') {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | LLAVE ÚNICA:
        | HONDURAS-04
        | NICARAGUA-04
        |--------------------------------------------------------------------------
        */
        $keyStore = aud_store_country_key(
            $regionStore,
            $codStore
        );

        /*
        |--------------------------------------------------------------------------
        | GUARDAR SIEMPRE
        |--------------------------------------------------------------------------
        | IMPORTANTE:
        | NO usar:
        | if (!isset(...))
        |
        | porque Honduras y Nicaragua pueden tener
        | el mismo código.
        |--------------------------------------------------------------------------
        */
        $storeMapAud[$keyStore] = [
            'nombre' => $nomStore !== ''
                ? $nomStore
                : $codStore,

            'zona' => $zonaStore,
        ];
    }
}
}
/* =========================================================
   PASO 20) LISTADO PAGINADO
   ---------------------------------------------------------
   IMPORTANTE:
   Se trae region, zona y codalmacen.
   Esa combinación evita mezclar tiendas con mismo código.
   ========================================================= */
$rows = [];

$sql = "
    SELECT
        a.id,
        a.fecha,
        a.usuario,
        a.rol,
        a.modulo,
        a.accion,
        a.descripcion,
        a.region,
        a.zona,
        a.tienda,
        a.codalmacen,
        a.ip
    FROM auditoria a
    {$whereSql}
    ORDER BY a.fecha DESC, a.id DESC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

if ($stmt) {
    $bindTypes  = $types . 'ii';
    $bindParams = array_merge($params, [$perPage, $offset]);

    $stmt->bind_param($bindTypes, ...$bindParams);
    $stmt->execute();

    $res = $stmt->get_result();

    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $descripcion = (string)($r['descripcion'] ?? '');

            /*
            |--------------------------------------------------------------------------
            | PASO 20.1) NORMALIZAR REGIÓN / ZONA / CODALMACEN
            |--------------------------------------------------------------------------
            | Si la columna viene vacía, intentamos leer el dato desde descripción.
            | Esto es clave para que no se mezclen Honduras y Nicaragua cuando el
            | mismo código de almacén existe en ambos países.
            |--------------------------------------------------------------------------
            */
            $region = trim((string)($r['region'] ?? ''));

            if ($region === '') {
                $region = aud_extract_region_from_description($descripcion);
            }

            $region = aud_normalizar_region($region);

            $zona = trim((string)($r['zona'] ?? ''));

            if ($zona === '') {
                $zona = aud_extract_zona_from_description($descripcion);
            }

            $codalmacen = trim((string)($r['codalmacen'] ?? ''));

            if ($codalmacen === '') {
                $codalmacen = aud_extract_codalmacen_from_description($descripcion);
            }

            $r['region'] = $region;
            $r['zona'] = strtoupper(trim($zona));
            $r['codalmacen'] = strtoupper(trim($codalmacen));

            /*
            |--------------------------------------------------------------------------
            | PASO 20.2) BUSCAR NOMBRE REAL DE LA TIENDA
            |--------------------------------------------------------------------------
            | Primero busca por REGIÓN + CODALMACEN para no mezclar Honduras/Nicaragua.
            | Si auditoría ya trae nombre en tienda, se respeta. Si trae solo código,
            | se reemplaza por el nombre encontrado en usuario_tienda.
            |--------------------------------------------------------------------------
            */
            $storeKeySimple = aud_store_country_key($r['region'], $r['codalmacen']);
            $storeInfo = $storeMapAud[$storeKeySimple] ?? null;

            $tiendaOriginal = trim((string)($r['tienda'] ?? ''));

/*
|--------------------------------------------------------------------------
| FORZAR NOMBRE CORRECTO POR REGION + CODALMACEN
|--------------------------------------------------------------------------
| Aunque auditoría tenga guardado Juticalpa, si la región es NICARAGUA
| y el código es 04, debe tomar DeTodo Las Brisas desde usuario_tienda.
|--------------------------------------------------------------------------
*/
if ($storeInfo !== null) {
    $nombreTienda = (string)($storeInfo['nombre'] ?? '');
} else {
    $nombreTienda = $tiendaOriginal;
}

            if ($r['zona'] === '' && $storeInfo !== null) {
                $r['zona'] = strtoupper(trim((string)($storeInfo['zona'] ?? '')));
            }

            if ($nombreTienda === '') {
                $nombreTienda = $r['codalmacen'];
            }

            $r['tienda_nombre'] = $nombreTienda;
            $r['tienda_display'] = $r['codalmacen'] !== ''
                ? ($r['codalmacen'] . ' - ' . $nombreTienda)
                : $nombreTienda;

            $r['llave_tienda'] = aud_store_key($r['region'], $r['zona'], $r['codalmacen']);

            $rows[] = $r;
        }
    }

    $stmt->close();
}

/* =========================================================
   PASO 21) QUERY BASE PARA PAGINACIÓN
   ========================================================= */
$queryWithoutPage = $_GET;
unset($queryWithoutPage['page']);
$baseQuery = http_build_query($queryWithoutPage);
?>

<div class="aud-wrap">
    <div class="aud-panel">

        <section class="aud-header">
            <div>
                <p>
                    Consulta los movimientos registrados del sistema por usuario, módulo, acción, fecha, región, zona y tienda.
                </p>
            </div>

            <div class="aud-top-actions">
                <a href="index.php?vista=modulo2" class="aud-btn aud-btn-light" title="Limpiar filtros">
                    <i class="bi bi-arrow-clockwise"></i>
                    <span>Limpiar</span>
                </a>
            </div>
        </section>

        <section class="aud-card">
            <h2 class="aud-card-title">Listado de auditoría</h2>

            <div class="aud-toolbar">
                <div>
                    <form method="get" action="index.php" class="aud-mini-form" id="formPerPageAud">
                        <input type="hidden" name="vista" value="modulo2">

                        <?php foreach ($_GET as $k => $v): ?>
                            <?php if ($k !== 'per_page' && $k !== 'page' && $k !== 'vista'): ?>
                                <input type="hidden" name="<?= h_aud($k) ?>" value="<?= h_aud((string)$v) ?>">
                            <?php endif; ?>
                        <?php endforeach; ?>

                        <label for="per_page_aud">Registros por página</label>
                        <select name="per_page" id="per_page_aud">
                            <option value="100" <?= $perPage === 100 ? 'selected' : '' ?>>100</option>
                            <option value="200" <?= $perPage === 200 ? 'selected' : '' ?>>200</option>
                            <option value="500" <?= $perPage === 500 ? 'selected' : '' ?>>500</option>
                        </select>
                    </form>
                </div>

                <div class="aud-summary">
                    <span>Total <strong><?= $totalRows ?></strong></span>
                    <span>Hoy <strong><?= $totalHoy ?></strong></span>
                    <span>Página <strong><?= $page ?></strong> de <strong><?= $totalPages ?></strong></span>
                </div>
            </div>

            <div class="aud-table-shell">
                <form method="get" id="formFiltrosAud" action="index.php">
                    <input type="hidden" name="vista" value="modulo2">
                    <input type="hidden" name="per_page" value="<?= h_aud((string)$perPage) ?>">
                </form>

                <table class="aud-table">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Rol</th>
                            <th>Módulo</th>
                            <th>Acción</th>
                            <th>Descripción</th>
                           
                             <?php /*<th>Región</th>*/ ?>

                            <th>Zona</th>
                         <?php /*    <th>Código / Tienda</th> */ ?>
                             <?php /*<th>Codalmacen</th>*/ ?>
                              <?php /*<th>Llave tienda</th>*/ ?>
                            <th class="center">IP</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr class="aud-filter-row">
                            <td>
                                <div class="aud-date-range">
                                    <input form="formFiltrosAud" type="date" name="fecha_inicio" value="<?= h_aud($filters['fecha_inicio']) ?>">
                                    <input form="formFiltrosAud" type="date" name="fecha_fin" value="<?= h_aud($filters['fecha_fin']) ?>">
                                </div>
                            </td>

                            <td>
                                <input form="formFiltrosAud" type="text" name="usuario" value="<?= h_aud($filters['usuario']) ?>" class="js-aud-text" placeholder="Usuario">
                            </td>

                            <td></td>

                            <td>
                                <select form="formFiltrosAud" name="modulo">
                                    <option value="">Todos</option>

                                    <?php foreach ($modulos as $m): ?>
                                        <option value="<?= h_aud($m) ?>" <?= $filters['modulo'] === $m ? 'selected' : '' ?>>
                                            <?= h_aud($m) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>

                            <td>
                                <select form="formFiltrosAud" name="accion">
                                    <option value="">Todas</option>

                                    <?php foreach ($acciones as $a): ?>
                                        <option value="<?= h_aud($a) ?>" <?= $filters['accion'] === $a ? 'selected' : '' ?>>
                                            <?= h_aud($a) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>

                            <td></td>
                            <td></td>
                           
                            

                            <td class="center">
                                <button id="btnFiltrarAud" form="formFiltrosAud" type="submit" class="aud-btn aud-btn-primary" title="Filtrar">
                                    <i class="bi bi-funnel-fill"></i>
                                    <span>Filtrar</span>
                                </button>
                            </td>
                        </tr>

                        <?php if (empty($rows)): ?>
                            <tr>
                                <td colspan="10" class="aud-empty">
                                    <i class="bi bi-inbox"></i> No se encontraron movimientos.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($rows as $r): ?>
                                <tr>
                                    <td><?= h_aud($r['fecha'] ?? '') ?></td>
                                    <td><?= h_aud($r['usuario'] ?? '') ?></td>
                                    <td><?= h_aud($r['rol'] ?? '') ?></td>

                                    <td>
                                        <span class="aud-badge aud-mod">
                                            <?= h_aud($r['modulo'] ?? '') ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="aud-badge aud-act">
                                            <?= h_aud($r['accion'] ?? '') ?>
                                        </span>
                                    </td>

                                    <td class="aud-desc">
                                        <?= aud_format_descripcion((string)($r['descripcion'] ?? '')) ?>
                                    </td>

                            <?php /*       <td><?= h_aud($r['region'] ?? '') ?></td>  */ ?>
                                    <td><?= h_aud($r['zona'] ?? '') ?></td>
                                   <?php /*       <td><?= h_aud($r['tienda_display'] ?? ($r['tienda'] ?? '')) ?></td> */ ?>
                                   <?php /* <td><?= h_aud($r['codalmacen'] ?? '') ?></td>*/ ?>

                                    <?php /*
<td>
    <span class="aud-key">
        <?= h_aud($r['llave_tienda'] ?? '') ?>
    </span>
</td>
*/ ?>


                                    <td class="center"><?= h_aud($r['ip'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="aud-pagination">
                    <?php if ($page > 1): ?>
                        <a class="aud-page-btn aud-page-nav" href="<?= h_aud(aud_page_url(1, $baseQuery)) ?>">
                            <i class="bi bi-chevron-double-left"></i>
                        </a>

                        <a class="aud-page-btn aud-page-nav" href="<?= h_aud(aud_page_url($page - 1, $baseQuery)) ?>">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    <?php endif; ?>

                    <?php
                    $start = max(1, $page - 2);
                    $end   = min($totalPages, $page + 2);
                    ?>

                    <?php if ($start > 1): ?>
                        <span class="aud-page-dots">...</span>
                    <?php endif; ?>

                    <?php for ($i = $start; $i <= $end; $i++): ?>
                        <?php if ($i === $page): ?>
                            <span class="aud-page-btn active"><?= $i ?></span>
                        <?php else: ?>
                            <a class="aud-page-btn" href="<?= h_aud(aud_page_url($i, $baseQuery)) ?>">
                                <?= $i ?>
                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if ($end < $totalPages): ?>
                        <span class="aud-page-dots">...</span>
                    <?php endif; ?>

                    <?php if ($page < $totalPages): ?>
                        <a class="aud-page-btn aud-page-nav" href="<?= h_aud(aud_page_url($page + 1, $baseQuery)) ?>">
                            <i class="bi bi-chevron-right"></i>
                        </a>

                        <a class="aud-page-btn aud-page-nav" href="<?= h_aud(aud_page_url($totalPages, $baseQuery)) ?>">
                            <i class="bi bi-chevron-double-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>

<style>
.aud-wrap {
    padding: 2px;
    background: transparent;
    min-height: 100%;
}

.aud-panel {
    background: transparent !important;
    border-color: transparent !important;
    box-shadow: none !important;
}

.aud-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    border: 1px solid #e6ecf4;
    background: #fff;
    border-radius: 24px;
    padding: 22px 24px;
    margin-bottom: 18px;
}

.aud-header p {
    margin: 0;
    color: #64748b;
    font-size: 15px;
}

.aud-note {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1e3a8a;
    border-radius: 14px;
    padding: 12px 14px;
    font-size: 14px;
    margin-bottom: 14px;
}

.aud-top-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.aud-btn {
    border: none;
    text-decoration: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    min-height: 46px;
    padding: 0 16px;
    border-radius: 14px;
    font-size: 14px;
    font-weight: 800;
    transition: all .18s ease;
    box-shadow: 0 6px 16px rgba(15,23,42,.05);
}

.aud-btn i {
    font-size: 15px;
    line-height: 1;
}

.aud-btn-primary {
    background: linear-gradient(135deg, #635bff, #7c6cff);
    color: #fff;
    border: 1px solid #635bff;
}

.aud-btn-primary:hover {
    background: linear-gradient(135deg, #5548ff, #6d5fff);
    color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 10px 22px rgba(99,91,255,.18);
}

.aud-btn-light {
    background: #fff;
    color: #334155;
    border: 1px solid #dbe4f0;
}

.aud-btn-light:hover {
    background: #f8faff;
    color: #4f46e5;
    border-color: #c7d2fe;
    transform: translateY(-1px);
}

.aud-card {
    background: #fff;
    border: 1px solid #e6ecf4;
    border-radius: 22px;
    padding: 18px;
}

.aud-card-title {
    margin: 0 0 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid #e6ecf4;
    font-size: 16px;
    font-weight: 900;
    color: #0b1b46;
}

.aud-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 14px;
}

.aud-mini-form {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.aud-mini-form label {
    color: #64748b;
    font-size: 14px;
    font-weight: 700;
}

.aud-mini-form select {
    border: 1px solid #d7e0eb;
    border-radius: 12px;
    padding: 9px 12px;
    background: #fff;
    outline: none;
}

.aud-mini-form select:focus,
.aud-table input:focus,
.aud-table select:focus {
    border-color: #635bff;
    box-shadow: 0 0 0 4px rgba(99,91,255,.10);
}

.aud-summary {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
    color: #64748b;
    font-size: 14px;
}

.aud-summary strong {
    color: #0f172a;
}

.aud-table-shell {
    overflow: auto;
    border-radius: 18px;
}

.aud-table {
    width: 100%;
    min-width: 100px;
    border-collapse: separate;
    border-spacing: 0 10px;
}

.aud-table thead th {
    background: #edf2ff;
    color: #0b1b46;
    font-size: 14px;
    font-weight: 900;
    white-space: nowrap;
    text-align: left;
    padding: 14px 12px;
}

.aud-table thead th:first-child {
    border-top-left-radius: 14px;
    border-bottom-left-radius: 14px;
}

.aud-table thead th:last-child {
    border-top-right-radius: 14px;
    border-bottom-right-radius: 14px;
}

.aud-table tbody tr {
    background: #fff;
}

.aud-table tbody td {
    background: #fff;
    padding: 14px 12px;
    vertical-align: middle;
    border-top: 1px solid #e6ecf4;
    border-bottom: 1px solid #e6ecf4;
}

.aud-table tbody td:first-child {
    border-left: 1px solid #e6ecf4;
    border-top-left-radius: 14px;
    border-bottom-left-radius: 14px;
}

.aud-table tbody td:last-child {
    border-right: 1px solid #e6ecf4;
    border-top-right-radius: 14px;
    border-bottom-right-radius: 14px;
}

.aud-filter-row td {
    background: transparent !important;
}

.aud-table input[type="text"],
.aud-table input[type="date"],
.aud-table select {
    width: 100%;
    min-width: 90px;
    border: 1px solid #d7e0eb;
    border-radius: 12px;
    padding: 10px 12px;
    outline: none;
    background: #fff;
    font-size: 14px;
    color: #0f172a;
    transition: .18s ease;
}

.aud-date-range {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    min-width: 230px;
}

.aud-empty {
    padding: 15px !important;
    color: #64748b;
    font-weight: 700;
    text-align: center;
}

.aud-desc {
    min-width: 340px;
    color: #334155;
}

.aud-desc-box {
    display: flex;
    flex-direction: column;
    gap: 8px;
    line-height: 1.5;
}

.aud-desc-main {
    font-size: 14px;
    font-weight: 700;
    color: #0f172a;
}

.aud-desc-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding-left: 0;
    border-left: none;
}

.aud-desc-line {
    font-size: 13px;
    color: #475569;
    line-height: 1.45;
}

.aud-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 30px;
    padding: 5px 10px;
    border-radius: 999px;
    font-size: .78rem;
    font-weight: 800;
    white-space: nowrap;
}

.aud-mod {
    background: #eef2ff;
    color: #4f46e5;
}

.aud-act {
    background: #ecfeff;
    color: #0f766e;
}

.aud-key {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 999px;
    background: #f1f5f9;
    color: #334155;
    font-size: 12px;
    font-weight: 800;
    white-space: nowrap;
}

.center {
    text-align: center;
}

.aud-pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 20px;
}

.aud-page-btn {
    min-width: 42px;
    height: 42px;
    padding: 0 14px;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-weight: 800;
    font-size: 14px;
    border: 1px solid #dbe4f0;
    background: #ffffff;
    color: #334155;
    box-shadow: 0 4px 10px rgba(15,23,42,.04);
    transition: all .18s ease;
}

.aud-page-btn:hover {
    background: #f8faff;
    border-color: #c7d2fe;
    color: #4f46e5;
    transform: translateY(-1px);
}

.aud-page-btn.active {
    background: linear-gradient(135deg, #635bff, #7c6cff);
    color: #fff;
    border-color: #635bff;
    box-shadow: 0 10px 20px rgba(99,91,255,.18);
}

.aud-page-nav {
    width: 42px;
    padding: 0;
}

.aud-page-nav i {
    font-size: 15px;
    line-height: 1;
}

.aud-page-dots {
    color: #94a3b8;
    font-weight: 800;
    padding: 0 2px;
}

@media (max-width: 900px) {
    .aud-wrap {
        padding: 14px;
    }

    .aud-header {
        flex-direction: column;
        align-items: flex-start;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const perPage = document.getElementById('per_page_aud');
    const formPerPage = document.getElementById('formPerPageAud');
    const formFiltros = document.getElementById('formFiltrosAud');
    const btnFiltrar = document.getElementById('btnFiltrarAud');

    function loading(btn, iconHtml) {
        if (!btn) return;

        btn.disabled = true;
        btn.innerHTML = iconHtml;
        btn.style.opacity = '.75';
    }

    document.querySelectorAll('.js-aud-text').forEach(function(input){
        input.addEventListener('input', function(){
            this.value = this.value.replace(/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ._\- ]/g, '');
        });
    });

    if (perPage && formPerPage) {
        perPage.addEventListener('change', function () {
            formPerPage.submit();
        });
    }

    if (formFiltros && btnFiltrar) {
        formFiltros.addEventListener('submit', function () {
            loading(btnFiltrar, '<i class="bi bi-hourglass-split"></i><span>Filtrando</span>');
        });
    }
});
</script>