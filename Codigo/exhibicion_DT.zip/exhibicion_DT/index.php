<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| INICIAR SESIÓN PRINCIPAL DE EXHIBICIÓN
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

if (!isset($_SESSION['usuario_id'])) {
    header("Location: /exhibicion_DT/controlusuarios/login.php");
    exit;
}

$usuario   = $_SESSION['usuario'] ?? 'Usuario';
$rol       = $_SESSION['rol'] ?? '';
$pais_code = $_SESSION['pais_code'] ?? '';
$zona      = $_SESSION['zona'] ?? '';
$tienda    = $_SESSION['tienda'] ?? '';

$vistas = [
    'inicio'    => null,
    'dashboard' => __DIR__ . '/exhibiciontotal/dashboard.php',
    'usuarios'  => __DIR__ . '/controlusuarios/usuarios.php',
    'modulo1'   => __DIR__ . '/exhibiciontotal/exhibicion.php',
    'modulo2'   => __DIR__ . '/auditoria/auditoria.php',
    'modulo3'   => __DIR__ . '/exhibiciontotal/exhibicion_sin_stock.php',
    'perfil'    => __DIR__ . '/perfil/perfil.php',
];

$vista = $_GET['vista'] ?? 'inicio';

if ($vista === 'usuarios' && !in_array($rol, ['super_admin', 'admin_zona'], true)) {
    $vista = 'inicio';
}

if ($vista === 'modulo2' && !in_array($rol, ['super_admin', 'admin_zona'], true)) {
    $vista = 'inicio';
}

if (!array_key_exists($vista, $vistas)) {
    $vista = 'inicio';
}

$archivo_vista = $vistas[$vista];
$es_inicio = ($vista === 'inicio');

$flash_ok  = $_SESSION['flash_ok'] ?? '';
$flash_err = $_SESSION['flash_err'] ?? '';
unset($_SESSION['flash_ok'], $_SESSION['flash_err']);

function render_vista(?string $archivo_vista): void
{
    if ($archivo_vista && file_exists($archivo_vista)) {
        include $archivo_vista;
    } else {
        echo '<div class="alert alert-warning mb-0">La vista no existe todavía.</div>';
    }
}

$avatar_web  = '/exhibicion_DT/assets/img/user.png';
$avatar_file = __DIR__ . '/assets/img/user.png';
$avatar_ok   = file_exists($avatar_file);

$paisNombre = match (strtoupper(trim((string)$pais_code))) {
    'HN' => 'Honduras',
    'NI' => 'Nicaragua',
    default => (string)$pais_code,
};
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exhibición DT</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/exhibicion_DT/index.css">
    <link rel="stylesheet" href="/exhibicion_DT/exhibiciontotal/exhibicion.css">
<link rel="icon" type="image/png" href="/exhibicion_DT/img/logomcc.png">
</head>
<body>

<div class="site-shell">

    <header class="topbar-wrap">
        <div class="topbar-box">
            <a class="brand-link" href="/exhibicion_DT/index.php?vista=inicio">
                <span class="brand-icon">EDT</span>
            </a>

            <button class="navbar-toggler menu-toggle d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#menuTop">
                <span class="menu-lines">☰</span>
            </button>

            <div class="collapse navbar-collapse nav-area" id="menuTop">
                <nav class="main-nav">
                    <a class="nav-link-custom <?= in_array($vista, ['inicio','dashboard'], true) ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=inicio">
                        Inicio
                    </a>


                    <?php if (in_array($_SESSION['rol'] ?? '', ['super_admin', 'admin_zona'], true)): ?>
     
                    <a class="nav-link-custom <?= $vista === 'dashboard' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=dashboard">
                        Dashboard
                    </a>
                    <?php endif; ?>

                    <a class="nav-link-custom <?= $vista === 'modulo1' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=modulo1">
                        Exhibición DT
                    </a>

                    <a class="nav-link-custom <?= $vista === 'modulo3' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=modulo3">
                        Exhibicion sin stock
                    </a>
                    <?php if (in_array($rol, ['super_admin', 'admin_zona'], true)): ?>
                        <a class="nav-link-custom <?= $vista === 'usuarios' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=usuarios">
                            Control de Usuarios
                        </a>
                    <?php endif; ?>

                    <?php if (in_array($rol, ['super_admin','admin_zona'], true)): ?>
                        <a class="nav-link-custom <?= $vista === 'modulo2' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=modulo2">
                            Auditoría
                        </a>
                    <?php endif; ?>

                    <a class="nav-link-custom <?= $vista === 'perfil' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=perfil">
                        Perfil
                    </a>
                </nav>

                <div class="topbar-right">
                    <a class="logout-btn" href="/exhibicion_DT/controlusuarios/logout.php">
                        <span class="bi bi-box-arrow-right"></span>
                        <span></span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <?php if ($es_inicio): ?>
        <section class="hero-section">
            <div class="hero-left">
                <span class="hero-kicker">Plataforma administrativa</span>
                <h1>Controla tu operación en un solo lugar</h1>
                <p>
                    Visualiza módulos, administra usuarios y gestiona la información principal
                    de Exhibición DT con una interfaz más limpia y moderna.
                </p>

                <div class="hero-actions">
                    <a class="hero-btn primary" href="/exhibicion_DT/index.php?vista=modulo1">Ir a exhibición</a>

                    <?php if (in_array($rol, ['super_admin', 'admin_zona'], true)): ?>
                        <a class="hero-btn secondary" href="/exhibicion_DT/index.php?vista=usuarios">Gestionar usuarios</a>
                    <?php endif; ?>
                </div>

                <div class="hero-meta">
                    <?php if (!empty($rol)): ?>
                        <span>Rol: <?= htmlspecialchars($rol, ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>

                    <?php if (!empty($paisNombre)): ?>
                        <span>País: <?= htmlspecialchars($paisNombre, ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>

                    <?php if ($rol === 'admin_zona' && !empty($zona)): ?>
                        <span>Zona: <?= htmlspecialchars($zona, ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>

                    <?php if ($rol === 'tienda' && !empty($tienda)): ?>
                        <span>Tienda: <?= htmlspecialchars($tienda, ENT_QUOTES, 'UTF-8') ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hero-right">
                <div class="logo-hero-box">
                    <img src="/exhibicion_DT/img/logo.png" alt="Logo de la empresa" class="logo-hero-img">
                </div>
            </div>
        </section>
    <?php endif; ?>

    <main class="content-wrap">
        <?php if ($flash_ok): ?>
            <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
                <?= htmlspecialchars($flash_ok, ENT_QUOTES, 'UTF-8') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($flash_err): ?>
            <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                <?= htmlspecialchars($flash_err, ENT_QUOTES, 'UTF-8') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($vista !== 'inicio'): ?>
            <section class="content-panel">
                <?php render_vista($archivo_vista); ?>
            </section>
        <?php endif; ?>
    </main>

</div>

<style>
:root{
    --bg:#fbfbff;
    --bg-soft:#f6f7ff;
    --panel:#ffffff;
    --line:#e8eaf5;
    --line-soft:#eef1f8;

    --text:#111827;
    --text-soft:#4b5563;
    --muted:#6b7280;

    --primary:#635bff;
    --primary-2:#7c6cff;
    --primary-soft:#f1efff;

    --danger:#dc2626;
    --danger-soft:#fff1f2;

    --shadow-xs:0 2px 8px rgba(15,23,42,.04);
    --shadow-sm:0 12px 24px rgba(15,23,42,.05);
    --shadow:0 24px 60px rgba(15,23,42,.07);

    --radius:18px;
    --radius-lg:28px;
}

*{
    box-sizing:border-box;
}

html,
body{
    margin:0;
    min-height:100%;
    font-family:"Segoe UI", Arial, Helvetica, sans-serif;
    color:var(--text);
    background:
        radial-gradient(circle at top right, rgba(124,108,255,.08), transparent 18%),
        linear-gradient(180deg, #ffffff 0%, var(--bg) 100%);
}

.site-shell{
    width:100%;
    max-width:100%;
    margin:0;
    padding:18px 20px 30px;
}

.topbar-wrap{
    width:100%;
    margin-bottom:22px;
}

.topbar-box{
    width:100%;
    display:flex;
    align-items:center;
    gap:18px;
    justify-content:space-between;
    padding:18px 22px;
    background:rgba(255,255,255,.92);
    border:1px solid #ececf6;
    border-radius:26px;
    box-shadow:var(--shadow-sm);
    backdrop-filter:blur(14px);
    -webkit-backdrop-filter:blur(14px);
}

.hero-section{
    display:grid;
    grid-template-columns: 1.05fr .95fr;
    gap:34px;
    align-items:center;
    padding:32px 20px 22px;
    margin-bottom:26px;
    background:transparent;
    border:none;
    border-bottom:1px solid var(--line);
    border-radius:0;
    box-shadow:none;
}

.content-wrap{
    width:100%;
    margin-top:8px;
}

.content-panel{
    width:100%;
    background:var(--panel);
    border:1px solid var(--line);
    border-radius:26px;
    box-shadow:var(--shadow-sm);
    padding:24px;
    min-height:420px;
}

.logo-hero-img{
    max-width:100%;
    max-height:300px;
    width:auto;
    height:auto;
    object-fit:contain;
    display:block;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    <?php if ($vista === 'usuarios'): ?>
    if (typeof initControlUsuarios === 'function') {
        initControlUsuarios();
    }
    <?php endif; ?>
});

// Bloquear el menú del clic derecho
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // Bloquear atajos de teclado comunes (F12, Ctrl+Shift+I, Ctrl+U)
    document.addEventListener('keydown', function(e) {
        // F12
        if (e.keyCode === 123) {
            e.preventDefault();
        }
        // Ctrl + Shift + I (Inspector) o Ctrl + Shift + C
        if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 67)) {
            e.preventDefault();
        }
        // Ctrl + U (Ver código fuente)
        if (e.ctrlKey && e.keyCode === 85) {
            e.preventDefault();
        }
    });

</script>
</body>
</html>