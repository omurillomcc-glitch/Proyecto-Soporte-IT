<?php
declare(strict_types=1);

session_start();

ini_set('max_execution_time', '0');
ini_set('memory_limit', '1024M');
set_time_limit(0);

require_once __DIR__. '/../controlusuarios/auth.php';
require_once __DIR__. '/../vendor/autoload.php';
require_once __DIR__. '/../controlusuarios/conexion_sqlsrv.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

require_login();

function limpiar($v): string
{
    $v = trim(str_replace(["\n", "\r", "\t"], ' ', (string)$v));

    $malos = [
        '#N/D',
        '#N/A',
        '#¡N/A!',
        'N/A',
        'NA',
        'NULL',
        'SIN DATO',
        'SIN DATOS'
    ];

    if (in_array(strtoupper($v), $malos, true)) {
        return '';
    }

    return $v;
}

function num($v): int
{
    $v = limpiar($v);

    if ($v === '') {
        return 0;
    }

    return (int)preg_replace('/\D/', '', $v);
}

function key_norm($v): string
{
    $v = limpiar((string)$v);
    $v = strtoupper($v);
    $v = preg_replace('/\s+/', '', $v);
    $v = preg_replace('/[^A-Z0-9]/', '', $v);

    return trim($v);
}

function normalizar_region(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'NI', 'NIC', 'NICARAGUA' => 'NICARAGUA',
        'HN', 'HON', 'HONDURAS'  => 'HONDURAS',
        default                  => $region,
    };
}

function db_por_region(string $region): string
{
    $region = normalizar_region($region);

    if ($region === 'NICARAGUA') {
        return 'ACANICARAGUA2';
    }

    return 'DETODO';
}

function sql_key_expr(string $campo): string
{
    return "
        UPPER(
            REPLACE(
            REPLACE(
            REPLACE(
            REPLACE(
                LTRIM(RTRIM(CONVERT(VARCHAR(150), {$campo}))),
            CHAR(10), ''),
            CHAR(13), ''),
            CHAR(9), ''),
            ' ', '')
        )
    ";
}

function cargar_mapas_db($sqlsrv_conn, string $db): array
{
    $mapBarras = [];
    $mapPlu    = [];
    $mapRef    = [];

    /*
    |--------------------------------------------------------------------------
    | MAPA REFERENCIA
    |--------------------------------------------------------------------------
    */
    $sql = "
        SELECT
            " . sql_key_expr('REFPROVEEDOR') . " AS REFERENCIA,
            LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) AS CODARTICULO
        FROM {$db}.dbo.ARTICULOS
        WHERE REFPROVEEDOR IS NOT NULL
          AND LTRIM(RTRIM(CONVERT(VARCHAR(150), REFPROVEEDOR))) <> ''
          AND DESCATALOGADO = 'F'
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql);

    if ($stmt === false) {
        throw new Exception("Error cargando mapa REFERENCIA de {$db}: " . print_r(sqlsrv_errors(), true));
    }

    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $key = key_norm($r['REFERENCIA'] ?? '');
        $cod = limpiar($r['CODARTICULO'] ?? '');

        if ($key !== '' && $cod !== '') {
            $mapRef[$key] = $cod;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MAPA CODBARRAS
    |--------------------------------------------------------------------------
    */
    $sql = "
        SELECT
            " . sql_key_expr('CODBARRAS') . " AS CODBARRAS,
            LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) AS CODARTICULO
        FROM {$db}.dbo.ARTICULOSLIN
        WHERE CODBARRAS IS NOT NULL
          AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODBARRAS))) <> ''
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql);

    if ($stmt === false) {
        throw new Exception("Error cargando mapa CODBARRAS de {$db}: " . print_r(sqlsrv_errors(), true));
    }

    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $key = key_norm($r['CODBARRAS'] ?? '');
        $cod = limpiar($r['CODARTICULO'] ?? '');

        if ($key !== '' && $cod !== '') {
            $mapBarras[$key] = $cod;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | MAPA PLU
    |--------------------------------------------------------------------------
    */
    $sql = "
        SELECT
            " . sql_key_expr('PLU') . " AS PLU,
            LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) AS CODARTICULO
        FROM {$db}.dbo.ARTICULOSCAMPOSLIBRES
        WHERE PLU IS NOT NULL
          AND LTRIM(RTRIM(CONVERT(VARCHAR(100), PLU))) <> ''
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql);

    if ($stmt === false) {
        throw new Exception("Error cargando mapa PLU de {$db}: " . print_r(sqlsrv_errors(), true));
    }

    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $key = key_norm($r['PLU'] ?? '');
        $cod = limpiar($r['CODARTICULO'] ?? '');

        if ($key !== '' && $cod !== '') {
            $mapPlu[$key] = $cod;
        }
    }

    return [
        'ref'    => $mapRef,
        'barras' => $mapBarras,
        'plu'    => $mapPlu,
    ];
}

$mensaje = '';
$error = '';
$erroresDetalle = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
            throw new Exception("No hay conexión a SQL Server.");
        }

        $codalmacen = preg_replace('/\D/', '', (string)($_POST['codalmacen'] ?? ''));

        if ($codalmacen === '') {
            throw new Exception("Debe ingresar CODALMACEN.");
        }

        $codalmacen = str_pad($codalmacen, 2, '0', STR_PAD_LEFT);

        if (!isset($_FILES['archivo']) || $_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Debe subir un archivo Excel válido.");
        }

        $spreadsheet = IOFactory::load($_FILES['archivo']['tmp_name']);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray(null, true, true, true);

        if (count($rows) < 2) {
            throw new Exception("El Excel está vacío.");
        }

        array_shift($rows);

        $mapasPorDb = [];

        $procesados = 0;
        $errores = 0;
        $saltados = 0;

        $sqlMerge = "
            MERGE vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] AS destino

            USING (
                SELECT
                    ? AS REGION,
                    ? AS CODALMACEN,
                    ? AS CODARTICULO,
                    ? AS CODBARRAS,
                    ? AS PLU,
                    ? AS EXHIBICION,
                    ? AS UXC
            ) AS origen

            ON  LTRIM(RTRIM(CONVERT(VARCHAR(100), destino.REGION)))
                = LTRIM(RTRIM(CONVERT(VARCHAR(100), origen.REGION)))

            AND LTRIM(RTRIM(CONVERT(VARCHAR(100), destino.CODALMACEN)))
                = LTRIM(RTRIM(CONVERT(VARCHAR(100), origen.CODALMACEN)))

            AND LTRIM(RTRIM(CONVERT(VARCHAR(100), destino.CODARTICULO)))
                = LTRIM(RTRIM(CONVERT(VARCHAR(100), origen.CODARTICULO)))

            WHEN MATCHED THEN
                UPDATE SET
                    destino.CODBARRAS = origen.CODBARRAS,
                    destino.PLU = origen.PLU,
                    destino.EXHIBICION = origen.EXHIBICION,
                    destino.UXC = origen.UXC

            WHEN NOT MATCHED THEN
                INSERT (
                    REGION,
                    CODALMACEN,
                    CODARTICULO,
                    CODBARRAS,
                    PLU,
                    EXHIBICION,
                    UXC
                )
                VALUES (
                    origen.REGION,
                    origen.CODALMACEN,
                    origen.CODARTICULO,
                    origen.CODBARRAS,
                    origen.PLU,
                    origen.EXHIBICION,
                    origen.UXC
                );
        ";

        foreach ($rows as $numFila => $row) {

            $filaReal = $numFila + 2;

            $region = normalizar_region(limpiar($row['A'] ?? ''));

            $referencia = limpiar(
                (string)$sheet->getCell('B' . $filaReal)->getFormattedValue()
            );

            if (
                $referencia !== '' &&
                ctype_digit($referencia) &&
                strlen($referencia) < 5
            ) {
                $referencia = str_pad($referencia, 5, '0', STR_PAD_LEFT);
            }

            $descripcion = limpiar($row['C'] ?? '');

            $codbarras = limpiar(
                (string)$sheet->getCell('G' . $filaReal)->getFormattedValue()
            );

            $plu = limpiar(
                (string)$sheet->getCell('H' . $filaReal)->getFormattedValue()
            );

            /*
            |--------------------------------------------------------------------------
            | LEER EXHIBICION Y UXC DESDE EL VALOR CALCULADO DEL EXCEL
            |--------------------------------------------------------------------------
            */
            $exhibicionRaw = $sheet->getCell('J' . $filaReal)->getCalculatedValue();
            $uxcRaw        = $sheet->getCell('K' . $filaReal)->getCalculatedValue();

            $exhibicion = num($exhibicionRaw);
            $uxc        = num($uxcRaw);

            if (
                $region === '' &&
                $referencia === '' &&
                $descripcion === '' &&
                $codbarras === '' &&
                $plu === ''
            ) {
                $saltados++;
                continue;
            }

            if ($region === '') {
                $errores++;
                $erroresDetalle[] = "Fila {$filaReal}: no tiene REGION.";
                continue;
            }

            $dbFila = db_por_region($region);

            if (!isset($mapasPorDb[$dbFila])) {
                $mapasPorDb[$dbFila] = cargar_mapas_db($sqlsrv_conn, $dbFila);
            }

            $mapRef    = $mapasPorDb[$dbFila]['ref'];
            $mapBarras = $mapasPorDb[$dbFila]['barras'];
            $mapPlu    = $mapasPorDb[$dbFila]['plu'];

            $kr = key_norm($referencia);
            $kb = key_norm($codbarras);
            $kp = key_norm($plu);

            $codarticulo = '';

            /*
            |--------------------------------------------------------------------------
            | ORDEN CORREGIDO:
            | 1) REFERENCIA
            | 2) CODBARRAS
            | 3) PLU
            |--------------------------------------------------------------------------
            */
            if ($kr !== '' && isset($mapRef[$kr])) {
                $codarticulo = $mapRef[$kr];
            }

            if ($codarticulo === '' && $kb !== '' && isset($mapBarras[$kb])) {
                $codarticulo = $mapBarras[$kb];
            }

            if ($codarticulo === '' && $kp !== '' && isset($mapPlu[$kp])) {
                $codarticulo = $mapPlu[$kp];
            }

            if ($codarticulo === '') {

                $errores++;

                $erroresDetalle[] =
                    "Fila {$filaReal}: no se encontró CODARTICULO en {$dbFila}. "
                    . "Region: {$region}, "
                    . "Ref: {$referencia}, "
                    . "Barra: {$codbarras}, "
                    . "PLU: {$plu}";

                continue;
            }

            $params = [
                $region,
                $codalmacen,
                $codarticulo,
                $codbarras,
                $plu,
                $exhibicion,
                $uxc
            ];

            $stmtMerge = sqlsrv_query($sqlsrv_conn, $sqlMerge, $params);

            if ($stmtMerge === false) {

                $errores++;

                $erroresDetalle[] =
                    "Fila {$filaReal}: error SQL Server - "
                    . print_r(sqlsrv_errors(), true);

                continue;
            }

            $procesados++;
        }

        $mensaje =
            "Proceso terminado. "
            . "Procesados: {$procesados}. "
            . "Errores: {$errores}. "
            . "Saltados: {$saltados}.";

    } catch (Throwable $e) {

        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Importar directo a producción</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
> 
</head>

<body class="bg-light">

<div class="container py-5">

    <div class="card p-4 shadow">

        <h4 class="mb-3">
            Importar Excel directo a producción
        </h4>

        <div class="alert alert-info">
           
        </div>

        <?php if ($mensaje): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($erroresDetalle)): ?>

            <div class="alert alert-warning">

                <strong>Primeros errores:</strong>

                <ul>
                    <?php foreach (array_slice($erroresDetalle, 0, 30) as $err): ?>
                        <li><?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>

                <?php if (count($erroresDetalle) > 30): ?>
                    <p>
                        Hay más errores, solo se muestran los primeros 30.
                    </p>
                <?php endif; ?>

            </div>

        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">

            <div class="mb-3">

                <label class="form-label">
                    CODALMACEN
                </label>

                <input
                    type="text"
                    name="codalmacen"
                    class="form-control"
                    placeholder="Ej: 15"
                    required
                >

            </div>

            <div class="mb-3">

                <label class="form-label">
                    Excel de tienda
                </label>

                <input
                    type="file"
                    name="archivo"
                    class="form-control"
                    accept=".xlsx,.xls"
                    required
                >

            </div>

            <button class="btn btn-primary">
                Importar a producción
            </button>

        </form>

    </div>

</div>

</body>
</html>