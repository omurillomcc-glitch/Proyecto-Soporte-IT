<?php
declare(strict_types=1);

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| INICIAR SESIÓN SI NO ESTÁ INICIADA
|--------------------------------------------------------------------------
| Si ya está iniciada desde index.php/auth.php, no cambiamos el nombre.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* =========================================================
   2) ARCHIVOS NECESARIOS
   ========================================================= */
require_once __DIR__ . '/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/* =========================================================
   3) VALIDAR LOGIN
   ========================================================= */
require_login();
$me = me();

/* =========================================================
   4) FUNCIONES
   ========================================================= */
function h_view(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function exh_normalizar_pais(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

function exh_get_tiendas_permitidas(mysqli $conn, $sqlsrvConn, array $me): array
{
    $miId   = (int)($me['id'] ?? 0);
    $miRol  = trim((string)($me['rol'] ?? ''));
    $miPais = exh_normalizar_pais((string)($me['pais_code'] ?? ''));

    $rows = [];

    if ($miRol === 'super_admin') {
        if ($miPais === 'NI') {
            $sql = "
                SELECT DISTINCT
                    LTRIM(RTRIM(CODALMACEN)) AS codalmacen,
                    LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen,
                    LTRIM(RTRIM(POBLACION)) AS zona,
                    'Nicaragua' AS pais,
                    'ACANICARAGUA2' AS base_datos
                FROM ACANICARAGUA2.dbo.almacen
                WHERE POBLACION IS NOT NULL
                  AND LTRIM(RTRIM(POBLACION)) <> ''
                  AND LTRIM(RTRIM(CODALMACEN)) LIKE '[0-9][0-9]'
                  AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
                ORDER BY CODALMACEN ASC
            ";
        } else {
            $sql = "
                SELECT DISTINCT
                    LTRIM(RTRIM(CODALMACEN)) AS codalmacen,
                    LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen,
                    LTRIM(RTRIM(POBLACION)) AS zona,
                    'Honduras' AS pais,
                    'DETODO' AS base_datos
                FROM DETODO.dbo.almacen
                WHERE POBLACION IS NOT NULL
                  AND LTRIM(RTRIM(POBLACION)) <> ''
                  AND LTRIM(RTRIM(CODALMACEN)) LIKE '[0-9][0-9]'
                  AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
                ORDER BY CODALMACEN ASC
            ";
        }

        $stmt = sqlsrv_query($sqlsrvConn, $sql);

        if ($stmt === false) {
            return [];
        }

        while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $cod = trim((string)($r['codalmacen'] ?? ''));

            if ($cod === '') {
                continue;
            }

            $rows[$cod] = [
                'codalmacen'    => $cod,
                'nombrealmacen' => trim((string)($r['nombrealmacen'] ?? '')),
                'zona'          => trim((string)($r['zona'] ?? '')),
                'pais'          => trim((string)($r['pais'] ?? '')),
                'base_datos'    => trim((string)($r['base_datos'] ?? '')),
            ];
        }

        sqlsrv_free_stmt($stmt);

        return array_values($rows);
    }

    if ($miRol === 'admin_zona' || $miRol === 'tienda') {
        $sql = "
            SELECT DISTINCT
                ut.codalmacen,
                ut.nombrealmacen,
                ut.zona,
                ut.pais,
                ut.base_datos
            FROM usuario_tienda ut
            WHERE ut.usuario_id = ?
              AND TRIM(COALESCE(ut.codalmacen, '')) <> ''
            ORDER BY codalmacen ASC
        ";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            return [];
        }

        $stmt->bind_param("i", $miId);
        $stmt->execute();

        $res = $stmt->get_result();

        while ($r = $res->fetch_assoc()) {
            $cod = trim((string)($r['codalmacen'] ?? ''));

            if ($cod === '') {
                continue;
            }

            $rows[$cod] = [
                'codalmacen'    => $cod,
                'nombrealmacen' => trim((string)($r['nombrealmacen'] ?? '')),
                'zona'          => trim((string)($r['zona'] ?? '')),
                'pais'          => trim((string)($r['pais'] ?? '')),
                'base_datos'    => trim((string)($r['base_datos'] ?? '')),
            ];
        }

        $stmt->close();

        return array_values($rows);
    }

    return [];
}

function build_page_url_modulo1(int $targetPage, string $baseQueryString): string
{
    $params = [];

    if ($baseQueryString !== '') {
        parse_str($baseQueryString, $params);
    }

    $params['vista'] = 'modulo1';
    $params['page'] = $targetPage;

    return 'index.php?' . http_build_query($params);
}

/* =========================================================
   5) REGIÓN
   ========================================================= */
$paisCode = strtoupper(trim((string)($_SESSION['pais_code'] ?? '')));
$region   = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';

/* =========================================================
   6) FILTROS Y TIENDAS
   ========================================================= */
$filters = exhibicion_filters_from_get();

$tiendasPermitidas = exh_get_tiendas_permitidas(
    $conn,
    $sqlsrv_conn_exhibicion,
    $me
);

$filtroCodAlmacen = trim((string)($filters['codalmacen'] ?? ''));

/* =========================================================
   7) PAGINACIÓN
   ========================================================= */
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)($_GET['per_page'] ?? 500);

if (!in_array($perPage, [500, 1000, 2000], true)) {
    $perPage = 500;
}

/* =========================================================
   8) CONSULTA BASE
   ========================================================= */
[$baseSql, $baseParams, $ctx] = exhibicion_build_query($filters);

$offset = ($page - 1) * $perPage;
$fetchRows = $perPage + 1;

/*
|--------------------------------------------------------------------------
| PASO 8.1: ORDENAMIENTO CORRECTO
|--------------------------------------------------------------------------
| - Si NO se seleccionó A→Z / Z→A:
|   ordena Inventario Tienda de mayor a menor.
|
| - Si SÍ se seleccionó A→Z / Z→A:
|   ordena por la columna seleccionada.
|--------------------------------------------------------------------------
*/
$ordenCampo = strtolower(trim((string)($_GET['orden_campo'] ?? '')));
$ordenDir   = strtolower(trim((string)($_GET['orden_dir'] ?? '')));

$columnasOrdenPermitidas = [
    'referencia'        => 'Q.REFERENCIA',
    'descripcion'       => 'Q.DESCRIPCION',
    'departamento'      => 'Q.DEPARTAMENTO',
    'seccion'           => 'Q.SECCION',
    'familia'           => 'Q.FAMILIA',
    'codbarras'         => 'Q.CODBARRAS',
    'plu'               => 'Q.PLU',
    'inventario_tienda' => 'Q.INVENTARIO_TIENDA',
    'exhibicion'        => 'Q.EXHIBICION',
     'uxc'               => 'Q.UXC',
    'codarticulo'       => 'Q.CODARTICULO',
    'codalmacen'        => 'Q.CODALMACEN',
];

/*
|--------------------------------------------------------------------------
| CASO 1: SIN ORDEN SELECCIONADO
|--------------------------------------------------------------------------
*/
if (
    $ordenCampo === '' ||
    $ordenDir === '' ||
    !isset($columnasOrdenPermitidas[$ordenCampo]) ||
    !in_array($ordenDir, ['asc', 'desc'], true)
) {
    $orderByFinal = "
        Q.INVENTARIO_TIENDA DESC,
        Q.REFERENCIA ASC,
        Q.CODALMACEN ASC,
        Q.CODARTICULO ASC
    ";
}

/*
|--------------------------------------------------------------------------
| CASO 2: CON A→Z / Z→A SELECCIONADO
|--------------------------------------------------------------------------
*/
else {
    $ordenPrincipal = $columnasOrdenPermitidas[$ordenCampo] . ' ' . strtoupper($ordenDir);

    $ordenSecundario = [];

    if ($ordenCampo !== 'inventario_tienda') {
        $ordenSecundario[] = 'Q.INVENTARIO_TIENDA DESC';
    }

    if ($ordenCampo !== 'referencia') {
        $ordenSecundario[] = 'Q.REFERENCIA ASC';
    }

    if ($ordenCampo !== 'codalmacen') {
        $ordenSecundario[] = 'Q.CODALMACEN ASC';
    }

    if ($ordenCampo !== 'codarticulo') {
        $ordenSecundario[] = 'Q.CODARTICULO ASC';
    }

    $orderByFinal = implode(",\n        ", array_merge([$ordenPrincipal], $ordenSecundario));
}

$dataSql = $baseSql . "
    ORDER BY
        $orderByFinal
    OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
";

$dataParams = array_merge($baseParams, [$offset, $fetchRows]);

$stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $dataSql, $dataParams, [
    "QueryTimeout" => 300
]);

if ($stmt === false) {
    die('<pre>Error en consulta: ' . print_r(sqlsrv_errors(), true) . '</pre>');
}

$rows = [];

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $rows[] = $row;
}

sqlsrv_free_stmt($stmt);

$hasNext = count($rows) > $perPage;

if ($hasNext) {
    array_pop($rows);
}

$hasPrev = $page > 1;

$queryWithoutPage = $_GET;
unset($queryWithoutPage['page']);

$currentQueryString = http_build_query($_GET);
$baseQueryString = http_build_query($queryWithoutPage);

$rol = strtolower(trim($ctx['rol'] ?? ''));
?>

<div class="exh-wrap">

    <?php if (isset($_GET['ok']) && $_GET['ok'] === '1'): ?>
        <div class="exh-alert exh-alert-ok">
            <i class="bi bi-check-circle-fill"></i>
            <span>Registro guardado correctamente.</span>
        </div>
    <?php endif; ?>

    <?php if (!empty($_GET['err'])): ?>
        <div class="exh-alert exh-alert-err">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <span><?= h_view($_GET['err']) ?></span>
        </div>
    <?php endif; ?>

    <div class="exh-panel">

        <section class="exh-header">
            <div>
                <p>Consulta inventario por tienda, filtra información y actualiza la exhibición de forma rápida.</p>
            </div>

            <div class="exh-top-actions">
                <span class="region-badge"><?= h_view($region) ?></span>

                <a
                    id="btnExportar"
                    href="exhibiciontotal/exportar_excel.php<?= $baseQueryString !== '' ? '?' . h_view($baseQueryString) : '' ?>"
                    class="exh-btn-label exh-btn-success"
                    title="Exportar Excel"
                >
                    <i class="bi bi-file-earmark-excel-fill"></i>
                    <span>Exportar</span>
                </a>

                <a
                    id="btnLimpiar"
                    href="index.php?vista=modulo1"
                    class="exh-btn-icon exh-btn-light"
                    title="Limpiar filtros"
                >
                    <i class="bi bi-arrow-clockwise"></i>
                </a>
            </div>
        </section>

        <section class="exh-card">

            <h2 class="exh-card-title">Listado de exhibición</h2>

            <div class="exh-toolbar">

                <form method="get" action="index.php" class="exh-mini-form" id="formPerPage">
                    <input type="hidden" name="vista" value="modulo1">

                    <?php foreach ($_GET as $k => $v): ?>
                        <?php if ($k !== 'per_page' && $k !== 'page' && $k !== 'vista'): ?>
                            <input type="hidden" name="<?= h_view($k) ?>" value="<?= h_view((string)$v) ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>

                    <label for="per_page">Registros por página</label>

                    <select name="per_page" id="per_page">
                        <option value="500" <?= $perPage === 500 ? 'selected' : '' ?>>500</option>
                        <option value="1000" <?= $perPage === 1000 ? 'selected' : '' ?>>1000</option>
                        <option value="2000" <?= $perPage === 2000 ? 'selected' : '' ?>>2000</option>
                    </select>
                </form>

                <div class="exh-summary">
                    <span>Página <strong><?= $page ?></strong></span>
                    <span>Mostrando <strong><?= count($rows) ?></strong> registros<?= $hasNext ? ' · Hay más resultados' : '' ?></span>
                </div>

               <button
    type="submit"
    form="formMasivoExhibicion"
    id="btnGuardarMasivo"
    class="btn-masivo-mini"
>
    <i class="bi bi-save-fill"></i>
    Guardar Masivo
</button>

            </div>

            <div class="exh-table-shell" id="tablaExhibicion">

                <form method="get" id="formFiltros" action="index.php">
                    <input type="hidden" name="vista" value="modulo1">
                    <input type="hidden" name="per_page" value="<?= h_view((string)$perPage) ?>">

                    <input type="hidden" name="region" value="<?= h_view($filters['region'] ?? '') ?>">
                    <input type="hidden" name="referencia" value="<?= h_view($filters['referencia'] ?? '') ?>">
                    <input type="hidden" name="descripcion" value="<?= h_view($filters['descripcion'] ?? '') ?>">
                    <input type="hidden" name="departamento" value="<?= h_view($filters['departamento'] ?? '') ?>">
                    <input type="hidden" name="seccion" value="<?= h_view($filters['seccion'] ?? '') ?>">
                    <input type="hidden" name="familia" value="<?= h_view($filters['familia'] ?? '') ?>">
                    <input type="hidden" name="codbarras" value="<?= h_view($filters['codbarras'] ?? '') ?>">
                    <input type="hidden" name="plu" value="<?= h_view($filters['plu'] ?? '') ?>">
                    <input type="hidden" name="inventario_tienda" value="<?= h_view($filters['inventario_tienda'] ?? '') ?>">
                    <input type="hidden" name="exhibicion" value="<?= h_view($filters['exhibicion'] ?? '') ?>">
                    <input type="hidden" name="uxc" value="<?= h_view($filters['uxc'] ?? '') ?>">
                    <input type="hidden" name="codarticulo" value="<?= h_view($filters['codarticulo'] ?? '') ?>">
                    <input type="hidden" name="codalmacen" value="<?= h_view($filters['codalmacen'] ?? '') ?>">
                    <input type="hidden" name="orden_campo" id="orden_campo" value="<?= h_view($ordenCampo) ?>">
                    <input type="hidden" name="orden_dir" id="orden_dir" value="<?= h_view($ordenDir) ?>">
                </form>

                <!-- =====================================================
                     FILTRO TIPO EXCEL
                     ===================================================== -->
                <div id="excelMenu" class="excel-menu" hidden>
                    <div class="excel-menu-head">
                        <strong id="excelMenuTitle">Filtrar</strong>

                        <button type="button" id="excelMenuClose" class="excel-menu-close" title="Cerrar">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <input type="hidden" id="excelField">

                    <div class="excel-menu-body">

                        <input
                            type="text"
                            id="excelSearch"
                            class="excel-menu-input"
                            placeholder="Buscar..."
                        >

                        <label class="excel-check-all">
                            <input type="checkbox" id="excelSelectAll">
                            Seleccionar todo
                        </label>

                        <div id="excelOptions" class="excel-options"></div>

                        <div class="excel-menu-actions">
                            <button type="button" id="excelApply" class="exh-btn-label exh-btn-primary">
                                <i class="bi bi-check2"></i>
                                <span>Aplicar</span>
                            </button>

                            <button type="button" id="excelClear" class="exh-btn-label exh-btn-light">
                                <i class="bi bi-eraser"></i>
                                <span>Limpiar</span>
                            </button>
                        </div>

                    </div>
                </div>

                <script>
                    const TIENDAS_PERMITIDAS = <?= json_encode($tiendasPermitidas, JSON_UNESCAPED_UNICODE) ?>;
                </script>

                <form
                    id="formMasivoExhibicion"
                    method="post"
                    action="/exhibicion_DT/exhibiciontotal/guardar_exhibicion_masivo_v2.php"
                >
                    <input type="hidden" name="return_qs" value="<?= h_view($currentQueryString) ?>">
                    <input type="hidden" name="items_json" id="items_json" value="">
                    <input type="hidden" name="masivo_version" value="V2_UNICO">
                </form>

                <table class="exh-table">
                    <thead>
                        <tr>
                            <!-- =====================================================
                                 PASO: CHECKBOX MASIVO PRIMERO
                                 Sirve para seleccionar todos los registros visibles.
                            ====================================================== -->
                            <th class="center" title="Seleccionar todos">
                                <input
                                    type="checkbox"
                                    id="checkTodosMasivo"
                                    title="Seleccionar todos los registros visibles"
                                >
                            </th>

                            <!-- =====================================================
                                 PASO: COLUMNA DE NUMERACIÓN DESPUÉS
                              
                            ====================================================== -->
                            <th class="exh-col-num" title="Número de fila">N°</th>

                            <?php
                            $headers = [
                                'referencia'        => 'Referencia',
                                'descripcion'       => 'Descripción',
                                'departamento'      => 'Departamento',
                                'seccion'           => 'Sección',
                                'familia'           => 'Familia',
                                'codbarras'         => 'Cod Barras',
                                'plu'               => 'PLU',
                                'inventario_tienda' => 'Inventario Tienda',
                                'exhibicion'        => 'Exhibición',
                                 'uxc'               => 'UXC',
                               /* 'codarticulo'       => 'Codarticulo',*/
                            ];

                            if ($rol === 'admin_zona' || $rol === 'super_admin') {
                                $headers['codalmacen'] = 'Almacén';
                                }
                            ?>

                            <?php foreach ($headers as $field => $label): ?>
                                <th>
                                    <div class="exh-th-wrap">
                                        <span><?= h_view($label) ?></span>

                                        <button
                                            type="button"
                                            class="exh-filter-trigger <?= ($filters[$field] ?? '') !== '' ? 'is-active' : '' ?>"
                                            data-field="<?= h_view($field) ?>"
                                            data-label="<?= h_view($label) ?>"
                                            title="Filtrar <?= h_view($label) ?>"
                                        >
                                            <i class="bi bi-funnel-fill"></i>
                                        </button>
                                    </div>
                                </th>
                            <?php endforeach; ?>

                            <th>Guardar</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (empty($rows)): ?>
                            <tr>
                                <td colspan="15" class="exh-empty">
                                    <i class="bi bi-inbox"></i> No se encontraron registros.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php
                            /*
                            |--------------------------------------------------------------------------
                            | NUMERACIÓN DE FILAS
                            |--------------------------------------------------------------------------
                            | Página 1: 1,2,3...
                            | Página 2: continúa según el offset.
                            |--------------------------------------------------------------------------
                            */
                            $numeroFila = $offset + 1;
                            ?>

                            <?php foreach ($rows as $i => $row): ?>
                                <?php
                                $formId = 'frm_exh_' . md5(
                                    (string)($row['CODARTICULO'] ?? '') . '|' .
                                    (string)($row['CODBARRAS'] ?? '') . '|' .
                                    (string)($row['PLU'] ?? '') . '|' .
                                    (string)($row['CODALMACEN'] ?? '')
                                );
                                ?>

                                <tr>
    <!-- =====================================================
         CHECKBOX MASIVO PRIMERO
         Aquí también van los datos ocultos que se envían al guardar masivo.
    ====================================================== -->
    <td class="center" data-label="Seleccionar">
        <input
            form="formMasivoExhibicion"
            type="checkbox"
            class="js-check-masivo"
            name="items[<?= $i ?>][seleccionado]"
            value="1"
            title="Seleccionar este registro"
        >

        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][region]" value="<?= h_view($row['REGION'] ?? $region) ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codalmacen]" value="<?= h_view($row['CODALMACEN'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codarticulo]" value="<?= h_view($row['CODARTICULO'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codbarras]" value="<?= h_view($row['CODBARRAS'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][plu]" value="<?= h_view($row['PLU'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][uxc]" value="<?= h_view((string)($row['UXC'] ?? 0)) ?>">
        

        <input
            form="formMasivoExhibicion"
            type="hidden"
            id="bulk_exhibicion_<?= $i ?>"
            name="items[<?= $i ?>][exhibicion]"
            value="<?= h_view((string)($row['EXHIBICION'] ?? 0)) ?>"
        >
    </td>

    <!-- =====================================================
         NÚMERO DE FILA DESPUÉS DEL CHECKBOX
    ====================================================== -->
    <td class="exh-col-num" data-label="N°">
        <span><?= $numeroFila++ ?></span>
    </td>

    <td 
        data-field="referencia"
        title="<?= h_view($row['REFERENCIA'] ?? '') ?>"
    >
        <?= h_view($row['REFERENCIA'] ?? '') ?>
    </td>

    <td 
        data-field="descripcion"
        title="<?= h_view($row['DESCRIPCION'] ?? '') ?>"
    >
        <?= h_view($row['DESCRIPCION'] ?? '') ?>
    </td>

    <td 
        data-field="departamento"
        title="<?= h_view($row['DEPARTAMENTO'] ?? '') ?>"
    >
        <?= h_view($row['DEPARTAMENTO'] ?? '') ?>
    </td>

    <td 
        data-field="seccion"
        title="<?= h_view($row['SECCION'] ?? '') ?>"
    >
        <?= h_view($row['SECCION'] ?? '') ?>
    </td>

    <td 
        data-field="familia"
        title="<?= h_view($row['FAMILIA'] ?? '') ?>"
    >
        <?= h_view($row['FAMILIA'] ?? '') ?>
    </td>

    <td 
        data-field="codbarras"
        title="<?= h_view($row['CODBARRAS'] ?? '') ?>"
    >
        <?= h_view($row['CODBARRAS'] ?? '') ?>
    </td>

    <td 
        data-field="plu"
        title="<?= h_view($row['PLU'] ?? '') ?>"
    >
        <?= h_view($row['PLU'] ?? '') ?>
    </td>

    <td 
        data-field="inventario_tienda"
        class="center"
        title="<?= h_view((string)($row['INVENTARIO_TIENDA'] ?? 0)) ?>"
    >
        <?= h_view((string)($row['INVENTARIO_TIENDA'] ?? 0)) ?>
    </td>

    <td data-field="exhibicion" class="center align-middle">
        <form
            id="<?= h_view($formId) ?>"
            method="post"
            action="exhibiciontotal/guardar_exhibicion.php"
            class="js-form-guardar exh-inline-edit"
        >
            <input type="hidden" name="accion" value="editar">
            <input type="hidden" name="codarticulo" value="<?= h_view($row['CODARTICULO'] ?? '') ?>">
            <input type="hidden" name="codbarras" value="<?= h_view($row['CODBARRAS'] ?? '') ?>">
            <input type="hidden" name="plu" value="<?= h_view($row['PLU'] ?? '') ?>">
            <input type="hidden" name="codalmacen" value="<?= h_view($row['CODALMACEN'] ?? '') ?>">
            <input type="hidden" name="return_qs" value="<?= h_view($currentQueryString) ?>">
        </form>

        <input
            form="<?= h_view($formId) ?>"
            type="text"
            name="exhibicion"
            value="<?= h_view((string)($row['EXHIBICION'] ?? '')) ?>"
            required
            maxlength="5"
            inputmode="numeric"
            autocomplete="off"
            class="form-control form-control-sm text-center js-only-number exh-input-mini js-exhibicion-masivo"
            data-bulk-index="<?= $i ?>"
            oninput="this.value = this.value.replace(/\D/g, '').slice(0,5); const h=document.getElementById('bulk_exhibicion_<?= $i ?>'); if(h){h.value=this.value;}"
            onkeypress="return /[0-9]/.test(event.key);"
            onpaste="event.preventDefault();"
        >
    </td>

<td 
    data-field="uxc"
    class="center"
    title="<?= h_view((string)($row['UXC'] ?? 0)) ?>"
>
    <?= h_view((string)($row['UXC'] ?? 0)) ?>
</td>




    <!--
    <td 
        data-field="codarticulo"
        class="center"
        title="<?= h_view($row['CODARTICULO'] ?? '') ?>"
    >
        <?= h_view($row['CODARTICULO'] ?? '') ?>
    </td>
-->
    
  <?php if ($rol === 'admin_zona' || $rol === 'super_admin'): ?>
    <td 
        data-field="codalmacen"
        class="center"
        title="<?= h_view($row['ALMACEN'] ?? $row['CODALMACEN'] ?? '') ?>"
    >
        <?= h_view($row['ALMACEN'] ?? '') ?>
    </td>
<?php endif; ?>

    <td class="center">
        <button
            form="<?= h_view($formId) ?>"
            type="submit"
            class="exh-btn-icon exh-btn-primary js-btn-guardar"
            title="Guardar"
        >
            <i class="bi bi-save-fill"></i>
        </button>
    </td>
</tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>

            <div class="exh-pagination">
                <?php if ($hasPrev): ?>
                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1(1, $baseQueryString)) ?>" title="Primera">
                        <i class="bi bi-chevron-bar-left"></i>
                    </a>

                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1($page - 1, $baseQueryString)) ?>" title="Anterior">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                <?php endif; ?>

                <span class="active"><?= $page ?></span>

                <?php if ($hasNext): ?>
                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1($page + 1, $baseQueryString)) ?>" title="Siguiente">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                <?php endif; ?>
            </div>

            <!-- =====================================================
                 BOTÓN FLOTANTE DE GUARDADO MASIVO
                 Siempre visible para no subir arriba a guardar.
            ====================================================== -->
            <div class="floating-save-wrap">
                <button
                    type="submit"
                    form="formMasivoExhibicion"
                    id="btnGuardarMasivoFloat"
                    class="floating-save-btn"
                    title="Guardar registros seleccionados"
                >
                    <i class="bi bi-save2-fill"></i>
                    <span>Guardar</span>
                </button>
            </div>


        </section>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | PASO 1: CAPTURAR ELEMENTOS PRINCIPALES
    |--------------------------------------------------------------------------
    */
    const perPage = document.getElementById('per_page');
    const formPerPage = document.getElementById('formPerPage');
    const formFiltros = document.getElementById('formFiltros');

    const excelMenu = document.getElementById('excelMenu');
    const excelMenuTitle = document.getElementById('excelMenuTitle');
    const excelMenuClose = document.getElementById('excelMenuClose');
    const excelField = document.getElementById('excelField');
    const excelSearch = document.getElementById('excelSearch');
    const excelOptions = document.getElementById('excelOptions');
    const excelSelectAll = document.getElementById('excelSelectAll');
    const excelApply = document.getElementById('excelApply');
    const excelClear = document.getElementById('excelClear');

    /*
    |--------------------------------------------------------------------------
    | PASO 1.1: ELEMENTOS DE GUARDADO MASIVO
    |--------------------------------------------------------------------------
    */
    const formMasivo = document.getElementById('formMasivoExhibicion');
    const checkTodosMasivo = document.getElementById('checkTodosMasivo');
    const btnGuardarMasivo = document.getElementById('btnGuardarMasivo');
    const btnGuardarMasivoFloat = document.getElementById('btnGuardarMasivoFloat');

    /*
    |--------------------------------------------------------------------------
    | PASO 1.2: RESTAURAR POSICIÓN DESPUÉS DE GUARDAR
    |--------------------------------------------------------------------------
    | Si guardas en la fila 49 o 50, al recargar vuelve al mismo scroll.
    |--------------------------------------------------------------------------
    */
    const savedScroll = sessionStorage.getItem('scrollTablaExhibicion');

    if (savedScroll !== null) {
        setTimeout(() => {
            window.scrollTo({
                top: parseInt(savedScroll, 10),
                behavior: 'auto'
            });

            sessionStorage.removeItem('scrollTablaExhibicion');
        }, 150);
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 1.3: GUARDAR POSICIÓN ANTES DE ENVIAR FORMULARIOS
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function () {
            sessionStorage.setItem(
                'scrollTablaExhibicion',
                String(window.scrollY)
            );
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 2: CREAR SELECT DE ORDEN A-Z / Z-A AUTOMÁTICAMENTE
    |--------------------------------------------------------------------------
    */
    let excelOrder = document.getElementById('excelOrder');

    if (!excelOrder && excelOptions) {
        excelOrder = document.createElement('select');
        excelOrder.id = 'excelOrder';
        excelOrder.className = 'excel-menu-input';

        excelOrder.innerHTML = `
            <option value="asc">Ordenar A → Z</option>
            <option value="desc">Ordenar Z → A</option>
        `;

        excelOptions.parentNode.insertBefore(excelOrder, excelOptions);
    }

    const triggers = document.querySelectorAll('.exh-filter-trigger');

    /*
    |--------------------------------------------------------------------------
    | PASO 3: BOTÓN CARGANDO
    |--------------------------------------------------------------------------
    */
    function loading(btn, iconHtml) {
        if (!btn) return;

        btn.disabled = true;
        btn.innerHTML = iconHtml;
        btn.style.opacity = '.75';
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 4: SOLO NÚMEROS
    |--------------------------------------------------------------------------
    */
    function sanitizeOnlyNumber(value) {
        return String(value || '').replace(/\D/g, '');
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 5: OBTENER INPUT OCULTO DEL FILTRO
    |--------------------------------------------------------------------------
    */
    function getFilterInput(name) {
        return formFiltros ? formFiltros.querySelector('input[name="' + name + '"]') : null;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 6: CERRAR MENÚ EXCEL
    |--------------------------------------------------------------------------
    */
    function closeExcelMenu() {
        if (!excelMenu) return;
        excelMenu.hidden = true;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 7: OBTENER VALORES YA SELECCIONADOS
    |--------------------------------------------------------------------------
    */
    function getSelectedValues(field) {
        const input = getFilterInput(field);
        const value = input ? input.value.trim() : '';

        if (value === '') {
            return [];
        }

        return value.split('||').filter(v => v.trim() !== '');
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 8: ORDENAR VALORES DEL FILTRO
    |--------------------------------------------------------------------------
    */
    function ordenarValores(values, tipo = 'asc') {
        const arr = Array.from(values)
            .filter(v => String(v || '').trim() !== '');

        if (tipo === 'desc') {
            return arr.sort((a, b) =>
                String(b).localeCompare(String(a), undefined, {
                    numeric: true,
                    sensitivity: 'base'
                })
            );
        }

        return arr.sort((a, b) =>
            String(a).localeCompare(String(b), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 9: OBTENER VALORES DE CUALQUIER COLUMNA
    |--------------------------------------------------------------------------
    */
    function getColumnValues(field) {
        const values = new Set();

        if (field === 'codalmacen') {
            if (typeof TIENDAS_PERMITIDAS !== 'undefined') {
                TIENDAS_PERMITIDAS.forEach(t => {
                    const cod = String(t.codalmacen || '').trim();
                    const nom = String(t.nombrealmacen || '').trim();

                    if (cod !== '') {
                        values.add(nom !== '' ? cod + ' - ' + nom : cod);
                    }
                });
            }

            return ordenarValores(values, excelOrder ? excelOrder.value : 'asc');
        }

        document.querySelectorAll('td[data-field="' + field + '"]').forEach(td => {
            let value = '';

            const input = td.querySelector('input');

            if (input) {
                value = input.value.trim();
            } else if (td.hasAttribute('title')) {
                value = td.getAttribute('title').trim();
            } else {
                value = td.textContent.trim();
            }

            if (value !== '') {
                values.add(value);
            }
        });

        return ordenarValores(values, excelOrder ? excelOrder.value : 'asc');
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 10: PINTAR OPCIONES DEL FILTRO
    |--------------------------------------------------------------------------
    */
    function renderOptions(values, selectedValues = [], field = '') {
        excelOptions.innerHTML = '';

        values.forEach(value => {
            let compareValue = value;

            if (field === 'codalmacen') {
                compareValue = value.split(' - ')[0].trim();
            }

            const checked = selectedValues.includes(compareValue) ? 'checked' : '';

            const label = document.createElement('label');
            label.className = 'excel-option';
            label.dataset.value = String(value).toLowerCase();

            label.innerHTML = `
                <input type="checkbox" class="excel-option-check" value="${value}" ${checked}>
                <span>${value}</span>
            `;

            excelOptions.appendChild(label);
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 11: ABRIR MENÚ DE FILTRO
    |--------------------------------------------------------------------------
    */
   /*
/*
|--------------------------------------------------------------------------
| PASO 11: ABRIR MENÚ DE FILTRO EN EL CENTRO
|--------------------------------------------------------------------------
| El menú aparece centrado en la pantalla.
| Ya no sale pegado a la derecha ni debajo del icono.
|--------------------------------------------------------------------------
*/
function openExcelMenu(btn) {
    if (!excelMenu) return;

    const field = btn.dataset.field || '';
    const label = btn.dataset.label || 'Filtrar';

    excelField.value = field;
    excelMenuTitle.textContent = label;
    excelSearch.value = '';

    const selectedValues = getSelectedValues(field);
    const values = getColumnValues(field);

    renderOptions(values, selectedValues, field);

    excelSelectAll.checked = selectedValues.length > 0 && selectedValues.length === values.length;

    /*
    |--------------------------------------------------------------------------
    | POSICIÓN CENTRADA
    |--------------------------------------------------------------------------
    */
    const menuWidth = 340;
    const menuHeight = 430;

    let left = (window.innerWidth - menuWidth) / 2;
    let top = (window.innerHeight - menuHeight) / 2;

    /*
    |--------------------------------------------------------------------------
    | SEGURIDAD PARA PANTALLAS PEQUEÑAS
    |--------------------------------------------------------------------------
    */
    if (left < 12) {
        left = 12;
    }

    if (top < 12) {
        top = 12;
    }

    excelMenu.style.width = menuWidth + 'px';
    excelMenu.style.left = left + 'px';
    excelMenu.style.top = top + 'px';

    excelMenu.hidden = false;

    setTimeout(() => excelSearch.focus(), 30);
}
    /*
    |--------------------------------------------------------------------------
    | PASO 12: CAMBIAR ORDEN A-Z / Z-A SIN CERRAR EL FILTRO
    |--------------------------------------------------------------------------
    */
    if (excelOrder) {
        excelOrder.addEventListener('change', function () {
            const field = excelField.value;

            if (!field) return;

            const selectedValues = getSelectedValues(field);
            const values = getColumnValues(field);

            renderOptions(values, selectedValues, field);
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 13: VALIDAR INPUTS NUMÉRICOS
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('.js-only-number').forEach(function (input) {
        input.addEventListener('input', function () {
            this.value = sanitizeOnlyNumber(this.value).slice(0, 5);
        });

        input.addEventListener('paste', function (e) {
            e.preventDefault();
        });

        input.addEventListener('keypress', function (e) {
            if (!/[0-9]/.test(e.key)) {
                e.preventDefault();
            }
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 14: GUARDAR INDIVIDUAL
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('.js-form-guardar').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const formId = form.getAttribute('id');
            const inputExh = document.querySelector('input[name="exhibicion"][form="' + formId + '"]');

            if (!inputExh || !/^\d+$/.test(inputExh.value.trim())) {
                e.preventDefault();
                alert('La exhibición debe llevar solo números.');

                if (inputExh) {
                    inputExh.focus();
                }

                return;
            }

            const btn = document.querySelector('.js-btn-guardar[form="' + formId + '"]');
            loading(btn, '<i class="bi bi-hourglass-split"></i>');
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 15: GUARDADO MASIVO CORREGIDO
    |--------------------------------------------------------------------------
    | IMPORTANTE:
    | - Solo valida los registros MARCADOS.
    | - Busca el input de exhibición dentro de la misma fila.
    | - Antes se validaban hidden inputs y por eso daba error.
    |--------------------------------------------------------------------------
    */
    if (checkTodosMasivo) {
        checkTodosMasivo.addEventListener('change', function () {
            document.querySelectorAll('.js-check-masivo').forEach(chk => {
                chk.checked = checkTodosMasivo.checked;
            });
        });
    }

    document.querySelectorAll('.js-check-masivo').forEach(chk => {
        chk.addEventListener('change', function () {
            if (!checkTodosMasivo) return;

            const total = document.querySelectorAll('.js-check-masivo').length;
            const marcados = document.querySelectorAll('.js-check-masivo:checked').length;

            checkTodosMasivo.checked = total > 0 && marcados === total;
            checkTodosMasivo.indeterminate = marcados > 0 && marcados < total;
        });
    });

    if (formMasivo) {
        formMasivo.addEventListener('submit', function (e) {
            e.preventDefault();

            const marcados = Array.from(
                document.querySelectorAll('.js-check-masivo:checked')
            );

            if (marcados.length === 0) {
                alert('Seleccione al menos un registro para guardar.');
                return;
            }

            const registros = [];

            for (const checkbox of marcados) {
                const fila = checkbox.closest('tr');

                if (!fila) {
                    alert('No se pudo identificar una fila seleccionada.');
                    return;
                }

                const coincidencia = checkbox.name.match(
                    /^items\[(\d+)\]\[seleccionado\]$/
                );

                if (!coincidencia) {
                    alert('No se pudo identificar el índice de una fila seleccionada.');
                    return;
                }

                const indice = coincidencia[1];

                const obtenerCampo = function (campo) {
                    const input = fila.querySelector(
                        '[name="items[' + indice + '][' + campo + ']"]'
                    );

                    return input ? input.value.trim() : '';
                };

                const inputExhibicion = fila.querySelector('.js-exhibicion-masivo');

                if (!inputExhibicion) {
                    alert('No se encontró el campo Exhibición en una fila seleccionada.');
                    return;
                }

                const exhibicion = inputExhibicion.value.trim();

                if (exhibicion === '' || !/^\d+$/.test(exhibicion)) {
                    alert('Todos los registros seleccionados deben tener Exhibición numérica.');
                    inputExhibicion.focus();
                    return;
                }

                const registro = {
                    seleccionado: '1',
                    region: obtenerCampo('region'),
                    codalmacen: obtenerCampo('codalmacen'),
                    codarticulo: obtenerCampo('codarticulo'),
                    codbarras: obtenerCampo('codbarras'),
                    plu: obtenerCampo('plu'),
                    uxc: obtenerCampo('uxc'),
                    exhibicion: exhibicion
                };

                if (registro.codalmacen === '' || registro.codbarras === '') {
                    alert(
                        'Una fila seleccionada no tiene CODALMACEN o CODBARRAS. ' +
                        'No se enviará el guardado.'
                    );
                    return;
                }

                registros.push(registro);
            }

            const inputJson = document.getElementById('items_json');

            if (!inputJson) {
                alert('No se encontró el campo interno items_json.');
                return;
            }

            /*
            |------------------------------------------------------------------
            | ENVIAR LAS FILAS MARCADAS EN UNA SOLA VARIABLE JSON
            |------------------------------------------------------------------
            | Esto evita max_input_vars y permite guardar filas ubicadas al
            | inicio, en medio o al final de los 1000 registros.
            |------------------------------------------------------------------
            */
            inputJson.value = JSON.stringify(registros);

            /*
            |------------------------------------------------------------------
            | DESACTIVAR LOS CAMPOS ITEMS ANTIGUOS
            |------------------------------------------------------------------
            | El servidor recibirá únicamente return_qs + items_json.
            |------------------------------------------------------------------
            */
            document.querySelectorAll('[name^="items["]').forEach(function (campo) {
                campo.disabled = true;
            });

            if (btnGuardarMasivo) {
                loading(
                    btnGuardarMasivo,
                    '<i class="bi bi-hourglass-split"></i>' +
                    '<span>Guardando ' + registros.length + '...</span>'
                );
            }

            if (btnGuardarMasivoFloat) {
                loading(
                    btnGuardarMasivoFloat,
                    '<i class="bi bi-hourglass-split"></i>' +
                    '<span>Guardando ' + registros.length + '...</span>'
                );
            }

            HTMLFormElement.prototype.submit.call(formMasivo);
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 16: PAGINACIÓN
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('.js-page-link').forEach(function (link) {
        link.addEventListener('click', function () {
            link.style.pointerEvents = 'none';
            link.style.opacity = '.75';
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 17: CAMBIAR REGISTROS POR PÁGINA
    |--------------------------------------------------------------------------
    */
    if (perPage && formPerPage) {
        perPage.addEventListener('change', function () {
            formPerPage.submit();
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 18: ABRIR FILTRO DESDE CUALQUIER COLUMNA
    |--------------------------------------------------------------------------
    */
    triggers.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            openExcelMenu(btn);
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 19: NORMALIZAR TEXTO PARA BUSCAR
    |--------------------------------------------------------------------------
    */
    function normalizarFiltroTexto(texto) {
        return String(texto || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 20: BUSCADOR DENTRO DEL FILTRO
    |--------------------------------------------------------------------------
    */
    if (excelSearch) {
        excelSearch.addEventListener('input', function () {
            const search = normalizarFiltroTexto(this.value);

            document.querySelectorAll('.excel-option').forEach(option => {
                const value = normalizarFiltroTexto(option.textContent || '');
                option.style.display = value.includes(search) ? 'flex' : 'none';
            });
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 21: SELECCIONAR TODO DEL FILTRO
    |--------------------------------------------------------------------------
    */
    if (excelSelectAll) {
        excelSelectAll.addEventListener('change', function () {
            document.querySelectorAll('.excel-option').forEach(option => {
                if (option.style.display !== 'none') {
                    const check = option.querySelector('.excel-option-check');

                    if (check) {
                        check.checked = excelSelectAll.checked;
                    }
                }
            });
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 22: APLICAR FILTRO
    |--------------------------------------------------------------------------
    */
    if (excelApply) {
        excelApply.addEventListener('click', function () {
            const field = excelField.value;
            const input = getFilterInput(field);

            if (!input || !formFiltros) return;

            const selected = [];

            document.querySelectorAll('.excel-option-check:checked').forEach(check => {
                let value = check.value;

                if (field === 'codalmacen') {
                    value = value.split(' - ')[0].trim();
                }

                selected.push(value);
            });

            if (selected.length > 0) {
                input.value = selected.join('||');
            } else {
                const textoBuscado = excelSearch.value.trim();
                input.value = textoBuscado !== '' ? '__LIKE__' + textoBuscado : '';
            }

            const inputOrdenCampo = document.getElementById('orden_campo');
            const inputOrdenDir = document.getElementById('orden_dir');

            if (inputOrdenCampo && inputOrdenDir && excelOrder) {
                inputOrdenCampo.value = field;
                inputOrdenDir.value = excelOrder.value;
            }

            formFiltros.submit();
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 23: LIMPIAR FILTRO
    |--------------------------------------------------------------------------
    */
    if (excelClear) {
        excelClear.addEventListener('click', function () {
            const field = excelField.value;
            const input = getFilterInput(field);

            if (!input || !formFiltros) return;

            input.value = '';
            formFiltros.submit();
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 24: CERRAR MENÚ
    |--------------------------------------------------------------------------
    */
    if (excelMenuClose) {
        excelMenuClose.addEventListener('click', closeExcelMenu);
    }

    document.addEventListener('click', function (e) {
        if (!excelMenu || excelMenu.hidden) return;

        if (!excelMenu.contains(e.target) && !e.target.closest('.exh-filter-trigger')) {
            closeExcelMenu();
        }
    });

    window.addEventListener('resize', closeExcelMenu);

    if (excelMenu) {
        excelMenu.addEventListener('wheel', function (e) {
            e.stopPropagation();
        });
    }

    if (excelOptions) {
        excelOptions.addEventListener('wheel', function (e) {
            e.stopPropagation();
        });
    }

});
</script>

<style>
/* =========================================================
   PASO 1: VARIABLES GENERALES DEL DISEÑO
========================================================= */
:root {
    --card: #ffffff;
    --line: #e6ecf4;
    --line-2: #d7e0eb;
    --text: #0f172a;
    --muted: #64748b;
    --primary: #5b5ce9;
    --primary-dark: #4b4cd8;
    --gray-btn: #f1f5f9;
}

/* =========================================================
   PASO 2: CONFIGURACIÓN GENERAL
========================================================= */
* {
    box-sizing: border-box;
}

/* =========================================================
   PASO 3: CONTENEDOR GENERAL
   zoom agranda toda la vista.
   Si se mira demasiado grande, cambia 1.10 por 1.05.
========================================================= */
.exh-wrap {
  
    padding: 2px;
    background: transparent;
}

.exh-panel {
    background: transparent !important;
    border-color: transparent !important;
    box-shadow: none !important;
}

/* =========================================================
   PASO 4: ENCABEZADO SUPERIOR
========================================================= */
.exh-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    border: 1px solid var(--line);
    background: #fff;
    border-radius: 24px;
    padding: 22px 24px;
    margin-bottom: 18px;
}

.exh-header p {
    margin: 0;
    color: var(--muted);
    font-size: 15px;
}

.exh-top-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

/* =========================================================
   PASO 5: BOTONES GENERALES
========================================================= */
.exh-btn-icon,
.exh-btn-label {
    border: none;
    cursor: pointer;
    transition: .18s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
}

.exh-btn-icon {
    width: 30px;
    height: 30px;
    border-radius: 9px;
    font-size: 12px;
}

.exh-btn-label {
    gap: 8px;
    padding: 10px 16px;
    border-radius: 12px;
    font-size: 14px;
}

.exh-btn-primary {
    background: var(--primary);
    color: #fff;
}

.exh-btn-primary:hover {
    background: var(--primary-dark);
    color: #fff;
}

.exh-btn-success {
    background: #10b981;
    color: #fff;
}

.exh-btn-success:hover {
    background: #059669;
    color: #fff;
}

.exh-btn-light {
    background: var(--gray-btn);
    color: #334155;
    border: 1px solid var(--line);
}

/* =========================================================
   PASO 6: TARJETAS
========================================================= */
.exh-card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 22px;
    padding: 18px;
}

.exh-card-title {
    margin: 0 0 16px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--line);
    font-size: 18px;
    font-weight: 900;
    color: #0b1b46;
}

/* =========================================================
   PASO 7: BARRA SUPERIOR DE LA TABLA
========================================================= */
.exh-toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 14px;
}

.exh-mini-form {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.exh-mini-form label {
    color: var(--muted);
    font-size: 15px;
    font-weight: 700;
}

.exh-mini-form select {
    border: 1px solid var(--line-2);
    border-radius: 12px;
    padding: 10px 14px;
    background: #fff;
    outline: none;
    font-size: 15px;
}

.exh-summary {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
    color: var(--muted);
    font-size: 15px;
}

.exh-summary strong {
    color: var(--text);
}

/* =========================================================
   PASO 8: BOTÓN GUARDAR MASIVO SUPERIOR
========================================================= */
.btn-masivo-wrap {
    width: 100%;
    display: flex;
    justify-content: flex-end;
    margin: 0 0 10px;
}

#btnGuardarMasivo,
.btn-masivo-mini {
    border: none !important;
    background: var(--primary) !important;
    color: #fff !important;
    border-radius: 12px !important;
    padding: 9px 15px !important;
    font-size: 13px !important;
    font-weight: 900 !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 7px !important;
    box-shadow: 0 5px 12px rgba(91, 92, 233, .22) !important;
    white-space: nowrap !important;
}

#btnGuardarMasivo:hover,
.btn-masivo-mini:hover {
    background: var(--primary-dark) !important;
}

/* =========================================================
   PASO 9: CONTENEDOR DE TABLA
   IMPORTANTE:
   overflow-y visible permite que los filtros no se corten.
========================================================= */
.exh-table-shell {
    width: 100%;
    overflow-x: auto !important;
    overflow-y: visible !important;
    border-radius: 18px;
    position: relative;
    -webkit-overflow-scrolling: touch;
}

/* =========================================================
   PASO 10: TABLA PRINCIPAL
   min-width controla qué tan amplia se mira.
========================================================= */
.exh-table {
    width: 100% !important;
    min-width: 1320px !important;
    table-layout: fixed !important;
    border-collapse: collapse !important;
    background: #fff;
}

/* =========================================================
   PASO 11: ENCABEZADOS DE TABLA
========================================================= */
.exh-table thead {
    position: relative !important;
    z-index: 50 !important;
}

.exh-table thead th {
    background: #edf2ff !important;
    color: #0b1b46 !important;
    font-size: 13px !important;
    font-weight: 900 !important;
    padding: 10px 6px !important;
    white-space: normal !important;
    vertical-align: middle !important;
    border-bottom: 1px solid var(--line);
    position: sticky !important;
    top: 0;
    z-index: 60 !important;
    text-align: center;
    overflow: visible !important;
}

/* =========================================================
   PASO 12: CELDAS DE TABLA
========================================================= */
.exh-table tbody td {
    background: #fff !important;
    font-size: 13px !important;
    padding: 10px 6px !important;
    white-space: normal !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    word-break: break-word !important;
    vertical-align: middle !important;
    line-height: 1.35 !important;
    border-top: 1px solid var(--line);
    border-bottom: 1px solid var(--line);
}

.exh-table tbody tr:hover td {
    background: #f8fafc !important;
}

/* =========================================================
   PASO 13: COLUMNA 1 - CHECKBOX
========================================================= */
.exh-table th:nth-child(1),
.exh-table td:nth-child(1) {
    width: 44px !important;
    min-width: 44px !important;
    max-width: 44px !important;
    text-align: center !important;
}

/* =========================================================
   PASO 14: COLUMNA 2 - NUMERACIÓN
========================================================= */
.exh-table th:nth-child(2),
.exh-table td:nth-child(2),
.exh-table .exh-col-num {
    width: 55px !important;
    min-width: 55px !important;
    max-width: 55px !important;
    text-align: center !important;
}

.exh-col-num span {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    margin: auto;
    border-radius: 10px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 13px;
    font-weight: 900;
}

/* =========================================================
   PASO 15: COLUMNA 3 - REFERENCIA
========================================================= */
.exh-table th:nth-child(3),
.exh-table td[data-field="referencia"] {
    width: 100px !important;
    min-width: 100px !important;
    max-width: 100px !important;
    white-space: normal !important;
}

/* =========================================================
   PASO 16: COLUMNA 4 - DESCRIPCIÓN
========================================================= */
.exh-table th:nth-child(4),
.exh-table td[data-field="descripcion"] {
    width: 275px !important;
    min-width: 275px !important;
    max-width: 275px !important;
    white-space: normal !important;
    overflow: visible !important;
    text-overflow: unset !important;
    word-break: break-word !important;
}

/* =========================================================
   PASO 17: COLUMNA 5 - DEPARTAMENTO
========================================================= */
.exh-table th:nth-child(5),
.exh-table td[data-field="departamento"] {
    width: 120px !important;
    min-width: 120px !important;
    max-width: 120px !important;
}

/* =========================================================
   PASO 18: COLUMNA 6 - SECCIÓN
========================================================= */
.exh-table th:nth-child(6),
.exh-table td[data-field="seccion"] {
    width: 120px !important;
    min-width: 120px !important;
    max-width: 120px !important;
}

/* =========================================================
   PASO 19: COLUMNA 7 - FAMILIA
========================================================= */
.exh-table th:nth-child(7),
.exh-table td[data-field="familia"] {
    width: 120px !important;
    min-width: 120px !important;
    max-width: 120px !important;
}

/* =========================================================
   PASO 20: COLUMNA 8 - CÓDIGO DE BARRAS
========================================================= */
.exh-table th:nth-child(8),
.exh-table td[data-field="codbarras"] {
    width: 120px !important;
    min-width: 120px !important;
    max-width: 120px !important;
    font-size: 12px !important;
}

/* =========================================================
   PASO 21: COLUMNA 9 - PLU
========================================================= */
.exh-table th:nth-child(9),
.exh-table td[data-field="plu"] {
    width: 115px !important;
    min-width: 115px !important;
    max-width: 115px !important;
    font-size: 12px !important;
}

/* =========================================================
   PASO 22: COLUMNA 10 - INVENTARIO
========================================================= */
.exh-table th:nth-child(10),
.exh-table td[data-field="inventario_tienda"] {
    width: 105px !important;
    min-width: 105px !important;
    max-width: 105px !important;
    text-align: center !important;
}

/* =========================================================
   PASO 23: COLUMNA 11 - EXHIBICIÓN
========================================================= */
.exh-table th:nth-child(11),
.exh-table td[data-field="exhibicion"] {
    width: 105px !important;
    min-width: 105px !important;
    max-width: 105px !important;
    text-align: center !important;
}

/* =========================================================
   PASO 24: COLUMNA 12 - UXC
========================================================= */
.exh-table th:nth-child(12),
.exh-table td[data-field="uxc"] {
    width: 75px !important;
    min-width: 75px !important;
    max-width: 75px !important;
    text-align: center !important;
}

/* =========================================================
   PASO 25: COLUMNA 13 - ALMACÉN
========================================================= */
.exh-table th:nth-child(13),
.exh-table td[data-field="codalmacen"] {
    width: 140px !important;
    min-width: 140px !important;
    max-width: 140px !important;
    font-size: 12px !important;
}

/* =========================================================
   PASO 26: COLUMNA 14 - GUARDAR
========================================================= */
.exh-table th:nth-child(14),
.exh-table td:nth-child(14) {
    width: 70px !important;
    min-width: 70px !important;
    max-width: 70px !important;
    text-align: center !important;
}

/* =========================================================
   PASO 27: INPUTS DENTRO DE TABLA
========================================================= */
.exh-table input[type="text"],
.exh-table input[type="number"] {
    width: 100%;
    border: 1px solid var(--line-2);
    border-radius: 9px;
    padding: 6px 7px;
    outline: none;
    background: #fff;
    font-size: 13px;
    color: #0f172a;
}

.exh-input-mini,
.exh-table .exh-input-mini {
    width: 60px !important;
    min-width: 60px !important;
    max-width: 60px !important;
    height: 42px !important;
    font-size: 15px !important;
    font-weight: 900 !important;
    padding: 3px !important;
    text-align: center !important;
    margin: 0 auto !important;
    border-radius: 11px !important;
}

/* =========================================================
   PASO 28: CHECKBOXES
========================================================= */
#checkTodosMasivo,
.js-check-masivo {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: var(--primary);
}

/* =========================================================
   PASO 29: CLASES AUXILIARES
========================================================= */
.center {
    text-align: center;
}

.exh-empty {
    text-align: center;
    padding: 35px !important;
    color: var(--muted);
    font-weight: 700;
}

/* =========================================================
   PASO 30: FILTROS EN ENCABEZADOS
========================================================= */
.exh-th-wrap {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    gap: 6px !important;
    width: 100% !important;
    white-space: normal !important;
    overflow: visible !important;
}

.exh-filter-trigger {
    width: 23px !important;
    height: 23px !important;
    min-width: 23px !important;
    border: none !important;
    border-radius: 6px !important;
    background: #eaf2ff !important;
    color: #1d4ed8 !important;
    padding: 0 !important;
    margin: 0 !important;
    box-shadow: none !important;
    outline: none !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    cursor: pointer;
    flex-shrink: 0 !important;
    z-index: 80 !important;
}

.exh-filter-trigger:hover {
    background: #dbeafe !important;
    color: #1d4ed8 !important;
}

.exh-filter-trigger.is-active {
    background: var(--primary) !important;
    color: #fff !important;
    border-radius: 6px;
}

.exh-filter-trigger i {
    font-size: 12px !important;
}

/* =========================================================
   PASO 31: MENÚ FILTRO TIPO EXCEL CORREGIDO
   Este menú sale encima de todo y no queda escondido.
========================================================= */
.excel-menu {
    position: fixed !important;
    z-index: 999999 !important;
    width: 320px !important;
    max-width: 320px !important;
    background: #fff !important;
    border: 1px solid #dbe3ef !important;
    border-radius: 16px !important;
    box-shadow: 0 18px 45px rgba(15,23,42,.22) !important;
    padding: 14px !important;
    overflow: visible !important;
}

.excel-menu[hidden] {
    display: none !important;
}

.excel-menu-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 12px;
}

.excel-menu-close {
    width: 32px;
    height: 32px;
    border: none;
    border-radius: 10px;
    background: #f1f5f9;
    color: #334155;
    cursor: pointer;
}

.excel-menu-body {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.excel-menu-input {
    width: 100%;
    border: 1px solid #cfd8e3;
    border-radius: 12px;
    padding: 11px 12px;
    outline: none;
    font-size: 14px;
    background: #fff;
}

.excel-check-all {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 800;
    font-size: 13px;
    color: #0f172a;
}

.excel-options {
    height: 240px;
    max-height: 240px;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    padding-right: 6px;
}

.excel-option {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 4px;
    font-size: 13px;
    cursor: pointer;
    color: #334155;
}

.excel-option:hover {
    background: #f1f5f9;
    border-radius: 8px;
}

.excel-menu-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 4px;
}

#excelOrder {
    width: 100%;
    border: 1px solid #cfd8e3;
    border-radius: 12px;
    padding: 10px 12px;
    outline: none;
    font-size: 14px;
    background: #fff;
    color: #0f172a;
    font-weight: 700;
}

/* =========================================================
   PASO 32: BADGE DE REGIÓN
========================================================= */
.region-badge {
    display: inline-flex;
    align-items: center;
    padding: 8px 14px;
    border-radius: 999px;
    background: #eaf2ff;
    color: #6610f2;
    font-weight: 700;
    border: 1px solid rgba(37,99,235,.15);
}

/* =========================================================
   PASO 33: PAGINACIÓN
========================================================= */
.exh-pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    margin-top: 18px;
}

.exh-pagination a,
.exh-pagination span {
    min-width: 38px;
    height: 38px;
    padding: 0 12px;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-weight: 800;
    border: 1px solid var(--line);
    background: #fff;
    color: #334155;
}

.exh-pagination .active {
    background: var(--primary);
    color: #fff;
    border-color: var(--primary);
}

/* =========================================================
   PASO 34: ALERTAS
========================================================= */
.exh-alert {
    margin-bottom: 16px;
    padding: 14px 16px;
    border-radius: 16px;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 10px;
}

.exh-alert-ok {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #bbf7d0;
}

.exh-alert-err {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
}

/* =========================================================
   PASO 35: EDICIÓN INLINE
========================================================= */
.exh-inline-edit {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

/* =========================================================
   PASO 36: BOTÓN FLOTANTE GUARDAR MASIVO
========================================================= */
.floating-save-wrap {
    position: fixed;
    right: 18px;
    bottom: 18px;
    z-index: 9999;
}

.floating-save-btn {
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    min-height: 54px;
    padding: 0 22px;
    border-radius: 999px;
    background: linear-gradient(135deg, #5b5ce9, #4f46e5);
    color: #fff;
    font-size: 15px;
    font-weight: 900;
    box-shadow: 0 10px 30px rgba(79, 70, 229, .35);
    transition: .18s ease;
}

.floating-save-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 16px 36px rgba(79, 70, 229, .45);
}

.floating-save-btn i {
    font-size: 18px;
}

/* =========================================================
   PASO 37: RESPONSIVE TABLET
========================================================= */
@media (max-width: 1200px) {
    .exh-table {
        min-width: 1250px !important;
    }

    .exh-table thead th,
    .exh-table tbody td {
        font-size: 12px !important;
        padding: 8px 5px !important;
    }

    .exh-table th:nth-child(4),
    .exh-table td[data-field="descripcion"] {
        width: 250px !important;
        min-width: 250px !important;
        max-width: 250px !important;
    }
}

/* =========================================================
   PASO 38: RESPONSIVE CELULAR
========================================================= */
@media (max-width: 768px) {
    .exh-header {
        padding: 16px;
        flex-direction: column;
        align-items: flex-start;
    }

    .exh-card {
        padding: 12px;
        border-radius: 16px;
    }

    .exh-toolbar {
        align-items: flex-start;
    }

    .exh-table-shell {
        overflow-x: auto !important;
        overflow-y: visible !important;
        -webkit-overflow-scrolling: touch;
    }

    .exh-table {
        min-width: 1150px !important;
    }

    .exh-table thead th,
    .exh-table tbody td {
        font-size: 11px !important;
        padding: 7px 4px !important;
        line-height: 1.25 !important;
    }

    .exh-table th:nth-child(1),
    .exh-table td:nth-child(1) {
        width: 38px !important;
        min-width: 38px !important;
        max-width: 38px !important;
    }

    .exh-table th:nth-child(2),
    .exh-table td:nth-child(2),
    .exh-table .exh-col-num {
        width: 46px !important;
        min-width: 46px !important;
        max-width: 46px !important;
    }

    .exh-col-num span {
        width: 26px;
        height: 26px;
        font-size: 11px;
    }

    .exh-table th:nth-child(3),
    .exh-table td[data-field="referencia"] {
        width: 85px !important;
        min-width: 85px !important;
        max-width: 85px !important;
    }

    .exh-table th:nth-child(4),
    .exh-table td[data-field="descripcion"] {
        width: 220px !important;
        min-width: 220px !important;
        max-width: 220px !important;
    }

    .exh-table th:nth-child(5),
    .exh-table td[data-field="departamento"],
    .exh-table th:nth-child(6),
    .exh-table td[data-field="seccion"],
    .exh-table th:nth-child(7),
    .exh-table td[data-field="familia"] {
        width: 100px !important;
        min-width: 100px !important;
        max-width: 100px !important;
    }

    .exh-table th:nth-child(8),
    .exh-table td[data-field="codbarras"],
    .exh-table th:nth-child(9),
    .exh-table td[data-field="plu"] {
        width: 95px !important;
        min-width: 95px !important;
        max-width: 95px !important;
        font-size: 10px !important;
    }

    .exh-table th:nth-child(10),
    .exh-table td[data-field="inventario_tienda"],
    .exh-table th:nth-child(11),
    .exh-table td[data-field="exhibicion"] {
        width: 85px !important;
        min-width: 85px !important;
        max-width: 85px !important;
    }

    .exh-table th:nth-child(12),
    .exh-table td[data-field="uxc"] {
        width: 60px !important;
        min-width: 60px !important;
        max-width: 60px !important;
    }

    .exh-table th:nth-child(13),
    .exh-table td[data-field="codalmacen"] {
        width: 110px !important;
        min-width: 110px !important;
        max-width: 110px !important;
        font-size: 10px !important;
    }

    .exh-table th:nth-child(14),
    .exh-table td:nth-child(14) {
        width: 58px !important;
        min-width: 58px !important;
        max-width: 58px !important;
    }

    .exh-input-mini,
    .exh-table .exh-input-mini {
        width: 48px !important;
        min-width: 48px !important;
        max-width: 48px !important;
        height: 36px !important;
        font-size: 12px !important;
    }

    .excel-menu {
        width: calc(100vw - 20px) !important;
        left: 10px !important;
        right: 10px !important;
        max-width: calc(100vw - 20px) !important;
    }

    .floating-save-wrap {
        left: 12px;
        right: 12px;
        bottom: 12px;
    }

    .floating-save-btn {
        width: 100%;
        border-radius: 18px;
    }
}
</style>