<?php
declare(strict_types=1);

header('X-Masivo-Version: V2_SIN_DUPLICADOS');

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| 1) SESIÓN
|--------------------------------------------------------------------------
*/
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| 2) ARCHIVOS REQUERIDOS
|--------------------------------------------------------------------------
| Se usa la misma conexión del guardado individual:
|   $sqlsrv_conn_exhibicion
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/conexion_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

require_login();
$me = me();

/*
|--------------------------------------------------------------------------
| 3) FUNCIONES AUXILIARES
|--------------------------------------------------------------------------
*/
function masivo_texto(mixed $valor): string
{
    return trim((string)$valor);
}

function masivo_solo_digitos(mixed $valor): string
{
    return (string)preg_replace('/\D/', '', trim((string)$valor));
}

function masivo_entero(mixed $valor): int
{
    $limpio = masivo_solo_digitos($valor);
    return $limpio === '' ? 0 : (int)$limpio;
}

function masivo_normalizar_pais(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

function masivo_region_desde_sesion(array $me): string
{
    $pais = masivo_normalizar_pais(
        (string)($me['pais_code'] ?? $_SESSION['pais_code'] ?? '')
    );

    return $pais === 'NI' ? 'NICARAGUA' : 'HONDURAS';
}

function masivo_db_origen(string $region): string
{
    return strtoupper(trim($region)) === 'NICARAGUA'
        ? 'ACANICARAGUA2'
        : 'DETODO';
}

function masivo_codalmacen(string $valor): string
{
    return masivo_solo_digitos($valor);
}

function masivo_codalmacen_valido(string $valor): bool
{
    return preg_match('/^\d{2}$/', $valor) === 1;
}

function masivo_plu(string $valor): string
{
    return strtoupper((string)preg_replace(
        '/[^A-Z0-9]/i',
        '',
        trim($valor)
    ));
}

function masivo_sqlsrv_error(): string
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ALL);

    if (!is_array($errores) || $errores === []) {
        return 'Error desconocido de SQL Server.';
    }

    $mensajes = [];

    foreach ($errores as $error) {
        $codigo  = (string)($error['code'] ?? '');
        $estado  = (string)($error['SQLSTATE'] ?? '');
        $mensaje = trim((string)($error['message'] ?? ''));

        $mensajes[] = trim("SQLSTATE {$estado} | Código {$codigo} | {$mensaje}");
    }

    return implode(' || ', $mensajes);
}

/*
|--------------------------------------------------------------------------
| 4) REGRESAR A LA TABLA CONSERVANDO FILTROS
|--------------------------------------------------------------------------
*/
function masivo_volver(
    string $returnQs,
    bool $ok,
    string $mensaje = ''
): never {
    $returnQs = trim($returnQs);
    $params = [];

    if ($returnQs !== '') {
        parse_str($returnQs, $params);
    }

    unset($params['ok'], $params['err']);

    if (!isset($params['vista']) || trim((string)$params['vista']) === '') {
        $params['vista'] = 'modulo1';
    }

    if ($ok) {
        $params['ok'] = '1';
    } else {
        $detalle = $mensaje !== ''
            ? $mensaje
            : 'No se pudo completar el guardado masivo.';
        $params['err'] = '[MASIVO V2] ' . $detalle;
    }

    header(
        'Location: /exhibicion_DT/index.php?' .
        http_build_query($params) .
        '#tablaExhibicion'
    );
    exit;
}

/*
|--------------------------------------------------------------------------
| 5) ALMACENES PERMITIDOS DEL USUARIO
|--------------------------------------------------------------------------
*/
function masivo_almacenes_permitidos(
    mysqli $conn,
    int $usuarioId,
    string $paisCode
): array {
    if ($usuarioId <= 0) {
        return [];
    }

    $sql = "
        SELECT DISTINCT codalmacen, pais
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND COALESCE(TRIM(codalmacen), '') <> ''
        ORDER BY codalmacen
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $res = $stmt->get_result();

    $almacenes = [];

    while ($row = $res->fetch_assoc()) {
        $codalmacen = masivo_codalmacen((string)($row['codalmacen'] ?? ''));
        $paisFila   = masivo_normalizar_pais((string)($row['pais'] ?? ''));

        if (!masivo_codalmacen_valido($codalmacen)) {
            continue;
        }

        if ($paisFila !== '' && $paisCode !== '' && $paisFila !== $paisCode) {
            continue;
        }

        $almacenes[$codalmacen] = true;
    }

    $stmt->close();

    return $almacenes;
}

/*
|--------------------------------------------------------------------------
| 6) NOMBRE DE TIENDA PARA AUDITORÍA
|--------------------------------------------------------------------------
*/
function masivo_nombre_tienda(
    mysqli $conn,
    string $codalmacen,
    string $paisCode,
    array $me
): string {
    $codalmacen = masivo_codalmacen($codalmacen);

    if ($codalmacen === '') {
        return trim((string)($me['tienda'] ?? $_SESSION['tienda'] ?? ''));
    }

    $sql = "
        SELECT nombrealmacen
        FROM usuario_tienda
        WHERE LPAD(TRIM(codalmacen), 2, '0') = ?
          AND UPPER(TRIM(pais)) IN (?, ?)
        ORDER BY nombrealmacen ASC
        LIMIT 1
    ";

    $paisLargo = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return $codalmacen;
    }

    $stmt->bind_param('sss', $codalmacen, $paisCode, $paisLargo);
    $stmt->execute();
    $res = $stmt->get_result();

    $nombre = '';

    if ($res && ($row = $res->fetch_assoc())) {
        $nombre = trim((string)($row['nombrealmacen'] ?? ''));
    }

    $stmt->close();

    if ($nombre === '') {
        $nombre = trim((string)($me['tienda'] ?? $_SESSION['tienda'] ?? ''));
    }

    return $nombre !== '' ? $nombre : $codalmacen;
}

/*
|--------------------------------------------------------------------------
| 7) BUSCAR CODARTICULO AUTOMÁTICAMENTE
|--------------------------------------------------------------------------
| Es la misma lógica usada por guardar_exhibicion.php.
|--------------------------------------------------------------------------
*/
function masivo_buscar_codarticulo(
    mixed $sqlsrvConn,
    string $dbOrigen,
    string $codbarras,
    string $plu = ''
): string {
    $sql = "
        SELECT TOP 1
            AA.CODARTICULO
        FROM {$dbOrigen}.dbo.ARTICULOSLIN AA
        LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
            ON CL.CODARTICULO = AA.CODARTICULO
        INNER JOIN {$dbOrigen}.dbo.ARTICULOS A
            ON A.CODARTICULO = AA.CODARTICULO
           AND A.DESCATALOGADO = 'F'
        WHERE AA.CODBARRAS = ?
    ";

    $params = [$codbarras];

    if ($plu !== '') {
        $sql .= " AND ISNULL(CL.PLU, '') = ? ";
        $params[] = $plu;
    }

    $stmt = sqlsrv_query($sqlsrvConn, $sql, $params);

    if ($stmt === false) {
        return '';
    }

    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);

    return masivo_solo_digitos($row['CODARTICULO'] ?? '');
}

/*
|--------------------------------------------------------------------------
| 8) VALIDAR MÉTODO Y DATOS PRINCIPALES
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    masivo_volver('vista=modulo1', false, 'Método inválido.');
}

$returnQs = masivo_texto($_POST['return_qs'] ?? 'vista=modulo1');

if ((string)($_POST['masivo_version'] ?? '') !== 'V2_UNICO') {
    masivo_volver($returnQs, false, 'La pantalla activa todavía no es la versión nueva.');
}

/*
|--------------------------------------------------------------------------
| RECIBIR REGISTROS MASIVOS
|--------------------------------------------------------------------------
| La pantalla envía las filas seleccionadas dentro de una sola variable
| JSON. Esto evita que PHP corte las filas inferiores por max_input_vars.
| También se conserva compatibilidad con el formato anterior $_POST['items'].
|--------------------------------------------------------------------------
*/
$itemsJson = trim((string)($_POST['items_json'] ?? ''));
$items = [];

if ($itemsJson !== '') {
    $itemsDecodificados = json_decode($itemsJson, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($itemsDecodificados)) {
        masivo_volver(
            $returnQs,
            false,
            'No se pudieron interpretar los registros seleccionados.'
        );
    }

    $items = $itemsDecodificados;
} else {
    $items = $_POST['items'] ?? [];
}

if (!is_array($items) || $items === []) {
    masivo_volver($returnQs, false, 'No se recibieron registros para guardar.');
}

if (
    !isset($sqlsrv_conn_exhibicion) ||
    $sqlsrv_conn_exhibicion === false
) {
    masivo_volver(
        $returnQs,
        false,
        'No hay conexión a SQL Server para Exhibición.'
    );
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    masivo_volver(
        $returnQs,
        false,
        'No hay conexión MySQL para validar permisos y auditoría.'
    );
}

/*
|--------------------------------------------------------------------------
| 9) CONTEXTO DEL USUARIO
|--------------------------------------------------------------------------
*/
$usuarioId     = (int)($me['id'] ?? $_SESSION['usuario_id'] ?? 0);
$usuarioNombre = trim((string)($me['usuario'] ?? $_SESSION['usuario'] ?? 'Sistema'));
$rolUsuario    = trim((string)($me['rol'] ?? $_SESSION['rol'] ?? ''));
$paisCode      = masivo_normalizar_pais(
    (string)($me['pais_code'] ?? $_SESSION['pais_code'] ?? '')
);
$regionSesion  = masivo_region_desde_sesion($me);
$dbOrigen      = masivo_db_origen($regionSesion);
$zonaAuditoria = trim((string)($me['zona'] ?? $_SESSION['zona'] ?? ''));

if (!in_array($rolUsuario, ['super_admin', 'admin_zona', 'tienda'], true)) {
    masivo_volver($returnQs, false, 'No tienes permisos para esta acción.');
}

$almacenesPermitidos = [];

if ($rolUsuario !== 'super_admin') {
    $almacenesPermitidos = masivo_almacenes_permitidos(
        $conn,
        $usuarioId,
        $paisCode
    );

    if ($almacenesPermitidos === []) {
        masivo_volver($returnQs, false, 'No tienes almacenes asignados.');
    }
}

/*
|--------------------------------------------------------------------------
| 10) SQL IGUAL AL GUARDADO INDIVIDUAL
|--------------------------------------------------------------------------
| En registros existentes solamente se actualiza EXHIBICION.
| UXC se utiliza al crear un registro nuevo, igual que en el individual.
|--------------------------------------------------------------------------
*/
$sqlExiste = "
    SELECT TOP 1 1 AS EXISTE
    FROM dbo.[DT-ESTANDARESEXHIBICION] WITH (UPDLOCK, HOLDLOCK)
    WHERE CODARTICULO = ?
      AND CODBARRAS = ?
      AND ISNULL(PLU, '') = ISNULL(?, '')
      AND CODALMACEN = ?
      AND REGION = ?
";

$sqlUpdate = "
    UPDATE dbo.[DT-ESTANDARESEXHIBICION]
    SET EXHIBICION = ?
    WHERE CODARTICULO = ?
      AND CODBARRAS = ?
      AND ISNULL(PLU, '') = ISNULL(?, '')
      AND CODALMACEN = ?
      AND REGION = ?
";

$sqlInsert = "
    INSERT INTO dbo.[DT-ESTANDARESEXHIBICION]
    (
        CODARTICULO,
        CODBARRAS,
        PLU,
        EXHIBICION,
        CODALMACEN,
        REGION,
        UXC
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
";

/*
|--------------------------------------------------------------------------
| 11) CONTADORES Y TRANSACCIÓN
|--------------------------------------------------------------------------
*/
$seleccionados = 0;
$guardados     = 0;
$actualizados  = 0;
$creados       = 0;
$auditorias    = [];

if (!sqlsrv_begin_transaction($sqlsrv_conn_exhibicion)) {
    masivo_volver(
        $returnQs,
        false,
        'No se pudo iniciar la transacción de guardado masivo.'
    );
}

try {
    foreach ($items as $indice => $item) {
        if (!is_array($item)) {
            continue;
        }

        if ((string)($item['seleccionado'] ?? '') !== '1') {
            continue;
        }

        $seleccionados++;

        /*
        |------------------------------------------------------------------
        | LIMPIEZA IDÉNTICA AL GUARDADO INDIVIDUAL
        |------------------------------------------------------------------
        */
        $codbarras   = masivo_solo_digitos($item['codbarras'] ?? '');
        $plu         = masivo_plu((string)($item['plu'] ?? ''));
        $codalmacen  = masivo_codalmacen((string)($item['codalmacen'] ?? ''));
        $codarticulo = masivo_solo_digitos($item['codarticulo'] ?? '');
        $exhibicion  = masivo_entero($item['exhibicion'] ?? 0);
        $uxc         = masivo_entero($item['uxc'] ?? 0);
        $region      = $regionSesion;

        $numeroFila = is_int($indice) ? $indice + 1 : (string)$indice;

        if ($codbarras === '') {
            throw new RuntimeException("Fila {$numeroFila}: CODBARRAS es obligatorio.");
        }

        if (!masivo_codalmacen_valido($codalmacen)) {
            throw new RuntimeException("Fila {$numeroFila}: CODALMACEN debe tener exactamente 2 dígitos.");
        }

        if ($rolUsuario !== 'super_admin' && !isset($almacenesPermitidos[$codalmacen])) {
            throw new RuntimeException("Fila {$numeroFila}: no tienes permiso para guardar en el almacén {$codalmacen}.");
        }

        if ($codarticulo === '') {
            $codarticulo = masivo_buscar_codarticulo($sqlsrv_conn_exhibicion, $dbOrigen, $codbarras, $plu);
        }

        if ($codarticulo === '') {
            throw new RuntimeException("Fila {$numeroFila}: no se encontró CODARTICULO para CODBARRAS {$codbarras}.");
        }

        /*
        |------------------------------------------------------------------
        | COMPROBAR EXISTENCIA CON BLOQUEO TRANSACCIONAL
        |------------------------------------------------------------------
        */
        $paramsLlave = [$codarticulo, $codbarras, $plu, $codalmacen, $region];
        $stmtExiste = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlExiste, $paramsLlave);

        if ($stmtExiste === false) {
            throw new RuntimeException("Fila {$numeroFila}: no se pudo comprobar si el registro ya existe. " . masivo_sqlsrv_error());
        }

        $filaExiste = sqlsrv_fetch_array($stmtExiste, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtExiste);

        $existe = is_array($filaExiste);
        $accionRegistro = $existe ? 'ACTUALIZADO' : 'CREADO';

        if ($existe) {
            $paramsUpdate = [$exhibicion, $codarticulo, $codbarras, $plu, $codalmacen, $region];
            $stmtUpdate = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlUpdate, $paramsUpdate);
            if ($stmtUpdate === false) {
                throw new RuntimeException("Fila {$numeroFila}: no se pudo actualizar EXHIBICIÓN. " . masivo_sqlsrv_error());
            }
            sqlsrv_free_stmt($stmtUpdate);
            $actualizados++;
        } else {
            $paramsInsert = [$codarticulo, $codbarras, $plu, $exhibicion, $codalmacen, $region, $uxc];
            $stmtInsert = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlInsert, $paramsInsert);
            if ($stmtInsert === false) {
                throw new RuntimeException("Fila {$numeroFila}: no se pudo insertar el registro. " . masivo_sqlsrv_error());
            }
            sqlsrv_free_stmt($stmtInsert);
            $creados++;
        }

        $tiendaAuditoria = masivo_nombre_tienda($conn, $codalmacen, $paisCode, $me);

        // Almacenamos temporalmente los datos para procesarlos DESPUÉS del COMMIT
        $auditorias[] = [
            'accion'      => $accionRegistro === 'CREADO' ? 'CREAR_EXHIBICION_MASIVO' : 'EDITAR_EXHIBICION_MASIVO',
            'descripcion' => 'Se guardó exhibición masiva. | ACCION: ' . $accionRegistro . ' | REGION: ' . $region . ' | TIENDA: ' . $tiendaAuditoria . ' | CODARTICULO: ' . $codarticulo . ' | CODBARRAS: ' . $codbarras . ' | PLU: ' . $plu . ' | EXHIBICION: ' . $exhibicion . ' | UXC: ' . $uxc,
            'region'      => $region,
            'tienda'      => $tiendaAuditoria,
            'codalmacen'  => $codalmacen
        ];

        $guardados++;
    } 

    
    if ($seleccionados <= 0) {
        throw new RuntimeException('No seleccionó registros para guardar.');
    }

    if ($guardados !== $seleccionados) {
        throw new RuntimeException('No fue posible procesar todos los registros seleccionados.');
    }

    // Confirmamos los cambios de los productos primero
    if (!sqlsrv_commit($sqlsrv_conn_exhibicion)) {
        throw new RuntimeException('No se pudo confirmar la transacción de SQL Server.');
    }

    /*
    |--------------------------------------------------------------------------
    | 12) AUDITORÍA DESPUÉS DEL COMMIT (UBICADO CORRECTAMENTE AFUERA)
    |--------------------------------------------------------------------------
    */
    foreach ($auditorias as $auditoria) {
        $codigoAlmacenFila = (string)($auditoria['codalmacen'] ?? '');
        $tiendaFila = (string)($auditoria['tienda'] ?? '');
        $zonaFila   = '';

        /*
        |------------------------------------------------------------------
        | PAÍS DE LA FILA SEGÚN SU REGIÓN
        |------------------------------------------------------------------
        | Evita que un CODALMACEN de Nicaragua tome la zona de Honduras
        | cuando existe el mismo código de almacén en ambos países.
        |------------------------------------------------------------------
        */
        $regionAuditoria = strtoupper(trim((string)($auditoria['region'] ?? '')));
        $paisAuditoria = $regionAuditoria === 'NICARAGUA' ? 'NI' : 'HN';
        $paisLargoAuditoria = $paisAuditoria === 'NI' ? 'NICARAGUA' : 'HONDURAS';

        if ($codigoAlmacenFila !== '') {
            $sqlZona = "
                SELECT zona
                FROM usuario_tienda
                WHERE LPAD(TRIM(codalmacen), 2, '0') = ?
                  AND UPPER(TRIM(pais)) IN (?, ?)
                LIMIT 1
            ";

            $stmtZ = $conn->prepare($sqlZona);

            if ($stmtZ) {
                $stmtZ->bind_param(
                    'sss',
                    $codigoAlmacenFila,
                    $paisAuditoria,
                    $paisLargoAuditoria
                );

                $stmtZ->execute();
                $resZ = $stmtZ->get_result();

                if ($resZ && ($rowZ = $resZ->fetch_assoc())) {
                    $zonaFila = trim((string)($rowZ['zona'] ?? ''));
                }

                $stmtZ->close();
            }
        }

        if ($zonaFila === '') {
            $zonaFila = trim((string)($_SESSION['zona'] ?? 'SIN ZONA'));
        }

        
        registrar_auditoria(
            'EXHIBICION',
            (string)$auditoria['accion'],
            (string)$auditoria['descripcion'],
            (string)$auditoria['region'],
            $zonaFila,      // Cae en columna 'zona'
            $tiendaFila,    // Cae en columna 'tienda'
            $codigoAlmacenFila
        );
    }

    masivo_volver(
        $returnQs,
        true,
        "Registros guardados correctamente. Actualizados: {$actualizados}. Creados: {$creados}."
    );

} catch (Throwable $e) {
    @sqlsrv_rollback($sqlsrv_conn_exhibicion);
    masivo_volver($returnQs, false, 'Error al guardar masivo: ' . $e->getMessage());
}
