<?php
declare(strict_types=1);

/* =========================================================
   1) INICIAR SESIÓN
   ========================================================= */
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   2) BUFFER DE SALIDA
   ========================================================= */
ob_start();

/* =========================================================
   3) CONFIGURACIÓN
   ========================================================= */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
set_time_limit(0);
ini_set('memory_limit', '1024M');

/* =========================================================
   4) ARCHIVOS REQUERIDOS
   ========================================================= */
require_once __DIR__. '/conexion_exhibicion.php';
require_once dirname(__DIR__, 2) . '/exhibicion_reporte/conexion_sqlsrv.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/* =========================================================
   5) VALIDAR LOGIN
   ========================================================= */
require_login();

/* =========================================================
   6) OBTENER REGIÓN DESDE LA SESIÓN
   ---------------------------------------------------------
   Esto evita mezclar tiendas con el mismo código:
   Ejemplo:
   - Tienda 08 Honduras
   - Tienda 08 Nicaragua
   ========================================================= */
$me = me();

$paisCode = strtoupper(trim((string)($me['pais_code'] ?? $_SESSION['pais_code'] ?? 'HN')));

$regionSesion = ($paisCode === 'NI' || $paisCode === 'NICARAGUA')
    ? 'NICARAGUA'
    : 'HONDURAS';

/* =========================================================
   7) FUNCIÓN PARA LIMPIAR TEXTO EN HTML
   ---------------------------------------------------------
   Como descargamos .xls en tabla HTML, esta función evita
   caracteres raros y protege el contenido.
   ========================================================= */
function xls_text(mixed $value): string
{
    return htmlspecialchars(trim((string)$value), ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   8) FILTROS RECIBIDOS DESDE LA PANTALLA
   ---------------------------------------------------------
   Si la URL no trae región, usamos la región de sesión.
   ========================================================= */
$codalmacen = trim((string)($_GET['codalmacen'] ?? ''));

$region = trim((string)($_GET['region'] ?? ''));

if ($region === '') {
    $region = $regionSesion;
}

$region = strtoupper(trim($region));

if ($region === 'HN') {
    $region = 'HONDURAS';
}

if ($region === 'NI') {
    $region = 'NICARAGUA';
}

$whereSql = " WHERE 1 = 1 ";
$params = [];

/* Filtrar por tienda */
if ($codalmacen !== '') {
    $whereSql .= "
        AND LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) = ?
    ";
    $params[] = $codalmacen;
}

/* Filtrar siempre por región */
$whereSql .= "
    AND LTRIM(RTRIM(CONVERT(VARCHAR(100), E.REGION))) = ?
";
$params[] = $region;

/* =========================================================
   9) CONSULTA
   ---------------------------------------------------------
   - Usa DT-ESTANDARESEXHIBICION como base.
   - Evita duplicados por JOIN agrupando por E_ID.
   - INVENTARIO_TIENDA queda comentado para no hacer lenta
     la descarga.
   - CODALMACEN queda internamente para ordenar, pero no sale
     en el Excel.
   ========================================================= */
$sql = "
WITH E_BASE AS (
    SELECT
        ROW_NUMBER() OVER (ORDER BY E.REGION, E.CODALMACEN, E.CODARTICULO, E.PLU) AS E_ID,
        E.REGION,
        E.CODALMACEN,
        E.CODARTICULO,
        E.CODBARRAS,
        E.PLU,
        E.EXHIBICION,
        E.UXC
    FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E
    {$whereSql}
),
Q AS (
    SELECT
        E.E_ID,
        E.REGION,

        MAX(CASE WHEN E.REGION = 'HONDURAS' THEN A_HN.REFPROVEEDOR ELSE A_NI.REFPROVEEDOR END) AS REFERENCIA,
        MAX(CASE WHEN E.REGION = 'HONDURAS' THEN A_HN.DESCRIPCION ELSE A_NI.DESCRIPCION END) AS DESCRIPCION,
        MAX(CASE WHEN E.REGION = 'HONDURAS' THEN D_HN.DESCRIPCION ELSE D_NI.DESCRIPCION END) AS DEPARTAMENTO,
        MAX(CASE WHEN E.REGION = 'HONDURAS' THEN S_HN.DESCRIPCION ELSE S_NI.DESCRIPCION END) AS SECCION,
        MAX(CASE WHEN E.REGION = 'HONDURAS' THEN F_HN.DESCRIPCION ELSE F_NI.DESCRIPCION END) AS FAMILIA,

        E.CODBARRAS,
        E.PLU,

        /*
        INVENTARIO_TIENDA comentado.
        Si se agrega STOCKS aquí, la descarga se vuelve más lenta.
        */

        E.EXHIBICION,
        E.UXC,
        E.CODARTICULO,
        E.CODALMACEN

    FROM E_BASE E

    LEFT JOIN DETODO.dbo.ARTICULOS A_HN
        ON E.REGION = 'HONDURAS'
       AND LTRIM(RTRIM(CONVERT(VARCHAR(100), A_HN.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN DETODO.dbo.DEPARTAMENTO D_HN
        ON D_HN.NUMDPTO = A_HN.DPTO

    LEFT JOIN DETODO.dbo.SECCIONES S_HN
        ON S_HN.NUMDPTO = A_HN.DPTO
       AND S_HN.NUMSECCION = A_HN.SECCION

    LEFT JOIN DETODO.dbo.FAMILIAS F_HN
        ON F_HN.NUMDPTO = A_HN.DPTO
       AND F_HN.NUMSECCION = A_HN.SECCION
       AND F_HN.NUMFAMILIA = A_HN.FAMILIA

    LEFT JOIN ACANICARAGUA2.dbo.ARTICULOS A_NI
        ON E.REGION = 'NICARAGUA'
       AND LTRIM(RTRIM(CONVERT(VARCHAR(100), A_NI.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN ACANICARAGUA2.dbo.DEPARTAMENTO D_NI
        ON D_NI.NUMDPTO = A_NI.DPTO

    LEFT JOIN ACANICARAGUA2.dbo.SECCIONES S_NI
        ON S_NI.NUMDPTO = A_NI.DPTO
       AND S_NI.NUMSECCION = A_NI.SECCION

    LEFT JOIN ACANICARAGUA2.dbo.FAMILIAS F_NI
        ON F_NI.NUMDPTO = A_NI.DPTO
       AND F_NI.NUMSECCION = A_NI.SECCION
       AND F_NI.NUMFAMILIA = A_NI.FAMILIA

    GROUP BY
        E.E_ID,
        E.REGION,
        E.CODBARRAS,
        E.PLU,
        E.EXHIBICION,
        E.UXC,
        E.CODARTICULO,
        E.CODALMACEN
)
SELECT
    REGION,
    ISNULL(REFERENCIA, '') AS REFERENCIA,
    ISNULL(DESCRIPCION, '') AS DESCRIPCION,
    ISNULL(DEPARTAMENTO, '') AS DEPARTAMENTO,
    ISNULL(SECCION, '') AS SECCION,
    ISNULL(FAMILIA, '') AS FAMILIA,
    CODBARRAS,
    PLU,
    -- INVENTARIO_TIENDA,
    EXHIBICION,
    UXC,
    CODARTICULO
    -- CODALMACEN
FROM Q
ORDER BY
    REGION,
    CODALMACEN,
    CODARTICULO,
    PLU
";

/* =========================================================
   10) EJECUTAR CONSULTA
   ========================================================= */
$stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $sql, $params, [
    'QueryTimeout' => 0
]);

if ($stmt === false) {
    if (ob_get_length()) {
        ob_end_clean();
    }

    http_response_code(500);
    echo '<pre>';
    echo "Error al generar la exportación:\n\n";
    print_r(sqlsrv_errors());
    echo '</pre>';
    exit;
}

/* =========================================================
   11) LIMPIAR BUFFER ANTES DEL EXCEL
   ========================================================= */
if (ob_get_length()) {
    ob_end_clean();
}

/* =========================================================
   12) CABECERAS PARA EXCEL .XLS
   ---------------------------------------------------------
   Se usa .xls HTML para evitar que Edge/Excel conviertan
   códigos largos a notación científica.
   ========================================================= */
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="exhibicion_guardada_' . date('Ymd_His') . '.xls"');
header('Cache-Control: max-age=0');

/* =========================================================
   13) INICIAR DOCUMENTO HTML PARA EXCEL
   ========================================================= */
echo '<html>';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '</head>';
echo '<body>';
echo '<table border="1">';

/* =========================================================
   14) ENCABEZADOS
   ========================================================= */
echo '<tr>';
echo '<th>REGION</th>';
echo '<th>REFERENCIA</th>';
echo '<th>DESCRIPCION</th>';
echo '<th>DEPARTAMENTO</th>';
echo '<th>SECCION</th>';
echo '<th>FAMILIA</th>';
echo '<th>CODBARRAS</th>';
echo '<th>PLU</th>';
// echo '<th>INVENTARIO_TIENDA</th>';
echo '<th>EXHIBICION</th>';
echo '<th>UXC</th>';
echo '<th>CODARTICULO</th>';
// echo '<th>CODALMACEN</th>';
echo '</tr>';

/* =========================================================
   15) DATOS
   ---------------------------------------------------------
   mso-number-format:'\@' fuerza a Excel a tratar códigos
   largos como texto.
   ========================================================= */
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';

    echo '<td>' . xls_text($row['REGION'] ?? '') . '</td>';
    echo '<td style="mso-number-format:\'\@\';">' . xls_text($row['REFERENCIA'] ?? '') . '</td>';
    echo '<td>' . xls_text($row['DESCRIPCION'] ?? '') . '</td>';
    echo '<td>' . xls_text($row['DEPARTAMENTO'] ?? '') . '</td>';
    echo '<td>' . xls_text($row['SECCION'] ?? '') . '</td>';
    echo '<td>' . xls_text($row['FAMILIA'] ?? '') . '</td>';
    echo '<td style="mso-number-format:\'\@\';">' . xls_text($row['CODBARRAS'] ?? '') . '</td>';
    echo '<td style="mso-number-format:\'\@\';">' . xls_text($row['PLU'] ?? '') . '</td>';
    // echo '<td>' . xls_text($row['INVENTARIO_TIENDA'] ?? 0) . '</td>';
    echo '<td>' . xls_text($row['EXHIBICION'] ?? 0) . '</td>';
    echo '<td>' . xls_text($row['UXC'] ?? 0) . '</td>';
    echo '<td style="mso-number-format:\'\@\';">' . xls_text($row['CODARTICULO'] ?? '') . '</td>';
    // echo '<td>' . xls_text($row['CODALMACEN'] ?? '') . '</td>';

    echo '</tr>';
}

/* =========================================================
   16) CERRAR Y FINALIZAR
   ========================================================= */
echo '</table>';
echo '</body>';
echo '</html>';

sqlsrv_free_stmt($stmt);
exit;