<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| CONFIGURACIÓN GENERAL
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| 1) INICIAR SESIÓN
|--------------------------------------------------------------------------
| Esta aplicación usa su propia sesión para no mezclarse con otras apps.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/*
|--------------------------------------------------------------------------
| 2) ARCHIVOS REQUERIDOS
|--------------------------------------------------------------------------
*/
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/*
|--------------------------------------------------------------------------
| 3) GUARDAR CONEXIÓN MYSQL GLOBAL
|--------------------------------------------------------------------------
*/
if (isset($conn) && $conn instanceof mysqli) {
    $GLOBALS['exhibicion_mysql_conn'] = $conn;
}

/*
|--------------------------------------------------------------------------
| 4) FUNCIONES DE LIMPIEZA
|--------------------------------------------------------------------------
*/
function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function exhibicion_clean_text(string $value): string
{
    return trim($value);
}

function exhibicion_clean_codalmacen(string $value): string
{
    return preg_replace('/\D/', '', trim($value));
}

/*
|--------------------------------------------------------------------------
| 5) LEER FILTROS DESDE GET
|--------------------------------------------------------------------------
| IMPORTANTE:
| No limpiamos con preg_replace porque el filtro Excel manda:
| valor1||valor2||valor3
|--------------------------------------------------------------------------
*/
function exhibicion_filters_from_get(): array
{
    return [
        'region'            => exhibicion_clean_text((string)($_GET['region'] ?? '')),
        'referencia'        => exhibicion_clean_text((string)($_GET['referencia'] ?? '')),
        'descripcion'       => exhibicion_clean_text((string)($_GET['descripcion'] ?? '')),
        'departamento'      => exhibicion_clean_text((string)($_GET['departamento'] ?? '')),
        'seccion'           => exhibicion_clean_text((string)($_GET['seccion'] ?? '')),
        'familia'           => exhibicion_clean_text((string)($_GET['familia'] ?? '')),
        'codbarras'         => exhibicion_clean_text((string)($_GET['codbarras'] ?? '')),
        'plu'               => exhibicion_clean_text((string)($_GET['plu'] ?? '')),
        'inventario_tienda' => exhibicion_clean_text((string)($_GET['inventario_tienda'] ?? '')),
        'exhibicion'        => exhibicion_clean_text((string)($_GET['exhibicion'] ?? '')),
        'uxc'               => exhibicion_clean_text((string)($_GET['uxc'] ?? '')),
        'codarticulo'       => exhibicion_clean_text((string)($_GET['codarticulo'] ?? '')),
        'codalmacen'        => exhibicion_clean_text((string)($_GET['codalmacen'] ?? '')),
    ];
}

/*
|--------------------------------------------------------------------------
| 6) NORMALIZAR PAÍS
|--------------------------------------------------------------------------
*/
function exhibicion_normalizar_pais(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/*
|--------------------------------------------------------------------------
| 7) CONTEXTO DEL USUARIO
|--------------------------------------------------------------------------
*/
function exhibicion_context_from_session(): array
{
    require_login();

    $me = me();

    $paisCode  = exhibicion_normalizar_pais((string)($me['pais_code'] ?? ''));
    $rol       = trim((string)($me['rol'] ?? ''));
    $usuarioId = (int)($me['id'] ?? 0);

    if ($paisCode === 'NI') {
        return [
            'db'        => 'ACANICARAGUA2',
            'region'    => 'NICARAGUA',
            'paisCode'  => 'NI',
            'rol'       => $rol,
            'usuarioId' => $usuarioId,
        ];
    }

    return [
        'db'        => 'DETODO',
        'region'    => 'HONDURAS',
        'paisCode'  => 'HN',
        'rol'       => $rol,
        'usuarioId' => $usuarioId,
    ];
}

/*
|--------------------------------------------------------------------------
| 8) OBTENER TIENDAS DEL USUARIO
|--------------------------------------------------------------------------
*/
function exhibicion_get_user_stores(mysqli $conn, int $usuarioId, string $paisCode): array
{
    if ($usuarioId <= 0) {
        return [];
    }

    $sql = "
        SELECT DISTINCT codalmacen, pais
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND COALESCE(TRIM(codalmacen), '') <> ''
        ORDER BY codalmacen
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();

    $res = $stmt->get_result();
    $stores = [];

    while ($row = $res->fetch_assoc()) {
        $cod  = exhibicion_clean_codalmacen((string)($row['codalmacen'] ?? ''));
        $pais = exhibicion_normalizar_pais((string)($row['pais'] ?? ''));

        if ($cod === '') {
            continue;
        }

        if ($pais !== '' && $paisCode !== '' && $pais !== $paisCode) {
            continue;
        }

        if (!preg_match('/^\d{2}$/', $cod)) {
            continue;
        }

        $stores[] = $cod;
    }

    $stmt->close();

    $stores = array_values(array_unique($stores));
    sort($stores);

    return $stores;
}

/*
|--------------------------------------------------------------------------
| 9) VERIFICAR SI HAY ALGÚN FILTRO
|--------------------------------------------------------------------------
*/
function exhibicion_tiene_filtro_clave(array $filters): bool
{
    foreach ($filters as $value) {
        if (trim((string)$value) !== '') {
            return true;
        }
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| 10) EXPRESIÓN LIMPIA PARA CODALMACEN
|--------------------------------------------------------------------------
*/
function exhibicion_sql_codalmacen(string $campoSql): string
{
    return "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$campoSql})))";
}

/*
|--------------------------------------------------------------------------
| 11) SEPARAR VALORES DEL FILTRO EXCEL
|--------------------------------------------------------------------------
| Recibe:
|   01||02||03
|--------------------------------------------------------------------------
*/
function exhibicion_excel_values(string $valor): array
{
    $valor = trim($valor);

    if ($valor === '') {
        return [];
    }

    return array_values(array_filter(
        array_map('trim', explode('||', $valor)),
        fn($v) => $v !== ''
    ));
}

/*
|--------------------------------------------------------------------------
| 12) FILTRO EXACTO / BUSCADOR TIPO EXCEL
|--------------------------------------------------------------------------
| Si seleccionas valores:
|   01||02||03
| filtra exacto.
|
| Si solo escribes en el buscador:
|   __LIKE__camisa
| filtra por coincidencia.
|--------------------------------------------------------------------------
*/
function exhibicion_add_excel_exact_filter(
    string &$sql,
    array &$params,
    string $campoSql,
    string $valor
): void {
    $valor = trim($valor);

    /*
    |--------------------------------------------------------------------------
    | CASO 1: EL USUARIO ESCRIBIÓ EN EL BUSCADOR Y NO SELECCIONÓ CHECKBOX
    |--------------------------------------------------------------------------
    */
    if (str_starts_with($valor, '__LIKE__')) {
        $texto = trim(str_replace('__LIKE__', '', $valor));

        if ($texto !== '') {
            $sql .= "
                AND LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
                    COLLATE DATABASE_DEFAULT
                    LIKE ?
                    COLLATE DATABASE_DEFAULT
            ";

            $params[] = '%' . $texto . '%';
        }

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | CASO 2: EL USUARIO SELECCIONÓ UNO O VARIOS VALORES
    |--------------------------------------------------------------------------
    */
    $valores = exhibicion_excel_values($valor);

    if (empty($valores)) {
        return;
    }

    $partes = [];

    foreach ($valores as $v) {
        $partes[] = "
            LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
            COLLATE DATABASE_DEFAULT
            =
            ?
            COLLATE DATABASE_DEFAULT
        ";

        $params[] = trim((string)$v);
    }

    $sql .= " AND (" . implode(" OR ", $partes) . ")";
}

/*
|--------------------------------------------------------------------------
| 13) FILTRO LIKE
|--------------------------------------------------------------------------
| Este sirve si escribes texto manualmente.
| Lo dejamos disponible, pero el filtro tipo Excel usa el exacto.
|--------------------------------------------------------------------------
*/
function exhibicion_add_excel_like_filter(
    string &$sql,
    array &$params,
    string $campoSql,
    string $valor
): void {
    $valores = exhibicion_excel_values($valor);

    if (empty($valores)) {
        return;
    }

    $partes = [];

    foreach ($valores as $v) {
        $partes[] = "LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql}))) COLLATE DATABASE_DEFAULT LIKE ? COLLATE DATABASE_DEFAULT";
        $params[] = '%' . trim((string)$v) . '%';
    }

    $sql .= " AND (" . implode(" OR ", $partes) . ")";
}

/*
|--------------------------------------------------------------------------
| 14) CONSTRUIR ALCANCE POR ROL
|--------------------------------------------------------------------------
*/
function exhibicion_build_scope_clause(array $ctx, mysqli $conn, array $filters): array
{
    $rol       = (string)($ctx['rol'] ?? '');
    $usuarioId = (int)($ctx['usuarioId'] ?? 0);
    $paisCode  = (string)($ctx['paisCode'] ?? '');

    $codAlmacenScopeSql = exhibicion_sql_codalmacen('S.CODALMACEN');

    /*
    |--------------------------------------------------------------------------
    | SUPER ADMIN
    |--------------------------------------------------------------------------
    */
    if ($rol === 'super_admin') {
        if (!exhibicion_tiene_filtro_clave($filters)) {
            return [' AND 1 = 0 ', []];
        }

        return ['', []];
    }

    /*
    |--------------------------------------------------------------------------
    | ADMIN ZONA
    |--------------------------------------------------------------------------
    */
    if ($rol === 'admin_zona') {
        if (!exhibicion_tiene_filtro_clave($filters)) {
            return [' AND 1 = 0 ', []];
        }

        $stores = exhibicion_get_user_stores($conn, $usuarioId, $paisCode);

        if (empty($stores)) {
            return [' AND 1 = 0 ', []];
        }

        $placeholders = implode(',', array_fill(0, count($stores), '?'));

        return [
            " AND {$codAlmacenScopeSql} LIKE '[0-9][0-9]'
              AND {$codAlmacenScopeSql} IN ($placeholders) ",
            $stores
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | USUARIO NORMAL
    |--------------------------------------------------------------------------
    */
    $stores = exhibicion_get_user_stores($conn, $usuarioId, $paisCode);

    if (empty($stores)) {
        return [' AND 1 = 0 ', []];
    }

    $placeholders = implode(',', array_fill(0, count($stores), '?'));

    return [
        " AND {$codAlmacenScopeSql} LIKE '[0-9][0-9]'
          AND {$codAlmacenScopeSql} IN ($placeholders) ",
        $stores
    ];
}

/*
|--------------------------------------------------------------------------
| 15) QUERY PRINCIPAL
|--------------------------------------------------------------------------
*/
function exhibicion_build_query(array $filters): array
{
    $ctx = exhibicion_context_from_session();

    $dbOrigen = $ctx['db'];
    $region   = $ctx['region'];

    $codAlmacenSql = exhibicion_sql_codalmacen('S.CODALMACEN');

    if (
        !isset($GLOBALS['exhibicion_mysql_conn']) ||
        !($GLOBALS['exhibicion_mysql_conn'] instanceof mysqli)
    ) {
        throw new RuntimeException('No se encontró una conexión mysqli válida.');
    }

    $mysqlConn = $GLOBALS['exhibicion_mysql_conn'];

    /*
    |--------------------------------------------------------------------------
    | RESTRICCIÓN POR ROL
    |--------------------------------------------------------------------------
    */
    [$scopeSql, $scopeParams] = exhibicion_build_scope_clause($ctx, $mysqlConn, $filters);

    /*
    |--------------------------------------------------------------------------
    | WHERE INTERNO
    |--------------------------------------------------------------------------
    */
    $whereSql = "
        WHERE 1 = 1
        {$scopeSql}

        AND {$codAlmacenSql} LIKE '[0-9][0-9]'

        AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')))) <> 'PACKING ARTICULO'

        AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'

        AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%ARTICULOS DE GASTO%'

        AND UPPER(LTRIM(RTRIM(ISNULL(SC.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'

        AND UPPER(LTRIM(RTRIM(ISNULL(F.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
    ";

    /*
    |--------------------------------------------------------------------------
    | PARÁMETROS INICIALES
    |--------------------------------------------------------------------------
    */
    $params = array_merge([$region, $region], $scopeParams);

    /*
    |--------------------------------------------------------------------------
    | FILTROS ANTES DEL GROUP BY
    |--------------------------------------------------------------------------
    | Estos campos vienen de tablas originales.
    |--------------------------------------------------------------------------
    */

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        $codAlmacenSql,
        $filters['codalmacen']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')",
        $filters['referencia']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')",
        $filters['descripcion']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "ISNULL(D.DESCRIPCION, '')",
        $filters['departamento']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "ISNULL(SC.DESCRIPCION, '')",
        $filters['seccion']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "ISNULL(F.DESCRIPCION, '')",
        $filters['familia']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')",
        $filters['codbarras']
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "UPPER(ISNULL(CONVERT(VARCHAR(100), CL.PLU), ''))",
        strtoupper($filters['plu'])
    );

    exhibicion_add_excel_exact_filter(
        $whereSql,
        $params,
        "UPPER(CONVERT(VARCHAR(100), S.CODARTICULO))",
        strtoupper($filters['codarticulo'])
    );

    /*
    |--------------------------------------------------------------------------
    | CONSULTA PRINCIPAL
    |--------------------------------------------------------------------------
    */
   $sql = "
SELECT *
FROM
(
    SELECT
        ? AS REGION,

        S.CODARTICULO,

        {$codAlmacenSql} AS CODALMACEN,

        LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN,''))) AS ALMACEN,

        REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '') AS REFERENCIA,

        REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '') AS CODBARRAS,

        ISNULL(CONVERT(VARCHAR(100), CL.PLU), '') AS PLU,

        REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,

        ISNULL(SC.DESCRIPCION, '') AS SECCION,

        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        SUM(S.STOCK) AS INVENTARIO_TIENDA,

         MAX(E.EXHIBICION) AS EXHIBICION,

      ISNULL(MAX(E.UXC), MAX(ISNULL(CL.INNER_CASE_PACK, 0))) AS UXC,
        CASE
            WHEN MAX(E.CODARTICULO) IS NULL THEN 0
            ELSE 1
        END AS YA_EXISTE_EXHIBICION

    FROM {$dbOrigen}.dbo.STOCKS S

    INNER JOIN {$dbOrigen}.dbo.ARTICULOSLIN AA
        ON S.CODARTICULO = AA.CODARTICULO
       AND S.TALLA = AA.TALLA
       AND S.COLOR = AA.COLOR

    INNER JOIN {$dbOrigen}.dbo.ARTICULOS A
        ON A.CODARTICULO = AA.CODARTICULO
       AND A.DESCATALOGADO = 'F'

    LEFT JOIN {$dbOrigen}.dbo.ALMACEN ALM
        ON ALM.CODALMACEN = S.CODALMACEN

    LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
        ON CL.CODARTICULO = S.CODARTICULO

    LEFT JOIN {$dbOrigen}.dbo.DEPARTAMENTO D
        ON D.NUMDPTO = A.DPTO

    LEFT JOIN {$dbOrigen}.dbo.SECCIONES SC
        ON SC.NUMDPTO = A.DPTO
       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN {$dbOrigen}.dbo.FAMILIAS F
        ON F.NUMDPTO = A.DPTO
       AND F.NUMSECCION = A.SECCION
       AND F.NUMFAMILIA = A.FAMILIA

    LEFT JOIN vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E
    ON LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT
       =
       LTRIM(RTRIM(CONVERT(VARCHAR(100), S.CODARTICULO))) COLLATE DATABASE_DEFAULT

   AND LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODBARRAS))) COLLATE DATABASE_DEFAULT
       =
       LTRIM(RTRIM(CONVERT(VARCHAR(100), AA.CODBARRAS))) COLLATE DATABASE_DEFAULT

   AND LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) COLLATE DATABASE_DEFAULT
       =
       LTRIM(RTRIM(CONVERT(VARCHAR(100), {$codAlmacenSql}))) COLLATE DATABASE_DEFAULT

   AND LTRIM(RTRIM(CONVERT(VARCHAR(100), E.REGION))) COLLATE DATABASE_DEFAULT
       =
       LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT

   AND LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), E.PLU), ''))) COLLATE DATABASE_DEFAULT
       =
       LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), CL.PLU), ''))) COLLATE DATABASE_DEFAULT
       
    {$whereSql}

    GROUP BY
        S.CODARTICULO,
        {$codAlmacenSql},
        ALM.NOMBREALMACEN,
        A.REFPROVEEDOR,
        AA.CODBARRAS,
        CL.PLU,
        A.DESCRIPCION,
        D.DESCRIPCION,
        SC.DESCRIPCION,
        F.DESCRIPCION
) Q
WHERE 1 = 1
";

    /*
    |--------------------------------------------------------------------------
    | FILTROS DESPUÉS DEL GROUP BY
    |--------------------------------------------------------------------------
    */

    exhibicion_add_excel_exact_filter(
        $sql,
        $params,
        "Q.REGION",
        $filters['region']
    );

    exhibicion_add_excel_exact_filter(
        $sql,
        $params,
        "Q.INVENTARIO_TIENDA",
        $filters['inventario_tienda']
    );

    exhibicion_add_excel_exact_filter(
        $sql,
        $params,
        "Q.EXHIBICION",
        $filters['exhibicion']
    );

    exhibicion_add_excel_exact_filter(
        $sql,
        $params,
        "Q.UXC",
        $filters['uxc']
    );

    return [$sql, $params, $ctx];
}