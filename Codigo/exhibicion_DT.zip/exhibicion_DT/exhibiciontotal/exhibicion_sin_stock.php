<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PASO 1: CONFIGURACIÓN GENERAL DEL PHP
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| PASO 2: INICIAR SESIÓN
|--------------------------------------------------------------------------
| Esta aplicación usa su propia sesión para no mezclarse con otras apps.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}



/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR ARCHIVOS NECESARIOS
|--------------------------------------------------------------------------
*/
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/conexion_sqlsrv.php';

/*
|--------------------------------------------------------------------------
| PASO 4: VALIDAR LOGIN
|--------------------------------------------------------------------------
*/
require_login();

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIONES AUXILIARES
|--------------------------------------------------------------------------
*/
function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function clean_codalmacen(string $v): string {
    $v = preg_replace('/\D/', '', trim($v));
    return $v === '' ? '' : str_pad($v, 2, '0', STR_PAD_LEFT);
}

function clean_text(string $v): string {
    return trim($v);
}

function normalizar_pais(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS' => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default => $pais,
    };
}

/*
|--------------------------------------------------------------------------
| PASO 6: FUNCIONES PARA FILTRO TIPO EXCEL
|--------------------------------------------------------------------------
| Estas funciones permiten:
| - seleccionar una opción exacta
| - seleccionar varias opciones separadas por ||
| - escribir texto y aplicar búsqueda con _LIKE_texto
|--------------------------------------------------------------------------
*/
function excel_filter_values(string $value): array
{
    $value = trim($value);

    if ($value === '') {
        return [];
    }

    return array_values(array_filter(
        array_map('trim', explode('||', $value)),
        fn($v) => $v !== ''
    ));
}

function add_excel_sql_filter(
    string &$sql,
    array &$params,
    string $campoSql,
    string $value
): void {
    $value = trim($value);

    if ($value === '') {
        return;
    }

    /*
    |--------------------------------------------------------------------------
    | CASO 1: EL USUARIO SOLO ESCRIBIÓ EN EL BUSCADOR DEL FILTRO
    |--------------------------------------------------------------------------
    */
    if (str_starts_with($value, '_LIKE_')) {
        $texto = trim(str_replace('_LIKE_', '', $value));

        if ($texto !== '') {
            $sql .= "
                AND LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
                    COLLATE Modern_Spanish_CI_AS
                    LIKE ?
                    COLLATE Modern_Spanish_CI_AS
            ";

            $params[] = '%' . $texto . '%';
        }

        return;
    }

    /*
    |--------------------------------------------------------------------------
    | CASO 2: EL USUARIO SELECCIONÓ UNO O VARIOS CHECKBOX
    |--------------------------------------------------------------------------
    */
    $valores = excel_filter_values($value);

    if (empty($valores)) {
        return;
    }

    $partes = [];

    foreach ($valores as $v) {
        $partes[] = "
            LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
            COLLATE Modern_Spanish_CI_AS
            =
            ?
            COLLATE Modern_Spanish_CI_AS
        ";

        $params[] = $v;
    }

    $sql .= " AND (" . implode(" OR ", $partes) . ")";
}

/*
|--------------------------------------------------------------------------
| PASO 7: DATOS DEL USUARIO LOGUEADO
|--------------------------------------------------------------------------
*/
$me = me();

$rol       = trim((string)($me['rol'] ?? ($_SESSION['rol'] ?? '')));
$usuarioId = (int)($me['id'] ?? ($_SESSION['usuario_id'] ?? 0));
$paisCode  = normalizar_pais((string)($me['pais_code'] ?? ($_SESSION['pais_code'] ?? 'HN')));

/*
|--------------------------------------------------------------------------
| PASO 8: DEFINIR BASE DE DATOS Y REGIÓN
|--------------------------------------------------------------------------
*/
if ($paisCode === 'NI') {
    $dbOrigen = 'ACANICARAGUA2';
    $region   = 'NICARAGUA';
} else {
    $dbOrigen = 'DETODO';
    $region   = 'HONDURAS';
}

/*
|--------------------------------------------------------------------------
| PASO 9: OBTENER TIENDAS ASIGNADAS AL USUARIO
|--------------------------------------------------------------------------
*/
function tiendas_usuario(mysqli $conn, int $usuarioId, string $paisCode, $sqlsrv_conn, string $dbOrigen): array
{
    if ($usuarioId <= 0) {
        return [];
    }

    $sql = "
        SELECT DISTINCT codalmacen, pais
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND COALESCE(TRIM(codalmacen), '') <> ''
        ORDER BY codalmacen
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();

    $res = $stmt->get_result();
    $stores = [];

    while ($row = $res->fetch_assoc()) {
        $cod  = clean_codalmacen((string)($row['codalmacen'] ?? ''));
        $pais = normalizar_pais((string)($row['pais'] ?? ''));

        if ($cod === '') {
            continue;
        }

        if ($pais !== '' && $paisCode !== '' && $pais !== $paisCode) {
            continue;
        }

        $nombre = $cod;

        $sqlNombre = "
            SELECT TOP 1
                LTRIM(RTRIM(ISNULL(NOMBREALMACEN, ''))) AS NOMBRE
            FROM {$dbOrigen}.dbo.ALMACEN
            WHERE LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) = ?
        ";

        $stmtNombre = sqlsrv_query($sqlsrv_conn, $sqlNombre, [$cod]);

        if ($stmtNombre !== false) {
            $rowNombre = sqlsrv_fetch_array($stmtNombre, SQLSRV_FETCH_ASSOC);

            if ($rowNombre && !empty($rowNombre['NOMBRE'])) {
                $nombre = (string)$rowNombre['NOMBRE'];
            }

            sqlsrv_free_stmt($stmtNombre);
        }

        $stores[] = [
            'codigo' => $cod,
            'nombre' => $nombre
        ];
    }

    $stmt->close();

    usort($stores, fn($a, $b) => strcmp($a['codigo'], $b['codigo']));

    return $stores;
}

/*
|--------------------------------------------------------------------------
| PASO 10: OBTENER TODAS LAS TIENDAS PARA SUPER ADMIN
|--------------------------------------------------------------------------
*/
function todas_tiendas_sqlsrv($sqlsrv_conn, string $dbOrigen): array
{
    if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
        return [];
    }

    $sql = "
        SELECT
            LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) AS CODIGO,
            LTRIM(RTRIM(ISNULL(NOMBREALMACEN, ''))) AS NOMBRE
        FROM {$dbOrigen}.dbo.ALMACEN
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) NOT LIKE '%M'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%ACA JOE%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%ACAJOE%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%MERMA%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%MERMAS%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%DESECHO%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%DESECHOS%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%SUMINISTRO%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%SUMINISTROS%'
        ORDER BY CODALMACEN
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql);

    if ($stmt === false) {
        return [];
    }

    $tiendas = [];

    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $cod = clean_codalmacen((string)($row['CODIGO'] ?? ''));

        if ($cod === '') {
            continue;
        }

        $nombre = trim((string)($row['NOMBRE'] ?? ''));

        $tiendas[] = [
            'codigo' => $cod,
            'nombre' => $nombre !== '' ? $nombre : $cod
        ];
    }

    sqlsrv_free_stmt($stmt);

    return $tiendas;
}


/*
|--------------------------------------------------------------------------
| PASO 10.1: OBTENER INFO LOCAL DE TIENDA PARA AUDITORÍA
|--------------------------------------------------------------------------
| Sirve para mandar en el guardado masivo:
| - zona
| - nombrealmacen
|
| Importante:
| Se filtra por PAÍS + CODALMACEN para no mezclar Honduras y Nicaragua
| cuando ambos tienen el mismo código de tienda.
|--------------------------------------------------------------------------
*/
function tienda_local_info(mysqli $conn, string $paisCode, string $codalmacen): array
{
    $paisCode = normalizar_pais($paisCode);
    $cod      = clean_codalmacen($codalmacen);

    if ($cod === '') {
        return [
            'zona' => '',
            'nombre' => '',
        ];
    }

    $p1 = $paisCode;
    $p2 = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';

    $sql = "
        SELECT
            COALESCE(NULLIF(TRIM(zona), ''), '') AS zona,
            COALESCE(NULLIF(TRIM(nombrealmacen), ''), '') AS nombrealmacen
        FROM usuario_tienda
        WHERE UPPER(TRIM(pais)) IN (?, ?)
          AND LPAD(TRIM(codalmacen), 2, '0') = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [
            'zona' => '',
            'nombre' => '',
        ];
    }

    $stmt->bind_param('sss', $p1, $p2, $cod);
    $stmt->execute();

    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    return [
        'zona' => strtoupper(trim((string)($row['zona'] ?? ''))),
        'nombre' => trim((string)($row['nombrealmacen'] ?? '')),
    ];
}

/*
|--------------------------------------------------------------------------
| PASO 11: CARGAR TIENDAS SEGÚN ROL
|--------------------------------------------------------------------------
*/
$tiendasPermitidas = [];
$tiendasSuperAdmin = [];

if ($rol === 'super_admin') {
    $tiendasSuperAdmin = todas_tiendas_sqlsrv($sqlsrv_conn, $dbOrigen);
} else {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        echo '<div class="alert alert-danger">No hay conexión MySQL local.</div>';
        return;
    }

    $tiendasPermitidas = tiendas_usuario(
        $conn,
        $usuarioId,
        $paisCode,
        $sqlsrv_conn,
        $dbOrigen
    );
}

/*
|--------------------------------------------------------------------------
| PASO 12: RECIBIR FILTROS GET
|--------------------------------------------------------------------------
| Estos filtros ahora soportan:
| - valor normal
| - valor1||valor2||valor3
| - _LIKE_texto escrito
|--------------------------------------------------------------------------
*/
$codalmacen   = clean_codalmacen((string)($_GET['codalmacen'] ?? ''));
$referencia   = clean_text((string)($_GET['referencia'] ?? ''));
$codbarras    = clean_text((string)($_GET['codbarras'] ?? ''));
$codarticulo  = clean_text((string)($_GET['codarticulo'] ?? ''));
$plu          = clean_text((string)($_GET['plu'] ?? ''));
$descripcion  = clean_text((string)($_GET['descripcion'] ?? ''));
$departamento = clean_text((string)($_GET['departamento'] ?? ''));
$seccion      = clean_text((string)($_GET['seccion'] ?? ''));
$familia      = clean_text((string)($_GET['familia'] ?? ''));
$exhibicion   = clean_text((string)($_GET['exhibicion'] ?? ''));
$uxc          = clean_text((string)($_GET['uxc'] ?? ''));

/*
|--------------------------------------------------------------------------
| PASO 12.1: INFO DE TIENDA PARA GUARDADO MASIVO / AUDITORÍA
|--------------------------------------------------------------------------
| Se llena después de recibir codalmacen.
| nombre puede venir también desde SQL Server en cada fila (ALMACEN).
|--------------------------------------------------------------------------
*/
$infoTiendaSeleccionada = [
    'zona' => '',
    'nombre' => '',
];

if ($codalmacen !== '' && isset($conn) && $conn instanceof mysqli) {
    $infoTiendaSeleccionada = tienda_local_info($conn, $paisCode, $codalmacen);
}


/*
|--------------------------------------------------------------------------
| PASO 13: PAGINACIÓN RÁPIDA
|--------------------------------------------------------------------------
*/
$page = max(1, (int)($_GET['page'] ?? 1));

$perPage       = 1000;
$limitConsulta = $perPage + 1;
$offset        = ($page - 1) * $perPage;

$haySiguiente = false;

/*
|--------------------------------------------------------------------------
| PASO 14: BLOQUEAR TIENDA NO PERMITIDA
|--------------------------------------------------------------------------
*/
if ($rol !== 'super_admin' && $codalmacen !== '') {
    $codigosPermitidos = array_column($tiendasPermitidas, 'codigo');

    if (!in_array($codalmacen, $codigosPermitidos, true)) {
        $codalmacen = '';
    }
}

/*
|--------------------------------------------------------------------------
| PASO 15: VARIABLES DE RESULTADO
|--------------------------------------------------------------------------
*/
$resultados = [];
$error = '';

/*
|--------------------------------------------------------------------------
| PASO 16: CONSULTAR SOLO SI HAY TIENDA SELECCIONADA
|--------------------------------------------------------------------------
*/
if ($codalmacen !== '') {
    try {
        if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
            throw new Exception('No hay conexión a SQL Server.');
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17: CONSULTA PRINCIPAL
        |--------------------------------------------------------------------------
        */
        $sql = "
            SELECT
                E.REGION COLLATE Modern_Spanish_CI_AS AS REGION,
                E.CODALMACEN COLLATE Modern_Spanish_CI_AS AS CODALMACEN,
                LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, ''))) COLLATE Modern_Spanish_CI_AS AS ALMACEN,
                CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS AS CODARTICULO,
                REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS REFERENCIA,
                REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS CODBARRAS,
                ISNULL(CONVERT(VARCHAR(100), E.PLU), '') COLLATE Modern_Spanish_CI_AS AS PLU,
                REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS DESCRIPCION,
                ISNULL(D.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS DEPARTAMENTO,
                ISNULL(SC.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS SECCION,
                ISNULL(F.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS FAMILIA,
                CAST(0 AS DECIMAL(18,2)) AS INVENTARIO_TIENDA,
                ISNULL(E.EXHIBICION, 0) AS EXHIBICION,
                CASE
                    WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                    WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                    ELSE 0
                END AS UXC
            FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

            LEFT JOIN {$dbOrigen}.dbo.STOCKS ST
                ON CONVERT(VARCHAR(100), ST.CODALMACEN) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODALMACEN) COLLATE Modern_Spanish_CI_AS
               AND CONVERT(VARCHAR(100), ST.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ARTICULOS A
                ON CONVERT(VARCHAR(100), A.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
                ON CONVERT(VARCHAR(100), CL.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ALMACEN ALM
                ON CONVERT(VARCHAR(100), ALM.CODALMACEN) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODALMACEN) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.DEPARTAMENTO D
                ON D.NUMDPTO = A.DPTO

            LEFT JOIN {$dbOrigen}.dbo.SECCIONES SC
                ON SC.NUMDPTO = A.DPTO
               AND SC.NUMSECCION = A.SECCION

            LEFT JOIN {$dbOrigen}.dbo.FAMILIAS F
                ON F.NUMDPTO = A.DPTO
               AND F.NUMSECCION = A.SECCION
               AND F.NUMFAMILIA = A.FAMILIA

            WHERE E.REGION COLLATE Modern_Spanish_CI_AS = ? COLLATE Modern_Spanish_CI_AS
              AND E.CODALMACEN COLLATE Modern_Spanish_CI_AS = ? COLLATE Modern_Spanish_CI_AS
              AND ISNULL(E.EXHIBICION, 0) > 0
              AND ST.CODARTICULO IS NULL
        ";

        $params = [$region, $codalmacen];

        /*
        |--------------------------------------------------------------------------
        | PASO 18: FILTROS TIPO EXCEL
        |--------------------------------------------------------------------------
        */
        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')", $referencia);
        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')", $codbarras);
        add_excel_sql_filter($sql, $params, "CONVERT(VARCHAR(100), E.CODARTICULO)", $codarticulo);
        add_excel_sql_filter($sql, $params, "ISNULL(CONVERT(VARCHAR(100), E.PLU), '')", $plu);
        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')", $descripcion);
        add_excel_sql_filter($sql, $params, "ISNULL(D.DESCRIPCION, '')", $departamento);
        add_excel_sql_filter($sql, $params, "ISNULL(SC.DESCRIPCION, '')", $seccion);
        add_excel_sql_filter($sql, $params, "ISNULL(F.DESCRIPCION, '')", $familia);
        add_excel_sql_filter($sql, $params, "ISNULL(E.EXHIBICION, 0)", $exhibicion);
        add_excel_sql_filter(
            $sql,
            $params,
            "CASE
                WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                ELSE 0
            END",
            $uxc
        );

        /*
        |--------------------------------------------------------------------------
        | PASO 19: ORDEN DINÁMICO Y PAGINACIÓN
        |--------------------------------------------------------------------------
        | Ahora el filtro tipo Excel puede ordenar la consulta real en SQL Server.
        |
        | Funciona con:
        | - CodArtículo
        | - Referencia
        | - Código de barras
        | - PLU
        | - Descripción
        | - Departamento
        | - Sección
        | - Familia
        | - Exhibición
        |
        | Importante:
        | - Ya NO usamos el botón viejo de mayor/menor.
        | - Ya NO se fuerza inventario mayor/menor.
        | - El orden se recibe desde los inputs ocultos orden_campo y orden_dir.
        |--------------------------------------------------------------------------
        */
        $ordenCampo = strtolower(trim((string)($_GET['orden_campo'] ?? 'codarticulo')));
        $ordenDir   = strtolower(trim((string)($_GET['orden_dir'] ?? 'asc')));

        /*
        |--------------------------------------------------------------------------
        | PASO 19A: COLUMNAS PERMITIDAS PARA ORDENAR
        |--------------------------------------------------------------------------
        | Se usa una lista blanca para evitar errores y proteger el ORDER BY.
        |--------------------------------------------------------------------------
        */
        $columnasOrden = [
            'codarticulo'  => 'TRY_CAST(E.CODARTICULO AS INT)',
            'referencia'   => "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')",
            'codbarras'    => "REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')",
            'plu'          => "ISNULL(CONVERT(VARCHAR(100), E.PLU), '')",
            'descripcion'  => "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')",
            'departamento' => "ISNULL(D.DESCRIPCION, '')",
            'seccion'      => "ISNULL(SC.DESCRIPCION, '')",
            'familia'      => "ISNULL(F.DESCRIPCION, '')",
            'exhibicion'   => 'ISNULL(E.EXHIBICION, 0)',
            'uxc'          => "CASE
                WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                ELSE 0
            END",
        ];

        /*
        |--------------------------------------------------------------------------
        | PASO 19B: VALIDAR COLUMNA
        |--------------------------------------------------------------------------
        */
        if (!isset($columnasOrden[$ordenCampo])) {
            $ordenCampo = 'codarticulo';
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 19C: VALIDAR DIRECCIÓN
        |--------------------------------------------------------------------------
        */
        if (!in_array($ordenDir, ['asc', 'desc'], true)) {
            $ordenDir = 'asc';
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 19D: CREAR ORDER BY FINAL
        |--------------------------------------------------------------------------
        | Si ordenas por otra columna, CodArtículo queda como segundo orden para que
        | los resultados sean estables. Si ordenas por CodArtículo, no se repite la
        | misma columna para evitar el error de SQL Server.
        |--------------------------------------------------------------------------
        */
        $ordenPrincipal = $columnasOrden[$ordenCampo] . ' ' . strtoupper($ordenDir);
        $ordenSecundario = [];

        if ($ordenCampo !== 'codarticulo') {
            $ordenSecundario[] = 'TRY_CAST(E.CODARTICULO AS INT) ASC';
        }

        $orderByFinal = implode(",
    ", array_merge([$ordenPrincipal], $ordenSecundario));

        $sql .= "
ORDER BY
    {$orderByFinal}

OFFSET ? ROWS
FETCH NEXT ? ROWS ONLY
";
        

        $params[] = $offset;
        $params[] = $limitConsulta;

        /*
        |--------------------------------------------------------------------------
        | PASO 20: EJECUTAR CONSULTA
        |--------------------------------------------------------------------------
        */
        $stmt = sqlsrv_query($sqlsrv_conn, $sql, $params);

        if ($stmt === false) {
            throw new Exception(print_r(sqlsrv_errors(), true));
        }

        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $resultados[] = $row;
        }

        sqlsrv_free_stmt($stmt);

        /*
        |--------------------------------------------------------------------------
        | PASO 21: VALIDAR SI HAY PÁGINA SIGUIENTE
        |--------------------------------------------------------------------------
        */
        if (count($resultados) > $perPage) {
            $haySiguiente = true;
            array_pop($resultados);
        }

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| PASO 22: CONTADORES Y MENSAJES
|--------------------------------------------------------------------------
*/
$totalResultados = count($resultados);

$desde = $codalmacen !== '' && $totalResultados > 0 ? ($offset + 1) : 0;
$hasta = $offset + $totalResultados;

$mensajeOk  = isset($_GET['ok']) && $_GET['ok'] === '1';
$mensajeErr = trim((string)($_GET['err'] ?? ''));
?>

<style>
/*
|--------------------------------------------------------------------------
| PASO 23: ESTILOS GENERALES
|--------------------------------------------------------------------------
*/
.exhibicion-page{
    background:#f6f7fb;
    min-height:100vh;
    padding:16px;
}

.hero-card,
.filter-card,
.result-card,
.metric-card{
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:16px;
    box-shadow:0 4px 14px rgba(0,0,0,.04);
}

.hero-card{ padding:18px; }

.hero-icon{
    width:48px;
    height:48px;
    border-radius:14px;
    background:#f1f5f9;
    color:#334155;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:24px;
}

.metric-card{ padding:14px; }

.metric-icon{
    width:40px;
    height:40px;
    border-radius:12px;
    background:#f8fafc;
    color:#475569;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
}

.form-label{
    font-size:.78rem;
    font-weight:700;
    color:#334155;
}

.form-control,
.form-select{
    border-radius:12px;
    min-height:40px;
    border:1px solid #dbe1ea;
    font-size:.86rem;
}

.form-control:focus,
.form-select:focus{
    border-color:#94a3b8;
    box-shadow:none;
}

.btn-modern{
    border-radius:12px;
    min-height:40px;
    font-weight:700;
}

.text-primary{ color:#334155 !important; }

.btn-primary{
    background:#111827 !important;
    border-color:#111827 !important;
}

.btn-outline-secondary{
    border-color:#cbd5e1;
    color:#334155;
}

.btn-outline-secondary:hover{
    background:#f1f5f9;
    color:#111827;
}

.badge-soft-danger,
.badge-soft-primary,
.badge-soft-warning{
    background:#f1f5f9;
    color:#334155;
    border:1px solid #e2e8f0;
}

.empty-state{
    text-align:center;
    padding:35px 15px;
    color:#64748b;
}

.empty-state i{
    font-size:38px;
    color:#94a3b8;
    margin-bottom:10px;
}

/*
|--------------------------------------------------------------------------
| PASO 24: TABLA
|--------------------------------------------------------------------------
*/
.table-responsive{
    width:100%;
    overflow-x:visible !important;
}

.table-modern{
    width:100%;
    border-collapse:collapse;
    font-size:.74rem;
    table-layout:auto;
}

.table-modern thead th{
    background:#f8fafc;
    color:#334155;
    border-bottom:1px solid #e5e7eb;
    padding:30px 6px;
    font-size:.70rem;
    white-space:normal;
    text-align:center;
    vertical-align:middle;
}

.table-modern tbody td{
    padding:7px 6px;
    font-size:.74rem;
    white-space:normal;
    word-break:break-word;
    vertical-align:middle;
    text-align:center;
    border-color:#eef2f7;
}

.table-modern tbody tr:hover{ background:#f9fafb; }

.table-modern input.form-control-sm{
    font-size:.75rem;
    padding:4px 5px;
    height:32px;
    text-align:center;
}

.table-modern .btn-sm{
    padding:5px 8px;
    font-size:.75rem;
}

/*
|--------------------------------------------------------------------------
| PASO 25: FILTRO TIPO EXCEL
|--------------------------------------------------------------------------
*/
.excel-th{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:5px;
}

.excel-filter-btn{
    border:0;
    background:transparent;
    color:#334155;
    cursor:pointer;
    padding:0;
    font-size:11px;
}

.excel-filter-btn:hover{ color:#111827; }

.excel-filter-btn.is-active{
    color:#111827;
    font-weight:900;
}

.excel-menu{
    position:fixed;
    top:120px;
    right:30px;
    width:320px;
    z-index:99999;
    background:#fff;
    border:1px solid #dbe3ef;
    border-radius:16px;
    padding:14px;
    box-shadow:0 18px 45px rgba(15,23,42,.18);
}

.excel-menu[hidden]{ display:none !important; }

.excel-menu-head{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:12px;
}

.excel-menu-close{
    border:0;
    width:32px;
    height:32px;
    border-radius:10px;
    background:#f1f5f9;
    color:#334155;
}

.excel-menu-body{
    display:flex;
    flex-direction:column;
    gap:10px;
}

.excel-menu-input{
    width:100%;
    border:1px solid #cfd8e3;
    border-radius:12px;
    padding:10px 12px;
    font-size:14px;
}

.excel-check-all{
    display:flex;
    gap:8px;
    align-items:center;
    font-size:13px;
    font-weight:700;
}

.excel-options{
    height:220px;
    overflow-y:auto;
    overflow-x:hidden;
    border:1px solid #eef2f7;
    border-radius:12px;
    padding:8px;
}

.excel-option{
    display:flex;
    align-items:center;
    gap:8px;
    padding:6px 4px;
    font-size:13px;
    cursor:pointer;
}

.excel-option:hover{
    background:#f1f5f9;
    border-radius:8px;
}

.excel-menu-actions{
    display:flex;
    gap:8px;
}

/*
|--------------------------------------------------------------------------
| PASO 26: PAGINACIÓN
|--------------------------------------------------------------------------
*/
.pagination .page-link{
    color:#111827;
    border-radius:10px;
    margin:2px;
    border:1px solid #dbe1ea;
}

.pagination .page-item.active .page-link{
    background:#111827;
    border-color:#111827;
    color:#fff;
}


/*
|--------------------------------------------------------------------------
| PASO 26.1: COLUMNA DE NUMERACIÓN
|--------------------------------------------------------------------------
| Se usa para mostrar 1, 2, 3... en la tabla.
|--------------------------------------------------------------------------
*/
.sin-col-num{
    width:55px;
    min-width:55px;
    max-width:55px;
    text-align:center !important;
    vertical-align:middle !important;
}

.sin-col-num span{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    width:32px;
    height:32px;
    margin:auto;
    border-radius:10px;
    background:#eef2ff;
    color:#4f46e5;
    font-weight:900;
    font-size:13px;
}

/*
|--------------------------------------------------------------------------
| PASO 26.2: BOTÓN FLOTANTE DE GUARDADO MASIVO
|--------------------------------------------------------------------------
| Permite guardar sin volver arriba de la pantalla.
|--------------------------------------------------------------------------
*/
.floating-save-wrap{
    position:fixed;
    right:18px;
    bottom:18px;
    z-index:9999;
}

.floating-save-btn{
    border:none;
    cursor:pointer;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    min-height:54px;
    padding:0 22px;
    border-radius:999px;
    background:linear-gradient(135deg, #111827, #334155);
    color:#fff;
    font-size:15px;
    font-weight:900;
    box-shadow:0 10px 30px rgba(15,23,42,.25);
    transition:.18s ease;
}

.floating-save-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 16px 36px rgba(15,23,42,.35);
}

.floating-save-btn:disabled{
    opacity:.55;
    cursor:not-allowed;
}

.floating-save-btn i{
    font-size:18px;
}

/*
|--------------------------------------------------------------------------
| PASO 27: CELULAR SIN SCROLL HORIZONTAL
|--------------------------------------------------------------------------
*/
@media(max-width:768px){
    html,
    body{
        max-width:100%;
        overflow-x:hidden !important;
    }

    .exhibicion-page{
        padding:10px;
        overflow-x:hidden !important;
    }

    .hero-card{ padding:14px; }

    .filter-card,
    .result-card,
    .metric-card{ border-radius:14px; }

    .table-responsive{
        width:100%;
        overflow-x:visible !important;
    }

    .table-modern{
        width:100%;
        border:0 !important;
    }

    .table-modern thead{ display:none !important; }

    .table-modern,
    .table-modern tbody,
    .table-modern tr,
    .table-modern td{
        display:block;
        width:100% !important;
    }

    .table-modern tr{
        background:#fff;
        border:1px solid #e5e7eb;
        border-radius:16px;
        margin-bottom:14px;
        padding:12px;
        box-shadow:0 4px 12px rgba(0,0,0,.05);
    }

    .table-modern tbody td{
        border:0 !important;
        border-bottom:1px solid #eef2f7 !important;
        padding:9px 4px !important;
        display:flex !important;
        justify-content:space-between;
        align-items:center;
        gap:12px;
        text-align:right;
        font-size:.82rem;
        word-break:break-word;
    }

    .table-modern tbody td:last-child{ border-bottom:0 !important; }

    .table-modern tbody td::before{
        content:attr(data-label);
        font-weight:700;
        color:#334155;
        text-align:left;
        flex:0 0 115px;
        max-width:115px;
        font-size:.76rem;
    }

    .table-modern input.form-control-sm{
        width:92px;
        min-width:92px;
        height:32px;
        font-size:.76rem;
        text-align:center;
        margin-left:auto;
    }

    .table-modern .btn-sm{ margin-left:auto; }

    .excel-menu{
        left:12px;
        right:12px;
        width:auto;
        top:90px;
    }

    .floating-save-wrap{
        left:12px;
        right:12px;
        bottom:12px;
    }

    .floating-save-btn{
        width:100%;
        border-radius:18px;
    }
}
</style>

<div class="exhibicion-page">

    <!-- PASO 28: ENCABEZADO -->
    <div class="hero-card mb-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-3">
                <div class="hero-icon">
                    <i class="bi bi-box-seam"></i>
                </div>

                <div>
                    <div class="opacity-75">
                        Consulta productos que están en exhibición, pero no existen en STOCKS.
                    </div>
                </div>
            </div>

            <div class="text-end">
                <span class="badge bg-light text-primary px-3 py-2 rounded-pill">
                    Región: <?= h($region) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- PASO 29: MENSAJES -->
    <?php if ($mensajeOk): ?>
        <div class="alert alert-success rounded-4 shadow-sm">
            <i class="bi bi-check-circle me-1"></i>
            Exhibición guardada correctamente.
        </div>
    <?php endif; ?>

    <?php if ($mensajeErr !== ''): ?>
        <div class="alert alert-danger rounded-4 shadow-sm">
            <strong>Error:</strong> <?= h($mensajeErr) ?>
        </div>
    <?php endif; ?>

    <!-- PASO 30: TARJETAS -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="metric-card">
                <div class="d-flex align-items-center gap-3">
                    <div class="metric-icon"><i class="bi bi-shop"></i></div>
                    <div>
                        <div class="text-muted small">Tienda seleccionada</div>
                        <h5 class="fw-bold mb-0"><?= $codalmacen !== '' ? h($codalmacen . (($infoTiendaSeleccionada['nombre'] ?? '') !== '' ? ' - ' . $infoTiendaSeleccionada['nombre'] : '')) : 'Sin seleccionar' ?></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="metric-card">
                <div class="d-flex align-items-center gap-3">
                    <div class="metric-icon"><i class="bi bi-exclamation-triangle"></i></div>
                    <div>
                        <div class="text-muted small">Mostrando en pantalla</div>
                        <h5 class="fw-bold mb-0"><?= h($totalResultados) ?></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="metric-card">
                <div class="d-flex align-items-center gap-3">
                    <div class="metric-icon"><i class="bi bi-database-check"></i></div>
                    <div>
                        <div class="text-muted small">Base consultada</div>
                        <h5 class="fw-bold mb-0"><?= h($dbOrigen) ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <!-- PASO 32: FILTROS SUPERIORES -->
<div class="card filter-card p-4 mb-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">

        <!-- INFO -->
        <div>
            <h5 class="fw-bold mb-1">Resultado de productos</h5>

            <div class="text-muted small">
                Página <?= h($page) ?> ·
                Mostrando <?= h($desde) ?> - <?= h($hasta) ?> ·
                <?= h($perPage) ?> registros por página
            </div>
        </div>

        <!-- ACCIONES -->
        <div class="d-flex align-items-center gap-2 flex-wrap">

        <!-- BADGE -->
            <span class="badge badge-soft-danger rounded-pill px-3 py-2">
                <i class="bi bi-exclamation-circle me-1"></i>
                Sin stock
            </span>

            <button
                type="submit"
                form="formGuardarMasivoSinStock"
                class="btn btn-primary btn-modern"
                id="btnGuardarMasivo"
                <?= empty($resultados) ? 'disabled' : '' ?>
            >
                <i class="bi bi-save2 me-1"></i>
                Guardar
            </button>

        </div>

    </div>

        <form method="GET" class="row g-3" id="formFiltrosSinStock">
            <input type="hidden" name="vista" value="modulo3">
            <input type="hidden" name="page" value="1">

            <!-- =====================================================
                 ORDEN DINÁMICO A → Z / Z → A
                 ===================================================== -->
            <input type="hidden" name="orden_campo" id="orden_campo" value="<?= h($ordenCampo ?? 'codarticulo') ?>">
            <input type="hidden" name="orden_dir" id="orden_dir" value="<?= h($ordenDir ?? 'asc') ?>">

            <!-- Inputs ocultos usados por filtros tipo Excel -->
            <input type="hidden" name="plu" value="<?= h($plu) ?>">
            <input type="hidden" name="descripcion" value="<?= h($descripcion) ?>">
            <input type="hidden" name="departamento" value="<?= h($departamento) ?>">
            <input type="hidden" name="seccion" value="<?= h($seccion) ?>">
            <input type="hidden" name="familia" value="<?= h($familia) ?>">
            <input type="hidden" name="exhibicion" value="<?= h($exhibicion) ?>">
            <input type="hidden" name="uxc" value="<?= h($uxc) ?>">

            <div class="col-lg-3 col-md-6">
                <label class="form-label">CODALMACEN / Tienda</label>

                <select name="codalmacen" class="form-select" required>
                    <option value="">Seleccione tienda</option>

                    <?php if ($rol === 'super_admin'): ?>
                        <?php foreach ($tiendasSuperAdmin as $t): ?>
                            <option value="<?= h($t['codigo']) ?>" <?= $codalmacen === $t['codigo'] ? 'selected' : '' ?>>
                                <?= h($t['codigo']) ?> - <?= h($t['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <?php foreach ($tiendasPermitidas as $t): ?>
                            <option value="<?= h($t['codigo']) ?>" <?= $codalmacen === $t['codigo'] ? 'selected' : '' ?>>
                                <?= h($t['codigo']) ?> - <?= h($t['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-lg-3 col-md-6">
                <label class="form-label">Referencia</label>
                <input type="text" name="referencia" value="<?= h($referencia) ?>" class="form-control" placeholder="Buscar referencia">
            </div>

            <div class="col-lg-3 col-md-6">
                <label class="form-label">Código de barras</label>
                <input type="text" name="codbarras" value="<?= h($codbarras) ?>" class="form-control" placeholder="Buscar código de barras">
            </div>

            <div class="col-lg-2 col-md-6">
                <label class="form-label">Codartículo</label>
                <input type="text" name="codarticulo" value="<?= h($codarticulo) ?>" class="form-control" placeholder="Artículo">
            </div>

            <div class="col-lg-1 col-md-12 d-flex align-items-end gap-2">
                <button class="btn btn-primary btn-modern w-100">
                    <i class="bi bi-search"></i>
                </button>

                <a href="/exhibicion_DT/index.php?vista=modulo3" class="btn btn-outline-secondary btn-modern">
                    <i class="bi bi-x-circle"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- PASO 33: SIN TIENDA -->
    <?php if ($codalmacen === ''): ?>
        <div class="card result-card">
            <div class="empty-state">
                <i class="bi bi-shop-window"></i>
                <h5 class="fw-bold">Seleccione una tienda</h5>
                <p class="mb-0">Para consultar productos en exhibición sin stock, primero seleccione un CODALMACEN.</p>
            </div>
        </div>
    <?php else: ?>

     

            <div class="table-responsive" id="tablaExhibicion">

                <!-- PASO 35: MENÚ FLOTANTE TIPO EXCEL -->
                <div id="excelMenu" class="excel-menu" hidden>
                    <div class="excel-menu-head">
                        <strong id="excelMenuTitle">Filtrar</strong>

                        <button type="button" id="excelMenuClose" class="excel-menu-close">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <input type="hidden" id="excelField">

                    <div class="excel-menu-body">
                        <select id="excelOrder" class="excel-menu-input">
                            <option value="asc">Ordenar A → Z</option>
                            <option value="desc">Ordenar Z → A</option>
                        </select>

                        <input type="text" id="excelSearch" class="excel-menu-input" placeholder="Buscar...">

                        <label class="excel-check-all">
                            <input type="checkbox" id="excelSelectAll">
                            Seleccionar todo
                        </label>

                        <div id="excelOptions" class="excel-options"></div>

                        <div class="excel-menu-actions">
                            <button type="button" id="excelApply" class="btn btn-primary btn-sm">
                                <i class="bi bi-check2"></i>
                                Aplicar
                            </button>

                            <button type="button" id="excelClear" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-eraser"></i>
                                Limpiar
                            </button>
                        </div>
                    </div>
                </div>

                <form
                    method="POST"
                    action="/exhibicion_DT/exhibiciontotal/guardar_exhibicion_masivo_nuevo.php"
                    id="formGuardarMasivoSinStock"
                >
                    <input type="hidden" name="return_qs" value="<?= h($_SERVER['QUERY_STRING'] ?? '') ?>">

                <table class="table table-hover table-modern align-middle">
                    <thead>
                        <tr>
                            <!-- =====================================================
                                 PASO 35.1: CHECKBOX MASIVO
                                 Este checkbox marca o desmarca todos los registros visibles.
                            ====================================================== -->
                            <th>
                                <div class="excel-th">
                                    <input type="checkbox" id="checkTodosMasivo" title="Seleccionar todos">
                                </div>
                            </th>

                            <!-- =====================================================
                                 PASO 35.2: COLUMNA DE NUMERACIÓN
                                 Muestra 1, 2, 3... y continúa según la página.
                            ====================================================== -->
                            <th class="sin-col-num">N°</th>

                            <?php
                            $headers = [
                               /* 'estado'       => 'Estado',*/
                               /* 'region'       => 'Región',*/
                              /*  'almacen'      => 'Tienda',*/
                               /* 'codarticulo'  => 'CodArtículo',*/
                                'referencia'   => 'Referencia',
                                'codbarras'    => 'Código barras',
                                'plu'          => 'PLU',
                                'descripcion'  => 'Descripción',
                                'departamento' => 'Departamento',
                                'seccion'      => 'Sección',
                                'familia'      => 'Familia',
                                'inventario'   => 'Inventario',
                                'exhibicion'   => 'Exhibición',
                                'uxc'          => 'UXC',
                            ];
                            ?>

                            <?php foreach ($headers as $field => $label): ?>
                                <th>
                                    <div class="excel-th">
                                        <span><?= h($label) ?></span>

                                        <?php if (!in_array($field, ['estado', 'inventario'], true)): ?>
                                            <button
                                                type="button"
                                                class="excel-filter-btn <?= trim((string)($_GET[$field] ?? '')) !== '' ? 'is-active' : '' ?>"
                                                data-field="<?= h($field) ?>"
                                                data-label="<?= h($label) ?>"
                                            >
                                                <i class="bi bi-funnel-fill"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </th>
                            <?php endforeach; ?>

                            <!-- =====================================================
                                 PASO 35.3: BOTÓN GUARDAR INDIVIDUAL
                                 Permite guardar solo una fila sin marcar manualmente.
                            ====================================================== -->
                            <th>Guardar</th>

                        </tr>
                    </thead>

                    <tbody>
                    <?php if (empty($resultados)): ?>
                        <tr>
                            <td colspan="13">
                                <div class="empty-state">
                                    <i class="bi bi-check-circle"></i>
                                    <h5 class="fw-bold">Todo bien</h5>
                                    <p class="mb-0">No hay productos en exhibición sin stock para esta tienda.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php
                    /*
                    |--------------------------------------------------------------------------
                    | PASO 36.1: NUMERACIÓN DE FILAS
                    |--------------------------------------------------------------------------
                    | Si estás en la página 1: 1, 2, 3...
                    | Si estás en la página 2: continúa según el offset.
                    |--------------------------------------------------------------------------
                    */
                    $numeroFila = $offset + 1;
                    ?>

                    <?php foreach ($resultados as $i => $r): ?>
                        <tr>
                            <?php $i = (int)$i; ?>

                            <td data-label="Seleccionar">
                                <input
                                    type="checkbox"
                                    class="check-fila-masivo"
                                    name="items[<?= $i ?>][seleccionado]"
                                    value="1"
                                >

                                <input type="hidden" name="items[<?= $i ?>][region]" value="<?= h($r['REGION'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codalmacen]" value="<?= h($r['CODALMACEN'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codarticulo]" value="<?= h($r['CODARTICULO'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codbarras]" value="<?= h($r['CODBARRAS'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][plu]" value="<?= h($r['PLU'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][uxc]" value="<?= h($r['UXC'] ?? 0) ?>">

                                <!-- Datos extra para auditoría/dashboard -->
                                <input type="hidden" name="items[<?= $i ?>][zona]" value="<?= h($infoTiendaSeleccionada['zona'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][nombrealmacen]" value="<?= h($r['ALMACEN'] ?? ($infoTiendaSeleccionada['nombre'] ?? '')) ?>">
                            </td>

                            <!-- =====================================================
                                 PASO 36.2: NÚMERO VISIBLE DE FILA
                            ====================================================== -->
                            <td class="sin-col-num" data-label="N°">
                                <span><?= $numeroFila++ ?></span>
                            </td>

                            <td data-field="referencia" data-label="Referencia"><?= h($r['REFERENCIA'] ?? '') ?></td>
                            <td data-field="codbarras" data-label="Código barras"><?= h($r['CODBARRAS'] ?? '') ?></td>
                            <td data-field="plu" data-label="PLU"><?= h($r['PLU'] ?? '') ?></td>
                            <td data-field="descripcion" data-label="Descripción"><?= h($r['DESCRIPCION'] ?? '') ?></td>
                            <td data-field="departamento" data-label="Departamento"><?= h($r['DEPARTAMENTO'] ?? '') ?></td>
                            <td data-field="seccion" data-label="Sección"><?= h($r['SECCION'] ?? '') ?></td>
                            <td data-field="familia" data-label="Familia"><?= h($r['FAMILIA'] ?? '') ?></td>

                            <td data-field="inventario" data-label="Inventario">
                                <span class="badge badge-soft-warning rounded-pill">0</span>
                            </td>

                            <td data-field="exhibicion" data-label="Exhibición" style="min-width:90px;">
                                <input
                                    type="number"
                                    class="form-control form-control-sm excel-value-input"
                                    name="items[<?= $i ?>][exhibicion]"
                                    value="<?= h($r['EXHIBICION'] ?? 0) ?>"
                                    min="0"
                                    max="99999"
                                    required
                                    oninput="this.value=this.value.replace(/\D/g,'').slice(0,5);"
                                >
                            </td>

                            <td data-field="uxc" data-label="UXC">
                                <?= h($r['UXC'] ?? 0) ?>
                            </td>

                            <!-- =====================================================
                                 PASO 36.3: BOTÓN GUARDAR INDIVIDUAL
                                 Este botón guarda solo esta fila.
                                 El JavaScript marca únicamente esta fila antes de enviar.
                            ====================================================== -->
                            <td data-label="Guardar">
                                <button
                                    type="submit"
                                    class="btn btn-primary btn-sm btn-guardar-fila"
                                    title="Guardar solo este registro"
                                >
                                    <i class="bi bi-save-fill"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-end mt-3">
                    <button
                        type="submit"
                        class="btn btn-primary btn-modern"
                        id="btnGuardarMasivoBottom"
                        <?= empty($resultados) ? 'disabled' : '' ?>
                    >
                        <i class="bi bi-save2 me-1"></i>
                        Guardar
                    </button>
                </div>

                <!-- =====================================================
                     PASO 36.4: BOTÓN FLOTANTE DE GUARDADO MASIVO
                     Siempre queda visible para guardar sin subir arriba.
                ====================================================== -->
                <div class="floating-save-wrap">
                    <button
                        type="submit"
                        form="formGuardarMasivoSinStock"
                        class="floating-save-btn"
                        id="btnGuardarMasivoFloat"
                        <?= empty($resultados) ? 'disabled' : '' ?>
                    >
                        <i class="bi bi-save2-fill"></i>
                        <span>Guardar</span>
                    </button>
                </div>

                </form>
            </div>

            <!-- PASO 37: PAGINACIÓN -->
            <div class="d-flex justify-content-center mt-4">
                <nav>
                    <ul class="pagination pagination-sm flex-wrap">
                        <?php $qs = $_GET; ?>

                        <?php $qs['page'] = max(1, $page - 1); ?>
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= h(http_build_query($qs)) ?>">Anterior</a>
                        </li>

                        <li class="page-item active">
                            <span class="page-link">Página <?= h($page) ?></span>
                        </li>

                        <?php $qs['page'] = $page + 1; ?>
                        <li class="page-item <?= !$haySiguiente ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= h(http_build_query($qs)) ?>">Siguiente</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | PASO 1: ELEMENTOS DEL FILTRO
    |--------------------------------------------------------------------------
    */
    const excelMenu = document.getElementById('excelMenu');
    const excelMenuTitle = document.getElementById('excelMenuTitle');
    const excelMenuClose = document.getElementById('excelMenuClose');
    const excelField = document.getElementById('excelField');
    const excelSearch = document.getElementById('excelSearch');
    const excelOptions = document.getElementById('excelOptions');
    const excelSelectAll = document.getElementById('excelSelectAll');
    const excelApply = document.getElementById('excelApply');
    const excelOrder = document.getElementById('excelOrder');
    const excelClear = document.getElementById('excelClear');
    const filterButtons = document.querySelectorAll('.excel-filter-btn');
    const formFiltros = document.getElementById('formFiltrosSinStock');
    const btnGuardarMasivoFloat = document.getElementById('btnGuardarMasivoFloat');

    /*
    |--------------------------------------------------------------------------
    | PASO 1.1: RESTAURAR POSICIÓN DESPUÉS DE GUARDAR
    |--------------------------------------------------------------------------
    | Cuando la página regresa del backend, vuelve al mismo punto donde estabas.
    |--------------------------------------------------------------------------
    */
    const savedScroll = sessionStorage.getItem('scrollSinStockTabla');

    if (savedScroll !== null) {
        setTimeout(() => {
            window.scrollTo({
                top: parseInt(savedScroll, 10),
                behavior: 'auto'
            });

            sessionStorage.removeItem('scrollSinStockTabla');
        }, 150);
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 1.2: GUARDAR POSICIÓN ANTES DE ENVIAR
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function () {
            sessionStorage.setItem(
                'scrollSinStockTabla',
                String(window.scrollY)
            );
        });
    });

    if (!excelMenu || !formFiltros) {
        return;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 2: NORMALIZAR TEXTO
    |--------------------------------------------------------------------------
    */
    function normalizar(texto) {
        return String(texto || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 3: OBTENER INPUT DEL FORMULARIO
    |--------------------------------------------------------------------------
    */
    function getInputFiltro(field) {
        return formFiltros.querySelector('[name="' + field + '"]');
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 4: CERRAR MENÚ
    |--------------------------------------------------------------------------
    */
    function cerrarMenu() {
        excelMenu.hidden = true;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 5: VALORES YA SELECCIONADOS
    |--------------------------------------------------------------------------
    */
    function getSelectedValues(field) {
        const input = getInputFiltro(field);
        const value = input ? input.value.trim() : '';

        if (value === '' || value.startsWith('_LIKE_')) {
            return [];
        }

        return value.split('||').filter(v => v.trim() !== '');
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 6: OBTENER VALORES VISIBLES DE LA TABLA
    |--------------------------------------------------------------------------
    */
   function getColumnValues(field) {

    const values = new Set();

    document.querySelectorAll('[data-field="' + field + '"]').forEach(td => {

        let value = '';

        const input = td.querySelector('input[name="exhibicion"]');

        if (input) {
            value = input.value.trim();
        } else {
            value = td.textContent.trim();
        }

        if (value !== '') {
            values.add(value);
        }
    });

    let arr = Array.from(values).filter(v => v !== '');

    /*
    |--------------------------------------------------------------------------
    | ORDEN A → Z / Z → A
    |--------------------------------------------------------------------------
    */
    if (excelOrder && excelOrder.value === 'desc') {

        arr.sort((a, b) =>
            String(b).localeCompare(String(a), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );

    } else {

        arr.sort((a, b) =>
            String(a).localeCompare(String(b), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );
    }

    return arr;
}
    /*
    |--------------------------------------------------------------------------
    | PASO 7: PINTAR OPCIONES
    |--------------------------------------------------------------------------
    */
    function renderOptions(values, selectedValues = []) {
        excelOptions.innerHTML = '';

        values.forEach(value => {
            const checked = selectedValues.includes(value) ? 'checked' : '';
            const label = document.createElement('label');

            label.className = 'excel-option';
            label.dataset.value = normalizar(value);

            label.innerHTML = `
                <input type="checkbox" class="excel-option-check" value="${value}" ${checked}>
                <span>${value}</span>
            `;

            excelOptions.appendChild(label);
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 8: ABRIR FILTRO
    |--------------------------------------------------------------------------
    */
    function abrirMenu(btn) {
        const field = btn.dataset.field;
        const label = btn.dataset.label;

        excelField.value = field;
        excelMenuTitle.textContent = label;
        excelSearch.value = '';

        const selectedValues = getSelectedValues(field);
        const values = getColumnValues(field);

        renderOptions(values, selectedValues);

        excelSelectAll.checked = selectedValues.length > 0 && selectedValues.length === values.length;

        excelMenu.hidden = false;
        setTimeout(() => excelSearch.focus(), 30);
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 9: BOTONES DE FILTRO
    |--------------------------------------------------------------------------
    */
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            abrirMenu(btn);
        });
    });

    /*
|--------------------------------------------------------------------------
| CAMBIAR ORDEN DEL MENÚ
|--------------------------------------------------------------------------
*/
if (excelOrder) {

    excelOrder.addEventListener('change', function () {

        const field = excelField.value;

        if (!field) {
            return;
        }

        const selectedValues = getSelectedValues(field);

        const values = getColumnValues(field);

        renderOptions(values, selectedValues);
    });
}

    /*
    |--------------------------------------------------------------------------
    | PASO 10: BUSCAR DENTRO DEL FILTRO
    |--------------------------------------------------------------------------
    */
    excelSearch.addEventListener('input', function () {
        const search = normalizar(this.value);

        document.querySelectorAll('.excel-option').forEach(option => {
            const value = option.dataset.value || '';
            option.style.display = value.includes(search) ? 'flex' : 'none';
        });

        excelSelectAll.checked = false;
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 11: SELECCIONAR TODO VISIBLE
    |--------------------------------------------------------------------------
    */
    excelSelectAll.addEventListener('change', function () {
        document.querySelectorAll('.excel-option').forEach(option => {
            if (option.style.display !== 'none') {
                const check = option.querySelector('.excel-option-check');

                if (check) {
                    check.checked = excelSelectAll.checked;
                }
            }
        });
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 12: APLICAR FILTRO
    |--------------------------------------------------------------------------
    */
    excelApply.addEventListener('click', function () {
        const field = excelField.value;
        const input = getInputFiltro(field);

        if (!input) {
            return;
        }

        const selected = [];

        document.querySelectorAll('.excel-option-check:checked').forEach(check => {
            selected.push(check.value);
        });

        if (selected.length > 0) {
            input.value = selected.join('||');
        } else {
            const texto = excelSearch.value.trim();
            input.value = texto !== '' ? '_LIKE_' + texto : '';
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 12A: ENVIAR ORDEN AL PHP
        |--------------------------------------------------------------------------
        | Aquí se guarda qué columna se tocó y si se eligió A→Z o Z→A.
        | Esto hace que SQL Server ordene TODA la tabla, no solo el menú.
        |--------------------------------------------------------------------------
        */
        const inputOrdenCampo = document.getElementById('orden_campo');
        const inputOrdenDir = document.getElementById('orden_dir');

        if (inputOrdenCampo && inputOrdenDir && excelOrder) {
            inputOrdenCampo.value = field;
            inputOrdenDir.value = excelOrder.value;
        }

        formFiltros.submit();
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 13: LIMPIAR FILTRO ACTUAL
    |--------------------------------------------------------------------------
    */
    excelClear.addEventListener('click', function () {
        const field = excelField.value;
        const input = getInputFiltro(field);

        if (!input) {
            return;
        }

        input.value = '';

        /*
        |--------------------------------------------------------------------------
        | PASO 13A: AL LIMPIAR, VOLVER AL ORDEN BASE
        |--------------------------------------------------------------------------
        */
        const inputOrdenCampo = document.getElementById('orden_campo');
        const inputOrdenDir = document.getElementById('orden_dir');

        if (inputOrdenCampo && inputOrdenDir) {
            inputOrdenCampo.value = 'codarticulo';
            inputOrdenDir.value = 'asc';
        }

        formFiltros.submit();
    });

    /*
    |--------------------------------------------------------------------------
    | PASO 14: CERRAR FILTRO
    |--------------------------------------------------------------------------
    */
    excelMenuClose.addEventListener('click', cerrarMenu);

    document.addEventListener('click', function (e) {
        if (!excelMenu.hidden && !excelMenu.contains(e.target)) {
            cerrarMenu();
        }
    });

    excelMenu.addEventListener('wheel', function (e) {
        e.stopPropagation();
    });


    /*
    |--------------------------------------------------------------------------
    | PASO 15: SELECCIÓN MASIVA Y VALIDACIÓN DE GUARDADO
    |--------------------------------------------------------------------------
    */
    const checkTodosMasivo = document.getElementById('checkTodosMasivo');
    const formGuardarMasivo = document.getElementById('formGuardarMasivoSinStock');

    if (checkTodosMasivo) {
        checkTodosMasivo.addEventListener('change', function () {
            document.querySelectorAll('.check-fila-masivo').forEach(check => {
                check.checked = checkTodosMasivo.checked;
            });
        });
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 15.1: BOTÓN GUARDAR INDIVIDUAL POR FILA
    |--------------------------------------------------------------------------
    | Al presionar el botón pequeño de una fila:
    | - desmarca todas las demás filas
    | - marca solo esa fila
    | - envía el mismo formulario masivo
    | Así se guarda un solo registro sin duplicar formularios.
    |--------------------------------------------------------------------------
    */
    document.querySelectorAll('.btn-guardar-fila').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const fila = btn.closest('tr');

            if (!fila || !formGuardarMasivo) {
                return;
            }

            document.querySelectorAll('.check-fila-masivo').forEach(check => {
                check.checked = false;
            });

            const checkFila = fila.querySelector('.check-fila-masivo');

            if (checkFila) {
                checkFila.checked = true;
            }

            sessionStorage.setItem(
                'scrollSinStockTabla',
                String(window.scrollY)
            );

            if (typeof formGuardarMasivo.requestSubmit === 'function') {
                formGuardarMasivo.requestSubmit();
            } else {
                formGuardarMasivo.submit();
            }
        });
    });

    if (formGuardarMasivo) {
        formGuardarMasivo.addEventListener('submit', function (e) {
            const seleccionados = document.querySelectorAll('.check-fila-masivo:checked');

            if (seleccionados.length === 0) {
                e.preventDefault();
                alert('Seleccione al menos un registro para guardar.');
                return;
            }

            const btnTop = document.getElementById('btnGuardarMasivo');
            const btnBottom = document.getElementById('btnGuardarMasivoBottom');
            const btnFloat = document.getElementById('btnGuardarMasivoFloat');

            [btnTop, btnBottom, btnFloat].forEach(btn => {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Guardando...';
                }
            });
        });
    }
});
</script>