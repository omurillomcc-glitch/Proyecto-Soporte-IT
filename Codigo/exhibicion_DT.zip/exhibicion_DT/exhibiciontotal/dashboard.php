<?php
declare(strict_types=1);

/* =========================================================
   PASO 1) INICIAR SESIÓN
   ========================================================= */
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* =========================================================
   PASO 2) MOSTRAR ERRORES EN DESARROLLO
   ========================================================= */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

/* =========================================================
   PASO 3) CARGAR ARCHIVOS NECESARIOS
   ========================================================= */
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

/* =========================================================
   PASO 4) ASEGURAR CONEXIÓN GLOBAL
   ========================================================= */
if (isset($conn) && $conn instanceof mysqli) {
    $GLOBALS['conn'] = $conn;
}

/* =========================================================
   PASO 5) VALIDAR LOGIN
   ========================================================= */
require_login();
$me = me();

/* =========================================================
   PASO 6) BLOQUEAR DASHBOARD PARA PERFIL TIENDA
   ========================================================= */
if (($me['rol'] ?? '') === 'tienda') {
    echo '<div class="alert alert-warning m-3">No tienes acceso al dashboard.</div>';
    return;
}

/* =========================================================
   PASO 7) HELPERS GENERALES
   ========================================================= */
function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function db_conn(): mysqli
{
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
        return $GLOBALS['conn'];
    }

    http_response_code(500);
    exit('<div class="alert alert-danger m-3">No hay conexión a la base de datos.</div>');
}

function table_exists(mysqli $conn, string $table): bool
{
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res instanceof mysqli_result && $res->num_rows > 0;
}

function column_exists(mysqli $conn, string $table, string $column): bool
{
    $table  = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
    return $res instanceof mysqli_result && $res->num_rows > 0;
}

function pick_first_existing_column(mysqli $conn, string $table, array $candidates): string
{
    foreach ($candidates as $col) {
        if (column_exists($conn, $table, $col)) {
            return $col;
        }
    }

    return '';
}

function fetch_rows(mysqli $conn, string $sql, array $params = [], string $types = ''): array
{
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    if ($params) {
        if ($types === '') {
            foreach ($params as $p) {
                $types .= is_int($p) ? 'i' : 's';
            }
        }

        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        $stmt->close();
        return [];
    }

    $res = $stmt->get_result();

    if (!$res) {
        $stmt->close();
        return [];
    }

    $rows = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows ?: [];
}

function fetch_scalar(mysqli $conn, string $sql, array $params = [], string $types = ''): mixed
{
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return null;
    }

    if ($params) {
        if ($types === '') {
            foreach ($params as $p) {
                $types .= is_int($p) ? 'i' : 's';
            }
        }

        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        $stmt->close();
        return null;
    }

    $res = $stmt->get_result();

    if (!$res) {
        $stmt->close();
        return null;
    }

    $row = $res->fetch_row();
    $stmt->close();

    return $row[0] ?? null;
}

function fetch_one_int(mysqli $conn, string $sql, array $params = [], string $types = ''): int
{
    return (int)(fetch_scalar($conn, $sql, $params, $types) ?? 0);
}

/* =========================================================
   PASO 8) HELPERS PARA AUDITORÍA Y TIENDAS
   ========================================================= */
function extract_store_code_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/CODALMACEN:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    if (preg_match('/TIENDA:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    return '';
}

function extract_zone_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/ZONA:\s*([^|]+)/i', $detalle, $m)) {
        return strtoupper(trim((string)$m[1]));
    }

    return '';
}

function extract_region_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/REGION:\s*([^|]+)/i', $detalle, $m)) {
        return normalizar_region_dashboard((string)$m[1]);
    }

    return '';
}

function extract_codarticulo_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/CODARTICULO:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    if (preg_match('/CODIGO:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    return '';
}

function region_label_from_pais_code(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}

function normalizar_region_dashboard(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $region,
    };
}

/* =========================================================
   PASO 8.1) ACCIONES DE EXHIBICIÓN PARA DASHBOARD
   ---------------------------------------------------------
   Aquí agregamos las acciones del guardado masivo.
   IMPORTANTE:
   El backend masivo debe guardar en auditoría una acción como:
   - CREAR_EXHIBICION_MASIVO
   - EDITAR_EXHIBICION_MASIVO
   - GUARDAR_EXHIBICION_MASIVO
   ========================================================= */
function dashboard_exhibicion_actions(): array
{
    return [

        /*
        |--------------------------------------------------------------------------
        | EXHIBICIÓN NORMAL
        |--------------------------------------------------------------------------
        */
        'CREAR_EXHIBICION',
        'EDITAR_EXHIBICION',

        /*
        |--------------------------------------------------------------------------
        | MASIVO NORMAL
        |--------------------------------------------------------------------------
        */
        'CREAR_EXHIBICION_MASIVO',
        'EDITAR_EXHIBICION_MASIVO',
        'GUARDAR_EXHIBICION_MASIVO',

        /*
        |--------------------------------------------------------------------------
        | MASIVO SIN STOCK
        |--------------------------------------------------------------------------
        */
        'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO',
    ];
}

function dashboard_sql_placeholders(int $count): string
{
    return implode(',', array_fill(0, max(1, $count), '?'));
}

function dashboard_accion_label(string $accion): string
{
    $accion = strtoupper(trim($accion));

    return match ($accion) {

        'CREAR_EXHIBICION'
            => 'Creó exhibición',

        'EDITAR_EXHIBICION'
            => 'Editó exhibición',

        'CREAR_EXHIBICION_MASIVO'
            => 'Creó exhibición masiva',

        'EDITAR_EXHIBICION_MASIVO'
            => 'Editó exhibición masiva',

        'GUARDAR_EXHIBICION_MASIVO'
            => 'Guardado masivo',

        /*
        |--------------------------------------------------------------------------
        | NUEVO SIN STOCK
        |--------------------------------------------------------------------------
        */
        'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO'
            => 'Guardado masivo sin stock',

        default
            => 'Movimiento de exhibición',
    };
}

function dashboard_badge_class(string $accion): string
{
    $accion = strtoupper(trim($accion));

    /*
    |--------------------------------------------------------------------------
    | CREAR
    |--------------------------------------------------------------------------
    */
    if (str_contains($accion, 'CREAR')) {
        return 'badge-create';
    }

    /*
    |--------------------------------------------------------------------------
    | MASIVO
    |--------------------------------------------------------------------------
    */
    if (
        str_contains($accion, 'MASIVO') ||
        str_contains($accion, 'SIN_STOCK')
    ) {
        return 'badge-masivo';
    }

    /*
    |--------------------------------------------------------------------------
    | EDITAR
    |--------------------------------------------------------------------------
    */
    return 'badge-edit';
}

/* =========================================================
   PASO 9) LLAVE ÚNICA DE TIENDA
   ---------------------------------------------------------
   IMPORTANTE:
   Antes el dashboard usaba solo codalmacen:
   05

   Eso podía mezclar:
   05 Ceiba
   05 Las Américas

   Ahora se usa:
   REGION + ZONA + CODALMACEN

   Ejemplo:
   HONDURAS-CEIBA-05
   HONDURAS-LAS AMERICAS-05
   ========================================================= */
function dashboard_store_key(string $region, string $zona, string $codalmacen): string
{
    $region     = normalizar_region_dashboard($region);
    $codalmacen = strtoupper(trim($codalmacen));

    return $region . '-' . $codalmacen;
}

/* =========================================================
   PASO 10) NORMALIZAR ETIQUETAS DEL DETALLE
   ========================================================= */
function normalize_label(string $label): string
{
    $label = trim(str_replace('_', ' ', $label));
    $label = preg_replace('/\s+/', ' ', $label) ?? $label;
    $upper = strtoupper($label);

    return match ($upper) {
        'CODALMACEN'  => 'Código tienda',
        'CODARTICULO' => 'Codarticulo',
        'CODBARRAS'   => 'Codbarras',
        'EXHIBICION'  => 'Exhibición',
        'UXC'         => 'UXC',
        'TOTAL'       => 'Total',
        'GUARDADOS'   => 'Guardados',
        'MASIVO'      => 'Masivo',
        'REGION'      => 'Región',
        'ZONA'        => 'Zona',
        'PLU'         => 'Plu',
        default       => ucwords(mb_strtolower($label, 'UTF-8')),
    };
}

function split_detail_lines(string $detalle): array
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return [];
    }

    $parts = preg_split('/\s*\|\s*/u', $detalle) ?: [];
    $out = [];

    foreach ($parts as $part) {
        $part = trim($part);

        if ($part === '') {
            continue;
        }

        if (preg_match('/^\s*([^:]{2,80})\s*:\s*(.+)\s*$/u', $part, $m)) {
            $rawLabel = trim((string)$m[1]);
            $label = normalize_label($rawLabel);
            $value = trim((string)$m[2]);


            /*ocultar del detalle de movimiento region, tienda*/

          if (in_array($label, ['Código tienda', 'Región','Tienda','Codarticulo'], true)) {
    continue;
}

            if (
                stripos($rawLabel, 'Se Actualizó Exhibición.') !== false ||
                stripos($rawLabel, 'Se actualizó exhibición.') !== false ||
                stripos($rawLabel, 'Se Creó Exhibición.') !== false ||
                stripos($rawLabel, 'Se creó exhibición.') !== false
            ) {
                continue;
            }

            if ($label !== '' && $value !== '') {
                $out[] = [
                    'label' => $label,
                    'value' => $value,
                ];
            }
        }
    }

    $orden = [
        
        'Codbarras'   => 1,
        'Plu'         => 2,
        'Exhibición'  => 3,
        'Zona'        => 4,
    ];

    usort($out, function ($a, $b) use ($orden) {
        $oa = $orden[$a['label']] ?? 99;
        $ob = $orden[$b['label']] ?? 99;
        return $oa <=> $ob;
    });

    return $out;
}

function extract_detail_title(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (stripos($detalle, 'Se actualizó exhibición') !== false) {
        return 'Se actualizó exhibición';
    }

    if (stripos($detalle, 'Se creó exhibición') !== false) {
        return 'Se creó exhibición';
    }

    if (stripos($detalle, 'masivo') !== false || stripos($detalle, 'seleccionados') !== false) {
        return 'Guardado masivo de exhibición';
    }

    return 'Movimiento de exhibición';
}

/* =========================================================
   PASO 11) FILTRO DE USUARIOS SEGÚN ROL
   ========================================================= */
function build_user_scope(
    mysqli $conn,
    int $miId,
    string $rol,
    string $paisCode,
    string $zona,
    string $tienda
): array {
    $where  = "1=1";
    $params = [];
    $types  = '';

    $paisCode = strtoupper(trim($paisCode));
    $zona     = strtoupper(trim($zona));
    $tienda   = strtoupper(trim($tienda));

    if ($rol === 'super_admin') {
        if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
            $where .= " AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?";
            $params[] = $paisCode;
            $types   .= 's';
        }

        return [$where, $params, $types];
    }

    if ($rol === 'admin_zona') {
        $hasUsuarioTienda = table_exists($conn, 'usuario_tienda')
            && column_exists($conn, 'usuario_tienda', 'usuario_id')
            && column_exists($conn, 'usuario_tienda', 'codalmacen');

        if ($hasUsuarioTienda) {
            $where .= " AND EXISTS (
                SELECT 1
                FROM usuario_tienda ut_admin
                INNER JOIN usuario_tienda ut_user
                    ON CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.pais, ''), 'HN'))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.zona, ''), ''))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.codalmacen, ''), '')))
                    ) = CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.pais, ''), 'HN'))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.zona, ''), ''))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.codalmacen, ''), '')))
                    )
                WHERE ut_admin.usuario_id = ?
                  AND ut_user.usuario_id = u.id
            )";

            $params[] = $miId;
            $types   .= 'i';
        }

        if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
            $where .= " AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?";
            $params[] = $paisCode;
            $types   .= 's';
        }

        return [$where, $params, $types];
    }

    if ($rol === 'tienda') {
        if ($tienda !== '' && column_exists($conn, 'usuarios', 'tienda')) {
            $where .= " AND UPPER(TRIM(COALESCE(u.tienda, ''))) = ?";
            $params[] = $tienda;
            $types   .= 's';

            if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
                $where .= " AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?";
                $params[] = $paisCode;
                $types   .= 's';
            }
        }

        return [$where, $params, $types];
    }

    return [$where, $params, $types];
}

/* =========================================================
   PASO 12) FILTRO DE AUDITORÍA SEGÚN ROL
   ---------------------------------------------------------
   super_admin:
   - Ve todo lo de su país.

   admin_zona:
   - Ve SOLO movimientos de las tiendas que tiene asignadas
     en usuario_tienda.
   - Filtra por país/región y codalmacen.
   - Si la columna codalmacen viene vacía, intenta buscar
     CODALMACEN dentro de descripcion/detalle.
   ========================================================= */
function build_audit_scope(
    mysqli $conn,
    int $miId,
    string $rol,
    string $paisCode,
    string $zona,
    string $tienda,
    string $accionCol,
    string $zonaCol,
    string $tiendaCol,
    string $detalleCol,
    string $regionCol
): array {

    /*
    |--------------------------------------------------------------------------
    | 1) ACCIONES DE EXHIBICIÓN QUE SE TOMAN EN CUENTA
    |--------------------------------------------------------------------------
    */
    $acciones = dashboard_exhibicion_actions();
    $placeholders = dashboard_sql_placeholders(count($acciones));

    $where  = "UPPER(TRIM({$accionCol})) IN ($placeholders)";
    $params = $acciones;
    $types  = str_repeat('s', count($acciones));

    /*
    |--------------------------------------------------------------------------
    | 2) NORMALIZAR DATOS DEL USUARIO
    |--------------------------------------------------------------------------
    */
    $rol      = strtolower(trim($rol));
    $paisCode = strtoupper(trim($paisCode));
    $zona     = strtoupper(trim($zona));
    $tienda   = strtoupper(trim($tienda));

    $regionUsuario = region_label_from_pais_code($paisCode);
    $regionUsuario = normalizar_region_dashboard($regionUsuario);

    /*
    |--------------------------------------------------------------------------
    | 3) SUPER ADMIN
    |-------------------------------------------------------------------------- 
    | Ve todo lo de su país.
    |--------------------------------------------------------------------------
    */
    if ($rol === 'super_admin') {

        if ($regionCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(TRIM(COALESCE({$regionCol}, ''))) = ?";
            $params[] = $regionUsuario;
            $types .= 's';
        } elseif ($detalleCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
            $params[] = '%REGION: ' . $regionUsuario . '%';
            $types .= 's';
        } else {
            $where .= " AND 1 = 0";
        }

        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | 4) ADMIN ZONA
    |-------------------------------------------------------------------------- 
    | Aquí está lo importante:
    | - Buscar las tiendas asignadas al admin_zona.
    | - Filtrar auditoría SOLO por esas tiendas.
    |--------------------------------------------------------------------------
    */
    if ($rol === 'admin_zona') {

        /*
        |--------------------------------------------------------------------------
        | Validar que exista usuario_tienda
        |--------------------------------------------------------------------------
        */
        if (
            !table_exists($conn, 'usuario_tienda') ||
            !column_exists($conn, 'usuario_tienda', 'usuario_id') ||
            !column_exists($conn, 'usuario_tienda', 'codalmacen')
        ) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        /*
        |--------------------------------------------------------------------------
        | 4.1) Obtener códigos de tiendas asignadas al admin_zona
        |--------------------------------------------------------------------------
        */
        $codigosTiendas = [];

        $sqlTiendas = "
            SELECT DISTINCT
                UPPER(TRIM(COALESCE(codalmacen, ''))) AS codalmacen
            FROM usuario_tienda
            WHERE usuario_id = ?
              AND TRIM(COALESCE(codalmacen, '')) <> ''
              AND (
                    UPPER(TRIM(COALESCE(pais, ''))) = ?
                    OR UPPER(TRIM(COALESCE(pais, ''))) = ?
                  )
        ";

        $stmtTiendas = $conn->prepare($sqlTiendas);

        if (!$stmtTiendas) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        $stmtTiendas->bind_param(
            'iss',
            $miId,
            $paisCode,
            $regionUsuario
        );

        $stmtTiendas->execute();
        $resTiendas = $stmtTiendas->get_result();

        if ($resTiendas) {
            while ($rowTienda = $resTiendas->fetch_assoc()) {
                $cod = strtoupper(trim((string)($rowTienda['codalmacen'] ?? '')));

                if ($cod !== '') {
                    $codigosTiendas[] = $cod;
                }
            }
        }

        $stmtTiendas->close();

        $codigosTiendas = array_values(array_unique($codigosTiendas));

        /*
        |--------------------------------------------------------------------------
        | Si el admin_zona no tiene tiendas, no ve nada.
        |--------------------------------------------------------------------------
        */
        if (empty($codigosTiendas)) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        /*
        |--------------------------------------------------------------------------
        | 4.2) Filtrar por región/país
        |--------------------------------------------------------------------------
        */
        if ($regionCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(TRIM(COALESCE({$regionCol}, ''))) = ?";
            $params[] = $regionUsuario;
            $types .= 's';
        } elseif ($detalleCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
            $params[] = '%REGION: ' . $regionUsuario . '%';
            $types .= 's';
        } else {
            $where .= " AND 1 = 0";
        }

        /*
        |--------------------------------------------------------------------------
        | 4.3) Filtrar por las tiendas asignadas
        |--------------------------------------------------------------------------
        | Caso moderno:
        | - auditoria.codalmacen tiene dato.
        |
        | Caso alterno:
        | - auditoria.codalmacen está vacío.
        | - busca CODALMACEN dentro de descripcion/detalle.
        |--------------------------------------------------------------------------
        */
        $placeholdersTiendas = implode(',', array_fill(0, count($codigosTiendas), '?'));

        if ($tiendaCol !== '') {

            $where .= "
                AND (
                    UPPER(TRIM(COALESCE({$tiendaCol}, ''))) IN ($placeholdersTiendas)
            ";

            foreach ($codigosTiendas as $cod) {
                $params[] = $cod;
                $types .= 's';
            }

            /*
            |--------------------------------------------------------------------------
            | Si hay detalle/descripcion, también buscamos CODALMACEN ahí.
            |--------------------------------------------------------------------------
            */
            if ($detalleCol !== '') {
                $where .= "
                    OR (
                        TRIM(COALESCE({$tiendaCol}, '')) = ''
                        AND (
                ";

                $condicionesDetalle = [];

                foreach ($codigosTiendas as $cod) {
                    $condicionesDetalle[] = "UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
                    $params[] = '%CODALMACEN: ' . $cod . '%';
                    $types .= 's';
                }

                $where .= implode(' OR ', $condicionesDetalle);

                $where .= "
                        )
                    )
                ";
            }

            $where .= "
                )
            ";

        } elseif ($detalleCol !== '') {

            $where .= " AND (";

            $condicionesDetalle = [];

            foreach ($codigosTiendas as $cod) {
                $condicionesDetalle[] = "UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
                $params[] = '%CODALMACEN: ' . $cod . '%';
                $types .= 's';
            }

            $where .= implode(' OR ', $condicionesDetalle);
            $where .= ")";

        } else {
            $where .= " AND 1 = 0";
        }

        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | 5) TIENDA
    |--------------------------------------------------------------------------
    | Aunque el dashboard lo bloqueas para tienda, dejamos protección.
    |--------------------------------------------------------------------------
    */
    if ($rol === 'tienda') {

        if ($tienda === '') {
            $where .= " AND 1 = 0";
            return [$where, $params, $types];
        }

        if ($tiendaCol !== '') {
            $where .= " AND UPPER(TRIM(COALESCE({$tiendaCol}, ''))) = ?";
            $params[] = $tienda;
            $types .= 's';
        } elseif ($detalleCol !== '') {
            $where .= " AND UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
            $params[] = '%CODALMACEN: ' . $tienda . '%';
            $types .= 's';
        } else {
            $where .= " AND 1 = 0";
        }

        return [$where, $params, $types];
    }

    /*
    |--------------------------------------------------------------------------
    | 6) Cualquier otro rol no ve nada
    |--------------------------------------------------------------------------
    */
    $where .= " AND 1 = 0";

      return [$where, $params, $types];
    }

/* =========================================================
   PASO 12.1) FILTRO POR PERIODO
   ========================================================= */
function build_period_scope(string $periodo, string $fechaCol): array { 
    return match ($periodo) { 
        'hoy' => ["DATE({$fechaCol}) = CURDATE()", [], ''], 
        //  semana actual del calendario (Modo 1 = Lunes a Domingo)
        'semana' => ["YEARWEEK({$fechaCol}, 1) = YEARWEEK(CURDATE(), 1)", [], ''], 
        'mes' => ["MONTH({$fechaCol}) = MONTH(CURDATE()) AND YEAR({$fechaCol}) = YEAR(CURDATE())", [], ''], 
        default => ["1=1", [], ''], 
    }; 
}


/* =========================================================
   PASO 13) DATOS DEL USUARIO ACTUAL
   ========================================================= */
$conn = db_conn();

$miId       = (int)($me['id'] ?? 0);
$rol        = (string)($me['rol'] ?? '');
$usuario    = (string)($me['usuario'] ?? 'Usuario');
$pais_code  = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));
$zona       = strtoupper(trim((string)($me['zona'] ?? '')));
$tienda     = strtoupper(trim((string)($me['tienda'] ?? '')));
$codalmacen = strtoupper(trim((string)($me['codalmacen'] ?? $me['tienda'] ?? '')));

if ($pais_code === '') {
    $pais_code = 'HN';
}

$tiendaScope = $rol === 'tienda' ? $codalmacen : $tienda;

/* =========================================================
   PASO 14) PERIODO
   ========================================================= */
$periodo = strtolower(trim((string)($_GET['periodo'] ?? 'semana')));

if (!in_array($periodo, ['hoy', 'semana', 'mes'], true)) {
    $periodo = 'semana';
}

/* =========================================================
   PASO 15) VALIDAR TABLAS DISPONIBLES
   ========================================================= */
$usuariosTable      = table_exists($conn, 'usuarios');
$auditoriaTable     = table_exists($conn, 'auditoria') ? 'auditoria' : (table_exists($conn, 'auditoria_logs') ? 'auditoria_logs' : '');
$usuarioTiendaTable = table_exists($conn, 'usuario_tienda');

/* =========================================================
   PASO 16) MAPA DE TIENDAS CORREGIDO
   ---------------------------------------------------------
   Antes:
   $storeMap[$codalmacen] = nombrealmacen

   Ahora:
   $storeMap[REGION-ZONA-CODALMACEN] = nombrealmacen
   ========================================================= */
$storeMap = [];

if (
    $usuarioTiendaTable &&
    column_exists($conn, 'usuario_tienda', 'codalmacen') &&
    column_exists($conn, 'usuario_tienda', 'nombrealmacen')
) {
    $rowsTiendas = fetch_rows(
        $conn,
        "SELECT DISTINCT
            COALESCE(NULLIF(pais, ''), 'HN') AS pais,
            COALESCE(NULLIF(zona, ''), '') AS zona,
            codalmacen,
            nombrealmacen
         FROM usuario_tienda
         WHERE COALESCE(TRIM(codalmacen), '') <> ''"
    );

    foreach ($rowsTiendas as $r) {
        $pais = strtoupper(trim((string)($r['pais'] ?? 'HN')));
        $region = region_label_from_pais_code($pais);
        $zonaTienda = strtoupper(trim((string)($r['zona'] ?? '')));
        $cod = strtoupper(trim((string)($r['codalmacen'] ?? '')));
        $nom = trim((string)($r['nombrealmacen'] ?? ''));

        if ($cod === '') {
            continue;
        }

        $key = dashboard_store_key($region, '', $cod);

        $storeMap[$key] = $nom !== '' ? $nom : $cod;
    }
}

/* =========================================================
   PASO 17) MÉTRICAS DE USUARIOS
   ========================================================= */
$totalUsuarios       = 0;
$totalActivos        = 0;
$totalBloqueados     = 0;
$totalAdminsZona     = 0;
$totalUsuariosTienda = 0;
$totalCreados        = 0;
$totalSuperAdmin     = 0;

$roleChartLabels = [];
$roleChartData   = [];

if ($usuariosTable) {
    [$userWhere, $userParams, $userTypes] = build_user_scope(
        $conn,
        $miId,
        $rol,
        $pais_code,
        $zona,
        $tiendaScope
    );

    $totalUsuarios = fetch_one_int(
        $conn,
        "SELECT COUNT(*) FROM usuarios u WHERE {$userWhere}",
        $userParams,
        $userTypes
    );

    if (column_exists($conn, 'usuarios', 'estado')) {
        $totalActivos = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND CAST(COALESCE(u.estado, 0) AS UNSIGNED) = 1",
            $userParams,
            $userTypes
        );

        $totalBloqueados = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND CAST(COALESCE(u.estado, 0) AS UNSIGNED) = 0",
            $userParams,
            $userTypes
        );
    } elseif (column_exists($conn, 'usuarios', 'bloqueado')) {
        $totalBloqueados = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND u.bloqueado = 1",
            $userParams,
            $userTypes
        );

        $totalActivos = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND (u.bloqueado = 0 OR u.bloqueado IS NULL)",
            $userParams,
            $userTypes
        );
    } else {
        $totalActivos = $totalUsuarios;
        $totalBloqueados = 0;
    }

    if (column_exists($conn, 'usuarios', 'rol')) {
        if ($rol === 'super_admin') {
            $totalSuperAdmin = fetch_one_int(
                $conn,
                "SELECT COUNT(*)
                 FROM usuarios u
                 WHERE {$userWhere}
                   AND UPPER(TRIM(u.rol)) = UPPER(TRIM(?))",
                array_merge($userParams, ['super_admin']),
                $userTypes . 's'
            );
        }

        $totalAdminsZona = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND UPPER(TRIM(u.rol)) = 'ADMIN_ZONA'",
            $userParams,
            $userTypes
        );

        $totalUsuariosTienda = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND UPPER(TRIM(u.rol)) = 'TIENDA'",
            $userParams,
            $userTypes
        );
    }

    $fechaUsuarioCol = pick_first_existing_column($conn, 'usuarios', ['created_at', 'fecha_creacion', 'fecha_registro', 'fecha']);

if ($fechaUsuarioCol !== '') {
    // 1. Llamamos a la función para obtener la condición SQL del período (ej. 'mes')
    [$periodWhere] = build_period_scope($periodo, "u.{$fechaUsuarioCol}");

    $totalCreados = fetch_one_int(
        $conn,
        "SELECT COUNT(*)
         FROM usuarios u
         WHERE {$userWhere}
           AND u.{$fechaUsuarioCol} IS NOT NULL
           AND {$periodWhere}", // 2. Agregamos la condición aquí
        $userParams,
        $userTypes
    );
} else {
    $totalCreados = $totalUsuarios;
}


    if ($rol === 'super_admin') {
        $roleChartLabels = ['Super admin', 'Admins zona', 'Usuarios tienda'];
        $roleChartData   = [
            (int)$totalSuperAdmin,
            (int)$totalAdminsZona,
            (int)$totalUsuariosTienda,
        ];
    } elseif ($rol === 'admin_zona') {
        $roleChartLabels = ['Admins zona', 'Usuarios tienda'];
        $roleChartData   = [
            (int)$totalAdminsZona,
            (int)$totalUsuariosTienda,
        ];
    }
}

/* =========================================================
   PASO 18) MÉTRICAS DE AUDITORÍA
   ========================================================= */
$movimientosExhibicion = 0;
$creadosPeriodo        = 0;
$editadosPeriodo       = 0;
$masivosPeriodo        = 0;
$ultimaFechaMovimiento = '-';
$usuarioTop            = '-';
$tiendaTop             = '-';
$actividadExhibicion   = [];
$barLabels             = [];
$barValues             = [];
$topUsuariosLabels     = [];
$topUsuariosData       = [];
$tiendasConMovimiento  = 0;
$usuariosConMovimiento = 0;

if ($auditoriaTable !== '') {
    $auditFechaCol   = pick_first_existing_column($conn, $auditoriaTable, ['fecha', 'created_at', 'fecha_registro']);
    $auditUsuarioCol = pick_first_existing_column($conn, $auditoriaTable, ['usuario', 'usuario_nombre']);
    $auditAccionCol  = pick_first_existing_column($conn, $auditoriaTable, ['accion', 'actividad']);
    $auditDetalleCol = pick_first_existing_column($conn, $auditoriaTable, ['detalle', 'descripcion']);
    $auditZonaCol    = pick_first_existing_column($conn, $auditoriaTable, ['zona']);
    $auditTiendaCol  = pick_first_existing_column($conn, $auditoriaTable, ['codalmacen', 'tienda']);
    $auditRegionCol  = pick_first_existing_column($conn, $auditoriaTable, ['region']);

    if ($auditFechaCol !== '' && $auditUsuarioCol !== '' && $auditAccionCol !== '') {
        [$auditBaseWhere, $auditBaseParams, $auditBaseTypes] = build_audit_scope(
            $conn,
            $miId,
            $rol,
            $pais_code,
            $zona,
            $tiendaScope,
            $auditAccionCol,
            $auditZonaCol,
            $auditTiendaCol,
            $auditDetalleCol,
            $auditRegionCol
        );

        [$periodWhere, $periodParams, $periodTypes] = build_period_scope($periodo, $auditFechaCol);

        $auditWhere  = "({$auditBaseWhere}) AND ({$periodWhere})";
        $auditParams = array_merge($auditBaseParams, $periodParams);
        $auditTypes  = $auditBaseTypes . $periodTypes;

        $movimientosExhibicion = fetch_one_int(
            $conn,
            "SELECT COUNT(*) FROM {$auditoriaTable} WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $creadosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND (
                    UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
                    OR UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
               )",
            array_merge($auditParams, ['CREAR_EXHIBICION', 'CREAR_EXHIBICION_MASIVO']),
            $auditTypes . 'ss'
        );

        $editadosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND (
                    UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
                    OR UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
               )",
            array_merge($auditParams, ['EDITAR_EXHIBICION', 'EDITAR_EXHIBICION_MASIVO']),
            $auditTypes . 'ss'
        );

        /*
        |--------------------------------------------------------------------------
        | MOVIMIENTOS MASIVOS DEL PERIODO
        |--------------------------------------------------------------------------
        */
        $masivosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND UPPER(TRIM({$auditAccionCol})) LIKE '%MASIVO%'",
            $auditParams,
            $auditTypes
        );

        $ultimaFecha = fetch_scalar(
            $conn,
            "SELECT MAX({$auditFechaCol})
             FROM {$auditoriaTable}
             WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $ultimaFechaMovimiento = $ultimaFecha !== null && $ultimaFecha !== '' ? (string)$ultimaFecha : '-';

        $rowsTopUser = fetch_rows(
            $conn,
            "SELECT {$auditUsuarioCol} AS usuario, COUNT(*) AS total
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             GROUP BY {$auditUsuarioCol}
             ORDER BY total DESC, {$auditUsuarioCol} ASC
             LIMIT 1",
            $auditParams,
            $auditTypes
        );

        if (!empty($rowsTopUser)) {
            $usuarioTop = (string)$rowsTopUser[0]['usuario'] . ' (' . (int)$rowsTopUser[0]['total'] . ')';
        }

        $usuariosConMovimiento = fetch_one_int(
            $conn,
            "SELECT COUNT(DISTINCT {$auditUsuarioCol})
             FROM {$auditoriaTable}
             WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $actividadExhibicion = fetch_rows(
            $conn,
            "SELECT
                {$auditUsuarioCol} AS usuario,
                {$auditAccionCol} AS accion,
                " . ($auditDetalleCol !== '' ? "{$auditDetalleCol}" : "''") . " AS detalle,
                " . ($auditTiendaCol !== '' ? "{$auditTiendaCol}" : "''") . " AS codalmacen,
                " . ($auditZonaCol !== '' ? "{$auditZonaCol}" : "''") . " AS zona,
                " . ($auditRegionCol !== '' ? "{$auditRegionCol}" : "''") . " AS region,
                {$auditFechaCol} AS fecha_registro
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             ORDER BY {$auditFechaCol} DESC
             LIMIT 20",
            $auditParams,
            $auditTypes
        );

        $storeTotals = [];

        if ($auditTiendaCol !== '') {
            $rowsStores = fetch_rows(
                $conn,
                "SELECT
                    {$auditTiendaCol} AS store_code,
                    " . ($auditZonaCol !== '' ? "{$auditZonaCol}" : "''") . " AS zona,
                    " . ($auditRegionCol !== '' ? "{$auditRegionCol}" : "''") . " AS region,
                    COUNT(*) AS total
                 FROM {$auditoriaTable}
                 WHERE {$auditWhere}
                   AND COALESCE(TRIM({$auditTiendaCol}), '') <> ''
                 GROUP BY
                    {$auditTiendaCol}
                    " . ($auditZonaCol !== '' ? ", {$auditZonaCol}" : "") . "
                    " . ($auditRegionCol !== '' ? ", {$auditRegionCol}" : "") . "
                 ORDER BY total DESC
                 LIMIT 15",
                $auditParams,
                $auditTypes
            );

            foreach ($rowsStores as $r) {
                $code = strtoupper(trim((string)($r['store_code'] ?? '')));
                $zonaStore = strtoupper(trim((string)($r['zona'] ?? '')));
                $regionStore = normalizar_region_dashboard((string)($r['region'] ?? ''));

                if ($code === '') {
                    continue;
                }

                if ($regionStore === '') {
                    $regionStore = region_label_from_pais_code($pais_code);
                }

                $key = dashboard_store_key($regionStore, $zonaStore, $code);
                $name = $storeMap[$key] ?? ($code . ' - ' . $regionStore);

                $storeTotals[$name] = ($storeTotals[$name] ?? 0) + (int)($r['total'] ?? 0);
            }
        } else {
            foreach ($actividadExhibicion as $r) {
                $detalle = (string)($r['detalle'] ?? '');

                $code = extract_store_code_from_detail($detalle);
                $zonaDetalle = extract_zone_from_detail($detalle);
                $regionDetalle = extract_region_from_detail($detalle);

                if ($regionDetalle === '') {
                    $regionDetalle = region_label_from_pais_code($pais_code);
                }

                $key = dashboard_store_key($regionDetalle, $zonaDetalle, $code);
                $name = $storeMap[$key] ?? ($code !== '' ? $code : 'Sin tienda');

                $storeTotals[$name] = ($storeTotals[$name] ?? 0) + 1;
            }
        }

        if (!empty($storeTotals)) {
            arsort($storeTotals);
            $topStores = array_slice($storeTotals, 0, 20, true);
            $barLabels = array_keys($topStores);
            $barValues = array_values($topStores);
            $tiendasConMovimiento = count($topStores);

            $storeNameTop = array_key_first($topStores);

            if ($storeNameTop !== null) {
                $tiendaTop = $storeNameTop . ' (' . (int)$topStores[$storeNameTop] . ')';
            }
        }

        $rowsTopUsers = fetch_rows(
            $conn,
            "SELECT {$auditUsuarioCol} AS usuario, COUNT(*) AS total
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             GROUP BY {$auditUsuarioCol}
             ORDER BY total DESC, {$auditUsuarioCol} ASC
             LIMIT 9",
            $auditParams,
            $auditTypes
        );

        foreach ($rowsTopUsers as $r) {
            $topUsuariosLabels[] = (string)($r['usuario'] ?? '');
            $topUsuariosData[]   = (int)($r['total'] ?? 0);
        }

        foreach ($actividadExhibicion as &$mov) {
            $detalle = (string)($mov['detalle'] ?? '');

            $codAlmacen = trim((string)($mov['codalmacen'] ?? ''));
            $zonaMov = trim((string)($mov['zona'] ?? ''));
            $regionMov = trim((string)($mov['region'] ?? ''));

            if ($codAlmacen === '') {
                $codAlmacen = extract_store_code_from_detail($detalle);
            }

            if ($zonaMov === '') {
                $zonaMov = extract_zone_from_detail($detalle);
            }

            if ($regionMov === '') {
                $regionMov = extract_region_from_detail($detalle);
            }

            if ($regionMov === '') {
                $regionMov = region_label_from_pais_code($pais_code);
            }

            $codAlmacen = strtoupper(trim($codAlmacen));
            $zonaMov = strtoupper(trim($zonaMov));
            $regionMov = normalizar_region_dashboard($regionMov);

            $key = dashboard_store_key($regionMov, '', $codAlmacen);

            $mov['codalmacen'] = $codAlmacen;
            $mov['zona'] = $zonaMov;
            $mov['region'] = $regionMov;
            $mov['llave_tienda'] = $key;
            $mov['tienda_nombre'] = $codAlmacen !== '' ? ($storeMap[$key] ?? $codAlmacen) : '-';
            $mov['codarticulo_extraido'] = extract_codarticulo_from_detail($detalle);
            $mov['detalle_lines'] = split_detail_lines($detalle);
            $mov['detalle_title'] = extract_detail_title($detalle);
        }

        unset($mov);
    }
}

/* =========================================================
   PASO 19) DATOS DE GRÁFICAS
   ========================================================= */
$userChartLabels = ['Usuarios creados', 'Usuarios bloqueados'];
$userChartData   = [max($totalCreados - $totalBloqueados, 0), $totalBloqueados];

$periodoLabel = match ($periodo) {
    'hoy'    => 'Hoy',
    'semana' => 'Esta semana',
    'mes'    => 'Este mes',
    default  => 'Todo el tiempo' // Cambiado para reflejar el "1=1" de tu función build_period_scope
};

$resumenSuperior = [
    'Total movimientos: ' . number_format($movimientosExhibicion),
    'Masivos: ' . number_format($masivosPeriodo),
    'Última fecha: ' . h($ultimaFechaMovimiento),
    'Usuario más activo: ' . h($usuarioTop),
    'Tienda más activa: ' . h($tiendaTop),
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root{
            --bg:#f4f7fb;
            --panel:#ffffff;
            --line:#e5e7eb;
            --text:#0f172a;
            --muted:#64748b;
            --shadow:0 10px 28px rgba(15,23,42,.06);
            --radius:22px;
        }

        *{ box-sizing:border-box; }

        body{
            margin:0;
            font-family:"Segoe UI", Arial, sans-serif;
            color:var(--text);
            background:linear-gradient(180deg,#f8fbff 0%,#f3f6fb 100%);
        }

        .dash-wrap{ padding:22px; }

        .toolbar{
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:14px;
            flex-wrap:wrap;
            margin-bottom:18px;
        }

        .period-filter{
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }

        .period-btn{
            border:none;
            padding:10px 14px;
            border-radius:999px;
            background:#fff;
            color:var(--text);
            border:1px solid var(--line);
            text-decoration:none;
            font-size:14px;
            font-weight:700;
            box-shadow:none;
        }

        .period-btn:hover{
            color:#111827;
            border-color:#9ca3af;
        }

        .period-btn.active{
            background:#1f2937;
            color:#fff;
            border-color:#1f2937;
        }

        .period-label{
            color:var(--muted);
            font-size:13px;
            font-weight:700;
        }

        .summary-strip{
            display:flex;
            gap:10px;
            flex-wrap:wrap;
            margin-bottom:18px;
        }

        .summary-pill{
            background:var(--panel);
            border:1px solid #e5e7eb;
            border-radius:999px;
            padding:10px 14px;
            font-size:14px;
            box-shadow:0 6px 18px rgba(15,23,42,.04);
        }

        .grid-top,
        .grid-middle,
        .grid-bottom{
            display:grid;
            grid-template-columns:.86fr 1.14fr;
            gap:18px;
            margin-bottom:18px;
            align-items:start;
        }

        .grid-top{ grid-template-columns:1fr 1fr; }
        .grid-middle{ grid-template-columns:1fr 1fr; }
        .grid-bottom{ grid-template-columns:.86fr 1.14fr; }

        .panel,
        .table-panel{
            background:var(--panel);
            border:1px solid #e5e7eb;
            border-radius:var(--radius);
            box-shadow:0 8px 20px rgba(15,23,42,.05);
            padding:20px;
        }

        .panel-title{
            margin:0 0 4px;
            font-size:18px;
            font-weight:800;
        }

        .panel-sub{
            margin:0 0 16px;
            color:var(--muted);
            font-size:13px;
        }

        .chart-box{
            height:300px;
        }

        .chart-box.small{ height:300px; }

        .activity-list{
            display:grid;
            gap:12px;
        }

        .activity-card{
            border:1px solid #e5e7eb;
            border-radius:18px;
            background:#fbfdff;
            padding:16px;
        }

        .activity-top{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
            margin-bottom:10px;
        }

        .activity-user{
            display:flex;
            align-items:center;
            gap:10px;
        }

        .activity-avatar{
            width:40px;
            height:40px;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            font-weight:800;
            color:#fff;
            background:linear-gradient(135deg,#6b7280,#374151);
            flex-shrink:0;
        }

        .activity-user h5{
            margin:0;
            font-size:15px;
            font-weight:800;
            color:#0f172a;
        }

        .activity-user small{
            color:#64748b;
            font-size:12px;
        }

        .badge-soft{
            display:inline-block;
            padding:7px 12px;
            border-radius:999px;
            font-size:12px;
            font-weight:800;
            letter-spacing:.2px;
        }

        .badge-create{
            background:#dcfce7;
            color:#166534;
        }

        .badge-edit{
            background:#e5e7eb;
            color:#374151;
        }

        .badge-masivo{
            background:#ede9fe;
            color:#5b21b6;
        }

        .activity-meta{
            display:grid;
            grid-template-columns:repeat(5, minmax(110px, 1fr));
            gap:10px;
            margin-bottom:12px;
        }

        .activity-meta-box{
            background:#ffffff;
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:10px 12px;
        }

        .activity-meta-box .label{
            display:block;
            font-size:11px;
            font-weight:800;
            color:#64748b;
            text-transform:uppercase;
            margin-bottom:4px;
        }

        .activity-meta-box .value{
            display:block;
            font-size:14px;
            font-weight:700;
            color:#0f172a;
            word-break:break-word;
        }

        .detail-clean{
            background:#fff;
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:12px;
        }

        .detail-title{
            font-size:11px;
            font-weight:800;
            color:#64748b;
            text-transform:uppercase;
            margin-bottom:8px;
            letter-spacing:.3px;
        }

        .detail-mini-action{
            font-size:13px;
            font-weight:800;
            color:#0f172a;
            margin-bottom:10px;
        }

        .detail-pills{
            display:flex;
            flex-wrap:wrap;
            gap:8px;
        }

        .detail-pill{
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding:7px 10px;
            border-radius:999px;
            background:#f8fafc;
            border:1px solid #e5e7eb;
            font-size:12px;
            color:#334155;
            line-height:1.2;
            word-break:break-word;
        }

        .detail-pill strong{
            color:#0f172a;
            font-weight:800;
        }

        .empty-box{
            padding:24px;
            border:1px dashed #cbd5e1;
            border-radius:16px;
            background:#f8fafc;
            color:#64748b;
            text-align:center;
        }

        button:focus,
        a:focus,
        .btn:focus,
        .period-btn:focus,
        canvas:focus{
            outline:none !important;
            box-shadow:none !important;
        }

        .panel-resumen-graficos{
            min-height:auto;
        }

        .mini-charts-grid{
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:16px;
            margin-top:8px;
        }

        .mini-chart-card{
            background:#f8fbff;
            border:1px solid #e5e7eb;
            border-radius:18px;
            padding:14px;
            text-align:center;
        }

        .mini-chart-title{
            font-size:13px;
            font-weight:800;
            color:#334155;
            margin-bottom:10px;
        }

        .mini-chart-wrap{
            position:relative;
            height:180px;
        }

        .mini-chart-wrap canvas{
            width:100% !important;
            height:100% !important;
        }

        .mini-chart-number{
            margin-top:8px;
            font-size:24px;
            font-weight:800;
            color:#0f172a;
        }

        @media (max-width: 1180px){
            .grid-top,
            .grid-middle,
            .grid-bottom{
                grid-template-columns:1fr;
            }

            .activity-meta{
                grid-template-columns:repeat(2, minmax(110px, 1fr));
            }
        }

        @media (max-width: 1100px){
            .mini-charts-grid{
                grid-template-columns:1fr;
            }
        }

        @media (max-width: 768px){
            .dash-wrap{ padding:14px; }

            .activity-meta{
                grid-template-columns:1fr;
            }
        }
    </style>
</head>

<body>

<div class="dash-wrap">

    <section class="toolbar">
        <div class="period-filter">
            <a class="period-btn <?= $periodo === 'hoy' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=dashboard&periodo=hoy">Hoy</a>
            <a class="period-btn <?= $periodo === 'semana' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=dashboard&periodo=semana">Semana</a>
            <a class="period-btn <?= $periodo === 'mes' ? 'active' : '' ?>" href="/exhibicion_DT/index.php?vista=dashboard&periodo=mes">Mes</a>
        </div>

        <div class="period-label">Periodo activo: <strong><?= h($periodoLabel) ?></strong></div>
    </section>

    <section class="summary-strip">
        <?php foreach ($resumenSuperior as $item): ?>
            <span class="summary-pill"><?= $item ?></span>
        <?php endforeach; ?>
    </section>

    <section class="grid-top">
        <article class="panel">
            <h3 class="panel-title">Usuarios creados y bloqueados</h3>
            <p class="panel-sub">Resumen general de usuarios según tus permisos.</p>

            <div class="chart-box small">
                <canvas id="chartUsuarios"></canvas>
            </div>
        </article>

        <article class="panel">
            <h3 class="panel-title">Tiendas con más movimientos</h3>
            <p class="panel-sub">Tiendas con mayor actividad de exhibición en el periodo.</p>

            <div class="chart-box">
                <canvas id="chartTiendas"></canvas>
            </div>
        </article>
    </section>

    <section class="grid-middle">
        <article class="panel">
            <h3 class="panel-title">Usuarios con más movimientos</h3>
            <p class="panel-sub">Top usuarios que más editaron o crearon exhibición.</p>

            <div class="chart-box">
                <canvas id="chartTopUsuarios"></canvas>
            </div>
        </article>

        <article class="panel panel-resumen-graficos">
            <h3 class="panel-title">Resumen del periodo</h3>
            <p class="panel-sub">Visual del periodo seleccionado: <?= h($periodoLabel) ?>.</p>

            <div class="mini-charts-grid">
                <div class="mini-chart-card">
                    <div class="mini-chart-title">Movimientos totales</div>
                    <div class="mini-chart-wrap">
                        <canvas id="chartMovimientosPeriodo"></canvas>
                    </div>
                    <div class="mini-chart-number"><?= number_format($movimientosExhibicion) ?></div>
                </div>

                <div class="mini-chart-card">
                    <div class="mini-chart-title">Creados vs Editados</div>
                    <div class="mini-chart-wrap">
                        <canvas id="chartCreadosEditados"></canvas>
                    </div>
                </div>

                <div class="mini-chart-card">
                    <div class="mini-chart-title">Tiendas vs Usuarios</div>
                    <div class="mini-chart-wrap">
                        <canvas id="chartTiendasUsuariosPeriodo"></canvas>
                    </div>
                </div>
            </div>
        </article>
    </section>

    <section class="grid-bottom">
        <article class="panel">
            <h3 class="panel-title">Usuarios por rol</h3>
            <p class="panel-sub">Distribución de usuarios según tus permisos.</p>

            <div class="chart-box small">
                <canvas id="chartRoles"></canvas>
            </div>
        </article>

        <article class="table-panel">
            <h3 class="panel-title">Actividad de Exhibición</h3>
            <p class="panel-sub">Historial de cambios y creaciones.</p>

            <?php if (!empty($actividadExhibicion)): ?>
                <div class="activity-list">
                    <?php foreach ($actividadExhibicion as $row): ?>
                        <?php
                        $accion = (string)($row['accion'] ?? '');
                        $class  = dashboard_badge_class($accion);
                        $usuarioNombre = (string)($row['usuario'] ?? '');
                        $inicial = strtoupper(substr($usuarioNombre, 0, 1) ?: 'U');
                        $detalleLines = is_array($row['detalle_lines'] ?? null) ? $row['detalle_lines'] : [];
                        ?>
                        <div class="activity-card">
                            <div class="activity-top">
                                <div class="activity-user">
                                    <div class="activity-avatar"><?= h($inicial) ?></div>
                                    <div>
                                        <h5><?= h($usuarioNombre) ?></h5>
                                        <small><?= h($row['fecha_registro'] ?? '') ?></small>
                                    </div>
                                </div>

                                <span class="badge-soft <?= $class ?>">
                                    <?= h(dashboard_accion_label($accion)) ?>
                                </span>
                            </div>

                            <div class="activity-meta">
                                <div class="activity-meta-box">
                                    <span class="label">Región</span>
                                    <span class="value"><?= h($row['region'] ?? '-') ?></span>
                                </div>

                               <?php /*
                            <div class="activity-meta-box">
                             <span class="label">Zona</span>
                            <span class="value"><?= h($row['zona'] ?? '-') ?></span>
                                </div>
                                */ ?>

                                <div class="activity-meta-box">
                                    <span class="label">Código tienda</span>
                                    <span class="value"><?= h($row['codalmacen'] ?? '-') ?></span>
                                </div>

                                <div class="activity-meta-box">
                                    <span class="label">Nombre tienda</span>
                                    <span class="value"><?= h($row['tienda_nombre'] ?? '-') ?></span>
                                </div>

                                <div class="activity-meta-box">
                                    <span class="label">Código artículo</span>
                                    <span class="value"><?= h($row['codarticulo_extraido'] ?? '-') ?></span>
                                </div>
                            </div>

                            <div class="detail-clean">
                                <div class="detail-title">Detalle del movimiento</div>

                                <div class="detail-mini-action">
                                    <?= h($row['detalle_title'] ?? 'Movimiento de exhibición') ?>.
                                </div>

                                <?php if (!empty($detalleLines)): ?>
                                    <div class="detail-pills">
                                        <?php foreach ($detalleLines as $line): ?>
                                            <?php
                                            $label = trim((string)($line['label'] ?? ''));
                                            $value = trim((string)($line['value'] ?? ''));

                                            if ($label === '' || $value === '') {
                                                continue;
                                            }
                                            ?>
                                            <span class="detail-pill">
                                                <strong><?= h($label) ?>:</strong>
                                                <?= h($value) ?>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-box">
                    No hay movimientos de exhibición para mostrar en <?= h($periodoLabel) ?>.
                </div>
            <?php endif; ?>
        </article>
    </section>

</div>

<script>
const userChartLabels   = <?= json_encode($userChartLabels, JSON_UNESCAPED_UNICODE) ?>;
const userChartData     = <?= json_encode($userChartData, JSON_UNESCAPED_UNICODE) ?>;
const storeChartLabels  = <?= json_encode($barLabels, JSON_UNESCAPED_UNICODE) ?>;
const storeChartData    = <?= json_encode($barValues, JSON_UNESCAPED_UNICODE) ?>;
const topUsuariosLabels = <?= json_encode($topUsuariosLabels, JSON_UNESCAPED_UNICODE) ?>;
const topUsuariosData   = <?= json_encode($topUsuariosData, JSON_UNESCAPED_UNICODE) ?>;
const roleChartLabels   = <?= json_encode($roleChartLabels, JSON_UNESCAPED_UNICODE) ?>;
const roleChartData     = <?= json_encode($roleChartData, JSON_UNESCAPED_UNICODE) ?>;

const movimientosExhibicionTotal = <?= (int)$movimientosExhibicion ?>;
const creadosPeriodoTotal = <?= (int)$creadosPeriodo ?>;
const editadosPeriodoTotal = <?= (int)$editadosPeriodo ?>;
const masivosPeriodoTotal = <?= (int)$masivosPeriodo ?>;
const tiendasConMovimientoTotal = <?= (int)$tiendasConMovimiento ?>;
const usuariosConMovimientoTotal = <?= (int)$usuariosConMovimiento ?>;

const coloresTiendas = [
    '#2563eb',
    '#0f766e',
    '#7c3aed',
    '#ea580c',
    '#dc2626',
    '#0891b2',
    '#16a34a',
    '#ca8a04'
];

const coloresRoles = [
    '#2563eb',
    '#7c3aed',
    '#14b8a6',
    '#f59e0b'
];

const coloresTopUsuarios = [
    '#1d4ed8',
    '#2563eb',
    '#3b82f6',
    '#60a5fa',
    '#93c5fd'
];

const elChartUsuarios = document.getElementById('chartUsuarios');
if (elChartUsuarios) {
    new Chart(elChartUsuarios, {
        type: 'doughnut',
        data: {
            labels: userChartLabels,
            datasets: [{
                data: userChartData,
                backgroundColor: ['#2563eb', '#f59e0b'],
                borderColor: '#ffffff',
                borderWidth: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            cutout: '68%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        padding: 16,
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    }
                }
            }
        }
    });
}

const elChartMovimientosPeriodo = document.getElementById('chartMovimientosPeriodo');
if (elChartMovimientosPeriodo) {
    new Chart(elChartMovimientosPeriodo, {
        type: 'doughnut',
        data: {
            labels: ['Movimientos'],
            datasets: [{
                data: [movimientosExhibicionTotal || 1],
                backgroundColor: ['#2563eb'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '72%',
            animation: false,
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false }
            }
        }
    });
}

const elChartCreadosEditados = document.getElementById('chartCreadosEditados');
if (elChartCreadosEditados) {
    new Chart(elChartCreadosEditados, {
        type: 'pie',
        data: {
            labels: ['Creados', 'Editados', 'Masivos'],
            datasets: [{
                data: [
                    creadosPeriodoTotal || 0,
                    editadosPeriodoTotal || 0,
                    masivosPeriodoTotal || 0
                ],
                backgroundColor: ['#22c55e', '#f59e0b', '#8b5cf6'],
                borderColor: '#ffffff',
                borderWidth: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        padding: 12,
                        font: {
                            size: 11,
                            weight: '600'
                        }
                    }
                }
            }
        }
    });
}

const elChartTiendasUsuariosPeriodo = document.getElementById('chartTiendasUsuariosPeriodo');
if (elChartTiendasUsuariosPeriodo) {
    new Chart(elChartTiendasUsuariosPeriodo, {
        type: 'bar',
        data: {
            labels: ['Tiendas', 'Usuarios'],
            datasets: [{
                data: [
                    tiendasConMovimientoTotal || 0,
                    usuariosConMovimientoTotal || 0
                ],
                backgroundColor: ['#7c3aed', '#0ea5e9'],
                borderRadius: 10,
                borderSkipped: false,
                maxBarThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#334155',
                        font: {
                            size: 12,
                            weight: '700'
                        }
                    },
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        color: '#64748b'
                    },
                    grid: {
                        color: 'rgba(148,163,184,.14)'
                    }
                }
            }
        }
    });
}

const elChartTiendas = document.getElementById('chartTiendas');
if (elChartTiendas) {
    new Chart(elChartTiendas, {
        type: 'bar',
        data: {
            labels: storeChartLabels,
            datasets: [{
                label: 'Movimientos',
                data: storeChartData,
                backgroundColor: storeChartData.map((_, i) => coloresTiendas[i % coloresTiendas.length]),
                borderRadius: 12,
                borderSkipped: false,
                maxBarThickness: 48
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#475569',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    },
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        color: '#64748b'
                    },
                    grid: {
                        color: 'rgba(148,163,184,.14)'
                    }
                }
            }
        }
    });
}

const elChartTopUsuarios = document.getElementById('chartTopUsuarios');
if (elChartTopUsuarios) {
    new Chart(elChartTopUsuarios, {
        type: 'bar',
        data: {
            labels: topUsuariosLabels,
            datasets: [{
                data: topUsuariosData,
                backgroundColor: topUsuariosData.map((_, i) => coloresTopUsuarios[i % coloresTopUsuarios.length]),
                borderRadius: 12,
                borderSkipped: false
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        color: '#64748b',
                        precision: 0
                    },
                    grid: {
                        color: 'rgba(148,163,184,.14)'
                    }
                },
                y: {
                    ticks: {
                        color: '#0f172a',
                        font: {
                            weight: '600'
                        }
                    },
                    grid: { display: false }
                }
            }
        }
    });
}

const elChartRoles = document.getElementById('chartRoles');
if (elChartRoles) {
    new Chart(elChartRoles, {
        type: 'bar',
        data: {
            labels: roleChartLabels,
            datasets: [{
                data: roleChartData,
                backgroundColor: roleChartData.map((_, i) => coloresRoles[i % coloresRoles.length]),
                borderRadius: 10,
                borderSkipped: false,
                maxBarThickness: 28
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        color: '#64748b'
                    },
                    grid: {
                        color: 'rgba(148,163,184,.14)'
                    }
                },
                y: {
                    ticks: {
                        color: '#0f172a',
                        font: {
                            size: 12,
                            weight: '700'
                        }
                    },
                    grid: { display: false }
                }
            }
        }
    });
}
</script>

</body>
</html>