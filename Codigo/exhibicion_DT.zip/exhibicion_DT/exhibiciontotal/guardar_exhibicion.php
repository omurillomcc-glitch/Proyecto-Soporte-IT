<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| 1) INICIAR SESIÓN
|--------------------------------------------------------------------------
| Esta aplicación usa su propia sesión para no mezclarse con otras apps.
|--------------------------------------------------------------------------
*/
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| 2) ARCHIVOS REQUERIDOS
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/conexion_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

/*
|--------------------------------------------------------------------------
| 3) REDIRIGIR AL INDEX CONSERVANDO FILTROS Y MENSAJES
|--------------------------------------------------------------------------
| Si el formulario venía desde exhibición con filtros activos,
| los conservamos al volver.
|--------------------------------------------------------------------------
*/
function redirect_back(string $message = '', bool $ok = false): never
{
    $returnQs = trim((string)($_POST['return_qs'] ?? ''));
    $params = [];

    if ($returnQs !== '') {
        parse_str($returnQs, $params);
    }

    unset($params['ok'], $params['err']);

    if ($ok) {
        $params['ok'] = '1';
    } else {
        $params['err'] = $message;
    }

    $qs = http_build_query($params);
    header('Location: ../index.php' . ($qs !== '' ? '?' . $qs : '') . '#tablaExhibicion');
    exit;
}

/*
|--------------------------------------------------------------------------
| 4) NORMALIZAR PAÍS
|--------------------------------------------------------------------------
| Convierte:
| - HN / HONDURAS -> HN
| - NI / NICARAGUA -> NI
|--------------------------------------------------------------------------
*/
function normalizar_pais_exhibicion(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/*
|--------------------------------------------------------------------------
| 5) OBTENER REGIÓN DESDE LA SESIÓN
|--------------------------------------------------------------------------
| Se usa para guardar/consultar en DT-ESTANDARESEXHIBICION.
|--------------------------------------------------------------------------
*/
function region_desde_sesion(): string
{
    $paisCode = normalizar_pais_exhibicion((string)($_SESSION['pais_code'] ?? ''));
    return $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';
}

/*
|--------------------------------------------------------------------------
| 6) ELEGIR BASE DE DATOS ORIGEN SEGÚN REGIÓN
|--------------------------------------------------------------------------
| HONDURAS  -> DETODO
| NICARAGUA -> ACANICARAGUA2
|--------------------------------------------------------------------------
*/
function db_origen_desde_region(string $region): string
{
    return strtoupper(trim($region)) === 'NICARAGUA' ? 'ACANICARAGUA2' : 'DETODO';
}

/*
|--------------------------------------------------------------------------
| 7) LIMPIAR CODALMACEN A SOLO 2 DÍGITOS
|--------------------------------------------------------------------------
| Ejemplo:
| - 04M -> 04
| - M04 -> 04
|--------------------------------------------------------------------------
*/
function clean_codalmacen_2d(string $value): string
{
    return preg_replace('/\D/', '', trim($value));
}

/*
|--------------------------------------------------------------------------
| 8) VALIDAR CODALMACEN DE EXACTAMENTE 2 DÍGITOS
|--------------------------------------------------------------------------
*/
function is_codalmacen_2d(string $value): bool
{
    return preg_match('/^\d{2}$/', $value) === 1;
}

/*
|--------------------------------------------------------------------------
| 9) OBTENER ALMACENES PERMITIDOS DEL USUARIO
|--------------------------------------------------------------------------
| Consulta usuario_tienda en MySQL y devuelve un arreglo tipo:
| [
|   '01' => true,
|   '02' => true
| ]
|--------------------------------------------------------------------------
*/
function get_user_allowed_stores(mysqli $conn, int $usuarioId, string $paisCode): array
{
    if ($usuarioId <= 0) {
        return [];
    }

    $sql = "
        SELECT DISTINCT codalmacen, pais
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND COALESCE(TRIM(codalmacen), '') <> ''
        ORDER BY codalmacen
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $res = $stmt->get_result();

    $stores = [];
    while ($row = $res->fetch_assoc()) {
        $cod  = clean_codalmacen_2d((string)($row['codalmacen'] ?? ''));
        $pais = normalizar_pais_exhibicion((string)($row['pais'] ?? ''));

        if ($cod === '') {
            continue;
        }

        if ($pais !== '' && $paisCode !== '' && $pais !== $paisCode) {
            continue;
        }

        if (!is_codalmacen_2d($cod)) {
            continue;
        }

        $stores[$cod] = true;
    }

    $stmt->close();
    return $stores;
}

/*
|--------------------------------------------------------------------------
| 10) OBTENER ZONA PARA AUDITORÍA
|--------------------------------------------------------------------------
*/
function obtener_zona_auditoria(array $me): string
{
    return trim((string)($me['zona'] ?? $_SESSION['zona'] ?? ''));
}

/*
|--------------------------------------------------------------------------
| 11) OBTENER NOMBRE DE TIENDA PARA AUDITORÍA CORREGIDO
|--------------------------------------------------------------------------
| Busca el nombre en usuario_tienda filtrando estrictamente por código y país
| para evitar mezclas entre Honduras y Nicaragua.
|--------------------------------------------------------------------------
*/
function obtener_nombre_tienda(mysqli $conn, string $codalmacen, array $me = []): string
{
    $codalmacen = clean_codalmacen_2d($codalmacen);

    // Identificar el país actual del usuario en sesión
    $paisUsuario = normalizar_pais_exhibicion((string)($_SESSION['pais_code'] ?? $me['pais_code'] ?? ''));

    if ($codalmacen === '') {
        return trim((string)($me['tienda'] ?? $_SESSION['tienda'] ?? ''));
    }

    // SOLUCIÓN: Agregamos el filtro AND pais = ? para que no mezcle HN con NI
    $sql = "
        SELECT nombrealmacen
        FROM usuario_tienda
        WHERE TRIM(codalmacen) = ?
          AND TRIM(pais) = ?
        ORDER BY nombrealmacen ASC
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return trim((string)($me['tienda'] ?? $_SESSION['tienda'] ?? $codalmacen));
    }

    // Pasamos el código de la tienda y el país del usuario
    $stmt->bind_param('ss', $codalmacen, $paisUsuario);
    $stmt->execute();
    $res = $stmt->get_result();

    $nombre = '';
    if ($res && ($row = $res->fetch_assoc())) {
        $nombre = trim((string)($row['nombrealmacen'] ?? ''));
    }

    $stmt->close();

    if ($nombre === '') {
        $nombre = trim((string)($me['tienda'] ?? $_SESSION['tienda'] ?? ''));
    }

    if ($nombre === '') {
        $nombre = $codalmacen;
    }

    return $nombre;
}


/*
|--------------------------------------------------------------------------
| 12) BUSCAR AUTOMÁTICAMENTE EL CODARTICULO EN SQL SERVER
|--------------------------------------------------------------------------
| Si no vino CODARTICULO, se busca por:
| - CODBARRAS
| - y PLU, si existe
|--------------------------------------------------------------------------
*/
function buscar_codarticulo_automatico($sqlsrvConn, string $dbOrigen, string $codbarras, string $plu = ''): string
{
    $sql = "
        SELECT TOP 1
            AA.CODARTICULO
        FROM {$dbOrigen}.dbo.ARTICULOSLIN AA
        LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
            ON CL.CODARTICULO = AA.CODARTICULO
        INNER JOIN {$dbOrigen}.dbo.ARTICULOS A
            ON A.CODARTICULO = AA.CODARTICULO
           AND A.DESCATALOGADO = 'F'
        WHERE AA.CODBARRAS = ?
    ";

    $params = [$codbarras];

    if ($plu !== '') {
        $sql .= " AND ISNULL(CL.PLU, '') = ? ";
        $params[] = $plu;
    }

    $stmt = sqlsrv_query($sqlsrvConn, $sql, $params);

    if ($stmt === false) {
        return '';
    }

    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);

    return trim((string)($row['CODARTICULO'] ?? ''));
}

/*
|--------------------------------------------------------------------------
| 13) SOLO PERMITIR POST
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_back('Acceso no permitido.');
}

/*
|--------------------------------------------------------------------------
| 14) VALIDAR LOGIN Y OBTENER USUARIO ACTUAL
|--------------------------------------------------------------------------
*/
require_login();
$me = me();

$miId       = (int)($me['id'] ?? 0);
$miRol      = trim((string)($me['rol'] ?? ''));
$miPaisCode = normalizar_pais_exhibicion((string)($me['pais_code'] ?? ''));
$region     = region_desde_sesion();
$dbOrigen   = db_origen_desde_region($region);

/*
|--------------------------------------------------------------------------
| 15) VALIDAR ROLES PERMITIDOS
|--------------------------------------------------------------------------
*/
if (!in_array($miRol, ['super_admin', 'admin_zona', 'tienda'], true)) {
    redirect_back('No tienes permisos para esta acción.');
}

/*
|--------------------------------------------------------------------------
| 16) RECIBIR Y LIMPIAR DATOS DEL FORMULARIO
|--------------------------------------------------------------------------
*/
$codbarras   = preg_replace('/\D/', '', trim((string)($_POST['codbarras'] ?? '')));
$plu         = strtoupper(preg_replace('/[^A-Z0-9]/i', '', trim((string)($_POST['plu'] ?? ''))));
$codalmacen  = clean_codalmacen_2d((string)($_POST['codalmacen'] ?? ''));
$uxc         = preg_replace('/\D/', '', trim((string)($_POST['uxc'] ?? '0')));
$exhibicion  = preg_replace('/\D/', '', trim((string)($_POST['exhibicion'] ?? '')));
$codarticulo = preg_replace('/\D/', '', trim((string)($_POST['codarticulo'] ?? '')));

/*
|--------------------------------------------------------------------------
| 17) VALIDACIONES BÁSICAS
|--------------------------------------------------------------------------
*/
if ($codbarras === '') {
    redirect_back('CODBARRAS es obligatorio y solo debe contener números.');
}

if ($codalmacen === '') {
    redirect_back('CODALMACEN es obligatorio.');
}

if (!is_codalmacen_2d($codalmacen)) {
    redirect_back('CODALMACEN debe tener exactamente 2 dígitos, por ejemplo: 01, 02, 12.');
}

if ($exhibicion === '') {
    $exhibicion = '0';
}

if ($uxc === '') {
    $uxc = '0';
}

$exhibicion = (int)$exhibicion;
$uxc        = (int)$uxc;

if ($exhibicion < 0) {
    redirect_back('EXHIBICION debe ser un número mayor o igual a 0.');
}

if ($uxc < 0) {
    redirect_back('UXC debe ser un número mayor o igual a 0.');
}

/*
|--------------------------------------------------------------------------
| 18) VALIDAR ALMACENES PERMITIDOS POR ROL
|--------------------------------------------------------------------------
| super_admin: puede guardar en cualquier almacén visible
| admin_zona / tienda: solo en sus almacenes asignados
|--------------------------------------------------------------------------
*/
if ($miRol !== 'super_admin') {
    $allowedStores = get_user_allowed_stores($conn, $miId, $miPaisCode);

    if (empty($allowedStores)) {
        redirect_back('No tienes almacenes asignados.');
    }

    if (!isset($allowedStores[$codalmacen])) {
        redirect_back('No puedes guardar en ese almacén.');
    }
}

/*
|--------------------------------------------------------------------------
| 19) RESOLVER CODARTICULO ANTES DE BUSCAR/ACTUALIZAR
|--------------------------------------------------------------------------
| Si CODARTICULO viene vacío, primero lo buscamos por CODBARRAS y PLU.
| Así nunca se intenta actualizar con un código vacío ni se inserta sin
| comprobar antes si el registro ya existe.
|--------------------------------------------------------------------------
*/
if ($codarticulo === '') {
    $codarticulo = buscar_codarticulo_automatico(
        $sqlsrv_conn_exhibicion,
        $dbOrigen,
        $codbarras,
        $plu
    );

    if ($codarticulo === '') {
        redirect_back('No se encontró el código de artículo para guardar el registro.');
    }
}

/*
|--------------------------------------------------------------------------
| 20) PREPARAR DATOS PARA AUDITORÍA
|--------------------------------------------------------------------------
*/
$zonaAuditoria   = obtener_zona_auditoria($me);
$tiendaAuditoria = obtener_nombre_tienda($conn, $codalmacen, $me);

/*
|--------------------------------------------------------------------------
| 21) TRANSACCIÓN Y BLOQUEO PARA EVITAR DUPLICADOS
|--------------------------------------------------------------------------
| La llave usada es:
| CODARTICULO + CODBARRAS + PLU + CODALMACEN + REGION
|
| UPDLOCK + HOLDLOCK mantiene bloqueada la comprobación hasta terminar la
| transacción. Si ya existe, se actualiza. Solo se inserta si no existe.
|--------------------------------------------------------------------------
*/
if (!sqlsrv_begin_transaction($sqlsrv_conn_exhibicion)) {
    redirect_back('No se pudo iniciar la transacción de guardado.');
}

$accionAuditoria = '';

try {
    $sqlExiste = "
        SELECT TOP 1 1 AS EXISTE
        FROM dbo.[DT-ESTANDARESEXHIBICION] WITH (UPDLOCK, HOLDLOCK)
        WHERE CODARTICULO = ?
          AND CODBARRAS = ?
          AND ISNULL(PLU, '') = ISNULL(?, '')
          AND CODALMACEN = ?
          AND REGION = ?
    ";

    $paramsLlave = [
        $codarticulo,
        $codbarras,
        $plu,
        $codalmacen,
        $region
    ];

    $stmtExiste = sqlsrv_query(
        $sqlsrv_conn_exhibicion,
        $sqlExiste,
        $paramsLlave
    );

    if ($stmtExiste === false) {
        throw new RuntimeException('No se pudo comprobar si el registro ya existe.');
    }

    $filaExistente = sqlsrv_fetch_array($stmtExiste, SQLSRV_FETCH_ASSOC);

    if ($filaExistente === false) {
        sqlsrv_free_stmt($stmtExiste);
        throw new RuntimeException('No se pudo leer la comprobación del registro.');
    }

    $registroExiste = is_array($filaExistente);
    sqlsrv_free_stmt($stmtExiste);

    if ($registroExiste) {
        /*
        |------------------------------------------------------------------
        | YA EXISTE: ACTUALIZAR ÚNICAMENTE EXHIBICIÓN
        |------------------------------------------------------------------
        */
        $sqlUpdate = "
            UPDATE dbo.[DT-ESTANDARESEXHIBICION]
            SET EXHIBICION = ?
            WHERE CODARTICULO = ?
              AND CODBARRAS = ?
              AND ISNULL(PLU, '') = ISNULL(?, '')
              AND CODALMACEN = ?
              AND REGION = ?
        ";

        $paramsUpdate = [
            $exhibicion,
            $codarticulo,
            $codbarras,
            $plu,
            $codalmacen,
            $region
        ];

        $stmtUpdate = sqlsrv_query(
            $sqlsrv_conn_exhibicion,
            $sqlUpdate,
            $paramsUpdate
        );

        if ($stmtUpdate === false) {
            throw new RuntimeException('No se pudo actualizar EXHIBICION.');
        }

        sqlsrv_free_stmt($stmtUpdate);
        $accionAuditoria = 'EDITAR_EXHIBICION';
    } else {
        /*
        |------------------------------------------------------------------
        | NO EXISTE: INSERTAR UNA SOLA VEZ
        |------------------------------------------------------------------
        */
        $sqlInsert = "
            INSERT INTO dbo.[DT-ESTANDARESEXHIBICION]
            (
                CODARTICULO,
                CODBARRAS,
                PLU,
                EXHIBICION,
                CODALMACEN,
                REGION,
                UXC
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ";

        $paramsInsert = [
            $codarticulo,
            $codbarras,
            $plu,
            $exhibicion,
            $codalmacen,
            $region,
            $uxc
        ];

        $stmtInsert = sqlsrv_query(
            $sqlsrv_conn_exhibicion,
            $sqlInsert,
            $paramsInsert
        );

        if ($stmtInsert === false) {
            throw new RuntimeException('No se pudo insertar el registro.');
        }

        sqlsrv_free_stmt($stmtInsert);
        $accionAuditoria = 'CREAR_EXHIBICION';
    }

    if (!sqlsrv_commit($sqlsrv_conn_exhibicion)) {
        throw new RuntimeException('No se pudo confirmar el guardado.');
    }
} catch (Throwable $e) {
    @sqlsrv_rollback($sqlsrv_conn_exhibicion);
    redirect_back($e->getMessage());
}

/*
|--------------------------------------------------------------------------
| 22) AUDITORÍA DESPUÉS DE CONFIRMAR EL GUARDADO
|--------------------------------------------------------------------------
*/
$descripcionAuditoria = $accionAuditoria === 'CREAR_EXHIBICION'
    ? 'Se creó exhibición.'
    : 'Se actualizó exhibición.';

registrar_auditoria(
    'EXHIBICION',
    $accionAuditoria,
    $descripcionAuditoria .
    ' | REGION: ' . $region .
    ' | TIENDA: ' . $tiendaAuditoria .
    ' | CODARTICULO: ' . $codarticulo .
    ' | CODBARRAS: ' . $codbarras .
    ' | CODALMACEN: ' . $codalmacen .
    ' | PLU: ' . $plu .
    ' | EXHIBICION: ' . $exhibicion .
    ' | UXC: ' . $uxc,
    $region,
    '',                 // Zona vacía
    $tiendaAuditoria,
    $codalmacen
);
/*
|--------------------------------------------------------------------------
| 23) REDIRIGIR CON ÉXITO
|--------------------------------------------------------------------------
*/
redirect_back('', true);