<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: guardar_exhibicion_sin_stock_masivo.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Guardar masivamente exhibición SIN STOCK.
| - Si el registro YA EXISTE: actualizar EXHIBICION y UXC.
| - Si el registro NO EXISTE: insertar un nuevo registro.
| - Guardar auditoría correctamente.
| - Mostrar nombre de tienda.
| - NO mostrar zona.
| - NO confundir con masivo normal.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: CONFIGURACIÓN PHP
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| PASO 2: INICIAR SESIÓN
|--------------------------------------------------------------------------
| Esta aplicación usa su propia sesión para no mezclarse con otras apps.
|--------------------------------------------------------------------------
*/
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR ARCHIVOS
|--------------------------------------------------------------------------
*/
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/conexion_sqlsrv.php';

/*
|--------------------------------------------------------------------------
| PASO 4: VALIDAR LOGIN
|--------------------------------------------------------------------------
*/
require_login();
$me = me();

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIONES AUXILIARES
|--------------------------------------------------------------------------
*/
function limpiar_texto_sinstock(mixed $v): string
{
    return trim((string)$v);
}

function limpiar_numero_sinstock(mixed $v): int
{
    $v = preg_replace('/\D/', '', (string)$v);
    return $v === '' ? 0 : (int)$v;
}

function normalizar_region_sinstock(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS'   => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default           => $region,
    };
}

function obtener_ip_sinstock(): string
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['REMOTE_ADDR']
        ?? '';

    if (str_contains($ip, ',')) {
        $partes = explode(',', $ip);
        $ip = trim($partes[0]);
    }

    if ($ip === '::1') {
        $ip = 'LOCALHOST';
    }

    return trim($ip);
}

/*
|--------------------------------------------------------------------------
| PASO 6: REDIRECCIONAR
|--------------------------------------------------------------------------
*/
function volver_sinstock(
    string $returnQs,
    string $tipo,
    string $mensaje
): void {

    $returnQs = trim($returnQs);

    if ($returnQs === '') {
        $returnQs = 'vista=modulo3';
    }

    parse_str($returnQs, $params);

    unset($params['ok'], $params['err']);

    if (!isset($params['vista'])) {
        $params['vista'] = 'modulo3';
    }

    if ($tipo === 'ok') {
        $params['ok'] = '1';
    } else {
        $params['err'] = $mensaje;
    }

    header(
        'Location: /exhibicion_DT/index.php?' .
        http_build_query($params) .
        '#tablaExhibicion'
    );

    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 7: VALIDAR MÉTODO POST
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    volver_sinstock(
        'vista=modulo3',
        'err',
        'Método inválido.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 8: RECIBIR DATOS
|--------------------------------------------------------------------------
*/
$returnQs = limpiar_texto_sinstock(
    $_POST['return_qs'] ?? 'vista=modulo3'
);

$items = $_POST['items'] ?? [];

if (!is_array($items) || empty($items)) {
    volver_sinstock(
        $returnQs,
        'err',
        'No se recibieron registros.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 9: VALIDAR CONEXIONES
|--------------------------------------------------------------------------
*/
if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
    volver_sinstock(
        $returnQs,
        'err',
        'No hay conexión SQL Server.'
    );
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    volver_sinstock(
        $returnQs,
        'err',
        'No hay conexión MySQL.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 10: DATOS USUARIO
|--------------------------------------------------------------------------
*/
$usuarioId = (int)(
    $me['id']
    ?? $_SESSION['usuario_id']
    ?? 0
);

$usuarioNombre = (string)(
    $me['usuario']
    ?? $_SESSION['usuario']
    ?? 'Sistema'
);

$rolUsuario = (string)(
    $me['rol']
    ?? $_SESSION['rol']
    ?? ''
);

$ipUsuario = obtener_ip_sinstock();

/*
|--------------------------------------------------------------------------
| PASO 11: UPDATE SQL SERVER
|--------------------------------------------------------------------------
| Primero intentamos actualizar.
| Si el registro existe, aquí se actualiza.
|--------------------------------------------------------------------------
*/
$sqlUpdate = "
UPDATE vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]
SET
    EXHIBICION = ?,
    UXC = ?
WHERE LTRIM(RTRIM(CONVERT(VARCHAR(100), REGION))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODALMACEN))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODBARRAS))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), PLU), ''))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), ?), ''))) COLLATE DATABASE_DEFAULT
";

/*
|--------------------------------------------------------------------------
| PASO 12: INSERT SQL SERVER
|--------------------------------------------------------------------------
| Si el UPDATE no encuentra registro, se crea uno nuevo.
|--------------------------------------------------------------------------
*/
$sqlInsert = "
INSERT INTO vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]
(
    REGION,
    CODALMACEN,
    CODARTICULO,
    CODBARRAS,
    PLU,
    EXHIBICION,
    UXC
)
VALUES
(
    ?, ?, ?, ?, ?, ?, ?
)
";

/*
|--------------------------------------------------------------------------
| PASO 13: INSERT AUDITORÍA MYSQL
|--------------------------------------------------------------------------
*/
$sqlAuditoria = "
INSERT INTO auditoria
(
    usuario_id,
    usuario,
    rol,
    modulo,
    accion,
    descripcion,
    region,
    tienda,
    zona,
    codalmacen,
    ip
)
VALUES
(
    ?,
    ?,
    ?,
    'EXHIBICION',
    'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO',
    ?,
    ?,
    ?,
    ?,
    ?,
    ?
);
"; 


/*
|--------------------------------------------------------------------------
| PASO 14: PREPARAR AUDITORÍA
|--------------------------------------------------------------------------
*/
$stmtAud = $conn->prepare($sqlAuditoria);

if (!$stmtAud) {
    volver_sinstock(
        $returnQs,
        'err',
        'No se pudo preparar auditoría.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 15: INICIAR TRANSACCIÓN SQL SERVER
|--------------------------------------------------------------------------
*/
if (!sqlsrv_begin_transaction($sqlsrv_conn)) {
    $stmtAud->close();

    volver_sinstock(
        $returnQs,
        'err',
        'No se pudo iniciar transacción en SQL Server.'
    );
}

/*
|--------------------------------------------------------------------------
| PASO 16: CONTADORES
|--------------------------------------------------------------------------
*/
$guardados = 0;
$actualizados = 0;
$creados = 0;

try {

    /*
    |--------------------------------------------------------------------------
    | PASO 17: RECORRER REGISTROS
    |--------------------------------------------------------------------------
    */
    foreach ($items as $item) {

        if (!is_array($item)) {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.1: SOLO CHECK SELECCIONADOS
        |--------------------------------------------------------------------------
        */
        if (
            !isset($item['seleccionado']) ||
            (string)$item['seleccionado'] !== '1'
        ) {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.2: LIMPIAR DATOS
        |--------------------------------------------------------------------------
        */
        $region = normalizar_region_sinstock(
            (string)($item['region'] ?? '')
        );

        $codalmacen = limpiar_texto_sinstock(
            $item['codalmacen'] ?? ''
        );

        $codarticulo = limpiar_texto_sinstock(
            $item['codarticulo'] ?? ''
        );

        $codbarras = limpiar_texto_sinstock(
            $item['codbarras'] ?? ''
        );

        $plu = limpiar_texto_sinstock(
            $item['plu'] ?? ''
        );

        $tienda = limpiar_texto_sinstock(
            $item['nombrealmacen']
            ?? $item['tienda']
            ?? ''
        );

        $exhibicion = limpiar_numero_sinstock(
            $item['exhibicion'] ?? 0
        );

        $uxc = limpiar_numero_sinstock(
            $item['uxc'] ?? 0
        );

        /*
        |--------------------------------------------------------------------------
        | PASO 17.3: SI NO VIENE NOMBRE TIENDA
        |--------------------------------------------------------------------------
        */
        if ($tienda === '') {
            $tienda = $codalmacen;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.4: VALIDAR CAMPOS OBLIGATORIOS
        |--------------------------------------------------------------------------
        | Para crear o actualizar se necesita:
        | - REGION
        | - CODALMACEN
        | - CODARTICULO
        |--------------------------------------------------------------------------
        */
        if (
            $region === '' ||
            $codalmacen === '' ||
            $codarticulo === ''
        ) {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.5: INTENTAR UPDATE SQL SERVER
        |--------------------------------------------------------------------------
        */
      $paramsUpdate = [
    $exhibicion,
    $uxc,
    $region,
    $codalmacen,
    $codarticulo,
    $codbarras,
    $plu
];

        $stmtUpdate = sqlsrv_query(
            $sqlsrv_conn,
            $sqlUpdate,
            $paramsUpdate
        );

        if ($stmtUpdate === false) {
            throw new RuntimeException(
                print_r(sqlsrv_errors(), true)
            );
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.6: VERIFICAR SI ACTUALIZÓ
        |--------------------------------------------------------------------------
        | rows_affected:
        | - > 0: sí existía y actualizó
        | - 0: no existía y hay que insertar
        |--------------------------------------------------------------------------
        */
        $rowsAffected = sqlsrv_rows_affected($stmtUpdate);
        sqlsrv_free_stmt($stmtUpdate);

        $accionRegistro = 'ACTUALIZADO';

        /*
        |--------------------------------------------------------------------------
        | PASO 17.7: SI NO EXISTÍA, INSERTAR
        |--------------------------------------------------------------------------
        */
        if ((int)$rowsAffected <= 0) {

            $paramsInsert = [
                $region,
                $codalmacen,
                $codarticulo,
                $codbarras,
                $plu,
                $exhibicion,
                $uxc
            ];

            $stmtInsert = sqlsrv_query(
                $sqlsrv_conn,
                $sqlInsert,
                $paramsInsert
            );

            if ($stmtInsert === false) {
                throw new RuntimeException(
                    print_r(sqlsrv_errors(), true)
                );
            }

            sqlsrv_free_stmt($stmtInsert);

            $accionRegistro = 'CREADO';
            $creados++;

        } else {

            $actualizados++;
        }

        /*
        |--------------------------------------------------------------------------
        | PASO 17.8: DESCRIPCIÓN AUDITORÍA
        |--------------------------------------------------------------------------
        | IMPORTANTE:
        | - SIN ZONA
        | - CON NOMBRE TIENDA
        | - INDICA SI FUE CREADO O ACTUALIZADO
        |--------------------------------------------------------------------------
        */
        $descripcion = "Se guardó exhibición sin stock masiva."
            . " | ACCION: {$accionRegistro}"
            . " | REGION: {$region}"
            . " | TIENDA: {$tienda}"
            . " | CODARTICULO: {$codarticulo}"
            . " | CODBARRAS: {$codbarras}"
            . " | PLU: {$plu}"
            . " | EXHIBICION: {$exhibicion}"
            . " | UXC: {$uxc}";

              /*
        |--------------------------------------------------------------------------
        | PASO 17.9: GUARDAR AUDITORÍA
        |--------------------------------------------------------------------------
        */
        // 1. Obtenemos de forma dinámica la zona real de este registro específico ($item)
        // Si no viene en el registro, usamos la zona del usuario logueado como respaldo.
        $zonaDinamica = !empty($item['zona']) 
            ? trim((string)$item['zona']) 
            : (string)($me['zona'] ?? 'SIN ZONA');

        // 2. Usamos exactamente 9 letras ('issssssss') y 9 variables para coincidir con tu SQL.
        // Mantenemos invertidas $tienda y $zonaDinamica debido al cruce de tu Base de Datos.
        $stmtAud->bind_param(
            'issssssss',
            $usuarioId,
            $usuarioNombre,
            $rolUsuario,
            $descripcion,
            $region,
            $tienda,
            $zonaDinamica,           
            $codalmacen,
            $ipUsuario
        );

        if (!$stmtAud->execute()) {
            throw new RuntimeException(
                'No se pudo guardar auditoría: ' . $stmtAud->error
            );
        }

        $guardados++;
    }


    /*
    |--------------------------------------------------------------------------
    | PASO 18: VALIDAR SI GUARDÓ
    |--------------------------------------------------------------------------
    */
    if ($guardados <= 0) {

        sqlsrv_rollback($sqlsrv_conn);
        $stmtAud->close();

        volver_sinstock(
            $returnQs,
            'err',
            'No seleccionó registros.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 19: CONFIRMAR
    |--------------------------------------------------------------------------
    */
    sqlsrv_commit($sqlsrv_conn);

    $stmtAud->close();

    volver_sinstock(
        $returnQs,
        'ok',
        "Registros sin stock guardados correctamente. Actualizados: {$actualizados}. Creados: {$creados}."
    );

} catch (Throwable $e) {

    /*
    |--------------------------------------------------------------------------
    | PASO 20: SI HAY ERROR, DESHACER CAMBIOS
    |--------------------------------------------------------------------------
    */
    sqlsrv_rollback($sqlsrv_conn);

    if ($stmtAud instanceof mysqli_stmt) {
        $stmtAud->close();
    }

    volver_sinstock(
        $returnQs,
        'err',
        'Error al guardar: ' . $e->getMessage()
    );
}