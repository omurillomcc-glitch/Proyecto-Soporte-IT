<?php
declare(strict_types=1);

/* =========================================================
   1) RESPUESTA EN FORMATO JSON
========================================================= */
header('Content-Type: application/json; charset=utf-8');


session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   3) MOSTRAR ERRORES EN DESARROLLO
========================================================= */
ini_set('display_errors', '1');
error_reporting(E_ALL);

/* =========================================================
   4) CARGAR ARCHIVOS NECESARIOS
========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';



function aud_region_label(string $code): string
{
    return match (strtoupper(trim($code))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($code)),
    };
}

/* =========================================================
   5) FUNCIÓN PARA RESPONDER JSON
========================================================= */
function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(['ok' => $ok, 'msg' => $msg] + $extra, JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   6) NORMALIZAR PAÍS
========================================================= */
function normalizar_pais_code_guardar(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/* =========================================================
   7) VALIDAR LOGIN Y PERMISO ADMIN
========================================================= */
require_user_admin();
$me = me();

/* =========================================================
   8) DATOS DEL USUARIO LOGUEADO
========================================================= */
$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = normalizar_pais_code_guardar((string)($me['pais_code'] ?? ''));
$miZona = trim((string)($me['zona'] ?? ''));

/* =========================================================
   9) VALIDAR QUIÉN PUEDE CREAR USUARIOS
========================================================= */
if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    json_out(false, 'No tienes permisos.');
}

/* =========================================================
   10) RECIBIR DATOS DEL FORMULARIO
========================================================= */
$usuario     = trim((string)($_POST['usuario'] ?? ''));
$password    = trim((string)($_POST['password'] ?? ''));
$rol         = trim((string)($_POST['rol'] ?? ''));
$paisCode    = normalizar_pais_code_guardar((string)($_POST['pais_code'] ?? ''));
$estado      = isset($_POST['estado']) ? (int)($_POST['estado']) : 1;
$postTiendas = $_POST['tiendas'] ?? [];

/* =========================================================
   11) VALIDAR CAMPOS OBLIGATORIOS
========================================================= */
if ($usuario === '' || $password === '' || $rol === '' || $paisCode === '') {
    json_out(false, 'Completa todos los campos obligatorios.');
}

/* =========================================================
   12) VALIDAR NOMBRE DE USUARIO
   Solo letras, incluyendo acentos y Ñ.
========================================================= */
if (!preg_match('/^[\p{L}]+$/u', $usuario)) {
    json_out(false, 'El usuario solo puede contener letras.');
}

/* =========================================================
   13) VALIDAR LONGITUD DEL USUARIO
========================================================= */
if (mb_strlen($usuario) > 30) {
    json_out(false, 'El usuario no puede tener más de 30 caracteres.');
}

/* =========================================================
   14) VALIDAR LONGITUD DE CONTRASEÑA
========================================================= */
if (mb_strlen($password) < 6 || mb_strlen($password) > 20) {
    json_out(false, 'La contraseña debe tener entre 6 y 20 caracteres.');
}

/* =========================================================
   15) VALIDAR FORMATO DE CONTRASEÑA
========================================================= */
if (!preg_match('/^[A-Za-z0-9.]+$/', $password)) {
    json_out(false, 'La contraseña solo puede llevar letras, números y punto.');
}

/* =========================================================
   16) VALIDAR ROL
========================================================= */
$rolesValidos = ['super_admin', 'admin_zona', 'tienda'];

if (!in_array($rol, $rolesValidos, true)) {
    json_out(false, 'Rol inválido.');
}

/* =========================================================
   17) VALIDAR PAÍS
========================================================= */
$paisesValidos = ['HN', 'NI'];

if (!in_array($paisCode, $paisesValidos, true)) {
    json_out(false, 'País inválido.');
}

/* =========================================================
   18) RESTRICCIONES POR ROL DEL CREADOR
   - super_admin puede crear cualquier rol.
   - admin_zona solo puede crear tienda.
   - admin_zona solo puede crear de su país.
========================================================= */
if ($miRol === 'admin_zona' && $rol !== 'tienda') {
    json_out(false, 'Un admin_zona solo puede crear usuarios de tienda.');
}

if ($miRol === 'admin_zona' && $paisCode !== $miPais) {
    json_out(false, 'Solo puedes crear usuarios de tu mismo país.');
}

/* =========================================================
   19) NORMALIZAR ESTADO
========================================================= */
$estado = ($estado === 1) ? 1 : 0;

/* =========================================================
   20) DECODIFICAR TIENDAS RECIBIDAS
========================================================= */
$tiendas = [];

if (is_array($postTiendas)) {
    foreach ($postTiendas as $token) {
        $store = u_decode_store_token((string)$token);

        if (!$store || !is_array($store)) {
            continue;
        }

        $storePais = normalizar_pais_code_guardar((string)($store['pais_code'] ?? $store['pais'] ?? ''));
        $store['pais_code'] = $storePais;

        $tiendas[u_store_key_from_array($store)] = $store;
    }
}

$tiendas = array_values($tiendas);

/* =========================================================
   21) VALIDACIONES DE TIENDAS SEGÚN ROL NUEVO
========================================================= */
if ($rol !== 'super_admin' && count($tiendas) === 0) {
    json_out(false, 'Debes asignar al menos una tienda.');
}

if ($rol === 'tienda' && count($tiendas) !== 1) {
    json_out(false, 'El rol tienda solo puede tener una tienda.');
}

if ($rol === 'super_admin' && count($tiendas) > 0) {
    json_out(false, 'El super_admin no necesita tiendas asignadas.');
}

/* =========================================================
   22) VALIDAR QUE LAS TIENDAS SEAN DEL PAÍS ELEGIDO
========================================================= */
foreach ($tiendas as $t) {
    $storePais = normalizar_pais_code_guardar((string)($t['pais_code'] ?? $t['pais'] ?? ''));

    if ($storePais !== $paisCode) {
        json_out(false, 'Todas las tiendas seleccionadas deben pertenecer al país elegido.');
    }
}

/* =========================================================
   23) VALIDAR QUE LAS TIENDAS EXISTAN EN SQL SERVER
========================================================= */
foreach ($tiendas as $t) {
    if (!u_sqlsrv_store_exists($sqlsrv_conn, $t)) {
        json_out(false, 'Una tienda seleccionada no existe o ya no es válida.');
    }
}

/* =========================================================
   24) RESTRICCIONES EXTRA PARA ADMIN_ZONA
========================================================= */
if ($miRol === 'admin_zona') {
    $mias = u_get_user_store_keys($conn, $miId);

    foreach ($tiendas as $t) {
        $storeKey  = u_store_key_from_array($t);
        $storePais = normalizar_pais_code_guardar((string)($t['pais_code'] ?? $t['pais'] ?? ''));
        $storeZona = strtoupper(trim((string)($t['zona'] ?? '')));
        $miZonaCmp = strtoupper(trim($miZona));

        if ($storePais !== $miPais) {
            json_out(false, 'Solo puedes asignar tiendas de tu mismo país.');
        }

        if ($miZonaCmp !== '' && $storeZona !== $miZonaCmp) {
            json_out(false, 'Solo puedes asignar tiendas de tu misma zona.');
        }

        if (!isset($mias[$storeKey])) {
            json_out(false, 'Solo puedes asignar tiendas que te pertenecen.');
        }
    }
}

/* =========================================================
   25) VALIDAR QUE EL USUARIO NO EXISTA YA
========================================================= */
$stmtDup = $conn->prepare("
    SELECT id 
    FROM usuarios 
    WHERE BINARY usuario = ? 
    LIMIT 1
");

if (!$stmtDup) {
    json_out(false, 'Error preparando validación usuario.', ['sql_error' => $conn->error]);
}

$stmtDup->bind_param("s", $usuario);

if (!$stmtDup->execute()) {
    $errDup = $stmtDup->error;
    $stmtDup->close();
    json_out(false, 'Error ejecutando validación usuario.', ['sql_error' => $errDup]);
}

$resDup = $stmtDup->get_result();

if ($resDup && $resDup->num_rows > 0) {
    $stmtDup->close();
    json_out(false, 'Ese usuario ya existe.');
}

$stmtDup->close();

/* =========================================================
   25.1) VALIDAR QUE LA TIENDA NO TENGA YA UN USUARIO
========================================================= */
if ($rol === 'tienda' && count($tiendas) === 1) {

    $t = $tiendas[0];

    $baseDatos  = strtoupper(trim((string)($t['base_datos'] ?? '')));
    $codalmacen = trim((string)($t['codalmacen'] ?? ''));

    $stmtTiendaDup = $conn->prepare("
        SELECT u.id
        FROM usuarios u
        INNER JOIN usuario_tienda ut
            ON ut.usuario_id = u.id
        WHERE u.rol = 'tienda'
          AND UPPER(TRIM(ut.base_datos)) = ?
          AND TRIM(ut.codalmacen) = ?
        LIMIT 1
    ");

    if (!$stmtTiendaDup) {
        json_out(false, 'Error preparando validación tienda.', ['sql_error' => $conn->error]);
    }

    $stmtTiendaDup->bind_param("ss", $baseDatos, $codalmacen);

    if (!$stmtTiendaDup->execute()) {
        $errTiendaDup = $stmtTiendaDup->error;
        $stmtTiendaDup->close();
        json_out(false, 'Error ejecutando validación tienda.', ['sql_error' => $errTiendaDup]);
    }

    $resTiendaDup = $stmtTiendaDup->get_result();

    if ($resTiendaDup && $resTiendaDup->num_rows > 0) {
        $stmtTiendaDup->close();
        json_out(false, 'Esta tienda ya tiene un usuario creado. No puedes crear otro usuario para la misma tienda.');
    }

    $stmtTiendaDup->close();
}

/* =========================================================
   26) GENERAR HASH SEGURO DE CONTRASEÑA
========================================================= */
$hash = password_hash($password, PASSWORD_BCRYPT);

if ($hash === false) {
    json_out(false, 'No se pudo generar la contraseña segura.');
}

/* =========================================================
   27) INICIAR TRANSACCIÓN
========================================================= */
$conn->begin_transaction();

try {

    /* =====================================================
       28) INSERTAR USUARIO
    ===================================================== */
    $stmt = $conn->prepare("
        INSERT INTO usuarios (
            usuario, 
            password_hash, 
            rol, 
            pais_code, 
            estado
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        throw new RuntimeException('Error preparando insert usuarios: ' . $conn->error);
    }

    $stmt->bind_param("ssssi", $usuario, $hash, $rol, $paisCode, $estado);

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Error insertando usuario: ' . $err);
    }

    $stmt->close();

    /* =====================================================
       29) OBTENER ID DEL USUARIO NUEVO
    ===================================================== */
    $nuevoId = (int)$conn->insert_id;

    /* =====================================================
       30) INSERTAR TIENDAS ASIGNADAS
    ===================================================== */
    if ($rol !== 'super_admin') {

        $stmtUT = $conn->prepare("
            INSERT INTO usuario_tienda (
                usuario_id, 
                pais, 
                base_datos, 
                zona, 
                codalmacen, 
                nombrealmacen
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if (!$stmtUT) {
            throw new RuntimeException('Error preparando insert usuario_tienda: ' . $conn->error);
        }

        foreach ($tiendas as $t) {
            $pais          = normalizar_pais_code_guardar((string)($t['pais'] ?? $t['pais_code'] ?? ''));
            $base_datos    = trim((string)($t['base_datos'] ?? ''));
            $zona          = trim((string)($t['zona'] ?? ''));
            $codalmacen    = trim((string)($t['codalmacen'] ?? ''));
            $nombrealmacen = trim((string)($t['nombrealmacen'] ?? ''));

            $stmtUT->bind_param(
                "isssss",
                $nuevoId,
                $pais,
                $base_datos,
                $zona,
                $codalmacen,
                $nombrealmacen
            );

            if (!$stmtUT->execute()) {
                $errUT = $stmtUT->error;
                $stmtUT->close();
                throw new RuntimeException('Error insertando tienda del usuario: ' . $errUT);
            }
        }

        $stmtUT->close();
    }

    /* =====================================================
       31) CONFIRMAR TRANSACCIÓN
    ===================================================== */
    $conn->commit();

    /* =====================================================
       32) DESCRIPCIÓN PARA AUDITORÍA
    ===================================================== */
    $descripcionAuditoria = 'Se creó el usuario: ' . $usuario .
        ' | Rol: ' . $rol .
        ' | País: ' . $paisCode;

    if ($rol === 'tienda' && !empty($tiendas)) {
        $t = $tiendas[0];
        $descripcionAuditoria .= ' | Tienda: ' . (string)($t['nombrealmacen'] ?? '');
    }

    /* =====================================================
       33) REGISTRAR AUDITORÍA
    ===================================================== */
registrar_auditoria(
    'USUARIOS',
    'USUARIO_CREADO',
    $descripcionAuditoria,
    aud_region_label($paisCode),
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['zona'] ?? '') : '',
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['nombrealmacen'] ?? '') : '',
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['codalmacen'] ?? '') : ''
);

    /* =====================================================
       34) RESPUESTA EXITOSA
    ===================================================== */
    json_out(true, 'Usuario guardado correctamente.');

} catch (Throwable $e) {

    /* =====================================================
       35) SI ALGO FALLA, REVERTIR TODO
    ===================================================== */
    $conn->rollback();

    json_out(false, $e->getMessage());
}