<?php
declare(strict_types=1);

/* =========================================================
   1) RESPUESTA EN FORMATO JSON
   ---------------------------------------------------------
   Este archivo responde en JSON porque se usa desde fetch/AJAX
   al bloquear o desbloquear usuarios.
   ========================================================= */
header('Content-Type: application/json; charset=utf-8');

/* =========================================================
   2) INICIAR SESIÓN SI NO ESTÁ INICIADA
   ---------------------------------------------------------
   Esta aplicación usa su propia sesión para no mezclarse
   con otras apps.
   ========================================================= */
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   3) MOSTRAR ERRORES EN DESARROLLO
   ---------------------------------------------------------
   Útil mientras pruebas.
   En producción puedes desactivarlo.
   ========================================================= */
ini_set('display_errors', '1');
error_reporting(E_ALL);

/* =========================================================
   4) CARGAR ARCHIVOS NECESARIOS
   ---------------------------------------------------------
   db.php                -> conexión MySQL
   auth.php              -> validación de acceso/login
   helpers_usuarios.php  -> funciones auxiliares
   auditoria_helper.php  -> registrar auditoría
   ========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';

/* =========================================================
   5) FUNCIÓN PARA RESPONDER JSON Y SALIR
   ---------------------------------------------------------
   Devuelve una respuesta uniforme:
   {
     ok: true/false,
     msg: "mensaje"
   }
   ========================================================= */
function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

function aud_region_label_from_pais(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}

/* =========================================================
   6) VALIDAR QUE EL USUARIO ACTUAL SEA ADMIN
   ---------------------------------------------------------
   Solo administradores pueden bloquear o desbloquear usuarios.
   ========================================================= */
require_user_admin();
$me = me();

/* =========================================================
   7) DATOS DEL USUARIO AUTENTICADO
   ---------------------------------------------------------
   Se obtienen desde sesión:
   - id
   - rol
   ========================================================= */
$miId  = (int)($me['id'] ?? 0);
$miRol = (string)($me['rol'] ?? '');

/* =========================================================
   7.1) SOLO SUPER_ADMIN PUEDE BLOQUEAR / DESBLOQUEAR
   ---------------------------------------------------------
   admin_zona NO puede cambiar estado de usuarios.
   ========================================================= */
if ($miRol !== 'super_admin') {
    json_out(false, 'Solo el super_admin puede bloquear o desbloquear usuarios.');
}

/* =========================================================
   8) OBTENER DATOS RECIBIDOS
   ---------------------------------------------------------
   Se espera por POST:
   - id del usuario objetivo
   - estado nuevo (1 activo / 0 bloqueado)
   ========================================================= */
$id     = (int)($_POST['id'] ?? 0);
$estado = isset($_POST['estado']) ? (int)($_POST['estado']) : -1;

/* =========================================================
   9) VALIDAR DATOS BÁSICOS
   ---------------------------------------------------------
   - id debe ser válido
   - estado solo puede ser 0 o 1
   ========================================================= */
if ($id <= 0 || !in_array($estado, [0, 1], true)) {
    json_out(false, 'Datos inválidos.');
}

/* =========================================================
   10) EVITAR QUE EL USUARIO SE BLOQUEE A SÍ MISMO
   ---------------------------------------------------------
   Por seguridad, no puede cambiar su propio estado.
   ========================================================= */
if ($id === $miId) {
    json_out(false, 'No puedes bloquearte a ti misma.');
}

/* =========================================================
   11) VALIDAR PERMISO SOBRE EL USUARIO OBJETIVO
   ---------------------------------------------------------
   super_admin puede más.
   admin_zona solo puede gestionar usuarios permitidos
   según la lógica de u_can_manage_user().
   ========================================================= */
if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    json_out(false, 'No puedes cambiar el estado de este usuario.');
}

/* =========================================================
   12) CONSULTAR DATOS DEL USUARIO ANTES DE ACTUALIZAR
   ---------------------------------------------------------
   Esto se usa para:
   - validar que exista
   - registrar auditoría
   ========================================================= */
$stmtUser = $conn->prepare("
    SELECT usuario, rol, pais_code
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmtUser) {
    json_out(false, 'No se pudo consultar el usuario.');
}

$stmtUser->bind_param("i", $id);
$stmtUser->execute();
$resUser = $stmtUser->get_result();
$userRow = $resUser ? $resUser->fetch_assoc() : null;
$stmtUser->close();

if (!$userRow) {
    json_out(false, 'Usuario no encontrado.');
}

/* =========================================================
   13) GUARDAR DATOS DEL USUARIO OBJETIVO
   ---------------------------------------------------------
   Se usarán luego en la auditoría.
   ========================================================= */
$usuarioObjetivo = (string)($userRow['usuario'] ?? '');
$rolObjetivo     = (string)($userRow['rol'] ?? '');
$paisObjetivo    = (string)($userRow['pais_code'] ?? '');

/* =========================================================
   14) BUSCAR ZONA / TIENDA / CODALMACEN DEL USUARIO
   ---------------------------------------------------------
   Si el usuario tiene tienda asignada, se usa la primera
   para completar la auditoría.
   ========================================================= */
$zonaObjetivo = '';
$tiendaObjetivo = '';
$codalmacenObjetivo = '';

$stmtStore = $conn->prepare("
    SELECT zona, nombrealmacen, codalmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY id ASC
    LIMIT 1
");

if ($stmtStore) {
    $stmtStore->bind_param("i", $id);
    $stmtStore->execute();
    $resStore = $stmtStore->get_result();
    $storeRow = $resStore ? $resStore->fetch_assoc() : null;
    $stmtStore->close();

    if ($storeRow) {
        $zonaObjetivo       = (string)($storeRow['zona'] ?? '');
        $tiendaObjetivo     = (string)($storeRow['nombrealmacen'] ?? '');
        $codalmacenObjetivo = (string)($storeRow['codalmacen'] ?? '');
    }
}

/* =========================================================
   15) ACTUALIZAR ESTADO DEL USUARIO
   ---------------------------------------------------------
   1 = activo
   0 = bloqueado
   ========================================================= */
$stmt = $conn->prepare("
    UPDATE usuarios
    SET estado = ?
    WHERE id = ?
");

if (!$stmt) {
    json_out(false, 'No se pudo preparar el cambio de estado.');
}

$stmt->bind_param("ii", $estado, $id);

if (!$stmt->execute()) {
    $err = $stmt->error;
    $stmt->close();
    json_out(false, 'No se pudo cambiar el estado del usuario: ' . $err);
}

$stmt->close();

/* =========================================================
   16) REGISTRAR AUDITORÍA
   ---------------------------------------------------------
   Guarda si se bloqueó o desbloqueó el usuario y agrega:
   - usuario
   - rol
   - país
   - zona
   - tienda
   - codalmacen
   ========================================================= */
registrar_auditoria(
    'USUARIOS',
    $estado === 1 ? 'USUARIO_DESBLOQUEADO' : 'USUARIO_BLOQUEADO',
    $estado === 1
        ? 'Se desbloqueó el usuario: ' . $usuarioObjetivo . ' | Rol: ' . $rolObjetivo
        : 'Se bloqueó el usuario: ' . $usuarioObjetivo . ' | Rol: ' . $rolObjetivo,
    aud_region_label_from_pais($paisObjetivo),
    $zonaObjetivo,
    $tiendaObjetivo,
    $codalmacenObjetivo
);
/* =========================================================
   17) RESPUESTA EXITOSA
   ========================================================= */
json_out(
    true,
    $estado === 1
        ? 'Usuario desbloqueado correctamente.'
        : 'Usuario bloqueado correctamente.'
);