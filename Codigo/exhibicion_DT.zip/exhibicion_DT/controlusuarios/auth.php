<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


/* =========================================================
   2) CONFIGURACIÓN DE SESIÓN
   ========================================================= */
define('SESSION_TIMEOUT', 86400); // 1 día por inactividad
define('SESSION_LIFETIME', 86400); // 1 día máximo total

/* =========================================================
   3) CERRAR SESIÓN POR TIEMPO
   ========================================================= */
function validar_tiempo_sesion(): void {

    if (empty($_SESSION['usuario_id'])) {
        return;
    }

    if (isset($_SESSION['LAST_ACTIVITY'])) {
        $inactivo = time() - (int)$_SESSION['LAST_ACTIVITY'];

        if ($inactivo > SESSION_TIMEOUT) {
            session_unset();
            session_destroy();

            header('Location: /exhibicion_DT/controlusuarios/login.php?expired=1');
            exit;
        }
    }

    $_SESSION['LAST_ACTIVITY'] = time();

    if (!isset($_SESSION['CREATED'])) {
        $_SESSION['CREATED'] = time();
    } elseif ((time() - (int)$_SESSION['CREATED']) > SESSION_LIFETIME) {
        session_unset();
        session_destroy();

        header('Location: /exhibicion_DT/controlusuarios/login.php?expired=1');
        exit;
    }
}

/* =========================================================
   4) OBLIGAR A QUE EL USUARIO ESTÉ LOGUEADO
   ========================================================= */
function require_login(): void {
    validar_tiempo_sesion();

    if (empty($_SESSION['usuario_id'])) {
        header('Location: /exhibicion_DT/controlusuarios/login.php');
        exit;
    }
}

/* =========================================================
   5) OBLIGAR A QUE SEA USUARIO ADMINISTRADOR
   ========================================================= */
function require_user_admin(): void {
    require_login();

    $rol = (string)($_SESSION['rol'] ?? '');

    if (!in_array($rol, ['super_admin', 'admin_zona'], true)) {
        http_response_code(403);
        exit('Acceso denegado.');
    }
}

/* =========================================================
   6) DEVOLVER DATOS DEL USUARIO AUTENTICADO
   ========================================================= */
function me(): array {
    return [
        'id'         => (int)($_SESSION['usuario_id'] ?? 0),
        'usuario'    => (string)($_SESSION['usuario'] ?? ''),
        'rol'        => (string)($_SESSION['rol'] ?? ''),
        'estado'     => (int)($_SESSION['estado'] ?? 0),
        'pais_code'  => (string)($_SESSION['pais_code'] ?? ''),
        'pais'       => (string)($_SESSION['pais'] ?? ''),
        'zona'       => (string)($_SESSION['zona'] ?? ''),
        'tienda'     => (string)($_SESSION['tienda'] ?? ''),
        'codalmacen' => (string)($_SESSION['codalmacen'] ?? ''),
    ];
}