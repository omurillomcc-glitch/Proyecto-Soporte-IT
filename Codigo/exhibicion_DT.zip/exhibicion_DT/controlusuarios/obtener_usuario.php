<?php
declare(strict_types=1);

/* =========================================================
   1) RESPUESTA EN FORMATO JSON
   ---------------------------------------------------------
   Este archivo responde en JSON porque se usa desde fetch/AJAX
   al abrir el modal de editar usuario.
   ========================================================= */
header('Content-Type: application/json; charset=utf-8');

/*
|--------------------------------------------------------------------------
| 2) INICIAR SESIÓN SI NO ESTÁ INICIADA
|--------------------------------------------------------------------------
| Esta aplicación usa su propia sesión para no mezclarse con otras apps.
|--------------------------------------------------------------------------
*/
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/* =========================================================
   3) CARGAR ARCHIVOS NECESARIOS
   ---------------------------------------------------------
   db.php               -> conexión MySQL
   auth.php             -> login / permisos
   helpers_usuarios.php -> funciones auxiliares
   ========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';

/* =========================================================
   4) FUNCIÓN PARA RESPONDER JSON Y SALIR
   ---------------------------------------------------------
   Devuelve una respuesta uniforme:
   {
     ok: true/false,
     msg: "mensaje",
     ...
   }
   ========================================================= */
function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/* =========================================================
   5) NORMALIZAR CÓDIGO DE PAÍS
   ---------------------------------------------------------
   Convierte variantes como:
   - HONDURAS  -> HN
   - NICARAGUA -> NI
   ========================================================= */
function normalizar_pais_code_obtener(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/* =========================================================
   6) VALIDAR QUE EL USUARIO AUTENTICADO SEA ADMIN
   ---------------------------------------------------------
   Solo un administrador puede abrir datos de usuarios
   para editarlos.
   ========================================================= */
require_user_admin();
$me = me();

/* =========================================================
   7) DATOS DEL USUARIO ACTUAL
   ---------------------------------------------------------
   Se toman desde sesión:
   - ID
   - rol
   ========================================================= */
$miId  = (int)($me['id'] ?? 0);
$miRol = (string)($me['rol'] ?? '');

/* =========================================================
   8) OBTENER ID DEL USUARIO A CONSULTAR
   ---------------------------------------------------------
   Se recibe por GET:
   obtener_usuario.php?id=123
   ========================================================= */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    json_out(false, 'ID inválido.');
}

/* =========================================================
   9) VALIDAR QUE EL USUARIO ACTUAL TENGA PERMISO
   ---------------------------------------------------------
   super_admin puede ver más usuarios.
   admin_zona solo los que le correspondan.
   ========================================================= */
if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    json_out(false, 'No puedes ver este usuario.');
}

/* =========================================================
   10) OBTENER DATOS PRINCIPALES DEL USUARIO
   ---------------------------------------------------------
   Se consultan:
   - id
   - usuario
   - rol
   - estado
   - país
   ========================================================= */
$stmt = $conn->prepare("
    SELECT
        id,
        usuario,
        rol,
        estado,
        pais_code
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    json_out(false, 'Error preparando consulta del usuario.', [
        'sql_error' => $conn->error
    ]);
}

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
    $err = $stmt->error;
    $stmt->close();
    json_out(false, 'Error ejecutando consulta del usuario.', [
        'sql_error' => $err
    ]);
}

$res  = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if (!$user) {
    json_out(false, 'Usuario no encontrado.');
}

/* =========================================================
   11) OBTENER TIENDAS ASIGNADAS AL USUARIO
   ---------------------------------------------------------
   Se traen desde la tabla usuario_tienda.
   ========================================================= */
$stmt2 = $conn->prepare("
    SELECT
        pais,
        base_datos,
        zona,
        codalmacen,
        nombrealmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY pais, base_datos, zona, codalmacen
");

if (!$stmt2) {
    json_out(false, 'Error preparando consulta de tiendas.', [
        'sql_error' => $conn->error
    ]);
}

$stmt2->bind_param("i", $id);

if (!$stmt2->execute()) {
    $err2 = $stmt2->error;
    $stmt2->close();
    json_out(false, 'Error ejecutando consulta de tiendas.', [
        'sql_error' => $err2
    ]);
}

$res2 = $stmt2->get_result();

/* =========================================================
   12) ARMAR ARREGLOS DE TIENDAS Y CLAVES ÚNICAS
   ---------------------------------------------------------
   stores:
   - arreglo completo de tiendas

   store_keys:
   - llaves únicas para marcar checkboxes en el modal editar
   ========================================================= */
$stores = [];
$store_keys = [];

while ($row = $res2->fetch_assoc()) {
    $paisTexto = trim((string)($row['pais'] ?? ''));
    $paisCode  = normalizar_pais_code_obtener($paisTexto);

    $store = [
        'pais'          => $paisTexto,
        'pais_code'     => $paisCode,
        'base_datos'    => (string)($row['base_datos'] ?? ''),
        'zona'          => (string)($row['zona'] ?? ''),
        'codalmacen'    => (string)($row['codalmacen'] ?? ''),
        'nombrealmacen' => (string)($row['nombrealmacen'] ?? ''),
    ];

    $stores[] = $store;

    $store_keys[] = u_store_key(
        $paisTexto,
        (string)($row['base_datos'] ?? ''),
        (string)($row['codalmacen'] ?? '')
    );
}

$stmt2->close();

/* =========================================================
   13) RESPUESTA EXITOSA
   ---------------------------------------------------------
   Devuelve:
   - datos del usuario
   - tiendas asignadas
   - claves de tiendas para marcar en el modal
   ========================================================= */
json_out(true, 'ok', [
    'data' => [
        'id'         => (int)($user['id'] ?? 0),
        'usuario'    => (string)($user['usuario'] ?? ''),
        'rol'        => (string)($user['rol'] ?? ''),
        'estado'     => (int)($user['estado'] ?? 1),
        'pais_code'  => normalizar_pais_code_obtener((string)($user['pais_code'] ?? '')),
        'stores'     => $stores,
        'store_keys' => $store_keys,
    ]
]);