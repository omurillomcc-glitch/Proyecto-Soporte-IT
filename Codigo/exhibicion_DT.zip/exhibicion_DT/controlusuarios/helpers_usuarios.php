<?php
declare(strict_types=1);

/* =========================================================
   1) ESCAPAR TEXTO PARA HTML
   ---------------------------------------------------------
   Evita problemas de XSS al imprimir texto en pantalla.
   ========================================================= */
function u_h(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* =========================================================
   2) NORMALIZAR TEXTO
   ---------------------------------------------------------
   Convierte a string y quita espacios sobrantes.
   ========================================================= */
function u_norm($v): string {
    return trim((string)$v);
}

/* =========================================================
   3) NORMALIZAR CÓDIGO DE PAÍS
   ---------------------------------------------------------
   Convierte:
   - HONDURAS  -> HN
   - NICARAGUA -> NI
   ========================================================= */
function u_pais_code(string $pais): string {
    $pais = mb_strtoupper(u_norm($pais), 'UTF-8');

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/* =========================================================
   4) OBTENER NOMBRE BONITO DEL PAÍS
   ---------------------------------------------------------
   Convierte:
   - HN -> Honduras
   - NI -> Nicaragua
   ========================================================= */
function u_pais_nombre(string $pais): string {
    $code = u_pais_code($pais);

    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => u_norm($pais),
    };
}

/* =========================================================
   5) CREAR LLAVE ÚNICA DE TIENDA
   ---------------------------------------------------------
   Se usa para comparar tiendas entre usuarios.
   Formato:
   PAIS|BASE|CODALMACEN
   ========================================================= */
function u_store_key(string $pais, string $base, string $cod): string {
    return mb_strtoupper(
        u_pais_code($pais) . '|' . u_norm($base) . '|' . u_norm($cod),
        'UTF-8'
    );
}

/* =========================================================
   6) CREAR LLAVE ÚNICA DE TIENDA DESDE ARREGLO
   ========================================================= */
function u_store_key_from_array(array $t): string {
    return u_store_key(
        (string)($t['pais_code'] ?? $t['pais'] ?? ''),
        (string)($t['base_datos'] ?? ''),
        (string)($t['codalmacen'] ?? '')
    );
}

/* =========================================================
   7) CODIFICAR TIENDA EN TOKEN
   ---------------------------------------------------------
   Convierte la tienda a base64/json para enviarla
   en checkboxes del formulario.
   ========================================================= */
function u_store_token(array $t): string {
    return base64_encode(json_encode([
        'pais'          => u_pais_nombre((string)($t['pais'] ?? $t['pais_code'] ?? '')),
        'pais_code'     => u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? '')),
        'base_datos'    => u_norm($t['base_datos'] ?? ''),
        'zona'          => u_norm($t['zona'] ?? ''),
        'codalmacen'    => u_norm($t['codalmacen'] ?? ''),
        'nombrealmacen' => u_norm($t['nombrealmacen'] ?? ''),
    ], JSON_UNESCAPED_UNICODE));
}

/* =========================================================
   8) DECODIFICAR TOKEN DE TIENDA
   ---------------------------------------------------------
   Convierte el token base64/json nuevamente en arreglo.
   ========================================================= */
function u_decode_store_token(string $token): ?array {
    $json = base64_decode($token, true);
    if ($json === false) {
        return null;
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        return null;
    }

    $paisCode = u_pais_code((string)($data['pais_code'] ?? $data['pais'] ?? ''));
    $pais     = u_pais_nombre((string)($data['pais'] ?? $paisCode));

    $store = [
        'pais'          => $pais,
        'pais_code'     => $paisCode,
        'base_datos'    => u_norm($data['base_datos'] ?? ''),
        'zona'          => u_norm($data['zona'] ?? ''),
        'codalmacen'    => u_norm($data['codalmacen'] ?? ''),
        'nombrealmacen' => u_norm($data['nombrealmacen'] ?? ''),
    ];

    if (
        $store['pais_code'] === '' ||
        $store['base_datos'] === '' ||
        $store['zona'] === '' ||
        $store['codalmacen'] === '' ||
        $store['nombrealmacen'] === ''
    ) {
        return null;
    }

    return $store;
}

/* =========================================================
   9) CONSULTA SEGURA A SQL SERVER
   ---------------------------------------------------------
   Ejecuta query y devuelve todas las filas.
   Si falla, lanza excepción.
   ========================================================= */
function u_sqlsrv_fetch_all_safe($sqlsrv_conn, string $sql, array $params = []): array {
    $stmt = sqlsrv_query($sqlsrv_conn, $sql, $params);

    if ($stmt === false) {
        throw new RuntimeException('Error consultando SQL Server.');
    }

    $rows = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $rows[] = $row;
    }

    sqlsrv_free_stmt($stmt);
    return $rows;
}

/* =========================================================
   10) OBTENER TODAS LAS TIENDAS DESDE SQL SERVER
   ---------------------------------------------------------
   Trae tiendas válidas desde:
   - DETODO (HN)
   - ACANICARAGUA2 (NI)
   ========================================================= */
function u_get_all_stores_from_sqlsrv($sqlsrv_conn): array {
    $sqlDetodo = "
        SELECT DISTINCT
            'Honduras' AS pais,
            'HN' AS pais_code,
            'DETODO' AS base_datos,
            LTRIM(RTRIM(POBLACION))     AS zona,
            LTRIM(RTRIM(CODALMACEN))    AS codalmacen,
            LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen
        FROM DETODO.dbo.almacen
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(POBLACION)) <> ''
          AND LTRIM(RTRIM(CODALMACEN)) NOT LIKE '%M'
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $sqlNicaragua = "
        SELECT DISTINCT
            'Nicaragua' AS pais,
            'NI' AS pais_code,
            'ACANICARAGUA2' AS base_datos,
            LTRIM(RTRIM(POBLACION))     AS zona,
            LTRIM(RTRIM(CODALMACEN))    AS codalmacen,
            LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen
        FROM ACANICARAGUA2.dbo.almacen
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(POBLACION)) <> ''
          AND LTRIM(RTRIM(CODALMACEN)) NOT LIKE '%M'
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $rows = array_merge(
        u_sqlsrv_fetch_all_safe($sqlsrv_conn, $sqlDetodo),
        u_sqlsrv_fetch_all_safe($sqlsrv_conn, $sqlNicaragua)
    );

    $map = [];
    foreach ($rows as $r) {
        $item = [
            'pais'          => u_pais_nombre((string)($r['pais'] ?? $r['pais_code'] ?? '')),
            'pais_code'     => u_pais_code((string)($r['pais_code'] ?? $r['pais'] ?? '')),
            'base_datos'    => u_norm($r['base_datos'] ?? ''),
            'zona'          => u_norm($r['zona'] ?? ''),
            'codalmacen'    => u_norm($r['codalmacen'] ?? ''),
            'nombrealmacen' => u_norm($r['nombrealmacen'] ?? ''),
        ];

        if (
            $item['pais_code'] === '' ||
            $item['base_datos'] === '' ||
            $item['zona'] === '' ||
            $item['codalmacen'] === '' ||
            $item['nombrealmacen'] === ''
        ) {
            continue;
        }

        $map[u_store_key_from_array($item)] = $item;
    }

    $stores = array_values($map);

    usort($stores, function ($a, $b) {
        return [
            $a['pais_code'], $a['pais'], $a['base_datos'], $a['zona'], $a['codalmacen'], $a['nombrealmacen']
        ] <=> [
            $b['pais_code'], $b['pais'], $b['base_datos'], $b['zona'], $b['codalmacen'], $b['nombrealmacen']
        ];
    });

    return $stores;
}

/* =========================================================
   11) OBTENER LLAVES DE TIENDAS DE UN USUARIO
   ---------------------------------------------------------
   Devuelve arreglo tipo:
   [
     'HN|DETODO|001' => true,
     'HN|DETODO|002' => true
   ]
   ========================================================= */
function u_get_user_store_keys(mysqli $conn, int $usuarioId): array {
    $stmt = $conn->prepare("
        SELECT pais, base_datos, codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
    ");
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();
    $res = $stmt->get_result();

    $keys = [];
    while ($row = $res->fetch_assoc()) {
        $keys[u_store_key(
            (string)($row['pais'] ?? ''),
            (string)($row['base_datos'] ?? ''),
            (string)($row['codalmacen'] ?? '')
        )] = true;
    }

    $stmt->close();
    return $keys;
}

/* =========================================================
   12) FILTRAR TIENDAS DISPONIBLES PARA admin_zona
   ---------------------------------------------------------
   Solo deja las tiendas que le pertenecen al admin actual.
   ========================================================= */
function u_filter_stores_for_admin(mysqli $conn, int $usuarioId, array $stores): array {
    $allowed = u_get_user_store_keys($conn, $usuarioId);

    if (empty($allowed)) {
        return [];
    }

    return array_values(array_filter($stores, function ($t) use ($allowed) {
        return isset($allowed[u_store_key_from_array($t)]);
    }));
}

/* =========================================================
   13) AGRUPAR TIENDAS
   ---------------------------------------------------------
   Estructura:
   Pais -> Base -> Zona -> tiendas[]
   ========================================================= */
function u_group_stores(array $stores): array {
    $grouped = [];

    foreach ($stores as $t) {
        $paisNombre = (string)($t['pais'] ?? u_pais_nombre((string)($t['pais_code'] ?? '')));
        $base       = (string)($t['base_datos'] ?? '');
        $zona       = (string)($t['zona'] ?? '');

        $grouped[$paisNombre][$base][$zona][] = $t;
    }

    return $grouped;
}

/* =========================================================
   14) RENDERIZAR CHECKBOXES DE TIENDAS
   ---------------------------------------------------------
   Genera el HTML de tiendas para crear/editar usuarios.
   ========================================================= */
function u_render_store_checks(array $grouped, string $name, string $class, array $selectedKeys = []): string {
    ob_start();

    if (empty($grouped)) {
        echo '<div class="alert alert-warning">No hay tiendas disponibles.</div>';
        return ob_get_clean();
    }

    foreach ($grouped as $pais => $bases) {
        $paisCode = u_pais_code((string)$pais);

        echo '<div class="mb-4 store-country-group" data-pais="' . u_h($paisCode) . '">';
        echo '<h6 class="fw-bold text-primary">' . u_h((string)$pais) . '</h6>';

        foreach ($bases as $base => $zonas) {
            echo '<div class="border rounded-4 p-3 mb-3 store-base-box">';
            echo '<div class="fw-semibold mb-2">Base: ' . u_h((string)$base) . '</div>';

            foreach ($zonas as $zona => $items) {
                echo '<div class="mb-3 store-zone-group">';
                echo '<div class="small fw-bold text-secondary mb-2">Zona: ' . u_h((string)$zona) . '</div>';
                echo '<div class="row g-2">';

                foreach ($items as $t) {
                    $token   = u_store_token($t);
                    $key     = u_store_key_from_array($t);
                    $checked = isset($selectedKeys[$key]) ? 'checked' : '';
                    $paisC   = u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? ''));

                    echo '<div class="col-md-6 col-xl-4 store-item" data-pais="' . u_h($paisC) . '">';
                    echo '<label class="border rounded-3 p-2 w-100 d-flex align-items-start gap-2">';
                    echo '<input type="checkbox"
                                name="' . u_h($name) . '[]"
                                value="' . u_h($token) . '"
                                data-key="' . u_h($key) . '"
                                data-pais="' . u_h($paisC) . '"
                                class="mt-1 ' . u_h($class) . '"
                                ' . $checked . '>';
                    echo '<span>';
                    echo '<strong>' . u_h((string)($t['codalmacen'] ?? '')) . '</strong> - ' . u_h((string)($t['nombrealmacen'] ?? '')) . '<br>';
                    echo '<small class="text-muted">' . u_h((string)($t['pais'] ?? '')) . ' / ' . u_h((string)($t['base_datos'] ?? '')) . ' / ' . u_h((string)($t['zona'] ?? '')) . '</small>';
                    echo '</span>';
                    echo '</label>';
                    echo '</div>';
                }

                echo '</div>';
                echo '</div>';
            }

            echo '</div>';
        }

        echo '</div>';
    }

    return ob_get_clean();
}

/* =========================================================
   15) VALIDAR SI UNA TIENDA EXISTE EN SQL SERVER
   ---------------------------------------------------------
   Verifica codalmacen en la base correcta.
   ========================================================= */
function u_sqlsrv_store_exists($sqlsrv_conn, array $t): bool {
    $base = u_norm($t['base_datos'] ?? '');

    $dbs = [
        'DETODO'        => 'DETODO',
        'ACANICARAGUA2' => 'ACANICARAGUA2',
    ];

    if (!isset($dbs[$base])) {
        return false;
    }

    $db = $dbs[$base];
    $codalmacen = u_norm($t['codalmacen'] ?? '');

    if ($codalmacen === '') {
        return false;
    }

    $sql = "
        SELECT TOP 1 1 AS existe
        FROM {$db}.dbo.almacen
        WHERE LTRIM(RTRIM(CODALMACEN)) = ?
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql, [$codalmacen]);

    if ($stmt === false) {
        return false;
    }

    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);

    return $row ? true : false;
}

/* =========================================================
   16) VALIDAR SI EL USUARIO ACTUAL PUEDE GESTIONAR A OTRO
   ---------------------------------------------------------
   REGLAS:
   - super_admin puede gestionar a todos
   - admin_zona:
       * puede gestionarse a sí mismo
       * puede gestionar solo usuarios tienda
       * solo si las tiendas del usuario objetivo pertenecen
         completamente a sus propias tiendas
       * no puede gestionar super_admin
       * no puede gestionar otro admin_zona
   ========================================================= */
function u_can_manage_user(mysqli $conn, int $myId, string $myRole, int $targetId): bool {
    /* -----------------------------------------------------
       super_admin puede gestionar a cualquiera
       ----------------------------------------------------- */
    if ($myRole === 'super_admin') {
        return true;
    }

    /* -----------------------------------------------------
       Si no es admin_zona, no tiene permiso
       ----------------------------------------------------- */
    if ($myRole !== 'admin_zona') {
        return false;
    }

    /* -----------------------------------------------------
       admin_zona sí puede gestionarse a sí mismo
       ----------------------------------------------------- */
    if ($targetId === $myId) {
        return true;
    }

    /* -----------------------------------------------------
       Obtener datos básicos del usuario actual
       ----------------------------------------------------- */
    $stmtMine = $conn->prepare("
        SELECT pais_code
        FROM usuarios
        WHERE id = ?
        LIMIT 1
    ");
    if (!$stmtMine) {
        return false;
    }

    $stmtMine->bind_param("i", $myId);
    $stmtMine->execute();
    $mine = $stmtMine->get_result()->fetch_assoc();
    $stmtMine->close();

    if (!$mine) {
        return false;
    }

    $miPais = u_pais_code((string)($mine['pais_code'] ?? ''));

    /* -----------------------------------------------------
       Obtener datos del usuario objetivo
       ----------------------------------------------------- */
    $stmtTarget = $conn->prepare("
        SELECT id, rol, pais_code
        FROM usuarios
        WHERE id = ?
        LIMIT 1
    ");
    if (!$stmtTarget) {
        return false;
    }

    $stmtTarget->bind_param("i", $targetId);
    $stmtTarget->execute();
    $target = $stmtTarget->get_result()->fetch_assoc();
    $stmtTarget->close();

    if (!$target) {
        return false;
    }

    $targetRol  = (string)($target['rol'] ?? '');
    $targetPais = u_pais_code((string)($target['pais_code'] ?? ''));

    /* -----------------------------------------------------
       admin_zona NO puede gestionar:
       - super_admin
       - admin_zona
       ----------------------------------------------------- */
    if ($targetRol === 'super_admin' || $targetRol === 'admin_zona') {
        return false;
    }

    /* -----------------------------------------------------
       Debe ser del mismo país
       ----------------------------------------------------- */
    if ($targetPais !== '' && $miPais !== '' && $targetPais !== $miPais) {
        return false;
    }

    /* -----------------------------------------------------
       Obtener tiendas del admin_zona actual
       ----------------------------------------------------- */
    $misKeys = u_get_user_store_keys($conn, $myId);
    if (empty($misKeys)) {
        return false;
    }

    /* -----------------------------------------------------
       Obtener tiendas del usuario objetivo
       ----------------------------------------------------- */
    $stmtStores = $conn->prepare("
        SELECT pais, base_datos, codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
    ");
    if (!$stmtStores) {
        return false;
    }

    $stmtStores->bind_param("i", $targetId);
    $stmtStores->execute();
    $resStores = $stmtStores->get_result();

    $targetTieneTiendas = false;

    while ($row = $resStores->fetch_assoc()) {
        $targetTieneTiendas = true;

        $pais = u_pais_code((string)($row['pais'] ?? ''));
        $key  = u_store_key(
            (string)($row['pais'] ?? ''),
            (string)($row['base_datos'] ?? ''),
            (string)($row['codalmacen'] ?? '')
        );

        if ($miPais !== '' && $pais !== $miPais) {
            $stmtStores->close();
            return false;
        }

        if (!isset($misKeys[$key])) {
            $stmtStores->close();
            return false;
        }
    }

    $stmtStores->close();

    /* -----------------------------------------------------
       El usuario tienda debe tener al menos una tienda
       para poder ser gestionado
       ----------------------------------------------------- */
    return $targetTieneTiendas;
}