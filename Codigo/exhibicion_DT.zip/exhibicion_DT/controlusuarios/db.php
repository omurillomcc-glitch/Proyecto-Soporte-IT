<?php
declare(strict_types=1);

$host = "localhost";
$user = "root";
$pass = "";
$db   = "exhibiciondt";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

/* Charset */
$conn->set_charset("utf8mb4");

/* Collation */
$conn->query("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");