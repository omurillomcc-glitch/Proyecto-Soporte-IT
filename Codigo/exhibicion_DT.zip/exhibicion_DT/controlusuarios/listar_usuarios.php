<?php
declare(strict_types=1);

/* =========================================================
   1) INICIAR SESIÓN SI NO ESTÁ INICIADA
   ---------------------------------------------------------
   Si la sesión ya está activa, no intentamos cambiar el nombre.
   ========================================================= */
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


/* =========================================================
   2) MOSTRAR ERRORES EN DESARROLLO
   ========================================================= */
ini_set('display_errors', '1');
error_reporting(E_ALL);

/* =========================================================
   3) CARGAR ARCHIVOS NECESARIOS
   ========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__. '/helpers_usuarios.php';

/* =========================================================
   4) VALIDAR ACCESO
   ========================================================= */
require_user_admin();
$me = me();

$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));

if ($miPais === '') {
    $miPais = 'HN';
}

if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}

/* =========================================================
   5) FUNCIÓN PARA MOSTRAR NOMBRE BONITO DEL PAÍS
   ========================================================= */
function nombre_pais_listado(string $code): string {
    $code = strtoupper(trim($code));

    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => $code !== '' ? $code : 'Sin país',
    };
}

/* =========================================================
   6) FUNCIÓN PARA PARTIR TEXTO CONCATENADO
   ========================================================= */
function partir_valores_concat(?string $texto): array
{
    $texto = trim((string)$texto);

    if ($texto === '') {
        return [];
    }

    $partes = array_map('trim', explode('||', $texto));
    $partes = array_filter($partes, static fn($v) => $v !== '');

    return array_values(array_unique($partes));
}

/* =========================================================
   7) FUNCIÓN PARA PARSEAR TIENDAS
   ========================================================= */
function parsear_tienda(string $texto): array
{
    $texto = trim($texto);

    $resultado = [
        'pais'   => '',
        'base'   => '',
        'zona'   => '',
        'codigo' => '',
        'nombre' => '',
        'texto'  => $texto,
    ];

    if ($texto === '') {
        return $resultado;
    }

    $partes = array_map('trim', explode(' / ', $texto));

    if (count($partes) >= 4) {
        $resultado['pais'] = $partes[0] ?? '';
        $resultado['base'] = $partes[1] ?? '';
        $resultado['zona'] = $partes[2] ?? '';

        $ultimo = $partes[3] ?? '';

        if (str_contains($ultimo, ' - ')) {
            [$codigo, $nombre] = array_map('trim', explode(' - ', $ultimo, 2));
            $resultado['codigo'] = $codigo;
            $resultado['nombre'] = $nombre;
        } else {
            $resultado['nombre'] = $ultimo;
        }
    } else {
        $resultado['nombre'] = $texto;
    }

    return $resultado;
}

/* =========================================================
   8) CONFIGURACIÓN DE PAGINACIÓN
   ========================================================= */
$page = max(1, (int)($_GET['page'] ?? 1));

$perPage = (int)($_GET['per_page'] ?? 50);
$permitidosPerPage = [50, 100, 200];

if (!in_array($perPage, $permitidosPerPage, true)) {
    $perPage = 50;
}

$offset = ($page - 1) * $perPage;
$totalRows = 0;
$totalPages = 1;

/* =========================================================
   9) CONSULTAS SEGÚN ROL
   ========================================================= */
if ($miRol === 'super_admin') {

    /* =====================================================
       9.1) CONTAR TOTAL DE USUARIOS DEL PAÍS
       ===================================================== */
    $sqlCount = "
        SELECT COUNT(*) AS total
        FROM usuarios u
        WHERE UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?
    ";

    $stmtCount = $conn->prepare($sqlCount);

    if (!$stmtCount) {
        echo '<div class="alert alert-danger">Error preparando conteo: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmtCount->bind_param("s", $miPais);
    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $stmtCount->close();

    $totalRows = (int)($rowCount['total'] ?? 0);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }

    /* =====================================================
       9.2) CONSULTA PRINCIPAL PAGINADA
       ===================================================== */
    $sql = "
        SELECT
            u.id,
            u.usuario,
            u.rol,
            u.estado,
            UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) AS pais_code,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.zona IS NOT NULL AND TRIM(ut.zona) <> ''
                    THEN ut.zona
                    ELSE NULL
                END
                ORDER BY ut.zona
                SEPARATOR '||'
            ) AS zonas,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.codalmacen IS NOT NULL AND TRIM(ut.codalmacen) <> ''
                    THEN CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))), ' / ',
                        COALESCE(ut.base_datos, ''), ' / ',
                        COALESCE(ut.zona, ''), ' / ',
                        COALESCE(ut.codalmacen, ''), ' - ',
                        COALESCE(ut.nombrealmacen, '')
                    )
                    ELSE NULL
                END
                ORDER BY ut.pais, ut.base_datos, ut.zona, ut.codalmacen
                SEPARATOR '||'
            ) AS tiendas

        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        WHERE UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?

        GROUP BY u.id, u.usuario, u.rol, u.estado, u.pais_code
        ORDER BY u.id DESC
        LIMIT ?, ?
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo '<div class="alert alert-danger">Error preparando consulta: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmt->bind_param("sii", $miPais, $offset, $perPage);
    $stmt->execute();
    $res = $stmt->get_result();

} else {

    /* =====================================================
       9.3) CONTAR TOTAL DE USUARIOS PARA ADMIN_ZONA
       ===================================================== */
    $sqlCount = "
        SELECT COUNT(DISTINCT u.id) AS total
        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        WHERE
            u.id = ?
            OR (
                u.rol = 'tienda'
                AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?
                AND CONCAT(
                    UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))),
                    '-',
                    TRIM(ut.codalmacen)
                ) IN (
                    SELECT CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(pais, ''), 'HN'))),
                        '-',
                        TRIM(codalmacen)
                    )
                    FROM usuario_tienda
                    WHERE usuario_id = ?
                )
            )
    ";

    $stmtCount = $conn->prepare($sqlCount);

    if (!$stmtCount) {
        echo '<div class="alert alert-danger">Error preparando conteo: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmtCount->bind_param("isi", $miId, $miPais, $miId);
    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $stmtCount->close();

    $totalRows = (int)($rowCount['total'] ?? 0);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }

    /* =====================================================
       9.4) CONSULTA PRINCIPAL PAGINADA PARA ADMIN_ZONA
       ===================================================== */
    $sql = "
        SELECT
            u.id,
            u.usuario,
            u.rol,
            u.estado,
            UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) AS pais_code,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.zona IS NOT NULL AND TRIM(ut.zona) <> ''
                    THEN ut.zona
                    ELSE NULL
                END
                ORDER BY ut.zona
                SEPARATOR '||'
            ) AS zonas,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.codalmacen IS NOT NULL AND TRIM(ut.codalmacen) <> ''
                    THEN CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))), ' / ',
                        COALESCE(ut.base_datos, ''), ' / ',
                        COALESCE(ut.zona, ''), ' / ',
                        COALESCE(ut.codalmacen, ''), ' - ',
                        COALESCE(ut.nombrealmacen, '')
                    )
                    ELSE NULL
                END
                ORDER BY ut.pais, ut.base_datos, ut.zona, ut.codalmacen
                SEPARATOR '||'
            ) AS tiendas

        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        WHERE
            u.id = ?
            OR (
                u.rol = 'tienda'
                AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?
                AND CONCAT(
                    UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))),
                    '-',
                    TRIM(ut.codalmacen)
                ) IN (
                    SELECT CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(pais, ''), 'HN'))),
                        '-',
                        TRIM(codalmacen)
                    )
                    FROM usuario_tienda
                    WHERE usuario_id = ?
                )
            )

        GROUP BY u.id, u.usuario, u.rol, u.estado, u.pais_code
        ORDER BY u.id DESC
        LIMIT ?, ?
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo '<div class="alert alert-danger">Error preparando consulta: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmt->bind_param("isiii", $miId, $miPais, $miId, $offset, $perPage);
    $stmt->execute();
    $res = $stmt->get_result();
}
?>

<style>
.table-usuarios th:nth-child(6),
.table-usuarios td:nth-child(6){
    min-width:170px;
}

.table-usuarios th:nth-child(7),
.table-usuarios td:nth-child(7){
    min-width:280px;
}

.tienda-chip{
    padding:8px 10px;
}

.tienda-chip-nombre{
    font-size:.95rem;
}

.tienda-chip-meta{
    font-size:.78rem;
}

.acciones-usuarios{
    justify-content:center;
}

.control-wrap{
    background:transparent;
    border:1px solid #e2e8f0;
    border-radius:28px;
}

.hero-card{
    background:#fff;
    border:1px solid #e2e8f0;
    border-radius:24px;
    padding:24px;
    box-shadow:0 10px 30px rgba(15,23,42,.05);
    margin-bottom:18px;
}

.hero-title{
    margin:0;
    font-size:2rem;
    font-weight:800;
    color:#0f172a;
}

.hero-sub{
    margin:6px 0 0;
    color:#64748b;
    font-size:1.05rem;
}

.btn-main{
    background:linear-gradient(135deg,#4f46e5,#6366f1);
    color:#fff;
    border:none;
    border-radius:14px;
    padding:12px 18px;
    font-weight:700;
    cursor:pointer;
}

.btn-main:hover{
    filter:brightness(.96);
}

.list-card{
    background:#fff;
    border:1px solid #e2e8f0;
    border-radius:24px;
    padding:18px;
    min-height:220px;
    box-shadow:0 10px 30px rgba(15,23,42,.04);
}

.list-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:14px;
    padding-bottom:12px;
    border-bottom:1px solid #e2e8f0;
}

.list-head h4{
    margin:0;
    font-size:1.2rem;
    font-weight:800;
    color:#0f172a;
}

.table-wrap{
    overflow:auto;
}

.table-usuarios{
    width:100%;
    border-collapse:separate;
    border-spacing:0 10px;
}

.table-usuarios thead th{
    background:#eef2ff;
    color:#1e293b;
    padding:12px 14px;
    font-size:.92rem;
    font-weight:800;
    border:none;
    white-space:nowrap;
}

.table-usuarios thead th:first-child{
    border-radius:14px 0 0 14px;
}

.table-usuarios thead th:last-child{
    border-radius:0 14px 14px 0;
}

.table-usuarios tbody tr{
    background:#fff;
    box-shadow:0 6px 18px rgba(15,23,42,.05);
}

.table-usuarios tbody td{
    padding:14px;
    border-top:1px solid #edf2f7;
    border-bottom:1px solid #edf2f7;
    vertical-align:top;
}

.table-usuarios tbody td:first-child{
    border-left:1px solid #edf2f7;
    border-radius:14px 0 0 14px;
}

.table-usuarios tbody td:last-child{
    border-right:1px solid #edf2f7;
    border-radius:0 14px 14px 0;
}

.estado-badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:.82rem;
    font-weight:700;
}

.estado-activo{
    background:#dcfce7;
    color:#166534;
}

.estado-bloqueado{
    background:#fee2e2;
    color:#991b1b;
}

.pais-badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:.82rem;
    font-weight:700;
    background:#e0ecff;
    color:#1d4ed8;
}

.acciones-usuarios{
    display:flex;
    align-items:center;
    gap:10px;
}

.btn-icon{
    width:40px;
    height:40px;
    border:none;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:18px;
    cursor:pointer;
}

.btn-icon.editar{
    background:#6366f1;
    color:#fff;
}

.btn-icon.bloquear{
    background:#fee2e2;
    color:#b91c1c;
}

.btn-icon.activar{
    background:#dcfce7;
    color:#166534;
}

.zonas-lista{
    display:flex;
    flex-wrap:wrap;
    gap:6px;
}

.zona-chip{
    display:inline-flex;
    align-items:center;
    padding:5px 10px;
    border-radius:999px;
    background:#f1f5f9;
    color:#475569;
    font-size:.78rem;
    font-weight:700;
    line-height:1.2;
}

.tiendas-lista{
    display:flex;
    flex-direction:column;
    gap:10px;
    min-width:280px;
}

.tienda-chip{
    display:flex;
    align-items:flex-start;
    gap:10px;
    padding:10px 12px;
    border:1px solid #e2e8f0;
    border-radius:14px;
    background:#f8fafc;
}

.tienda-chip-codigo{
    min-width:42px;
    padding:4px 8px;
    border-radius:999px;
    background:#dbeafe;
    color:#1d4ed8;
    text-align:center;
    font-size:.78rem;
    font-weight:800;
    line-height:1.2;
}

.tienda-chip-info{
    min-width:0;
    flex:1;
}

.tienda-chip-nombre{
    color:#0f172a;
    font-weight:700;
    line-height:1.3;
    word-break:break-word;
}

.tienda-chip-meta{
    margin-top:4px;
    color:#64748b;
    font-size:.82rem;
    line-height:1.35;
    word-break:break-word;
}

.badge-acceso-total{
    display:inline-flex;
    align-items:center;
    padding:7px 12px;
    border-radius:999px;
    background:#dcfce7;
    color:#166534;
    font-size:.84rem;
    font-weight:800;
}

#modalCrearUsuario .modal-dialog,
#modalEditarUsuario .modal-dialog{
    max-width:1200px !important;
    width:95vw;
    margin:1rem auto;
}

#modalCrearUsuario .modal-content,
#modalEditarUsuario .modal-content{
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 25px 60px rgba(0,0,0,.15);
    border:none;
}

#modalCrearUsuario .modal-header,
#modalEditarUsuario .modal-header{
    padding:20px 24px;
    border-bottom:1px solid #e2e8f0;
    background:#fff;
}

#modalCrearUsuario .modal-body,
#modalEditarUsuario .modal-body{
    padding:24px;
    background:transparent;
    overflow-x:hidden !important;
    overflow-y:auto;
    max-height:calc(100vh - 220px);
    scroll-behavior:smooth;
}

#modalCrearUsuario .modal-footer,
#modalEditarUsuario .modal-footer{
    border-top:1px solid #e2e8f0;
    background:#fff;
    padding:18px 24px;
}

.form-label{
    font-weight:700;
    color:#0f172a;
}

.form-control,
.form-select{
    border:1px solid #dbe2ea;
    border-radius:14px;
    min-height:46px;
}

.form-control:focus,
.form-select:focus{
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.10);
}

.store-base-box{
    background:#fff;
    border:1px solid #dbe2ea;
    border-radius:18px;
    padding:16px;
    overflow:hidden;
}

.store-base-title{
    font-weight:800;
    font-size:1rem;
    margin-bottom:12px;
    color:#1e293b;
}

.store-zone-title{
    font-size:.95rem;
    font-weight:700;
    color:#475569;
    margin-bottom:10px;
}

#modalCrearUsuario .store-grid,
#modalEditarUsuario .store-grid{
    display:grid !important;
    grid-template-columns:repeat(3, minmax(0, 1fr)) !important;
    gap:12px !important;
    width:100% !important;
    margin:0 !important;
}

#modalCrearUsuario .store-item,
#modalEditarUsuario .store-item{
    width:auto !important;
    max-width:none !important;
    min-width:0 !important;
    margin:0 !important;
    padding:0 !important;
    display:block !important;
}

.store-card{
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:16px;
    padding:14px;
    cursor:pointer;
    min-height:92px;
    display:flex;
    align-items:flex-start;
    gap:10px;
    width:100% !important;
    height:100% !important;
    box-sizing:border-box !important;
}

.store-card input{
    margin-top:4px;
    flex-shrink:0;
}

.store-text{
    min-width:0;
    flex:1;
}

.store-name,
.store-meta{
    display:block;
    line-height:1.45;
    word-break:break-word;
    overflow-wrap:anywhere;
}

.store-name{
    color:#0f172a;
    font-weight:700;
}

.store-meta{
    color:#64748b;
    margin-top:4px;
    white-space:normal;
}

.store-card strong{
    font-weight:800;
    color:#0f172a;
}

.paginacion-wrap{
    margin-top:18px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:12px;
    flex-wrap:wrap;
}

.paginacion-info{
    color:#64748b;
    font-size:.92rem;
    font-weight:600;
}

.paginacion-controles{
    display:flex;
    align-items:center;
    gap:8px;
    flex-wrap:wrap;
}

.paginacion-btn{
    border:1px solid #dbe2ea;
    background:#fff;
    color:#0f172a;
    border-radius:12px;
    padding:8px 12px;
    font-weight:700;
    font-size:.9rem;
    text-decoration:none;
    cursor:pointer;
    transition:.2s ease;
}

.paginacion-btn:hover{
    background:#f8fafc;
    border-color:#cbd5e1;
}

.paginacion-btn.activa{
    background:#4f46e5;
    color:#fff;
    border-color:#4f46e5;
}

.paginacion-btn.disabled{
    opacity:.45;
    pointer-events:none;
}

.paginacion-select{
    border:1px solid #dbe2ea;
    border-radius:12px;
    min-height:40px;
    padding:6px 10px;
    font-weight:600;
    background:#fff;
}

@media (max-width: 992px){
    #modalCrearUsuario .store-grid,
    #modalEditarUsuario .store-grid{
        grid-template-columns:repeat(2, minmax(0, 1fr)) !important;
    }
}

@media (max-width: 768px){
    #modalCrearUsuario .modal-dialog,
    #modalEditarUsuario .modal-dialog{
        max-width:96vw !important;
        width:96vw;
        margin:.8rem auto;
    }

    #modalCrearUsuario .modal-body,
    #modalEditarUsuario .modal-body{
        padding:16px;
        max-height:calc(100vh - 190px);
    }

    #modalCrearUsuario .modal-footer,
    #modalEditarUsuario .modal-footer{
        padding:14px 16px;
    }

    #modalCrearUsuario .store-grid,
    #modalEditarUsuario .store-grid{
        grid-template-columns:1fr !important;
    }

    .tiendas-lista{
        min-width:220px;
    }
}
</style>

<div class="table-wrap">
    <table class="table-usuarios">
        <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th style="width:180px;">Usuario</th>
                <th style="width:140px;">Rol</th>
                <th style="width:130px;">País</th>
                <th style="width:130px;">Estado</th>
                <th style="width:180px;">Zona</th>
                <th style="width:180px;">Tiendas</th>
                <th style="width:120px;">Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php if (!$res || $res->num_rows === 0): ?>
                <tr>
                    <td colspan="8">
                        <div class="text-center text-muted py-4">No hay usuarios registrados.</div>
                    </td>
                </tr>
            <?php else: ?>

                <?php while ($row = $res->fetch_assoc()): ?>
                    <?php
                    $idUsuarioFila = (int)($row['id'] ?? 0);
                    $rolUsuario = (string)($row['rol'] ?? '');
                    $zonasArray = partir_valores_concat($row['zonas'] ?? '');
                    $tiendasArray = partir_valores_concat($row['tiendas'] ?? '');
                    $puedeGestionar = u_can_manage_user($conn, $miId, $miRol, $idUsuarioFila);
                    ?>

                    <tr>
                        <td><?= $idUsuarioFila ?></td>

                        <td>
                            <strong><?= u_h((string)$row['usuario']) ?></strong>
                        </td>

                        <td><?= u_h($rolUsuario) ?></td>

                        <td>
                            <span class="pais-badge">
                                <?= u_h(nombre_pais_listado((string)($row['pais_code'] ?? ''))) ?>
                            </span>
                        </td>

                        <td>
                            <?php if ((int)$row['estado'] === 1): ?>
                                <span class="estado-badge estado-activo">Activo</span>
                            <?php else: ?>
                                <span class="estado-badge estado-bloqueado">Bloqueado</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($rolUsuario === 'super_admin'): ?>
                                <span class="text-muted">No aplica</span>
                            <?php elseif (empty($zonasArray)): ?>
                                <span class="text-muted">Sin zona asignada</span>
                            <?php else: ?>
                                <div class="zonas-lista">
                                    <?php foreach ($zonasArray as $zona): ?>
                                        <span class="zona-chip"><?= u_h($zona) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($rolUsuario === 'super_admin'): ?>
                                <span class="badge-acceso-total">Acceso total</span>
                            <?php elseif (empty($tiendasArray)): ?>
                                <span class="text-muted">Sin tiendas asignadas</span>
                            <?php else: ?>
                                <div class="tiendas-lista">
                                    <?php foreach ($tiendasArray as $tiendaTexto): ?>
                                        <?php $tienda = parsear_tienda($tiendaTexto); ?>

                                        <div class="tienda-chip">
                                            <?php if ($tienda['codigo'] !== ''): ?>
                                                <div class="tienda-chip-codigo">
                                                    <?= u_h($tienda['codigo']) ?>
                                                </div>
                                            <?php else: ?>
                                                <div class="tienda-chip-codigo">--</div>
                                            <?php endif; ?>

                                            <div class="tienda-chip-info">
                                                <div class="tienda-chip-nombre">
                                                    <?= u_h($tienda['nombre'] !== '' ? $tienda['nombre'] : 'Tienda sin nombre') ?>
                                                </div>

                                                <div class="tienda-chip-meta">
                                                    <?php
                                                    $meta = array_filter([
                                                        $tienda['pais'],
                                                        $tienda['base'],
                                                        $tienda['zona'],
                                                    ], static fn($v) => trim((string)$v) !== '');

                                                    echo !empty($meta)
                                                        ? u_h(implode(' · ', $meta))
                                                        : 'Sin detalle';
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($puedeGestionar): ?>
                                <div class="acciones-usuarios">
                                    <button
                                        type="button"
                                        class="btn-icon editar btn-editar-usuario"
                                        data-id="<?= $idUsuarioFila ?>"
                                        title="Editar usuario"
                                    >
                                        <i class="bi bi-person-check"></i>
                                    </button>

                                    <?php if ($miRol === 'super_admin'): ?>
                                        <button
                                            type="button"
                                            class="btn-icon <?= ((int)$row['estado'] === 1) ? 'bloquear' : 'activar' ?> btn-estado-usuario"
                                            data-id="<?= $idUsuarioFila ?>"
                                            data-estado="<?= (int)$row['estado'] ?>"
                                            title="<?= ((int)$row['estado'] === 1) ? 'Bloquear usuario' : 'Activar usuario' ?>"
                                        >
                                            <?php if ((int)$row['estado'] === 1): ?>
                                                <i class="bi bi-shield-lock"></i>
                                            <?php else: ?>
                                                <i class="bi bi-person-check"></i>
                                            <?php endif; ?>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-muted">Sin acceso</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>

            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$desde = $totalRows > 0 ? ($offset + 1) : 0;
$hasta = min($offset + $perPage, $totalRows);
?>

<div class="paginacion-wrap">
    <div class="paginacion-info">
        Mostrando <?= $desde ?> a <?= $hasta ?> de <?= $totalRows ?> usuarios
    </div>

    <div class="paginacion-controles">
        <label class="me-1 fw-semibold text-muted">Mostrar:</label>

        <select id="usuariosPerPage" class="paginacion-select">
            <?php foreach ($permitidosPerPage as $valor): ?>
                <option value="<?= $valor ?>" <?= $perPage === $valor ? 'selected' : '' ?>>
                    <?= $valor ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button
            type="button"
            class="paginacion-btn <?= $page <= 1 ? 'disabled' : '' ?>"
            data-page="<?= max(1, $page - 1) ?>"
        >
            Anterior
        </button>

        <?php
        $inicio = max(1, $page - 2);
        $fin = min($totalPages, $page + 2);

        for ($i = $inicio; $i <= $fin; $i++):
        ?>
            <button
                type="button"
                class="paginacion-btn <?= $i === $page ? 'activa' : '' ?>"
                data-page="<?= $i ?>"
            >
                <?= $i ?>
            </button>
        <?php endfor; ?>

        <button
            type="button"
            class="paginacion-btn <?= $page >= $totalPages ? 'disabled' : '' ?>"
            data-page="<?= min($totalPages, $page + 1) ?>"
        >
            Siguiente
        </button>
    </div>
</div>

<script>
document.addEventListener('click', async function(e){
    const btn = e.target.closest('.paginacion-btn[data-page]');

    if (!btn || btn.classList.contains('disabled')) {
        return;
    }

    const page = btn.dataset.page || '1';
    const perPageSelect = document.getElementById('usuariosPerPage');
    const perPage = perPageSelect ? perPageSelect.value : '50';

    const contenedor = document.getElementById('listaUsuarios');

    if (!contenedor) {
        return;
    }

    try {
        const r = await fetch(
            '/exhibicion_DT/controlusuarios/listar_usuarios.php?page=' +
            encodeURIComponent(page) +
            '&per_page=' +
            encodeURIComponent(perPage),
            {
                cache: 'no-store'
            }
        );

        const html = await r.text();
        contenedor.innerHTML = html;
    } catch (error) {
        console.error(error);
    }
});

document.addEventListener('change', async function(e){
    if (e.target.id !== 'usuariosPerPage') {
        return;
    }

    const perPage = e.target.value || '50';
    const contenedor = document.getElementById('listaUsuarios');

    if (!contenedor) {
        return;
    }

    try {
        const r = await fetch(
            '/exhibicion_DT/controlusuarios/listar_usuarios.php?page=1&per_page=' +
            encodeURIComponent(perPage),
            {
                cache: 'no-store'
            }
        );

        const html = await r.text();
        contenedor.innerHTML = html;
    } catch (error) {
        console.error(error);
    }
});
</script>