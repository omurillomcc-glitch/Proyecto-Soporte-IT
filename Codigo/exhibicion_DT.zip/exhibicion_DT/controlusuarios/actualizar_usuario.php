<?php
declare(strict_types=1);

/* =========================================================
   1) RESPUESTA EN FORMATO JSON
   ---------------------------------------------------------
   Este archivo responde siempre en JSON porque se usa
   desde fetch/AJAX al actualizar un usuario.
   ========================================================= */
header('Content-Type: application/json; charset=utf-8');

/* =========================================================
   2) INICIAR SESIÓN
   ---------------------------------------------------------
   Esta aplicación usa su propia sesión para no mezclarse
   con otras apps.
   ========================================================= */
session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   3) MOSTRAR ERRORES EN DESARROLLO
   ---------------------------------------------------------
   En producción puedes cambiar display_errors a 0.
   ========================================================= */
ini_set('display_errors', '1');
error_reporting(E_ALL);

/* =========================================================
   4) CARGAR ARCHIVOS NECESARIOS
   ---------------------------------------------------------
   db.php                -> conexión MySQL
   conexion_sqlsrv.php   -> conexión SQL Server
   auth.php              -> validación de acceso/login
   helpers_usuarios.php  -> funciones auxiliares
   auditoria_helper.php  -> registrar auditoría
   ========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';

/* =========================================================
   5) CONVERTIR CÓDIGO DE PAÍS A REGIÓN PARA AUDITORÍA
   ========================================================= */
function aud_region_label(string $code): string
{
    return match (strtoupper(trim($code))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($code)),
    };
}

/* =========================================================
   6) FUNCIÓN PARA RESPONDER JSON Y SALIR
   ========================================================= */
function json_out(bool $ok, string $msg, array $extra = []): void
{
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/* =========================================================
   7) VALIDAR TEXTO DEL USUARIO
   ---------------------------------------------------------
   Reglas:
   - obligatorio
   - máximo 30 caracteres
   - solo letras
   ========================================================= */
function validar_usuario_txt(string $usuario): array
{
    $usuario = trim($usuario);

    if ($usuario === '') {
        return [false, 'El usuario es obligatorio.'];
    }

    if (mb_strlen($usuario, 'UTF-8') > 30) {
        return [false, 'El usuario no puede tener más de 30 caracteres.'];
    }

    if (!preg_match('/^[\p{L}]+$/u', $usuario)) {
        return [false, 'El usuario solo puede contener letras.'];
    }

    return [true, 'OK'];
}

/* =========================================================
   8) VALIDAR CONTRASEÑA
   ---------------------------------------------------------
   Al editar:
   - si viene vacía, se deja la contraseña actual
   - si viene con valor, debe cumplir validaciones
   ========================================================= */
function validar_password_txt(string $password, bool $permitirVacia = false): array
{
    $password = trim($password);

    if ($permitirVacia && $password === '') {
        return [true, 'OK'];
    }

    if ($password === '') {
        return [false, 'La contraseña es obligatoria.'];
    }

    if (mb_strlen($password, 'UTF-8') < 6 || mb_strlen($password, 'UTF-8') > 20) {
        return [false, 'La contraseña debe tener entre 6 y 20 caracteres.'];
    }

    if (!preg_match('/^[A-Za-z0-9.]+$/', $password)) {
        return [false, 'La contraseña solo puede llevar letras, números y punto.'];
    }

    return [true, 'OK'];
}

/* =========================================================
   9) NORMALIZAR CÓDIGO DE PAÍS
   ---------------------------------------------------------
   Convierte:
   - HONDURAS  -> HN
   - NICARAGUA -> NI
   ========================================================= */
function normalizar_pais_code_actualizar(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

/* =========================================================
   10) NORMALIZAR TIENDAS ACTUALES DE BD
   ---------------------------------------------------------
   Las tiendas actuales vienen desde usuario_tienda.
   Esta función las deja con estructura parecida a los tokens.
   ========================================================= */
function normalizar_tienda_actual(array $row): array
{
    $paisCode = normalizar_pais_code_actualizar((string)($row['pais'] ?? ''));

    return [
        'pais'          => $paisCode,
        'pais_code'     => $paisCode,
        'base_datos'    => trim((string)($row['base_datos'] ?? '')),
        'zona'          => trim((string)($row['zona'] ?? '')),
        'codalmacen'    => trim((string)($row['codalmacen'] ?? '')),
        'nombrealmacen' => trim((string)($row['nombrealmacen'] ?? '')),
    ];
}

/* =========================================================
   11) VALIDAR QUE EL USUARIO AUTENTICADO SEA ADMIN
   ---------------------------------------------------------
   Solo administradores pueden editar usuarios.
   ========================================================= */
require_user_admin();
$me = me();

/* =========================================================
   12) DATOS DEL USUARIO ACTUAL LOGUEADO
   ========================================================= */
$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = normalizar_pais_code_actualizar((string)($me['pais_code'] ?? ''));
$miZona = trim((string)($me['zona'] ?? ''));

/* =========================================================
   13) ID DEL USUARIO A EDITAR
   ========================================================= */
$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    json_out(false, 'ID inválido.');
}

/* =========================================================
   14) VALIDAR QUE PUEDA EDITAR ESTE USUARIO
   ---------------------------------------------------------
   super_admin puede más.
   admin_zona solo usuarios dentro de su alcance.
   ========================================================= */
if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    json_out(false, 'No puedes editar este usuario.');
}

/* =========================================================
   15) CARGAR EL USUARIO ACTUAL DESDE BD
   ---------------------------------------------------------
   Esto se hace antes de validar rol/pais/estado porque:
   - admin_zona tiene campos disabled en el modal
   - los campos disabled no siempre viajan por POST
   ========================================================= */
$stmtActual = $conn->prepare("
    SELECT id, usuario, rol, pais_code, estado
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmtActual) {
    json_out(false, 'Error consultando el usuario actual.');
}

$stmtActual->bind_param("i", $id);
$stmtActual->execute();
$usuarioActual = $stmtActual->get_result()->fetch_assoc();
$stmtActual->close();

if (!$usuarioActual) {
    json_out(false, 'Usuario no encontrado.');
}

$usuarioActualNombre = (string)($usuarioActual['usuario'] ?? '');
$rolActual           = (string)($usuarioActual['rol'] ?? '');
$paisCodeActual      = normalizar_pais_code_actualizar((string)($usuarioActual['pais_code'] ?? ''));
$estadoActual        = (int)($usuarioActual['estado'] ?? 1);

/* =========================================================
   16) CARGAR TIENDAS ACTUALES DEL USUARIO
   ---------------------------------------------------------
   Se usan para:
   - comparar tiendas
   - conservar tiendas si admin_zona edita
   - auditoría
   ========================================================= */
$tiendasActuales = [];

$stmtTiendasActuales = $conn->prepare("
    SELECT pais, base_datos, zona, codalmacen, nombrealmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY id ASC
");

if ($stmtTiendasActuales) {
    $stmtTiendasActuales->bind_param("i", $id);
    $stmtTiendasActuales->execute();
    $resTiendasActuales = $stmtTiendasActuales->get_result();

    while ($fila = $resTiendasActuales->fetch_assoc()) {
        $tiendasActuales[] = normalizar_tienda_actual($fila);
    }

    $stmtTiendasActuales->close();
}

/* =========================================================
   17) DATOS RECIBIDOS POR POST
   ---------------------------------------------------------
   Para super_admin usamos lo enviado.
   Para admin_zona, protegemos datos básicos.
   ========================================================= */
$usuario     = u_norm($_POST['usuario'] ?? '');
$password    = u_norm($_POST['password'] ?? '');
$rol         = u_norm($_POST['rol'] ?? '');
$paisCode    = normalizar_pais_code_actualizar((string)($_POST['pais_code'] ?? ''));
$estado      = isset($_POST['estado']) ? (int)$_POST['estado'] : 1;
$postTiendas = $_POST['tiendas'] ?? [];

/* =========================================================
   18) SI ES ADMIN_ZONA, CONSERVAR DATOS ACTUALES
   ---------------------------------------------------------
   El admin_zona solo debe poder cambiar contraseña.
   Como el modal tiene campos disabled, esos datos pueden no venir.
   Por eso los forzamos desde BD.
   ========================================================= */
if ($miRol === 'admin_zona') {
    $usuario  = $usuarioActualNombre;
    $rol      = $rolActual;
    $paisCode = $paisCodeActual;
    $estado   = $estadoActual;
}

/* =========================================================
   19) VALIDAR USUARIO Y CONTRASEÑA
   ========================================================= */
[$okUsuario, $msgUsuario] = validar_usuario_txt($usuario);
if (!$okUsuario) {
    json_out(false, $msgUsuario);
}

[$okPass, $msgPass] = validar_password_txt($password, true);
if (!$okPass) {
    json_out(false, $msgPass);
}

/* =========================================================
   20) VALIDAR ROL Y PAÍS
   ========================================================= */
$rolesValidos = ['super_admin', 'admin_zona', 'tienda'];
if (!in_array($rol, $rolesValidos, true)) {
    json_out(false, 'Rol inválido.');
}

$paisesValidos = ['HN', 'NI'];
if (!in_array($paisCode, $paisesValidos, true)) {
    json_out(false, 'País inválido.');
}

/* =========================================================
   21) RESTRICCIONES POR ROL DEL EDITOR
   ---------------------------------------------------------
   - super_admin puede asignar cualquier rol válido
   - admin_zona solo puede conservar rol actual
   - admin_zona solo puede usuarios de su mismo país
   ========================================================= */
if ($miRol === 'admin_zona' && $rol !== $rolActual) {
    json_out(false, 'Un admin_zona no puede cambiar el rol.');
}

if ($miRol === 'admin_zona' && $paisCode !== $miPais) {
    json_out(false, 'Solo puedes asignar usuarios de tu mismo país.');
}

/* =========================================================
   22) EVITAR CAMBIOS PELIGROSOS SOBRE UNO MISMO
   ---------------------------------------------------------
   Si el usuario se edita a sí mismo:
   - no puede cambiar su propio rol
   - no puede cambiar su propio país
   - no puede bloquearse
   ========================================================= */
if ($id === $miId && $rol !== $rolActual) {
    json_out(false, 'No puedes cambiar tu propio rol.');
}

if ($id === $miId && $paisCode !== $paisCodeActual) {
    json_out(false, 'No puedes cambiar tu propio país.');
}

if ($id === $miId && (int)$estado === 0) {
    json_out(false, 'No puedes bloquearte a ti misma.');
}

/* =========================================================
   23) NORMALIZAR ESTADO
   ========================================================= */
$estado = ($estado === 1) ? 1 : 0;

/* =========================================================
   24) DECODIFICAR TIENDAS RECIBIDAS
   ---------------------------------------------------------
   Convierte tokens en datos reales de tienda.
   También elimina tiendas duplicadas.
   ========================================================= */
$tiendas = [];

if (is_array($postTiendas)) {
    foreach ($postTiendas as $token) {
        $store = u_decode_store_token((string)$token);

        if (!$store || !is_array($store)) {
            continue;
        }

        $storePais = normalizar_pais_code_actualizar((string)($store['pais_code'] ?? $store['pais'] ?? ''));
        $store['pais_code'] = $storePais;

        $tiendas[u_store_key_from_array($store)] = $store;
    }
}

$tiendas = array_values($tiendas);

/* =========================================================
   25) ADMIN_ZONA NO PUEDE MODIFICAR TIENDAS
   ---------------------------------------------------------
   Si no vienen tiendas por estar deshabilitadas o no enviadas,
   se conservan las actuales.
   Si vienen y son diferentes, se bloquea.
   ========================================================= */
if ($miRol === 'admin_zona') {

    if (!empty($tiendas)) {
        $actualKeys = array_map(fn($t) => u_store_key_from_array($t), $tiendasActuales);
        $nuevasKeys = array_map(fn($t) => u_store_key_from_array($t), $tiendas);

        sort($actualKeys);
        sort($nuevasKeys);

        if ($actualKeys !== $nuevasKeys) {
            json_out(false, 'Un admin_zona no puede modificar las tiendas asignadas.');
        }
    }

    $tiendas = $tiendasActuales;
}

/* =========================================================
   26) VALIDACIONES DE TIENDAS SEGÚN EL ROL NUEVO
   ---------------------------------------------------------
   - si no es super_admin, debe tener al menos una tienda
   - si es tienda, debe tener exactamente una tienda
   - si es super_admin, no debe tener tiendas
   ========================================================= */
if ($rol !== 'super_admin' && count($tiendas) === 0) {
    json_out(false, 'Debes asignar al menos una tienda.');
}

if ($rol === 'tienda' && count($tiendas) !== 1) {
    json_out(false, 'El rol tienda solo puede tener una tienda.');
}

if ($rol === 'super_admin' && count($tiendas) > 0) {
    json_out(false, 'El super_admin no necesita tiendas asignadas.');
}

/* =========================================================
   27) VALIDAR QUE LAS TIENDAS SEAN DEL PAÍS SELECCIONADO
   ========================================================= */
foreach ($tiendas as $t) {
    $storePais = normalizar_pais_code_actualizar((string)($t['pais_code'] ?? $t['pais'] ?? ''));

    if ($storePais !== $paisCode) {
        json_out(false, 'Todas las tiendas seleccionadas deben pertenecer al país elegido.');
    }
}

/* =========================================================
   28) VALIDAR QUE LAS TIENDAS EXISTAN EN SQL SERVER
   ========================================================= */
foreach ($tiendas as $t) {
    if (!u_sqlsrv_store_exists($sqlsrv_conn, $t)) {
        json_out(false, 'Una tienda seleccionada no existe o ya no es válida.');
    }
}

/* =========================================================
   29) RESTRICCIONES EXTRA PARA ADMIN_ZONA
   ---------------------------------------------------------
   admin_zona:
   - solo puede conservar tiendas de su país
   - solo puede conservar tiendas de su zona
   - solo puede conservar tiendas que le pertenecen
   ========================================================= */
if ($miRol === 'admin_zona') {
    $mias = u_get_user_store_keys($conn, $miId);

    foreach ($tiendas as $t) {
        $storeKey  = u_store_key_from_array($t);
        $storePais = normalizar_pais_code_actualizar((string)($t['pais_code'] ?? $t['pais'] ?? ''));
        $storeZona = strtoupper(trim((string)($t['zona'] ?? '')));
        $miZonaCmp = strtoupper(trim($miZona));

        if ($storePais !== $miPais) {
            json_out(false, 'Solo puedes conservar tiendas de tu mismo país.');
        }

        if ($miZonaCmp !== '' && $storeZona !== $miZonaCmp) {
            json_out(false, 'Solo puedes conservar tiendas de tu misma zona.');
        }

        if (!isset($mias[$storeKey])) {
            json_out(false, 'Solo puedes conservar tiendas que te pertenecen.');
        }
    }
}

/* =========================================================
   30) VALIDAR QUE NO EXISTA OTRO USUARIO CON EL MISMO NOMBRE
   ========================================================= */
$stmtDup = $conn->prepare("
    SELECT id
    FROM usuarios
    WHERE BINARY usuario = ?
      AND id <> ?
    LIMIT 1
");

if (!$stmtDup) {
    json_out(false, 'Error preparando validación de usuario duplicado.');
}

$stmtDup->bind_param("si", $usuario, $id);

if (!$stmtDup->execute()) {
    $errDup = $stmtDup->error;
    $stmtDup->close();
    json_out(false, 'Error ejecutando validación de usuario duplicado: ' . $errDup);
}

$resDup = $stmtDup->get_result();

if ($resDup && $resDup->num_rows > 0) {
    $stmtDup->close();
    json_out(false, 'Ese usuario ya existe.');
}

$stmtDup->close();

/* =========================================================
   31) VALIDAR QUE LA TIENDA NO PERTENEZCA A OTRO USUARIO
   ---------------------------------------------------------
   Solo aplica para rol tienda.
   ========================================================= */
if ($rol === 'tienda' && count($tiendas) === 1) {

    $t = $tiendas[0];

    $baseDatos  = strtoupper(trim((string)($t['base_datos'] ?? '')));
    $codalmacen = trim((string)($t['codalmacen'] ?? ''));

    $stmtTiendaDup = $conn->prepare("
        SELECT u.id
        FROM usuarios u
        INNER JOIN usuario_tienda ut
            ON ut.usuario_id = u.id
        WHERE u.rol = 'tienda'
          AND u.id <> ?
          AND UPPER(TRIM(ut.base_datos)) = ?
          AND TRIM(ut.codalmacen) = ?
        LIMIT 1
    ");

    if (!$stmtTiendaDup) {
        json_out(false, 'Error preparando validación de tienda duplicada.');
    }

    $stmtTiendaDup->bind_param("iss", $id, $baseDatos, $codalmacen);

    if (!$stmtTiendaDup->execute()) {
        $errTiendaDup = $stmtTiendaDup->error;
        $stmtTiendaDup->close();
        json_out(false, 'Error ejecutando validación de tienda duplicada: ' . $errTiendaDup);
    }

    $resTiendaDup = $stmtTiendaDup->get_result();

    if ($resTiendaDup && $resTiendaDup->num_rows > 0) {
        $stmtTiendaDup->close();
        json_out(false, 'Esta tienda ya pertenece a otro usuario. No puedes asignarla nuevamente.');
    }

    $stmtTiendaDup->close();
}

/* =========================================================
   32) INICIAR TRANSACCIÓN
   ---------------------------------------------------------
   Todo se actualiza como una sola operación.
   Si algo falla, se revierte.
   ========================================================= */
$conn->begin_transaction();

try {

    /* =====================================================
       33) ACTUALIZAR TABLA usuarios
       -----------------------------------------------------
       Si viene contraseña nueva, se actualiza hash.
       Si viene vacía, se conserva la contraseña actual.
       ===================================================== */
    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        if ($hash === false) {
            throw new RuntimeException('No se pudo generar la contraseña segura.');
        }

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET usuario = ?,
                password_hash = ?,
                rol = ?,
                pais_code = ?,
                estado = ?
            WHERE id = ?
        ");

        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la actualización del usuario.');
        }

        $stmt->bind_param("ssssii", $usuario, $hash, $rol, $paisCode, $estado, $id);

    } else {

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET usuario = ?,
                rol = ?,
                pais_code = ?,
                estado = ?
            WHERE id = ?
        ");

        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la actualización del usuario.');
        }

        $stmt->bind_param("sssii", $usuario, $rol, $paisCode, $estado, $id);
    }

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('No se pudo actualizar el usuario: ' . $err);
    }

    $stmt->close();

    /* =====================================================
       34) BORRAR LAS TIENDAS ANTERIORES
       -----------------------------------------------------
       Se limpian para volver a guardar las nuevas.
       ===================================================== */
    $stmtDel = $conn->prepare("
        DELETE FROM usuario_tienda
        WHERE usuario_id = ?
    ");

    if (!$stmtDel) {
        throw new RuntimeException('No se pudo preparar el borrado de tiendas anteriores.');
    }

    $stmtDel->bind_param("i", $id);

    if (!$stmtDel->execute()) {
        $errDel = $stmtDel->error;
        $stmtDel->close();
        throw new RuntimeException('No se pudieron limpiar las tiendas anteriores: ' . $errDel);
    }

    $stmtDel->close();

    /* =====================================================
       35) INSERTAR NUEVAS TIENDAS
       -----------------------------------------------------
       Solo si el rol nuevo NO es super_admin.
       ===================================================== */
    if ($rol !== 'super_admin') {
        $stmtIns = $conn->prepare("
            INSERT INTO usuario_tienda (
                usuario_id,
                pais,
                base_datos,
                zona,
                codalmacen,
                nombrealmacen
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if (!$stmtIns) {
            throw new RuntimeException('No se pudo preparar el guardado de tiendas.');
        }

        foreach ($tiendas as $t) {
            $pais          = normalizar_pais_code_actualizar((string)($t['pais'] ?? $t['pais_code'] ?? ''));
            $base_datos    = trim((string)($t['base_datos'] ?? ''));
            $zona          = trim((string)($t['zona'] ?? ''));
            $codalmacen    = trim((string)($t['codalmacen'] ?? ''));
            $nombrealmacen = trim((string)($t['nombrealmacen'] ?? ''));

            $stmtIns->bind_param(
                "isssss",
                $id,
                $pais,
                $base_datos,
                $zona,
                $codalmacen,
                $nombrealmacen
            );

            if (!$stmtIns->execute()) {
                $errIns = $stmtIns->error;
                $stmtIns->close();
                throw new RuntimeException('No se pudieron guardar las tiendas del usuario: ' . $errIns);
            }
        }

        $stmtIns->close();
    }

    /* =====================================================
       36) CONFIRMAR TRANSACCIÓN
       ===================================================== */
    $conn->commit();

    /* =====================================================
       37) PREPARAR DESCRIPCIÓN DE AUDITORÍA
       ===================================================== */
    $descripcionAuditoria =
        'Se editó el usuario: ' . $usuarioActualNombre . ' -> ' . $usuario .
        ' | Rol: ' . $rolActual . ' -> ' . $rol .
        ' | País: ' . $paisCodeActual . ' -> ' . $paisCode .
        ' | Estado: ' . $estadoActual . ' -> ' . $estado;

    if ($password !== '') {
        $descripcionAuditoria .= ' | Contraseña: actualizada';
    }

    if ($rol === 'tienda' && !empty($tiendas)) {
        $t = $tiendas[0];
        $descripcionAuditoria .= ' | Tienda nueva: ' . (string)($t['nombrealmacen'] ?? '');
    } elseif ($rol === 'super_admin') {
        $descripcionAuditoria .= ' | Sin tiendas asignadas';
    } elseif (!empty($tiendas)) {
        $descripcionAuditoria .= ' | Tiendas asignadas: ' . count($tiendas);
    }

    /* =====================================================
       38) REGISTRAR AUDITORÍA
       ===================================================== */
    $resultado = registrar_auditoria(
        'USUARIOS',
        'USUARIO_EDITADO',
        $descripcionAuditoria,
        aud_region_label($paisCode),
        ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['zona'] ?? '') : '',
        ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['nombrealmacen'] ?? '') : '',
        ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['codalmacen'] ?? '') : ''
    );

    if (!$resultado) {
        error_log(">>> ERROR: auditoría no se insertó");
    }

    /* =====================================================
       39) RESPUESTA EXITOSA
       ===================================================== */
    json_out(true, 'Usuario actualizado correctamente.');

} catch (Throwable $e) {

    /* =====================================================
       40) SI ALGO FALLA, REVERTIR TODO
       ===================================================== */
    $conn->rollback();

    json_out(false, 'No se pudo actualizar el usuario: ' . $e->getMessage());
}