<?php
declare(strict_types=1);

session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

if (!empty($_SESSION['usuario_id'])) {
    $ahora = time();

    if (
        isset($_SESSION['CREATED']) &&
        ($ahora - (int)$_SESSION['CREATED']) > 86400
    ) {
        session_unset();
        session_destroy();

        header('Location: /exhibicion_DT/controlusuarios/login.php?expired=1');
        exit;
    }

    header('Location: /exhibicion_DT/index.php');
    exit;
}

$error = '';

if (isset($_GET['expired'])) {
    $error = 'Tu sesión expiró por seguridad. Inicia sesión nuevamente.';
}

function h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function normalizar_pais(?string $paisCode, ?string $paisTexto): array {
    $code = strtoupper(trim((string)$paisCode));
    $text = trim((string)$paisTexto);

    if ($code === '' && $text !== '') {
        $txt = strtoupper($text);
        if ($txt === 'HONDURAS') {
            $code = 'HN';
        } elseif ($txt === 'NICARAGUA') {
            $code = 'NI';
        }
    }

    if ($text === '' && $code !== '') {
        if ($code === 'HN') {
            $text = 'Honduras';
        } elseif ($code === 'NI') {
            $text = 'Nicaragua';
        }
    }

    return [$code, $text];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario  = trim((string)($_POST['usuario'] ?? ''));
    $password = trim((string)($_POST['password'] ?? ''));

    if ($usuario === '' || $password === '') {
        $error = 'Completa usuario y contraseña.';
    } elseif (!preg_match('/^[\p{L}]{1,30}$/u', $usuario)) {
        $error = 'El usuario solo puede llevar letras y máximo 30 caracteres.';
    } elseif (!preg_match('/^[A-Za-z0-9.]{6,20}$/', $password)) {
        $error = 'La contraseña debe tener entre 6 y 20 caracteres, solo letras, números y punto.';
    } else {

        $stmt = $conn->prepare("
            SELECT
                id,
                usuario,
                password_hash,
                rol,
                estado,
                pais_code,
                zona
            FROM usuarios
            WHERE BINARY usuario = ?
            LIMIT 1
        ");
        if (!$stmt) {
            $error = 'Error al preparar el acceso.';
        } else {

            $stmt->bind_param("s", $usuario);
            $stmt->execute();
            $res = $stmt->get_result();
            $row = $res ? $res->fetch_assoc() : null;
            $stmt->close();

            if (!$row) {
                $error = 'Usuario o contraseña incorrectos.';
            } elseif ((int)$row['estado'] !== 1) {
                $error = 'Tu usuario está bloqueado.';
            } elseif (!password_verify($password, (string)$row['password_hash'])) {
                $error = 'Usuario o contraseña incorrectos.';
            } else {

                $rolUsuario = (string)$row['rol'];
                $paisTienda = '';
                $zonaTienda = '';
                $codalmacen = '';
                $tienda     = '';

                if (in_array($rolUsuario, ['admin_zona', 'tienda'], true)) {

                    $stmtTienda = $conn->prepare("
                        SELECT
                            pais,
                            zona,
                            codalmacen,
                            nombrealmacen
                        FROM usuario_tienda
                        WHERE usuario_id = ?
                        ORDER BY id ASC
                        LIMIT 1
                    ");

                    if ($stmtTienda) {
                        $usuarioId = (int)$row['id'];
                        $stmtTienda->bind_param("i", $usuarioId);
                        $stmtTienda->execute();
                        $resTienda = $stmtTienda->get_result();
                        $store = $resTienda ? $resTienda->fetch_assoc() : null;
                        $stmtTienda->close();

                        if ($store) {
                            $paisTienda = trim((string)$store['pais']);
                            $zonaTienda = trim((string)$store['zona']);
                            $codalmacen = trim((string)$store['codalmacen']);
                            $tienda     = trim((string)$store['nombrealmacen']);
                        }
                    }
                }

                [$paisCode, $paisTexto] = normalizar_pais(
                    (string)$row['pais_code'],
                    $paisTienda
                );

                session_regenerate_id(true);

                $_SESSION['usuario_id'] = (int)$row['id'];
                $_SESSION['usuario']    = (string)$row['usuario'];
                $_SESSION['rol']        = $rolUsuario;
                $_SESSION['estado']     = (int)$row['estado'];
                $_SESSION['pais_code']  = $paisCode;
                $_SESSION['pais']       = $paisTexto;

                $_SESSION['LAST_ACTIVITY'] = time();
                $_SESSION['CREATED'] = time();

                if (in_array($rolUsuario, ['super_admin', 'admin_zona'], true)) {
                    $_SESSION['zona'] = '';
                } elseif ($rolUsuario === 'tienda') {
                    $_SESSION['zona'] = $zonaTienda;
                } else {
                    $_SESSION['zona'] = trim((string)$row['zona']);
                }

                $_SESSION['tienda']     = ($rolUsuario === 'tienda') ? $tienda : '';
                $_SESSION['codalmacen'] = ($rolUsuario === 'tienda') ? $codalmacen : '';

                header('Location: /exhibicion_DT/index.php');
                exit;
            }
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Estandares DT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#002b66">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css?v=<?= time(); ?>">
    <link rel="icon" type="image/png" href="/exhibicion_DT/img/logomcc.png">
</head>
<body>
    <div class="split-viewport">
        <!-- Lado Izquierdo: Branding Grupo MCC -->
        <section class="split-brand-panel">
            <div class="brand-overlay"></div>
            <div class="brand-content">
                <div class="brand-badge-pill">Sitio Oficial</div>
                <h1 class="brand-main-heading">Estandares De Exhibición</h1>
                <p class="brand-description">Aplicación centralizada para el control y seguimiento de exhibiciones.</p>
            </div>
            <div class="brand-copyright">
                © <?= date('Y') ?> Grupo MCC — Todos los derechos reservados.
            </div>
        </section>

        <!-- Lado Derecho: Formulario de Login -->
        <main class="split-form-panel">
            <div class="form-container">
                <header class="form-header">
                    <div class="logo-wrapper">
                        <img src="/exhibicion_DT/img/logodt.png" alt="Grupo MCC" class="mcc-logo">
                    </div>
                    <h2 class="form-title">Bienvenido</h2>
                    <p class="form-subtitle">Ingresa tus credenciales para acceder</p>
                </header>

                <?php if ($error !== ''): ?>
                    <div class="alert alert-error" role="alert">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="8" x2="12" y2="12"/>
                            <line x1="12" y1="16" x2="12.01" y2="16"/>
                        </svg>
                        <span><?= h($error) ?></span>
                    </div>
                <?php endif; ?>

                <form method="post" autocomplete="off" id="formLogin" class="login-fields-form">
                    <div class="field-group">
                        <label for="usuario">Usuario</label>
                        <div class="input-relative">
                            <svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input
                                type="text"
                                id="usuario"
                                name="usuario"
                                placeholder="Tu usuario"
                                maxlength="30"
                                value="<?= h($_POST['usuario'] ?? '') ?>"
                                autocomplete="username"
                                required
                                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')"
                            >
                        </div>
                    </div>

                    <div class="field-group">
                        <label for="password">Contraseña</label>
                        <div class="input-relative">
                            <svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="••••••••"
                                maxlength="20"
                                autocomplete="current-password"
                                required
                                oninput="this.value=this.value.replace(/[^A-Za-z0-9.]/g,'')"
                            >
                            <button type="button" class="eye-button" id="btnTogglePassword" onclick="togglePassword()" aria-label="Mostrar u ocultar contraseña">
                                <svg id="iconEyeOpen" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                                <svg id="iconEyeClosed" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none;">
                                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                                    <line x1="1" y1="1" x2="23" y2="23"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="button-stack">
                        <button class="btn-submit" type="submit">Ingresar</button>
                        <button class="btn-reset" type="reset" id="btnLimpiar">Limpiar</button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
    function togglePassword() {
        const input = document.getElementById('password');
        const eyeOpen = document.getElementById('iconEyeOpen');
        const eyeClosed = document.getElementById('iconEyeClosed');

        if (!input) return;

        const isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';

        if (eyeOpen && eyeClosed) {
            eyeOpen.style.display = isPassword ? 'none' : 'block';
            eyeClosed.style.display = isPassword ? 'block' : 'none';
        }
    }

    document.getElementById('btnLimpiar')?.addEventListener('click', function () {
        setTimeout(() => {
            const usuario = document.getElementById('usuario');
            const password = document.getElementById('password');
            const eyeOpen = document.getElementById('iconEyeOpen');
            const eyeClosed = document.getElementById('iconEyeClosed');

            if (usuario) usuario.value = '';
            if (password) {
                password.value = '';
                password.type = 'password';
            }

            if (eyeOpen && eyeClosed) {
                eyeOpen.style.display = 'block';
                eyeClosed.style.display = 'none';
            }

            usuario?.focus();
        }, 0);
    });
    </script>
</body>
</html>