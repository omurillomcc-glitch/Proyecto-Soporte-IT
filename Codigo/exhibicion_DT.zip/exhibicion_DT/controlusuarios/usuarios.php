<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| 1) INICIAR SESIÓN SI NO ESTÁ INICIADA
|--------------------------------------------------------------------------
| Si ya está iniciada, no intentamos cambiar el nombre.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* =========================================================
   2) CARGAR ARCHIVOS NECESARIOS
   ---------------------------------------------------------
   db.php               -> conexión MySQL
   conexion_sqlsrv.php  -> conexión SQL Server
   auth.php             -> validaciones de acceso/login
   helpers_usuarios.php -> funciones auxiliares de usuarios
   ========================================================= */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';

/* =========================================================
   3) VALIDAR QUE SOLO ADMINISTRADORES ENTREN
   ---------------------------------------------------------
   require_user_admin() valida que el usuario esté logueado
   y que tenga permiso administrativo.
   ========================================================= */
require_user_admin();
$me = me();

/* =========================================================
   4) GUARDAR DATOS DEL USUARIO ACTUAL
   ---------------------------------------------------------
   Se obtienen los datos del usuario autenticado:
   - ID
   - rol
   - país
   ========================================================= */
$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = strtoupper(trim((string)($me['pais_code'] ?? '')));

/* =========================================================
   5) DOBLE VALIDACIÓN DE ROLES
   ---------------------------------------------------------
   Solo pueden entrar:
   - super_admin
   - admin_zona
   Si es otro rol, se bloquea el acceso.
   ========================================================= */
if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}

/* =========================================================
   6) CARGAR TIENDAS DESDE SQL SERVER
   ---------------------------------------------------------
   - Obtiene todas las tiendas desde SQL Server
   - Si el usuario es admin_zona, filtra solo las tiendas
     que ese admin puede manejar
   - Luego agrupa las tiendas por país, base y zona
   ========================================================= */
try {
    $stores = u_get_all_stores_from_sqlsrv($sqlsrv_conn);

    if ($miRol === 'admin_zona') {
        $stores = u_filter_stores_for_admin($conn, $miId, $stores);
    }

    $groupedStores = u_group_stores($stores);
} catch (Throwable $e) {
    echo '<div class="alert alert-danger">No se pudieron cargar las tiendas desde SQL Server.</div>';
    exit;
}

/* =========================================================
   7) DEFINIR ROLES QUE SE PUEDEN CREAR
   ---------------------------------------------------------
   - super_admin puede crear:
     super_admin, admin_zona, tienda
   - admin_zona puede crear:
     admin_zona, tienda
   ========================================================= */
$rolesPermitidos = ($miRol === 'super_admin')
    ? ['super_admin', 'admin_zona', 'tienda']
    : ['tienda'];

/* =========================================================
   8) FUNCIÓN PARA MOSTRAR NOMBRE BONITO DEL PAÍS
   ---------------------------------------------------------
   Convierte:
   HN -> Honduras
   NI -> Nicaragua
   ========================================================= */
function nombre_pais(string $code): string {
    $code = strtoupper(trim($code));
    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => $code,
    };
}

/* =========================================================
   9) FUNCIÓN PARA RENDERIZAR EL BLOQUE DE TIENDAS
   ---------------------------------------------------------
   Esta función crea el HTML de las tiendas agrupadas:
   País -> Base -> Zona -> Tiendas

   Se usa tanto en:
   - modal crear usuario
   - modal editar usuario

   Cada tienda se imprime como checkbox para seleccionarla.
   ========================================================= */
function render_store_blocks(array $groupedStores, string $inputName, string $inputClass): string {
    ob_start();

    /* -----------------------------------------------------
       Si no hay tiendas disponibles, mostrar aviso
       ----------------------------------------------------- */
    if (empty($groupedStores)) {
        echo '<div class="alert alert-warning alert-custom">No hay tiendas disponibles.</div>';
        return ob_get_clean();
    }

    /* -----------------------------------------------------
       Recorrer países
       ----------------------------------------------------- */
    foreach ($groupedStores as $pais => $bases) {
        $paisCode = u_pais_code((string)$pais);

        echo '<div class="mb-4 store-country-group" data-pais="' . u_h($paisCode) . '">';
        echo '  <h6 class="fw-bold text-primary mb-3">' . u_h((string)$pais) . '</h6>';

        /* -------------------------------------------------
           Recorrer bases de datos dentro del país
           ------------------------------------------------- */
        foreach ($bases as $base => $zonas) {
            echo '<div class="store-base-box mb-3">';
            echo '  <div class="store-base-title">Base: ' . u_h((string)$base) . '</div>';

            /* ---------------------------------------------
               Recorrer zonas dentro de la base
               --------------------------------------------- */
            foreach ($zonas as $zona => $items) {
                echo '<div class="mb-3 store-zone-group">';
                echo '  <div class="store-zone-title">Zona: ' . u_h((string)$zona) . '</div>';
                echo '  <div class="store-grid">';

                /* -----------------------------------------
                   Recorrer tiendas dentro de la zona
                   ----------------------------------------- */
                foreach ($items as $t) {
                    $token    = u_store_token($t); // valor único de la tienda
                    $key      = u_store_key_from_array($t); // llave única para editar
                    $paisItem = u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? ''));

                    $codigo   = (string)($t['codalmacen'] ?? '');
                    $nombre   = (string)($t['nombrealmacen'] ?? '');
                    $paisTxt  = (string)($t['pais'] ?? '');
                    $baseTxt  = (string)($t['base_datos'] ?? '');
                    $zonaTxt  = (string)($t['zona'] ?? '');

                    echo '<div class="store-item" data-pais="' . u_h($paisItem) . '">';
                    echo '  <label class="store-card">';
                    echo '      <input
                                    type="checkbox"
                                    name="' . u_h($inputName) . '[]"
                                    value="' . u_h($token) . '"
                                    data-key="' . u_h($key) . '"
                                    data-pais="' . u_h($paisItem) . '"
                                    class="' . u_h($inputClass) . ' store-check"
                                >';
                    echo '      <div class="store-text">';
                    echo '          <span class="store-name"><strong>' . u_h($codigo) . '</strong> - ' . u_h($nombre) . '</span>';
                    echo '          <span class="store-meta">'
                                    . u_h($paisTxt) . ' / '
                                    . u_h($baseTxt) . ' / '
                                    . u_h($zonaTxt) .
                                '</span>';
                    echo '      </div>';
                    echo '  </label>';
                    echo '</div>';
                }

                echo '  </div>';
                echo '</div>';
            }

            echo '</div>';
        }

        echo '</div>';
    }

    return ob_get_clean();
}
?>

<!-- ======================================================
     10) ESTRUCTURA PRINCIPAL DE LA PANTALLA
     ------------------------------------------------------
     Aquí va:
     - cabecera
     - botón agregar usuario
     - listado de usuarios
     ====================================================== -->
<div class="control-wrap">
    <div class="hero-card">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <p class="hero-sub">Crear, editar, bloquear y desbloquear usuarios</p>
            </div>

            <!-- Botón para abrir modal de crear usuario -->
            <button type="button" class="btn btn-main d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#modalCrearUsuario">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus" viewBox="0 0 16 16">
                    <path d="M8 8a3 3 0 1 0-3-3 3 3 0 0 0 3 3z"/>
                    <path fill-rule="evenodd" d="M8 9a5 5 0 0 0-5 5v.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14a5 5 0 0 0-5-5zm3 1v2h2a.5.5 0 0 0 0-1h-2v-1a.5.5 0 0 0-1 0z"/>
                </svg>
                Agregar usuario
            </button>
        </div>
    </div>

    <div class="list-card">
        <div class="list-head">
            <h4>Listado de usuarios</h4>
        </div>

        <!-- Aquí se muestran mensajes globales -->
        <div id="respuesta_global"></div>

        <!-- Aquí se carga listar_usuarios.php -->
        <div id="listaUsuarios">
            <?php include __DIR__ . '/listar_usuarios.php'; ?>
        </div>
    </div>
</div>

<!-- ======================================================
     11) MODAL CREAR USUARIO
     ------------------------------------------------------
     Formulario para crear usuario nuevo
     ====================================================== -->
<div class="modal fade" id="modalCrearUsuario" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-usuario-form">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Agregar usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <!-- Formulario de creación -->
            <form id="formCrearUsuario" novalidate onsubmit="return false;">
                <div class="modal-body">

                    <div class="row g-3">
                        <!-- Usuario -->
                        <div class="col-md-4">
                            <label class="form-label">Usuario</label>
                            <input type="text" name="usuario" class="form-control" maxlength="30" autocomplete="off" spellcheck="false" required oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')">
                            <small class="text-muted">Solo letras. Sin espacios, números ni símbolos.</small>
                        </div>

                        <!-- Contraseña -->
                        <div class="col-md-4">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="password" class="form-control" maxlength="20" autocomplete="new-password" spellcheck="false" required oninput="this.value=this.value.replace(/[^A-Za-z0-9.]/g,'')">
                            <small class="text-muted">Solo letras, números y punto.</small>
                        </div>

                        <!-- Rol -->
                        <div class="col-md-4">
                            <label class="form-label">Rol</label>
                            <select name="rol" id="crear_rol" class="form-select" required>
                                <?php foreach ($rolesPermitidos as $rol): ?>
                                    <option value="<?= u_h($rol) ?>"><?= u_h($rol) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- País -->
                        <div class="col-md-4">
                            <label class="form-label">País</label>
                            <select name="pais_code" id="crear_pais" class="form-select" required>
                                <?php if ($miRol === 'super_admin'): ?>
                                    <option value="">Seleccione</option>
                                    <option value="HN">Honduras</option>
                                    <option value="NI">Nicaragua</option>
                                <?php else: ?>
                                    <option value="<?= u_h($miPais) ?>"><?= u_h(nombre_pais($miPais)) ?></option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <!-- Estado -->
                        <div class="col-md-4">
                            <label class="form-label">Estado</label>
                            <select name="estado" class="form-select">
                                <option value="1">Activo</option>
                                <option value="0">Bloqueado</option>
                            </select>
                        </div>
                    </div>

                    <!-- Mensaje cuando el rol es super_admin -->
                    <div id="mensaje_super_admin_crear" class="alert alert-info mt-4" style="display:none;">
                        <strong>Acceso total:</strong><br>
                        El super administrador tiene acceso total.<br>
                        No es necesario asignar tiendas.
                    </div>

                    <!-- Bloque de tiendas -->
                    <div id="bloque_tiendas_crear" class="mt-4">
                        <h5 class="mb-2">Asignar tiendas</h5>
                        <p class="text-muted mb-3">Tienda = una sola tienda. Admin_zona = varias tiendas.</p>
                        <?= render_store_blocks($groupedStores, 'tiendas', 'check-crear') ?>
                    </div>

                </div>

                <!-- Pie del modal -->
                <div class="modal-footer flex-column align-items-stretch">
                    <div id="respuesta_crear"></div>
                    <div class="d-flex justify-content-end gap-2 w-100">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-primary" id="btnGuardarUsuario">Guardar usuario</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

<!-- ======================================================
     MODAL EDITAR USUARIO (CORREGIDO)
====================================================== -->
<div class="modal fade" id="modalEditarUsuario" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-usuario-form">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Editar usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <?php
                $esAdminZona = ($miRol === 'admin_zona');
            ?>

            <form id="formEditarUsuario" novalidate onsubmit="return false;">
                <div class="modal-body">

                    <input type="hidden" name="id" id="edit_id">

                    <div class="row g-3">

                        <!-- USUARIO -->
                        <div class="col-md-4">
                            <label class="form-label">Usuario</label>
                            <input type="text"
                                   name="usuario"
                                   id="edit_usuario"
                                   class="form-control"
                                   maxlength="30"
                                   autocomplete="off"
                                   spellcheck="false"
                                   required
                                   <?= $esAdminZona ? 'readonly' : '' ?>
                                   onkeydown="<?= $esAdminZona ? 'return false;' : '' ?>"
                                   oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')">
                        </div>

                        <!-- CONTRASEÑA -->
                        <div class="col-md-4">
                            <label class="form-label">Nueva contraseña</label>
                            <input type="password"
                                   name="password"
                                   id="edit_password"
                                   class="form-control"
                                   maxlength="20"
                                   autocomplete="new-password"
                                   spellcheck="false"
                                   oninput="this.value=this.value.replace(/[^A-Za-z0-9.]/g,'')">
                            <small class="text-muted">Déjala vacía para no cambiarla.</small>
                        </div>

                        <!-- ROL -->
                        <div class="col-md-4">
                            <label class="form-label">Rol</label>
                            <select name="rol"
                                    id="edit_rol"
                                    class="form-select"
                                    required
                                    <?= $esAdminZona ? 'disabled' : '' ?>>
                                <?php foreach ($rolesPermitidos as $r): ?>
                                    <option value="<?= u_h($r) ?>"><?= u_h($r) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- PAÍS -->
                        <div class="col-md-4">
                            <label class="form-label">País</label>
                            <select name="pais_code"
                                    id="edit_pais"
                                    class="form-select"
                                    required
                                    <?= $esAdminZona ? 'disabled' : '' ?>>
                                <?php if ($miRol === 'super_admin'): ?>
                                    <option value="HN">Honduras</option>
                                    <option value="NI">Nicaragua</option>
                                <?php else: ?>
                                    <option value="<?= u_h($miPais) ?>">
                                        <?= u_h(nombre_pais($miPais)) ?>
                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <!-- ESTADO -->
                        <div class="col-md-4">
                            <label class="form-label">Estado</label>
                            <select name="estado"
                                    id="edit_estado"
                                    class="form-select"
                                    <?= $esAdminZona ? 'disabled' : '' ?>>
                                <option value="1">Activo</option>
                                <option value="0">Bloqueado</option>
                            </select>
                        </div>

                    </div>

                    <!-- TIENDAS -->
                    <div id="bloque_tiendas_editar" class="mt-4">
                        <h5 class="mb-2">Asignar tiendas</h5>
                        <?= render_store_blocks($groupedStores, 'tiendas', 'check-editar') ?>
                    </div>

                </div>

                <div class="modal-footer flex-column align-items-stretch">
                    <div id="respuesta_editar"></div>
                    <div class="d-flex justify-content-end gap-2 w-100">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-primary" id="btnActualizarUsuario">
                            Guardar cambios
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>
<!-- ======================================================
     13) MODAL CAMBIAR ESTADO
     ------------------------------------------------------
     Sirve para bloquear o desbloquear usuario
     ====================================================== -->
<div class="modal fade" id="modalEstadoUsuario" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cambiar estado</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="estado_id">
                <input type="hidden" id="estado_valor">
                <p id="estado_texto" class="mb-0">¿Deseas continuar?</p>
                <div id="respuesta_estado" class="mt-3"></div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="btnConfirmarEstado">Confirmar</button>
            </div>
        </div>
    </div>
</div>

<script>
/* =========================================================
   14) AL CARGAR EL DOCUMENTO
   ---------------------------------------------------------
   Aquí inicia toda la lógica JS de la pantalla:
   - validaciones
   - abrir/cerrar modales
   - guardar
   - editar
   - bloquear
   - filtrar tiendas
   ========================================================= */
document.addEventListener("DOMContentLoaded", function () {
    const formCrear = document.getElementById('formCrearUsuario');
    const formEditar = document.getElementById('formEditarUsuario');
    const listaUsuarios = document.getElementById('listaUsuarios');

    /* -----------------------------------------------------
       Si falta algún elemento clave o bootstrap no existe,
       detener el script para evitar errores.
       ----------------------------------------------------- */
    if (!formCrear || !formEditar || !listaUsuarios || typeof bootstrap === 'undefined') {
        return;
    }

    /* -----------------------------------------------------
       Mover modales al body para evitar problemas visuales
       con z-index o contenedores internos.
       ----------------------------------------------------- */
    ['modalCrearUsuario', 'modalEditarUsuario', 'modalEstadoUsuario'].forEach(function(id) {
        const modal = document.getElementById(id);
        if (modal && modal.parentNode !== document.body) {
            document.body.appendChild(modal);
        }
    });

    /* -----------------------------------------------------
       Referencias principales del formulario
       ----------------------------------------------------- */
    const crearRol   = document.getElementById('crear_rol');
    const editRol    = document.getElementById('edit_rol');
    const crearPais  = document.getElementById('crear_pais');
    const editPais   = document.getElementById('edit_pais');

    const bloqueCrear  = document.getElementById('bloque_tiendas_crear');
    const bloqueEditar = document.getElementById('bloque_tiendas_editar');

    const mensajeSuperAdminCrear = document.getElementById('mensaje_super_admin_crear');

    const elModalCrear  = document.getElementById('modalCrearUsuario');
    const elModalEditar = document.getElementById('modalEditarUsuario');
    const elModalEstado = document.getElementById('modalEstadoUsuario');

    /* -----------------------------------------------------
       Instancias Bootstrap de modales
       ----------------------------------------------------- */
    const modalCrear  = bootstrap.Modal.getOrCreateInstance(elModalCrear);
    const modalEditar = bootstrap.Modal.getOrCreateInstance(elModalEditar);
    const modalEstado = bootstrap.Modal.getOrCreateInstance(elModalEstado);

    /* =====================================================
       FUNCIONES AUXILIARES
       ===================================================== */

    /* -----------------------------------------------------
       Devuelve todos los elementos según selector
       ----------------------------------------------------- */
    function checks(selector) {
        return document.querySelectorAll(selector);
    }

    /* -----------------------------------------------------
       Valida que el usuario solo tenga letras
       ----------------------------------------------------- */
    function validarUsuarioTexto(valor) {
        return /^[A-Za-zÁÉÍÓÚáéíóúÑñ]+$/.test(valor.trim());
    }

    /* -----------------------------------------------------
       Valida que la contraseña solo tenga letras, números y .
       ----------------------------------------------------- */
    function validarPasswordTexto(valor) {
        return /^[A-Za-z0-9.]+$/.test(valor.trim());
    }

    /* -----------------------------------------------------
       Muestra errores en los contenedores del modal
       ----------------------------------------------------- */
    function mostrarError(contenedor, mensaje) {
        if (!contenedor) return;
        contenedor.innerHTML = `<div class="alert alert-danger alert-custom">${mensaje}</div>`;
    }

    /* -----------------------------------------------------
       Oculta o muestra grupos de tiendas según queden visibles
       tras filtrar por país.
       ----------------------------------------------------- */
    function actualizarVisibilidadGrupos(contenedorId) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor) return;

        contenedor.querySelectorAll('.store-zone-group').forEach(zoneGroup => {
            const itemsZona = Array.from(zoneGroup.querySelectorAll('.store-item'));
            const visiblesZona = itemsZona.filter(item => item.style.display !== 'none');
            zoneGroup.style.display = visiblesZona.length ? '' : 'none';
        });

        contenedor.querySelectorAll('.store-base-box').forEach(baseBox => {
            const itemsBase = Array.from(baseBox.querySelectorAll('.store-item'));
            const visiblesBase = itemsBase.filter(item => item.style.display !== 'none');
            baseBox.style.display = visiblesBase.length ? '' : 'none';
        });

        contenedor.querySelectorAll('.store-country-group').forEach(countryGroup => {
            const itemsPais = Array.from(countryGroup.querySelectorAll('.store-item'));
            const visiblesPais = itemsPais.filter(item => item.style.display !== 'none');
            countryGroup.style.display = visiblesPais.length ? '' : 'none';
        });
    }

    /* -----------------------------------------------------
       Filtra tiendas por país seleccionado
       ----------------------------------------------------- */
    function filtrarTiendasPorPais(selectPais, selectorChecks, contenedorId) {
        if (!selectPais) return;

        const pais = (selectPais.value || '').trim().toUpperCase();

        checks(selectorChecks).forEach(ch => {
            const item = ch.closest('.store-item');
            if (!item) return;

            const paisStore = (ch.dataset.pais || '').trim().toUpperCase();
            const mostrar = (pais === '' || paisStore === pais);

            item.style.display = mostrar ? '' : 'none';

            if (!mostrar) {
                ch.checked = false;
            }
        });

        actualizarVisibilidadGrupos(contenedorId);
    }

    /* -----------------------------------------------------
       Reglas del modal CREAR:
       - super_admin no necesita tiendas
       - tienda solo puede elegir una tienda
       - se filtran tiendas por país
       ----------------------------------------------------- */
    function aplicarReglasCrear() {
        const rol = crearRol ? crearRol.value : '';
        const cks = checks('.check-crear');

        if (rol === 'super_admin') {
            if (bloqueCrear) bloqueCrear.style.display = 'none';
            if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'block';
            cks.forEach(ch => ch.checked = false);
            return;
        }

        if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'none';
        if (bloqueCrear) bloqueCrear.style.display = '';

        filtrarTiendasPorPais(crearPais, '.check-crear', 'bloque_tiendas_crear');

        if (rol === 'tienda') {
            const marcadas = Array.from(checks('.check-crear:checked'));
            if (marcadas.length > 1) {
                marcadas.slice(1).forEach(ch => ch.checked = false);
            }
        }
    }

    /* -----------------------------------------------------
       Reglas del modal EDITAR
       ----------------------------------------------------- */
    function aplicarReglasEditar() {
        const rol = editRol ? editRol.value : '';
        const cks = checks('.check-editar');

        if (rol === 'super_admin') {
            if (bloqueEditar) bloqueEditar.style.display = 'none';
            cks.forEach(ch => ch.checked = false);
            return;
        }

        if (bloqueEditar) bloqueEditar.style.display = '';
        filtrarTiendasPorPais(editPais, '.check-editar', 'bloque_tiendas_editar');

        if (rol === 'tienda') {
            const marcadas = Array.from(checks('.check-editar:checked'));
            if (marcadas.length > 1) {
                marcadas.slice(1).forEach(ch => ch.checked = false);
            }
        }
    }

    /* -----------------------------------------------------
       Limpia formulario de crear usuario
       ----------------------------------------------------- */
    function limpiarFormularioCrear() {
        formCrear.reset();
        checks('.check-crear').forEach(ch => ch.checked = false);

        const respuestaCrear = document.getElementById('respuesta_crear');
        if (respuestaCrear) respuestaCrear.innerHTML = '';

        <?php if ($miRol !== 'super_admin'): ?>
        if (crearPais) crearPais.value = '<?= u_h($miPais) ?>';
        <?php endif; ?>

        if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'none';

        aplicarReglasCrear();

        const body = elModalCrear ? elModalCrear.querySelector('.modal-body') : null;
        if (body) body.scrollTop = 0;
    }

    /* -----------------------------------------------------
       Recargar listado de usuarios vía AJAX
       ----------------------------------------------------- */
    async function cargarUsuarios() {
        try {
            const r = await fetch('/exhibicion_DT/controlusuarios/listar_usuarios.php', { cache: 'no-store' });
            const html = await r.text();
            listaUsuarios.innerHTML = html;
        } catch (e) {
            console.error(e);
        }
    }

    /* =====================================================
       EVENTOS DE CHECKBOX PARA ROL TIENDA
       -----------------------------------------------------
       Si el rol es tienda, solo deja una tienda marcada.
       ===================================================== */
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('check-crear') && crearRol && crearRol.value === 'tienda' && e.target.checked) {
            checks('.check-crear').forEach(ch => {
                if (ch !== e.target) ch.checked = false;
            });
        }

        if (e.target.classList.contains('check-editar') && editRol && editRol.value === 'tienda' && e.target.checked) {
            checks('.check-editar').forEach(ch => {
                if (ch !== e.target) ch.checked = false;
            });
        }
    });

    /* =====================================================
       EVENTOS DE CAMBIO EN ROL Y PAÍS
       ===================================================== */
    if (crearRol) crearRol.addEventListener('change', aplicarReglasCrear);
    if (editRol) editRol.addEventListener('change', aplicarReglasEditar);
    if (crearPais) crearPais.addEventListener('change', aplicarReglasCrear);
    if (editPais) editPais.addEventListener('change', aplicarReglasEditar);

    /* =====================================================
       EVENTOS DEL MODAL CREAR
       ===================================================== */
    if (elModalCrear) {
        elModalCrear.addEventListener('show.bs.modal', limpiarFormularioCrear);
        elModalCrear.addEventListener('shown.bs.modal', function () {
            const body = elModalCrear.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
        elModalCrear.addEventListener('hidden.bs.modal', function () {
            const body = elModalCrear.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
    }

    /* =====================================================
       EVENTOS DEL MODAL EDITAR
       ===================================================== */
    if (elModalEditar) {
        elModalEditar.addEventListener('shown.bs.modal', function () {
            const body = elModalEditar.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
    }

    /* =====================================================
       GUARDAR USUARIO NUEVO
       -----------------------------------------------------
       - valida campos
       - envía por fetch a guardar_usuarios.php
       - recarga listado si guarda bien
       ===================================================== */
    const btnGuardarUsuario = document.getElementById('btnGuardarUsuario');
    if (btnGuardarUsuario) {
        btnGuardarUsuario.addEventListener('click', async function() {
            const respuesta = document.getElementById('respuesta_crear');

            const usuario = formCrear.querySelector('[name="usuario"]').value.trim();
            const password = formCrear.querySelector('[name="password"]').value.trim();
            const paisCode = formCrear.querySelector('[name="pais_code"]').value.trim();
            const rol      = formCrear.querySelector('[name="rol"]').value.trim();

            if (respuesta) respuesta.innerHTML = '';

            if (usuario === '') {
                mostrarError(respuesta, 'El usuario es obligatorio');
                return;
            }

            if (!validarUsuarioTexto(usuario)) {
                mostrarError(respuesta, 'El usuario solo puede contener letras');
                return;
            }

            if (password.length < 6 || password.length > 20) {
                mostrarError(respuesta, 'La contraseña debe tener entre 6 y 20 caracteres');
                return;
            }

            if (!validarPasswordTexto(password)) {
                mostrarError(respuesta, 'La contraseña solo puede llevar letras números y punto');
                return;
            }

            if (paisCode === '') {
                mostrarError(respuesta, 'Debes seleccionar un país');
                return;
            }

            const checksCrearMarcados = Array.from(document.querySelectorAll('.check-crear:checked'));

            if (rol !== 'super_admin' && checksCrearMarcados.length === 0) {
                mostrarError(respuesta, 'Debes seleccionar al menos una tienda');
                return;
            }

            if (rol === 'tienda' && checksCrearMarcados.length > 1) {
                mostrarError(respuesta, 'Un usuario de tienda solo puede tener una tienda asignada');
                return;
            }

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/guardar_usuarios.php', {
                    method: 'POST',
                    body: new FormData(formCrear)
                });

                const text = await r.text();
                let json;

                try {
                    json = JSON.parse(text);
                } catch {
                    mostrarError(respuesta, 'Respuesta inválida del servidor: ' + text);
                    return;
                }

                if (respuesta) {
                    respuesta.innerHTML = `<div class="alert ${json.ok ? 'alert-success' : 'alert-danger'} alert-custom">${json.msg}</div>`;
                }

                if (json.ok) {
                    await cargarUsuarios();

                    setTimeout(() => {
                        modalCrear.hide();
                        limpiarFormularioCrear();
                    }, 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'Error al guardar usuario');
            }
        });
    }

    /* =====================================================
       EVENTOS DE BOTONES DINÁMICOS DEL LISTADO
       -----------------------------------------------------
       - Editar usuario
       - Cambiar estado
       ===================================================== */
    document.addEventListener('click', async function(e) {
        const btnEditar = e.target.closest('.btn-editar-usuario');
        const btnEstado = e.target.closest('.btn-estado-usuario');

        /* -------------------------------------------------
           EDITAR USUARIO
           ------------------------------------------------- */
        if (btnEditar) {
            try {
                const id = btnEditar.dataset.id;

                const r = await fetch('/exhibicion_DT/controlusuarios/obtener_usuario.php?id=' + encodeURIComponent(id));
                const json = await r.json();

                if (!json.ok) {
                    alert(json.msg);
                    return;
                }

                document.getElementById('edit_id').value = json.data.id ?? '';
                document.getElementById('edit_usuario').value = json.data.usuario ?? '';
                document.getElementById('edit_rol').value = json.data.rol ?? '';
                document.getElementById('edit_estado').value = json.data.estado ?? '1';
                document.getElementById('edit_password').value = '';

                if (editPais) {
                    editPais.value = (json.data.pais_code ?? '').toUpperCase();
                }

                checks('.check-editar').forEach(ch => ch.checked = false);

                aplicarReglasEditar();

                (json.data.store_keys || []).forEach(key => {
                    const el = document.querySelector('.check-editar[data-key="' + CSS.escape(key) + '"]');
                    if (el && el.closest('.store-item') && el.closest('.store-item').style.display !== 'none') {
                        el.checked = true;
                    }
                });

                modalEditar.show();

            } catch (e) {
                console.error(e);
                alert('No se pudo cargar el usuario');
            }
        }

        /* -------------------------------------------------
           CAMBIAR ESTADO
           ------------------------------------------------- */
        if (btnEstado) {
            const id = btnEstado.dataset.id;
            const estado = btnEstado.dataset.estado === '1' ? '0' : '1';

            document.getElementById('estado_id').value = id;
            document.getElementById('estado_valor').value = estado;

            document.getElementById('estado_texto').textContent =
                estado === '0'
                    ? '¿Deseas bloquear este usuario?'
                    : '¿Deseas desbloquear este usuario?';

            document.getElementById('respuesta_estado').innerHTML = '';
            modalEstado.show();
        }
    });

    /* =====================================================
       ACTUALIZAR USUARIO EXISTENTE
       ===================================================== */
    const btnActualizarUsuario = document.getElementById('btnActualizarUsuario');
    if (btnActualizarUsuario) {
        btnActualizarUsuario.addEventListener('click', async function() {
            const respuesta = document.getElementById('respuesta_editar');
            const paisCode  = formEditar.querySelector('[name="pais_code"]').value.trim();
            const rol       = formEditar.querySelector('[name="rol"]').value.trim();
            const checksEditarMarcados = Array.from(document.querySelectorAll('.check-editar:checked'));

            if (respuesta) respuesta.innerHTML = '';

            if (paisCode === '') {
                mostrarError(respuesta, 'Debes seleccionar un país');
                return;
            }

            if (rol !== 'super_admin' && checksEditarMarcados.length === 0) {
                mostrarError(respuesta, 'Debes seleccionar al menos una tienda');
                return;
            }

            if (rol === 'tienda' && checksEditarMarcados.length > 1) {
                mostrarError(respuesta, 'Un usuario de tienda solo puede tener una tienda asignada');
                return;
            }

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/actualizar_usuario.php', {
                    method: 'POST',
                    body: new FormData(formEditar)
                });

                const json = await r.json();

                if (respuesta) {
                    respuesta.innerHTML = `<div class="alert ${json.ok ? 'alert-success' : 'alert-danger'} alert-custom">${json.msg}</div>`;
                }

                if (json.ok) {
                    await cargarUsuarios();
                    setTimeout(() => modalEditar.hide(), 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'Error al actualizar');
            }
        });
    }

    /* =====================================================
       CONFIRMAR CAMBIO DE ESTADO
       -----------------------------------------------------
       Envía al backend:
       - id del usuario
       - nuevo estado
       ===================================================== */
    const btnConfirmarEstado = document.getElementById('btnConfirmarEstado');
    if (btnConfirmarEstado) {
        btnConfirmarEstado.addEventListener('click', async function() {
            const id = document.getElementById('estado_id').value;
            const estado = document.getElementById('estado_valor').value;
            const respuesta = document.getElementById('respuesta_estado');

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/cambiar_estado_usuario.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({id, estado})
                });

                const json = await r.json();

                if (respuesta) {
                    respuesta.innerHTML = `<div class="alert ${json.ok ? 'alert-success' : 'alert-danger'} alert-custom">${json.msg}</div>`;
                }

                if (json.ok) {
                    await cargarUsuarios();
                    setTimeout(() => modalEstado.hide(), 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'No se pudo cambiar estado');
            }
        });
    }

    /* =====================================================
       DEJAR PAÍS FIJO CUANDO NO ES super_admin
       ===================================================== */
    <?php if ($miRol !== 'super_admin'): ?>
    if (crearPais) crearPais.value = '<?= u_h($miPais) ?>';
    if (editPais) editPais.value = '<?= u_h($miPais) ?>';
    <?php endif; ?>

    /* =====================================================
       APLICAR REGLAS AL CARGAR LA PANTALLA
       ===================================================== */
    aplicarReglasCrear();
    aplicarReglasEditar();
});
</script>