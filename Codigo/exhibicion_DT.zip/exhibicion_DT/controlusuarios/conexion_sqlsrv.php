<?php
declare(strict_types=1);

$serverName = "10.0.1.157";

$connectionOptions = [
    "UID" => "DT-Csa",
    "PWD" => "dt.2026#",
    "CharacterSet" => "UTF-8",
    "TrustServerCertificate" => true
];

$sqlsrv_conn = sqlsrv_connect($serverName, $connectionOptions);

if ($sqlsrv_conn === false) {
    die('Error al conectar con SQL Server.');
}