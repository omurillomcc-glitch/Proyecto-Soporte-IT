<?php
declare(strict_types=1);


ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


global $sqlsrv_conn, $sqlsrv_conn_exhibicion, $conexion_sqlsrv, $conn_sqlsrv, $sqlsrvConn;
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/conexion_sqlsrv.php';


if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
    foreach (['sqlsrv_conn_exhibicion', 'conexion_sqlsrv', 'conn_sqlsrv', 'sqlsrvConn'] as $nombreConexion) {
        if (isset($$nombreConexion) && $$nombreConexion !== false) {
            $sqlsrv_conn = $$nombreConexion;
            break;
        }
    }
}

if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
    echo '<div class="alert alert-danger" role="alert">No se encontró una conexión activa a SQL Server. Revise controlusuarios/conexion_sqlsrv.php y el nombre de su variable de conexión.</div>';
    return;
}


require_module_access('modulo3');


function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function clean_codalmacen(string $v): string {
    $v = preg_replace('/\D/', '', trim($v));
    return $v === '' ? '' : str_pad($v, 2, '0', STR_PAD_LEFT);
}

function clean_text(string $v): string {
    return trim($v);
}

function normalizar_pais(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS' => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default => $pais,
    };
}


function excel_filter_values(string $value): array
{
    $value = trim($value);

    if ($value === '') {
        return [];
    }

    return array_values(array_filter(
        array_map('trim', explode('||', $value)),
        fn($v) => $v !== ''
    ));
}

// Aplicar filtros de columnas con parámetros SQL.
function add_excel_sql_filter(
    string &$sql,
    array &$params,
    string $campoSql,
    string $value
): void {
    $value = trim($value);

    if ($value === '') {
        return;
    }


    if (str_starts_with($value, '_LIKE_')) {
        $texto = trim(str_replace('_LIKE_', '', $value));

        if ($texto !== '') {
            $sql .= "
                AND LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
                    COLLATE Modern_Spanish_CI_AS
                    LIKE ?
                    COLLATE Modern_Spanish_CI_AS
            ";

            $params[] = '%' . $texto . '%';
        }

        return;
    }


    $valores = excel_filter_values($value);

    if (empty($valores)) {
        return;
    }

    $partes = [];

    foreach ($valores as $v) {
        $partes[] = "
            LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))
            COLLATE Modern_Spanish_CI_AS
            =
            ?
            COLLATE Modern_Spanish_CI_AS
        ";

        $params[] = $v;
    }

    $sql .= " AND (" . implode(" OR ", $partes) . ")";
}


$me = me();

$rol       = trim((string)($me['rol'] ?? ($_SESSION['rol'] ?? '')));
$usuarioId = (int)($me['id'] ?? ($_SESSION['usuario_id'] ?? 0));
$paisCode  = normalizar_pais((string)($me['pais_code'] ?? ($_SESSION['pais_code'] ?? 'HN')));


if ($paisCode === 'NI') {
    $dbOrigen = 'ACANICARAGUA2';
    $region   = 'NICARAGUA';
} else {
    $dbOrigen = 'DETODO';
    $region   = 'HONDURAS';
}


// Obtener las tiendas asignadas al usuario.
function tiendas_usuario(mysqli $conn, int $usuarioId, string $paisCode, $sqlsrv_conn, string $dbOrigen): array
{
    if ($usuarioId <= 0) {
        return [];
    }

    $sql = "
        SELECT DISTINCT codalmacen, pais
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND COALESCE(TRIM(codalmacen), '') <> ''
        ORDER BY codalmacen
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();

    $res = $stmt->get_result();
    $stores = [];

    while ($row = $res->fetch_assoc()) {
        $cod  = clean_codalmacen((string)($row['codalmacen'] ?? ''));
        $pais = normalizar_pais((string)($row['pais'] ?? ''));

        if ($cod === '') {
            continue;
        }

        if ($pais !== '' && $paisCode !== '' && $pais !== $paisCode) {
            continue;
        }

        $nombre = $cod;

        $sqlNombre = "
            SELECT TOP 1
                LTRIM(RTRIM(ISNULL(NOMBREALMACEN, ''))) AS NOMBRE
            FROM {$dbOrigen}.dbo.ALMACEN
            WHERE LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) = ?
        ";

        $stmtNombre = sqlsrv_query($sqlsrv_conn, $sqlNombre, [$cod]);

        if ($stmtNombre !== false) {
            $rowNombre = sqlsrv_fetch_array($stmtNombre, SQLSRV_FETCH_ASSOC);

            if ($rowNombre && !empty($rowNombre['NOMBRE'])) {
                $nombre = (string)$rowNombre['NOMBRE'];
            }

            sqlsrv_free_stmt($stmtNombre);
        }

        $stores[] = [
            'codigo' => $cod,
            'nombre' => $nombre
        ];
    }

    $stmt->close();

    usort($stores, fn($a, $b) => strcmp($a['codigo'], $b['codigo']));

    return $stores;
}


// Consultar los almacenes disponibles para administración.
function todas_tiendas_sqlsrv($sqlsrv_conn, string $dbOrigen): array
{
    if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
        return [];
    }

    $sql = "
        SELECT
            LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) AS CODIGO,
            LTRIM(RTRIM(ISNULL(NOMBREALMACEN, ''))) AS NOMBRE
        FROM {$dbOrigen}.dbo.ALMACEN
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(CONVERT(VARCHAR(20), CODALMACEN))) NOT LIKE '%M'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%ACA JOE%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%ACAJOE%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%MERMA%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%MERMAS%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%DESECHO%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%DESECHOS%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%SUMINISTRO%'
          AND UPPER(ISNULL(NOMBREALMACEN, '')) NOT LIKE '%SUMINISTROS%'
        ORDER BY CODALMACEN
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql);

    if ($stmt === false) {
        return [];
    }

    $tiendas = [];

    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $cod = clean_codalmacen((string)($row['CODIGO'] ?? ''));

        if ($cod === '') {
            continue;
        }

        $nombre = trim((string)($row['NOMBRE'] ?? ''));

        $tiendas[] = [
            'codigo' => $cod,
            'nombre' => $nombre !== '' ? $nombre : $cod
        ];
    }

    sqlsrv_free_stmt($stmt);

    return $tiendas;
}


function tienda_local_info(mysqli $conn, string $paisCode, string $codalmacen): array
{
    $paisCode = normalizar_pais($paisCode);
    $cod      = clean_codalmacen($codalmacen);

    if ($cod === '') {
        return [
            'zona' => '',
            'nombre' => '',
        ];
    }

    $p1 = $paisCode;
    $p2 = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';

    $sql = "
        SELECT
            COALESCE(NULLIF(TRIM(zona), ''), '') AS zona,
            COALESCE(NULLIF(TRIM(nombrealmacen), ''), '') AS nombrealmacen
        FROM usuario_tienda
        WHERE UPPER(TRIM(pais)) IN (?, ?)
          AND LPAD(TRIM(codalmacen), 2, '0') = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [
            'zona' => '',
            'nombre' => '',
        ];
    }

    $stmt->bind_param('sss', $p1, $p2, $cod);
    $stmt->execute();

    $res = $stmt->get_result();
    $row = $res ? $res->fetch_assoc() : null;
    $stmt->close();

    return [
        'zona' => strtoupper(trim((string)($row['zona'] ?? ''))),
        'nombre' => trim((string)($row['nombrealmacen'] ?? '')),
    ];
}


$tiendasPermitidas = [];
$tiendasSuperAdmin = [];

if ($rol === 'super_admin') {
    $tiendasSuperAdmin = todas_tiendas_sqlsrv($sqlsrv_conn, $dbOrigen);
} else {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        echo '<div class="alert alert-danger">No hay conexión MySQL local.</div>';
        return;
    }

    $tiendasPermitidas = tiendas_usuario(
        $conn,
        $usuarioId,
        $paisCode,
        $sqlsrv_conn,
        $dbOrigen
    );
}


$codalmacen   = clean_codalmacen((string)($_GET['codalmacen'] ?? ''));
$referencia   = clean_text((string)($_GET['referencia'] ?? ''));
$codbarras    = clean_text((string)($_GET['codbarras'] ?? ''));
$codarticulo  = clean_text((string)($_GET['codarticulo'] ?? ''));
$plu          = clean_text((string)($_GET['plu'] ?? ''));
$descripcion  = clean_text((string)($_GET['descripcion'] ?? ''));
$departamento = clean_text((string)($_GET['departamento'] ?? ''));
$seccion      = clean_text((string)($_GET['seccion'] ?? ''));
$familia      = clean_text((string)($_GET['familia'] ?? ''));
$exhibicion   = clean_text((string)($_GET['exhibicion'] ?? ''));
$uxc          = clean_text((string)($_GET['uxc'] ?? ''));


$infoTiendaSeleccionada = [
    'zona' => '',
    'nombre' => '',
];

if ($codalmacen !== '' && isset($conn) && $conn instanceof mysqli) {
    $infoTiendaSeleccionada = tienda_local_info($conn, $paisCode, $codalmacen);
}


$page = max(1, (int)($_GET['page'] ?? 1));

$perPage       = 1000;
$limitConsulta = $perPage + 1;
$offset        = ($page - 1) * $perPage;

$haySiguiente = false;


if ($rol !== 'super_admin' && $codalmacen !== '') {
    $codigosPermitidos = array_column($tiendasPermitidas, 'codigo');

    if (!in_array($codalmacen, $codigosPermitidos, true)) {
        $codalmacen = '';
    }
}


$resultados = [];
$error = '';


if ($codalmacen !== '') {
    try {
        if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
            throw new Exception('No hay conexión a SQL Server.');
        }


        $sql = "
            SELECT
                E.REGION COLLATE Modern_Spanish_CI_AS AS REGION,
                E.CODALMACEN COLLATE Modern_Spanish_CI_AS AS CODALMACEN,
                LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, ''))) COLLATE Modern_Spanish_CI_AS AS ALMACEN,
                CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS AS CODARTICULO,
                REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS REFERENCIA,
                REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS CODBARRAS,
                ISNULL(CONVERT(VARCHAR(100), E.PLU), '') COLLATE Modern_Spanish_CI_AS AS PLU,
                REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '') COLLATE Modern_Spanish_CI_AS AS DESCRIPCION,
                ISNULL(D.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS DEPARTAMENTO,
                ISNULL(SC.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS SECCION,
                ISNULL(F.DESCRIPCION, '') COLLATE Modern_Spanish_CI_AS AS FAMILIA,
                CAST(0 AS DECIMAL(18,2)) AS INVENTARIO_TIENDA,
                ISNULL(E.EXHIBICION, 0) AS EXHIBICION,
                CASE
                    WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                    WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                    ELSE 0
                END AS UXC
            FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

            LEFT JOIN {$dbOrigen}.dbo.STOCKS ST
                ON CONVERT(VARCHAR(100), ST.CODALMACEN) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODALMACEN) COLLATE Modern_Spanish_CI_AS
               AND CONVERT(VARCHAR(100), ST.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ARTICULOS A
                ON CONVERT(VARCHAR(100), A.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
                ON CONVERT(VARCHAR(100), CL.CODARTICULO) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODARTICULO) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.ALMACEN ALM
                ON CONVERT(VARCHAR(100), ALM.CODALMACEN) COLLATE Modern_Spanish_CI_AS
                 = CONVERT(VARCHAR(100), E.CODALMACEN) COLLATE Modern_Spanish_CI_AS

            LEFT JOIN {$dbOrigen}.dbo.DEPARTAMENTO D
                ON D.NUMDPTO = A.DPTO

            LEFT JOIN {$dbOrigen}.dbo.SECCIONES SC
                ON SC.NUMDPTO = A.DPTO
               AND SC.NUMSECCION = A.SECCION

            LEFT JOIN {$dbOrigen}.dbo.FAMILIAS F
                ON F.NUMDPTO = A.DPTO
               AND F.NUMSECCION = A.SECCION
               AND F.NUMFAMILIA = A.FAMILIA

            WHERE E.REGION COLLATE Modern_Spanish_CI_AS = ? COLLATE Modern_Spanish_CI_AS
              AND E.CODALMACEN COLLATE Modern_Spanish_CI_AS = ? COLLATE Modern_Spanish_CI_AS
              AND ISNULL(E.EXHIBICION, 0) > 0
              AND ST.CODARTICULO IS NULL
        ";

        $params = [$region, $codalmacen];


        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')", $referencia);
        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')", $codbarras);
        add_excel_sql_filter($sql, $params, "CONVERT(VARCHAR(100), E.CODARTICULO)", $codarticulo);
        add_excel_sql_filter($sql, $params, "ISNULL(CONVERT(VARCHAR(100), E.PLU), '')", $plu);
        add_excel_sql_filter($sql, $params, "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')", $descripcion);
        add_excel_sql_filter($sql, $params, "ISNULL(D.DESCRIPCION, '')", $departamento);
        add_excel_sql_filter($sql, $params, "ISNULL(SC.DESCRIPCION, '')", $seccion);
        add_excel_sql_filter($sql, $params, "ISNULL(F.DESCRIPCION, '')", $familia);
        add_excel_sql_filter($sql, $params, "ISNULL(E.EXHIBICION, 0)", $exhibicion);
        add_excel_sql_filter(
            $sql,
            $params,
            "CASE
                WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                ELSE 0
            END",
            $uxc
        );


        $ordenCampo = strtolower(trim((string)($_GET['orden_campo'] ?? 'codarticulo')));
        $ordenDir   = strtolower(trim((string)($_GET['orden_dir'] ?? 'asc')));


        $columnasOrden = [
            'codarticulo'  => 'TRY_CAST(E.CODARTICULO AS INT)',
            'referencia'   => "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')",
            'codbarras'    => "REPLACE(REPLACE(ISNULL(E.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')",
            'plu'          => "ISNULL(CONVERT(VARCHAR(100), E.PLU), '')",
            'descripcion'  => "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')",
            'departamento' => "ISNULL(D.DESCRIPCION, '')",
            'seccion'      => "ISNULL(SC.DESCRIPCION, '')",
            'familia'      => "ISNULL(F.DESCRIPCION, '')",
            'exhibicion'   => 'ISNULL(E.EXHIBICION, 0)',
            'uxc'          => "CASE
                WHEN CL.OUTER_CASE IS NOT NULL THEN CL.OUTER_CASE
                WHEN CL.INNER_CASE_PACK IS NOT NULL THEN CL.INNER_CASE_PACK
                ELSE 0
            END",
        ];


        if (!isset($columnasOrden[$ordenCampo])) {
            $ordenCampo = 'codarticulo';
        }


        if (!in_array($ordenDir, ['asc', 'desc'], true)) {
            $ordenDir = 'asc';
        }


        $ordenPrincipal = $columnasOrden[$ordenCampo] . ' ' . strtoupper($ordenDir);
        $ordenSecundario = [];

        if ($ordenCampo !== 'codarticulo') {
            $ordenSecundario[] = 'TRY_CAST(E.CODARTICULO AS INT) ASC';
        }

        $orderByFinal = implode(",
    ", array_merge([$ordenPrincipal], $ordenSecundario));

        $sql .= "
ORDER BY
    {$orderByFinal}

OFFSET ? ROWS
FETCH NEXT ? ROWS ONLY
";
        

        $params[] = $offset;
        $params[] = $limitConsulta;


        $stmt = sqlsrv_query($sqlsrv_conn, $sql, $params);

        if ($stmt === false) {
            throw new Exception(print_r(sqlsrv_errors(), true));
        }

        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $resultados[] = $row;
        }

        sqlsrv_free_stmt($stmt);


        if (count($resultados) > $perPage) {
            $haySiguiente = true;
            array_pop($resultados);
        }

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}


$totalResultados = count($resultados);

$desde = $codalmacen !== '' && $totalResultados > 0 ? ($offset + 1) : 0;
$hasta = $offset + $totalResultados;

$mensajeOk  = isset($_GET['ok']) && $_GET['ok'] === '1';
$mensajeErr = trim((string)($_GET['err'] ?? ''));
?>
<link rel="stylesheet" href="exhibiciontotal/css/sin_stock.css?v=20261109">

<div class="exhibicion-page">


    <?php if ($mensajeOk): ?>
        <div class="alert alert-success rounded-4 shadow-sm">
            <i class="bi bi-check-circle me-1"></i>
            Exhibición guardada correctamente.
        </div>
    <?php endif; ?>

    <?php if ($mensajeErr !== ''): ?>
        <div class="alert alert-danger rounded-4 shadow-sm">
            <strong>Error:</strong> <?= h($mensajeErr) ?>
        </div>
    <?php endif; ?>


<div class="sin-hoja">
<div class="card filter-card p-4 mb-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">

        
        <div>
            <div class="sin-counter"><i class="bi bi-table"></i> <?= h($totalResultados) ?> registros <span class="sin-sep">|</span> Página <?= h($page) ?></div>
        </div>

        
        <div class="d-flex align-items-center gap-2 flex-wrap">


            <button
                type="submit"
                form="formGuardarMasivoSinStock"
                class="btn btn-primary btn-modern"
                id="btnGuardarMasivo"
                <?= empty($resultados) ? 'disabled' : '' ?>
            >
                <i class="bi bi-save2 me-1"></i>
                Guardar Masivo
            </button>

        </div>

    </div>

        <form method="GET" class="row g-3" id="formFiltrosSinStock">
            <input type="hidden" name="vista" value="modulo3">
            <input type="hidden" name="page" value="1">

            
            <input type="hidden" name="orden_campo" id="orden_campo" value="<?= h($ordenCampo ?? 'codarticulo') ?>">
            <input type="hidden" name="orden_dir" id="orden_dir" value="<?= h($ordenDir ?? 'asc') ?>">

            
            <input type="hidden" name="plu" value="<?= h($plu) ?>">
            <input type="hidden" name="descripcion" value="<?= h($descripcion) ?>">
            <input type="hidden" name="departamento" value="<?= h($departamento) ?>">
            <input type="hidden" name="seccion" value="<?= h($seccion) ?>">
            <input type="hidden" name="familia" value="<?= h($familia) ?>">
            <input type="hidden" name="exhibicion" value="<?= h($exhibicion) ?>">
            <input type="hidden" name="uxc" value="<?= h($uxc) ?>">

            <div class="col-lg-3 col-md-6">
                <label class="form-label" for="filtro_codalmacen">CODALMACEN / Tienda</label>

                <select id="filtro_codalmacen" name="codalmacen" class="form-select" required>
                    <option value="">Seleccione tienda</option>

                    <?php if ($rol === 'super_admin'): ?>
                        <?php foreach ($tiendasSuperAdmin as $t): ?>
                            <option value="<?= h($t['codigo']) ?>" <?= $codalmacen === $t['codigo'] ? 'selected' : '' ?>>
                                <?= h($t['codigo']) ?> - <?= h($t['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <?php foreach ($tiendasPermitidas as $t): ?>
                            <option value="<?= h($t['codigo']) ?>" <?= $codalmacen === $t['codigo'] ? 'selected' : '' ?>>
                                <?= h($t['codigo']) ?> - <?= h($t['nombre']) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-lg-3 col-md-6">
                <label class="form-label" for="filtro_referencia">Referencia</label>
                <input type="text" id="filtro_referencia" name="referencia" value="<?= h($referencia) ?>" class="form-control" placeholder="Buscar referencia">
            </div>

            <div class="col-lg-3 col-md-6">
                <label class="form-label" for="filtro_codbarras">Código de barras</label>
                <input type="text" id="filtro_codbarras" name="codbarras" value="<?= h($codbarras) ?>" class="form-control" placeholder="Buscar código de barras">
            </div>

            <div class="col-lg-2 col-md-6">
                <label class="form-label" for="filtro_codarticulo">Codartículo</label>
                <input type="text" id="filtro_codarticulo" name="codarticulo" value="<?= h($codarticulo) ?>" class="form-control" placeholder="Artículo">
            </div>

            <div class="col-lg-1 col-md-12 d-flex align-items-end gap-2">
                <button class="btn btn-primary btn-modern w-100">
                    <i class="bi bi-search"></i>
                </button>

                <a href="/exhibicion_DT/index.php?vista=modulo3" class="btn btn-outline-secondary btn-modern">
                    <i class="bi bi-x-circle"></i>
                </a>
            </div>
        </form>
    </div>

    
    <?php if ($codalmacen === ''): ?>
        <div class="card result-card">
            <div class="empty-state">
                <i class="bi bi-shop-window"></i>
                <h5 class="fw-bold">Seleccione una tienda</h5>
                <p class="mb-0">Para consultar productos en exhibición sin stock, primero seleccione un CODALMACEN.</p>
            </div>
        </div>
    <?php else: ?>


            <div class="table-responsive" id="tablaExhibicion">

                
                <div id="excelMenu" class="excel-menu" hidden>
                    <div class="excel-menu-head">
                        <div class="excel-menu-heading">
                            <span class="excel-menu-overline">FILTRO DE COLUMNA</span>
                            <strong id="excelMenuTitle">Filtrar</strong>
                        </div>

                        <button type="button" id="excelMenuClose" class="excel-menu-close">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <input type="hidden" id="excelField">

                    <div class="excel-menu-body">
                        <label class="excel-menu-order">Orden
                            <select id="excelOrder" class="excel-menu-input">
                                <option value="asc">Ordenar A → Z</option>
                                <option value="desc">Ordenar Z → A</option>
                            </select>
                        </label>

                        <input type="search" id="excelSearch" class="excel-menu-input" placeholder="Buscar valor..." aria-label="Buscar valores" autocomplete="off">

                        <label class="excel-check-all">
                            <input type="checkbox" id="excelSelectAll">
                            Seleccionar todo
                        </label>

                        <div id="excelOptions" class="excel-options"></div>
                        <small class="excel-menu-hint">Selecciona uno o varios valores, o escribe para buscar.</small>

                        <div class="excel-menu-actions">
                            <button type="button" id="excelClear" class="btn btn-outline-secondary btn-sm excel-menu-clear">
                                Limpiar
                            </button>
                            <button type="button" id="excelApply" class="btn btn-primary btn-sm excel-menu-apply">
                                Aplicar
                            </button>
                        </div>
                    </div>
                </div>

                <form
                    method="POST"
                    action="/exhibicion_DT/exhibiciontotal/guardar_exhibicion_masivo_nuevo.php"
                    id="formGuardarMasivoSinStock"
                >
                    <input type="hidden" name="return_qs" value="<?= h($_SERVER['QUERY_STRING'] ?? '') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(app_csrf_token()) ?>">

                <table class="table table-hover table-modern align-middle">
                    <thead>
                        <tr>
                            
                            <th>
                                <div class="excel-th">
                                    <input type="checkbox" id="checkTodosMasivo" title="Seleccionar todos">
                                </div>
                            </th>

                            
                            <th class="sin-col-num">N°</th>

                            <?php
                            $headers = [


                                'referencia'   => 'Referencia',
                                'codbarras'    => 'Código barras',
                                'plu'          => 'PLU',
                                'descripcion'  => 'Descripción',
                                'departamento' => 'Departamento',
                                'seccion'      => 'Sección',
                                'familia'      => 'Familia',
                                'inventario'   => 'Inventario',
                                'exhibicion'   => 'Exhibición',
                                'uxc'          => 'UXC',
                            ];
                            ?>

                            <?php foreach ($headers as $field => $label): ?>
                                <th>
                                    <div class="excel-th">
                                        <span><?= h($label) ?></span>

                                        <?php if (!in_array($field, ['estado', 'inventario'], true)): ?>
                                            <button
                                                type="button"
                                                class="excel-filter-btn <?= trim((string)($_GET[$field] ?? '')) !== '' ? 'is-active' : '' ?>"
                                                data-field="<?= h($field) ?>"
                                                data-label="<?= h($label) ?>"
                                            >
                                                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 2h13L9.2 7.1v5.1l-2.4 1.8V7.1L1.5 2z"/></svg>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </th>
                            <?php endforeach; ?>

                            
                            <th>Guardar</th>

                        </tr>
                    </thead>

                    <tbody>
                    <?php if (empty($resultados)): ?>
                        <tr>
                            <td colspan="13">
                                <div class="empty-state">
                                    <i class="bi bi-check-circle"></i>
                                    <h5 class="fw-bold">Todo bien</h5>
                                    <p class="mb-0">No hay productos en exhibición sin stock para esta tienda.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                    <?php
                    

                    $numeroFila = $offset + 1;
                    ?>

                    <?php foreach ($resultados as $i => $r): ?>
                        <tr>
                            <?php $i = (int)$i; ?>

                            <td data-label="Seleccionar">
                                <input
                                    type="checkbox"
                                    class="check-fila-masivo"
                                    name="items[<?= $i ?>][seleccionado]"
                                    value="1"
                                >

                                <input type="hidden" name="items[<?= $i ?>][region]" value="<?= h($r['REGION'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codalmacen]" value="<?= h($r['CODALMACEN'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codarticulo]" value="<?= h($r['CODARTICULO'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][codbarras]" value="<?= h($r['CODBARRAS'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][plu]" value="<?= h($r['PLU'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][uxc]" value="<?= h($r['UXC'] ?? 0) ?>">

                                
                                <input type="hidden" name="items[<?= $i ?>][zona]" value="<?= h($infoTiendaSeleccionada['zona'] ?? '') ?>">
                                <input type="hidden" name="items[<?= $i ?>][nombrealmacen]" value="<?= h($r['ALMACEN'] ?? ($infoTiendaSeleccionada['nombre'] ?? '')) ?>">
                            </td>

                            
                            <td class="sin-col-num" data-label="N°">
                                <span><?= $numeroFila++ ?></span>
                            </td>

                            <td data-field="referencia" data-label="Referencia"><?= h($r['REFERENCIA'] ?? '') ?></td>
                            <td data-field="codbarras" data-label="Código barras"><?= h($r['CODBARRAS'] ?? '') ?></td>
                            <td data-field="plu" data-label="PLU"><?= h($r['PLU'] ?? '') ?></td>
                            <td data-field="descripcion" data-label="Descripción"><?= h($r['DESCRIPCION'] ?? '') ?></td>
                            <td data-field="departamento" data-label="Departamento"><?= h($r['DEPARTAMENTO'] ?? '') ?></td>
                            <td data-field="seccion" data-label="Sección"><?= h($r['SECCION'] ?? '') ?></td>
                            <td data-field="familia" data-label="Familia"><?= h($r['FAMILIA'] ?? '') ?></td>

                            <td data-field="inventario" data-label="Inventario">
                                <span class="badge badge-soft-warning rounded-pill">0</span>
                            </td>

                            <td data-field="exhibicion" data-label="Exhibición" style="min-width:90px;">
                                <input
                                    type="number"
                                    class="form-control form-control-sm excel-value-input"
                                    name="items[<?= $i ?>][exhibicion]"
                                    value="<?= h($r['EXHIBICION'] ?? 0) ?>"
                                    min="0"
                                    max="99999"
                                    required
                                    oninput="this.value=this.value.replace(/\D/g,'').slice(0,5);"
                                >
                            </td>

                            <td data-field="uxc" data-label="UXC">
                                <?= h($r['UXC'] ?? 0) ?>
                            </td>

                            
                            <td data-label="Guardar">
                                <button
                                    type="submit"
                                    class="btn btn-primary btn-sm btn-guardar-fila"
                                    title="Guardar solo este registro"
                                >
                                    <i class="bi bi-save-fill"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-end mt-3">
                    <button
                        type="submit"
                        class="btn btn-primary btn-modern"
                        id="btnGuardarMasivoBottom"
                        <?= empty($resultados) ? 'disabled' : '' ?>
                    >
                        <i class="bi bi-save2 me-1"></i>
                        Guardar
                    </button>
                </div>

                
                <div class="floating-save-wrap">
                    <button
                        type="submit"
                        form="formGuardarMasivoSinStock"
                        class="floating-save-btn"
                        id="btnGuardarMasivoFloat"
                        <?= empty($resultados) ? 'disabled' : '' ?>
                    >
                        <i class="bi bi-save2-fill"></i>
                        <span>Guardar Masivo</span>
                    </button>
                </div>

                </form>
            </div>

            
            <div class="sin-sheet-footer">
                <span><i class="bi bi-table"></i> <?= h($totalResultados) ?> filas en esta página <span class="sin-sep">|</span> Página <?= h($page) ?><?= $haySiguiente ? ' · Más registros disponibles' : '' ?></span>
                <nav>
                    <ul class="pagination pagination-sm flex-wrap">
                        <?php $qs = $_GET; ?>

                        <?php $qs['page'] = max(1, $page - 1); ?>
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= h(http_build_query($qs)) ?>">Anterior</a>
                        </li>

                        <li class="page-item active">
                            <span class="page-link">Página <?= h($page) ?></span>
                        </li>

                        <?php $qs['page'] = $page + 1; ?>
                        <li class="page-item <?= !$haySiguiente ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= h(http_build_query($qs)) ?>">Siguiente</a>
                        </li>
                    </ul>
                </nav>
            </div>
    <?php endif; ?>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    
    const element1 = document.getElementById('excelMenu');
    const element2 = document.getElementById('excelMenuTitle');
    const element3 = document.getElementById('excelMenuClose');
    const element4 = document.getElementById('excelField');
    const element5 = document.getElementById('excelSearch');
    const element6 = document.getElementById('excelOptions');
    const element7 = document.getElementById('excelSelectAll');
    const element8 = document.getElementById('excelApply');
    const element9 = document.getElementById('excelOrder');
    const element10 = document.getElementById('excelClear');
    const elements1 = document.querySelectorAll('.excel-filter-btn');
    const element11 = document.getElementById('formFiltrosSinStock');
    const btnGuardarMasivoFloat = document.getElementById('btnGuardarMasivoFloat');

    
    // Restaurar el desplazamiento después de guardar.
    const value1 = sessionStorage.getItem('scrollSinStockTabla');

    if (value1 !== null) {
        setTimeout(() => {
            window.scrollTo({
                top: parseInt(value1, 10),
                behavior: 'auto'
            });

            sessionStorage.removeItem('scrollSinStockTabla');
        }, 150);
    }

    
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function () {
            sessionStorage.setItem(
                'scrollSinStockTabla',
                String(window.scrollY)
            );
        });
    });

    if (!element1 || !element11) {
        return;
    }

    
    function normalizar(texto) {
        return String(texto || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    
    function getInputFiltro(field) {
        return element11.querySelector('[name="' + field + '"]');
    }

    
    function cerrarMenu() {
        element1.hidden = true;
    }

    
    function getSelectedValues(field) {
        const value2 = getInputFiltro(field);
        const inputValue1 = value2 ? value2.value.trim() : '';

        if (inputValue1 === '' || inputValue1.startsWith('_LIKE_')) {
            return [];
        }

        return inputValue1.split('||').filter(v => v.trim() !== '');
    }

    
   function getColumnValues(field) {

    const seenItems1 = new Set();

    document.querySelectorAll('[data-field="' + field + '"]').forEach(td => {

        let text1 = '';

        const element12 = td.querySelector('input[name="exhibicion"]');

        if (element12) {
            text1 = element12.value.trim();
        } else {
            text1 = td.textContent.trim();
        }

        if (text1 !== '') {
            seenItems1.add(text1);
        }
    });

    let arr = Array.from(seenItems1).filter(v => v !== '');

    
    if (element9 && element9.value === 'desc') {

        arr.sort((a, b) =>
            String(b).localeCompare(String(a), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );

    } else {

        arr.sort((a, b) =>
            String(a).localeCompare(String(b), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );
    }

    return arr;
}
    
    function renderOptions(values, selectedValues = []) {
        element6.innerHTML = '';

        values.forEach(value => {
            const value3 = selectedValues.includes(value) ? 'checked' : '';
            const element13 = document.createElement('label');

            element13.className = 'excel-option';
            element13.dataset.value = normalizar(value);

            element13.innerHTML = `
                <input type="checkbox" class="excel-option-check" value="${value}" ${value3}>
                <span>${value}</span>
            `;

            element6.appendChild(element13);
        });
    }

    
    function abrirMenu(btn) {
        const value4 = btn.dataset.field;
        const value5 = btn.dataset.label;

        element4.value = value4;
        element2.textContent = 'Filtrar ' + value5;
        const element14 = element11.querySelector('[name="orden_campo"]')?.value;
        const element15 = element11.querySelector('[name="orden_dir"]')?.value;
        element9.value = element14 === value4 && element15 === 'desc' ? 'desc' : 'asc';
        element5.value = '';

        const itemCount1 = getSelectedValues(value4);
        const itemCount2 = getColumnValues(value4);

        renderOptions(itemCount2, itemCount1);

        element7.checked = itemCount1.length > 0 && itemCount1.length === itemCount2.length;

        element1.hidden = false;
        setTimeout(() => element5.focus(), 30);
    }

    
    elements1.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            abrirMenu(btn);
        });
    });

    
if (element9) {

    element9.addEventListener('change', function () {

        const inputValue2 = element4.value;

        if (!inputValue2) {
            return;
        }

        const value6 = getSelectedValues(inputValue2);

        const value7 = getColumnValues(inputValue2);

        renderOptions(value7, value6);
    });
}

    
    element5.addEventListener('input', function () {
        const inputValue3 = normalizar(this.value);

        document.querySelectorAll('.excel-option').forEach(option => {
            const inputValue4 = option.dataset.value || '';
            option.style.display = inputValue4.includes(inputValue3) ? 'flex' : 'none';
        });

        element7.checked = false;
    });

    
    element7.addEventListener('change', function () {
        document.querySelectorAll('.excel-option').forEach(option => {
            if (option.style.display !== 'none') {
                const element16 = option.querySelector('.excel-option-check');

                if (element16) {
                    element16.checked = element7.checked;
                }
            }
        });
    });

    
    element8.addEventListener('click', function () {
        const inputValue5 = element4.value;
        const value8 = getInputFiltro(inputValue5);

        if (!value8) {
            return;
        }

        const itemCount3 = [];

        document.querySelectorAll('.excel-option-check:checked').forEach(check => {
            itemCount3.push(check.value);
        });

        if (itemCount3.length > 0) {
            value8.value = itemCount3.join('||');
        } else {
            const inputValue6 = element5.value.trim();
            value8.value = inputValue6 !== '' ? '_LIKE_' + inputValue6 : '';
        }

        
        const element17 = document.getElementById('orden_campo');
        const element18 = document.getElementById('orden_dir');

        if (element17 && element18 && element9) {
            element17.value = inputValue5;
            element18.value = element9.value;
        }

        element11.submit();
    });

    
    element10.addEventListener('click', function () {
        const inputValue7 = element4.value;
        const value9 = getInputFiltro(inputValue7);

        if (!value9) {
            return;
        }

        value9.value = '';

        
        const element19 = document.getElementById('orden_campo');
        const element20 = document.getElementById('orden_dir');

        if (element19 && element20) {
            element19.value = 'codarticulo';
            element20.value = 'asc';
        }

        element11.submit();
    });

    
    element3.addEventListener('click', cerrarMenu);

    document.addEventListener('click', function (e) {
        if (!element1.hidden && !element1.contains(e.target)) {
            cerrarMenu();
        }
    });

    element1.addEventListener('wheel', function (e) {
        e.stopPropagation();
    });


    const element21 = document.getElementById('checkTodosMasivo');
    const element22 = document.getElementById('formGuardarMasivoSinStock');

    if (element21) {
        element21.addEventListener('change', function () {
            document.querySelectorAll('.check-fila-masivo').forEach(check => {
                check.checked = element21.checked;
            });
        });
    }

    
    document.querySelectorAll('.btn-guardar-fila').forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();

            const value10 = btn.closest('tr');

            if (!value10 || !element22) {
                return;
            }

            document.querySelectorAll('.check-fila-masivo').forEach(check => {
                check.checked = false;
            });

            const element23 = value10.querySelector('.check-fila-masivo');

            if (element23) {
                element23.checked = true;
            }

            sessionStorage.setItem(
                'scrollSinStockTabla',
                String(window.scrollY)
            );

            if (typeof element22.requestSubmit === 'function') {
                element22.requestSubmit();
            } else {
                element22.submit();
            }
        });
    });

    if (element22) {
        element22.addEventListener('submit', function (e) {
            const elements2 = document.querySelectorAll('.check-fila-masivo:checked');

            if (elements2.length === 0) {
                e.preventDefault();
                alert('Seleccione al menos un registro para guardar.');
                return;
            }

            const element24 = document.getElementById('btnGuardarMasivo');
            const element25 = document.getElementById('btnGuardarMasivoBottom');
            const element26 = document.getElementById('btnGuardarMasivoFloat');

            [element24, element25, element26].forEach(btn => {
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Guardando...';
                }
            });
        });
    }
});
</script>