<?php
declare(strict_types=1);

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

require_once __DIR__ . '/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';


// Comprobar el acceso antes de consultar los datos.
require_module_access('modulo1');
$me = me();



function h_view(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function exh_normalizar_pais(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}

// Obtener únicamente las tiendas disponibles para el usuario actual.
function exh_get_tiendas_permitidas(mysqli $conn, $sqlsrvConn, array $me): array
{
    $miId   = (int)($me['id'] ?? 0);
    $miRol  = trim((string)($me['rol'] ?? ''));
    $miPais = exh_normalizar_pais((string)($me['pais_code'] ?? ''));

    $rows = [];

    if ($miRol === 'super_admin') {
        if ($miPais === 'NI') {
            $sql = "
                SELECT DISTINCT
                    LTRIM(RTRIM(CODALMACEN)) AS codalmacen,
                    LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen,
                    LTRIM(RTRIM(POBLACION)) AS zona,
                    'Nicaragua' AS pais,
                    'ACANICARAGUA2' AS base_datos
                FROM ACANICARAGUA2.dbo.almacen
                WHERE POBLACION IS NOT NULL
                  AND LTRIM(RTRIM(POBLACION)) <> ''
                  AND LTRIM(RTRIM(CODALMACEN)) LIKE '[0-9][0-9]'
                  AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
                ORDER BY CODALMACEN ASC
            ";
        } else {
            $sql = "
                SELECT DISTINCT
                    LTRIM(RTRIM(CODALMACEN)) AS codalmacen,
                    LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen,
                    LTRIM(RTRIM(POBLACION)) AS zona,
                    'Honduras' AS pais,
                    'DETODO' AS base_datos
                FROM DETODO.dbo.almacen
                WHERE POBLACION IS NOT NULL
                  AND LTRIM(RTRIM(POBLACION)) <> ''
                  AND LTRIM(RTRIM(CODALMACEN)) LIKE '[0-9][0-9]'
                  AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
                ORDER BY CODALMACEN ASC
            ";
        }

        $stmt = sqlsrv_query($sqlsrvConn, $sql);

        if ($stmt === false) {
            return [];
        }

        while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $cod = trim((string)($r['codalmacen'] ?? ''));

            if ($cod === '') {
                continue;
            }

            $rows[$cod] = [
                'codalmacen'    => $cod,
                'nombrealmacen' => trim((string)($r['nombrealmacen'] ?? '')),
                'zona'          => trim((string)($r['zona'] ?? '')),
                'pais'          => trim((string)($r['pais'] ?? '')),
                'base_datos'    => trim((string)($r['base_datos'] ?? '')),
            ];
        }

        sqlsrv_free_stmt($stmt);

        return array_values($rows);
    }

    if ($miRol === 'admin_zona' || $miRol === 'tienda') {
        $sql = "
            SELECT DISTINCT
                ut.codalmacen,
                ut.nombrealmacen,
                ut.zona,
                ut.pais,
                ut.base_datos
            FROM usuario_tienda ut
            WHERE ut.usuario_id = ?
              AND TRIM(COALESCE(ut.codalmacen, '')) <> ''
            ORDER BY codalmacen ASC
        ";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            return [];
        }

        $stmt->bind_param("i", $miId);
        $stmt->execute();

        $res = $stmt->get_result();

        while ($r = $res->fetch_assoc()) {
            $cod = trim((string)($r['codalmacen'] ?? ''));

            if ($cod === '') {
                continue;
            }

            $rows[$cod] = [
                'codalmacen'    => $cod,
                'nombrealmacen' => trim((string)($r['nombrealmacen'] ?? '')),
                'zona'          => trim((string)($r['zona'] ?? '')),
                'pais'          => trim((string)($r['pais'] ?? '')),
                'base_datos'    => trim((string)($r['base_datos'] ?? '')),
            ];
        }

        $stmt->close();

        return array_values($rows);
    }

    return [];
}

function build_page_url_modulo1(int $targetPage, string $baseQueryString): string
{
    $params = [];

    if ($baseQueryString !== '') {
        parse_str($baseQueryString, $params);
    }

    $params['vista'] = 'modulo1';
    $params['page'] = $targetPage;

    return 'index.php?' . http_build_query($params);
}


$paisCode = strtoupper(trim((string)($_SESSION['pais_code'] ?? '')));
$region   = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';


// Se conservan los filtros activos entre consultas y cambios de página.
$filters = exhibicion_filters_from_get();

$tiendasPermitidas = exh_get_tiendas_permitidas(
    $conn,
    $sqlsrv_conn_exhibicion,
    $me
);

$filtroCodAlmacen = trim((string)($filters['codalmacen'] ?? ''));

// Validar la página y el tamaño del listado.
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)($_GET['per_page'] ?? 100);

if (!in_array($perPage, [100, 250, 500, 1000], true)) {
    $perPage = 100;
}

[$baseSql, $baseParams, $ctx] = exhibicion_build_query($filters);

$offset = ($page - 1) * $perPage;
$fetchRows = $perPage + 1;


$orderByFinal = exhibicion_order_by_from_get($_GET);

// Consultar una fila adicional para saber si existe página siguiente.
$dataSql = $baseSql . "
    ORDER BY
        $orderByFinal
    OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
";

$dataParams = array_merge($baseParams, [$offset, $fetchRows]);

$stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $dataSql, $dataParams, [
    "QueryTimeout" => 300
]);

if ($stmt === false) {
    die('<pre>Error en consulta: ' . print_r(sqlsrv_errors(), true) . '</pre>');
}

$rows = [];

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $rows[] = $row;
}

sqlsrv_free_stmt($stmt);

// Si hay más registros, la fila adicional no se muestra en la tabla.
$hasNext = count($rows) > $perPage;

if ($hasNext) {
    array_pop($rows);
}

$hasPrev = $page > 1;

$queryWithoutPage = $_GET;
unset($queryWithoutPage['page']);

$currentQueryString = http_build_query($_GET);
$baseQueryString = http_build_query($queryWithoutPage);

$rol = strtolower(trim($ctx['rol'] ?? ''));
?>

<div class="exh-wrap">

    <?php if (isset($_GET['ok']) && $_GET['ok'] === '1'): ?>
        <div class="exh-alert exh-alert-ok">
            <i class="bi bi-check-circle-fill"></i>
            <span>Registro guardado correctamente.</span>
        </div>
    <?php endif; ?>

    <?php if (!empty($_GET['err'])): ?>
        <div class="exh-alert exh-alert-err">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <span><?= h_view($_GET['err']) ?></span>
        </div>
    <?php endif; ?>

    <div class="exh-panel">

        
        <section class="exh-card" aria-label="Hoja de exhibición">
            <div class="exh-toolbar">
                <form method="get" action="index.php" class="exh-mini-form" id="formPerPage">
                    <input type="hidden" name="vista" value="modulo1">

                    <?php foreach ($_GET as $k => $v): ?>
                        <?php if ($k !== 'per_page' && $k !== 'page' && $k !== 'vista'): ?>
                            <input type="hidden" name="<?= h_view($k) ?>" value="<?= h_view((string)$v) ?>">
                        <?php endif; ?>
                    <?php endforeach; ?>

                    <label for="per_page">Registros por página</label>

                    <select name="per_page" id="per_page">
                        <option value="100" <?= $perPage === 100 ? 'selected' : '' ?>>100</option>
                        <option value="250" <?= $perPage === 250? 'selected' : '' ?>>250</option>
                        <option value="500" <?= $perPage === 500 ? 'selected' : '' ?>>500</option>
                        <option value="1000" <?= $perPage === 1000 ? 'selected' : '' ?>>1000</option>
                    </select>
                </form>

                <div class="exh-toolbar-separator"></div>
                <a id="btnLimpiar" href="index.php?vista=modulo1" class="exh-btn-label exh-btn-light" title="Limpiar filtros"><i class="bi bi-arrow-counterclockwise"></i><span>Limpiar</span></a>
                <a id="btnExportar" href="exhibiciontotal/exportar_excel.php<?= $currentQueryString !== '' ? '?' . h_view($currentQueryString) : '' ?>" class="exh-btn-label exh-btn-success" title="Exportar todos los resultados filtrados como CSV para Excel"><i class="bi bi-file-earmark-excel"></i><span>Excel CSV</span></a>

               <button
    type="submit"
    form="formMasivoExhibicion"
    id="btnGuardarMasivo"
    class="btn-masivo-mini"
>
    <i class="bi bi-save-fill"></i>
    Guardar Masivo
</button>

            </div>

            <div class="exh-table-shell" id="tablaExhibicion">

                <form method="get" id="formFiltros" action="index.php">
                    <input type="hidden" name="vista" value="modulo1">
                    <input type="hidden" name="per_page" value="<?= h_view((string)$perPage) ?>">

                    <input type="hidden" name="region" value="<?= h_view($filters['region'] ?? '') ?>">
                    <input type="hidden" name="referencia" value="<?= h_view($filters['referencia'] ?? '') ?>">
                    <input type="hidden" name="descripcion" value="<?= h_view($filters['descripcion'] ?? '') ?>">
                    <input type="hidden" name="departamento" value="<?= h_view($filters['departamento'] ?? '') ?>">
                    <input type="hidden" name="seccion" value="<?= h_view($filters['seccion'] ?? '') ?>">
                    <input type="hidden" name="familia" value="<?= h_view($filters['familia'] ?? '') ?>">
                    <input type="hidden" name="codbarras" value="<?= h_view($filters['codbarras'] ?? '') ?>">
                    <input type="hidden" name="plu" value="<?= h_view($filters['plu'] ?? '') ?>">
                    <input type="hidden" name="inventario_tienda" value="<?= h_view($filters['inventario_tienda'] ?? '') ?>">
                    <input type="hidden" name="exhibicion" value="<?= h_view($filters['exhibicion'] ?? '') ?>">
                    <input type="hidden" name="uxc" value="<?= h_view($filters['uxc'] ?? '') ?>">
                    <input type="hidden" name="codarticulo" value="<?= h_view($filters['codarticulo'] ?? '') ?>">
                    <input type="hidden" name="codalmacen" value="<?= h_view($filters['codalmacen'] ?? '') ?>">
                    <input type="hidden" name="orden_campo" id="orden_campo" value="<?= h_view($ordenCampo) ?>">
                    <input type="hidden" name="orden_dir" id="orden_dir" value="<?= h_view($ordenDir) ?>">
                </form>

                


                <div id="excelMenu" class="excel-menu" hidden>
                    <div class="excel-menu-head">
                        <div class="excel-menu-heading">
                            <span class="excel-menu-overline">FILTRO DE COLUMNA</span>
                            <strong id="excelMenuTitle">Filtrar</strong>
                        </div>

                        <button type="button" id="excelMenuClose" class="excel-menu-close" title="Cerrar">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>

                    <input type="hidden" id="excelField">

                    <div class="excel-menu-body">
                        <label class="excel-menu-order">Orden
                            <select id="excelOrder" class="excel-menu-input">
                                <option value="asc">Ordenar A → Z</option>
                                <option value="desc">Ordenar Z → A</option>
                            </select>
                        </label>

                        <input
                            type="search"
                            id="excelSearch"
                            class="excel-menu-input"
                            placeholder="Buscar valor..."
                            aria-label="Buscar valores"
                            autocomplete="off"
                        >

                        <label class="excel-check-all">
                            <input type="checkbox" id="excelSelectAll">
                            Seleccionar todo
                        </label>

                        <div id="excelOptions" class="excel-options"></div>
                        <small class="excel-menu-hint">Opciones de todos los registros, no solo de esta página. Escribe para buscar cualquier valor.</small>

                        <div class="excel-menu-actions">
                            <button type="button" id="excelClear" class="exh-btn-label exh-btn-light excel-menu-clear">
                                <i class="bi bi-eraser"></i>
                                <span>Limpiar</span>
                            </button>
                            <button type="button" id="excelApply" class="exh-btn-label exh-btn-primary excel-menu-apply">
                                <i class="bi bi-check2"></i>
                                <span>Aplicar</span>
                            </button>
                        </div>

                    </div>
                </div>

                <script>
                    const TIENDAS_PERMITIDAS = <?= json_encode($tiendasPermitidas, JSON_UNESCAPED_UNICODE) ?>;
                </script>

                <form
                    id="formMasivoExhibicion"
                    method="post"
                    action="/exhibicion_DT/exhibiciontotal/guardar_exhibicion_masivo_v2.php"
                >
                    <input type="hidden" name="return_qs" value="<?= h_view($currentQueryString) ?>">
                    <input type="hidden" name="csrf_token" value="<?= h_view(app_csrf_token()) ?>">
                    <input type="hidden" name="items_json" id="items_json" value="">
                    <input type="hidden" name="masivo_version" value="V2_UNICO">
                </form>

                <table class="exh-table">
                    <thead>
                        <tr>
                            



                            <th class="center" title="Seleccionar todos">
                                <input
                                    type="checkbox"
                                    id="checkTodosMasivo"
                                    title="Seleccionar todos los registros visibles"
                                >
                            </th>

                            



                            <th class="exh-col-num" title="Número de fila">N°</th>

                            <?php
                            $headers = [
                                'referencia'        => 'Referencia',
                                'descripcion'       => 'Descripción',
                                'departamento'      => 'Departamento',
                                'seccion'           => 'Sección',
                                'familia'           => 'Familia',
                                'codbarras'         => 'Cod Barras',
                                'plu'               => 'PLU',
                                'inventario_tienda' => 'Inventario Tienda',
                                'exhibicion'        => 'Exhibición',
                                 'uxc'               => 'UXC',
                               
                            ];

                            if ($rol === 'admin_zona' || $rol === 'super_admin') {
                                $headers['codalmacen'] = 'Almacén';
                                }
                            ?>

                            <?php foreach ($headers as $field => $label): ?>
                                <th>
                                    <div class="exh-th-wrap">
                                        <span><?= h_view($label) ?></span>

                                        <button
                                            type="button"
                                            class="exh-filter-trigger <?= ($filters[$field] ?? '') !== '' ? 'is-active' : '' ?>"
                                            data-field="<?= h_view($field) ?>"
                                            data-label="<?= h_view($label) ?>"
                                            title="Filtrar <?= h_view($label) ?>"
                                        >
                                            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 2h13L9.2 7.1v5.1l-2.4 1.8V7.1L1.5 2z"/></svg>
                                        </button>
                                    </div>
                                </th>
                            <?php endforeach; ?>

                            <th>Guardar</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (empty($rows)): ?>
                            <tr>
                                <td colspan="15" class="exh-empty">
                                    <i class="bi bi-inbox"></i> No se encontraron registros.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php
                            

                            $numeroFila = $offset + 1;
                            ?>

                            <?php foreach ($rows as $i => $row): ?>
                                <?php
                                $formId = 'frm_exh_' . md5(
                                    (string)($row['CODARTICULO'] ?? '') . '|' .
                                    (string)($row['CODBARRAS'] ?? '') . '|' .
                                    (string)($row['PLU'] ?? '') . '|' .
                                    (string)($row['CODALMACEN'] ?? '')
                                );
                                ?>

                                <tr>
    



    <td class="center" data-label="Seleccionar">
        <input
            form="formMasivoExhibicion"
            type="checkbox"
            class="js-check-masivo"
            name="items[<?= $i ?>][seleccionado]"
            value="1"
            title="Seleccionar este registro"
        >

        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][region]" value="<?= h_view($row['REGION'] ?? $region) ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codalmacen]" value="<?= h_view($row['CODALMACEN'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codarticulo]" value="<?= h_view($row['CODARTICULO'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][codbarras]" value="<?= h_view($row['CODBARRAS'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][plu]" value="<?= h_view($row['PLU'] ?? '') ?>">
        <input form="formMasivoExhibicion" type="hidden" name="items[<?= $i ?>][uxc]" value="<?= h_view((string)($row['UXC'] ?? 0)) ?>">
        

        <input
            form="formMasivoExhibicion"
            type="hidden"
            id="bulk_exhibicion_<?= $i ?>"
            name="items[<?= $i ?>][exhibicion]"
            value="<?= h_view((string)($row['EXHIBICION'] ?? 0)) ?>"
        >
    </td>

    


    <td class="exh-col-num" data-label="N°">
        <span><?= $numeroFila++ ?></span>
    </td>

    <td 
        data-field="referencia"
        title="<?= h_view($row['REFERENCIA'] ?? '') ?>"
    >
        <?= h_view($row['REFERENCIA'] ?? '') ?>
    </td>

    <td 
        data-field="descripcion"
        title="<?= h_view($row['DESCRIPCION'] ?? '') ?>"
    >
        <?= h_view($row['DESCRIPCION'] ?? '') ?>
    </td>

    <td 
        data-field="departamento"
        title="<?= h_view($row['DEPARTAMENTO'] ?? '') ?>"
    >
        <?= h_view($row['DEPARTAMENTO'] ?? '') ?>
    </td>

    <td 
        data-field="seccion"
        title="<?= h_view($row['SECCION'] ?? '') ?>"
    >
        <?= h_view($row['SECCION'] ?? '') ?>
    </td>

    <td 
        data-field="familia"
        title="<?= h_view($row['FAMILIA'] ?? '') ?>"
    >
        <?= h_view($row['FAMILIA'] ?? '') ?>
    </td>

    <td 
        data-field="codbarras"
        title="<?= h_view($row['CODBARRAS'] ?? '') ?>"
    >
        <?= h_view($row['CODBARRAS'] ?? '') ?>
    </td>

    <td 
        data-field="plu"
        title="<?= h_view($row['PLU'] ?? '') ?>"
    >
        <?= h_view($row['PLU'] ?? '') ?>
    </td>

    <td 
        data-field="inventario_tienda"
        class="center"
        title="<?= h_view((string)($row['INVENTARIO_TIENDA'] ?? 0)) ?>"
    >
        <?= h_view((string)($row['INVENTARIO_TIENDA'] ?? 0)) ?>
    </td>

    <td data-field="exhibicion" class="center align-middle">
        <form
            id="<?= h_view($formId) ?>"
            method="post"
            action="exhibiciontotal/guardar_exhibicion.php"
            class="js-form-guardar exh-inline-edit"
        >
            <input type="hidden" name="csrf_token" value="<?= h_view(app_csrf_token()) ?>">
            <input type="hidden" name="accion" value="editar">
            <input type="hidden" name="codarticulo" value="<?= h_view($row['CODARTICULO'] ?? '') ?>">
            <input type="hidden" name="codbarras" value="<?= h_view($row['CODBARRAS'] ?? '') ?>">
            <input type="hidden" name="plu" value="<?= h_view($row['PLU'] ?? '') ?>">
            <input type="hidden" name="codalmacen" value="<?= h_view($row['CODALMACEN'] ?? '') ?>">
            <input type="hidden" name="return_qs" value="<?= h_view($currentQueryString) ?>">
        </form>

        <input
            form="<?= h_view($formId) ?>"
            type="text"
            name="exhibicion"
            value="<?= h_view((string)($row['EXHIBICION'] ?? '')) ?>"
            required
            maxlength="5"
            inputmode="numeric"
            autocomplete="off"
            class="form-control form-control-sm text-center js-only-number exh-input-mini js-exhibicion-masivo"
            data-bulk-index="<?= $i ?>"
            oninput="this.value = this.value.replace(/\D/g, '').slice(0,5); const h=document.getElementById('bulk_exhibicion_<?= $i ?>'); if(h){h.value=this.value;}"
            onkeypress="return /[0-9]/.test(event.key);"
            onpaste="event.preventDefault();"
        >
    </td>

<td 
    data-field="uxc"
    class="center"
    title="<?= h_view((string)($row['UXC'] ?? 0)) ?>"
>
    <?= h_view((string)($row['UXC'] ?? 0)) ?>
</td>




    








    
  <?php if ($rol === 'admin_zona' || $rol === 'super_admin'): ?>
    <td 
        data-field="codalmacen"
        class="center"
        title="<?= h_view($row['ALMACEN'] ?? $row['CODALMACEN'] ?? '') ?>"
    >
        <?= h_view($row['ALMACEN'] ?? '') ?>
    </td>
<?php endif; ?>

    <td class="center">
        <button
            form="<?= h_view($formId) ?>"
            type="submit"
            class="exh-btn-icon exh-btn-primary js-btn-guardar"
            title="Guardar"
        >
            <i class="bi bi-save-fill"></i>
        </button>
    </td>
</tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>

            <div class="exh-sheet-footer">
                <div class="exh-footer-info"><i class="bi bi-table"></i> <?= count($rows) ?> filas en esta página <span class="exh-footer-divider">|</span> Página <?= $page ?><?= $hasNext ? ' · Más registros disponibles' : '' ?></div>
                <div class="exh-pagination">
                <?php if ($hasPrev): ?>
                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1(1, $baseQueryString)) ?>" title="Primera">
                        <i class="bi bi-chevron-bar-left"></i>
                    </a>

                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1($page - 1, $baseQueryString)) ?>" title="Anterior">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                <?php endif; ?>

                <span class="active"><?= $page ?></span>

                <?php if ($hasNext): ?>
                    <a class="js-page-link" href="<?= h_view(build_page_url_modulo1($page + 1, $baseQueryString)) ?>" title="Siguiente">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                <?php endif; ?>
                </div>
            </div>

            



            <div class="floating-save-wrap">
                <button
                    type="submit"
                    form="formMasivoExhibicion"
                    id="btnGuardarMasivoFloat"
                    class="floating-save-btn"
                    title="Guardar los registros seleccionados"
                >
                    <i class="bi bi-save2-fill"></i>
                    <span>Guardar Masivo</span>
                </button>
            </div>

        </section>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    




    const element1 = document.getElementById('per_page');
    const element2 = document.getElementById('formPerPage');
    const element3 = document.getElementById('formFiltros');

    const element4 = document.getElementById('excelMenu');
    const element5 = document.getElementById('excelMenuTitle');
    const element6 = document.getElementById('excelMenuClose');
    const element7 = document.getElementById('excelField');
    const element8 = document.getElementById('excelSearch');
    const element9 = document.getElementById('excelOptions');
    const element10 = document.getElementById('excelSelectAll');
    const element11 = document.getElementById('excelApply');
    const element12 = document.getElementById('excelClear');
    let value1 = [];
    let value2 = false;
    let value3 = 0;
    let value4 = null;
    let value5 = false;
    let seenItems1 = new Set();
    const cache1 = new Map();
    const value6 = [
        'region', 'referencia', 'descripcion', 'departamento', 'seccion',
        'familia', 'codbarras', 'plu', 'inventario_tienda', 'exhibicion',
        'uxc', 'codarticulo', 'codalmacen'
    ];

    




    const element13 = document.getElementById('formMasivoExhibicion');
    const element14 = document.getElementById('checkTodosMasivo');
    const element15 = document.getElementById('btnGuardarMasivo');
    const element16 = document.getElementById('btnGuardarMasivoFloat');

    






    // Recuperar la posición del listado después de guardar o cambiar de página.
    const value7 = sessionStorage.getItem('scrollTablaExhibicion');

    if (value7 !== null) {
        setTimeout(() => {
            window.scrollTo({
                top: parseInt(value7, 10),
                behavior: 'auto'
            });

            sessionStorage.removeItem('scrollTablaExhibicion');
        }, 150);
    }

    




    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function () {
            sessionStorage.setItem(
                'scrollTablaExhibicion',
                String(window.scrollY)
            );
        });
    });

    




    let element17 = document.getElementById('excelOrder');

    // Controles de filtro de las columnas.
    const elements1 = document.querySelectorAll('.exh-filter-trigger');

    




    function loading(btn, iconHtml) {
        if (!btn) return;

        btn.disabled = true;
        btn.innerHTML = iconHtml;
        btn.style.opacity = '.75';
    }

    




    function sanitizeOnlyNumber(value) {
        return String(value || '').replace(/\D/g, '');
    }

    




    function getFilterInput(name) {
        return element3 ? element3.querySelector('input[name="' + name + '"]') : null;
    }

    function getExcelOptionsCacheKey(field) {
        const value8 = value6
            .filter(name => name !== field)
            .map(name => [name, getFilterInput(name)?.value || '']);
        return JSON.stringify([field, value8]);
    }

    function rememberExcelOptions(cacheKey, search, data) {
        const key = cacheKey + '\u0000' + search;
        cache1.delete(key);
        cache1.set(key, {
            values: [...data.values],
            hasMore: data.hasMore
        });
        while (cache1.size > 30) {
            cache1.delete(cache1.keys().next().value);
        }
    }

    function renderCachedExcelOptions() {
        const inputValue1 = element7.value;
        const inputValue2 = element8.value.trim();
        const value9 = getExcelOptionsCacheKey(inputValue1);
        const value10 = cache1.get(value9 + '\u0000' + inputValue2);

        if (value10) {
            value1 = [...value10.values];
            value2 = value10.hasMore;
            renderOptions(
                ordenarValores(value1, element17 ? element17.value : 'asc'),
                [...seenItems1],
                inputValue1
            );
            return true;
        }

        const value11 = cache1.get(value9 + '\u0000');
        if (inputValue2 !== '' && value11 && !value11.hasMore) {
            const value12 = inputValue2.toLocaleLowerCase('es');
            value1 = [...value11.values];
            value2 = false;
            const filteredItems1 = value1.filter(value =>
                value.toLocaleLowerCase('es').includes(value12)
            );
            renderOptions(
                ordenarValores(filteredItems1, element17 ? element17.value : 'asc'),
                [...seenItems1],
                inputValue1
            );
            return true;
        }

        return false;
    }

    




    function closeExcelMenu() {
        if (!element4) return;
        element4.hidden = true;
        value3++;
        clearTimeout(value4);
    }

    




    function getSelectedValues(field) {
        const value13 = getFilterInput(field);
        const inputValue3 = value13 ? value13.value.trim() : '';

        if (inputValue3 === '' || inputValue3.startsWith('__LIKE__')) {
            return [];
        }

        return inputValue3.split('||').filter(v => v.trim() !== '');
    }

    




    function ordenarValores(values, tipo = 'asc') {
        const arr = Array.from(values)
            .filter(v => String(v || '').trim() !== '');

        if (tipo === 'desc') {
            return arr.sort((a, b) =>
                String(b).localeCompare(String(a), undefined, {
                    numeric: true,
                    sensitivity: 'base'
                })
            );
        }

        return arr.sort((a, b) =>
            String(a).localeCompare(String(b), undefined, {
                numeric: true,
                sensitivity: 'base'
            })
        );
    }

    




    function renderOptions(values, selectedValues = [], field = '') {
        element9.innerHTML = '';

        values.forEach(value => {
            let value14 = value;

            if (field === 'codalmacen') {
                value14 = value.split(' - ')[0].trim();
            }

            const element18 = document.createElement('label');
            element18.className = 'excel-option';
            element18.dataset.value = String(value).toLocaleLowerCase('es');
            const element19 = document.createElement('input');
            element19.type = 'checkbox';
            element19.className = 'excel-option-check';
            element19.value = value;
            element19.checked = selectedValues.includes(value14);
            const element20 = document.createElement('span');
            element20.textContent = value || '(Vacío)';
            element18.append(element19, element20);

            element9.appendChild(element18);
        });

        if (value2) {
            const element21 = document.createElement('small');
            element21.textContent = 'Hay más valores. Escribe arriba para buscarlos en todos los registros.';
            element9.appendChild(element21);
        }

        if (!values.length) {
            element9.textContent = 'No se encontraron valores.';
        }
        element10.checked = values.length > 0 &&
            values.every(value => {
                const value15 = field === 'codalmacen' ? value.split(' - ')[0].trim() : value;
                return selectedValues.includes(value15);
            });
    }

    async function loadExcelOptions() {
        const inputValue4 = element7.value;
        const value16 = ++value3;
        const inputValue5 = element8.value.trim();
        const value17 = getExcelOptionsCacheKey(inputValue4);

        if (renderCachedExcelOptions()) return;

        element9.textContent = 'Cargando valores...';
        try {
            if (inputValue4 === 'codalmacen' && typeof TIENDAS_PERMITIDAS !== 'undefined') {
                value1 = TIENDAS_PERMITIDAS.map(tienda => {
                    const value18 = String(tienda.codalmacen || '').trim();
                    const value19 = String(tienda.nombrealmacen || '').trim();
                    return value18 ? (value19 ? value18 + ' - ' + value19 : value18) : '';
                }).filter(Boolean);
                value2 = false;
                if (value16 !== value3 || element4.hidden) return;
                const value20 = inputValue5.toLocaleLowerCase('es');
                const filteredItems2 = value1.filter(value =>
                    value.toLocaleLowerCase('es').includes(value20)
                );
                renderOptions(
                    ordenarValores(filteredItems2, element17 ? element17.value : 'asc'),
                    [...seenItems1],
                    inputValue4
                );
                return;
            }
            const searchParams1 = new URLSearchParams(new FormData(element3));
            searchParams1.set('field', inputValue4);
            searchParams1.set('search', inputValue5);
            const response1 = await fetch('/exhibicion_DT/exhibiciontotal/opciones.php?' + searchParams1.toString(), {
                credentials: 'same-origin'
            });
            if (!response1.ok) throw new Error('No se pudieron consultar los valores del filtro.');
            const responseData1 = await response1.json();
            if (value16 !== value3 || element4.hidden || inputValue4 !== element7.value) return;
            value1 = Array.isArray(responseData1.values) ? responseData1.values.map(String) : [];
            value2 = Boolean(responseData1.has_more);
            rememberExcelOptions(value17, inputValue5, {
                values: value1,
                hasMore: value2
            });
            const inputValue6 = ordenarValores(value1, element17 ? element17.value : 'asc');
            renderOptions(inputValue6, [...seenItems1], inputValue4);
        } catch (error1) {
            if (value16 !== value3 || element4.hidden) return;
            element9.textContent = error1.message || 'No se pudieron cargar los valores del filtro.';
        }
    }

    function openExcelMenu(btn) {
    if (!element4) return;

    const value21 = btn.dataset.field || '';
    const value22 = btn.dataset.label || 'Filtrar';

    element7.value = value21;
    element5.textContent = 'Filtrar ' + value22;
    const element22 = element3.querySelector('[name="orden_campo"]')?.value;
    const element23 = element3.querySelector('[name="orden_dir"]')?.value;
    element17.value = element22 === value21 && element23 === 'desc' ? 'desc' : 'asc';
    element8.value = '';
    value1 = [];
    value2 = false;
    value5 = false;
    seenItems1 = new Set(getSelectedValues(value21));

    




    const boundedValue1 = Math.min(370, window.innerWidth - 24);
    const boundedValue2 = Math.min(430, window.innerHeight - 26);

    let value23 = (window.innerWidth - boundedValue1) / 2;
    let top = (window.innerHeight - boundedValue2) / 2;

    




    if (value23 < 12) {
        value23 = 12;
    }

    if (top < 12) {
        top = 12;
    }

    element4.style.width = boundedValue1 + 'px';
    element4.style.left = value23 + 'px';
    element4.style.top = top + 'px';

    element4.hidden = false;
    loadExcelOptions();

    setTimeout(() => element8.focus(), 30);
}
    




    if (element17) {
        element17.addEventListener('change', function () {
            const inputValue7 = element7.value;

            if (!inputValue7) return;

            const inputValue8 = ordenarValores(value1, element17.value);
            renderOptions(inputValue8, [...seenItems1], inputValue7);
        });
    }

    




    document.querySelectorAll('.js-only-number').forEach(function (input) {
        input.addEventListener('input', function () {
            this.value = sanitizeOnlyNumber(this.value).slice(0, 5);
        });

        input.addEventListener('paste', function (e) {
            e.preventDefault();
        });

        input.addEventListener('keypress', function (e) {
            if (!/[0-9]/.test(e.key)) {
                e.preventDefault();
            }
        });
    });

    




    document.querySelectorAll('.js-form-guardar').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const value24 = form.getAttribute('id');
            const element24 = document.querySelector('input[name="exhibicion"][form="' + value24 + '"]');

            if (!element24 || !/^\d+$/.test(element24.value.trim())) {
                e.preventDefault();
                alert('La exhibición debe llevar solo números.');

                if (element24) {
                    element24.focus();
                }

                return;
            }

            const btn = document.querySelector('.js-btn-guardar[form="' + value24 + '"]');
            loading(btn, '<i class="bi bi-hourglass-split"></i>');
        });
    });

    









    if (element14) {
        element14.addEventListener('change', function () {
            document.querySelectorAll('.js-check-masivo').forEach(chk => {
                chk.checked = element14.checked;
            });
        });
    }

    document.querySelectorAll('.js-check-masivo').forEach(chk => {
        chk.addEventListener('change', function () {
            if (!element14) return;

            const elements2 = document.querySelectorAll('.js-check-masivo').length;
            const elements3 = document.querySelectorAll('.js-check-masivo:checked').length;

            element14.checked = elements2 > 0 && elements3 === elements2;
            element14.indeterminate = elements3 > 0 && elements3 < elements2;
        });
    });

    // Preparar los registros seleccionados antes de enviarlos al servidor.
    if (element13) {
        element13.addEventListener('submit', function (e) {
            e.preventDefault();

            const itemCount1 = Array.from(
                document.querySelectorAll('.js-check-masivo:checked')
            );

            if (itemCount1.length === 0) {
                alert('Seleccione al menos un registro para guardar.');
                return;
            }

            const itemCount2 = [];

            for (const value25 of itemCount1) {
                const value26 = value25.closest('tr');

                if (!value26) {
                    alert('No se pudo identificar una fila seleccionada.');
                    return;
                }

                const value27 = value25.name.match(
                    /^items\[(\d+)\]\[seleccionado\]$/
                );

                if (!value27) {
                    alert('No se pudo identificar el índice de una fila seleccionada.');
                    return;
                }

                const value28 = value27[1];

                const value29 = function (campo) {
                    const element25 = value26.querySelector(
                        '[name="items[' + value28 + '][' + campo + ']"]'
                    );

                    return element25 ? element25.value.trim() : '';
                };

                const element26 = value26.querySelector('.js-exhibicion-masivo');

                if (!element26) {
                    alert('No se encontró el campo Exhibición en una fila seleccionada.');
                    return;
                }

                const inputValue9 = element26.value.trim();

                if (inputValue9 === '' || !/^\d+$/.test(inputValue9)) {
                    alert('Todos los registros seleccionados deben tener Exhibición numérica.');
                    element26.focus();
                    return;
                }

                const options1 = {
                    seleccionado: '1',
                    region: value29('region'),
                    codalmacen: value29('codalmacen'),
                    codarticulo: value29('codarticulo'),
                    codbarras: value29('codbarras'),
                    plu: value29('plu'),
                    uxc: value29('uxc'),
                    exhibicion: inputValue9
                };

                if (options1.codalmacen === '' || options1.codbarras === '') {
                    alert(
                        'Una fila seleccionada no tiene CODALMACEN o CODBARRAS. ' +
                        'No se enviará el guardado.'
                    );
                    return;
                }

                itemCount2.push(options1);
            }

            const inputJson = document.getElementById('items_json');

            if (!inputJson) {
                alert('No se encontró el campo interno items_json.');
                return;
            }

            







            inputJson.value = JSON.stringify(itemCount2);

            






            document.querySelectorAll('[name^="items["]').forEach(function (campo) {
                campo.disabled = true;
            });

            if (element15) {
                loading(
                    element15,
                    '<i class="bi bi-hourglass-split"></i>' +
                    '<span>Guardando ' + itemCount2.length + '...</span>'
                );
            }

            if (element16) {
                loading(
                    element16,
                    '<i class="bi bi-hourglass-split"></i>' +
                    '<span>Guardando ' + itemCount2.length + '...</span>'
                );
            }

            HTMLFormElement.prototype.submit.call(element13);
        });
    }

    




    document.querySelectorAll('.js-page-link').forEach(function (link) {
        link.addEventListener('click', function () {
            link.style.pointerEvents = 'none';
            link.style.opacity = '.75';
        });
    });

    




    if (element1 && element2) {
        element1.addEventListener('change', function () {
            element2.submit();
        });
    }

    




    elements1.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            openExcelMenu(btn);
        });
    });

    




    if (element8) {
        element8.addEventListener('input', function () {
            clearTimeout(value4);
            value5 = false;
            element10.checked = false;
            value3++;
            if (element7.value === 'codalmacen') {
                loadExcelOptions();
                return;
            }
            if (renderCachedExcelOptions()) return;
            value4 = setTimeout(loadExcelOptions, 180);
        });
    }

    




    if (element10) {
        element10.addEventListener('change', function () {
            value5 = this.checked;
            document.querySelectorAll('.excel-option').forEach(option => {
                const check = option.querySelector('.excel-option-check');
                if (!check) return;
                check.checked = element10.checked;
                const value = element7.value === 'codalmacen'
                    ? check.value.split(' - ')[0].trim()
                    : check.value;
                if (check.checked) seenItems1.add(value);
                else seenItems1.delete(value);
            });
        });
    }

    if (element9) {
        element9.addEventListener('change', function (event) {
            if (event.target.matches('.excel-option-check')) {
                value5 = false;
                const value = element7.value === 'codalmacen'
                    ? event.target.value.split(' - ')[0].trim()
                    : event.target.value;
                if (event.target.checked) seenItems1.add(value);
                else seenItems1.delete(value);
            }
        });
    }

    




    if (element11) {
        element11.addEventListener('click', function () {
            const field = element7.value;
            const input = getFilterInput(field);

            if (!input || !element3) return;

            const selected = [...seenItems1];

            if (value5) {
                const textoBuscado = element8.value.trim();
                input.value = textoBuscado !== '' ? '__LIKE__' + textoBuscado : '';
            } else if (selected.length > 0) {
                input.value = selected.join('||');
            } else {
                const textoBuscado = element8.value.trim();
                input.value = textoBuscado !== '' ? '__LIKE__' + textoBuscado : '';
            }

            const inputOrdenCampo = document.getElementById('orden_campo');
            const inputOrdenDir = document.getElementById('orden_dir');

            if (inputOrdenCampo && inputOrdenDir && element17) {
                inputOrdenCampo.value = field;
                inputOrdenDir.value = element17.value;
            }

            element3.submit();
        });
    }

    




    if (element12) {
        element12.addEventListener('click', function () {
            const field = element7.value;
            const input = getFilterInput(field);

            if (!input || !element3) return;

            input.value = '';
            element3.submit();
        });
    }

    




    if (element6) {
        element6.addEventListener('click', closeExcelMenu);
    }

    document.addEventListener('click', function (e) {
        if (!element4 || element4.hidden) return;

        if (!element4.contains(e.target) && !e.target.closest('.exh-filter-trigger')) {
            closeExcelMenu();
        }
    });

    window.addEventListener('resize', closeExcelMenu);

    if (element4) {
        element4.addEventListener('wheel', function (e) {
            e.stopPropagation();
        });
    }

    if (element9) {
        element9.addEventListener('wheel', function (e) {
            e.stopPropagation();
        });
    }

});
</script>

<link rel="stylesheet" href="exhibiciontotal/css/exhibicion.css?v=20261117">

<script>
(function () {
    function initExhView() {
        const element27 = document.querySelector('.exh-wrap');
        if (!element27 || element27.dataset.viewReady === '1') return;
        element27.dataset.viewReady = '1';
        const element28 = document.getElementById('exhQuickSearch');
        const element29 = document.getElementById('exhTheme');
        const element30 = document.getElementById('exhZoomValue');
        const element31 = element27.querySelector('.exh-table');
        let boundedValue3 = Math.max(0.8, Math.min(1.3, Number(localStorage.getItem('exh_zoom') || 1)));
        const value30 = ['blue','indigo','green','slate'];
        const value31 = localStorage.getItem('exh_theme') || 'blue';
        element27.dataset.theme = value30.includes(value31) ? value31 : 'blue';
        if (element29) element29.value = element27.dataset.theme;
        function renderZoom() {
            element27.style.setProperty('--exh-zoom', String(boundedValue3));
            if (element30) element30.textContent = Math.round(boundedValue3 * 100) + '%';
        }
        renderZoom();
        document.getElementById('exhZoomIn')?.addEventListener('click', () => {
            boundedValue3 = Math.min(1.3, Math.round((boundedValue3 + 0.1) * 10) / 10);
            localStorage.setItem('exh_zoom', String(boundedValue3)); renderZoom();
        });
        document.getElementById('exhZoomOut')?.addEventListener('click', () => {
            boundedValue3 = Math.max(0.8, Math.round((boundedValue3 - 0.1) * 10) / 10);
            localStorage.setItem('exh_zoom', String(boundedValue3)); renderZoom();
        });
        element29?.addEventListener('change', () => {
            element27.dataset.theme = element29.value;
            localStorage.setItem('exh_theme', element29.value);
        });
        
        element28?.addEventListener('input', () => {
            if (!element31) return;
            const inputValue10 = element28.value.trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
            element31.querySelectorAll('tbody tr').forEach(tr => {
                const raw = tr.textContent + ' ' + Array.from(tr.querySelectorAll('input[type="text"]')).map(i => i.value).join(' ');
                const value32 = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
                tr.hidden = !value32.includes(inputValue10);
            });
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initExhView);
    else initExhView();
})();
</script>
