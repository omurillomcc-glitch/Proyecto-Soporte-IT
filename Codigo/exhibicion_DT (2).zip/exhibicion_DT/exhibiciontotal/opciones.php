<?php
declare(strict_types=1);

session_name('APP_EXHIBICION');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_module_access('modulo1');
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

$fields = [
    'referencia' => 'REFERENCIA',
    'descripcion' => 'DESCRIPCION',
    'departamento' => 'DEPARTAMENTO',
    'seccion' => 'SECCION',
    'familia' => 'FAMILIA',
    'codbarras' => 'CODBARRAS',
    'plu' => 'PLU',
    'inventario_tienda' => 'INVENTARIO_TIENDA',
    'exhibicion' => 'EXHIBICION',
    'uxc' => 'UXC',
    'codarticulo' => 'CODARTICULO',
    'codalmacen' => 'CODALMACEN',
];

$field = (string)($_GET['field'] ?? '');
if (!isset($fields[$field])) {
    http_response_code(400);
    echo json_encode(['values' => [], 'has_more' => false]);
    exit;
}

try {
    $filters = exhibicion_filters_from_get();
    $filters[$field] = '';

    $search = trim((string)($_GET['search'] ?? ''));
    if (strlen($search) > 100) {
        throw new InvalidArgumentException('La búsqueda del filtro es demasiado larga.');
    }

    $aggregateFields = ['region', 'inventario_tienda', 'exhibicion', 'uxc'];
    $hasAggregateFilters = false;
    foreach (['inventario_tienda', 'exhibicion', 'uxc'] as $aggregateField) {
        if (trim((string)$filters[$aggregateField]) !== '') {
            $hasAggregateFilters = true;
            break;
        }
    }

    $searchApplied = false;
    if (!in_array($field, $aggregateFields, true) && !$hasAggregateFilters) {
        $ctx = exhibicion_context_from_session();
        $dbOrigen = $ctx['db'];
        $mysqlConn = $GLOBALS['exhibicion_mysql_conn'] ?? null;
        if (!$mysqlConn instanceof mysqli) {
            throw new RuntimeException('No se encontró una conexión mysqli válida.');
        }

        [$scopeSql, $params] = exhibicion_build_scope_clause($ctx, $mysqlConn, $filters);
        $codAlmacenSql = exhibicion_sql_codalmacen('S.CODALMACEN');
        $whereSql = "
            WHERE 1 = 1
                {$scopeSql}
                AND {$codAlmacenSql} LIKE '[0-9][0-9]'
                AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')))) <> 'PACKING ARTICULO'
                AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
                AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%ARTICULOS DE GASTO%'
                AND UPPER(LTRIM(RTRIM(ISNULL(SC.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
                AND UPPER(LTRIM(RTRIM(ISNULL(F.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
        ";

        if (trim((string)$filters['region']) !== '' &&
            strtoupper(trim((string)$filters['region'])) !== strtoupper((string)$ctx['region'])) {
            $whereSql .= ' AND 1 = 0 ';
        }

        $dimensionFilters = [
            'codalmacen' => $codAlmacenSql,
            'referencia' => "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')",
            'descripcion' => "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')",
            'departamento' => "ISNULL(D.DESCRIPCION, '')",
            'seccion' => "ISNULL(SC.DESCRIPCION, '')",
            'familia' => "ISNULL(F.DESCRIPCION, '')",
            'codbarras' => "REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')",
            'plu' => "UPPER(ISNULL(CONVERT(VARCHAR(100), CL.PLU), ''))",
            'codarticulo' => 'UPPER(CONVERT(VARCHAR(100), S.CODARTICULO))',
        ];
        foreach ($dimensionFilters as $filterField => $filterExpression) {
            exhibicion_add_excel_exact_filter(
                $whereSql,
                $params,
                $filterExpression,
                $filters[$filterField]
            );
        }

        $valueExpressions = [
            'referencia' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), ''))))",
            'descripcion' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), ''))))",
            'departamento' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), ISNULL(D.DESCRIPCION, ''))))",
            'seccion' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), ISNULL(SC.DESCRIPCION, ''))))",
            'familia' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), ISNULL(F.DESCRIPCION, ''))))",
            'codbarras' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), ''))))",
            'plu' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), ISNULL(CONVERT(VARCHAR(100), CL.PLU), ''))))",
            'codarticulo' => "LTRIM(RTRIM(CONVERT(NVARCHAR(255), S.CODARTICULO)))",
            'codalmacen' => "CONCAT({$codAlmacenSql}, N' - ', LTRIM(RTRIM(CONVERT(NVARCHAR(255), ISNULL(ALM.NOMBREALMACEN, '')))))",
        ];
        $valueExpression = $valueExpressions[$field];
        if ($search !== '') {
            $escapedSearch = strtr($search, ['~' => '~~', '%' => '~%', '_' => '~_', '[' => '~[']);
            $whereSql .= " AND {$valueExpression} COLLATE DATABASE_DEFAULT LIKE ? COLLATE DATABASE_DEFAULT ESCAPE '~'";
            $params[] = '%' . $escapedSearch . '%';
            $searchApplied = true;
        }

        $sql = "
            SELECT DISTINCT TOP (301) {$valueExpression} AS VALOR
            FROM {$dbOrigen}.dbo.STOCKS S
            INNER JOIN {$dbOrigen}.dbo.ARTICULOSLIN AA
                ON S.CODARTICULO = AA.CODARTICULO
               AND S.TALLA = AA.TALLA
               AND S.COLOR = AA.COLOR
            INNER JOIN {$dbOrigen}.dbo.ARTICULOS A
                ON A.CODARTICULO = AA.CODARTICULO
               AND A.DESCATALOGADO = 'F'
            LEFT JOIN {$dbOrigen}.dbo.ALMACEN ALM
                ON ALM.CODALMACEN = S.CODALMACEN
            LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL
                ON CL.CODARTICULO = S.CODARTICULO
            LEFT JOIN {$dbOrigen}.dbo.DEPARTAMENTO D
                ON D.NUMDPTO = A.DPTO
            LEFT JOIN {$dbOrigen}.dbo.SECCIONES SC
                ON SC.NUMDPTO = A.DPTO
               AND SC.NUMSECCION = A.SECCION
            LEFT JOIN {$dbOrigen}.dbo.FAMILIAS F
                ON F.NUMDPTO = A.DPTO
               AND F.NUMSECCION = A.SECCION
               AND F.NUMFAMILIA = A.FAMILIA
            {$whereSql}
        ";
    } else {
        [$baseSql, $params] = exhibicion_build_query($filters);
        $column = $fields[$field];
        $valueExpression = $field === 'codalmacen'
            ? "CONCAT(LTRIM(RTRIM(CONVERT(NVARCHAR(255), X.CODALMACEN))), N' - ', LTRIM(RTRIM(CONVERT(NVARCHAR(255), X.ALMACEN))))"
            : "LTRIM(RTRIM(CONVERT(NVARCHAR(255), X.[$column])))";
        $sql = "SELECT DISTINCT TOP (301) {$valueExpression} AS VALOR FROM ({$baseSql}) X";
    }

    if ($search !== '' && !$searchApplied) {
        $escapedSearch = strtr($search, ['~' => '~~', '%' => '~%', '_' => '~_', '[' => '~[']);
        $sql .= " WHERE {$valueExpression} COLLATE DATABASE_DEFAULT LIKE ? COLLATE DATABASE_DEFAULT ESCAPE '~'";
        $params[] = '%' . $escapedSearch . '%';
    }
    $sql .= ' ORDER BY VALOR';

    $stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $sql, $params, ['QueryTimeout' => 300]);
    if ($stmt === false) {
        error_log('SQL opciones de Exhibición: ' . print_r(sqlsrv_errors(), true));
        throw new RuntimeException('No se pudieron consultar las opciones del filtro.');
    }

    $values = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $values[] = (string)($row['VALOR'] ?? '');
    }
    sqlsrv_free_stmt($stmt);

    $hasMore = count($values) > 300;
    if ($hasMore) {
        array_pop($values);
    }
    echo json_encode(
        ['values' => $values, 'has_more' => $hasMore],
        JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
} catch (Throwable $error) {
    error_log('Opciones de filtro de Exhibición: ' . $error->getMessage());
    http_response_code($error instanceof InvalidArgumentException ? 400 : 500);
    echo json_encode(['values' => [], 'has_more' => false]);
}
