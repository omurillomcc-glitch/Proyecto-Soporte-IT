<?php
declare(strict_types=1);

session_name('APP_EXHIBICION');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_exhibicion.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_module_access('modulo1');

function exhibicion_csv_cell(mixed $value): string
{
    $text = (string)($value ?? '');
    if (preg_match('/^\s*[=+\-@]/u', $text)) {
        return "'" . $text;
    }
    return $text;
}

try {
    $filters = exhibicion_filters_from_get();
    [$baseSql, $baseParams, $ctx] = exhibicion_build_query($filters);

    $sql = $baseSql . '
        ORDER BY ' . exhibicion_order_by_from_get($_GET);
    $params = $baseParams;
    $stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $sql, $params, ['QueryTimeout' => 300]);
    if ($stmt === false) {
        error_log('SQL exportación Exhibición: ' . print_r(sqlsrv_errors(), true));
        throw new RuntimeException('No se pudieron consultar los resultados para exportar.');
    }

    $role = strtolower(trim((string)($ctx['rol'] ?? '')));
    $columns = [
        'REFERENCIA' => 'Referencia',
        'DESCRIPCION' => 'Descripción',
        'DEPARTAMENTO' => 'Departamento',
        'SECCION' => 'Sección',
        'FAMILIA' => 'Familia',
        'CODBARRAS' => 'Cod Barras',
        'PLU' => 'PLU',
        'INVENTARIO_TIENDA' => 'Inventario Tienda',
        'EXHIBICION' => 'Exhibición',
        'UXC' => 'UXC',
    ];
    if (in_array($role, ['admin_zona', 'super_admin'], true)) {
        $columns['ALMACEN'] = 'Almacén';
    }

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="exhibicion_filtrada_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store, no-cache, must-revalidate');

    $output = fopen('php://output', 'w');
    if ($output === false) {
        sqlsrv_free_stmt($stmt);
        throw new RuntimeException('No se pudo abrir la descarga CSV.');
    }

    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, array_merge(['N°'], array_values($columns)));
    $rowNumber = 0;
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $line = [(string)++$rowNumber];
        foreach (array_keys($columns) as $column) {
            $value = $row[$column] ?? '';
            $line[] = in_array($column, ['INVENTARIO_TIENDA', 'EXHIBICION', 'UXC'], true)
                ? (string)$value
                : exhibicion_csv_cell($value);
        }
        fputcsv($output, $line);
    }

    sqlsrv_free_stmt($stmt);
    fclose($output);
} catch (Throwable $error) {
    error_log('Exportación CSV de Exhibición: ' . $error->getMessage());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=UTF-8');
    }
    echo 'No fue posible generar la exportación.';
}
