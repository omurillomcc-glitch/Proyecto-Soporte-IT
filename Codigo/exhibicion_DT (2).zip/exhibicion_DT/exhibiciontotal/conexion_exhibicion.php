
<?php


// . UBICACIÓN DEL ARCHIVO PRIVADO

$rutaPrivada = dirname(__DIR__, 3)
    . DIRECTORY_SEPARATOR . 'privado_exhibicion'
    . DIRECTORY_SEPARATOR . 'credenciales.php';

// . VERIFICAR CONFIGURACIÓN

if (!is_file($rutaPrivada) || !is_readable($rutaPrivada)) {

    error_log('No se encontró credenciales.php');

    http_response_code(503);
    exit('No se pudo cargar la configuración SQL Server.');
}

$configuracion = require $rutaPrivada;

$sql = $configuracion['sqlserver'] ?? null;

if (!is_array($sql)) {

    http_response_code(503);
    exit('Configuración SQL Server incompleta.');
}

// . OBTENER DATOS DE CONEXIÓN

$servidor = trim((string) ($sql['servidor'] ?? ''));
$base     = trim((string) ($sql['base'] ?? ''));
$usuario  = trim((string) ($sql['usuario'] ?? ''));
$clave    = (string) ($sql['clave'] ?? '');

if ($servidor === '' || $base === '') {

    http_response_code(503);
    exit('Falta configurar el servidor o la base de datos.');
}

// . VERIFICAR EXTENSIÓN SQL SERVER

if (!function_exists('sqlsrv_connect')) {

    error_log('La extensión SQLSRV no está habilitada.');

    http_response_code(503);
    exit('No se pudo iniciar SQL Server.');
}

// . OPCIONES DE CONEXIÓN

$connectionOptions = [

    'Database' => $base,

    'CharacterSet' => 'UTF-8',

    'Encrypt' => true,

    // Certificado interno/autofirmado mientras se instala una CA de confianza.
    'TrustServerCertificate' => true,

    'LoginTimeout' => 10

];

// Si existe usuario y contraseña, usa autenticación SQL.
// En caso contrario, utiliza autenticación de Windows.

if ($usuario !== '' && $clave !== '') {

    $connectionOptions['UID'] = $usuario;
    $connectionOptions['PWD'] = $clave;

} elseif ($usuario !== '' || $clave !== '') {

    http_response_code(503);
    exit('Las credenciales SQL Server están incompletas.');
}

// CONECTAR A SQL SERVER

$sqlsrv_conn_exhibicion = sqlsrv_connect(
    $servidor,
    $connectionOptions
);

// 8. VALIDAR CONEXIÓN

if ($sqlsrv_conn_exhibicion === false) {

    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);

    if (is_array($errores)) {

        foreach ($errores as $error) {

            error_log(
                'SQL Server [' .
                ($error['SQLSTATE'] ?? 'N/A') .
                '] Código ' .
                ($error['code'] ?? 'N/A') .
                ': ' .
                ($error['message'] ?? 'Error desconocido')
            );
        }
    }

    http_response_code(503);

    exit('No se pudo conectar con SQL Server.');
}


