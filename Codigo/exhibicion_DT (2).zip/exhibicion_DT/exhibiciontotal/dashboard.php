<?php

declare(strict_types=1);

/* INICIAR SESIÓN */
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

/* ASEGURAR CONEXIÓN GLOBAL */
if (isset($conn) && $conn instanceof mysqli) {
    $GLOBALS['conn'] = $conn;
}

require_module_access('dashboard');
$me = me();


/* HELPERS GENERALES */
function h(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function db_conn(): mysqli
{
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
        return $GLOBALS['conn'];
    }

    http_response_code(500);
    exit('<div class="alert alert-danger m-3">No hay conexión a la base de datos.</div>');
}

function table_exists(mysqli $conn, string $table): bool
{
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res instanceof mysqli_result && $res->num_rows > 0;
}

function column_exists(mysqli $conn, string $table, string $column): bool
{
    $table  = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
    return $res instanceof mysqli_result && $res->num_rows > 0;
}

function pick_first_existing_column(mysqli $conn, string $table, array $candidates): string
{
    foreach ($candidates as $col) {
        if (column_exists($conn, $table, $col)) {
            return $col;
        }
    }

    return '';
}

function fetch_rows(mysqli $conn, string $sql, array $params = [], string $types = ''): array
{
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return [];
    }

    if ($params) {
        if ($types === '') {
            foreach ($params as $p) {
                $types .= is_int($p) ? 'i' : 's';
            }
        }

        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        $stmt->close();
        return [];
    }

    $res = $stmt->get_result();

    if (!$res) {
        $stmt->close();
        return [];
    }

    $rows = $res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $rows ?: [];
}

function fetch_scalar(mysqli $conn, string $sql, array $params = [], string $types = ''): mixed
{
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return null;
    }

    if ($params) {
        if ($types === '') {
            foreach ($params as $p) {
                $types .= is_int($p) ? 'i' : 's';
            }
        }

        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        $stmt->close();
        return null;
    }

    $res = $stmt->get_result();

    if (!$res) {
        $stmt->close();
        return null;
    }

    $row = $res->fetch_row();
    $stmt->close();

    return $row[0] ?? null;
}

function fetch_one_int(mysqli $conn, string $sql, array $params = [], string $types = ''): int
{
    return (int)(fetch_scalar($conn, $sql, $params, $types) ?? 0);
}

/* HELPERS PARA AUDITORÍA Y TIENDAS */
function extract_store_code_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/CODALMACEN:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    if (preg_match('/TIENDA:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    return '';
}

function extract_zone_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/ZONA:\s*([^|]+)/i', $detalle, $m)) {
        return strtoupper(trim((string)$m[1]));
    }

    return '';
}

function extract_region_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/REGION:\s*([^|]+)/i', $detalle, $m)) {
        return normalizar_region_dashboard((string)$m[1]);
    }

    return '';
}

function extract_codarticulo_from_detail(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (preg_match('/CODARTICULO:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    if (preg_match('/CODIGO:\s*([A-Z0-9\-]+)/i', $detalle, $m)) {
        return strtoupper(trim($m[1]));
    }

    return '';
}

function region_label_from_pais_code(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}

function normalizar_region_dashboard(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $region,
    };
}

/* ACCIONES DE EXHIBICIÓN PARA DASHBOARD */
function dashboard_exhibicion_actions(): array
{
    return [

        /* EXHIBICIÓN NORMAL */
        'CREAR_EXHIBICION',
        'EDITAR_EXHIBICION',

        /* MASIVO NORMAL */
        'CREAR_EXHIBICION_MASIVO',
        'EDITAR_EXHIBICION_MASIVO',
        'GUARDAR_EXHIBICION_MASIVO',

        /* MASIVO SIN STOCK */
        'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO',
    ];
}

function dashboard_sql_placeholders(int $count): string
{
    return implode(',', array_fill(0, max(1, $count), '?'));
}

function dashboard_accion_label(string $accion): string
{
    $accion = strtoupper(trim($accion));

    return match ($accion) {

        'CREAR_EXHIBICION'
            => 'Creó exhibición',

        'EDITAR_EXHIBICION'
            => 'Editó exhibición',

        'CREAR_EXHIBICION_MASIVO'
            => 'Creó exhibición masiva',

        'EDITAR_EXHIBICION_MASIVO'
            => 'Editó exhibición masiva',

        'GUARDAR_EXHIBICION_MASIVO'
            => 'Guardado masivo',

        /* NUEVO SIN STOCK */
        'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO'
            => 'Guardado masivo sin stock',

        default
            => 'Movimiento de exhibición',
    };
}

function dashboard_badge_class(string $accion): string
{
    $accion = strtoupper(trim($accion));

    /* CREAR */
    if (str_contains($accion, 'CREAR')) {
        return 'badge-create';
    }

    /* MASIVO */
    if (
        str_contains($accion, 'MASIVO') ||
        str_contains($accion, 'SIN_STOCK')
    ) {
        return 'badge-masivo';
    }

    /* EDITAR */
    return 'badge-edit';
}

/* LLAVE ÚNICA DE TIENDA */
function dashboard_store_key(string $region, string $zona, string $codalmacen): string
{
    $region     = normalizar_region_dashboard($region);
    $codalmacen = strtoupper(trim($codalmacen));

    return $region . '-' . $codalmacen;
}

/* NORMALIZAR ETIQUETAS DEL DETALLE */
function normalize_label(string $label): string
{
    $label = trim(str_replace('_', ' ', $label));
    $label = preg_replace('/\s+/', ' ', $label) ?? $label;
    $upper = strtoupper($label);

    return match ($upper) {
        'CODALMACEN'  => 'Código tienda',
        'CODARTICULO' => 'Codarticulo',
        'CODBARRAS'   => 'Codbarras',
        'EXHIBICION'  => 'Exhibición',
        'UXC'         => 'UXC',
        'TOTAL'       => 'Total',
        'GUARDADOS'   => 'Guardados',
        'MASIVO'      => 'Masivo',
        'REGION'      => 'Región',
        'ZONA'        => 'Zona',
        'PLU'         => 'Plu',
        default       => ucwords(mb_strtolower($label, 'UTF-8')),
    };
}

function split_detail_lines(string $detalle): array
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return [];
    }

    $parts = preg_split('/\s*\|\s*/u', $detalle) ?: [];
    $out = [];

    foreach ($parts as $part) {
        $part = trim($part);

        if ($part === '') {
            continue;
        }

        if (preg_match('/^\s*([^:]{2,80})\s*:\s*(.+)\s*$/u', $part, $m)) {
            $rawLabel = trim((string)$m[1]);
            $label = normalize_label($rawLabel);
            $value = trim((string)$m[2]);


            /*ocultar del detalle de movimiento region, tienda*/

          if (in_array($label, ['Código tienda', 'Región','Tienda','Codarticulo'], true)) {
    continue;
}

            if (
                stripos($rawLabel, 'Se Actualizó Exhibición.') !== false ||
                stripos($rawLabel, 'Se actualizó exhibición.') !== false ||
                stripos($rawLabel, 'Se Creó Exhibición.') !== false ||
                stripos($rawLabel, 'Se creó exhibición.') !== false
            ) {
                continue;
            }

            if ($label !== '' && $value !== '') {
                $out[] = [
                    'label' => $label,
                    'value' => $value,
                ];
            }
        }
    }

    $orden = [
        
        'Codbarras'   => 1,
        'Plu'         => 2,
        'Exhibición'  => 3,
        'Zona'        => 4,
    ];

    usort($out, function ($a, $b) use ($orden) {
        $oa = $orden[$a['label']] ?? 99;
        $ob = $orden[$b['label']] ?? 99;
        return $oa <=> $ob;
    });

    return $out;
}

function extract_detail_title(string $detalle): string
{
    $detalle = trim($detalle);

    if ($detalle === '') {
        return '';
    }

    if (stripos($detalle, 'Se actualizó exhibición') !== false) {
        return 'Se actualizó exhibición';
    }

    if (stripos($detalle, 'Se creó exhibición') !== false) {
        return 'Se creó exhibición';
    }

    if (stripos($detalle, 'masivo') !== false || stripos($detalle, 'seleccionados') !== false) {
        return 'Guardado masivo de exhibición';
    }

    return 'Movimiento de exhibición';
}

/* FILTRO DE USUARIOS SEGÚN ROL */
function build_user_scope(
    mysqli $conn,
    int $miId,
    string $rol,
    string $paisCode,
    string $zona,
    string $tienda
): array {
    $where  = "1=1";
    $params = [];
    $types  = '';

    $paisCode = strtoupper(trim($paisCode));
    $zona     = strtoupper(trim($zona));
    $tienda   = strtoupper(trim($tienda));

    if ($rol === 'super_admin') {
        if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
            $where .= " AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?";
            $params[] = $paisCode;
            $types   .= 's';
        }

        return [$where, $params, $types];
    }

    if ($rol === 'admin_zona') {
        $hasUsuarioTienda = table_exists($conn, 'usuario_tienda')
            && column_exists($conn, 'usuario_tienda', 'usuario_id')
            && column_exists($conn, 'usuario_tienda', 'codalmacen');

        if ($hasUsuarioTienda) {
            $where .= " AND EXISTS (
                SELECT 1
                FROM usuario_tienda ut_admin
                INNER JOIN usuario_tienda ut_user
                    ON CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.pais, ''), 'HN'))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.zona, ''), ''))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_admin.codalmacen, ''), '')))
                    ) = CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.pais, ''), 'HN'))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.zona, ''), ''))),
                        '-',
                        UPPER(TRIM(COALESCE(NULLIF(ut_user.codalmacen, ''), '')))
                    )
                WHERE ut_admin.usuario_id = ?
                  AND ut_user.usuario_id = u.id
            )";

            $params[] = $miId;
            $types   .= 'i';
        }

        if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
            $where .= " AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?";
            $params[] = $paisCode;
            $types   .= 's';
        }

        return [$where, $params, $types];
    }

    if ($rol === 'tienda') {
        /** Usuarios ligados exactamente a la misma tienda y país. */
        if (!table_exists($conn, 'usuario_tienda')) {
            return ['1=0', [], ''];
        }
        $where .= " AND EXISTS (
            SELECT 1 FROM usuario_tienda ut_usuario
            INNER JOIN usuario_tienda ut_actual
                ON ut_actual.usuario_id = ?
               AND TRIM(LEADING '0' FROM ut_actual.codalmacen)
                   = TRIM(LEADING '0' FROM ut_usuario.codalmacen)
               AND UPPER(TRIM(ut_actual.pais)) = UPPER(TRIM(ut_usuario.pais))
            WHERE ut_usuario.usuario_id = u.id
        )";
        $params[] = $miId;
        $types .= 'i';
        if ($paisCode !== '' && column_exists($conn, 'usuarios', 'pais_code')) {
            $where .= ' AND UPPER(TRIM(u.pais_code)) = ?';
            $params[] = $paisCode;
            $types .= 's';
        }
        return [$where, $params, $types];
    }

    return [$where, $params, $types];
}

/* FILTRO DE AUDITORÍA SEGÚN ROL */
function build_audit_scope(
    mysqli $conn,
    int $miId,
    string $rol,
    string $paisCode,
    string $zona,
    string $tienda,
    string $accionCol,
    string $zonaCol,
    string $tiendaCol,
    string $detalleCol,
    string $regionCol
): array {

    /* ACCIONES DE EXHIBICIÓN QUE SE TOMAN EN CUENTA */
    $acciones = dashboard_exhibicion_actions();
    $placeholders = dashboard_sql_placeholders(count($acciones));

    $where  = "UPPER(TRIM({$accionCol})) IN ($placeholders)";
    $params = $acciones;
    $types  = str_repeat('s', count($acciones));

    /* NORMALIZAR DATOS DEL USUARIO */
    $rol      = strtolower(trim($rol));
    $paisCode = strtoupper(trim($paisCode));
    $zona     = strtoupper(trim($zona));
    $tienda   = strtoupper(trim($tienda));

    $regionUsuario = region_label_from_pais_code($paisCode);
    $regionUsuario = normalizar_region_dashboard($regionUsuario);

    /* SUPER ADMIN */
    if ($rol === 'super_admin') {

        if ($regionCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(TRIM(COALESCE({$regionCol}, ''))) = ?";
            $params[] = $regionUsuario;
            $types .= 's';
        } elseif ($detalleCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
            $params[] = '%REGION: ' . $regionUsuario . '%';
            $types .= 's';
        } else {
            $where .= " AND 1 = 0";
        }

        return [$where, $params, $types];
    }

    /* ADMIN ZONA */
    if ($rol === 'admin_zona') {

        /* Validar que exista usuario_tienda */
        if (
            !table_exists($conn, 'usuario_tienda') ||
            !column_exists($conn, 'usuario_tienda', 'usuario_id') ||
            !column_exists($conn, 'usuario_tienda', 'codalmacen')
        ) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        /* Obtener códigos de tiendas asignadas al admin_zona */
        $codigosTiendas = [];

        $sqlTiendas = "
            SELECT DISTINCT
                UPPER(TRIM(COALESCE(codalmacen, ''))) AS codalmacen
            FROM usuario_tienda
            WHERE usuario_id = ?
              AND TRIM(COALESCE(codalmacen, '')) <> ''
              AND (
                    UPPER(TRIM(COALESCE(pais, ''))) = ?
                    OR UPPER(TRIM(COALESCE(pais, ''))) = ?
                  )
        ";

        $stmtTiendas = $conn->prepare($sqlTiendas);

        if (!$stmtTiendas) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        $stmtTiendas->bind_param(
            'iss',
            $miId,
            $paisCode,
            $regionUsuario
        );

        $stmtTiendas->execute();
        $resTiendas = $stmtTiendas->get_result();

        if ($resTiendas) {
            while ($rowTienda = $resTiendas->fetch_assoc()) {
                $cod = strtoupper(trim((string)($rowTienda['codalmacen'] ?? '')));

                if ($cod !== '') {
                    $codigosTiendas[] = $cod;
                }
            }
        }

        $stmtTiendas->close();

        $codigosTiendas = array_values(array_unique($codigosTiendas));

        /* Si el admin_zona no tiene tiendas, no ve nada. */
        if (empty($codigosTiendas)) {
            return [$where . " AND 1 = 0", $params, $types];
        }

        /* Filtrar por región/país */
        if ($regionCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(TRIM(COALESCE({$regionCol}, ''))) = ?";
            $params[] = $regionUsuario;
            $types .= 's';
        } elseif ($detalleCol !== '' && $regionUsuario !== '') {
            $where .= " AND UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
            $params[] = '%REGION: ' . $regionUsuario . '%';
            $types .= 's';
        } else {
            $where .= " AND 1 = 0";
        }

        /* Filtrar por las tiendas asignadas */
        $placeholdersTiendas = implode(',', array_fill(0, count($codigosTiendas), '?'));

        if ($tiendaCol !== '') {

            $where .= "
                AND (
                    UPPER(TRIM(COALESCE({$tiendaCol}, ''))) IN ($placeholdersTiendas)
            ";

            foreach ($codigosTiendas as $cod) {
                $params[] = $cod;
                $types .= 's';
            }

            /* Si hay detalle/descripcion, también buscamos CODALMACEN ahí. */
            if ($detalleCol !== '') {
                $where .= "
                    OR (
                        TRIM(COALESCE({$tiendaCol}, '')) = ''
                        AND (
                ";

                $condicionesDetalle = [];

                foreach ($codigosTiendas as $cod) {
                    $condicionesDetalle[] = "UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
                    $params[] = '%CODALMACEN: ' . $cod . '%';
                    $types .= 's';
                }

                $where .= implode(' OR ', $condicionesDetalle);

                $where .= "
                        )
                    )
                ";
            }

            $where .= "
                )
            ";

        } elseif ($detalleCol !== '') {

            $where .= " AND (";

            $condicionesDetalle = [];

            foreach ($codigosTiendas as $cod) {
                $condicionesDetalle[] = "UPPER(COALESCE({$detalleCol}, '')) LIKE ?";
                $params[] = '%CODALMACEN: ' . $cod . '%';
                $types .= 's';
            }

            $where .= implode(' OR ', $condicionesDetalle);
            $where .= ")";

        } else {
            $where .= " AND 1 = 0";
        }

        return [$where, $params, $types];
    }

    /** Movimientos de tienda: exigir columnas separadas de región y tienda. */
    if ($rol === 'tienda') {
        if ($tienda === '' || $tiendaCol === '' || $regionCol === '') {
            return [$where . ' AND 1 = 0', $params, $types];
        }
        $paisLargo = $paisCode === 'NI' ? 'NICARAGUA' : 'HONDURAS';
        $where .= " AND UPPER(TRIM(COALESCE({$regionCol}, ''))) IN (?, ?)";
        $params[] = $paisCode;
        $params[] = $paisLargo;
        $types .= 'ss';
        $where .= " AND TRIM(LEADING '0' FROM TRIM(COALESCE({$tiendaCol}, ''))) = ?";
        $normal = ltrim($tienda, '0');
        $params[] = $normal !== '' ? $normal : '0';
        $types .= 's';
        return [$where, $params, $types];
    }

    /* Cualquier otro rol no ve nada */
    $where .= " AND 1 = 0";

      return [$where, $params, $types];
    }

/* FILTRO POR PERIODO */
function build_period_scope(string $periodo, string $fechaCol): array { 
    return match ($periodo) { 
        'hoy' => ["DATE({$fechaCol}) = CURDATE()", [], ''], 
        //  semana actual del calendario (Modo 1 = Lunes a Domingo)
        'semana' => ["YEARWEEK({$fechaCol}, 1) = YEARWEEK(CURDATE(), 1)", [], ''], 
        'mes' => ["MONTH({$fechaCol}) = MONTH(CURDATE()) AND YEAR({$fechaCol}) = YEAR(CURDATE())", [], ''], 
        default => ["1=1", [], ''], 
    }; 
}


/* DATOS DEL USUARIO ACTUAL */
$conn = db_conn();

$miId       = (int)($me['id'] ?? 0);
$rol        = (string)($me['rol'] ?? '');
$usuario    = (string)($me['usuario'] ?? 'Usuario');
$pais_code  = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));
$zona       = strtoupper(trim((string)($me['zona'] ?? '')));
$tienda     = strtoupper(trim((string)($me['tienda'] ?? '')));
$codalmacen = strtoupper(trim((string)($me['codalmacen'] ?? $me['tienda'] ?? '')));

if ($pais_code === '') {
    $pais_code = 'HN';
}

$tiendaScope = $tienda;
if ($rol === 'tienda') {
    require_once dirname(__DIR__) . '/controlusuarios/alcance_tiendas.php';
    $asignadas = at_almacenes_permitidos($conn, $me);
    /** Nunca usar una tienda enviada en sesión si no coincide con la asignación vigente. */
    $tiendaScope = is_array($asignadas) && count($asignadas) === 1 ? (string)$asignadas[0] : '';
}


/* PERIODO */
$periodo = strtolower(trim((string)($_GET['periodo'] ?? 'semana')));

if (!in_array($periodo, ['hoy', 'semana', 'mes'], true)) {
    $periodo = 'semana';
}

/* VALIDAR TABLAS DISPONIBLES */
$usuariosTable      = table_exists($conn, 'usuarios');
$auditoriaTable     = table_exists($conn, 'auditoria') ? 'auditoria' : (table_exists($conn, 'auditoria_logs') ? 'auditoria_logs' : '');
$usuarioTiendaTable = table_exists($conn, 'usuario_tienda');

/* MAPA DE TIENDAS CORREGIDO */
$storeMap = [];

if (
    $usuarioTiendaTable &&
    column_exists($conn, 'usuario_tienda', 'codalmacen') &&
    column_exists($conn, 'usuario_tienda', 'nombrealmacen')
) {
    $rowsTiendas = fetch_rows(
        $conn,
        "SELECT DISTINCT
            COALESCE(NULLIF(pais, ''), 'HN') AS pais,
            COALESCE(NULLIF(zona, ''), '') AS zona,
            codalmacen,
            nombrealmacen
         FROM usuario_tienda
         WHERE COALESCE(TRIM(codalmacen), '') <> ''"
    );

    foreach ($rowsTiendas as $r) {
        $pais = strtoupper(trim((string)($r['pais'] ?? 'HN')));
        $region = region_label_from_pais_code($pais);
        $zonaTienda = strtoupper(trim((string)($r['zona'] ?? '')));
        $cod = strtoupper(trim((string)($r['codalmacen'] ?? '')));
        $nom = trim((string)($r['nombrealmacen'] ?? ''));

        if ($cod === '') {
            continue;
        }

        $key = dashboard_store_key($region, '', $cod);

        $storeMap[$key] = $nom !== '' ? $nom : $cod;
    }
}


/* Indicadores SQL Server: solo lectura; el dashboard original permanece intacto. */
function dash_h($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
function dash_query($db, string $sql, array $params = []): array {
    $st = sqlsrv_query($db, $sql, $params, ['QueryTimeout' => 20]);
    if ($st === false) { error_log('Dashboard SQL: ' . json_encode(sqlsrv_errors(SQLSRV_ERR_ERRORS))); return []; }
    $rows = [];
    while (($r = sqlsrv_fetch_array($st, SQLSRV_FETCH_ASSOC)) !== null) {
        if ($r === false) { $rows = []; break; }
        $rows[] = $r;
    }
    sqlsrv_free_stmt($st);
    return $rows;
}
function dash_num($rows, string $key): int
{
    return (int)($rows[0][$key] ?? 0);
}
function dash_in(array $items): string
{
    return implode(',', array_fill(0, count($items), '?'));
}

$dm_paisCode = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));
$dm_pais = in_array($dm_paisCode, ['NI', 'NICARAGUA', '02'], true) ? 'NICARAGUA' : 'HONDURAS';
$dm_paisNum = $dm_pais === 'NICARAGUA' ? '02' : '01';
$dm_rol = (string)($me['rol'] ?? '');
$dm_uid = (int)($me['id'] ?? 0);
$dm_esPropietario = false;
$dm_accesos = dirname(__DIR__) . '/controlusuarios/accesos_menu.php';
if (is_file($dm_accesos)) {
    require_once $dm_accesos;
    if (function_exists('am_es_propietario') && isset($conn) && $conn instanceof mysqli) {
        $dm_esPropietario = (bool)am_es_propietario($conn, $dm_uid);
    }
}
/* No se aceptan países ni tiendas arbitrarios por GET. */
$dm_tiendas = [];
if (!$dm_esPropietario && $dm_rol !== 'super_admin') {
    require_once dirname(__DIR__) . '/controlusuarios/alcance_tiendas.php';
    if (function_exists('at_almacenes_permitidos') && isset($conn) && $conn instanceof mysqli) {
        $dm_permitidas = at_almacenes_permitidos($conn, $me);
        if (is_array($dm_permitidas)) {
            foreach ($dm_permitidas as $dm_codigo) {
                $dm_codigo = trim((string)$dm_codigo);
                if ($dm_codigo !== '' && preg_match('/^[A-Za-z0-9_-]{1,30}$/D', $dm_codigo)) $dm_tiendas[] = $dm_codigo;
            }
        }
    }
    $dm_tiendas = array_values(array_unique($dm_tiendas));
}
$dm_sinTiendas = !$dm_esPropietario && $dm_rol !== 'super_admin' && !$dm_tiendas;
$dm_datos = ['bloqueados'=>null,'puntas'=>null,'unidades'=>null,'exhibicionPuntas'=>null,
          'exhibicionArticulos'=>null,'exhibicionCantidad'=>null,'cobertura'=>null,'m2s'=>null];
$dm_aviso = [];
if (!isset($sqlsrv_conn_exhibicion)) {
    $dm_conexion = dirname(__DIR__) . '/exhibiciontotal/conexion_exhibicion.php';
    if (is_file($dm_conexion)) { require_once $dm_conexion; }
}
$dm_db = $sqlsrv_conn_exhibicion ?? null;
if (!$dm_db) { $dm_aviso[] = 'No está disponible la conexión de consulta SQL Server.'; }

/* Bloqueo y Puntas son datos por PAÍS, no por tienda. Se ocultan a roles de tienda
   porque sus tablas no tienen CODALMACEN y mostrarlos revelaría datos de otras tiendas. */
$dm_puedeVerGlobal = $dm_esPropietario || $dm_rol === 'super_admin';
if ($dm_db && $dm_puedeVerGlobal) {
    $dm_r = dash_query($dm_db, "SELECT COUNT_BIG(*) AS total FROM vistasMCC.dbo.TB_DT_RCP_ARTICULOBLOQUEOGENERAL WHERE vIdPais = ?", [$dm_paisNum]);
    if ($dm_r) $dm_datos['bloqueados'] = dash_num($dm_r, 'total');
    $dm_r = dash_query($dm_db, "SELECT COUNT_BIG(*) AS articulos, COALESCE(SUM(CONVERT(BIGINT,UNIDADES_PUNTA)),0) AS unidades, COALESCE(SUM(CONVERT(BIGINT,EXHIBICION)),0) AS exhibicion FROM vistasMCC.dbo.TB_DT_RCP_PUNTAS_GONDOLA WHERE UPPER(LTRIM(RTRIM(PAIS))) IN (?,?)", [$dm_pais, $dm_paisNum]);
    if ($dm_r) {
        $dm_datos['puntas'] = dash_num($dm_r, 'articulos');
        $dm_datos['unidades'] = dash_num($dm_r, 'unidades');
        $dm_datos['exhibicionPuntas'] = dash_num($dm_r, 'exhibicion');
    }
} else {
    $dm_aviso[] = 'Puntas Góndolas contiene datos por país; se ocultan para usuarios de tienda para no mostrar datos ajenos.';
}

/* Exhibición sí permite filtrar por almacén. */
if ($dm_db && !$dm_sinTiendas) {
    $dm_where = ' WHERE UPPER(LTRIM(RTRIM(REGION))) IN (?,?)';
    $dm_params = [$dm_pais, $dm_paisNum];
    if (!$dm_esPropietario && $dm_rol !== 'super_admin') {
        $dm_where .= ' AND LTRIM(RTRIM(CONVERT(VARCHAR(30),CODALMACEN))) IN (' . dash_in($dm_tiendas) . ')';
        $dm_params = array_merge($dm_params, $dm_tiendas);
    }
    $dm_r = dash_query($dm_db, 'SELECT COUNT_BIG(*) AS articulos, COALESCE(SUM(TRY_CONVERT(BIGINT,EXHIBICION)),0) AS cantidad FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]' . $dm_where, $dm_params);
    if ($dm_r) {
        $dm_datos['exhibicionArticulos'] = dash_num($dm_r, 'articulos');
        $dm_datos['exhibicionCantidad'] = dash_num($dm_r, 'cantidad');
    }
}

/* Cobertura no almacena país. Solo se muestra para tiendas asignadas; para
   administradores globales se muestra el total general, claramente identificado. */
if ($dm_db && !$dm_sinTiendas) {
    $dm_params = [];
    $dm_where = ' WHERE CODTIENDA IS NOT NULL';
    if (!$dm_esPropietario && $dm_rol !== 'super_admin') {
        $dm_where .= ' AND LTRIM(RTRIM(CONVERT(VARCHAR(30),CODTIENDA))) IN (' . dash_in($dm_tiendas) . ')';
        $dm_params = $dm_tiendas;
    }
    $dm_r = dash_query($dm_db, 'SELECT COUNT_BIG(*) AS tiendas, COALESCE(SUM(TRY_CONVERT(DECIMAL(18,2),M2S)),0) AS m2s FROM vistasMCC.dbo.TB_TD_RCP_COBERTURA_TIENDA' . $dm_where, $dm_params);
    if ($dm_r) {
        $dm_datos['cobertura'] = dash_num($dm_r, 'tiendas');
        $dm_datos['m2s'] = round((float)($dm_r[0]['m2s'] ?? 0), 2);
    }
}
if ($dm_sinTiendas) $dm_aviso[] = 'No se encontraron tiendas autorizadas para consultar.';
if ($dm_esPropietario || $dm_rol === 'super_admin') $dm_aviso[] = 'Cobertura muestra el total general: su tabla no contiene un campo de país.';
if (in_array(null, $dm_datos, true)) $dm_aviso[] = 'Algunos indicadores no están disponibles o están restringidos por permisos.';


/* MÉTRICAS DE USUARIOS */
$totalUsuarios       = 0;
$totalActivos        = 0;
$totalBloqueados     = 0;
$totalAdminsZona     = 0;
$totalUsuariosTienda = 0;
$totalCreados        = 0;
$totalSuperAdmin     = 0;

$roleChartLabels = [];
$roleChartData   = [];

if ($usuariosTable) {
    [$userWhere, $userParams, $userTypes] = build_user_scope(
        $conn,
        $miId,
        $rol,
        $pais_code,
        $zona,
        $tiendaScope
    );

    $totalUsuarios = fetch_one_int(
        $conn,
        "SELECT COUNT(*) FROM usuarios u WHERE {$userWhere}",
        $userParams,
        $userTypes
    );

    if (column_exists($conn, 'usuarios', 'estado')) {
        $totalActivos = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND CAST(COALESCE(u.estado, 0) AS UNSIGNED) = 1",
            $userParams,
            $userTypes
        );

        $totalBloqueados = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND CAST(COALESCE(u.estado, 0) AS UNSIGNED) = 0",
            $userParams,
            $userTypes
        );
    } elseif (column_exists($conn, 'usuarios', 'bloqueado')) {
        $totalBloqueados = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND u.bloqueado = 1",
            $userParams,
            $userTypes
        );

        $totalActivos = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND (u.bloqueado = 0 OR u.bloqueado IS NULL)",
            $userParams,
            $userTypes
        );
    } else {
        $totalActivos = $totalUsuarios;
        $totalBloqueados = 0;
    }

    if (column_exists($conn, 'usuarios', 'rol')) {
        if ($rol === 'super_admin') {
            $totalSuperAdmin = fetch_one_int(
                $conn,
                "SELECT COUNT(*)
                 FROM usuarios u
                 WHERE {$userWhere}
                   AND UPPER(TRIM(u.rol)) = UPPER(TRIM(?))",
                array_merge($userParams, ['super_admin']),
                $userTypes . 's'
            );
        }

        $totalAdminsZona = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND UPPER(TRIM(u.rol)) = 'ADMIN_ZONA'",
            $userParams,
            $userTypes
        );

        $totalUsuariosTienda = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM usuarios u
             WHERE {$userWhere}
               AND UPPER(TRIM(u.rol)) = 'TIENDA'",
            $userParams,
            $userTypes
        );
    }

    $fechaUsuarioCol = pick_first_existing_column($conn, 'usuarios', ['created_at', 'fecha_creacion', 'fecha_registro', 'fecha']);

if ($fechaUsuarioCol !== '') {
    // 1. Llamamos a la función para obtener la condición SQL del período (ej. 'mes')
    [$periodWhere] = build_period_scope($periodo, "u.{$fechaUsuarioCol}");

    $totalCreados = fetch_one_int(
        $conn,
        "SELECT COUNT(*)
         FROM usuarios u
         WHERE {$userWhere}
           AND u.{$fechaUsuarioCol} IS NOT NULL
           AND {$periodWhere}", // 2. Agregamos la condición aquí
        $userParams,
        $userTypes
    );
} else {
    $totalCreados = $totalUsuarios;
}


    if ($rol === 'super_admin') {
        $roleChartLabels = ['Super admin', 'Admins zona', 'Usuarios tienda'];
        $roleChartData   = [
            (int)$totalSuperAdmin,
            (int)$totalAdminsZona,
            (int)$totalUsuariosTienda,
        ];
    } elseif ($rol === 'admin_zona') {
        $roleChartLabels = ['Admins zona', 'Usuarios tienda'];
        $roleChartData   = [
            (int)$totalAdminsZona,
            (int)$totalUsuariosTienda,
        ];
    }
}

/* MÉTRICAS DE AUDITORÍA */
$movimientosExhibicion = 0;
$creadosPeriodo        = 0;
$editadosPeriodo       = 0;
$masivosPeriodo        = 0;
$ultimaFechaMovimiento = '-';
$usuarioTop            = '-';
$tiendaTop             = '-';
$actividadExhibicion   = [];
$barLabels             = [];
$barValues             = [];
$topUsuariosLabels     = [];
$topUsuariosData       = [];
$tiendasConMovimiento  = 0;
$usuariosConMovimiento = 0;

if ($auditoriaTable !== '') {
    $auditFechaCol   = pick_first_existing_column($conn, $auditoriaTable, ['fecha', 'created_at', 'fecha_registro']);
    $auditUsuarioCol = pick_first_existing_column($conn, $auditoriaTable, ['usuario', 'usuario_nombre']);
    $auditAccionCol  = pick_first_existing_column($conn, $auditoriaTable, ['accion', 'actividad']);
    $auditDetalleCol = pick_first_existing_column($conn, $auditoriaTable, ['detalle', 'descripcion']);
    $auditZonaCol    = pick_first_existing_column($conn, $auditoriaTable, ['zona']);
    $auditTiendaCol  = pick_first_existing_column($conn, $auditoriaTable, ['codalmacen', 'tienda']);
    $auditRegionCol  = pick_first_existing_column($conn, $auditoriaTable, ['region']);

    if ($auditFechaCol !== '' && $auditUsuarioCol !== '' && $auditAccionCol !== '') {
        [$auditBaseWhere, $auditBaseParams, $auditBaseTypes] = build_audit_scope(
            $conn,
            $miId,
            $rol,
            $pais_code,
            $zona,
            $tiendaScope,
            $auditAccionCol,
            $auditZonaCol,
            $auditTiendaCol,
            $auditDetalleCol,
            $auditRegionCol
        );

        [$periodWhere, $periodParams, $periodTypes] = build_period_scope($periodo, $auditFechaCol);

        $auditWhere  = "({$auditBaseWhere}) AND ({$periodWhere})";
        $auditParams = array_merge($auditBaseParams, $periodParams);
        $auditTypes  = $auditBaseTypes . $periodTypes;

        $movimientosExhibicion = fetch_one_int(
            $conn,
            "SELECT COUNT(*) FROM {$auditoriaTable} WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $creadosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND (
                    UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
                    OR UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
               )",
            array_merge($auditParams, ['CREAR_EXHIBICION', 'CREAR_EXHIBICION_MASIVO']),
            $auditTypes . 'ss'
        );

        $editadosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND (
                    UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
                    OR UPPER(TRIM({$auditAccionCol})) = UPPER(TRIM(?))
               )",
            array_merge($auditParams, ['EDITAR_EXHIBICION', 'EDITAR_EXHIBICION_MASIVO']),
            $auditTypes . 'ss'
        );

        /* MOVIMIENTOS MASIVOS DEL PERIODO */
        $masivosPeriodo = fetch_one_int(
            $conn,
            "SELECT COUNT(*)
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
               AND UPPER(TRIM({$auditAccionCol})) LIKE '%MASIVO%'",
            $auditParams,
            $auditTypes
        );

        $ultimaFecha = fetch_scalar(
            $conn,
            "SELECT MAX({$auditFechaCol})
             FROM {$auditoriaTable}
             WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $ultimaFechaMovimiento = $ultimaFecha !== null && $ultimaFecha !== '' ? (string)$ultimaFecha : '-';

        $rowsTopUser = fetch_rows(
            $conn,
            "SELECT {$auditUsuarioCol} AS usuario, COUNT(*) AS total
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             GROUP BY {$auditUsuarioCol}
             ORDER BY total DESC, {$auditUsuarioCol} ASC
             LIMIT 1",
            $auditParams,
            $auditTypes
        );

        if (!empty($rowsTopUser)) {
            $usuarioTop = (string)$rowsTopUser[0]['usuario'] . ' (' . (int)$rowsTopUser[0]['total'] . ')';
        }

        $usuariosConMovimiento = fetch_one_int(
            $conn,
            "SELECT COUNT(DISTINCT {$auditUsuarioCol})
             FROM {$auditoriaTable}
             WHERE {$auditWhere}",
            $auditParams,
            $auditTypes
        );

        $actividadExhibicion = fetch_rows(
            $conn,
            "SELECT
                {$auditUsuarioCol} AS usuario,
                {$auditAccionCol} AS accion,
                " . ($auditDetalleCol !== '' ? "{$auditDetalleCol}" : "''") . " AS detalle,
                " . ($auditTiendaCol !== '' ? "{$auditTiendaCol}" : "''") . " AS codalmacen,
                " . ($auditZonaCol !== '' ? "{$auditZonaCol}" : "''") . " AS zona,
                " . ($auditRegionCol !== '' ? "{$auditRegionCol}" : "''") . " AS region,
                {$auditFechaCol} AS fecha_registro
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             ORDER BY {$auditFechaCol} DESC
             LIMIT 20",
            $auditParams,
            $auditTypes
        );

        $storeTotals = [];

        if ($auditTiendaCol !== '') {
            $rowsStores = fetch_rows(
                $conn,
                "SELECT
                    {$auditTiendaCol} AS store_code,
                    " . ($auditZonaCol !== '' ? "{$auditZonaCol}" : "''") . " AS zona,
                    " . ($auditRegionCol !== '' ? "{$auditRegionCol}" : "''") . " AS region,
                    COUNT(*) AS total
                 FROM {$auditoriaTable}
                 WHERE {$auditWhere}
                   AND COALESCE(TRIM({$auditTiendaCol}), '') <> ''
                 GROUP BY
                    {$auditTiendaCol}
                    " . ($auditZonaCol !== '' ? ", {$auditZonaCol}" : "") . "
                    " . ($auditRegionCol !== '' ? ", {$auditRegionCol}" : "") . "
                 ORDER BY total DESC
                 LIMIT 15",
                $auditParams,
                $auditTypes
            );

            foreach ($rowsStores as $r) {
                $code = strtoupper(trim((string)($r['store_code'] ?? '')));
                $zonaStore = strtoupper(trim((string)($r['zona'] ?? '')));
                $regionStore = normalizar_region_dashboard((string)($r['region'] ?? ''));

                if ($code === '') {
                    continue;
                }

                if ($regionStore === '') {
                    $regionStore = region_label_from_pais_code($pais_code);
                }

                $key = dashboard_store_key($regionStore, $zonaStore, $code);
                $name = $storeMap[$key] ?? ($code . ' - ' . $regionStore);

                $storeTotals[$name] = ($storeTotals[$name] ?? 0) + (int)($r['total'] ?? 0);
            }
        } else {
            foreach ($actividadExhibicion as $r) {
                $detalle = (string)($r['detalle'] ?? '');

                $code = extract_store_code_from_detail($detalle);
                $zonaDetalle = extract_zone_from_detail($detalle);
                $regionDetalle = extract_region_from_detail($detalle);

                if ($regionDetalle === '') {
                    $regionDetalle = region_label_from_pais_code($pais_code);
                }

                $key = dashboard_store_key($regionDetalle, $zonaDetalle, $code);
                $name = $storeMap[$key] ?? ($code !== '' ? $code : 'Sin tienda');

                $storeTotals[$name] = ($storeTotals[$name] ?? 0) + 1;
            }
        }

        if (!empty($storeTotals)) {
            arsort($storeTotals);
            $topStores = array_slice($storeTotals, 0, 20, true);
            $barLabels = array_keys($topStores);
            $barValues = array_values($topStores);
            $tiendasConMovimiento = count($topStores);

            $storeNameTop = array_key_first($topStores);

            if ($storeNameTop !== null) {
                $tiendaTop = $storeNameTop . ' (' . (int)$topStores[$storeNameTop] . ')';
            }
        }

        $rowsTopUsers = fetch_rows(
            $conn,
            "SELECT {$auditUsuarioCol} AS usuario, COUNT(*) AS total
             FROM {$auditoriaTable}
             WHERE {$auditWhere}
             GROUP BY {$auditUsuarioCol}
             ORDER BY total DESC, {$auditUsuarioCol} ASC
             LIMIT 9",
            $auditParams,
            $auditTypes
        );

        foreach ($rowsTopUsers as $r) {
            $topUsuariosLabels[] = (string)($r['usuario'] ?? '');
            $topUsuariosData[]   = (int)($r['total'] ?? 0);
        }

        foreach ($actividadExhibicion as &$mov) {
            $detalle = (string)($mov['detalle'] ?? '');

            $codAlmacen = trim((string)($mov['codalmacen'] ?? ''));
            $zonaMov = trim((string)($mov['zona'] ?? ''));
            $regionMov = trim((string)($mov['region'] ?? ''));

            if ($codAlmacen === '') {
                $codAlmacen = extract_store_code_from_detail($detalle);
            }

            if ($zonaMov === '') {
                $zonaMov = extract_zone_from_detail($detalle);
            }

            if ($regionMov === '') {
                $regionMov = extract_region_from_detail($detalle);
            }

            if ($regionMov === '') {
                $regionMov = region_label_from_pais_code($pais_code);
            }

            $codAlmacen = strtoupper(trim($codAlmacen));
            $zonaMov = strtoupper(trim($zonaMov));
            $regionMov = normalizar_region_dashboard($regionMov);

            $key = dashboard_store_key($regionMov, '', $codAlmacen);

            $mov['codalmacen'] = $codAlmacen;
            $mov['zona'] = $zonaMov;
            $mov['region'] = $regionMov;
            $mov['llave_tienda'] = $key;
            $mov['tienda_nombre'] = $codAlmacen !== '' ? ($storeMap[$key] ?? $codAlmacen) : '-';
            $mov['codarticulo_extraido'] = extract_codarticulo_from_detail($detalle);
            $mov['detalle_lines'] = split_detail_lines($detalle);
            $mov['detalle_title'] = extract_detail_title($detalle);
        }

        unset($mov);
    }
}

/* DATOS DE GRÁFICAS */
$userChartLabels = ['Usuarios creados', 'Usuarios bloqueados'];
$userChartData   = [max($totalCreados - $totalBloqueados, 0), $totalBloqueados];

$periodoLabel = match ($periodo) {
    'hoy'    => 'Hoy',
    'semana' => 'Esta semana',
    'mes'    => 'Este mes',
    default  => 'Todo el tiempo' // Cambiado para reflejar el "1=1" de tu función build_period_scope
};

$resumenSuperior = [
    'Total movimientos: ' . number_format($movimientosExhibicion),
    'Masivos: ' . number_format($masivosPeriodo),
    'Última fecha: ' . h($ultimaFechaMovimiento),
    'Tienda más activa: ' . h($tiendaTop),
];

/* Dashboard general: lectura de auditoría de todos los módulos. */
$general = [
    'total'=>0, 'hoy'=>0, 'tiendas'=>0, 'creados'=>0, 'editados'=>0,
    'semana'=>array_fill(0,7,0), 'tiendas_labels'=>[], 'tiendas_valores'=>[],
    'modulos'=>[], 'recientes'=>[], 'disponible'=>false
];
if ($auditoriaTable !== '') {
    $gFecha = pick_first_existing_column($conn,$auditoriaTable,['fecha','created_at','fecha_registro']);
    $gAccion = pick_first_existing_column($conn,$auditoriaTable,['accion','actividad']);
    $gUsuario = pick_first_existing_column($conn,$auditoriaTable,['usuario','usuario_nombre']);
    $gTienda = pick_first_existing_column($conn,$auditoriaTable,['codalmacen','tienda']);
    $gRegion = pick_first_existing_column($conn,$auditoriaTable,['region']);
    $gDetalle = pick_first_existing_column($conn,$auditoriaTable,['detalle','descripcion']);
    if ($gFecha !== '' && $gAccion !== '') {
        $gWhere = '1=1'; $gParams = []; $gTypes = '';
        $regionActiva = normalizar_region_dashboard(region_label_from_pais_code($pais_code));
        $gEsGlobal = $dm_esPropietario || $rol === 'super_admin';
        if ($gRegion !== '') {
            $gWhere .= " AND UPPER(TRIM(COALESCE({$gRegion},''))) IN (?,?)";
            array_push($gParams, $pais_code, $regionActiva);
            $gTypes .= 'ss';
        } else {
            // Sin región verificable no incluir movimientos que puedan pertenecer a otro país.
            $gWhere .= ' AND 1=0';
        }
        if (!$gEsGlobal) {
            if ($gTienda === '' || !$dm_tiendas) {
                $gWhere .= ' AND 1=0';
            } else {
                $gCodigos = array_values(array_unique(array_map(
                    static function($v) { $v= ltrim(trim((string)$v),'0'); return $v === '' ? '0' : $v; },
                    $dm_tiendas
                )));
                $gWhere .= " AND TRIM(LEADING '0' FROM TRIM(COALESCE({$gTienda},''))) IN (" . dashboard_sql_placeholders(count($gCodigos)) . ')';
                foreach ($gCodigos as $gCodigo) { $gParams[] = $gCodigo; $gTypes .= 's'; }
            }
        }
        // Respetar el filtro del dashboard; sin acciones ajenas a la región/tiendas permitidas.
        [$gPeriodSql] = build_period_scope($periodo, $gFecha);
        $gPeriodoWhere = "({$gWhere}) AND ({$gPeriodSql})";
        $gCounts = fetch_rows($conn, "SELECT COUNT(*) AS n,
            SUM(CASE WHEN UPPER({$gAccion}) LIKE '%CREAR%' OR UPPER({$gAccion}) LIKE '%AGREGAR%' THEN 1 ELSE 0 END) AS c,
            SUM(CASE WHEN UPPER({$gAccion}) LIKE '%EDIT%' OR UPPER({$gAccion}) LIKE '%ACTUALIZ%' THEN 1 ELSE 0 END) AS e
            FROM {$auditoriaTable} WHERE {$gPeriodoWhere}", $gParams,$gTypes);
        $general['total'] = (int)($gCounts[0]['n'] ?? 0);
        $general['creados'] = (int)($gCounts[0]['c'] ?? 0);
        $general['editados'] = (int)($gCounts[0]['e'] ?? 0);
        $general['hoy'] = fetch_one_int($conn,"SELECT COUNT(*) FROM {$auditoriaTable} WHERE {$gWhere} AND DATE({$gFecha})=CURDATE()",$gParams,$gTypes);
        if ($gTienda !== '') {
            $general['tiendas'] = fetch_one_int($conn,"SELECT COUNT(DISTINCT {$gTienda}) FROM {$auditoriaTable} WHERE {$gPeriodoWhere} AND TRIM(COALESCE({$gTienda},''))<>''",$gParams,$gTypes);
            $gTops = fetch_rows($conn,"SELECT {$gTienda} AS codigo, COUNT(*) AS n FROM {$auditoriaTable}
              WHERE {$gPeriodoWhere} AND TRIM(COALESCE({$gTienda},''))<>'' GROUP BY {$gTienda} ORDER BY n DESC LIMIT 7",$gParams,$gTypes);
            foreach ($gTops as $gTop) {
                $gCod = trim((string)$gTop['codigo']);
                $gKey = dashboard_store_key($regionActiva,'',$gCod);
                $general['tiendas_labels'][] = ($storeMap[$gKey] ?? 'Tienda ' . $gCod);
                $general['tiendas_valores'][] = (int)$gTop['n'];
            }
        }
        $gDias = fetch_rows($conn,"SELECT WEEKDAY({$gFecha}) AS dia, COUNT(*) AS n FROM {$auditoriaTable}
          WHERE {$gWhere} AND YEARWEEK({$gFecha},1)=YEARWEEK(CURDATE(),1)
          GROUP BY WEEKDAY({$gFecha})",$gParams,$gTypes);
        foreach ($gDias as $gDia) { $gIdx=(int)$gDia['dia']; if ($gIdx>=0 && $gIdx<7) $general['semana'][$gIdx]=(int)$gDia['n']; }
        $gAcciones = fetch_rows($conn,"SELECT {$gAccion} AS accion,COUNT(*) AS n FROM {$auditoriaTable}
          WHERE {$gPeriodoWhere} GROUP BY {$gAccion} ORDER BY n DESC",$gParams,$gTypes);
        foreach ($gAcciones as $gAcc) {
            $gName = strtoupper((string)$gAcc['accion']);
            $gModulo = str_contains($gName,'BLOQUE') ? 'Bloqueo RCP' :
                (str_contains($gName,'COBERTURA') ? 'Cobertura' :
                (str_contains($gName,'EXHIB') ? 'Exhibición' :
                (str_contains($gName,'STOCK') ? 'Stock' : 'Otros')));
            $general['modulos'][$gModulo] = ($general['modulos'][$gModulo]??0)+(int)$gAcc['n'];
        }
        $gRecentWhere = "({$gPeriodoWhere}) AND (
            UPPER(COALESCE({$gAccion},'')) LIKE '%EXHIB%'
            OR UPPER(COALESCE({$gAccion},'')) LIKE '%SIN%STOCK%'
        )";
        $gRecentRows = fetch_rows($conn,"SELECT {$gFecha} AS fecha, {$gAccion} AS accion, " .
            ($gUsuario !== '' ? $gUsuario : "''") . " AS usuario, " .
            ($gTienda !== '' ? $gTienda : "''") . " AS tienda, " .
            ($gDetalle !== '' ? $gDetalle : "''") . " AS detalle
            FROM {$auditoriaTable} WHERE {$gRecentWhere} ORDER BY {$gFecha} DESC LIMIT 12",$gParams,$gTypes);

        foreach ($gRecentRows as &$gRow) {
            $gCodigoTienda = strtoupper(trim((string)($gRow['tienda'] ?? '')));
            if ($gCodigoTienda !== '') {
                $gKeyTienda = dashboard_store_key($regionActiva, '', $gCodigoTienda);
                $gNombreTienda = $storeMap[$gKeyTienda] ?? $gCodigoTienda;
                $gRow['tienda'] = $gNombreTienda;
            }
        }
        unset($gRow);

        $general['recientes'] = $gRecentRows;
        $general['disponible'] = true;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="/exhibicion_DT/bootstrap-5.3.8/css/bootstrap.min.css">

<script src="/exhibicion_DT/chartjs/chart.umd.min.js"></script>
<link rel="stylesheet" href="exhibiciontotal/css/dashboard.css?v=20261109">

</head>
<body>
<main class="dashboard">
<header class="topline">
<div class="heading">
<div>
</div>
</div>
<nav class="periods" aria-label="Periodo">
<a href="/exhibicion_DT/index.php?vista=dashboard&periodo=hoy" class="<?= $periodo==='hoy'?'active':'' ?>
">Hoy</a>
<a href="/exhibicion_DT/index.php?vista=dashboard&periodo=semana" class="<?= $periodo==='semana'?'active':'' ?>
">Semana</a>
<a href="/exhibicion_DT/index.php?vista=dashboard&periodo=mes" class="<?= $periodo==='mes'?'active':'' ?>
">Mes</a>
</nav>
</header>
<div class="scope-line">
<span>País: <strong>
<?= h($dm_pais) ?>

</strong>
</span>
<span class="scope-dot">·</span>
<span>Tiendas autorizadas</span>
<span class="scope-dot">·</span>
<span>Actividad de todos los módulos registrados</span>
</div>
<section class="kpis" aria-label="Indicadores principales">

<?php foreach ([['unidades','Unidades Punta Góndola','Suma','#8744ea','▧'],['exhibicionPuntas','Exhibición Punta Góndola','Suma','#408fe7','▤'],['exhibicionCantidad','Exhibición DT','Suma de EXHIBICION en DT','#18ae9f','◈']] as [$k,$titulo,$descripcion,$color,$icono]): ?>

<article class="kpi" style="--tile:<?= h($color) ?>
">
<div class="kpi-head">
<div class="tag">
<?= h($icono) ?>

</div>
<div>
<div class="kpi-title">
<?= h($titulo) ?>

</div>
<div class="kpi-value">
<?= $dm_datos[$k]===null?'—':number_format((float)$dm_datos[$k],0) ?>

</div>
</div>
</div>
<div class="kpi-foot">
<?= h($descripcion) ?>

</div>
</article>

<?php endforeach; ?>

</section>
<section class="micro">
<div class="micro-item">
<span class="micro-icon">⇄</span>
<div>
<span>Movimientos hoy</span>
<strong>
<?= $general['disponible']?number_format($general['hoy']):'—' ?>

</strong>
</div>
</div>
<div class="micro-item">
<span class="micro-icon">▤</span>
<div>
<span>Tiendas con actividad · <?= h($periodoLabel) ?>

</span>
<strong>
<?= $general['disponible']?number_format($general['tiendas']):'—' ?>

</strong>
</div>
</div>
</section>
<section class="charts">
<article class="panel">
<div class="panelhead">
<div>
<h2>Tiendas más activas</h2>
<p>
<?= h($periodoLabel) ?>
 · Todos los módulos</p>
</div>
</div>
<div class="plot">
<canvas id="gStores" aria-label="Tiendas con más movimientos">
</canvas>
</div>
</article>
<article class="panel">
<div class="panelhead">
<div>
<h2>Actividad semanal</h2>
<p>Lunes a domingo de esta semana</p>
</div>
</div>
<div class="plot">
<canvas id="gWeek" aria-label="Actividad semanal">
</canvas>
</div>
</article>
<article class="panel">
<div class="panelhead">
<div>
<h2>Creaciones vs. editados</h2>
<p>
<?= h($periodoLabel) ?>
 · Todos los módulos</p>
</div>
</div>
<div class="plot plot-ring">
<canvas id="gChanges" aria-label="Proporción de creaciones y ediciones">
</canvas>
</div>
</article>
</section>
<section class="lower">
<article class="panel activity-panel">
<div class="panelhead">
<div>
<h2>Actividad reciente</h2>
<p>Exhibición · <?= h($periodoLabel) ?>

</p>
</div>
<input class="search" type="search" id="activitySearch" placeholder="Buscar movimiento…" aria-label="Buscar movimiento">
</div>

<?php if ($general['recientes']): ?>

<div class="table-scroll">
<table class="recenttable" id="activityTable">
<thead>
<tr>
<th>Usuario</th>
<th>Fecha y hora</th>
<th>Movimiento</th>
<th>Tienda</th>
<th>Artículo</th>
<th>Detalles</th>
</tr>
</thead>
<tbody>

<?php foreach ($general['recientes'] as $entry):
    $rawAction = strtoupper(trim((string)($entry['accion'] ?? '')));
    $actionLabel = (str_contains($rawAction, 'CREAR') || str_contains($rawAction, 'AGREGAR')) ? 'Creación' : ((str_contains($rawAction, 'EDIT') || str_contains($rawAction, 'ACTUALIZ')) ? 'Edición' : 'Movimiento');
    $moduleLabel = str_contains($rawAction, 'EXHIB') ? 'Exhibición' : (str_contains($rawAction, 'BLOQUE') ? 'Bloqueo RCP' : (str_contains($rawAction, 'COBERTURA') ? 'Cobertura' : (str_contains($rawAction, 'STOCK') ? 'Stock' : 'General')));
    $rawDetail = (string)($entry['detalle'] ?? '');
    $artCode = '-';
    if (preg_match('/(?:CODARTICULO|C[ÓO]DIGO ART[ÍI]CULO|ARTICULO)\s*:\s*([A-Z0-9_-]+)/iu', $rawDetail, $match)) $artCode = $match[1];
    $items = [];
    foreach (preg_split('/\s*\|\s*/u', $rawDetail) ?: [] as $part) {
        if (!preg_match('/^\s*([^:]{2,45})\s*:\s*(.+)$/u', trim($part), $field)) continue;
        $key = strtoupper(trim($field[1]));
        if (in_array($key, ['CODBARRAS','PLU','REFERENCIA','UXC','EXHIBICION'], true)) {
            $value = trim($field[2]);
            $name = match ($key) {
                'CODBARRAS' => 'Cód. barras',
                'EXHIBICION' => 'Exhibición',
                'UXC' => 'UXC',
                'PLU' => 'PLU',
                'REFERENCIA' => 'Referencia',
                default => ucfirst(strtolower($key)),
            };

            if ($key === 'EXHIBICION' && preg_match('/^\s*(.+?)\s+A\s+(.+?)\s*$/iu', $value, $cambio)) {
                $antes = trim($cambio[1]);
                $ahora = trim($cambio[2]);
                $value = 'Antes ' . $antes . ' · Ahora ' . $ahora;
            }

            $items[] = ['name' => $name, 'value' => $value];
        }
    }
?>

<tr>
<td class="actor">
<?= h($entry['usuario'] ?: '—') ?>

</td>
<td class="muted" style="white-space:nowrap">
<?= h($entry['fecha']) ?>

</td>
<td>
<span class="chip pill">
<?= h($moduleLabel) ?>
 · <?= h($actionLabel) ?>

</span>
</td>
<td>
<?= h($entry['tienda'] ?: '—') ?>

</td>
<td class="actor">
<?= h($artCode) ?>

</td>
<td>
<div class="detail-pills">

<?php if ($items): foreach (array_slice($items, 0, 5) as $item): ?>

<span class="detail-pill">
<b>
<?= h($item['name']) ?>
:</b> <?= h($item['value']) ?>

</span>

<?php endforeach; else: ?>

<span class="muted">Sin detalle adicional</span>

<?php endif; ?>

</div>
</td>
</tr>

<?php endforeach; ?>

</tbody>
</table>
</div>
<p class="note" id="searchEmpty" hidden>Sin coincidencias en los movimientos mostrados.</p>

<?php else: ?>

<div class="empty">No hay movimientos visibles en este período.</div>

<?php endif; ?>

</article>
</section>
</main>


<script id="dashboard-data" type="application/json"><?= json_encode([
    'stores'=>$general['tiendas_labels'],
    'storeVals'=>$general['tiendas_valores'],
    'week'=>$general['semana'],
    'create'=>(int)$general['creados'],
    'edit'=>(int)$general['editados'],
], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?></script>
<script src="exhibiciontotal/js/dashboard.js?v=20261124"></script>
<script>
document.addEventListener('contextmenu', function (event) {
    event.preventDefault();
}, true);
</script>
</body>
</html>
