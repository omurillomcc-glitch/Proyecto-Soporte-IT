
(function(){'use strict';
const element1=document.getElementById('dashboard-data');
if(!element1)throw new Error('No se encontraron los datos del dashboard.');
const responseData1=JSON.parse(element1.textContent);
let value1=document;
try{if(window.parent!==window && window.parent.document) value1=window.parent.document;}catch(e){}

function isDark(){let doc=value1;for(const el of [doc.body,doc.documentElement]){if(!el)continue;const v=['data-bs-theme','data-theme','data-layout-mode','data-color-mode','data-skin','data-layout-theme'].map(x=>el.getAttribute(x)||'').join(' ').toLowerCase();if(/dark|oscuro/.test(v)||/dark/.test(el.className+' '))return true;if(/light|claro/.test(v)||/light/.test(el.className+' '))return false;}return matchMedia('(prefers-color-scheme: dark)').matches;}

function themeColors(){const cs=getComputedStyle(document.body);return {text:cs.getPropertyValue('--text').trim()||'#1b2736',muted:cs.getPropertyValue('--muted').trim()||'#697789',line:cs.getPropertyValue('--stroke').trim()||'#e5e9ef',accent:cs.getPropertyValue('--accent').trim()||'#536dba',panel:cs.getPropertyValue('--panel').trim()||'#fff',blue:cs.getPropertyValue('--blue').trim()||'#477fb4'};}

function sync(){
 const value2=isDark()?'dark':'light';
 if(document.documentElement.getAttribute('data-bs-theme')!==value2)document.documentElement.setAttribute('data-bs-theme',value2);
 if(value1!==document&&value1.body){const value3=getComputedStyle(value1.body).fontFamily;document.documentElement.style.setProperty('--metis-font',value3);}
 const c=themeColors();
 value4.forEach(ch=>{
  if(ch.$dt==='stores'){ch.data.datasets[0].backgroundColor=c.accent;ch.data.datasets[0].hoverBackgroundColor=c.blue;}
  if(ch.$dt==='week'){ch.data.datasets[0].borderColor=c.accent;ch.data.datasets[0].pointBackgroundColor=c.accent;ch.data.datasets[0].pointHoverBorderColor=c.panel;ch.data.datasets[0].backgroundColor=ctx=>{const value5=ctx.chart.chartArea;if(!value5)return c.accent;const value6=ctx.chart.ctx.createLinearGradient(0,value5.top,0,value5.bottom);value6.addColorStop(0,value2==='dark'?'rgba(157,172,249,.26)':'rgba(83,109,186,.19)');value6.addColorStop(1,'rgba(83,109,186,0)');return value6;};}
  if(ch.$dt==='changes'){ch.data.datasets[0].backgroundColor=[c.accent,c.blue];ch.data.datasets[0].borderColor=c.panel;}
  if(ch.options.scales)for(const value7 of Object.values(ch.options.scales)){if(value7.ticks)value7.ticks.color=c.muted;if(value7.grid)value7.grid.color=c.line;}
  if(ch.options.plugins.legend)ch.options.plugins.legend.labels.color=c.text;
  ch.update('none');
 });
}
const value4=[];

function addStores(){
 const element2=document.getElementById('gStores');if(!element2)return;
 if(!responseData1.stores.length){element2.parentElement.innerHTML='<div class="empty">Sin movimientos en este período</div>';return;}
 const c=themeColors();
 const ch=new Chart(element2,{type:'bar',data:{labels:responseData1.stores.map(x=>x.length>21?x.slice(0,20)+'…':x),datasets:[{label:'Movimientos',data:responseData1.storeVals,backgroundColor:c.accent,hoverBackgroundColor:c.blue,borderSkipped:false,borderRadius:8,barThickness:13}]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,animation:{duration:420},layout:{padding:{right:13}},plugins:{legend:{display:false},tooltip:{callbacks:{title:items=>responseData1.stores[items[0].dataIndex]}}},scales:{x:{beginAtZero:true,grid:{display:false},border:{display:false},ticks:{precision:0,maxTicksLimit:5,color:c.muted}},y:{grid:{display:false},border:{display:false},ticks:{color:c.muted,font:{size:11},autoSkip:false}}}}});
 ch.$dt='stores';value4.push(ch);
}

function addWeek(){
 const element3=document.getElementById('gWeek');if(!element3)return;const c=themeColors();
 const ch=new Chart(element3,{type:'line',data:{labels:['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'],datasets:[{label:'Movimientos',data:responseData1.week,borderColor:c.accent,backgroundColor:'rgba(83,109,186,.15)',fill:true,tension:.42,borderWidth:2.5,pointRadius:2.5,pointHoverRadius:6,pointBackgroundColor:c.accent,pointBorderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,animation:{duration:460},interaction:{mode:'index',intersect:false},plugins:{legend:{display:false}},scales:{x:{grid:{display:false},border:{display:false},ticks:{color:c.muted}},y:{beginAtZero:true,grid:{color:c.line,drawTicks:false},border:{display:false,dash:[3,5]},ticks:{color:c.muted,precision:0,maxTicksLimit:5,padding:9}}}}});
 ch.$dt='week';value4.push(ch);
}
const options1={id:'dtCenterTotal',afterDraw(chart){if(chart.$dt!=='changes')return;const arc=chart.getDatasetMeta(0).data[0];if(!arc)return;const ctx=chart.ctx,c=themeColors(),x=arc.x,y=arc.y;ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=c.text;ctx.font='700 24px '+getComputedStyle(document.body).fontFamily;ctx.fillText(new Intl.NumberFormat('es-HN').format(responseData1.create+responseData1.edit),x,y-7);ctx.fillStyle=c.muted;ctx.font='11px '+getComputedStyle(document.body).fontFamily;ctx.fillText('movimientos',x,y+15);ctx.restore();}};

function addChanges(){
 const element4=document.getElementById('gChanges');if(!element4)return;const c=themeColors(),value8=responseData1.create+responseData1.edit;
 if(!value8){element4.parentElement.innerHTML='<div class="empty">Sin creaciones ni ediciones en este período</div>';return;}
 const ch=new Chart(element4,{type:'doughnut',data:{labels:['Creaciones','Ediciones'],datasets:[{data:[responseData1.create,responseData1.edit],backgroundColor:[c.accent,c.blue],borderColor:c.panel,borderWidth:4,hoverOffset:5,borderRadius:4}]},plugins:[options1],options:{responsive:true,maintainAspectRatio:false,cutout:'76%',animation:{duration:500},plugins:{legend:{display:true,position:'bottom',labels:{color:c.text,usePointStyle:true,pointStyle:'circle',boxWidth:8,boxHeight:8,padding:14,font:{size:11}}},tooltip:{callbacks:{label:context=>context.label+': '+context.parsed+' ('+(100*context.parsed/value8).toFixed(1)+'%)'}}}}});
 ch.$dt='changes';value4.push(ch);
}
if(typeof Chart!=='undefined'){addStores();addWeek();addChanges();}
sync();
const mutationObserver1=new MutationObserver(sync),value9={attributes:true,attributeFilter:['class','style','data-bs-theme','data-theme','data-layout-mode','data-color-mode','data-skin','data-layout-theme']};mutationObserver1.observe(value1.documentElement,value9);if(value1.body)mutationObserver1.observe(value1.body,value9);if(value1!==document){mutationObserver1.observe(document.documentElement,value9);if(document.body)mutationObserver1.observe(document.body,value9);}matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change',sync);window.addEventListener('focus',sync);sync();
const element5=document.getElementById('activitySearch');element5?.addEventListener('input',()=>{const q=element5.value.toLocaleLowerCase();let n=0;document.querySelectorAll('#activityTable tbody tr').forEach(row=>{let ok=row.textContent.toLocaleLowerCase().includes(q);row.hidden=!ok;if(ok)n++;});const element6=document.getElementById('searchEmpty');if(element6)element6.hidden=n>0;});
})();

