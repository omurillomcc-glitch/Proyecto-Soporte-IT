<?php
declare(strict_types=1);


ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/conexion_sqlsrv.php';

/* VALIDAR LOGIN */
require_module_access('modulo3');
app_require_csrf();
$me = me();

/* FUNCIONES AUXILIARES */
function limpiar_texto_sinstock(mixed $v): string
{
    return trim((string)$v);
}

function limpiar_numero_sinstock(mixed $v): int
{
    $v = preg_replace('/\D/', '', (string)$v);
    return $v === '' ? 0 : (int)$v;
}

function normalizar_region_sinstock(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS'   => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default           => $region,
    };
}

function obtener_ip_sinstock(): string
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return $ip === '::1' ? 'LOCALHOST' : $ip;
}

/* REDIRECCIONAR */
function volver_sinstock(
    string $returnQs,
    string $tipo,
    string $mensaje
): void {

    $returnQs = trim($returnQs);

    if ($returnQs === '') {
        $returnQs = 'vista=modulo3';
    }

    parse_str($returnQs, $params);

    unset($params['ok'], $params['err']);

    if (!isset($params['vista'])) {
        $params['vista'] = 'modulo3';
    }

    if ($tipo === 'ok') {
        $params['ok'] = '1';
    } else {
        $params['err'] = $mensaje;
    }

    header(
        'Location: /exhibicion_DT/index.php?' .
        http_build_query($params) .
        '#tablaExhibicion'
    );

    exit;
}

/* VALIDAR MÉTODO POST */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    volver_sinstock(
        'vista=modulo3',
        'err',
        'Método inválido.'
    );
}

/* RECIBIR DATOS */
$returnQs = limpiar_texto_sinstock(
    $_POST['return_qs'] ?? 'vista=modulo3'
);

$items = $_POST['items'] ?? [];

if (!is_array($items) || empty($items)) {
    volver_sinstock(
        $returnQs,
        'err',
        'No se recibieron registros.'
    );
}

/* VALIDAR CONEXIONES */
if (!isset($sqlsrv_conn) || $sqlsrv_conn === false) {
    volver_sinstock(
        $returnQs,
        'err',
        'No hay conexión SQL Server.'
    );
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    volver_sinstock(
        $returnQs,
        'err',
        'No hay conexión MySQL.'
    );
}

/* DATOS USUARIO */
$usuarioId = (int)(
    $me['id']
    ?? $_SESSION['usuario_id']
    ?? 0
);

$usuarioNombre = (string)(
    $me['usuario']
    ?? $_SESSION['usuario']
    ?? 'Sistema'
);

$rolUsuario = (string)(
    $me['rol']
    ?? $_SESSION['rol']
    ?? ''
);

$ipUsuario = obtener_ip_sinstock();

/* UPDATE SQL SERVER */
$sqlUpdate = "
UPDATE vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]
SET
    EXHIBICION = ?,
    UXC = ?
WHERE LTRIM(RTRIM(CONVERT(VARCHAR(100), REGION))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODALMACEN))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODBARRAS))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), PLU), ''))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), ?), ''))) COLLATE DATABASE_DEFAULT
";

/* INSERT SQL SERVER */
$sqlInsert = "
INSERT INTO vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]
(
    REGION,
    CODALMACEN,
    CODARTICULO,
    CODBARRAS,
    PLU,
    EXHIBICION,
    UXC
)
VALUES
(
    ?, ?, ?, ?, ?, ?, ?
)
";

/* INSERT AUDITORÍA MYSQL */
$sqlAuditoria = "
INSERT INTO auditoria
(
    usuario_id,
    usuario,
    rol,
    modulo,
    accion,
    descripcion,
    region,
    tienda,
    zona,
    codalmacen,
    ip
)
VALUES
(
    ?,
    ?,
    ?,
    'EXHIBICION',
    'GUARDAR_EXHIBICION_SIN_STOCK_MASIVO',
    ?,
    ?,
    ?,
    ?,
    ?,
    ?
);
"; 

/* CONSULTAR VALOR PREVIO PARA REGISTRAR EL CAMBIO DE EXHIBICIÓN */
$sqlExhibicionAnterior = "
SELECT TOP 1 EXHIBICION
FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION]
WHERE LTRIM(RTRIM(CONVERT(VARCHAR(100), REGION))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODALMACEN))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODARTICULO))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(CONVERT(VARCHAR(100), CODBARRAS))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(CONVERT(VARCHAR(100), ?))) COLLATE DATABASE_DEFAULT
  AND LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), PLU), ''))) COLLATE DATABASE_DEFAULT
      = LTRIM(RTRIM(ISNULL(CONVERT(VARCHAR(100), ?), ''))) COLLATE DATABASE_DEFAULT
";


/* PREPARAR AUDITORÍA */
$stmtAud = $conn->prepare($sqlAuditoria);

if (!$stmtAud) {
    volver_sinstock(
        $returnQs,
        'err',
        'No se pudo preparar auditoría.'
    );
}

/* INICIAR TRANSACCIÓN SQL SERVER */
if (!sqlsrv_begin_transaction($sqlsrv_conn)) {
    $stmtAud->close();

    volver_sinstock(
        $returnQs,
        'err',
        'No se pudo iniciar transacción en SQL Server.'
    );
}

/* CONTADORES */
$guardados = 0;
$actualizados = 0;
$creados = 0;

try {

    /* RECORRER REGISTROS */
    foreach ($items as $item) {

        if (!is_array($item)) {
            continue;
        }

        /* SOLO CHECK SELECCIONADOS */
        if (
            !isset($item['seleccionado']) ||
            (string)$item['seleccionado'] !== '1'
        ) {
            continue;
        }

        /* LIMPIAR DATOS */
        $region = normalizar_region_sinstock(
            (string)($item['region'] ?? '')
        );

        $codalmacen = limpiar_texto_sinstock(
            $item['codalmacen'] ?? ''
        );

        $codarticulo = limpiar_texto_sinstock(
            $item['codarticulo'] ?? ''
        );

        $codbarras = limpiar_texto_sinstock(
            $item['codbarras'] ?? ''
        );

        $plu = limpiar_texto_sinstock(
            $item['plu'] ?? ''
        );

        $tienda = limpiar_texto_sinstock(
            $item['nombrealmacen']
            ?? $item['tienda']
            ?? ''
        );

        $exhibicion = limpiar_numero_sinstock(
            $item['exhibicion'] ?? 0
        );

        $uxc = limpiar_numero_sinstock(
            $item['uxc'] ?? 0
        );

        /* SI NO VIENE NOMBRE TIENDA */
        if ($tienda === '') {
            $tienda = $codalmacen;
        }

        /* VALIDAR CAMPOS OBLIGATORIOS */
        if (
            $region === '' ||
            $codalmacen === '' ||
            $codarticulo === ''
        ) {
            continue;
        }

        $dbCatalogo = $region === 'NICARAGUA' ? 'ACANICARAGUA2' : 'DETODO';
        $stmtReferencia = sqlsrv_query(
            $sqlsrv_conn,
            "SELECT TOP 1 LTRIM(RTRIM(CONVERT(VARCHAR(100), REFPROVEEDOR))) AS REFERENCIA
             FROM {$dbCatalogo}.dbo.ARTICULOS
             WHERE CODARTICULO = ?",
            [$codarticulo]
        );
        $referenciaArticulo = '';
        if ($stmtReferencia === false) {
            error_log('No se pudo consultar la referencia del artículo para auditoría: ' . print_r(sqlsrv_errors(), true));
        } else {
            $filaReferencia = sqlsrv_fetch_array($stmtReferencia, SQLSRV_FETCH_ASSOC);
            if (is_array($filaReferencia)) {
                $referenciaArticulo = trim((string)($filaReferencia['REFERENCIA'] ?? ''));
            }
            sqlsrv_free_stmt($stmtReferencia);
        }

        $paramsAnterior = [$region, $codalmacen, $codarticulo, $codbarras, $plu];
        $stmtAnterior = sqlsrv_query($sqlsrv_conn, $sqlExhibicionAnterior, $paramsAnterior);
        if ($stmtAnterior === false) {
            throw new RuntimeException(print_r(sqlsrv_errors(), true));
        }
        $filaAnterior = sqlsrv_fetch_array($stmtAnterior, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtAnterior);
        if ($filaAnterior === false) {
            throw new RuntimeException('No se pudo leer el valor anterior de exhibición.');
        }

        /* INTENTAR UPDATE SQL SERVER */
      $paramsUpdate = [
    $exhibicion,
    $uxc,
    $region,
    $codalmacen,
    $codarticulo,
    $codbarras,
    $plu
];

        $stmtUpdate = sqlsrv_query(
            $sqlsrv_conn,
            $sqlUpdate,
            $paramsUpdate
        );

        if ($stmtUpdate === false) {
            throw new RuntimeException(
                print_r(sqlsrv_errors(), true)
            );
        }

        /* VERIFICAR SI ACTUALIZÓ */
        $rowsAffected = sqlsrv_rows_affected($stmtUpdate);
        sqlsrv_free_stmt($stmtUpdate);
        if ($rowsAffected === false) {
            throw new RuntimeException('No se pudo confirmar la actualización de exhibición.');
        }

        $accionRegistro = 'ACTUALIZADO';
        $existe = is_array($filaAnterior);
        $exhibicionAnterior = $existe
            ? trim((string)($filaAnterior['EXHIBICION'] ?? ''))
            : '';

        /* SI NO EXISTÍA, INSERTAR */
        if (!$existe) {

            $paramsInsert = [
                $region,
                $codalmacen,
                $codarticulo,
                $codbarras,
                $plu,
                $exhibicion,
                $uxc
            ];

            $stmtInsert = sqlsrv_query(
                $sqlsrv_conn,
                $sqlInsert,
                $paramsInsert
            );

            if ($stmtInsert === false) {
                throw new RuntimeException(
                    print_r(sqlsrv_errors(), true)
                );
            }

            sqlsrv_free_stmt($stmtInsert);

            $accionRegistro = 'CREADO';
            $creados++;

        } else {

            $actualizados++;
        }

        /* DESCRIPCIÓN AUDITORÍA */
        $detalleExhibicion = $existe
            ? ($exhibicionAnterior !== (string)$exhibicion
                ? $exhibicionAnterior . ' A ' . $exhibicion
                : (string)$exhibicion)
            : (string)$exhibicion;
        $descripcion = "Se guardó exhibición sin stock masiva."
            . " | ACCION: {$accionRegistro}"
            . " | REGION: {$region}"
            . " | TIENDA: {$tienda}"
            . " | CODARTICULO: {$codarticulo}"
            . " | CODBARRAS: {$codbarras}"
            . " | PLU: {$plu}"
            . " | REFERENCIA: {$referenciaArticulo}"
            . " | EXHIBICION: {$detalleExhibicion}"
            . " | UXC: {$uxc}";

        // . Obtenemos de forma dinámica la zona real de este registro específico ($item)
        // Si no viene en el registro, usamos la zona del usuario logueado como respaldo.
        $zonaDinamica = !empty($item['zona']) 
            ? trim((string)$item['zona']) 
            : (string)($me['zona'] ?? 'SIN ZONA');

        // . Usamos exactamente 9 letras ('issssssss') y 9 variables para coincidir con tu SQL.
        // Mantenemos invertidas $tienda y $zonaDinamica debido al cruce de tu Base de Datos.
        $stmtAud->bind_param(
            'issssssss',
            $usuarioId,
            $usuarioNombre,
            $rolUsuario,
            $descripcion,
            $region,
            $tienda,
            $zonaDinamica,           
            $codalmacen,
            $ipUsuario
        );

        if (!$stmtAud->execute()) {
            throw new RuntimeException(
                'No se pudo guardar auditoría: ' . $stmtAud->error
            );
        }

        $guardados++;
    }


    /* VALIDAR SI GUARDÓ */
    if ($guardados <= 0) {

        sqlsrv_rollback($sqlsrv_conn);
        $stmtAud->close();

        volver_sinstock(
            $returnQs,
            'err',
            'No seleccionó registros.'
        );
    }

    /* CONFIRMAR */
    sqlsrv_commit($sqlsrv_conn);

    $stmtAud->close();

    volver_sinstock(
        $returnQs,
        'ok',
        "Registros sin stock guardados correctamente. Actualizados: {$actualizados}. Creados: {$creados}."
    );

} catch (Throwable $e) {

    /* SI HAY ERROR, DESHACER CAMBIOS */
    sqlsrv_rollback($sqlsrv_conn);

    if ($stmtAud instanceof mysqli_stmt) {
        $stmtAud->close();
    }

    volver_sinstock(
        $returnQs,
        'err',
        'Error al guardar: ' . $e->getMessage()
    );
}