<?php
declare(strict_types=1);

/* INICIAR SESIÓN */
if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* CARGAR ARCHIVOS */
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/* OBTENER IP () */
function auditoria_ip(): string
{
    return (string)($_SERVER['REMOTE_ADDR'] ?? '');
}

function auditoria_region_label(string $valor): string
{
    $valor = strtoupper(trim($valor));

    return match ($valor) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $valor,
    };
}

/* REGISTRAR AUDITORÍA ADAPTADA Y BLINDADA */
function registrar_auditoria(
    string $modulo,
    string $accion,
    string $descripcion = '',
    ?string $region = null,
    ?string $zona = null,
    ?string $tienda = null,
    ?string $codalmacen = null,
    ?mysqli $customConn = null // <-- Parámetro de seguridad extra
): bool {
    global $conn;

    // Usar la conexión inyectada de forma segura o recurrir a la global validada
    $activeConn = $customConn ?? $conn;

    /* VALIDAR CONEXIÓN MYSQL (EVITA MENSAJES DE CAÍDAS PÚBLICOS) */
    if (!isset($activeConn) || !($activeConn instanceof mysqli)) {
        error_log("Fallo crítico: Intento de auditoría sin una conexión a base de datos válida activa.");
        return false;
    }

    /* OBTENER USUARIO LOGUEADO DE FORMA SEGURA */
    $me = function_exists('me') ? me() : [];

    $usuarioId = (int)($me['id'] ?? ($_SESSION['usuario_id'] ?? 0));
    $usuario   = trim((string)($me['usuario'] ?? ($_SESSION['usuario'] ?? 'Sistema')));
    $rol       = trim((string)($me['rol'] ?? ($_SESSION['rol'] ?? '')));

    /* OBTENER REGIÓN */
    $regionRaw = trim((string)(
        $region
        ?? ($_SESSION['pais'] ?? '')
        ?: ($_SESSION['pais_code'] ?? '')
        ?: ($me['pais_code'] ?? '')
    ));

    $regionVal = auditoria_region_label($regionRaw);

    /* OBTENER ZONA */
    $zonaVal = trim((string)(
        $zona
        ?? ($_SESSION['zona'] ?? '')
        ?: ($me['zona'] ?? '')
    ));

    /* OBTENER CÓDIGO DE ALMACÉN */
    $almacen = trim((string)(
        $codalmacen
        ?? ($_SESSION['codalmacen'] ?? '')
        ?: ($me['codalmacen'] ?? '')
    ));

    /* OBTENER TIENDA / NOMBRE TIENDA */
    $tiendaVal = trim((string)(
        $tienda
        ?? ($_SESSION['tienda'] ?? '')
        ?: ($me['tienda'] ?? '')
    ));

    if ($tiendaVal === '') {
        $tiendaVal = $almacen;
    }

    /* NORMALIZAR VALORES (EVITA INYECCIONES O CARACTERES TRUCADOS) */
    $regionVal = strtoupper(trim($regionVal));
    $zonaVal   = strtoupper(trim($zonaVal));
    $almacen   = strtoupper(trim($almacen));

    /* AGREGAR DATOS IMPORTANTES A LA DESCRIPCIÓN */
    if ($regionVal !== '' && stripos($descripcion, 'REGION:') === false) {
        $descripcion .= ' | REGION: ' . $regionVal;
    }

    if ($almacen !== '' && stripos($descripcion, 'CODALMACEN:') === false) {
        $descripcion .= ' | CODALMACEN: ' . $almacen;
    }

    if ($tiendaVal !== '' && stripos($descripcion, 'TIENDA:') === false) {
        $descripcion .= ' | TIENDA: ' . $tiendaVal;
    }

    /* OBTENER IP */
    $ip = auditoria_ip();

    /* INSERTAR EN AUDITORÍA MEDIANTE PREPARED STATEMENTS */
    $sql = "
        INSERT INTO auditoria
        (
            usuario_id,
            usuario,
            rol,
            modulo,
            accion,
            descripcion,
            region,
            zona,
            tienda,
            codalmacen,
            ip
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ";

    $stmt = $activeConn->prepare($sql);

    if (!$stmt) {
        error_log("Error estructurando sentencia de auditoría: " . $activeConn->error);
        return false;
    }

    $stmt->bind_param(
        'issssssssss',
        $usuarioId,
        $usuario,
        $rol,
        $modulo,
        $accion,
        $descripcion,
        $regionVal,
        $zonaVal,
        $tiendaVal,
        $almacen,
        $ip
    );

    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}
