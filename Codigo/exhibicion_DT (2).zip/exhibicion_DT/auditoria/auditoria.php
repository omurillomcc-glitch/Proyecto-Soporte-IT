<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/accesos_menu.php';

/* VALIDAR LOGIN */
require_module_access('modulo2');
$me = me();

/* DATOS DEL USUARIO LOGUEADO */
$miId   = (int)($me['id'] ?? 0);
$miUser = trim((string)($me['usuario'] ?? ''));
$miRol  = (string)($me['rol'] ?? '');
$miZona = trim((string)($me['zona'] ?? ''));
$miPais = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));

if ($miPais === '') {
    $miPais = 'HN';
}

/* HELPERS GENERALES */
function h_aud(mixed $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function aud_modulo_label(string $modulo): string
{
    return str_replace('_', ' ', trim($modulo));
}

function aud_clean_text(string $value): string
{
    return trim($value);
}

/* CONVERTIR PAÍS A REGIÓN */
function aud_region_label_from_pais(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        'HONDURAS' => 'HONDURAS',
        'NICARAGUA' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}

/* NORMALIZAR REGIÓN */
function aud_normalizar_region(string $region): string
{
    $region = strtoupper(trim($region));

    return match ($region) {
        'HN', 'HONDURAS' => 'HONDURAS',
        'NI', 'NICARAGUA' => 'NICARAGUA',
        default => $region,
    };
}

/* EXTRAER CAMPOS DESDE DESCRIPCIÓN */
function aud_extract_field_from_description(string $descripcion, string $field): string
{
    $descripcion = trim($descripcion);
    $field = preg_quote(trim($field), '/');

    if ($descripcion === '' || $field === '') {
        return '';
    }

    if (preg_match('/' . $field . '\s*:\s*([^|]+)/i', $descripcion, $m)) {
        return trim((string)$m[1]);
    }

    return '';
}

function aud_extract_region_from_description(string $descripcion): string
{
    return aud_normalizar_region(aud_extract_field_from_description($descripcion, 'REGION'));
}

function aud_extract_zona_from_description(string $descripcion): string
{
    return strtoupper(trim(aud_extract_field_from_description($descripcion, 'ZONA')));
}

function aud_extract_codalmacen_from_description(string $descripcion): string
{
    $cod = aud_extract_field_from_description($descripcion, 'CODALMACEN');

    if ($cod === '') {
        $cod = aud_extract_field_from_description($descripcion, 'TIENDA');
    }

    return strtoupper(trim($cod));
}

/* CREAR LLAVE ÚNICA DE TIENDA */
function aud_store_key(string $region, string $zona, string $codalmacen): string
{
    $region     = strtoupper(trim($region));
    $zona       = strtoupper(trim($zona));
    $codalmacen = strtoupper(trim($codalmacen));

    return $region . '-' . $zona . '-' . $codalmacen;
}

/* LLAVE SIMPLE POR PAÍS + CÓDIGO */
function aud_store_country_key(string $region, string $codalmacen): string
{
    return aud_normalizar_region($region) . '-' . strtoupper(trim($codalmacen));
}

/* VALIDAR TABLA MYSQL */
function aud_table_exists(mysqli $conn, string $table): bool
{
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");

    return $res instanceof mysqli_result && $res->num_rows > 0;
}


/* FORMATEAR DESCRIPCIÓN DE AUDITORÍA */
function aud_format_descripcion(
    string $texto,
    string $modulo = '',
    string $accion = '',
    string $region = '',
    array $tiendas = [],
    array $usuarios = []
): string
{
    $texto = trim($texto);

    if ($texto === '') {
        return '';
    }

    if ($modulo === 'USUARIOS' && $accion === 'USUARIO_EDITADO') {
        $texto = trim(explode('|', $texto, 2)[0]);
        $cambios = array_filter(array_map('trim', preg_split('/\R/u', $texto) ?: []));
        $html = '<div class="aud-desc-plain aud-desc-changes">';

        foreach ($cambios as $cambio) {
            $partesCambio = explode(':', $cambio, 2);
            $campo = trim($partesCambio[0]);
            $valor = trim((string)($partesCambio[1] ?? ''));
            $html .= '<div class="aud-change-row"><span class="aud-change-field">'
                . h_aud($campo) . '</span><span class="aud-change-value">'
                . h_aud($valor) . '</span></div>';
        }

        return $html . '</div>';
    }

    if ($modulo === 'PERMISOS' && $accion === 'PERMISOS_ACTUALIZADOS'
        && preg_match('/(?:^|\|)\s*CAMBIOS\s*:\s*([^|\r\n]*)/i', $texto, $coincidencia)) {
        $usuarioObjetivo = '';
        if (preg_match('/(?:^|\|)\s*Usuario(?:\s+ID)?\s*:\s*([^|]+)/i', $texto, $coincidenciaUsuario)) {
            $usuarioObjetivo = trim($coincidenciaUsuario[1]);
            if (ctype_digit($usuarioObjetivo)) {
                $usuarioObjetivo = trim((string)($usuarios[$usuarioObjetivo] ?? 'Usuario ' . $usuarioObjetivo));
            }
        }

        $cambios = array_filter(array_map('trim', explode(';', $coincidencia[1])));
        $html = '<div class="aud-desc-plain aud-desc-changes">';
        $modulos = am_modulos();
        if ($usuarioObjetivo !== '') {
            $html .= '<div class="aud-change-row"><span class="aud-change-field">Usuario</span>'
                . '<span class="aud-change-value">' . h_aud($usuarioObjetivo) . '</span></div>';
        }

        foreach ($cambios as $cambio) {
            $partesCambio = explode(':', $cambio, 2);
            $codigoModulo = trim($partesCambio[0]);
            $campo = (string)($modulos[$codigoModulo] ?? str_replace('_', ' ', $codigoModulo));
            $valor = trim((string)($partesCambio[1] ?? ''));
            $valor = preg_replace('/\bSI\b/u', 'Con acceso', $valor) ?? $valor;
            $valor = preg_replace('/\bNO\b/u', 'Sin acceso', $valor) ?? $valor;
            $valor = str_replace(['->', '→'], ' A ', $valor);
            $html .= '<div class="aud-change-row"><span class="aud-change-field">'
                . h_aud($campo) . '</span><span class="aud-change-value">'
                . h_aud($valor) . '</span></div>';
        }

        return $html . '</div>';
    }

    if ($modulo === 'BLOQUEO_GENERAL') {
        $campos = [
            'PLU' => 'PLU',
            'REFERENCIA' => 'Referencia',
            'REGION' => 'Región',
            'CODALMACEN' => 'Codalmacén',
            'TIENDA' => 'Tienda',
            'LOTE' => 'Lote',
            'RESULTADO' => 'Resultado',
        ];
        $detalles = array_filter(
            array_map('trim', preg_split('/[|\r\n]+/', $texto) ?: []),
            static fn(string $linea): bool => $linea !== ''
        );
        $html = '<div class="aud-desc-plain">';

        foreach ($detalles as $detalle) {
            $partesDetalle = explode(':', $detalle, 2);
            $campo = strtoupper(trim($partesDetalle[0]));
            $valor = trim((string)($partesDetalle[1] ?? ''));
            $etiqueta = $campos[$campo] ?? trim($partesDetalle[0]);
            $html .= '<div>' . h_aud($etiqueta . ($valor !== '' ? ': ' . $valor : '')) . '</div>';
        }

        return $html . '</div>';
    }

    if ($modulo === 'EXHIBICION') {
        $campos = [
            'ACCION' => 'Acción',
            'TIENDA' => 'Tienda',
            'CODARTICULO' => 'Código artículo',
            'CODBARRAS' => 'Código barras',
            'PLU' => 'PLU',
            'REFERENCIA' => 'Referencia',
            'EXHIBICION' => 'Exhibición',
        ];
        $detalles = array_filter(
            array_map('trim', preg_split('/[|\r\n]+/', $texto) ?: []),
            static fn(string $linea): bool => $linea !== ''
                && !preg_match('/^Se (?:guardó|creó|actualizó) exhibición(?: sin stock)? masiva?\.?$/iu', $linea)
                && !preg_match('/^Se (?:creó|actualizó) exhibición\.?$/iu', $linea)
        );
        $html = '<div class="aud-desc-plain">';

        foreach ($detalles as $detalle) {
            $partesDetalle = explode(':', $detalle, 2);
            $campo = strtoupper(trim($partesDetalle[0]));
            if (!isset($campos[$campo])) {
                continue;
            }
            $valor = trim((string)($partesDetalle[1] ?? ''));
            if ($campo === 'EXHIBICION') {
                $valor = str_replace(['->', '→'], ' A ', $valor);
            }
            $etiqueta = $campos[$campo] ?? trim($partesDetalle[0]);
            $html .= '<div>' . h_aud($etiqueta . ($valor !== '' ? ': ' . $valor : '')) . '</div>';
        }

        return $html . '</div>';
    }

    $texto = preg_replace_callback(
        '/(\bTIENDA\s*:\s*)([^|\r\n]+)/i',
        static function (array $coincidencia) use ($region, $tiendas): string {
            $valores = preg_split('/\s*(?:→|->)\s*/u', trim($coincidencia[2])) ?: [];
            $nombres = [];

            foreach ($valores as $valor) {
                $codigo = strtoupper(trim($valor));
                $key = aud_store_country_key($region, $codigo);
                $nombres[] = trim((string)($tiendas[$key]['nombre'] ?? '')) ?: $valor;
            }

            return $coincidencia[1] . implode(' → ', $nombres);
        },
        $texto
    ) ?? $texto;

    $lineas = array_filter(
        array_map('trim', preg_split('/[|\r\n]+/', $texto) ?: []),
        static fn(string $linea): bool => $linea !== ''
            && !preg_match('/^Contraseña\s*:\s*SIN CAMBIOS$/i', $linea)
    );

    $html = '<div class="aud-desc-plain">';
    foreach ($lineas as $linea) {
        $html .= '<div>' . h_aud($linea) . '</div>';
    }
    return $html . '</div>';
}

/* ALCANCE DE AUDITORÍA */
function aud_build_scope_sql(
    mysqli $conn,
    int $miId,
    string $miRol,
    string $miPais,
    string $miZona,
    string $miUser
): array {
    $where  = [];
    $params = [];
    $types  = '';

    // Solo el propietario ve movimientos de todos los países y tiendas.
    require_once dirname(__DIR__) . '/controlusuarios/accesos_menu.php';
    if (am_es_propietario($conn, $miId)) {
        return [$where, $params, $types];
    }

    /* NORMALIZAR ROL Y REGIÓN */
    $miRol = strtolower(trim($miRol));

    $regionLabel = aud_region_label_from_pais($miPais);
    $regionLabel = aud_normalizar_region($regionLabel);

    /* SI NO ES SUPER_ADMIN NI ADMIN_ZONA, NO VE NADA */
    if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /* VALIDAR REGIÓN */
    if ($regionLabel === '') {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /* FILTRO BASE POR PAÍS / REGIÓN */
    $where[] = "(
        UPPER(TRIM(COALESCE(a.region, ''))) = ?
        OR (
            TRIM(COALESCE(a.region, '')) = ''
            AND UPPER(COALESCE(a.descripcion, '')) LIKE ?
        )
    )";

    $params[] = $regionLabel;
    $params[] = '%REGION: ' . $regionLabel . '%';
    $types   .= 'ss';

    /* SUPER ADMIN */
    if ($miRol === 'super_admin') {
        return [$where, $params, $types];
    }

    /* ADMIN_ZONA */
    $codigosTiendas = [];

    $sqlTiendas = "
        SELECT DISTINCT
            TRIM(COALESCE(codalmacen, '')) AS codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
          AND TRIM(COALESCE(codalmacen, '')) <> ''
          AND (
                UPPER(TRIM(COALESCE(pais, ''))) = ?
                OR UPPER(TRIM(COALESCE(pais, ''))) = ?
          )
    ";

    $stmtTiendas = $conn->prepare($sqlTiendas);

    if (!$stmtTiendas) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    $paisCorto = strtoupper(trim($miPais));

    $stmtTiendas->bind_param(
        'iss',
        $miId,
        $paisCorto,
        $regionLabel
    );

    $stmtTiendas->execute();
    $resTiendas = $stmtTiendas->get_result();

    if ($resTiendas) {
        while ($t = $resTiendas->fetch_assoc()) {
            $cod = strtoupper(trim((string)($t['codalmacen'] ?? '')));

            if ($cod !== '') {
                $codigosTiendas[] = $cod;
            }
        }
    }

    $stmtTiendas->close();

    /* SI ADMIN_ZONA NO TIENE TIENDAS, NO VE NADA */
    $codigosTiendas = array_values(array_unique($codigosTiendas));

    if (empty($codigosTiendas)) {
        $where[] = '1 = 0';
        return [$where, $params, $types];
    }

    /* FILTRAR AUDITORÍA POR SUS TIENDAS ASIGNADAS */
    $placeholders = implode(',', array_fill(0, count($codigosTiendas), '?'));

    $whereTienda = "(
        UPPER(TRIM(COALESCE(a.codalmacen, ''))) IN ($placeholders)
        OR (
            TRIM(COALESCE(a.codalmacen, '')) = ''
            AND (
    ";

    /* Primero se agregan los parámetros del IN (...) */
    foreach ($codigosTiendas as $cod) {
        $params[] = $cod;
        $types   .= 's';
    }

    /* Luego se agregan las condiciones para buscar en descripción */
    $condicionesDescripcion = [];

    foreach ($codigosTiendas as $cod) {
        $condicionesDescripcion[] = "UPPER(COALESCE(a.descripcion, '')) LIKE ?";
        $params[] = '%CODALMACEN: ' . $cod . '%';
        $types   .= 's';

        $condicionesDescripcion[] = "UPPER(COALESCE(a.descripcion, '')) LIKE ?";
        $params[] = '%TIENDA: ' . $cod . '%';
        $types   .= 's';
    }

    $whereTienda .= implode(' OR ', $condicionesDescripcion);

    $whereTienda .= "
            )
        )
    )";

    $where[] = $whereTienda;

    return [$where, $params, $types];
}

/* URL DE PAGINACIÓN */
function aud_page_url(int $page, string $baseQuery): string
{
    $params = [];

    if ($baseQuery !== '') {
        parse_str($baseQuery, $params);
    }

    $params['vista'] = 'modulo2';
    $params['page']  = $page;

    return 'index.php?' . http_build_query($params);
}

/* FILTROS DEL USUARIO */
$filters = [
    'fecha_inicio' => aud_clean_text((string)($_GET['fecha_inicio'] ?? '')),
    'fecha_fin'    => aud_clean_text((string)($_GET['fecha_fin'] ?? '')),
    'usuario'      => aud_clean_text((string)($_GET['usuario'] ?? '')),
    'modulo'       => aud_clean_text((string)($_GET['modulo'] ?? '')),
    'accion'       => aud_clean_text((string)($_GET['accion'] ?? '')),
];

/* PAGINACIÓN */
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)($_GET['per_page'] ?? 100);

if (!in_array($perPage, [100, 200, 500], true)) {
    $perPage = 100;
}

/* ARMAR WHERE GENERAL */
$where  = [];
$params = [];
$types  = '';

[$scopeWhere, $scopeParams, $scopeTypes] = aud_build_scope_sql(
    $conn,
    $miId,
    $miRol,
    $miPais,
    $miZona,
    $miUser
);

$where  = array_merge($where, $scopeWhere);
$params = array_merge($params, $scopeParams);
$types .= $scopeTypes;

if ($filters['fecha_inicio'] !== '') {
    $where[]  = 'DATE(a.fecha) >= ?';
    $params[] = $filters['fecha_inicio'];
    $types   .= 's';
}

if ($filters['fecha_fin'] !== '') {
    $where[]  = 'DATE(a.fecha) <= ?';
    $params[] = $filters['fecha_fin'];
    $types   .= 's';
}

if ($filters['usuario'] !== '') {
    $where[]  = 'a.usuario LIKE ?';
    $params[] = '%' . $filters['usuario'] . '%';
    $types   .= 's';
}

if ($filters['modulo'] !== '') {
    $where[]  = 'a.modulo = ?';
    $params[] = $filters['modulo'];
    $types   .= 's';
}

if ($filters['accion'] !== '') {
    $where[]  = 'a.accion = ?';
    $params[] = $filters['accion'];
    $types   .= 's';
}

// Registrar y mostrar todos los cambios de datos; omitir eventos de sesión.
$where[] = "UPPER(TRIM(a.accion)) NOT IN (
    'LOGIN', 'LOGOUT', 'LOGIN_INICIADO', 'LOGIN_FINALIZADO',
    'INICIO_SESION', 'CIERRE_SESION', 'SESION_INICIADA', 'SESION_FINALIZADA'
)";

$whereSql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

/* SELECT DE MÓDULOS */
$modulos = [];

$sqlMod = "
    SELECT DISTINCT a.modulo
    FROM auditoria a
    {$whereSql}
      AND a.modulo <> ''
    ORDER BY a.modulo ASC
";

$stmtMod = $conn->prepare($sqlMod);

if ($stmtMod) {
    if ($types !== '') {
        $stmtMod->bind_param($types, ...$params);
    }

    $stmtMod->execute();
    $resMod = $stmtMod->get_result();

    if ($resMod) {
        while ($r = $resMod->fetch_assoc()) {
            $modulos[] = (string)($r['modulo'] ?? '');
        }
    }

    $stmtMod->close();
}

/* SELECT DE ACCIONES */
$acciones = [];

$sqlAcc = "
    SELECT DISTINCT a.accion
    FROM auditoria a
    {$whereSql}
      AND a.accion <> ''
    ORDER BY a.accion ASC
";

$stmtAcc = $conn->prepare($sqlAcc);

if ($stmtAcc) {
    if ($types !== '') {
        $stmtAcc->bind_param($types, ...$params);
    }

    $stmtAcc->execute();
    $resAcc = $stmtAcc->get_result();

    if ($resAcc) {
        while ($r = $resAcc->fetch_assoc()) {
            $acciones[] = (string)($r['accion'] ?? '');
        }
    }

    $stmtAcc->close();
}

/* CONTEO TOTAL */
$totalRows = 0;

$sqlCount = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    {$whereSql}
";

$stmtCount = $conn->prepare($sqlCount);

if ($stmtCount) {
    if ($types !== '') {
        $stmtCount->bind_param($types, ...$params);
    }

    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $totalRows = (int)($rowCount['total'] ?? 0);
    $stmtCount->close();
}

/* PAGINACIÓN REAL */
$totalPages = max(1, (int)ceil($totalRows / $perPage));

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;

/* TOTAL DE HOY */
$totalHoy  = 0;
$whereHoy  = $where;
$paramsHoy = $params;
$typesHoy  = $types;

$whereHoy[] = 'DATE(a.fecha) = CURDATE()';

$sqlHoy = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    WHERE " . implode(' AND ', $whereHoy);

$stmtHoy = $conn->prepare($sqlHoy);

if ($stmtHoy) {
    if ($typesHoy !== '') {
        $stmtHoy->bind_param($typesHoy, ...$paramsHoy);
    }

    $stmtHoy->execute();
    $resHoy = $stmtHoy->get_result();
    $rowHoy = $resHoy ? $resHoy->fetch_assoc() : null;
    $totalHoy = (int)($rowHoy['total'] ?? 0);
    $stmtHoy->close();
}

/* MAPA DE TIENDAS PARA MOSTRAR NOMBRE CORRECTO */
$storeMapAud = [];

$usuariosMapAud = [];
$resUsuariosAud = $conn->query('SELECT id, usuario, nombre_completo FROM usuarios');
if ($resUsuariosAud instanceof mysqli_result) {
    while ($usuarioAud = $resUsuariosAud->fetch_assoc()) {
        $loginAud = trim((string)($usuarioAud['usuario'] ?? ''));
        $nombreAud = trim((string)($usuarioAud['nombre_completo'] ?? ''));
        $usuariosMapAud[(string)(int)($usuarioAud['id'] ?? 0)] = $nombreAud !== ''
            ? $nombreAud . ' (@' . $loginAud . ')'
            : $loginAud;
    }
    $resUsuariosAud->free();
} else {
    error_log('No se pudo cargar el mapa de usuarios para mostrar cambios de permisos en auditoría: ' . $conn->error);
}

if (aud_table_exists($conn, 'usuario_tienda')) {
    $sqlStoresAud = "
        SELECT DISTINCT
            COALESCE(NULLIF(pais, ''), 'HN') AS pais,
            COALESCE(NULLIF(zona, ''), '') AS zona,
            COALESCE(NULLIF(codalmacen, ''), '') AS codalmacen,
            COALESCE(NULLIF(nombrealmacen, ''), '') AS nombrealmacen
        FROM usuario_tienda
        WHERE COALESCE(TRIM(codalmacen), '') <> ''
    ";

    $resStoresAud = $conn->query($sqlStoresAud);

  if ($resStoresAud instanceof mysqli_result) {

    while ($store = $resStoresAud->fetch_assoc()) {

        /* NORMALIZAR DATOS */
        $regionStore = aud_region_label_from_pais(
            (string)($store['pais'] ?? '')
        );

        $regionStore = aud_normalizar_region($regionStore);

        $codStore = strtoupper(
            trim((string)($store['codalmacen'] ?? ''))
        );

        $zonaStore = strtoupper(
            trim((string)($store['zona'] ?? ''))
        );

        $nomStore = trim(
            (string)($store['nombrealmacen'] ?? '')
        );

        /* VALIDAR */
        if ($regionStore === '' || $codStore === '') {
            continue;
        }

        /* LLAVE ÚNICA: */
        $keyStore = aud_store_country_key(
            $regionStore,
            $codStore
        );

        /* GUARDAR SIEMPRE */
        $storeMapAud[$keyStore] = [
            'nombre' => $nomStore !== ''
                ? $nomStore
                : $codStore,

            'zona' => $zonaStore,
        ];
    }
}
}
/* LISTADO PAGINADO */
$rows = [];

$sql = "
    SELECT
        a.id,
        a.fecha,
        a.usuario,
        a.rol,
        a.modulo,
        a.accion,
        a.descripcion,
        a.region,
        a.zona,
        a.tienda,
        a.codalmacen,
        a.ip
    FROM auditoria a
    {$whereSql}
    ORDER BY a.fecha DESC, a.id DESC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

if ($stmt) {
    $bindTypes  = $types . 'ii';
    $bindParams = array_merge($params, [$perPage, $offset]);

    $stmt->bind_param($bindTypes, ...$bindParams);
    $stmt->execute();

    $res = $stmt->get_result();

    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $descripcion = (string)($r['descripcion'] ?? '');

            /* NORMALIZAR REGIÓN / ZONA / CODALMACEN */
            $region = trim((string)($r['region'] ?? ''));

            if ($region === '') {
                $region = aud_extract_region_from_description($descripcion);
            }

            $region = aud_normalizar_region($region);

            $zona = trim((string)($r['zona'] ?? ''));

            if ($zona === '') {
                $zona = aud_extract_zona_from_description($descripcion);
            }

            $codalmacen = trim((string)($r['codalmacen'] ?? ''));

            if ($codalmacen === '') {
                $codalmacen = aud_extract_codalmacen_from_description($descripcion);
            }

            $r['region'] = $region;
            $r['zona'] = strtoupper(trim($zona));
            $r['codalmacen'] = strtoupper(trim($codalmacen));

            /* BUSCAR NOMBRE REAL DE LA TIENDA */
            $storeKeySimple = aud_store_country_key($r['region'], $r['codalmacen']);
            $storeInfo = $storeMapAud[$storeKeySimple] ?? null;

            $tiendaOriginal = trim((string)($r['tienda'] ?? ''));

/* FORZAR NOMBRE CORRECTO POR REGION + CODALMACEN */
if ($storeInfo !== null) {
    $nombreTienda = (string)($storeInfo['nombre'] ?? '');
} else {
    $nombreTienda = $tiendaOriginal;
}

            if ($r['zona'] === '' && $storeInfo !== null) {
                $r['zona'] = strtoupper(trim((string)($storeInfo['zona'] ?? '')));
            }

            if ($nombreTienda === '') {
                $nombreTienda = $r['codalmacen'];
            }

            $r['tienda_nombre'] = $nombreTienda;
            $r['tienda_display'] = $r['codalmacen'] !== ''
                ? ($r['codalmacen'] . ' - ' . $nombreTienda)
                : $nombreTienda;

            $r['llave_tienda'] = aud_store_key($r['region'], $r['zona'], $r['codalmacen']);

            $rows[] = $r;
        }
    }

    $stmt->close();
}

/* COMPLETAR REFERENCIAS EN REGISTROS ANTIGUOS DE EXHIBICIÓN */
$referenciasPendientes = [];
foreach ($rows as $indice => $rowAuditoria) {
    if ((string)($rowAuditoria['modulo'] ?? '') !== 'EXHIBICION') {
        continue;
    }

    $descripcion = (string)($rowAuditoria['descripcion'] ?? '');
    if (preg_match('/(?:^|\|)\s*REFERENCIA\s*:/i', $descripcion)) {
        continue;
    }

    $codigoArticulo = trim((string)aud_extract_field_from_description($descripcion, 'CODARTICULO'));
    $regionArticulo = aud_normalizar_region((string)($rowAuditoria['region'] ?? ''));
    if ($codigoArticulo === '' || !ctype_digit($codigoArticulo)
        || !in_array($regionArticulo, ['HONDURAS', 'NICARAGUA'], true)) {
        continue;
    }

    $claveArticulo = $regionArticulo . '|' . $codigoArticulo;
    if (!isset($referenciasPendientes[$claveArticulo])) {
        $referenciasPendientes[$claveArticulo] = [
            'indices' => [],
            'region' => $regionArticulo,
            'codigo' => $codigoArticulo,
        ];
    }
    $referenciasPendientes[$claveArticulo]['indices'][] = $indice;
}

if ($referenciasPendientes !== [] && function_exists('sqlsrv_connect')) {
    $rutaPrivada = dirname(__DIR__, 3)
        . DIRECTORY_SEPARATOR . 'privado_exhibicion'
        . DIRECTORY_SEPARATOR . 'credenciales.php';

    if (is_file($rutaPrivada) && is_readable($rutaPrivada)) {
        try {
            $configuracionAud = require $rutaPrivada;
            $configSqlAud = is_array($configuracionAud)
                ? ($configuracionAud['sqlserver'] ?? null)
                : null;

            if (is_array($configSqlAud)) {
                $servidorAud = trim((string)($configSqlAud['servidor'] ?? ''));
                $baseAud = trim((string)($configSqlAud['base'] ?? ''));
                $usuarioAud = trim((string)($configSqlAud['usuario'] ?? ''));
                $claveAud = (string)($configSqlAud['clave'] ?? '');
                $opcionesAud = [
                    'Database' => $baseAud,
                    'CharacterSet' => 'UTF-8',
                    'Encrypt' => true,
                    'TrustServerCertificate' => true,
                    'LoginTimeout' => 5,
                ];

                if ($usuarioAud !== '' && $claveAud !== '') {
                    $opcionesAud['UID'] = $usuarioAud;
                    $opcionesAud['PWD'] = $claveAud;
                }

                if ($servidorAud !== '' && $baseAud !== ''
                    && (($usuarioAud === '') === ($claveAud === ''))) {
                    $conexionAud = @sqlsrv_connect($servidorAud, $opcionesAud);

                    if ($conexionAud !== false) {
                        foreach ($referenciasPendientes as $pendiente) {
                            $baseCatalogo = $pendiente['region'] === 'NICARAGUA'
                                ? 'ACANICARAGUA2'
                                : 'DETODO';
                            $sqlReferencia = "
                                SELECT TOP 1 LTRIM(RTRIM(CONVERT(NVARCHAR(255), REFPROVEEDOR))) AS REFERENCIA
                                FROM {$baseCatalogo}.dbo.ARTICULOS
                                WHERE CODARTICULO = ?
                            ";
                            $stmtReferencia = sqlsrv_query(
                                $conexionAud,
                                $sqlReferencia,
                                [$pendiente['codigo']]
                            );

                            if ($stmtReferencia === false) {
                                error_log(
                                    'No se pudo recuperar una referencia histórica para auditoría: '
                                    . print_r(sqlsrv_errors(), true)
                                );
                                continue;
                            }

                            $filaReferencia = sqlsrv_fetch_array($stmtReferencia, SQLSRV_FETCH_ASSOC);
                            sqlsrv_free_stmt($stmtReferencia);
                            $referencia = trim((string)($filaReferencia['REFERENCIA'] ?? ''));

                            if ($referencia !== '') {
                                foreach ($pendiente['indices'] as $indice) {
                                    $rows[$indice]['descripcion'] .= ' | REFERENCIA: ' . $referencia;
                                }
                            }
                        }

                        sqlsrv_close($conexionAud);
                    } else {
                        error_log(
                            'No se pudo conectar a SQL Server para completar referencias históricas: '
                            . print_r(sqlsrv_errors(), true)
                        );
                    }
                } else {
                    error_log('Configuración SQL Server incompleta para completar referencias históricas de auditoría.');
                }
            } else {
                error_log('No existe una configuración SQL Server válida para completar referencias históricas de auditoría.');
            }
        } catch (Throwable $errorReferencia) {
            error_log('Error completando referencias históricas de auditoría: ' . $errorReferencia->getMessage());
        }
    } else {
        error_log('No se encontró la configuración SQL Server para completar referencias históricas de auditoría.');
    }
}

/* QUERY BASE PARA PAGINACIÓN */
$queryWithoutPage = $_GET;
unset($queryWithoutPage['page']);
$baseQuery = http_build_query($queryWithoutPage);
?>
<link rel="stylesheet" href="/exhibicion_DT/auditoria/css/aut.css?v=8">

<!-- ENCABEZADO MODULAR MODERNO -->
<div class="aud-top-box">
    <div class="aud-tb-info">
        <div class="aud-tb-icon">
            <i class="bi bi-shield-check"></i>
        </div>
        <div>
            <h2></h2>
            <p>Registro y control detallado de movimientos de usuarios</p>
        </div>
    </div>
    <div class="aud-tb-action">
        <a href="index.php?vista=modulo2" class="aud-reset-pill" title="Limpiar todos los filtros">
            <i class="bi bi-arrow-counterclockwise"></i>
            <span>Limpiar filtros</span>
        </a>
    </div>
</div>

<!-- BARRA DE MÉTRICAS RÁPIDAS -->
<div class="aud-metrics-bar">
    <div class="aud-metrics-summary">
        <div class="aud-metric-item">
            <i class="bi bi-database"></i>
            <span>Total registros: <strong><?= $totalRows ?></strong></span>
        </div>
        <div class="aud-metric-item aud-metric-highlight">
            <i class="bi bi-calendar-event"></i>
            <span>Movimientos hoy: <strong><?= $totalHoy ?></strong></span>
        </div>
    </div>
    <div class="aud-metric-perpage">
        <form method="get" action="index.php" id="formPerPageAud">
            <input type="hidden" name="vista" value="modulo2">
            <?php foreach ($_GET as $k => $v): ?>
                <?php if ($k !== 'per_page' && $k !== 'page' && $k !== 'vista'): ?>
                    <input type="hidden" name="<?= h_aud($k) ?>" value="<?= h_aud((string)$v) ?>">
                <?php endif; ?>
            <?php endforeach; ?>
            <label for="per_page_aud">Mostrar:</label>
            <select name="per_page" id="per_page_aud" class="aud-select-styled">
                <option value="100" <?= $perPage === 100 ? 'selected' : '' ?>>100</option>
                <option value="200" <?= $perPage === 200 ? 'selected' : '' ?>>200</option>
                <option value="500" <?= $perPage === 500 ? 'selected' : '' ?>>500</option>
            </select>
        </form>
    </div>
</div>

<!-- TABLA CON FILTROS TIPO EXCEL EN LA CABECERA -->
<div class="aud-table-frame">
    <form method="get" id="formFiltrosAud" action="index.php">
        <input type="hidden" name="vista" value="modulo2">
        <input type="hidden" name="per_page" value="<?= h_aud((string)$perPage) ?>">
    </form>

    <table class="aud-modern-table">
        <thead>
            <tr>
                <!-- Columna Fecha -->
                <th>
                    <div class="aud-th-wrap">
                        <span>Fecha y Hora</span>
                        <div class="aud-dropdown-filter">
                            <i class="bi bi-funnel aud-filter-icon <?= (!empty($filters['fecha_inicio']) || !empty($filters['fecha_fin'])) ? 'active-filter' : '' ?>" title="Filtrar fecha"></i>
                            <div class="aud-filter-popup">
                                <label for="aud_fecha_inicio">Desde:</label>
                                <input form="formFiltrosAud" type="date" id="aud_fecha_inicio" name="fecha_inicio" value="<?= h_aud($filters['fecha_inicio']) ?>" class="aud-input-popup">
                                <label for="aud_fecha_fin">Hasta:</label>
                                <input form="formFiltrosAud" type="date" id="aud_fecha_fin" name="fecha_fin" value="<?= h_aud($filters['fecha_fin']) ?>" class="aud-input-popup">
                                <div class="aud-popup-buttons">
                                    <button form="formFiltrosAud" type="submit" class="aud-popup-btn">Aplicar</button>
                                    <a href="index.php?vista=modulo2" class="aud-popup-btn-clear">Limpiar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </th>

                <!-- Columna Usuario -->
                <th>
                    <div class="aud-th-wrap">
                        <span>Usuario</span>
                        <div class="aud-dropdown-filter">
                            <i class="bi bi-funnel aud-filter-icon <?= !empty($filters['usuario']) ? 'active-filter' : '' ?>" title="Filtrar usuario"></i>
                            <div class="aud-filter-popup">
                                <label for="aud_usuario">Buscar usuario:</label>
                                <input form="formFiltrosAud" type="text" id="aud_usuario" name="usuario" value="<?= h_aud($filters['usuario']) ?>" class="aud-input-popup js-aud-text" placeholder="Escribe nombre...">
                                <div class="aud-popup-buttons">
                                    <button form="formFiltrosAud" type="submit" class="aud-popup-btn">Aplicar</button>
                                    <a href="index.php?vista=modulo2" class="aud-popup-btn-clear">Limpiar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </th>

                <th>Rol</th>

                <!-- Columna Módulo -->
                <th>
                    <div class="aud-th-wrap">
                        <span>Módulo</span>
                        <div class="aud-dropdown-filter">
                            <i class="bi bi-funnel aud-filter-icon<?= !empty($filters['modulo']) ? 'active-filter' : '' ?>" title="Filtrar módulo"></i>
                            <div class="aud-filter-popup">
                                <label for="aud_modulo">Módulo:</label>
                                <select form="formFiltrosAud" id="aud_modulo" name="modulo" class="aud-input-popup">
                                    <option value="">Todos los módulos</option>
                                    <?php foreach ($modulos as $m): ?>
                                        <option value="<?= h_aud($m) ?>" <?= $filters['modulo'] === $m ? 'selected' : '' ?>><?= h_aud(aud_modulo_label($m)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="aud-popup-buttons">
                                    <button form="formFiltrosAud" type="submit" class="aud-popup-btn">Aplicar</button>
                                    <a href="index.php?vista=modulo2" class="aud-popup-btn-clear">Limpiar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </th>

                <!-- Columna Acción -->
                <th>
                    <div class="aud-th-wrap">
                        <span>Acción</span>
                        <div class="aud-dropdown-filter">
                            <i class="bi bi-funnel aud-filter-icon <?= !empty($filters['accion']) ? 'active-filter' : '' ?>" title="Filtrar acción"></i>
                            <div class="aud-filter-popup">
                                <label for="aud_accion">Acción:</label>
                                <select form="formFiltrosAud" id="aud_accion" name="accion" class="aud-input-popup">
                                    <option value="">Todas las acciones</option>
                                    <?php foreach ($acciones as $a): ?>
                                        <option value="<?= h_aud($a) ?>" <?= $filters['accion'] === $a ? 'selected' : '' ?>><?= h_aud(aud_modulo_label($a)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="aud-popup-buttons">
                                    <button form="formFiltrosAud" type="submit" class="aud-popup-btn">Aplicar</button>
                                    <a href="index.php?vista=modulo2" class="aud-popup-btn-clear">Limpiar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </th>

                <th>Descripción del Movimiento</th>
                <th>Zona</th>
                <th class="center">IP</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($rows)): ?>
                <tr>
                    <td colspan="8" class="aud-empty-notice">
                        <i class="bi bi-inbox"></i>
                        <p>No se encontraron registros de auditoría disponibles.</p>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td class="aud-date-cell"><?= h_aud($r['fecha'] ?? '') ?></td>
                        <td><strong class="aud-user-text"><?= h_aud($r['usuario'] ?? '') ?></strong></td>
                        <td><span class="aud-pill-role"><?= h_aud($r['rol'] ?? '') ?></span></td>
                        <td><span class="aud-tag-mod"><?= h_aud(aud_modulo_label((string)($r['modulo'] ?? ''))) ?></span></td>
                        <td><span class="aud-tag-act"><?= h_aud(aud_modulo_label((string)($r['accion'] ?? ''))) ?></span></td>
                        <td class="aud-desc-cell"><?= aud_format_descripcion(
                            (string)($r['descripcion'] ?? ''),
                            (string)($r['modulo'] ?? ''),
                            (string)($r['accion'] ?? ''),
                            (string)($r['region'] ?? ''),
                            $storeMapAud,
                            $usuariosMapAud
                        ) ?></td>
                        <td class="aud-zone-cell"><?= h_aud($r['zona'] ?? '') ?></td>
                        <td class="center aud-ip-cell"><code><?= h_aud($r['ip'] ?? '') ?></code></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- PAGINACIÓN ELEGANTE -->
<?php if ($totalPages > 1): ?>
    <div class="aud-modern-pagination">
        <?php if ($page > 1): ?>
            <a class="aud-mp-btn" href="<?= h_aud(aud_page_url(1, $baseQuery)) ?>"><i class="bi bi-chevron-double-left"></i></a>
            <a class="aud-mp-btn" href="<?= h_aud(aud_page_url($page - 1, $baseQuery)) ?>"><i class="bi bi-chevron-left"></i></a>
        <?php endif; ?>

        <?php 
        $start = max(1, $page - 2);
        $end   = min($totalPages, $page + 2);
        ?>

        <?php if ($start > 1): ?><span class="aud-mp-dots">...</span><?php endif; ?>

        <?php for ($i = $start; $i <= $end; $i++): ?>
            <?php if ($i === $page): ?>
                <span class="aud-mp-btn active"><?= $i ?></span>
            <?php else: ?>
                <a class="aud-mp-btn" href="<?= h_aud(aud_page_url($i, $baseQuery)) ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if ($end < $totalPages): ?><span class="aud-mp-dots">...</span><?php endif; ?>

        <?php if ($page < $totalPages): ?>
            <a class="aud-mp-btn" href="<?= h_aud(aud_page_url($page + 1, $baseQuery)) ?>"><i class="bi bi-chevron-right"></i></a>
            <a class="aud-mp-btn" href="<?= h_aud(aud_page_url($totalPages, $baseQuery)) ?>"><i class="bi bi-chevron-double-right"></i></a>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const perPageSelect = document.getElementById('per_page_aud');
    const perPageForm = document.getElementById('formPerPageAud');

    if (perPageSelect && perPageForm) {
        perPageSelect.addEventListener('change', function () {
            perPageForm.submit();
        });
    }

    document.querySelectorAll('.aud-filter-icon').forEach(icon => {
        icon.addEventListener('click', function(e) {
            e.stopPropagation();
            document.querySelectorAll('.aud-filter-popup').forEach(p => {
                if (p !== this.nextElementSibling) p.style.display = 'none';
            });
            const filterPopup = this.nextElementSibling;
            filterPopup.style.display = filterPopup.style.display === 'block' ? 'none' : 'block';
        });
    });

    document.addEventListener('click', function() {
        document.querySelectorAll('.aud-filter-popup').forEach(p => {
            p.style.display = 'none';
        });
    });

    document.querySelectorAll('.aud-filter-popup').forEach(p => {
        p.addEventListener('click', e => e.stopPropagation());
    });
});
</script>