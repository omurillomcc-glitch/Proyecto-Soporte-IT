<?php
// En Exhibición DT el usuario final no puede modificar su propia contraseña.
// Todos los restablecimientos pasan por el módulo Usuarios con permisos y auditoría.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
require_once __DIR__ . '/auth.php';
require_login();
http_response_code(403);
echo json_encode([
    'ok' => false,
    'msg' => 'La contraseña solo puede ser actualizada por un administrador autorizado desde el menú Usuarios.'
], JSON_UNESCAPED_UNICODE);
