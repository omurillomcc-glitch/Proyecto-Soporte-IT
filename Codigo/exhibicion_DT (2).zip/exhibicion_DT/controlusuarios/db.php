
<?php


$rutaPrivada = dirname(__DIR__, 3)
    . DIRECTORY_SEPARATOR . 'privado_exhibicion'
    . DIRECTORY_SEPARATOR . 'credenciales.php';


if (!is_file($rutaPrivada) || !is_readable($rutaPrivada)) {

    error_log(
        'Exhibición DT: no se encontró el archivo privado de credenciales.'
    );

    http_response_code(503);
    exit('No se pudo cargar la configuración de la base de datos.');
}


$configuracion = require $rutaPrivada;

$mysql = is_array($configuracion)
    ? ($configuracion['mysql'] ?? null)
    : null;


if (
    !is_array($mysql) ||
    !isset(
        $mysql['host'],
        $mysql['usuario'],
        $mysql['clave'],
        $mysql['base']
    )
) {

    error_log('Exhibición DT: configuración MySQL incompleta.');

    http_response_code(503);
    exit('La configuración de la base de datos está incompleta.');
}


try {

    mysqli_report(
        MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT
    );

    $conn = new mysqli(
        (string) $mysql['host'],
        (string) $mysql['usuario'],
        (string) $mysql['clave'],
        (string) $mysql['base'],
        isset($mysql['puerto']) ? (int) $mysql['puerto'] : 3306 // Usa 3307 si existe, si no 3306 por cambiar docker

    );


    $conn->set_charset('utf8mb4');

} catch (Throwable $e) {


    error_log(
        'Exhibición DT - Error MySQL: ' . $e->getMessage()
    );

    http_response_code(503);

    exit(
        'No se pudo establecer conexión con la base de datos.'
    );
}
