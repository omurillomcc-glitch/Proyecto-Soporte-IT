<?php
declare(strict_types=1);


if (session_status() === PHP_SESSION_NONE) {

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');


    $usaHttps = (
        !empty($_SERVER['HTTPS']) &&
        strtolower((string) $_SERVER['HTTPS']) !== 'off'
    );

    session_name('APP_EXHIBICION');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $usaHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}


if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 3600);
}


if (!defined('SESSION_LIFETIME')) {
    define('SESSION_LIFETIME', 28800);
}


function cerrar_sesion_segura(): void
{
    $_SESSION = [];


    if (ini_get('session.use_cookies')) {

        $cookie = session_get_cookie_params();

        setcookie(session_name(), '', [
            'expires'  => time() - 3600,
            'path'     => $cookie['path'],
            'domain'   => $cookie['domain'],
            'secure'   => (bool) $cookie['secure'],
            'httponly' => (bool) $cookie['httponly'],
            'samesite' => $cookie['samesite'] ?: 'Lax'
        ]);
    }

    session_destroy();

    header(
        'Location: /exhibicion_DT/controlusuarios/login.php?expired=1'
    );

    exit;
}


function validar_tiempo_sesion(): void
{
    if (empty($_SESSION['usuario_id'])) {
        return;
    }

    $ahora = time();

    $ultimaActividad = (int) (
        $_SESSION['LAST_ACTIVITY'] ?? $ahora
    );

    $creada = (int) (
        $_SESSION['CREATED'] ?? $ahora
    );


    if (
        ($ahora - $ultimaActividad) > SESSION_TIMEOUT ||
        ($ahora - $creada) > SESSION_LIFETIME
    ) {
        cerrar_sesion_segura();
    }

    $_SESSION['LAST_ACTIVITY'] = $ahora;
    $_SESSION['CREATED'] = $creada;
}


function require_login(): void
{
    validar_tiempo_sesion();

    if (empty($_SESSION['usuario_id'])) {

        header(
            'Location: /exhibicion_DT/controlusuarios/login.php'
        );

        exit;
    }


    if ((int) ($_SESSION['estado'] ?? 0) !== 1) {
        cerrar_sesion_segura();
    }

    auth_verificar_cuenta();
    // La contraseña se administra en Usuarios; no redirigir al usuario final.
    // Los cambios anteriores quedan sin efecto para evitar bucles de redirección.
    $_SESSION['password_cambio_obligatorio'] = false;
}


// Revalidar estado y rol en la base de datos en cada solicitud.
function auth_verificar_cuenta(): void
{
    static $comprobada = false;
    if ($comprobada || empty($_SESSION['usuario_id'])) return;
    global $conn;
    require_once __DIR__ . '/db.php';
    $conexion = $GLOBALS['conn'] ?? null;
    if (!$conexion instanceof mysqli) {
        http_response_code(503);
        exit('No se pudo verificar la sesión.');
    }
    $id = (int)$_SESSION['usuario_id'];
    $stmt = $conexion->prepare('SELECT usuario, rol, estado, pais_code FROM usuarios WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $cuenta = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$cuenta || (int)$cuenta['estado'] !== 1) {
        cerrar_sesion_segura();
    }
    $paisBase = strtoupper(trim((string)($cuenta['pais_code'] ?? '')));
    $paisSesion = strtoupper(trim((string)($_SESSION['pais_code'] ?? '')));
    if (in_array($paisBase, ['HN', 'NI'], true) && $paisSesion !== $paisBase) {
        cerrar_sesion_segura();
    }
    $_SESSION['usuario'] = (string)$cuenta['usuario'];
    $_SESSION['rol'] = (string)$cuenta['rol'];
    $_SESSION['estado'] = (int)$cuenta['estado'];
    require_once __DIR__ . '/password_security.php';
    $_SESSION['password_cambio_obligatorio'] = false; // Renovación gestionada por administradores.
    $comprobada = true;
}

// Los permisos se verifican también al entrar por URL directa.
function require_module_access(string $modulo): void
{
    require_login();
    global $conn;
    require_once __DIR__ . '/db.php';
    require_once __DIR__ . '/accesos_menu.php';
    $conexion = $GLOBALS['conn'] ?? null;
    if (!$conexion instanceof mysqli || !am_puede($conexion, (int)$_SESSION['usuario_id'], $modulo)) {
        require_once __DIR__ . '/security_events.php';
        exdt_registrar_evento('ACCESO_DENEGADO', (string)($_SESSION['usuario'] ?? ''),
            (string)($_SERVER['REMOTE_ADDR'] ?? ''), $modulo);
        http_response_code(403);
        exit('Acceso denegado a este módulo.');
    }
}

function app_csrf_token(): string
{
    if (empty($_SESSION['app_csrf'])) {
        $_SESSION['app_csrf'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['app_csrf'];
}

function app_require_csrf(): void
{
    $recibido = (string)($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($recibido === '' || !hash_equals(app_csrf_token(), $recibido)) {
        require_once __DIR__ . '/security_events.php';
        exdt_registrar_evento('FORMULARIO_RECHAZADO', (string)($_SESSION['usuario'] ?? ''),
            (string)($_SERVER['REMOTE_ADDR'] ?? ''));
        http_response_code(403);
        exit('Formulario vencido. Actualiza la pantalla.');
    }
}

function require_user_admin(): void
{
    require_login();

    $rol = (string) ($_SESSION['rol'] ?? '');

    if (!in_array(
        $rol,
        ['super_admin', 'admin_zona'],
        true
    )) {

        require_once __DIR__ . '/security_events.php';
        exdt_registrar_evento('ACCESO_DENEGADO', (string)($_SESSION['usuario'] ?? ''),
            (string)($_SERVER['REMOTE_ADDR'] ?? ''), 'usuarios');
        http_response_code(403);

        exit('Acceso denegado.');
    }
}


function me(): array
{
    return [
        'id'         => (int) ($_SESSION['usuario_id'] ?? 0),
        'usuario'    => (string) ($_SESSION['usuario'] ?? ''),
        'rol'        => (string) ($_SESSION['rol'] ?? ''),
        'estado'     => (int) ($_SESSION['estado'] ?? 0),
        'pais_code'  => (string) ($_SESSION['pais_code'] ?? ''),
        'pais'       => (string) ($_SESSION['pais'] ?? ''),
        'zona'       => (string) ($_SESSION['zona'] ?? ''),
        'tienda'     => (string) ($_SESSION['tienda'] ?? ''),
        'codalmacen' => (string) ($_SESSION['codalmacen'] ?? '')
    ];
}
