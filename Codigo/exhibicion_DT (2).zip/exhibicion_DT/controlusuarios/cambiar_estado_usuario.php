<?php
declare(strict_types=1);


header('Content-Type: application/json; charset=utf-8');


session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


ini_set('display_errors', '0');
error_reporting(E_ALL);


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';


function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

function aud_region_label_from_pais(string $paisCode): string
{
    return match (strtoupper(trim($paisCode))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($paisCode)),
    };
}


if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'msg' => 'Método no permitido.']);
    exit;
}
require_user_admin();
$tokenEnviado = (string)($_POST['csrf_usuarios'] ?? '');
$tokenSesion = (string)($_SESSION['csrf_usuarios'] ?? '');
if ($tokenSesion === '' || !hash_equals($tokenSesion, $tokenEnviado)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'El formulario expiró. Recarga la página.']);
    exit;
}

$me = me();
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId  = (int)($me['id'] ?? 0);
$miRol = (string)($me['rol'] ?? '');


if ($miRol !== 'super_admin') {
    json_out(false, 'Solo el super_admin puede bloquear o desbloquear usuarios.');
}


$id     = (int)($_POST['id'] ?? 0);
$estado = isset($_POST['estado']) ? (int)($_POST['estado']) : -1;


if ($id <= 0 || !in_array($estado, [0, 1], true)) {
    json_out(false, 'Datos inválidos.');
}


if (am_es_propietario($conn, $id)) {
    json_out(false, 'La cuenta propietaria no se puede bloquear.');
}

if ($id === $miId) {
    json_out(false, 'No puedes bloquearte a ti misma.');
}


if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    json_out(false, 'No puedes cambiar el estado de este usuario.');
}


$stmtUser = $conn->prepare("
    SELECT usuario, rol, pais_code
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmtUser) {
    json_out(false, 'No se pudo consultar el usuario.');
}

$stmtUser->bind_param("i", $id);
$stmtUser->execute();
$resUser = $stmtUser->get_result();
$userRow = $resUser ? $resUser->fetch_assoc() : null;
$stmtUser->close();

if (!$userRow) {
    json_out(false, 'Usuario no encontrado.');
}


$usuarioObjetivo = (string)($userRow['usuario'] ?? '');
$rolObjetivo     = (string)($userRow['rol'] ?? '');
$paisObjetivo    = (string)($userRow['pais_code'] ?? '');


$zonaObjetivo = '';
$tiendaObjetivo = '';
$codalmacenObjetivo = '';

$stmtStore = $conn->prepare("
    SELECT zona, nombrealmacen, codalmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY id ASC
    LIMIT 1
");

if ($stmtStore) {
    $stmtStore->bind_param("i", $id);
    $stmtStore->execute();
    $resStore = $stmtStore->get_result();
    $storeRow = $resStore ? $resStore->fetch_assoc() : null;
    $stmtStore->close();

    if ($storeRow) {
        $zonaObjetivo       = (string)($storeRow['zona'] ?? '');
        $tiendaObjetivo     = (string)($storeRow['nombrealmacen'] ?? '');
        $codalmacenObjetivo = (string)($storeRow['codalmacen'] ?? '');
    }
}


$stmt = $conn->prepare("
    UPDATE usuarios
    SET estado = ?
    WHERE id = ?
");

if (!$stmt) {
    json_out(false, 'No se pudo preparar el cambio de estado.');
}

$stmt->bind_param("ii", $estado, $id);

if (!$stmt->execute()) {
    $err = $stmt->error;
    $stmt->close();
    json_out(false, 'No se pudo cambiar el estado del usuario: ' . $err);
}

$stmt->close();


registrar_auditoria(
    'USUARIOS',
    $estado === 1 ? 'USUARIO_DESBLOQUEADO' : 'USUARIO_BLOQUEADO',
    $estado === 1
        ? 'Se desbloqueó el usuario: ' . $usuarioObjetivo . ' | Rol: ' . $rolObjetivo
        : 'Se bloqueó el usuario: ' . $usuarioObjetivo . ' | Rol: ' . $rolObjetivo,
    aud_region_label_from_pais($paisObjetivo),
    $zonaObjetivo,
    $tiendaObjetivo,
    $codalmacenObjetivo
);


json_out(
    true,
    $estado === 1
        ? 'Usuario desbloqueado correctamente.'
        : 'Usuario bloqueado correctamente.'
);