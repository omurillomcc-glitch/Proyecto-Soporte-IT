<?php
declare(strict_types=1);


function u_h(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}


function u_norm($v): string {
    return trim((string)$v);
}


function u_pais_code(string $pais): string {
    $pais = mb_strtoupper(u_norm($pais), 'UTF-8');

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}


function u_pais_nombre(string $pais): string {
    $code = u_pais_code($pais);

    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => u_norm($pais),
    };
}


function u_store_key(string $pais, string $base, string $cod): string {
    return mb_strtoupper(
        u_pais_code($pais) . '|' . u_norm($base) . '|' . u_norm($cod),
        'UTF-8'
    );
}


function u_store_key_from_array(array $t): string {
    return u_store_key(
        (string)($t['pais_code'] ?? $t['pais'] ?? ''),
        (string)($t['base_datos'] ?? ''),
        (string)($t['codalmacen'] ?? '')
    );
}


function u_store_token(array $t): string {
    return base64_encode(json_encode([
        'pais'          => u_pais_nombre((string)($t['pais'] ?? $t['pais_code'] ?? '')),
        'pais_code'     => u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? '')),
        'base_datos'    => u_norm($t['base_datos'] ?? ''),
        'zona'          => u_norm($t['zona'] ?? ''),
        'codalmacen'    => u_norm($t['codalmacen'] ?? ''),
        'nombrealmacen' => u_norm($t['nombrealmacen'] ?? ''),
    ], JSON_UNESCAPED_UNICODE));
}


function u_decode_store_token(string $token): ?array {
    $json = base64_decode($token, true);
    if ($json === false) {
        return null;
    }

    $data = json_decode($json, true);
    if (!is_array($data)) {
        return null;
    }

    $paisCode = u_pais_code((string)($data['pais_code'] ?? $data['pais'] ?? ''));
    $pais     = u_pais_nombre((string)($data['pais'] ?? $paisCode));

    $store = [
        'pais'          => $pais,
        'pais_code'     => $paisCode,
        'base_datos'    => u_norm($data['base_datos'] ?? ''),
        'zona'          => u_norm($data['zona'] ?? ''),
        'codalmacen'    => u_norm($data['codalmacen'] ?? ''),
        'nombrealmacen' => u_norm($data['nombrealmacen'] ?? ''),
    ];

    if (
        $store['pais_code'] === '' ||
        $store['base_datos'] === '' ||
        $store['zona'] === '' ||
        $store['codalmacen'] === '' ||
        $store['nombrealmacen'] === ''
    ) {
        return null;
    }

    return $store;
}


function u_sqlsrv_fetch_all_safe($sqlsrv_conn, string $sql, array $params = []): array {
    $stmt = sqlsrv_query($sqlsrv_conn, $sql, $params);

    if ($stmt === false) {
        throw new RuntimeException('Error consultando SQL Server.');
    }

    $rows = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $rows[] = $row;
    }

    sqlsrv_free_stmt($stmt);
    return $rows;
}


function u_get_all_stores_from_sqlsrv($sqlsrv_conn): array {
    $sqlDetodo = "
        SELECT DISTINCT
            'Honduras' AS pais,
            'HN' AS pais_code,
            'DETODO' AS base_datos,
            LTRIM(RTRIM(POBLACION))     AS zona,
            LTRIM(RTRIM(CODALMACEN))    AS codalmacen,
            LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen
        FROM DETODO.dbo.almacen
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(POBLACION)) <> ''
          AND LTRIM(RTRIM(CODALMACEN)) NOT LIKE '%M'
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $sqlNicaragua = "
        SELECT DISTINCT
            'Nicaragua' AS pais,
            'NI' AS pais_code,
            'ACANICARAGUA2' AS base_datos,
            LTRIM(RTRIM(POBLACION))     AS zona,
            LTRIM(RTRIM(CODALMACEN))    AS codalmacen,
            LTRIM(RTRIM(NOMBREALMACEN)) AS nombrealmacen
        FROM ACANICARAGUA2.dbo.almacen
        WHERE POBLACION IS NOT NULL
          AND LTRIM(RTRIM(POBLACION)) <> ''
          AND LTRIM(RTRIM(CODALMACEN)) NOT LIKE '%M'
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $rows = array_merge(
        u_sqlsrv_fetch_all_safe($sqlsrv_conn, $sqlDetodo),
        u_sqlsrv_fetch_all_safe($sqlsrv_conn, $sqlNicaragua)
    );

    $map = [];
    foreach ($rows as $r) {
        $item = [
            'pais'          => u_pais_nombre((string)($r['pais'] ?? $r['pais_code'] ?? '')),
            'pais_code'     => u_pais_code((string)($r['pais_code'] ?? $r['pais'] ?? '')),
            'base_datos'    => u_norm($r['base_datos'] ?? ''),
            'zona'          => u_norm($r['zona'] ?? ''),
            'codalmacen'    => u_norm($r['codalmacen'] ?? ''),
            'nombrealmacen' => u_norm($r['nombrealmacen'] ?? ''),
        ];

        if (
            $item['pais_code'] === '' ||
            $item['base_datos'] === '' ||
            $item['zona'] === '' ||
            $item['codalmacen'] === '' ||
            $item['nombrealmacen'] === ''
        ) {
            continue;
        }

        $map[u_store_key_from_array($item)] = $item;
    }

    $stores = array_values($map);

    usort($stores, function ($a, $b) {
        return [
            $a['pais_code'], $a['pais'], $a['base_datos'], $a['zona'], $a['codalmacen'], $a['nombrealmacen']
        ] <=> [
            $b['pais_code'], $b['pais'], $b['base_datos'], $b['zona'], $b['codalmacen'], $b['nombrealmacen']
        ];
    });

    return $stores;
}


function u_get_user_store_keys(mysqli $conn, int $usuarioId): array {
    $stmt = $conn->prepare("
        SELECT pais, base_datos, codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
    ");
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();
    $res = $stmt->get_result();

    $keys = [];
    while ($row = $res->fetch_assoc()) {
        $keys[u_store_key(
            (string)($row['pais'] ?? ''),
            (string)($row['base_datos'] ?? ''),
            (string)($row['codalmacen'] ?? '')
        )] = true;
    }

    $stmt->close();
    return $keys;
}


function u_filter_stores_for_admin(mysqli $conn, int $usuarioId, array $stores): array {
    $allowed = u_get_user_store_keys($conn, $usuarioId);

    if (empty($allowed)) {
        return [];
    }

    return array_values(array_filter($stores, function ($t) use ($allowed) {
        return isset($allowed[u_store_key_from_array($t)]);
    }));
}


function u_group_stores(array $stores): array {
    $grouped = [];

    foreach ($stores as $t) {
        $paisNombre = (string)($t['pais'] ?? u_pais_nombre((string)($t['pais_code'] ?? '')));
        $base       = (string)($t['base_datos'] ?? '');
        $zona       = (string)($t['zona'] ?? '');

        $grouped[$paisNombre][$base][$zona][] = $t;
    }

    return $grouped;
}


function u_render_store_checks(array $grouped, string $name, string $class, array $selectedKeys = []): string {
    ob_start();

    if (empty($grouped)) {
        echo '<div class="alert alert-warning">No hay tiendas disponibles.</div>';
        return ob_get_clean();
    }

    foreach ($grouped as $pais => $bases) {
        $paisCode = u_pais_code((string)$pais);

        echo '<div class="mb-4 store-country-group" data-pais="' . u_h($paisCode) . '">';
        echo '<h6 class="fw-bold text-primary">' . u_h((string)$pais) . '</h6>';

        foreach ($bases as $base => $zonas) {
            echo '<div class="border rounded-4 p-3 mb-3 store-base-box">';
            echo '<div class="fw-semibold mb-2">Base: ' . u_h((string)$base) . '</div>';

            foreach ($zonas as $zona => $items) {
                echo '<div class="mb-3 store-zone-group">';
                echo '<div class="small fw-bold text-secondary mb-2">Zona: ' . u_h((string)$zona) . '</div>';
                echo '<div class="row g-2">';

                foreach ($items as $t) {
                    $token   = u_store_token($t);
                    $key     = u_store_key_from_array($t);
                    $checked = isset($selectedKeys[$key]) ? 'checked' : '';
                    $paisC   = u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? ''));

                    echo '<div class="col-md-6 col-xl-4 store-item" data-pais="' . u_h($paisC) . '">';
                    echo '<label class="border rounded-3 p-2 w-100 d-flex align-items-start gap-2">';
                    echo '<input type="checkbox"
                                name="' . u_h($name) . '[]"
                                value="' . u_h($token) . '"
                                data-key="' . u_h($key) . '"
                                data-pais="' . u_h($paisC) . '"
                                class="mt-1 ' . u_h($class) . '"
                                ' . $checked . '>';
                    echo '<span>';
                    echo '<strong>' . u_h((string)($t['codalmacen'] ?? '')) . '</strong> - ' . u_h((string)($t['nombrealmacen'] ?? '')) . '<br>';
                    echo '<small class="text-muted">' . u_h((string)($t['pais'] ?? '')) . ' / ' . u_h((string)($t['base_datos'] ?? '')) . ' / ' . u_h((string)($t['zona'] ?? '')) . '</small>';
                    echo '</span>';
                    echo '</label>';
                    echo '</div>';
                }

                echo '</div>';
                echo '</div>';
            }

            echo '</div>';
        }

        echo '</div>';
    }

    return ob_get_clean();
}


function u_sqlsrv_store_exists($sqlsrv_conn, array $t): bool {
    $base = u_norm($t['base_datos'] ?? '');

    $dbs = [
        'DETODO'        => 'DETODO',
        'ACANICARAGUA2' => 'ACANICARAGUA2',
    ];

    if (!isset($dbs[$base])) {
        return false;
    }

    $db = $dbs[$base];
    $codalmacen = u_norm($t['codalmacen'] ?? '');

    if ($codalmacen === '') {
        return false;
    }

    $sql = "
        SELECT TOP 1 1 AS existe
        FROM {$db}.dbo.almacen
        WHERE LTRIM(RTRIM(CODALMACEN)) = ?
          AND LTRIM(RTRIM(NOMBREALMACEN)) LIKE 'DeTodo%'
    ";

    $stmt = sqlsrv_query($sqlsrv_conn, $sql, [$codalmacen]);

    if ($stmt === false) {
        return false;
    }

    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);

    return $row ? true : false;
}


function u_can_manage_user(mysqli $conn, int $myId, string $myRole, int $targetId): bool {
    if ($myId <= 0 || $targetId <= 0) return false;
    require_once __DIR__ . '/accesos_menu.php';
    if (am_es_propietario($conn, $targetId) && !am_es_propietario($conn, $myId)) {
        return false;
    }


    if ($myRole === 'super_admin') {
        if (am_es_propietario($conn, $myId)) return true;
        $stmt = $conn->prepare('SELECT rol FROM usuarios WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $targetId);
        $stmt->execute();
        $target = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return (string)($target['rol'] ?? '') !== 'super_admin';
    }


    if ($myRole !== 'admin_zona') {
        return false;
    }


    if ($targetId === $myId) {
        return true;
    }


    $stmtMine = $conn->prepare("
        SELECT pais_code
        FROM usuarios
        WHERE id = ?
        LIMIT 1
    ");
    if (!$stmtMine) {
        return false;
    }

    $stmtMine->bind_param("i", $myId);
    $stmtMine->execute();
    $mine = $stmtMine->get_result()->fetch_assoc();
    $stmtMine->close();

    if (!$mine) {
        return false;
    }

    $miPais = u_pais_code((string)($mine['pais_code'] ?? ''));


    $stmtTarget = $conn->prepare("
        SELECT id, rol, pais_code
        FROM usuarios
        WHERE id = ?
        LIMIT 1
    ");
    if (!$stmtTarget) {
        return false;
    }

    $stmtTarget->bind_param("i", $targetId);
    $stmtTarget->execute();
    $target = $stmtTarget->get_result()->fetch_assoc();
    $stmtTarget->close();

    if (!$target) {
        return false;
    }

    $targetRol  = (string)($target['rol'] ?? '');
    $targetPais = u_pais_code((string)($target['pais_code'] ?? ''));


    if ($targetRol === 'super_admin' || $targetRol === 'admin_zona') {
        return false;
    }


    if ($targetPais !== '' && $miPais !== '' && $targetPais !== $miPais) {
        return false;
    }


    $misKeys = u_get_user_store_keys($conn, $myId);
    if (empty($misKeys)) {
        return false;
    }


    $stmtStores = $conn->prepare("
        SELECT pais, base_datos, codalmacen
        FROM usuario_tienda
        WHERE usuario_id = ?
    ");
    if (!$stmtStores) {
        return false;
    }

    $stmtStores->bind_param("i", $targetId);
    $stmtStores->execute();
    $resStores = $stmtStores->get_result();

    $targetTieneTiendas = false;

    while ($row = $resStores->fetch_assoc()) {
        $targetTieneTiendas = true;

        $pais = u_pais_code((string)($row['pais'] ?? ''));
        $key  = u_store_key(
            (string)($row['pais'] ?? ''),
            (string)($row['base_datos'] ?? ''),
            (string)($row['codalmacen'] ?? '')
        );

        if ($miPais !== '' && $pais !== $miPais) {
            $stmtStores->close();
            return false;
        }

        if (!isset($misKeys[$key])) {
            $stmtStores->close();
            return false;
        }
    }

    $stmtStores->close();


    return $targetTieneTiendas;
}

/** Comprueba permiso para restablecer la contraseña de un usuario específico. */
function u_can_reset_password(mysqli $conn, int $actorId, string $actorRol, int $targetId): bool
{
    if (!u_can_manage_user($conn, $actorId, $actorRol, $targetId)) {
        return false;
    }
    $stmt = $conn->prepare('SELECT rol FROM usuarios WHERE id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('i', $targetId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$row) return false;
    $rolDestino = (string)$row['rol'];

    require_once __DIR__ . '/accesos_menu.php';
    if (am_es_propietario($conn, $actorId)) {
        return true;
    }
    if ($actorRol === 'super_admin') {
        return in_array($rolDestino, ['admin_zona', 'tienda'], true);
    }
    if ($actorRol === 'admin_zona') {
        return $actorId !== $targetId && $rolDestino === 'tienda';
    }
    return false;
}
