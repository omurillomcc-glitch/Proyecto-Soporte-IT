
<?php


if (
    isset($_SERVER['SCRIPT_FILENAME']) &&
    realpath((string) $_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__)
) {
    http_response_code(403);
    exit('Acceso denegado.');
}


require_once dirname(__DIR__)
    . '/exhibiciontotal/conexion_exhibicion.php';


if (
    !isset($sqlsrv_conn_exhibicion) ||
    $sqlsrv_conn_exhibicion === false
) {
    error_log(
        'Control de Usuarios: conexión SQL Server no disponible.'
    );

    http_response_code(503);
    exit('No se pudo conectar con SQL Server.');
}


$sqlsrv_conn = $sqlsrv_conn_exhibicion;


