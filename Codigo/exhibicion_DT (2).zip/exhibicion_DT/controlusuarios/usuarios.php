<?php
declare(strict_types=1);


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';


require_user_admin();
$me = me();
if (empty($_SESSION['csrf_usuarios'])) {
    $_SESSION['csrf_usuarios'] = bin2hex(random_bytes(32));
}
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = strtoupper(trim((string)($me['pais_code'] ?? '')));


if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}


try {
    $stores = u_get_all_stores_from_sqlsrv($sqlsrv_conn);

    if ($miRol === 'admin_zona') {
        $stores = u_filter_stores_for_admin($conn, $miId, $stores);
    }

    $groupedStores = u_group_stores($stores);
} catch (Throwable $e) {
    echo '<div class="alert alert-danger">No se pudieron cargar las tiendas desde SQL Server.</div>';
    exit;
}


$rolesPermitidos = am_es_propietario($conn, $miId)
    ? ['super_admin', 'admin_zona', 'tienda']
    : ($miRol === 'super_admin' ? ['admin_zona', 'tienda'] : ['tienda']);


function nombre_pais(string $code): string {
    $code = strtoupper(trim($code));
    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => $code,
    };
}


function render_store_blocks(array $groupedStores, string $inputName, string $inputClass): string {
    ob_start();


    if (empty($groupedStores)) {
        echo '<div class="alert alert-warning alert-custom">No hay tiendas disponibles.</div>';
        return ob_get_clean();
    }


    foreach ($groupedStores as $pais => $bases) {
        $paisCode = u_pais_code((string)$pais);

        echo '<div class="mb-4 store-country-group" data-pais="' . u_h($paisCode) . '">';
        echo '  <h6 class="fw-bold text-primary mb-3">' . u_h((string)$pais) . '</h6>';


        foreach ($bases as $base => $zonas) {
            echo '<div class="store-base-box mb-3">';
            echo '  <div class="store-base-title">Base: ' . u_h((string)$base) . '</div>';


            foreach ($zonas as $zona => $items) {
                echo '<div class="mb-3 store-zone-group">';
                echo '  <div class="store-zone-title">Zona: ' . u_h((string)$zona) . '</div>';
                echo '  <div class="store-grid">';


                foreach ($items as $t) {
                    $token    = u_store_token($t); 

                    $key      = u_store_key_from_array($t); 

                    $paisItem = u_pais_code((string)($t['pais_code'] ?? $t['pais'] ?? ''));

                    $codigo   = (string)($t['codalmacen'] ?? '');
                    $nombre   = (string)($t['nombrealmacen'] ?? '');
                    $paisTxt  = (string)($t['pais'] ?? '');
                    $baseTxt  = (string)($t['base_datos'] ?? '');
                    $zonaTxt  = (string)($t['zona'] ?? '');

                    echo '<div class="store-item" data-pais="' . u_h($paisItem) . '">';
                    echo '  <label class="store-card">';
                    echo '      <input
                                    type="checkbox"
                                    name="' . u_h($inputName) . '[]"
                                    value="' . u_h($token) . '"
                                    data-key="' . u_h($key) . '"
                                    data-pais="' . u_h($paisItem) . '"
                                    class="' . u_h($inputClass) . ' store-check"
                                >';
                    echo '      <div class="store-text">';
                    echo '          <span class="store-name"><strong>' . u_h($codigo) . '</strong> - ' . u_h($nombre) . '</span>';
                    echo '          <span class="store-meta">'
                                    . u_h($paisTxt) . ' / '
                                    . u_h($baseTxt) . ' / '
                                    . u_h($zonaTxt) .
                                '</span>';
                    echo '      </div>';
                    echo '  </label>';
                    echo '</div>';
                }

                echo '  </div>';
                echo '</div>';
            }

            echo '</div>';
        }

        echo '</div>';
    }

    return ob_get_clean();
}
?>


<link rel="stylesheet" href="/exhibicion_DT/controlusuarios/css/usuarios_metis.css?v=20261024r4">
<link rel="stylesheet" href="/exhibicion_DT/controlusuarios/css/usuarios_modales_metis_dinamico.css?v=20261104">

<section class="usuarios-page control-wrap">
    <header class="usuarios-page-header">
        <div class="usuarios-heading">
            <div class="usuarios-heading-icon" aria-hidden="true"><i class="bi bi-people"></i></div>
            <div>
                <p>Usuarios, roles y asignaciones de tiendas</p>
            </div>
        </div>
        <div class="usuarios-header-actions">
            <?php if (am_es_propietario($conn, $miId)): ?>
            <a class="usuarios-btn usuarios-btn-outline" href="/exhibicion_DT/index.php?vista=permisos">
                <i class="bi bi-shield-check" aria-hidden="true"></i> Permisos del menú
            </a>
            <?php endif; ?>
            <button type="button" class="usuarios-btn usuarios-btn-primary btn-main" data-bs-toggle="modal" data-bs-target="#modalCrearUsuario">
                <i class="bi bi-person-plus" aria-hidden="true"></i> Agregar usuario
            </button>
        </div>
    </header>

    <section class="usuarios-directory" aria-labelledby="usuariosListadoTitulo">
        <div class="usuarios-directory-head">
            <div class="usuarios-directory-heading">
            </div>
            <div class="usuarios-directory-label"><span class="usuarios-status-dot"></span> Gestión de accesos</div>
        </div>
        <div id="respuesta_global" aria-live="polite"></div>
        <div id="listaUsuarios">
            <?php include __DIR__ . '/listar_usuarios.php'; ?>
        </div>
    </section>
</section>

<div class="modal fade um-modal" id="modalCrearUsuario" tabindex="-1" aria-hidden="true" aria-labelledby="umCrearTitulo">
    <div class="modal-dialog modal-dialog-centered um-modal-dialog">
        <div class="modal-content um-shell">
            <aside class="um-aside">
                <div class="um-aside-icon"><i class="bi bi-person-plus"></i></div>
                <div class="um-aside-kicker">CONTROL DE USUARIOS</div>
                <h2>Nuevo usuario</h2>
                <p>Configura la cuenta y las tiendas a las que tendrá acceso.</p>
                <div class="um-steps" aria-hidden="true">
                    <div class="um-step"><span>01</span><strong>Identidad</strong></div>
                    <div class="um-step"><span>02</span><strong>Acceso</strong></div>
                    <div class="um-step"><span>03</span><strong>Tiendas</strong></div>
                </div>
                <div class="um-aside-end"><i class="bi bi-shield-check"></i> Administración de accesos</div>
            </aside>

            <div class="um-workspace">
                <div class="modal-header um-topbar">
                    <div>
                        <span class="um-section-tag">CREAR CUENTA</span>
                        <h5 class="modal-title" id="umCrearTitulo">Información del usuario</h5>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>

                <form id="formCrearUsuario" class="um-form" novalidate onsubmit="return false;">
                    <input type="hidden" name="csrf_usuarios" value="<?= u_h($_SESSION['csrf_usuarios']) ?>">
                    <div class="modal-body um-scroll">
                        <section class="um-section">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-person-vcard"></i></span><div><strong>Datos personales</strong><small>Identificación y credenciales</small></div></div>
                            <div class="um-fields">
                                <div class="um-field um-wide">
                                    <label for="crear_nombre_completo">Nombre completo</label>
                                    <input type="text" name="nombre_completo" id="crear_nombre_completo" class="form-control" maxlength="120" autocomplete="name" placeholder="Nombre y apellido" required>
                                </div>
                                <div class="um-field">
                                    <label for="crear_usuario">Usuario</label>
                                    <input type="text" name="usuario" id="crear_usuario" class="form-control" maxlength="30" autocomplete="off" spellcheck="false" placeholder="Usuario de acceso" required oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')">
                                    <small>Solo letras, sin espacios.</small>
                                </div>
                                <div class="um-field">
                                    <label for="crear_password">Contraseña</label>
                                    <input type="password" name="password" id="crear_password" class="form-control" maxlength="64" autocomplete="new-password" spellcheck="false" placeholder="10 a 64 caracteres; permite símbolos" required>
                                    <small>Se permiten caracteres especiales (@, #, $, %, &amp;, !, ?). El administrador asigna la contraseña; el usuario no puede cambiarla desde su sesión.</small>
                                </div>
                            </div>
                        </section>

                        <section class="um-section">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-shield-lock"></i></span><div><strong>Acceso al sistema</strong><small>Rol, país y estado</small></div></div>
                            <div class="um-fields um-fields-three">
                                <div class="um-field">
                                    <label for="crear_rol">Rol</label>
                                    <select name="rol" id="crear_rol" class="form-select" required>
                                        <?php foreach ($rolesPermitidos as $rol): ?>
                                            <option value="<?= u_h($rol) ?>"><?= u_h(match ($rol) {'super_admin' => 'Superadministrador', 'admin_zona' => 'Administrador de zona', 'tienda' => 'Tienda', default => $rol}) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="um-field">
                                    <label for="crear_pais">País</label>
                                    <select name="pais_code" id="crear_pais" class="form-select" required>
                                        <?php if ($miRol === 'super_admin'): ?>
                                            <option value="">Seleccione</option>
                                            <option value="HN">Honduras</option>
                                            <option value="NI">Nicaragua</option>
                                        <?php else: ?>
                                            <option value="<?= u_h($miPais) ?>"><?= u_h(nombre_pais($miPais)) ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="um-field">
                                    <label for="crear_estado">Estado</label>
                                    <select name="estado" id="crear_estado" class="form-select">
                                        <option value="1">Activo</option>
                                        <option value="0">Bloqueado</option>
                                    </select>
                                </div>
                            </div>
                        </section>

                        <div id="mensaje_super_admin_crear" class="um-note" style="display:none;">
                            <i class="bi bi-info-circle"></i>
                            <div><strong>Acceso general</strong><span>El superadministrador no necesita asignaciones de tiendas.</span></div>
                        </div>

                        <section id="bloque_tiendas_crear" class="um-section um-stores">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-shop"></i></span><div><strong>Tiendas asignadas</strong><small>El rol Tienda permite seleccionar una; Admin de zona, varias.</small></div></div>
                            <div class="um-store-list"><?= render_store_blocks($groupedStores, 'tiendas', 'check-crear') ?></div>
                        </section>
                    </div>

                    <div class="modal-footer um-actions">
                        <div class="um-response" id="respuesta_crear" aria-live="polite"></div>
                        <div class="um-action-buttons">
                            <button type="button" class="btn um-btn-plain" data-bs-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn um-btn-main" id="btnGuardarUsuario"><i class="bi bi-check2"></i> Crear usuario</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade um-modal" id="modalEditarUsuario" tabindex="-1" aria-hidden="true" aria-labelledby="umEditarTitulo">
    <div class="modal-dialog modal-dialog-centered um-modal-dialog">
        <div class="modal-content um-shell">
            <aside class="um-aside">
                <div class="um-aside-icon"><i class="bi bi-pencil-square"></i></div>
                <div class="um-aside-kicker">CONTROL DE USUARIOS</div>
                <h2>Editar cuenta</h2>
                <p>Actualiza datos y asignaciones sin alterar el historial del usuario.</p>
                <div class="um-steps" aria-hidden="true">
                    <div class="um-step"><span>01</span><strong>Datos</strong></div>
                    <div class="um-step"><span>02</span><strong>Permisos</strong></div>
                    <div class="um-step"><span>03</span><strong>Tiendas</strong></div>
                </div>
                <div class="um-aside-end"><i class="bi bi-lock"></i> Cambios sujetos a tu rol</div>
            </aside>

            <div class="um-workspace">
                <div class="modal-header um-topbar">
                    <div><span class="um-section-tag">EDITAR CUENTA</span><h5 class="modal-title" id="umEditarTitulo">Modificar información</h5></div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>

                <?php $esAdminZona = ($miRol === 'admin_zona'); ?>
                <form id="formEditarUsuario" class="um-form" novalidate onsubmit="return false;">
                    <input type="hidden" name="csrf_usuarios" value="<?= u_h($_SESSION['csrf_usuarios']) ?>">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="modal-body um-scroll">
                        <section class="um-section">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-person-vcard"></i></span><div><strong>Datos personales</strong><small>Información del usuario registrado</small></div></div>
                            <div class="um-fields">
                                <div class="um-field um-wide">
                                    <label for="edit_nombre_completo">Nombre completo</label>
                                    <input type="text" name="nombre_completo" id="edit_nombre_completo" class="form-control" maxlength="120" autocomplete="name" required <?= $esAdminZona ? 'readonly' : '' ?>>
                                </div>
                                <div class="um-field">
                                    <label for="edit_usuario">Usuario</label>
                                    <input type="text" name="usuario" id="edit_usuario" class="form-control" maxlength="30" autocomplete="off" spellcheck="false" required <?= $esAdminZona ? 'readonly' : '' ?> oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')">
                                </div>
                                <div class="um-field">
                                    <label for="edit_password">Restablecer contraseña</label>
                                    <input type="password" name="password" id="edit_password" class="form-control" maxlength="64" autocomplete="new-password" spellcheck="false" placeholder="Nueva contraseña asignada" >
                                    <small>Propietario: todos. Superadministrador: administradores de zona y tiendas. Administrador de zona: solo tiendas asignadas. La contraseña se renueva desde este menú; el usuario de tienda no puede cambiarla.</small>
                                </div>
                            </div>
                        </section>

                        <section class="um-section">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-shield-lock"></i></span><div><strong>Acceso al sistema</strong><small>Rol, país y estado de la cuenta</small></div></div>
                            <div class="um-fields um-fields-three">
                                <div class="um-field">
                                    <label for="edit_rol">Rol</label>
                                    <select name="rol" id="edit_rol" class="form-select" required <?= $esAdminZona ? 'disabled' : '' ?>>
                                        <?php foreach ($rolesPermitidos as $r): ?>
                                            <option value="<?= u_h($r) ?>"><?= u_h(match ($r) {'super_admin' => 'Superadministrador', 'admin_zona' => 'Administrador de zona', 'tienda' => 'Tienda', default => $r}) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="um-field">
                                    <label for="edit_pais">País</label>
                                    <select name="pais_code" id="edit_pais" class="form-select" required <?= $esAdminZona ? 'disabled' : '' ?>>
                                        <?php if ($miRol === 'super_admin'): ?>
                                            <option value="HN">Honduras</option>
                                            <option value="NI">Nicaragua</option>
                                        <?php else: ?>
                                            <option value="<?= u_h($miPais) ?>"><?= u_h(nombre_pais($miPais)) ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="um-field">
                                    <label for="edit_estado">Estado</label>
                                    <select name="estado" id="edit_estado" class="form-select" <?= $esAdminZona ? 'disabled' : '' ?>>
                                        <option value="1">Activo</option>
                                        <option value="0">Bloqueado</option>
                                    </select>
                                </div>
                            </div>
                        </section>

                        <section id="bloque_tiendas_editar" class="um-section um-stores">
                            <div class="um-section-heading"><span class="um-section-icon"><i class="bi bi-shop"></i></span><div><strong>Tiendas asignadas</strong><small>Selecciona las tiendas que corresponden al usuario.</small></div></div>
                            <div class="um-store-list"><?= render_store_blocks($groupedStores, 'tiendas', 'check-editar') ?></div>
                        </section>
                    </div>

                    <div class="modal-footer um-actions">
                        <div class="um-response" id="respuesta_editar" aria-live="polite"></div>
                        <div class="um-action-buttons">
                            <button type="button" class="btn um-btn-plain" data-bs-dismiss="modal">Cancelar</button>
                            <button type="button" class="btn um-btn-main" id="btnActualizarUsuario"><i class="bi bi-check2"></i> Guardar cambios</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEstadoUsuario" tabindex="-1" aria-hidden="true" aria-labelledby="umEstadoTitulo">
    <div class="modal-dialog modal-dialog-centered um-confirm-dialog">
        <div class="modal-content um-confirm-shell">
            <div class="um-confirm-top">
                <div class="um-confirm-symbol"><i class="bi bi-shield-lock"></i></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body um-confirm-body">
                <input type="hidden" id="estado_id">
                <input type="hidden" id="estado_valor">
                <h5 class="modal-title" id="umEstadoTitulo">Confirmar cambio de estado</h5>
                <p id="estado_texto">¿Deseas continuar?</p>
                <div id="respuesta_estado" aria-live="polite"></div>
            </div>
            <div class="modal-footer um-confirm-footer">
                <button type="button" class="btn um-btn-plain" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn um-btn-main" id="btnConfirmarEstado">Confirmar</button>
            </div>
        </div>
    </div>
</div>

<script>

document.addEventListener("DOMContentLoaded", function () {
    const formCrear = document.getElementById('formCrearUsuario');
    const formEditar = document.getElementById('formEditarUsuario');
    const listaUsuarios = document.getElementById('listaUsuarios');

    

    
    if (!formCrear || !formEditar || !listaUsuarios || typeof bootstrap === 'undefined') {
        return;
    }

    
    ['modalCrearUsuario', 'modalEditarUsuario', 'modalEstadoUsuario'].forEach(function(id) {
        const modal = document.getElementById(id);
        if (modal && modal.parentNode !== document.body) {
            document.body.appendChild(modal);
        }
    });

    
    const crearRol   = document.getElementById('crear_rol');
    const editRol    = document.getElementById('edit_rol');
    const crearPais  = document.getElementById('crear_pais');
    const editPais   = document.getElementById('edit_pais');

    const bloqueCrear  = document.getElementById('bloque_tiendas_crear');
    const bloqueEditar = document.getElementById('bloque_tiendas_editar');

    const mensajeSuperAdminCrear = document.getElementById('mensaje_super_admin_crear');

    const elModalCrear  = document.getElementById('modalCrearUsuario');
    const elModalEditar = document.getElementById('modalEditarUsuario');
    const elModalEstado = document.getElementById('modalEstadoUsuario');

    
    const modalCrear  = bootstrap.Modal.getOrCreateInstance(elModalCrear);
    const modalEditar = bootstrap.Modal.getOrCreateInstance(elModalEditar);
    const modalEstado = bootstrap.Modal.getOrCreateInstance(elModalEstado);

    // Evitar que el foco permanezca dentro de un modal oculto
[elModalCrear, elModalEditar, elModalEstado].forEach(modal => {
    if (!modal) return;

    modal.addEventListener('hide.bs.modal', function () {
        if (modal.contains(document.activeElement)) {
            document.activeElement.blur();
        }
    });
});


    function checks(selector) {
        return document.querySelectorAll(selector);
    }

    
    function validarUsuarioTexto(valor) {
        return /^[A-Za-zÁÉÍÓÚáéíóúÑñ]+$/.test(valor.trim());
    }

    
    function validarPasswordTexto(valor) {
        return valor.length >= 10 && valor.length <= 64 && new TextEncoder().encode(valor).length <= 72 && !/[\u0000-\u001F\u007F]/.test(valor);
    }

    
    function mostrarError(contenedor, mensaje) {
        if (!contenedor) return;
        contenedor.replaceChildren();
        const div = document.createElement('div');
        div.className = 'alert alert-danger alert-custom';
        div.textContent = mensaje;
        contenedor.appendChild(div);
    }

    
    function actualizarVisibilidadGrupos(contenedorId) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor) return;

        contenedor.querySelectorAll('.store-zone-group').forEach(zoneGroup => {
            const itemsZona = Array.from(zoneGroup.querySelectorAll('.store-item'));
            const visiblesZona = itemsZona.filter(item => item.style.display !== 'none');
            zoneGroup.style.display = visiblesZona.length ? '' : 'none';
        });

        contenedor.querySelectorAll('.store-base-box').forEach(baseBox => {
            const itemsBase = Array.from(baseBox.querySelectorAll('.store-item'));
            const visiblesBase = itemsBase.filter(item => item.style.display !== 'none');
            baseBox.style.display = visiblesBase.length ? '' : 'none';
        });

        contenedor.querySelectorAll('.store-country-group').forEach(countryGroup => {
            const itemsPais = Array.from(countryGroup.querySelectorAll('.store-item'));
            const visiblesPais = itemsPais.filter(item => item.style.display !== 'none');
            countryGroup.style.display = visiblesPais.length ? '' : 'none';
        });
    }

    
    function filtrarTiendasPorPais(selectPais, selectorChecks, contenedorId) {
        if (!selectPais) return;

        const pais = (selectPais.value || '').trim().toUpperCase();

        checks(selectorChecks).forEach(ch => {
            const item = ch.closest('.store-item');
            if (!item) return;

            const paisStore = (ch.dataset.pais || '').trim().toUpperCase();
            const mostrar = (pais === '' || paisStore === pais);

            item.style.display = mostrar ? '' : 'none';

            if (!mostrar) {
                ch.checked = false;
            }
        });

        actualizarVisibilidadGrupos(contenedorId);
    }

    
    function aplicarReglasCrear() {
        const rol = crearRol ? crearRol.value : '';
        const cks = checks('.check-crear');

        if (rol === 'super_admin') {
            if (bloqueCrear) bloqueCrear.style.display = 'none';
            if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'block';
            cks.forEach(ch => ch.checked = false);
            return;
        }

        if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'none';
        if (bloqueCrear) bloqueCrear.style.display = '';

        filtrarTiendasPorPais(crearPais, '.check-crear', 'bloque_tiendas_crear');

        if (rol === 'tienda') {
            const marcadas = Array.from(checks('.check-crear:checked'));
            if (marcadas.length > 1) {
                marcadas.slice(1).forEach(ch => ch.checked = false);
            }
        }
    }

    
    function aplicarReglasEditar() {
        const rol = editRol ? editRol.value : '';
        const cks = checks('.check-editar');

        if (rol === 'super_admin') {
            if (bloqueEditar) bloqueEditar.style.display = 'none';
            cks.forEach(ch => ch.checked = false);
            return;
        }

        if (bloqueEditar) bloqueEditar.style.display = '';
        filtrarTiendasPorPais(editPais, '.check-editar', 'bloque_tiendas_editar');

        if (rol === 'tienda') {
            const marcadas = Array.from(checks('.check-editar:checked'));
            if (marcadas.length > 1) {
                marcadas.slice(1).forEach(ch => ch.checked = false);
            }
        }
    }

    
    function limpiarFormularioCrear() {
        formCrear.reset();
        checks('.check-crear').forEach(ch => ch.checked = false);

        const respuestaCrear = document.getElementById('respuesta_crear');
        if (respuestaCrear) respuestaCrear.innerHTML = '';

        <?php if ($miRol !== 'super_admin'): ?>
        if (crearPais) crearPais.value = '<?= u_h($miPais) ?>';
        <?php endif; ?>

        if (mensajeSuperAdminCrear) mensajeSuperAdminCrear.style.display = 'none';

        aplicarReglasCrear();

        const body = elModalCrear ? elModalCrear.querySelector('.modal-body') : null;
        if (body) body.scrollTop = 0;
    }

    
    async function cargarUsuarios() {
        try {
            const perPageSelect = document.getElementById('usuariosPerPage');
            const paginaActiva = listaUsuarios.querySelector('.paginacion-btn.activa[data-page]');
            const page = paginaActiva ? (paginaActiva.dataset.page || '1') : '1';
            const perPage = perPageSelect ? perPageSelect.value : '50';
            const parametros = new URLSearchParams({ page, per_page: perPage });
            const r = await fetch(
                '/exhibicion_DT/controlusuarios/listar_usuarios.php?' + parametros.toString(),
                { cache: 'no-store' }
            );
            const html = await r.text();
            listaUsuarios.innerHTML = html;
        } catch (e) {
            console.error(e);
        }
    }

    
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('check-crear') && crearRol && crearRol.value === 'tienda' && e.target.checked) {
            checks('.check-crear').forEach(ch => {
                if (ch !== e.target) ch.checked = false;
            });
        }

        if (e.target.classList.contains('check-editar') && editRol && editRol.value === 'tienda' && e.target.checked) {
            checks('.check-editar').forEach(ch => {
                if (ch !== e.target) ch.checked = false;
            });
        }
    });

    
    if (crearRol) crearRol.addEventListener('change', aplicarReglasCrear);
    if (editRol) editRol.addEventListener('change', aplicarReglasEditar);
    if (crearPais) crearPais.addEventListener('change', aplicarReglasCrear);
    if (editPais) editPais.addEventListener('change', aplicarReglasEditar);

    
    if (elModalCrear) {
        elModalCrear.addEventListener('show.bs.modal', limpiarFormularioCrear);
        elModalCrear.addEventListener('shown.bs.modal', function () {
            const body = elModalCrear.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
        elModalCrear.addEventListener('hidden.bs.modal', function () {
            const body = elModalCrear.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
    }

    
    if (elModalEditar) {
        elModalEditar.addEventListener('shown.bs.modal', function () {
            const body = elModalEditar.querySelector('.modal-body');
            if (body) body.scrollTop = 0;
        });
    }

    
    const btnGuardarUsuario = document.getElementById('btnGuardarUsuario');
    if (btnGuardarUsuario) {
        btnGuardarUsuario.addEventListener('click', async function() {
            const respuesta = document.getElementById('respuesta_crear');

            const usuario = formCrear.querySelector('[name="usuario"]').value.trim();
            const nombreCompleto = formCrear.querySelector('[name="nombre_completo"]').value.trim();
            const password = formCrear.querySelector('[name="password"]').value;
            const paisCode = formCrear.querySelector('[name="pais_code"]').value.trim();
            const rol      = formCrear.querySelector('[name="rol"]').value.trim();

            if (respuesta) respuesta.innerHTML = '';

            if (usuario === '') {
                mostrarError(respuesta, 'El usuario es obligatorio');
                return;
            }

            if (!validarUsuarioTexto(usuario)) {
                mostrarError(respuesta, 'El usuario solo puede contener letras');
                return;
            }

            if (nombreCompleto.length < 3 || nombreCompleto.length > 120) {
                mostrarError(respuesta, 'Ingresa un nombre completo válido');
                return;
            }

            if (password.length < 10 || password.length > 64) {
                mostrarError(respuesta, 'La contraseña debe tener entre 10 y 64 caracteres');
                return;
            }

            if (!validarPasswordTexto(password)) {
                mostrarError(respuesta, 'Se permiten símbolos especiales, pero no caracteres de control ni más de 72 bytes');
                return;
            }

            if (paisCode === '') {
                mostrarError(respuesta, 'Debes seleccionar un país');
                return;
            }

            const checksCrearMarcados = Array.from(document.querySelectorAll('.check-crear:checked'));

            if (rol !== 'super_admin' && checksCrearMarcados.length === 0) {
                mostrarError(respuesta, 'Debes seleccionar al menos una tienda');
                return;
            }

            if (rol === 'tienda' && checksCrearMarcados.length > 1) {
                mostrarError(respuesta, 'Un usuario de tienda solo puede tener una tienda asignada');
                return;
            }

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/guardar_usuarios.php', {
                    method: 'POST',
                    body: new FormData(formCrear)
                });

                const text = await r.text();
                let json;

                try {
                    json = JSON.parse(text);
                } catch {
                    mostrarError(respuesta, 'Respuesta inválida del servidor: ' + text);
                    return;
                }

                if (respuesta) {
                    respuesta.replaceChildren();
                    const aviso = document.createElement('div');
                    aviso.className = 'alert ' + (json.ok ? 'alert-success' : 'alert-danger') + ' alert-custom';
                    aviso.textContent = json.msg || '';
                    respuesta.appendChild(aviso);
                }

                if (json.ok) {
                    await cargarUsuarios();

                    setTimeout(() => {
                        modalCrear.hide();
                        limpiarFormularioCrear();
                    }, 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'Error al guardar usuario');
            }
        });
    }

    
    document.addEventListener('click', async function(e) {
        const btnEditar = e.target.closest('.btn-editar-usuario');
        const btnEstado = e.target.closest('.btn-estado-usuario');

        
        if (btnEditar) {
            try {
                const id = btnEditar.dataset.id;

                const r = await fetch('/exhibicion_DT/controlusuarios/obtener_usuario.php?id=' + encodeURIComponent(id));
                const json = await r.json();

                if (!json.ok) {
                    alert(json.msg);
                    return;
                }

                document.getElementById('edit_id').value = json.data.id ?? '';
                document.getElementById('edit_usuario').value = json.data.usuario ?? '';
                document.getElementById('edit_nombre_completo').value = json.data.nombre_completo || json.data.usuario || '';
                document.getElementById('edit_rol').value = json.data.rol ?? '';
                document.getElementById('edit_estado').value = json.data.estado ?? '1';
                const campoPasswordEditar = document.getElementById('edit_password');
                campoPasswordEditar.value = '';
                campoPasswordEditar.disabled = !json.data.puede_restablecer_password;
                campoPasswordEditar.readOnly = !json.data.puede_restablecer_password;

                if (editPais) {
                    editPais.value = (json.data.pais_code ?? '').toUpperCase();
                }

                checks('.check-editar').forEach(ch => ch.checked = false);

                aplicarReglasEditar();

                (json.data.store_keys || []).forEach(key => {
                    const el = document.querySelector('.check-editar[data-key="' + CSS.escape(key) + '"]');
                    if (el && el.closest('.store-item') && el.closest('.store-item').style.display !== 'none') {
                        el.checked = true;
                    }
                });

                modalEditar.show();

            } catch (e) {
                console.error(e);
                alert('No se pudo cargar el usuario');
            }
        }

        
        if (btnEstado) {
            const id = btnEstado.dataset.id;
            const estado = btnEstado.dataset.estado === '1' ? '0' : '1';

            document.getElementById('estado_id').value = id;
            document.getElementById('estado_valor').value = estado;
            elModalEstado.dataset.action = (estado === '0') ? 'lock' : 'unlock';

            document.getElementById('estado_texto').textContent =
                estado === '0'
                    ? '¿Deseas bloquear este usuario?'
                    : '¿Deseas desbloquear este usuario?';

            document.getElementById('respuesta_estado').innerHTML = '';
            modalEstado.show();
        }
    });

    
    const btnActualizarUsuario = document.getElementById('btnActualizarUsuario');
    if (btnActualizarUsuario) {
        btnActualizarUsuario.addEventListener('click', async function() {
            const respuesta = document.getElementById('respuesta_editar');
            const paisCode  = formEditar.querySelector('[name="pais_code"]').value.trim();
            const rol       = formEditar.querySelector('[name="rol"]').value.trim();
            const nombreCompleto = formEditar.querySelector('[name="nombre_completo"]').value.trim();
            if (nombreCompleto.length < 3 || nombreCompleto.length > 120) {
                mostrarError(respuesta, 'Ingresa un nombre completo válido');
                return;
            }
            const checksEditarMarcados = Array.from(document.querySelectorAll('.check-editar:checked'));

            if (respuesta) respuesta.innerHTML = '';

            if (paisCode === '') {
                mostrarError(respuesta, 'Debes seleccionar un país');
                return;
            }

            if (rol !== 'super_admin' && checksEditarMarcados.length === 0) {
                mostrarError(respuesta, 'Debes seleccionar al menos una tienda');
                return;
            }

            if (rol === 'tienda' && checksEditarMarcados.length > 1) {
                mostrarError(respuesta, 'Un usuario de tienda solo puede tener una tienda asignada');
                return;
            }

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/actualizar_usuario.php', {
                    method: 'POST',
                    body: new FormData(formEditar)
                });

                const json = await r.json();

                if (respuesta) {
                    respuesta.replaceChildren();
                    const aviso = document.createElement('div');
                    aviso.className = 'alert ' + (json.ok ? 'alert-success' : 'alert-danger') + ' alert-custom';
                    aviso.textContent = json.msg || '';
                    respuesta.appendChild(aviso);
                }

                if (json.ok) {
                    await cargarUsuarios();
                    setTimeout(() => modalEditar.hide(), 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'Error al actualizar');
            }
        });
    }

    
    const btnConfirmarEstado = document.getElementById('btnConfirmarEstado');
    if (btnConfirmarEstado) {
        btnConfirmarEstado.addEventListener('click', async function() {
            const id = document.getElementById('estado_id').value;
            const estado = document.getElementById('estado_valor').value;
            const respuesta = document.getElementById('respuesta_estado');

            try {
                const r = await fetch('/exhibicion_DT/controlusuarios/cambiar_estado_usuario.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({id, estado, csrf_usuarios: <?= json_encode($_SESSION['csrf_usuarios']) ?>})
                });

                const json = await r.json();

                if (respuesta) {
                    respuesta.replaceChildren();
                    const aviso = document.createElement('div');
                    aviso.className = 'alert ' + (json.ok ? 'alert-success' : 'alert-danger') + ' alert-custom';
                    aviso.textContent = json.msg || '';
                    respuesta.appendChild(aviso);
                }

                if (json.ok) {
                    await cargarUsuarios();
                    setTimeout(() => modalEstado.hide(), 700);
                }

            } catch (e) {
                mostrarError(respuesta, 'No se pudo cambiar estado');
            }
        });
    }

    
    <?php if ($miRol !== 'super_admin'): ?>
    if (crearPais) crearPais.value = '<?= u_h($miPais) ?>';
    if (editPais) editPais.value = '<?= u_h($miPais) ?>';
    <?php endif; ?>

    
    aplicarReglasCrear();
    aplicarReglasEditar();
});
</script>