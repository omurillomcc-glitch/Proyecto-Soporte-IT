<?php
declare(strict_types=1);


header('Content-Type: application/json; charset=utf-8');


session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


ini_set('display_errors', '0');
error_reporting(E_ALL);


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/password_security.php';
require_once __DIR__ . '/security_events.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';


function aud_region_label(string $code): string
{
    return match (strtoupper(trim($code))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($code)),
    };
}


function json_out(bool $ok, string $msg, array $extra = []): void
{
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}


function validar_usuario_txt(string $usuario): array
{
    $usuario = trim($usuario);

    if ($usuario === '') {
        return [false, 'El usuario es obligatorio.'];
    }

    if (mb_strlen($usuario, 'UTF-8') > 30) {
        return [false, 'El usuario no puede tener más de 30 caracteres.'];
    }

    if (!preg_match('/^[\p{L}]+$/u', $usuario)) {
        return [false, 'El usuario solo puede contener letras.'];
    }

    return [true, 'OK'];
}


function validar_password_txt(string $password, bool $permitirVacia = false): array
{
    return exdt_validar_password($password, $permitirVacia);
}


function normalizar_pais_code_actualizar(string $pais): string
{
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}


function normalizar_tienda_actual(array $row): array
{
    $paisCode = normalizar_pais_code_actualizar((string)($row['pais'] ?? ''));

    return [
        'pais'          => $paisCode,
        'pais_code'     => $paisCode,
        'base_datos'    => trim((string)($row['base_datos'] ?? '')),
        'zona'          => trim((string)($row['zona'] ?? '')),
        'codalmacen'    => trim((string)($row['codalmacen'] ?? '')),
        'nombrealmacen' => trim((string)($row['nombrealmacen'] ?? '')),
    ];
}


if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'msg' => 'Método no permitido.']);
    exit;
}
require_user_admin();
$tokenEnviado = (string)($_POST['csrf_usuarios'] ?? '');
$tokenSesion = (string)($_SESSION['csrf_usuarios'] ?? '');
if ($tokenSesion === '' || !hash_equals($tokenSesion, $tokenEnviado)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'El formulario expiró. Recarga la página.']);
    exit;
}

$me = me();
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = normalizar_pais_code_actualizar((string)($me['pais_code'] ?? ''));
$miZona = trim((string)($me['zona'] ?? ''));


$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    json_out(false, 'ID inválido.');
}


if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    exdt_registrar_evento('ACCESO_DENEGADO', (string)($me['usuario'] ?? ''),
        (string)($_SERVER['REMOTE_ADDR'] ?? ''), 'usuarios:editar');
    json_out(false, 'No puedes editar este usuario.');
}


$stmtActual = $conn->prepare("
    SELECT id, usuario, nombre_completo, rol, pais_code, estado
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmtActual) {
    json_out(false, 'Error consultando el usuario actual.');
}

$stmtActual->bind_param("i", $id);
$stmtActual->execute();
$usuarioActual = $stmtActual->get_result()->fetch_assoc();
$stmtActual->close();

if (!$usuarioActual) {
    json_out(false, 'Usuario no encontrado.');
}

$usuarioActualNombre = (string)($usuarioActual['usuario'] ?? '');
$nombreCompletoActual = (string)($usuarioActual['nombre_completo'] ?? '');
$rolActual           = (string)($usuarioActual['rol'] ?? '');
$paisCodeActual      = normalizar_pais_code_actualizar((string)($usuarioActual['pais_code'] ?? ''));
$estadoActual        = (int)($usuarioActual['estado'] ?? 1);
if ($id === $miId && isset($_POST['estado']) && (int)$_POST['estado'] !== $estadoActual) {
    json_out(false, 'No puedes cambiar el estado de tu propia cuenta.');
}


$tiendasActuales = [];

$stmtTiendasActuales = $conn->prepare("
    SELECT pais, base_datos, zona, codalmacen, nombrealmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY id ASC
");

if ($stmtTiendasActuales) {
    $stmtTiendasActuales->bind_param("i", $id);
    $stmtTiendasActuales->execute();
    $resTiendasActuales = $stmtTiendasActuales->get_result();

    while ($fila = $resTiendasActuales->fetch_assoc()) {
        $tiendasActuales[] = normalizar_tienda_actual($fila);
    }

    $stmtTiendasActuales->close();
}


$usuario     = u_norm($_POST['usuario'] ?? '');
$nombreCompleto = trim((string)($_POST['nombre_completo'] ?? ''));
$password    = (string)($_POST['password'] ?? '');
$rol         = u_norm($_POST['rol'] ?? '');
$paisCode    = normalizar_pais_code_actualizar((string)($_POST['pais_code'] ?? ''));
$estado      = isset($_POST['estado']) ? (int)$_POST['estado'] : 1;
$postTiendas = $_POST['tiendas'] ?? [];


if ($miRol === 'admin_zona') {
    $usuario  = $usuarioActualNombre;
    $nombreCompleto = $nombreCompletoActual !== '' ? $nombreCompletoActual : $usuarioActualNombre;
    $rol      = $rolActual;
    $paisCode = $paisCodeActual;
    $estado   = $estadoActual;
}


if (mb_strlen($nombreCompleto, 'UTF-8') < 3 || mb_strlen($nombreCompleto, 'UTF-8') > 120
    || !preg_match('/^[\p{L}][\p{L}\s.-]*$/u', $nombreCompleto)) {
    json_out(false, 'Nombre completo inválido.');
}

[$okUsuario, $msgUsuario] = validar_usuario_txt($usuario);
if (!$okUsuario) {
    json_out(false, $msgUsuario);
}

if ($password !== '' && !u_can_reset_password($conn, $miId, $miRol, $id)) {
    exdt_registrar_evento('ACCESO_DENEGADO', (string)($me['usuario'] ?? ''),
        (string)($_SERVER['REMOTE_ADDR'] ?? ''), 'usuarios:reset');
    json_out(false, 'No tienes permiso para restablecer la contraseña de esta cuenta.');
}

[$okPass, $msgPass] = validar_password_txt($password, true);
if (!$okPass) {
    json_out(false, $msgPass);
}


$rolesValidos = ['super_admin', 'admin_zona', 'tienda'];
if ($rol === 'super_admin' && !am_es_propietario($conn, $miId)) {
    json_out(false, 'Solo el Propietario puede asignar el rol Super Admin.');
}
if (am_es_propietario($conn, $id) && ($rol !== 'super_admin' || $estado !== 1)) {
    json_out(false, 'No se puede desactivar ni cambiar el rol del Propietario.');
}

if (!in_array($rol, $rolesValidos, true)) {
    json_out(false, 'Rol inválido.');
}

$paisesValidos = ['HN', 'NI'];
if (!in_array($paisCode, $paisesValidos, true)) {
    json_out(false, 'País inválido.');
}


if ($miRol === 'admin_zona' && $rol !== $rolActual) {
    json_out(false, 'Un admin_zona no puede cambiar el rol.');
}

if ($miRol === 'admin_zona' && $paisCode !== $miPais) {
    json_out(false, 'Solo puedes asignar usuarios de tu mismo país.');
}


if ($id === $miId && $rol !== $rolActual) {
    json_out(false, 'No puedes cambiar tu propio rol.');
}

if ($id === $miId && $paisCode !== $paisCodeActual) {
    json_out(false, 'No puedes cambiar tu propio país.');
}

if ($id === $miId && (int)$estado === 0) {
    json_out(false, 'No puedes bloquearte a ti misma.');
}


$estado = ($estado === 1) ? 1 : 0;


$tiendas = [];

if (is_array($postTiendas)) {
    foreach ($postTiendas as $token) {
        $store = u_decode_store_token((string)$token);

        if (!$store || !is_array($store)) {
            continue;
        }

        $storePais = normalizar_pais_code_actualizar((string)($store['pais_code'] ?? $store['pais'] ?? ''));
        $store['pais_code'] = $storePais;

        $tiendas[u_store_key_from_array($store)] = $store;
    }
}

$tiendas = array_values($tiendas);


if ($miRol === 'admin_zona') {

    if (!empty($tiendas)) {
        $actualKeys = array_map(fn($t) => u_store_key_from_array($t), $tiendasActuales);
        $nuevasKeys = array_map(fn($t) => u_store_key_from_array($t), $tiendas);

        sort($actualKeys);
        sort($nuevasKeys);

        if ($actualKeys !== $nuevasKeys) {
            json_out(false, 'Un admin_zona no puede modificar las tiendas asignadas.');
        }
    }

    $tiendas = $tiendasActuales;
}


if ($rol !== 'super_admin' && count($tiendas) === 0) {
    json_out(false, 'Debes asignar al menos una tienda.');
}

if ($rol === 'tienda' && count($tiendas) !== 1) {
    json_out(false, 'El rol tienda solo puede tener una tienda.');
}

if ($rol === 'super_admin' && count($tiendas) > 0) {
    json_out(false, 'El super_admin no necesita tiendas asignadas.');
}


foreach ($tiendas as $t) {
    $storePais = normalizar_pais_code_actualizar((string)($t['pais_code'] ?? $t['pais'] ?? ''));

    if ($storePais !== $paisCode) {
        json_out(false, 'Todas las tiendas seleccionadas deben pertenecer al país elegido.');
    }
}


foreach ($tiendas as $t) {
    if (!u_sqlsrv_store_exists($sqlsrv_conn, $t)) {
        json_out(false, 'Una tienda seleccionada no existe o ya no es válida.');
    }
}


if ($miRol === 'admin_zona') {
    $mias = u_get_user_store_keys($conn, $miId);

    foreach ($tiendas as $t) {
        $storeKey  = u_store_key_from_array($t);
        $storePais = normalizar_pais_code_actualizar((string)($t['pais_code'] ?? $t['pais'] ?? ''));
        $storeZona = strtoupper(trim((string)($t['zona'] ?? '')));
        $miZonaCmp = strtoupper(trim($miZona));

        if ($storePais !== $miPais) {
            json_out(false, 'Solo puedes conservar tiendas de tu mismo país.');
        }

        if ($miZonaCmp !== '' && $storeZona !== $miZonaCmp) {
            json_out(false, 'Solo puedes conservar tiendas de tu misma zona.');
        }

        if (!isset($mias[$storeKey])) {
            json_out(false, 'Solo puedes conservar tiendas que te pertenecen.');
        }
    }
}


$stmtDup = $conn->prepare("
    SELECT id
    FROM usuarios
    WHERE BINARY usuario = ?
      AND id <> ?
    LIMIT 1
");

if (!$stmtDup) {
    json_out(false, 'Error preparando validación de usuario duplicado.');
}

$stmtDup->bind_param("si", $usuario, $id);

if (!$stmtDup->execute()) {
    $errDup = $stmtDup->error;
    $stmtDup->close();
    json_out(false, 'Error ejecutando validación de usuario duplicado: ' . $errDup);
}

$resDup = $stmtDup->get_result();

if ($resDup && $resDup->num_rows > 0) {
    $stmtDup->close();
    json_out(false, 'Ese usuario ya existe.');
}

$stmtDup->close();


if ($rol === 'tienda' && count($tiendas) === 1) {

    $t = $tiendas[0];

    $baseDatos  = strtoupper(trim((string)($t['base_datos'] ?? '')));
    $codalmacen = trim((string)($t['codalmacen'] ?? ''));

    $stmtTiendaDup = $conn->prepare("
        SELECT u.id
        FROM usuarios u
        INNER JOIN usuario_tienda ut
            ON ut.usuario_id = u.id
        WHERE u.rol = 'tienda'
          AND u.id <> ?
          AND UPPER(TRIM(ut.base_datos)) = ?
          AND TRIM(ut.codalmacen) = ?
        LIMIT 1
    ");

    if (!$stmtTiendaDup) {
        json_out(false, 'Error preparando validación de tienda duplicada.');
    }

    $stmtTiendaDup->bind_param("iss", $id, $baseDatos, $codalmacen);

    if (!$stmtTiendaDup->execute()) {
        $errTiendaDup = $stmtTiendaDup->error;
        $stmtTiendaDup->close();
        json_out(false, 'Error ejecutando validación de tienda duplicada: ' . $errTiendaDup);
    }

    $resTiendaDup = $stmtTiendaDup->get_result();

    if ($resTiendaDup && $resTiendaDup->num_rows > 0) {
        $stmtTiendaDup->close();
        json_out(false, 'Esta tienda ya pertenece a otro usuario. No puedes asignarla nuevamente.');
    }

    $stmtTiendaDup->close();
}


$conn->begin_transaction();

try {


    if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        if ($hash === false) {
            throw new RuntimeException('No se pudo generar la contraseña segura.');
        }

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET usuario = ?,
                nombre_completo = ?,
                password_hash = ?,
                rol = ?,
                pais_code = ?,
                estado = ?
            WHERE id = ?
        ");

        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la actualización del usuario.');
        }

        $stmt->bind_param("sssssii", $usuario, $nombreCompleto, $hash, $rol, $paisCode, $estado, $id);

    } else {

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET usuario = ?,
                nombre_completo = ?,
                rol = ?,
                pais_code = ?,
                estado = ?
            WHERE id = ?
        ");

        if (!$stmt) {
            throw new RuntimeException('No se pudo preparar la actualización del usuario.');
        }

        $stmt->bind_param("ssssii", $usuario, $nombreCompleto, $rol, $paisCode, $estado, $id);
    }

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('No se pudo actualizar el usuario: ' . $err);
    }

    $stmt->close();

    if ($password !== '') {
        exdt_registrar_password_admin($conn, $id);
    }

    $stmtDel = $conn->prepare("
        DELETE FROM usuario_tienda
        WHERE usuario_id = ?
    ");

    if (!$stmtDel) {
        throw new RuntimeException('No se pudo preparar el borrado de tiendas anteriores.');
    }

    $stmtDel->bind_param("i", $id);

    if (!$stmtDel->execute()) {
        $errDel = $stmtDel->error;
        $stmtDel->close();
        throw new RuntimeException('No se pudieron limpiar las tiendas anteriores: ' . $errDel);
    }

    $stmtDel->close();


    if ($rol !== 'super_admin') {
        $stmtIns = $conn->prepare("
            INSERT INTO usuario_tienda (
                usuario_id,
                pais,
                base_datos,
                zona,
                codalmacen,
                nombrealmacen
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if (!$stmtIns) {
            throw new RuntimeException('No se pudo preparar el guardado de tiendas.');
        }

        foreach ($tiendas as $t) {
            $pais          = normalizar_pais_code_actualizar((string)($t['pais'] ?? $t['pais_code'] ?? ''));
            $base_datos    = trim((string)($t['base_datos'] ?? ''));
            $zona          = trim((string)($t['zona'] ?? ''));
            $codalmacen    = trim((string)($t['codalmacen'] ?? ''));
            $nombrealmacen = trim((string)($t['nombrealmacen'] ?? ''));

            $stmtIns->bind_param(
                "isssss",
                $id,
                $pais,
                $base_datos,
                $zona,
                $codalmacen,
                $nombrealmacen
            );

            if (!$stmtIns->execute()) {
                $errIns = $stmtIns->error;
                $stmtIns->close();
                throw new RuntimeException('No se pudieron guardar las tiendas del usuario: ' . $errIns);
            }
        }

        $stmtIns->close();
    }


    $conn->commit();

$cambios = [];

    if ($nombreCompletoActual !== $nombreCompleto) {
        $nombreAnterior = $nombreCompletoActual !== '' ? $nombreCompletoActual : 'No registrado';
        $cambios[] = "Nombre cambio de: '{$nombreAnterior}' A '{$nombreCompleto}'";
    }

    if ($usuarioActualNombre !== $usuario) {
        $cambios[] = "Usuario cambio de: '{$usuarioActualNombre}' A '{$usuario}'";
    }

    if ($rolActual !== $rol) {
        $cambios[] = "Rol cambio de: '{$rolActual}' A '{$rol}'";
    }

    if ($paisCodeActual !== $paisCode) {
        $cambios[] = "País cambio de: '{$paisCodeActual}' A '{$paisCode}'";
    }

    if ($estadoActual !== $estado) {
        $estadoAnterior = $estadoActual === 1 ? 'Activo' : 'Bloqueado';
        $estadoNuevo = $estado === 1 ? 'Activo' : 'Bloqueado';
        $cambios[] = "Estado cambio de: '{$estadoAnterior}' A '{$estadoNuevo}'";
    }

    if ($password !== '') {
        $cambios[] = "Contraseña: Restablecida por administrador autorizado; renovación registrada";
        exdt_registrar_evento('PASSWORD_RESTABLECIDA', $usuario, (string)($_SERVER['REMOTE_ADDR'] ?? ''), (string)($me['usuario'] ?? '')); 
    }

    $tiendasActualesPorClave = [];
    foreach ($tiendasActuales as $tiendaActual) {
        $tiendasActualesPorClave[u_store_key_from_array($tiendaActual)] = $tiendaActual;
    }

    $tiendasNuevasPorClave = [];
    foreach ($tiendas as $tiendaNueva) {
        $tiendasNuevasPorClave[u_store_key_from_array($tiendaNueva)] = $tiendaNueva;
    }

    $clavesTiendasEliminadas = array_diff(
        array_keys($tiendasActualesPorClave),
        array_keys($tiendasNuevasPorClave)
    );
    $clavesTiendasAgregadas = array_diff(
        array_keys($tiendasNuevasPorClave),
        array_keys($tiendasActualesPorClave)
    );

    $formatearTiendas = static function (array $claves, array $tiendasPorClave): string {
        $nombres = [];
        foreach ($claves as $clave) {
            $tienda = $tiendasPorClave[$clave];
            $nombre = trim((string)($tienda['nombrealmacen'] ?? ''));
            $codigo = trim((string)($tienda['codalmacen'] ?? ''));
            $nombres[] = $nombre !== '' ? $nombre . ($codigo !== '' ? ' (' . $codigo . ')' : '') : $codigo;
        }

        return implode(', ', $nombres);
    };

    if ($clavesTiendasEliminadas !== []) {
        $cambios[] = 'Tiendas eliminadas: ' . $formatearTiendas($clavesTiendasEliminadas, $tiendasActualesPorClave);
    }

    if ($clavesTiendasAgregadas !== []) {
        $cambios[] = 'Tiendas agregadas: ' . $formatearTiendas($clavesTiendasAgregadas, $tiendasNuevasPorClave);
    }

    if ($cambios !== []) {
        $resultado = registrar_auditoria(
            'USUARIOS',
            'USUARIO_EDITADO',
            implode("\n", $cambios), // Unido limpiamente tal como se ve en los demás logs
            aud_region_label($paisCode),
            ($rol === 'tienda' && !empty($tiendas))
                ? (string)($tiendas[0]['zona'] ?? '')
                : '',
            ($rol === 'tienda' && !empty($tiendas))
                ? (string)($tiendas[0]['nombrealmacen'] ?? '')
                : '',
            ($rol === 'tienda' && !empty($tiendas))
                ? (string)($tiendas[0]['codalmacen'] ?? '')
                : ''
        );

        if (!$resultado) {
            error_log(">>> ERROR: auditoría no se insertó");
        }
    }

    json_out(true, 'Usuario actualizado correctamente.');
}
catch (Throwable $e) {


    $conn->rollback();

    error_log('Error editando usuario: ' . $e->getMessage());
    json_out(false, 'No se pudo actualizar el usuario. Consulta el registro de errores.');
}