<?php
// Reglas unificadas de contraseñas de Exhibición DT.
// La renovación cada 90 días la realiza exclusivamente un administrador autorizado.
// PASSWORD_BCRYPT incorpora una sal aleatoria; nunca guardar contraseñas originales.

function exdt_validar_password(string $password, bool $opcional = false): array
{
    if ($opcional && $password === '') {
        return [true, 'OK'];
    }

    $longitud = function_exists('mb_strlen')
        ? mb_strlen($password, 'UTF-8')
        : preg_match_all('/./us', $password);
    if ($longitud < 10 || $longitud > 64 || strlen($password) > 72) {
        return [false, 'La contraseña debe tener entre 10 y 64 caracteres y como máximo 72 bytes.'];
    }

    // Permite símbolos especiales, espacios y caracteres internacionales imprimibles.
    if (preg_match('/\A[^\x00-\x1F\x7F]+\z/u', $password) !== 1) {
        return [false, 'La contraseña contiene caracteres de control no permitidos.'];
    }

    return [true, 'OK'];
}

function exdt_estado_password_disponible(mysqli $conn): bool
{
    static $disponible = null;
    if ($disponible !== null) {
        return $disponible;
    }
    try {
        $resultado = $conn->query("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'usuario_password_estado' LIMIT 1");
        $disponible = $resultado && $resultado->num_rows > 0;
        if ($resultado) {
            $resultado->free();
        }
    } catch (Throwable $e) {
        error_log('Exhibición DT: no se pudo comprobar tabla de contraseñas.');
        $disponible = false;
    }
    return $disponible;
}

function exdt_registrar_password_admin(mysqli $conn, int $id): void
{
    if (!exdt_estado_password_disponible($conn)) {
        throw new RuntimeException('Instalar primero la tabla MySQL usuario_password_estado.');
    }
    $stmt = $conn->prepare('INSERT INTO usuario_password_estado
        (usuario_id, cambio_obligatorio, actualizado_en)
        VALUES (?, 0, NOW())
        ON DUPLICATE KEY UPDATE cambio_obligatorio = 0, actualizado_en = NOW()');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
}

function exdt_debe_cambiar_password(mysqli $conn, int $id): bool
{
    if (!exdt_estado_password_disponible($conn)) {
        return false; // No interrumpir inicios de sesión existentes antes de instalar SQL.
    }
    $stmt = $conn->prepare('SELECT cambio_obligatorio,
        (actualizado_en <= NOW() - INTERVAL 90 DAY) AS vencida
        FROM usuario_password_estado WHERE usuario_id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $registro = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return (int)($registro['cambio_obligatorio'] ?? 0) === 1
        || (int)($registro['vencida'] ?? 0) === 1;
}
