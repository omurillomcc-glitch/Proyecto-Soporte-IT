<?php
declare(strict_types=1);


if (!function_exists('am_modulos')) {
    function am_modulos(): array
    {
        return [
            'dashboard' => 'Dashboard',
            'modulo1' => 'Exhibición DT',
            'modulo3' => 'Sin Stock (registro)',
            'consulta_con_stock' => 'Consulta con Stock',
            'consulta_sin_stock' => 'Consulta sin Stock',
            'modulo2' => 'Auditoría',
            'usuarios' => 'Control de usuarios',
            'cobertura' => 'Cobertura de tiendas',
            'cobertura_importar' => 'Importar cobertura',
            'bloqueo' => 'Bloqueo General RCP',
            'bloqueo_tienda' => 'Bloqueo Tienda',
            'puntas_gondolas' => 'Puntas Góndolas',
        ];
    }
}

/** La asignación es del Propietario; no se otorgan accesos por el rol. */
if (!function_exists('am_modulo_compatible')) {
    function am_modulo_compatible(string $rol, string $modulo): bool
    {
        if (!array_key_exists($modulo, am_modulos())) return false;
        if (!in_array($rol, ['super_admin', 'admin_zona', 'tienda'], true)) return false;
        
        // Todos estos roles están permitidos para los módulos del sistema
        $rolPermitido = in_array($rol, ['super_admin', 'admin_zona', 'tienda'], true);

        if (in_array($modulo, ['usuarios', 'modulo2', 'cobertura', 'cobertura_importar', 'bloqueo', 'puntas_gondolas','bloqueo_tienda'], true) && !$rolPermitido) {
            return false;
        }

        return true;
    }
}

// Una cuenta de Tienda debe tener exactamente una sucursal de su país.
if (!function_exists('am_tienda_unica')) {
    function am_tienda_unica(mysqli $conn, int $usuarioId, string $pais): bool
    {
        static $cache = [];
        if (!in_array($pais, ['HN', 'NI'], true)) return false;
        $clave = $usuarioId . ':' . $pais;
        if (array_key_exists($clave, $cache)) return $cache[$clave];
        $largo = $pais === 'NI' ? 'NICARAGUA' : 'HONDURAS';
        $stmt = $conn->prepare(
            'SELECT codalmacen FROM usuario_tienda '
            . 'WHERE usuario_id = ? AND UPPER(TRIM(pais)) IN (?, ?)'
        );
        if (!$stmt) return false;
        $stmt->bind_param('iss', $usuarioId, $pais, $largo);
        $ok = $stmt->execute();
        $res = $ok ? $stmt->get_result() : false;
        $almacenes = [];
        if ($res) {
            while ($fila = $res->fetch_assoc()) {
                $codigo = trim((string)($fila['codalmacen'] ?? ''));
                if (!preg_match('/^\d{1,4}$/D', $codigo)) continue;
                $normal = ltrim($codigo, '0');
                $almacenes[$normal !== '' ? $normal : '0'] = true;
            }
        }
        $stmt->close();
        return $cache[$clave] = $ok && count($almacenes) === 1;
    }
}

if (!function_exists('am_es_propietario')) {
    function am_es_propietario(mysqli $conn, int $usuarioId): bool
    {
        if ($usuarioId < 1) return false;
        $stmt = $conn->prepare(
            "SELECT 1 FROM app_propietario p
             JOIN usuarios u ON u.id = p.usuario_id
             WHERE p.clave = 1 AND p.usuario_id = ?
               AND u.rol = 'super_admin' AND u.estado = 1 LIMIT 1"
        );
        if (!$stmt) return false;
        $stmt->bind_param('i', $usuarioId);
        $ok = $stmt->execute() && (bool)$stmt->get_result()->fetch_row();
        $stmt->close();
        return $ok;
    }
}

if (!function_exists('am_cuenta_activa')) {
    function am_cuenta_activa(mysqli $conn, int $usuarioId): bool
    {
        if ($usuarioId < 1) return false;
        $stmt = $conn->prepare('SELECT estado FROM usuarios WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row !== null && (int)$row['estado'] === 1;
    }
}

if (!function_exists('am_puede')) {
    function am_puede(mysqli $conn, int $usuarioId, string $modulo): bool
    {
        if ($usuarioId < 1) return false;
        if ($modulo === 'inicio' || $modulo === 'perfil') {
            return am_cuenta_activa($conn, $usuarioId);
        }
        if (am_es_propietario($conn, $usuarioId)) return true;
        if (!array_key_exists($modulo, am_modulos())) return false;

        $stmt = $conn->prepare('SELECT rol, estado, pais_code FROM usuarios WHERE id = ? LIMIT 1');
        if (!$stmt) return false;
        $stmt->bind_param('i', $usuarioId);
        $row = $stmt->execute() ? $stmt->get_result()->fetch_assoc() : null;
        $stmt->close();
        if (!$row || (int)$row['estado'] !== 1) return false;

        $rol = (string)$row['rol'];
        if (!am_modulo_compatible($rol, $modulo)) return false;
        if ($rol === 'tienda' && !am_tienda_unica(
            $conn, $usuarioId, strtoupper(trim((string)($row['pais_code'] ?? '')))
        )) return false;

        $stmt = $conn->prepare(
            'SELECT permitido FROM usuario_acceso_menu WHERE usuario_id = ? AND modulo = ? LIMIT 1'
        );
        if (!$stmt) return false;
        $stmt->bind_param('is', $usuarioId, $modulo);
        $row = $stmt->execute() ? $stmt->get_result()->fetch_assoc() : null;
        $stmt->close();
        return $row && (int)$row['permitido'] === 1;
    }
}
