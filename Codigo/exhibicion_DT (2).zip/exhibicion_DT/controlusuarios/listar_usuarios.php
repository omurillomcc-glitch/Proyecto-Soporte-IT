<?php
declare(strict_types=1);


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


ini_set('display_errors', '0');
error_reporting(E_ALL);


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__. '/helpers_usuarios.php';


require_user_admin();
$me = me();
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = strtoupper(trim((string)($me['pais_code'] ?? 'HN')));

if ($miPais === '') {
    $miPais = 'HN';
}

if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}


function nombre_pais_listado(string $code): string {
    $code = strtoupper(trim($code));

    return match ($code) {
        'HN' => 'Honduras',
        'NI' => 'Nicaragua',
        default => $code !== '' ? $code : 'Sin país',
    };
}


function partir_valores_concat(?string $texto): array
{
    $texto = trim((string)$texto);

    if ($texto === '') {
        return [];
    }

    $partes = array_map('trim', explode('||', $texto));
    $partes = array_filter($partes, static fn($v) => $v !== '');

    return array_values(array_unique($partes));
}


function parsear_tienda(string $texto): array
{
    $texto = trim($texto);

    $resultado = [
        'pais'   => '',
        'base'   => '',
        'zona'   => '',
        'codigo' => '',
        'nombre' => '',
        'texto'  => $texto,
    ];

    if ($texto === '') {
        return $resultado;
    }

    $partes = array_map('trim', explode(' / ', $texto));

    if (count($partes) >= 4) {
        $resultado['pais'] = $partes[0] ?? '';
        $resultado['base'] = $partes[1] ?? '';
        $resultado['zona'] = $partes[2] ?? '';

        $ultimo = $partes[3] ?? '';

        if (str_contains($ultimo, ' - ')) {
            [$codigo, $nombre] = array_map('trim', explode(' - ', $ultimo, 2));
            $resultado['codigo'] = $codigo;
            $resultado['nombre'] = $nombre;
        } else {
            $resultado['nombre'] = $ultimo;
        }
    } else {
        $resultado['nombre'] = $texto;
    }

    return $resultado;
}


$page = max(1, (int)($_GET['page'] ?? 1));

$perPage = (int)($_GET['per_page'] ?? 50);
$permitidosPerPage = [50, 100, 200];

if (!in_array($perPage, $permitidosPerPage, true)) {
    $perPage = 50;
}

$offset = ($page - 1) * $perPage;
$totalRows = 0;
$totalPages = 1;


if ($miRol === 'super_admin') {
    $paisListado = am_es_propietario($conn, $miId) ? 'ALL' : $miPais;


    $sqlCount = "
        SELECT COUNT(*) AS total
        FROM usuarios u
        WHERE (? = 'ALL' OR UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?)
    ";

    $stmtCount = $conn->prepare($sqlCount);

    if (!$stmtCount) {
        echo '<div class="alert alert-danger">Error preparando conteo: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmtCount->bind_param("ss", $paisListado, $paisListado);
    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $stmtCount->close();

    $totalRows = (int)($rowCount['total'] ?? 0);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }


    $sql = "
        SELECT
            u.id,
            u.usuario,
            u.nombre_completo,
            u.rol,
            u.estado,
            UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) AS pais_code,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.zona IS NOT NULL AND TRIM(ut.zona) <> ''
                    THEN ut.zona
                    ELSE NULL
                END
                ORDER BY ut.zona
                SEPARATOR '||'
            ) AS zonas,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.codalmacen IS NOT NULL AND TRIM(ut.codalmacen) <> ''
                    THEN CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))), ' / ',
                        COALESCE(ut.base_datos, ''), ' / ',
                        COALESCE(ut.zona, ''), ' / ',
                        COALESCE(ut.codalmacen, ''), ' - ',
                        COALESCE(ut.nombrealmacen, '')
                    )
                    ELSE NULL
                END
                ORDER BY ut.pais, ut.base_datos, ut.zona, ut.codalmacen
                SEPARATOR '||'
            ) AS tiendas,
            MAX(upe.actualizado_en) AS password_actualizada,
            MAX(upe.cambio_obligatorio) AS password_revision_pendiente

        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        LEFT JOIN usuario_password_estado upe ON upe.usuario_id = u.id

        WHERE (? = 'ALL' OR UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?)

        GROUP BY u.id, u.usuario, u.nombre_completo, u.rol, u.estado, u.pais_code
        ORDER BY u.id DESC
        LIMIT ?, ?
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo '<div class="alert alert-danger">Error preparando consulta: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmt->bind_param("ssii", $paisListado, $paisListado, $offset, $perPage);
    $stmt->execute();
    $res = $stmt->get_result();

} else {


    $sqlCount = "
        SELECT COUNT(DISTINCT u.id) AS total
        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        WHERE
            u.id = ?
            OR (
                u.rol = 'tienda'
                AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?
                AND CONCAT(
                    UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))),
                    '-',
                    TRIM(ut.codalmacen)
                ) IN (
                    SELECT CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(pais, ''), 'HN'))),
                        '-',
                        TRIM(codalmacen)
                    )
                    FROM usuario_tienda
                    WHERE usuario_id = ?
                )
            )
    ";

    $stmtCount = $conn->prepare($sqlCount);

    if (!$stmtCount) {
        echo '<div class="alert alert-danger">Error preparando conteo: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmtCount->bind_param("isi", $miId, $miPais, $miId);
    $stmtCount->execute();
    $resCount = $stmtCount->get_result();
    $rowCount = $resCount ? $resCount->fetch_assoc() : null;
    $stmtCount->close();

    $totalRows = (int)($rowCount['total'] ?? 0);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }


    $sql = "
        SELECT
            u.id,
            u.usuario,
            u.nombre_completo,
            u.rol,
            u.estado,
            UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) AS pais_code,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.zona IS NOT NULL AND TRIM(ut.zona) <> ''
                    THEN ut.zona
                    ELSE NULL
                END
                ORDER BY ut.zona
                SEPARATOR '||'
            ) AS zonas,

            GROUP_CONCAT(
                DISTINCT CASE
                    WHEN ut.codalmacen IS NOT NULL AND TRIM(ut.codalmacen) <> ''
                    THEN CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))), ' / ',
                        COALESCE(ut.base_datos, ''), ' / ',
                        COALESCE(ut.zona, ''), ' / ',
                        COALESCE(ut.codalmacen, ''), ' - ',
                        COALESCE(ut.nombrealmacen, '')
                    )
                    ELSE NULL
                END
                ORDER BY ut.pais, ut.base_datos, ut.zona, ut.codalmacen
                SEPARATOR '||'
            ) AS tiendas,
            MAX(upe.actualizado_en) AS password_actualizada,
            MAX(upe.cambio_obligatorio) AS password_revision_pendiente

        FROM usuarios u

        LEFT JOIN usuario_tienda ut
            ON ut.usuario_id = u.id

        LEFT JOIN usuario_password_estado upe ON upe.usuario_id = u.id

        WHERE
            u.id = ?
            OR (
                u.rol = 'tienda'
                AND UPPER(TRIM(COALESCE(NULLIF(u.pais_code, ''), 'HN'))) = ?
                AND CONCAT(
                    UPPER(TRIM(COALESCE(NULLIF(ut.pais, ''), 'HN'))),
                    '-',
                    TRIM(ut.codalmacen)
                ) IN (
                    SELECT CONCAT(
                        UPPER(TRIM(COALESCE(NULLIF(pais, ''), 'HN'))),
                        '-',
                        TRIM(codalmacen)
                    )
                    FROM usuario_tienda
                    WHERE usuario_id = ?
                )
            )

        GROUP BY u.id, u.usuario, u.nombre_completo, u.rol, u.estado, u.pais_code
        ORDER BY u.id DESC
        LIMIT ?, ?
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo '<div class="alert alert-danger">Error preparando consulta: ' . htmlspecialchars($conn->error) . '</div>';
        exit;
    }

    $stmt->bind_param("isiii", $miId, $miPais, $miId, $offset, $perPage);
    $stmt->execute();
    $res = $stmt->get_result();
}
?>

<div class="table-wrap">
    <table class="table-usuarios">
        <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th style="width:150px;">Usuario</th>
                <th style="min-width:190px;">Nombre completo</th>
                <th style="width:140px;">Rol</th>
                <th style="width:130px;">País</th>
                <th style="width:130px;">Estado</th>
                <th style="min-width:145px;">Contraseña</th>
                <th style="width:180px;">Zona</th>
                <th style="width:180px;">Tiendas</th>
                <th style="width:120px;">Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php if (!$res || $res->num_rows === 0): ?>
                <tr>
                    <td colspan="10">
                        <div class="text-center text-muted py-4">No hay usuarios registrados.</div>
                    </td>
                </tr>
            <?php else: ?>

                <?php while ($row = $res->fetch_assoc()): ?>
                    <?php
                    $idUsuarioFila = (int)($row['id'] ?? 0);
                    $rolUsuario = (string)($row['rol'] ?? '');
                    $zonasArray = partir_valores_concat($row['zonas'] ?? '');
                    $tiendasArray = partir_valores_concat($row['tiendas'] ?? '');
                    $puedeGestionar = u_can_manage_user($conn, $miId, $miRol, $idUsuarioFila);
                    $esPropietarioFila = am_es_propietario($conn, $idUsuarioFila);
                    // Estado informativo de renovación, visible solo a administradores.
                    $fechaClave = (string)($row['password_actualizada'] ?? '');
                    $clavePendiente = (int)($row['password_revision_pendiente'] ?? 0) === 1;
                    $diasClave = $fechaClave !== '' ? (int)floor((time() - strtotime($fechaClave)) / 86400) : null;
                    $claveVencida = $clavePendiente || ($diasClave !== null && $diasClave >= 90);
                    $clavePorVencer = !$claveVencida && $diasClave !== null && $diasClave >= 75;
                    ?>

                    <tr>
                        <td><?= $idUsuarioFila ?></td>

                        <td>
                            <strong><?= u_h((string)$row['usuario']) ?></strong>
                        </td>

                        <td><?= u_h((string)($row['nombre_completo'] ?? '') ?: 'No registrado') ?></td>

                        <td><?= $esPropietarioFila ? 'Propietario' : u_h($rolUsuario) ?></td>

                        <td>
                            <span class="pais-badge">
                                <?= u_h(nombre_pais_listado((string)($row['pais_code'] ?? ''))) ?>
                            </span>
                        </td>

                        <td>
                            <?php if ((int)$row['estado'] === 1): ?>
                                <span class="estado-badge estado-activo">Activo</span>
                            <?php else: ?>
                                <span class="estado-badge estado-bloqueado">Bloqueado</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($claveVencida): ?>
                                <span class="estado-badge estado-bloqueado" title="Renovar desde Editar usuario">Renovación pendiente</span>
                            <?php elseif ($clavePorVencer): ?>
                                <span class="estado-badge" title="Próximo vencimiento">Vence pronto</span>
                            <?php elseif ($diasClave !== null): ?>
                                <span class="text-muted">Vigente</span>
                            <?php else: ?>
                                <span class="text-muted">Sin fecha</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($rolUsuario === 'super_admin'): ?>
                                <span class="text-muted">No aplica</span>
                            <?php elseif (empty($zonasArray)): ?>
                                <span class="text-muted">Sin zona asignada</span>
                            <?php else: ?>
                                <div class="zonas-lista">
                                    <?php foreach ($zonasArray as $zona): ?>
                                        <span class="zona-chip"><?= u_h($zona) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($rolUsuario === 'super_admin'): ?>
                                <span class="badge-acceso-total">Acceso total</span>
                            <?php elseif (empty($tiendasArray)): ?>
                                <span class="text-muted">Sin tiendas asignadas</span>
                            <?php else: ?>
                                <div class="tiendas-lista">
                                    <?php foreach ($tiendasArray as $tiendaTexto): ?>
                                        <?php $tienda = parsear_tienda($tiendaTexto); ?>

                                        <div class="tienda-chip">
                                            <?php if ($tienda['codigo'] !== ''): ?>
                                                <div class="tienda-chip-codigo">
                                                    <?= u_h($tienda['codigo']) ?>
                                                </div>
                                            <?php else: ?>
                                                <div class="tienda-chip-codigo">--</div>
                                            <?php endif; ?>

                                            <div class="tienda-chip-info">
                                                <div class="tienda-chip-nombre">
                                                    <?= u_h($tienda['nombre'] !== '' ? $tienda['nombre'] : 'Tienda sin nombre') ?>
                                                </div>

                                                <div class="tienda-chip-meta">
                                                    <?php
                                                    $meta = array_filter([
                                                        $tienda['pais'],
                                                        $tienda['base'],
                                                        $tienda['zona'],
                                                    ], static fn($v) => trim((string)$v) !== '');

                                                    echo !empty($meta)
                                                        ? u_h(implode(' · ', $meta))
                                                        : 'Sin detalle';
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($puedeGestionar): ?>
                                <div class="acciones-usuarios">
                                    <button
                                        type="button"
                                        class="btn-icon editar btn-editar-usuario"
                                        data-id="<?= $idUsuarioFila ?>"
                                        title="Editar usuario"
                                    >
                                        <i class="bi bi-person-check"></i>
                                    </button>

                                    <?php if ($miRol === 'super_admin'): ?>
                                        <button
                                            type="button"
                                            class="btn-icon <?= ((int)$row['estado'] === 1) ? 'bloquear' : 'activar' ?> btn-estado-usuario"
                                            data-id="<?= $idUsuarioFila ?>"
                                            data-estado="<?= (int)$row['estado'] ?>"
                                            title="<?= ((int)$row['estado'] === 1) ? 'Bloquear usuario' : 'Activar usuario' ?>"
                                        >
                                            <?php if ((int)$row['estado'] === 1): ?>
                                                <i class="bi bi-shield-lock"></i>
                                            <?php else: ?>
                                                <i class="bi bi-person-check"></i>
                                            <?php endif; ?>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="text-muted">Sin acceso</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>

            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$desde = $totalRows > 0 ? ($offset + 1) : 0;
$hasta = min($offset + $perPage, $totalRows);
?>

<div class="paginacion-wrap">
    <div class="paginacion-info">
        Mostrando <?= $desde ?> a <?= $hasta ?> de <?= $totalRows ?> usuarios
    </div>

    <div class="paginacion-controles">
        <label class="me-1 fw-semibold text-muted" for="usuariosPerPage">Mostrar:</label>

        <select id="usuariosPerPage" class="paginacion-select">
            <?php foreach ($permitidosPerPage as $valor): ?>
                <option value="<?= $valor ?>" <?= $perPage === $valor ? 'selected' : '' ?>>
                    <?= $valor ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button
            type="button"
            class="paginacion-btn <?= $page <= 1 ? 'disabled' : '' ?>"
            data-page="<?= max(1, $page - 1) ?>"
        >
            Anterior
        </button>

        <?php
        $inicio = max(1, $page - 2);
        $fin = min($totalPages, $page + 2);

        for ($i = $inicio; $i <= $fin; $i++):
        ?>
            <button
                type="button"
                class="paginacion-btn <?= $i === $page ? 'activa' : '' ?>"
                data-page="<?= $i ?>"
            >
                <?= $i ?>
            </button>
        <?php endfor; ?>

        <button
            type="button"
            class="paginacion-btn <?= $page >= $totalPages ? 'disabled' : '' ?>"
            data-page="<?= min($totalPages, $page + 1) ?>"
        >
            Siguiente
        </button>
    </div>
</div>

<script>
document.addEventListener('click', async function(e){
    const btn = e.target.closest('.paginacion-btn[data-page]');

    if (!btn || btn.classList.contains('disabled')) {
        return;
    }

    const pageNumber = btn.dataset.page || '1';
    const perPageSelect = document.getElementById('usuariosPerPage');
    const itemsPerPage = perPageSelect ? perPageSelect.value : '50';

    const userListContainer = document.getElementById('listaUsuarios');

    if (!userListContainer) {
        return;
    }

    try {
        const r = await fetch(
            '/exhibicion_DT/controlusuarios/listar_usuarios.php?page=' +
            encodeURIComponent(pageNumber) +
            '&per_page=' +
            encodeURIComponent(itemsPerPage),
            {
                cache: 'no-store'
            }
        );

        const userListHtml = await r.text();
        userListContainer.innerHTML = userListHtml;
    } catch (requestError) {
        console.error(requestError);
    }
});

document.addEventListener('change', async function(e){
    if (e.target.id !== 'usuariosPerPage') {
        return;
    }

    const itemsPerPage = e.target.value || '50';
    const userListContainer = document.getElementById('listaUsuarios');

    if (!userListContainer) {
        return;
    }

    try {
        const r = await fetch(
            '/exhibicion_DT/controlusuarios/listar_usuarios.php?page=1&per_page=' +
            encodeURIComponent(itemsPerPage),
            {
                cache: 'no-store'
            }
        );

        const userListHtml = await r.text();
        userListContainer.innerHTML = userListHtml;
    } catch (requestError) {
        console.error(requestError);
    }
});
</script>