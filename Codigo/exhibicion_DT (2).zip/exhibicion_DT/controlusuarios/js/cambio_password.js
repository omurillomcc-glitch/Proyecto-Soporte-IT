document.getElementById('cambioPasswordForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const aviso = document.getElementById('aviso');
    const boton = document.getElementById('guardar');
    const nueva = form.elements.nueva.value;
    const confirmar = form.elements.confirmar.value;
    aviso.classList.remove('exito');
    if (nueva.length < 10 || nueva.length > 64 || new TextEncoder().encode(nueva).length > 72 || /[\u0000-\u001f\u007f]/.test(nueva)) {
        aviso.textContent = 'La nueva contraseña debe tener 10 a 64 caracteres imprimibles y máximo 72 bytes.';
        return;
    }
    if (nueva !== confirmar) {
        aviso.textContent = 'La confirmación no coincide.';
        return;
    }
    boton.disabled = true;
    try {
        const response = await fetch(form.action, {method: 'POST', body: new FormData(form), credentials: 'same-origin'});
        const data = await response.json();
        if (!response.ok || !data.ok) throw new Error(data.msg || 'No se pudo actualizar la contraseña.');
        aviso.textContent = 'Contraseña actualizada. Entrando a la aplicación…';
        aviso.classList.add('exito');
        window.location.assign('/exhibicion_DT/index.php');
    } catch (e) {
        aviso.textContent = e.message || 'No fue posible guardar el cambio.';
        boton.disabled = false;
    }
});
