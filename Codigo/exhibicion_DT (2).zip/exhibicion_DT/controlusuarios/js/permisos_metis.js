/** Permisos de menú y asignaciones de tiendas. */
(() => {
    const permissionsPage = document.getElementById('pmPage');
    if (!permissionsPage) return;

    const pageMessage = document.getElementById('pmMensaje');
    const userSearchInput = document.getElementById('pmBuscar');
    const userCards = [...permissionsPage.querySelectorAll('.pm-user')];
    const noResultsMessage = document.getElementById('pmSinResultados');


    /** Modal de configuración de cada usuario. */
    for (const userCard of userCards) {
        const openModalButton = userCard.querySelector('[data-pm-open-modal]');
        const userDialog = userCard.querySelector('.pm-user-dialog');
        const closeModalButton = userCard.querySelector('[data-pm-close-modal]');
        if (!openModalButton || !userDialog) continue;

        openModalButton.addEventListener('click', () => {
            if (typeof userDialog.showModal === 'function') userDialog.showModal();
        });
        closeModalButton?.addEventListener('click', () => userDialog.close());
        userDialog.addEventListener('click', evento => {
            if (evento.target === userDialog) userDialog.close();
        });
    }

    function informar(mensaje, correcto, formulario = null) {
        const feedbackElement = formulario?.closest('.pm-user-dialog')?.querySelector('.pm-dialog-feedback') || pageMessage;
        feedbackElement.textContent = mensaje;
        feedbackElement.className = (feedbackElement === pageMessage ? 'pm-alert ' : 'pm-dialog-feedback ') +
            (correcto ? 'pm-alert-success' : 'pm-alert-error');
        feedbackElement.hidden = false;
    }

    userSearchInput?.addEventListener('input', () => {
        const searchTerm = userSearchInput.value.trim().toLocaleLowerCase('es');
        let visibleUserCount = 0;
        for (const userCard of userCards) {
            const matchesSearch = (userCard.dataset.pmUser || '').toLocaleLowerCase('es').includes(searchTerm);
            userCard.hidden = !matchesSearch;
            if (matchesSearch) visibleUserCount++;
        }
        if (noResultsMessage) noResultsMessage.hidden = visibleUserCount > 0;
    });

    for (const permissionForm of permissionsPage.querySelectorAll('.pm-form')) {
        permissionForm.addEventListener('submit', async evento => {
            evento.preventDefault();
            const dialogFeedback = permissionForm.closest('.pm-user-dialog')?.querySelector('.pm-dialog-feedback');
            if (dialogFeedback) dialogFeedback.hidden = true;
            else pageMessage.hidden = true;
            const saveButton = permissionForm.querySelector('.pm-save');
            saveButton.disabled = true;
            try {
                const response = await fetch(permissionForm.action, {
                    method: 'POST', body: new FormData(permissionForm),
                    credentials: 'same-origin', cache: 'no-store',
                    headers: { Accept: 'application/json' }
                });
                const result = await response.json();
                informar(result.msg || 'No se pudo completar la operación.', response.ok && result.ok, permissionForm);
            } catch (_) {
                informar('No se pudo comunicar con el servidor.', false, permissionForm);
            } finally {
                saveButton.disabled = false;
            }
        });
    }

    for (const storeSection of permissionsPage.querySelectorAll('[data-pm-store-section]')) {
        const openStoreButton = storeSection.querySelector('[data-pm-open-store]');
        const storeEditor = storeSection.querySelector('.pm-store-editor');
        const storeForm = storeSection.querySelector('.pm-store-form');
        if (!openStoreButton || !storeEditor || !storeForm) continue;

        const userIdInput = storeForm.querySelector('[name="usuario_id"]');
        const storeOptions = storeForm.querySelector('.pm-store-options');
        const storeSearchInput = storeForm.querySelector('.pm-store-search input');
        const storeSelectionCount = storeForm.querySelector('.pm-store-selected');
        const saveStoresButton = storeForm.querySelector('.pm-store-save');
        const currentStoresSummary = storeSection.querySelector('[data-pm-current-stores]');
        const cancelStoresButton = storeForm.querySelector('.pm-store-cancel');
        const storeFeedback = storeSection.querySelector('.pm-store-feedback');
        function informarTienda(mensaje, correcto) {
            storeFeedback.textContent = mensaje;
            storeFeedback.className = 'pm-store-feedback ' + (correcto ? 'pm-store-ok' : 'pm-store-error');
            storeFeedback.hidden = false;
        }
        let rol = 'tienda';
        let availableStores = [];

        function actualizarConteo() {
            const selectedStoreCount = storeOptions.querySelectorAll('input[type="checkbox"]:checked').length;
            storeSelectionCount.textContent = rol === 'tienda'
                ? `${selectedStoreCount} de 1 tienda seleccionada`
                : `${selectedStoreCount} tiendas seleccionadas`;
        }

        function dibujarTiendas() {
            storeOptions.replaceChildren();
            if (availableStores.length === 0) {
                storeOptions.textContent = 'No hay tiendas disponibles para este país.';
                actualizarConteo();
                return;
            }
            const optionsFragment = document.createDocumentFragment();
            for (const store of availableStores) {
                const storeOption = document.createElement('label');
                storeOption.className = 'pm-store-option';
                storeOption.dataset.buscar = `${store.codigo} ${store.nombre} ${store.zona}`.toLocaleLowerCase('es');
                const storeCheckbox = document.createElement('input');
                storeCheckbox.type = 'checkbox';
                storeCheckbox.name = 'tiendas[]';
                storeCheckbox.value = store.clave;
                storeCheckbox.checked = !!store.seleccionada;
                const storeDetails = document.createElement('span');
                const storeName = document.createElement('strong');
                storeName.textContent = `${store.codigo} · ${store.nombre}`;
                const storeZone = document.createElement('small');
                storeZone.textContent = `Zona: ${store.zona}`;
                storeDetails.append(storeName, storeZone);
                storeOption.append(storeCheckbox, storeDetails);
                storeCheckbox.addEventListener('change', () => {
                    if (rol === 'tienda' && storeCheckbox.checked) {
                        for (const otherStoreCheckbox of storeOptions.querySelectorAll('input[type="checkbox"]')) {
                            if (otherStoreCheckbox !== storeCheckbox) otherStoreCheckbox.checked = false;
                        }
                    }
                    actualizarConteo();
                });
                optionsFragment.appendChild(storeOption);
            }
            storeOptions.appendChild(optionsFragment);
            actualizarConteo();
        }

        openStoreButton.addEventListener('click', async () => {
            if (!storeEditor.hidden) {
                storeEditor.hidden = true;
                return;
            }
            openStoreButton.disabled = true;
            storeFeedback.hidden = true;
            storeOptions.textContent = 'Consultando tiendas autorizadas...';
            storeEditor.hidden = false;
            try {
                const url = `/exhibicion_DT/controlusuarios/tiendas_permisos.php?usuario_id=${encodeURIComponent(userIdInput.value)}`;
                const res = await fetch(url, { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } });
                const response = await res.json();
                if (!res.ok || !response.ok) throw new Error(response.msg || 'No se pudieron cargar las tiendas.');
                availableStores = Array.isArray(response.tiendas) ? response.tiendas : [];
                rol = response.rol;
                storeSearchInput.value = '';
                dibujarTiendas();
            } catch (requestError) {
                storeEditor.hidden = true;
                informarTienda(requestError.message || 'No se pudieron cargar las tiendas.', false);
            } finally {
                openStoreButton.disabled = false;
            }
        });

        cancelStoresButton.addEventListener('click', () => {
            storeEditor.hidden = true;
        });

        storeSearchInput.addEventListener('input', () => {
            const storeSearchTerm = storeSearchInput.value.trim().toLocaleLowerCase('es');
            for (const storeOption of storeOptions.querySelectorAll('.pm-store-option')) {
                storeOption.hidden = !storeOption.dataset.buscar.includes(storeSearchTerm);
            }
        });

        storeForm.addEventListener('submit', async evento => {
            evento.preventDefault();
            const selectedStoreCheckboxes = [...storeOptions.querySelectorAll('input[type="checkbox"]:checked')];
            if ((rol === 'tienda' && selectedStoreCheckboxes.length !== 1) || (rol === 'admin_zona' && selectedStoreCheckboxes.length === 0)) {
                informarTienda(rol === 'tienda' ? 'Debes seleccionar exactamente una tienda.' : 'Selecciona al menos una tienda.', false);
                return;
            }
            saveStoresButton.disabled = true;
            try {
                const saveResponse = await fetch(storeForm.action, {
                    method: 'POST', body: new FormData(storeForm), credentials: 'same-origin',
                    cache: 'no-store', headers: { Accept: 'application/json' }
                });
                const result = await saveResponse.json();
                if (!saveResponse.ok || !result.ok) throw new Error(result.msg || 'No se pudieron guardar las tiendas.');
                const assignedStores = Array.isArray(result.asignadas) ? result.asignadas : [];
                const storeCount = currentStoresSummary.querySelector('.pm-store-count');
                const storeChips = currentStoresSummary.querySelector('.pm-store-chips');
                storeCount.textContent = `${assignedStores.length} ${assignedStores.length === 1 ? 'tienda asignada' : 'tiendas asignadas'}`;
                storeChips.replaceChildren();
                for (const store of assignedStores.slice(0, 12)) {
                    const storeChip = document.createElement('span');
                    storeChip.className = 'pm-store-chip';
                    storeChip.textContent = `${store.codigo} · ${store.nombre}`;
                    storeChips.appendChild(storeChip);
                }
                if (assignedStores.length > 12) {
                    const moreStoresChip = document.createElement('span');
                    moreStoresChip.className = 'pm-store-chip';
                    moreStoresChip.textContent = `+${assignedStores.length - 12} más`;
                    storeChips.appendChild(moreStoresChip);
                }
                storeEditor.hidden = true;
                informarTienda(result.msg, true);
            } catch (requestError) {
                informarTienda(requestError.message || 'No se pudieron guardar las tiendas.', false);
            } finally {
                saveStoresButton.disabled = false;
            }
        });
    }
})();
