<?php
declare(strict_types=1);

// Alcance de tiendas para rutas independientes de Metis.
function at_normalizar_codigo(string $codigo): string
{
    $codigo = trim($codigo);
    if (!preg_match('/^\d{1,4}$/D', $codigo)) return '';
    $sinCeros = ltrim($codigo, '0');
    return str_pad($sinCeros === '' ? '0' : $sinCeros, 2, '0', STR_PAD_LEFT);
}

function at_almacenes_permitidos(mysqli $conn, array $usuario): ?array
{
    $rol = (string)($usuario['rol'] ?? '');
    if ($rol === 'super_admin') return null;
    if (!in_array($rol, ['tienda', 'admin_zona'], true)) return [];
    $id = (int)($usuario['id'] ?? 0);
    $pais = strtoupper(trim((string)($usuario['pais_code'] ?? '')));
    if ($id < 1 || !in_array($pais, ['HN', 'NI'], true)) return [];
    $largo = $pais === 'NI' ? 'NICARAGUA' : 'HONDURAS';
    $stmt = $conn->prepare(
        'SELECT codalmacen FROM usuario_tienda WHERE usuario_id = ? '
        . 'AND UPPER(TRIM(pais)) IN (?, ?)'
    );
    if (!$stmt) throw new RuntimeException('No se pudieron consultar las tiendas permitidas.');
    $stmt->bind_param('iss', $id, $pais, $largo);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('No se pudieron consultar las tiendas permitidas.');
    }
    $rows = $stmt->get_result();
    $codigos = [];
    while ($fila = $rows->fetch_assoc()) {
        $codigo = at_normalizar_codigo((string)($fila['codalmacen'] ?? ''));
        if ($codigo !== '') $codigos[$codigo] = true;
    }
    $stmt->close();
    if ($rol === 'tienda' && count($codigos) !== 1) return [];
    return array_keys($codigos);
}

function at_exigir_tienda(?array $permitidas, string $codigo): void
{
    if ($permitidas === null) return;
    $normal = at_normalizar_codigo($codigo);
    if ($normal === '' || !in_array($normal, $permitidas, true)) {
        throw new DomainException('No tienes acceso a la tienda indicada.');
    }
}

function at_exigir_pais(array $usuario, string $region): void
{
    $pais = strtoupper(trim((string)($usuario['pais_code'] ?? '')));
    $esperada = $pais === 'NI' ? 'NICARAGUA' : 'HONDURAS';
    $actual = strtoupper(trim($region));
    if ($actual === 'NI') $actual = 'NICARAGUA';
    if ($actual === 'HN') $actual = 'HONDURAS';
    if ($actual !== $esperada) {
        throw new DomainException('No tienes acceso al país indicado.');
    }
}
