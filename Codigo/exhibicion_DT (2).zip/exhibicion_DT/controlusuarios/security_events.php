<?php
// Eventos locales de seguridad. No contiene contraseñas ni tokens.
function exdt_registrar_evento(string $tipo, string $usuario, string $ip, string $actor = ''): void
{
    $eventos = ['LOGIN_CORRECTO','LOGIN_FALLIDO','LOGIN_BLOQUEADO','PASSWORD_RESTABLECIDA','PASSWORD_CAMBIADA','ACCESO_DENEGADO','FORMULARIO_RECHAZADO'];
    if (!in_array($tipo, $eventos, true)) {
        return;
    }
    $privado = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'privado_exhibicion';
    $carpeta = $privado . DIRECTORY_SEPARATOR . 'seguridad';
    if (!is_dir($privado)) {
        error_log('Exhibición DT: falta carpeta privada para registros de seguridad.');
        return;
    }
    if (!is_dir($carpeta) && !@mkdir($carpeta, 0700, true) && !is_dir($carpeta)) {
        error_log('Exhibición DT: no se pudo crear carpeta de registros de seguridad.');
        return;
    }
    $evento = [
        'fecha' => date('c'),
        'evento' => $tipo,
        'usuario' => mb_substr($usuario, 0, 60, 'UTF-8'),
        'ip' => mb_substr($ip, 0, 45, 'UTF-8'),
        'actor' => mb_substr($actor, 0, 60, 'UTF-8'),
    ];
    try {
        if (@file_put_contents($carpeta . DIRECTORY_SEPARATOR . 'eventos.jsonl',
            json_encode($evento, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) . PHP_EOL,
            FILE_APPEND | LOCK_EX) === false) {
            error_log('Exhibición DT: falló escritura de registro de seguridad.');
        }
    } catch (Throwable $e) {
        error_log('Exhibición DT: error de registro de seguridad.');
    }
}
