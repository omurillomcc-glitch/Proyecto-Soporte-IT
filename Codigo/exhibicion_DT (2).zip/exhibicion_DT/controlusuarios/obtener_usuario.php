<?php
declare(strict_types=1);


header('Content-Type: application/json; charset=utf-8');


session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/security_events.php';


function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(
        ['ok' => $ok, 'msg' => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}


function normalizar_pais_code_obtener(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}


require_user_admin();
$me = me();
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId  = (int)($me['id'] ?? 0);
$miRol = (string)($me['rol'] ?? '');


$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    json_out(false, 'ID inválido.');
}


if (!u_can_manage_user($conn, $miId, $miRol, $id)) {
    exdt_registrar_evento('ACCESO_DENEGADO', (string)($me['usuario'] ?? ''),
        (string)($_SERVER['REMOTE_ADDR'] ?? ''), 'usuarios:ver');
    json_out(false, 'No puedes ver este usuario.');
}


$stmt = $conn->prepare("
    SELECT
        id,
        usuario,
        nombre_completo,
        rol,
        estado,
        pais_code
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    json_out(false, 'Error preparando consulta del usuario.', [
        'sql_error' => $conn->error
    ]);
}

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
    $err = $stmt->error;
    $stmt->close();
    json_out(false, 'Error ejecutando consulta del usuario.', [
        'sql_error' => $err
    ]);
}

$res  = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if (!$user) {
    json_out(false, 'Usuario no encontrado.');
}


$stmt2 = $conn->prepare("
    SELECT
        pais,
        base_datos,
        zona,
        codalmacen,
        nombrealmacen
    FROM usuario_tienda
    WHERE usuario_id = ?
    ORDER BY pais, base_datos, zona, codalmacen
");

if (!$stmt2) {
    json_out(false, 'Error preparando consulta de tiendas.', [
        'sql_error' => $conn->error
    ]);
}

$stmt2->bind_param("i", $id);

if (!$stmt2->execute()) {
    $err2 = $stmt2->error;
    $stmt2->close();
    json_out(false, 'Error ejecutando consulta de tiendas.', [
        'sql_error' => $err2
    ]);
}

$res2 = $stmt2->get_result();


$stores = [];
$store_keys = [];

while ($row = $res2->fetch_assoc()) {
    $paisTexto = trim((string)($row['pais'] ?? ''));
    $paisCode  = normalizar_pais_code_obtener($paisTexto);

    $store = [
        'pais'          => $paisTexto,
        'pais_code'     => $paisCode,
        'base_datos'    => (string)($row['base_datos'] ?? ''),
        'zona'          => (string)($row['zona'] ?? ''),
        'codalmacen'    => (string)($row['codalmacen'] ?? ''),
        'nombrealmacen' => (string)($row['nombrealmacen'] ?? ''),
    ];

    $stores[] = $store;

    $store_keys[] = u_store_key(
        $paisTexto,
        (string)($row['base_datos'] ?? ''),
        (string)($row['codalmacen'] ?? '')
    );
}

$stmt2->close();


json_out(true, 'ok', [
    'data' => [
        'id'         => (int)($user['id'] ?? 0),
        'usuario'    => (string)($user['usuario'] ?? ''),
        'nombre_completo' => (string)($user['nombre_completo'] ?? ''),
        'rol'        => (string)($user['rol'] ?? ''),
        'estado'     => (int)($user['estado'] ?? 1),
        'pais_code'  => normalizar_pais_code_obtener((string)($user['pais_code'] ?? '')),
        'stores'     => $stores,
        'store_keys' => $store_keys,
        'puede_restablecer_password' => u_can_reset_password($conn, $miId, $miRol, $id),
    ]
]);