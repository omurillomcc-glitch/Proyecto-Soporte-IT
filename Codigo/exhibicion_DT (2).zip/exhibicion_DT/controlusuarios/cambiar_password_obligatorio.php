<?php
// La renovación de contraseñas se gestiona exclusivamente desde el módulo Usuarios.
header('Cache-Control: no-store, no-cache, must-revalidate');
require_once __DIR__ . '/auth.php';
require_login();
header('Location: /exhibicion_DT/index.php');
exit;
