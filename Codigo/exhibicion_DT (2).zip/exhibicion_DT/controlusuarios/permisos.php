<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/accesos_menu.php';
require_login();
$miId = (int)(me()['id'] ?? $_SESSION['usuario_id'] ?? 0);
if (!am_es_propietario($conn, $miId)) {
    http_response_code(403);
    exit('Acceso denegado.');
}
if (empty($_SESSION['csrf_permisos'])) {
    $_SESSION['csrf_permisos'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['csrf_permisos'];
function pm_h(mixed $valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$usuarios = [];
$res = $conn->query('SELECT id, usuario, nombre_completo, rol, estado, pais_code FROM usuarios ORDER BY usuario');
while ($fila = $res->fetch_assoc()) $usuarios[] = $fila;
$res->free();

$permisos = [];
$res = $conn->query('SELECT usuario_id, modulo, permitido FROM usuario_acceso_menu');
while ($fila = $res->fetch_assoc()) {
    $permisos[(int)$fila['usuario_id']][(string)$fila['modulo']] = (int)$fila['permitido'];
}
$res->free();

/** Consultar las tiendas asignadas. */
$tiendasPorUsuario = [];
$consultaTiendas = $conn->query(
    'SELECT usuario_id, pais, codalmacen, nombrealmacen FROM usuario_tienda ORDER BY nombrealmacen, codalmacen'
);
while ($tienda = $consultaTiendas->fetch_assoc()) {
    $tiendasPorUsuario[(int)$tienda['usuario_id']][] = $tienda;
}
$consultaTiendas->free();

$modulos = am_modulos();
$grupos = [
    'Operación y gestión' => ['dashboard', 'modulo1', 'modulo3', 'cobertura', 'cobertura_importar', 'bloqueo', 'bloqueo_tienda'],
    'Consultas' => ['consulta_con_stock', 'consulta_sin_stock', 'puntas_gondolas'],
    'Administración' => ['modulo2', 'usuarios'],
];
$iconosGrupo = [
    'Operación y gestión' => 'bi-grid-1x2',
    'Consultas' => 'bi-search',
    'Administración' => 'bi-shield-lock',
];
?>
<link rel="stylesheet" href="/exhibicion_DT/controlusuarios/css/permisos_metis.css?v=9">
<section class="pm-page" id="pmPage" aria-label="Administración de permisos">
    <header class="pm-heading">
        <div class="pm-heading-info">
            <div class="pm-heading-icon"><i class="bi bi-shield-lock" aria-hidden="true"></i></div>
            <div>
                <p>Menús de cada usuario. Las restricciones de país y tiendas permanecen activas.</p>
            </div>
        </div>
        <div class="pm-counter"><i class="bi bi-people" aria-hidden="true"></i> <?= count($usuarios) ?> usuarios</div>
    </header>

    <div id="pmMensaje" class="pm-alert" role="status" aria-live="polite" hidden></div>
    <div class="pm-toolbar">
        <label class="pm-search">
            <i class="bi bi-search" aria-hidden="true"></i>
            <input id="pmBuscar" type="search" placeholder="Buscar usuario, nombre o rol..." autocomplete="off" aria-label="Buscar usuarios">
        </label>
        <p><i class="bi bi-info-circle" aria-hidden="true"></i> Solo el Propietario puede otorgar o retirar permisos.</p>
    </div>
    <div class="pm-directory" id="pmDirectorio">
        <?php foreach ($usuarios as $u):
            $uid = (int)$u['id'];
            $esDueno = am_es_propietario($conn, $uid);
            $rol = (string)$u['rol'];
            $origen = strtoupper(trim((string)($u['pais_code'] ?? '')));
            $paisOrigen = $origen === 'NI' ? 'Nicaragua' : ($origen === 'HN' ? 'Honduras' : 'No asignado');
            $nombre = trim((string)($u['nombre_completo'] ?? '')) ?: (string)$u['usuario'];
            $activo = (int)$u['estado'] === 1;
        ?>
        <article class="pm-user" data-pm-user="<?= pm_h($nombre . ' ' . $u['usuario'] . ' ' . $rol . ' ' . $paisOrigen) ?>">
            <button type="button" class="pm-user-header" data-pm-open-modal aria-haspopup="dialog" aria-controls="pmDialog-<?= $uid ?>">
                    <span class="pm-avatar" aria-hidden="true"><?= pm_h(function_exists('mb_substr') ? mb_strtoupper(mb_substr($nombre, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($nombre, 0, 1))) ?></span>
                    <span class="pm-user-main">
                        <strong><?= pm_h($nombre) ?></strong>
                        <small>@<?= pm_h($u['usuario']) ?> <span aria-hidden="true">·</span> <?= pm_h(str_replace('_', ' ', $rol)) ?></small>
                    </span>
                    <span class="pm-user-meta">
                        <?php if ($esDueno): ?><span class="pm-tag pm-tag-owner">Propietario</span><?php endif; ?>
                        <span class="pm-tag <?= $activo ? 'pm-tag-active' : 'pm-tag-inactive' ?>"><?= $activo ? 'Activo' : 'Inactivo' ?></span>
                        <span class="pm-tag pm-tag-country"><?= pm_h($paisOrigen) ?></span>
                    </span>
                    <span class="pm-action-caption"><i class="bi bi-sliders" aria-hidden="true"></i> <?= $esDueno ? 'Ver propietario' : 'Configurar' ?></span>
            </button>
            <dialog class="pm-user-dialog" id="pmDialog-<?= $uid ?>" aria-labelledby="pmDialogTitle-<?= $uid ?>">
                <header class="pm-dialog-header">
                    <div class="pm-dialog-person">
                        <span class="pm-avatar pm-dialog-avatar" aria-hidden="true"><?= pm_h(function_exists('mb_substr') ? mb_strtoupper(mb_substr($nombre, 0, 1, 'UTF-8'), 'UTF-8') : strtoupper(substr($nombre, 0, 1))) ?></span>
                        <div class="pm-dialog-identity">
                            <p class="pm-dialog-eyebrow">Administración de accesos</p>
                            <h3 id="pmDialogTitle-<?= $uid ?>"><?= pm_h($nombre) ?></h3>
                            <p>@<?= pm_h($u['usuario']) ?> · <?= pm_h(str_replace('_', ' ', $rol)) ?></p>
                        </div>
                    </div>
                    <button type="button" class="pm-dialog-close" data-pm-close-modal aria-label="Cerrar configuración" title="Cerrar">
                        <i class="bi bi-x-lg" aria-hidden="true"></i>
                    </button>
                </header>
                <div class="pm-dialog-meta" aria-label="Información de la cuenta">
                    <?php if ($esDueno): ?><span class="pm-tag pm-tag-owner"><i class="bi bi-shield-check" aria-hidden="true"></i> Propietario</span><?php endif; ?>
                    <span class="pm-tag <?= $activo ? 'pm-tag-active' : 'pm-tag-inactive' ?>"><i class="bi bi-circle-fill" aria-hidden="true"></i> <?= $activo ? 'Activo' : 'Inactivo' ?></span>
                    <span class="pm-tag pm-tag-country"><i class="bi bi-globe-americas" aria-hidden="true"></i> <?= pm_h($paisOrigen) ?></span>
                </div>
                <div class="pm-dialog-scroll">
                    <div class="pm-dialog-feedback" role="status" aria-live="polite" hidden></div>
                    <div class="pm-user-body">
                    <?php if ($esDueno): ?>
                        <p class="pm-owner-message"><i class="bi bi-shield-check" aria-hidden="true"></i> El Propietario tiene acceso total. Los permisos de su cuenta no se modifican desde aquí.</p>
                    <?php else: ?>
                    <form class="pm-form" action="/exhibicion_DT/controlusuarios/guardar_permisos.php" method="post">
                        <input type="hidden" name="usuario_id" value="<?= $uid ?>">
                        <input type="hidden" name="csrf_token" value="<?= pm_h($csrf) ?>">
                        <p class="pm-perm-intro"><i class="bi bi-shield-check" aria-hidden="true"></i> <span>Selecciona los menús que podrá abrir este usuario. Los cambios se aplican al guardar.</span></p>
                        <?php foreach ($grupos as $grupo => $codigos): ?>
                        <section class="pm-perm-group">
                            <h3><i class="bi <?= pm_h($iconosGrupo[$grupo] ?? 'bi-grid') ?>" aria-hidden="true"></i><?= pm_h($grupo) ?></h3>
                            <div class="pm-perm-grid">
                                <?php foreach ($codigos as $codigo):
                                    $nombreModulo = $modulos[$codigo];
                                    $compatible = am_modulo_compatible($rol, $codigo);
                                    $activado = $compatible && (($permisos[$uid][$codigo] ?? 0) === 1);
                                ?>
                                <div class="pm-perm-card <?= !$compatible ? 'pm-perm-unavailable' : '' ?> <?= $codigo === 'bloqueo' && $compatible && in_array($rol, ['tienda', 'admin_zona'], true) ? 'pm-perm-sensitive' : '' ?>" data-pm-module>
                                    <label class="pm-module-toggle">
                                        <input type="checkbox" name="modulos[]" value="<?= pm_h($codigo) ?>"
                                            <?= $activado ? 'checked' : '' ?> <?= !$compatible || !$activo ? 'disabled' : '' ?>>
                                        <span><?= pm_h($nombreModulo) ?></span>
                                    </label>
                                    <?php if (!$compatible): ?>
                                        <span class="pm-module-note">No disponible para este rol</span>
                                    <?php endif; ?>
                                    <?php
                                        $mensajeAlcance = 'Acceso al módulo';
                                        if ($codigo === 'bloqueo' && in_array($rol, ['tienda', 'admin_zona'], true)) {
                                            $mensajeAlcance = 'IMPORTANTE: verá los bloqueos de todo su país, no solo su tienda';
                                        } elseif ($codigo === 'dashboard' && $rol === 'tienda') {
                                            $mensajeAlcance = 'Indicadores de su tienda asignada';
                                        } elseif ($codigo === 'cobertura_importar') {
                                            $mensajeAlcance = 'Requiere permiso Cobertura; solo tiendas asignadas';
                                        } elseif (in_array($codigo, ['cobertura', 'bloqueo_tienda'], true)
                                            && in_array($rol, ['tienda', 'admin_zona'], true)) {
                                            $mensajeAlcance = 'Solo sus tiendas asignadas';
                                        } elseif ($rol === 'tienda' && $compatible) {
                                            $mensajeAlcance = 'Limitado a su tienda asignada';
                                        }
                                    ?>
                                    <span class="pm-module-note"><?= pm_h($mensajeAlcance) ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </section>
                        <?php endforeach; ?>
                        <footer class="pm-form-footer">
                            <span><i class="bi bi-shield-check" aria-hidden="true"></i> Los permisos se validan también al abrir enlaces directos.</span>
                            <button type="submit" class="pm-save" <?= !$activo ? 'disabled' : '' ?>><i class="bi bi-check2-circle" aria-hidden="true"></i> Guardar permisos</button>
                        </footer>
                    </form>
                    <!-- Las asignaciones se gestionan desde Control de Usuarios. -->
                    <section class="pm-store-section" aria-label="Información de tiendas asignadas">
                        <header class="pm-store-heading">
                            <div>
                                <h3><i class="bi bi-shop" aria-hidden="true"></i> Tiendas asignadas</h3>
                                <p>Información de consulta. Las tiendas se asignan desde Control de Usuarios.</p>
                            </div>
                        </header>
                        <?php if (in_array($rol, ['tienda', 'admin_zona'], true)): ?>
                            <?php $asignadas = array_values(array_filter($tiendasPorUsuario[$uid] ?? [], static fn($t) => (
                                strtoupper(trim((string)$t['pais'])) === $origen ||
                                (strtoupper(trim((string)$t['pais'])) === 'HONDURAS' && $origen === 'HN') ||
                                (strtoupper(trim((string)$t['pais'])) === 'NICARAGUA' && $origen === 'NI')
                            ))); ?>
                            <div class="pm-store-current">
                                <strong class="pm-store-count"><?= count($asignadas) ?> <?= count($asignadas) === 1 ? 'tienda asignada' : 'tiendas asignadas' ?></strong>
                                <div class="pm-store-chips">
                                    <?php foreach ($asignadas as $tienda): ?>
                                        <span class="pm-store-chip"><?= pm_h($tienda['codalmacen']) ?> · <?= pm_h($tienda['nombrealmacen']) ?></span>
                                    <?php endforeach; ?>
                                </div>
                                <?php if (!$asignadas): ?>
                                    <p class="pm-note">Sin tiendas asignadas. Configúralas desde Control de Usuarios.</p>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="pm-note">Este rol no utiliza asignaciones individuales de tienda.</p>
                        <?php endif; ?>
                    </section>
                    <?php if (!$activo): ?><p class="pm-note">Activa esta cuenta antes de asignarle permisos.</p><?php endif; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </dialog>
        </article>
        <?php endforeach; ?>
        <p class="pm-noresults" id="pmSinResultados" hidden>No se encontraron usuarios con ese filtro.</p>
    </div>
    <footer class="pm-footnote">Cada usuario conserva su país. El rol Tienda tiene una tienda y Admin de Zona solo las tiendas que se le asignen. Estos accesos son independientes de los permisos de módulos.</footer>
</section>
<script src="/exhibicion_DT/controlusuarios/js/permisos_metis.js?v=7" defer></script>
