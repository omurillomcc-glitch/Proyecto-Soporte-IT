<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/accesos_menu.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function gp_respuesta(bool $ok, string $msg, int $codigo): never
{
    http_response_code($codigo);
    echo json_encode(['ok' => $ok, 'msg' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') gp_respuesta(false, 'Método no permitido.', 405);
require_login();
$miId = (int)(me()['id'] ?? $_SESSION['usuario_id'] ?? 0);
if (!am_es_propietario($conn, $miId)) gp_respuesta(false, 'Acceso denegado.', 403);

$enviado = (string)($_POST['csrf_token'] ?? '');
$esperado = (string)($_SESSION['csrf_permisos'] ?? '');
if ($esperado === '' || !hash_equals($esperado, $enviado)) {
    gp_respuesta(false, 'La sesión de seguridad venció.', 403);
}

$usuarioId = filter_input(INPUT_POST, 'usuario_id', FILTER_VALIDATE_INT);
if (!$usuarioId || $usuarioId <= 0 || $usuarioId === $miId) {
    gp_respuesta(false, 'Usuario no válido.', 422);
}

$stmt = $conn->prepare('SELECT id, rol, usuario, nombre_completo FROM usuarios WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $usuarioId);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$usuario || am_es_propietario($conn, $usuarioId)) gp_respuesta(false, 'Usuario no válido.', 422);

$seleccion = $_POST['modulos'] ?? [];
if (!is_array($seleccion)) gp_respuesta(false, 'Permisos no válidos.', 422);
$lista = am_modulos();
foreach ($seleccion as $valor) {
    if (!is_string($valor) || !array_key_exists($valor, $lista)) {
        gp_respuesta(false, 'Se recibió un módulo no válido.', 422);
    }
}
$seleccion = array_unique($seleccion);
$rol = (string)$usuario['rol'];

try {
    $anteriores = [];
    $consulta = $conn->prepare('SELECT modulo, permitido FROM usuario_acceso_menu WHERE usuario_id = ?');
    $consulta->bind_param('i', $usuarioId);
    $consulta->execute();
    $filas = $consulta->get_result();
    while ($fila = $filas->fetch_assoc()) {
        $anteriores[(string)$fila['modulo']] = (int)$fila['permitido'];
    }
    $consulta->close();
    $cambios = [];
    $conn->begin_transaction();
    $stmt = $conn->prepare(
        'INSERT INTO usuario_acceso_menu (usuario_id, modulo, permitido) VALUES (?, ?, ?) '
        . 'ON DUPLICATE KEY UPDATE permitido = VALUES(permitido)'
    );
  foreach ($lista as $codigo => $_) {
        // Roles permitidos para estos módulos operativos y de gestión
        $rolPermitido = in_array($rol, ['super_admin', 'admin_zona', 'tienda'], true);

        $compatible = !(in_array($codigo, ['usuarios','modulo2'], true) && !$rolPermitido)
            && !(in_array($codigo, ['cobertura','cobertura_importar','bloqueo'], true) && !$rolPermitido);

        $permitido = ($compatible && in_array($codigo, $seleccion, true)) ? 1 : 0;
        $anterior = $anteriores[$codigo] ?? 0;
        if ($anterior !== $permitido) {
            $cambios[] = $codigo . ': ' . ($anterior ? 'SI' : 'NO') . ' -> ' . ($permitido ? 'SI' : 'NO');
        }
        $stmt->bind_param('isi', $usuarioId, $codigo, $permitido);
        if (!$stmt->execute()) throw new RuntimeException('No se guardó el módulo.');
    }
    $stmt->close();
    $conn->commit();
    if ($cambios) {
        require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';
        $nombreUsuario = trim((string)($usuario['nombre_completo'] ?? ''));
        $nombreUsuario = $nombreUsuario !== ''
            ? $nombreUsuario . ' (@' . (string)$usuario['usuario'] . ')'
            : (string)$usuario['usuario'];
        try {
            registrar_auditoria('PERMISOS', 'PERMISOS_ACTUALIZADOS',
                'Usuario: ' . $nombreUsuario . ' | CAMBIOS: ' . implode('; ', $cambios),
                null, null, null, null, $conn);
        } catch (Throwable $errorAuditoria) {
            error_log('Auditoría de permisos: ' . $errorAuditoria->getMessage());
        }
    }
    gp_respuesta(true, 'Permisos actualizados.', 200);
} catch (Throwable $e) {
    $conn->rollback();
    error_log('Error guardando permisos de menú: ' . $e->getMessage());
    gp_respuesta(false, 'No se pudieron actualizar los permisos.', 500);
}
