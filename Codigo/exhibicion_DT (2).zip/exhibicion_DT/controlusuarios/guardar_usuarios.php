<?php
declare(strict_types=1);


header('Content-Type: application/json; charset=utf-8');


session_name('APP_EXHIBICION');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


ini_set('display_errors', '0');
error_reporting(E_ALL);


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/conexion_sqlsrv.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/helpers_usuarios.php';
require_once __DIR__ . '/password_security.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';


function aud_region_label(string $code): string
{
    return match (strtoupper(trim($code))) {
        'HN' => 'HONDURAS',
        'NI' => 'NICARAGUA',
        default => strtoupper(trim($code)),
    };
}


function json_out(bool $ok, string $msg, array $extra = []): void {
    echo json_encode(['ok' => $ok, 'msg' => $msg] + $extra, JSON_UNESCAPED_UNICODE);
    exit;
}


function normalizar_pais_code_guardar(string $pais): string {
    $pais = strtoupper(trim($pais));

    return match ($pais) {
        'HN', 'HONDURAS'  => 'HN',
        'NI', 'NICARAGUA' => 'NI',
        default           => $pais,
    };
}


if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'msg' => 'Método no permitido.']);
    exit;
}
require_user_admin();
$tokenEnviado = (string)($_POST['csrf_usuarios'] ?? '');
$tokenSesion = (string)($_SESSION['csrf_usuarios'] ?? '');
if ($tokenSesion === '' || !hash_equals($tokenSesion, $tokenEnviado)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'msg' => 'El formulario expiró. Recarga la página.']);
    exit;
}

$me = me();
require_once __DIR__ . '/accesos_menu.php';
if (!am_puede($conn, (int)($me['id'] ?? 0), 'usuarios')) {
    http_response_code(403);
    exit('Acceso denegado.');
}


$miId   = (int)($me['id'] ?? 0);
$miRol  = (string)($me['rol'] ?? '');
$miPais = normalizar_pais_code_guardar((string)($me['pais_code'] ?? ''));
$miZona = trim((string)($me['zona'] ?? ''));


if (!in_array($miRol, ['super_admin', 'admin_zona'], true)) {
    json_out(false, 'No tienes permisos.');
}


$usuario     = trim((string)($_POST['usuario'] ?? ''));
$nombreCompleto = trim((string)($_POST['nombre_completo'] ?? ''));
$password    = (string)($_POST['password'] ?? '');
$rol         = trim((string)($_POST['rol'] ?? ''));
$paisCode    = normalizar_pais_code_guardar((string)($_POST['pais_code'] ?? ''));
$estado      = isset($_POST['estado']) ? (int)($_POST['estado']) : 1;
$postTiendas = $_POST['tiendas'] ?? [];


if ($usuario === '' || $nombreCompleto === '' || $password === '' || $rol === '' || $paisCode === '') {
    json_out(false, 'Completa todos los campos obligatorios.');
}


if (!preg_match('/^[\p{L}]+$/u', $usuario)) {
    json_out(false, 'El usuario solo puede contener letras.');
}


if (mb_strlen($nombreCompleto, 'UTF-8') < 3 || mb_strlen($nombreCompleto, 'UTF-8') > 120
    || !preg_match('/^[\p{L}][\p{L}\s.-]*$/u', $nombreCompleto)) {
    json_out(false, 'El nombre completo debe tener entre 3 y 120 caracteres y contener solo letras.');
}

if (mb_strlen($usuario) > 30) {
    json_out(false, 'El usuario no puede tener más de 30 caracteres.');
}


[$passwordValida, $passwordMensaje] = exdt_validar_password($password);
if (!$passwordValida) {
    json_out(false, $passwordMensaje);
}


$rolesValidos = ['super_admin', 'admin_zona', 'tienda'];

if ($rol === 'super_admin' && !am_es_propietario($conn, $miId)) {
    json_out(false, 'Solo el Propietario puede crear superadministradores.');
}

if (!in_array($rol, $rolesValidos, true)) {
    json_out(false, 'Rol inválido.');
}


$paisesValidos = ['HN', 'NI'];

if (!in_array($paisCode, $paisesValidos, true)) {
    json_out(false, 'País inválido.');
}


if ($miRol === 'admin_zona' && $rol !== 'tienda') {
    json_out(false, 'Un admin_zona solo puede crear usuarios de tienda.');
}

if ($miRol === 'admin_zona' && $paisCode !== $miPais) {
    json_out(false, 'Solo puedes crear usuarios de tu mismo país.');
}


$estado = ($estado === 1) ? 1 : 0;


$tiendas = [];

if (is_array($postTiendas)) {
    foreach ($postTiendas as $token) {
        $store = u_decode_store_token((string)$token);

        if (!$store || !is_array($store)) {
            continue;
        }

        $storePais = normalizar_pais_code_guardar((string)($store['pais_code'] ?? $store['pais'] ?? ''));
        $store['pais_code'] = $storePais;

        $tiendas[u_store_key_from_array($store)] = $store;
    }
}

$tiendas = array_values($tiendas);


if ($rol !== 'super_admin' && count($tiendas) === 0) {
    json_out(false, 'Debes asignar al menos una tienda.');
}

if ($rol === 'tienda' && count($tiendas) !== 1) {
    json_out(false, 'El rol tienda solo puede tener una tienda.');
}

if ($rol === 'super_admin' && count($tiendas) > 0) {
    json_out(false, 'El super_admin no necesita tiendas asignadas.');
}


foreach ($tiendas as $t) {
    $storePais = normalizar_pais_code_guardar((string)($t['pais_code'] ?? $t['pais'] ?? ''));

    if ($storePais !== $paisCode) {
        json_out(false, 'Todas las tiendas seleccionadas deben pertenecer al país elegido.');
    }
}


foreach ($tiendas as $t) {
    if (!u_sqlsrv_store_exists($sqlsrv_conn, $t)) {
        json_out(false, 'Una tienda seleccionada no existe o ya no es válida.');
    }
}


if ($miRol === 'admin_zona') {
    $mias = u_get_user_store_keys($conn, $miId);

    foreach ($tiendas as $t) {
        $storeKey  = u_store_key_from_array($t);
        $storePais = normalizar_pais_code_guardar((string)($t['pais_code'] ?? $t['pais'] ?? ''));
        $storeZona = strtoupper(trim((string)($t['zona'] ?? '')));
        $miZonaCmp = strtoupper(trim($miZona));

        if ($storePais !== $miPais) {
            json_out(false, 'Solo puedes asignar tiendas de tu mismo país.');
        }

        if ($miZonaCmp !== '' && $storeZona !== $miZonaCmp) {
            json_out(false, 'Solo puedes asignar tiendas de tu misma zona.');
        }

        if (!isset($mias[$storeKey])) {
            json_out(false, 'Solo puedes asignar tiendas que te pertenecen.');
        }
    }
}


$stmtDup = $conn->prepare("
    SELECT id 
    FROM usuarios 
    WHERE BINARY usuario = ? 
    LIMIT 1
");

if (!$stmtDup) {
    json_out(false, 'Error preparando validación usuario.', ['sql_error' => $conn->error]);
}

$stmtDup->bind_param("s", $usuario);

if (!$stmtDup->execute()) {
    $errDup = $stmtDup->error;
    $stmtDup->close();
    json_out(false, 'Error ejecutando validación usuario.', ['sql_error' => $errDup]);
}

$resDup = $stmtDup->get_result();

if ($resDup && $resDup->num_rows > 0) {
    $stmtDup->close();
    json_out(false, 'Ese usuario ya existe.');
}

$stmtDup->close();


if ($rol === 'tienda' && count($tiendas) === 1) {

    $t = $tiendas[0];

    $baseDatos  = strtoupper(trim((string)($t['base_datos'] ?? '')));
    $codalmacen = trim((string)($t['codalmacen'] ?? ''));

    $stmtTiendaDup = $conn->prepare("
        SELECT u.id
        FROM usuarios u
        INNER JOIN usuario_tienda ut
            ON ut.usuario_id = u.id
        WHERE u.rol = 'tienda'
          AND UPPER(TRIM(ut.base_datos)) = ?
          AND TRIM(ut.codalmacen) = ?
        LIMIT 1
    ");

    if (!$stmtTiendaDup) {
        json_out(false, 'Error preparando validación tienda.', ['sql_error' => $conn->error]);
    }

    $stmtTiendaDup->bind_param("ss", $baseDatos, $codalmacen);

    if (!$stmtTiendaDup->execute()) {
        $errTiendaDup = $stmtTiendaDup->error;
        $stmtTiendaDup->close();
        json_out(false, 'Error ejecutando validación tienda.', ['sql_error' => $errTiendaDup]);
    }

    $resTiendaDup = $stmtTiendaDup->get_result();

    if ($resTiendaDup && $resTiendaDup->num_rows > 0) {
        $stmtTiendaDup->close();
        json_out(false, 'Esta tienda ya tiene un usuario creado. No puedes crear otro usuario para la misma tienda.');
    }

    $stmtTiendaDup->close();
}


$hash = password_hash($password, PASSWORD_BCRYPT);

if ($hash === false) {
    json_out(false, 'No se pudo generar la contraseña segura.');
}


$conn->begin_transaction();

try {


    $stmt = $conn->prepare("
        INSERT INTO usuarios (
            usuario,
            nombre_completo,
            password_hash, 
            rol, 
            pais_code, 
            estado
        )
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        throw new RuntimeException('Error preparando insert usuarios: ' . $conn->error);
    }

    $stmt->bind_param("sssssi", $usuario, $nombreCompleto, $hash, $rol, $paisCode, $estado);

    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Error insertando usuario: ' . $err);
    }

    $stmt->close();


    $nuevoId = (int)$conn->insert_id;
    exdt_registrar_password_admin($conn, $nuevoId);


    if ($rol !== 'super_admin') {

        $stmtUT = $conn->prepare("
            INSERT INTO usuario_tienda (
                usuario_id, 
                pais, 
                base_datos, 
                zona, 
                codalmacen, 
                nombrealmacen
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if (!$stmtUT) {
            throw new RuntimeException('Error preparando insert usuario_tienda: ' . $conn->error);
        }

        foreach ($tiendas as $t) {
            $pais          = normalizar_pais_code_guardar((string)($t['pais'] ?? $t['pais_code'] ?? ''));
            $base_datos    = trim((string)($t['base_datos'] ?? ''));
            $zona          = trim((string)($t['zona'] ?? ''));
            $codalmacen    = trim((string)($t['codalmacen'] ?? ''));
            $nombrealmacen = trim((string)($t['nombrealmacen'] ?? ''));

            $stmtUT->bind_param(
                "isssss",
                $nuevoId,
                $pais,
                $base_datos,
                $zona,
                $codalmacen,
                $nombrealmacen
            );

            if (!$stmtUT->execute()) {
                $errUT = $stmtUT->error;
                $stmtUT->close();
                throw new RuntimeException('Error insertando tienda del usuario: ' . $errUT);
            }
        }

        $stmtUT->close();
    }


    $conn->commit();


    $descripcionAuditoria = 'Se creó el usuario: ' . $usuario .
        ' | Rol: ' . $rol .
        ' | País: ' . $paisCode;

    if ($rol === 'tienda' && !empty($tiendas)) {
        $t = $tiendas[0];
        $descripcionAuditoria .= ' | Tienda: ' . (string)($t['nombrealmacen'] ?? '');
    }


registrar_auditoria(
    'USUARIOS',
    'USUARIO_CREADO',
    $descripcionAuditoria,
    aud_region_label($paisCode),
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['zona'] ?? '') : '',
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['nombrealmacen'] ?? '') : '',
    ($rol === 'tienda' && !empty($tiendas)) ? (string)($tiendas[0]['codalmacen'] ?? '') : ''
);


    json_out(true, 'Usuario guardado correctamente.');

} catch (Throwable $e) {


    $conn->rollback();

    error_log('Error creando usuario: ' . $e->getMessage());
    json_out(false, 'No se pudo guardar el usuario. Revisa los datos o consulta el registro de errores.');
}