<?php
declare(strict_types=1);


header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');


if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');

    $https = !empty($_SERVER['HTTPS'])
        && strtolower((string) $_SERVER['HTTPS']) !== 'off';

    session_name('APP_EXHIBICION');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}


require_once __DIR__ . '/db.php';
require_once __DIR__ . '/password_security.php';
require_once __DIR__ . '/security_events.php';

function escapar_login(string $texto): string
{
    return htmlspecialchars($texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function pais_de_usuario(?string $codigo, ?string $paisTienda): array
{
    $codigo = strtoupper(trim((string) $codigo));
    $pais = trim((string) $paisTienda);

    if ($codigo === '' && strcasecmp($pais, 'Honduras') === 0) {
        $codigo = 'HN';
    } elseif ($codigo === '' && strcasecmp($pais, 'Nicaragua') === 0) {
        $codigo = 'NI';
    }

    if ($pais === '' && $codigo === 'HN') {
        $pais = 'Honduras';
    } elseif ($pais === '' && $codigo === 'NI') {
        $pais = 'Nicaragua';
    }

    return [$codigo, $pais];
}


function limite_login(string $identificador, int $maximo, string $accion): bool
{
    $carpeta = rtrim(sys_get_temp_dir(), '/\\')
        . DIRECTORY_SEPARATOR . 'exhibicion_login_limites';

    if (!is_dir($carpeta) && !@mkdir($carpeta, 0700, true) && !is_dir($carpeta)) {
        throw new RuntimeException('No se pudo preparar el control de intentos.');
    }

    $archivo = $carpeta . DIRECTORY_SEPARATOR
        . hash('sha256', $identificador) . '.json';

    $manejador = @fopen($archivo, 'c+');
    if ($manejador === false) {
        throw new RuntimeException('No se pudo abrir el control de intentos.');
    }

    try {
        if (!flock($manejador, LOCK_EX)) {
            throw new RuntimeException('No se pudo bloquear el contador.');
        }

        rewind($manejador);
        $datos = json_decode((string) stream_get_contents($manejador), true);
        $ahora = time();
        $inicio = (int) ($datos['inicio'] ?? $ahora);
        $intentos = (int) ($datos['intentos'] ?? 0);

        if ($inicio > $ahora || ($ahora - $inicio) >= 900) {
            $inicio = $ahora;
            $intentos = 0;
        }

        if ($accion === 'fallo') {
            $intentos++;
        } elseif ($accion === 'reiniciar') {
            $intentos = 0;
            $inicio = $ahora;
        }

        rewind($manejador);
        ftruncate($manejador, 0);
        $guardado = fwrite($manejador, (string) json_encode([
            'inicio' => $inicio,
            'intentos' => $intentos,
        ]));
        fflush($manejador);

        if ($guardado === false) {
            throw new RuntimeException('No se pudo guardar el control de intentos.');
        }

        return $intentos < $maximo;
    } finally {
        flock($manejador, LOCK_UN);
        fclose($manejador);
    }
}


if (!empty($_SESSION['usuario_id'])) {
    $inicio = (int) ($_SESSION['CREATED'] ?? 0);
    if ($inicio > 0 && (time() - $inicio) <= 86400) {
        header('Location: /exhibicion_DT/index.php');
        exit;
    }

    $_SESSION = [];
    session_regenerate_id(true);
}

$error = isset($_GET['expired'])
    ? 'Tu sesión expiró. Inicia sesión nuevamente.'
    : '';
$usuarioEscrito = '';


if (empty($_SESSION['csrf_login'])) {
    $_SESSION['csrf_login'] = bin2hex(random_bytes(32));
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $usuarioEscrito = trim((string) ($_POST['usuario'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $token = (string) ($_POST['csrf_login'] ?? '');

    if (!hash_equals((string) $_SESSION['csrf_login'], $token)) {
        $error = 'El formulario expiró. Actualiza la página e inténtalo de nuevo.';
    } elseif ($usuarioEscrito === '' || $password === '') {
        $error = 'Completa usuario y contraseña.';
    } elseif (!preg_match('/^[\p{L}\p{N}._-]{1,60}$/u', $usuarioEscrito)
        || strlen($password) > 255) {
        $error = 'Usuario o contraseña incorrectos.';
    } else {
        

        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'desconocida');
        $claveIp = 'ip|' . $ip;
        $claveUsuario = 'usuario|' . strtolower($usuarioEscrito);

        try {
            if (!limite_login($claveIp, 30, 'consultar')
                || !limite_login($claveUsuario, 3, 'consultar')) {
                $error = 'Demasiados intentos. Intenta nuevamente en 15 minutos.';
                exdt_registrar_evento('LOGIN_BLOQUEADO', $usuarioEscrito, $ip);
            } else {
                

                $consulta = $conn->prepare('
                    SELECT id, usuario, password_hash, rol, estado, pais_code, zona
                    FROM usuarios
                    WHERE BINARY usuario = ?
                    LIMIT 1
                ');
                $consulta->bind_param('s', $usuarioEscrito);
                $consulta->execute();
                $resultado = $consulta->get_result();
                $fila = $resultado ? $resultado->fetch_assoc() : null;
                $consulta->close();


                $hash = (string) ($fila['password_hash']
                    ?? '$2y$12$WEt6YJbTiA/EDWtLx.h/auO6rzfxn2veMurCapeq4TvcVtec22yQq');
                $claveCorrecta = password_verify($password, $hash);

                if (!$fila || (int) $fila['estado'] !== 1 || !$claveCorrecta) {
                    limite_login($claveIp, 30, 'fallo');
                    limite_login($claveUsuario, 3, 'fallo');
                    exdt_registrar_evento('LOGIN_FALLIDO', $usuarioEscrito, $ip);
                    $error = 'Usuario o contraseña incorrectos, o cuenta inactiva.';
                } else {
                    $id = (int) $fila['id'];
                    $rol = (string) $fila['rol'];
                    $paisTienda = '';
                    $zonaTienda = '';
                    $codigoTienda = '';
                    $nombreTienda = '';


                    if (in_array($rol, ['admin_zona', 'tienda'], true)) {
                        $tiendas = $conn->prepare('
                            SELECT pais, zona, codalmacen, nombrealmacen
                            FROM usuario_tienda
                            WHERE usuario_id = ?
                            ORDER BY id ASC
                            LIMIT 1
                        ');
                        $tiendas->bind_param('i', $id);
                        $tiendas->execute();
                        $resTienda = $tiendas->get_result();
                        $asignada = $resTienda ? $resTienda->fetch_assoc() : null;
                        $tiendas->close();

                        if ($asignada) {
                            $paisTienda = trim((string) $asignada['pais']);
                            $zonaTienda = trim((string) $asignada['zona']);
                            $codigoTienda = trim((string) $asignada['codalmacen']);
                            $nombreTienda = trim((string) $asignada['nombrealmacen']);
                        }
                    }

                    [$paisCodigo, $paisNombre] = pais_de_usuario(
                        (string) $fila['pais_code'], $paisTienda
                    );


                    session_regenerate_id(true);
                    $_SESSION = [];
                    $_SESSION['usuario_id'] = $id;
                    $_SESSION['usuario'] = (string) $fila['usuario'];
                    $_SESSION['rol'] = $rol;
                    $_SESSION['estado'] = (int) $fila['estado'];
                    $_SESSION['pais_code'] = $paisCodigo;
                    $_SESSION['pais'] = $paisNombre;
                    $_SESSION['CREATED'] = time();
                    $_SESSION['LAST_ACTIVITY'] = time();
                    $_SESSION['verificacion_cuenta'] = time();
                    $_SESSION['zona'] = $rol === 'tienda'
                        ? $zonaTienda
                        : (in_array($rol, ['super_admin', 'admin_zona'], true)
                            ? '' : (string) $fila['zona']);
                    $_SESSION['tienda'] = $rol === 'tienda' ? $nombreTienda : '';
                    $_SESSION['codalmacen'] = $rol === 'tienda' ? $codigoTienda : '';
                    $_SESSION['password_cambio_obligatorio'] = false; // Solo la administración renueva contraseñas.

                    limite_login($claveUsuario, 3, 'reiniciar');
                    unset($_SESSION['csrf_login']);
                    exdt_registrar_evento('LOGIN_CORRECTO', $usuarioEscrito, $ip);
                    header('Location: /exhibicion_DT/index.php');
                    exit;
                }
            }
        } catch (Throwable $e) {
            error_log('Exhibicion DT - Error de acceso: ' . $e->getMessage());
            $error = 'No se pudo verificar el acceso. Contacta al administrador.';
        }
    }
}
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Estandares DT</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#002b66">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css?v=<?= time(); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="/exhibicion_DT/faviconDT/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/exhibicion_DT/faviconDT/favicon-16x16.png">

</head>
<body>
    <div class="split-viewport">
        
        <section class="split-brand-panel">
            <div class="brand-overlay"></div>
            <div class="brand-content">
                <div class="brand-badge-pill">Sitio Oficial</div>
                <h1 class="brand-main-heading">Estandares De Exhibición</h1>
                <p class="brand-description">Aplicación centralizada para el control y seguimiento de exhibiciones.</p>
            </div>
            <div class="brand-copyright">
                © <?= date('Y') ?> Grupo MCC — Todos los derechos reservados.
            </div>
        </section>

        
        <main class="split-form-panel">
            <div class="form-container">
                <header class="form-header">
                    <div class="logo-wrapper">
                        <img src="/exhibicion_DT/img/DeTodo.png" alt="Grupo MCC" class="mcc-logo">
                    </div>
                    <h2 class="form-title">Bienvenido</h2>
                    <p class="form-subtitle">Ingresa tus credenciales para acceder</p>
                </header>

                <?php if ($error !== ''): ?>
                    <div class="alert alert-error" role="alert">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <line x1="12" y1="8" x2="12" y2="12"/>
                            <line x1="12" y1="16" x2="12.01" y2="16"/>
                        </svg>
                        <span><?= escapar_login($error) ?></span>
                    </div>
                <?php endif; ?>

                <form method="post" autocomplete="off" id="formLogin" class="login-fields-form">
                    <input type="hidden" name="csrf_login" value="<?= escapar_login($_SESSION['csrf_login']) ?>">
                    <div class="field-group">
                        <label for="usuario">Usuario</label>
                        <div class="input-relative">
                            <svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input
                                type="text"
                                id="usuario"
                                name="usuario"
                                placeholder="Tu usuario"
                                maxlength="30"
                                value="<?= escapar_login($_POST['usuario'] ?? '') ?>"
                                autocomplete="username"
                                required
                                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g,'')"
                            >
                        </div>
                    </div>

                    <div class="field-group">
                        <label for="password">Contraseña</label>
                        <div class="input-relative">
                            <svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                            </svg>
                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="••••••••"
                                maxlength="64"
                                autocomplete="current-password"
                                required
                            >
                            <button type="button" class="eye-button" id="btnTogglePassword" onclick="togglePassword()" aria-label="Mostrar u ocultar contraseña">
                                <svg id="iconEyeOpen" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                </svg>
                                <svg id="iconEyeClosed" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none;">
                                    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                                    <line x1="1" y1="1" x2="23" y2="23"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="button-stack">
                        <button class="btn-submit" type="submit">Ingresar</button>
                        <button class="btn-reset" type="reset" id="btnLimpiar">Limpiar</button>
                    </div>
                </form>
            </div>
        </main>
    </div>

    <script>
    function togglePassword() {
        const passwordInput = document.getElementById('password');
        const eyeOpenIcon = document.getElementById('iconEyeOpen');
        const eyeClosedIcon = document.getElementById('iconEyeClosed');

        if (!passwordInput) return;

        const isPasswordVisible = passwordInput.type === 'password';
        passwordInput.type = isPasswordVisible ? 'text' : 'password';

        if (eyeOpenIcon && eyeClosedIcon) {
            eyeOpenIcon.style.display = isPasswordVisible ? 'none' : 'block';
            eyeClosedIcon.style.display = isPasswordVisible ? 'block' : 'none';
        }
    }

    document.getElementById('btnLimpiar')?.addEventListener('click', function () {
        setTimeout(() => {
            const usernameInput = document.getElementById('usuario');
            const passwordInput = document.getElementById('password');
            const eyeOpenIcon = document.getElementById('iconEyeOpen');
            const eyeClosedIcon = document.getElementById('iconEyeClosed');

            if (usernameInput) usernameInput.value = '';
            if (passwordInput) {
                passwordInput.value = '';
                passwordInput.type = 'password';
            }

            if (eyeOpenIcon && eyeClosedIcon) {
                eyeOpenIcon.style.display = 'block';
                eyeClosedIcon.style.display = 'none';
            }

            usernameInput?.focus();
        }, 0);
    });

    document.addEventListener('contextmenu', function (event) {
        event.preventDefault();
    });

    window.addEventListener('keydown', function (event) {
        const tecla = event.key.toLowerCase();
        const atajoBloqueado = tecla === 'f12'
            || (event.ctrlKey && tecla === 'u')
            || (event.ctrlKey && event.shiftKey && tecla === 'i');

        if (atajoBloqueado) {
            event.preventDefault();
            event.stopPropagation();
        }
    }, true);
    </script>
</body>
</html>