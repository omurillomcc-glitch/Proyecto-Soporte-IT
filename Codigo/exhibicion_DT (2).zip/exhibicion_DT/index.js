/*
| Búsqueda de pantallas, menú adaptable, zoom, tema, acento y fullscreen.
*/
(function () {
    'use strict';

    /* Protección básica contra acciones accidentales o básicas del navegador.
       Esto no impide inspeccionar una aplicación web ni ver sus recursos desde
       herramientas externas. La seguridad real debe mantenerse en el servidor. */
    const contextMenuBlockedDocuments = new WeakSet();
    function blockContextMenu(targetDocument) {
        if (contextMenuBlockedDocuments.has(targetDocument)) return;
        contextMenuBlockedDocuments.add(targetDocument);
        targetDocument.addEventListener('contextmenu', function (event) {
            event.preventDefault();
        }, true);
    }

    blockContextMenu(document);
    document.querySelectorAll('iframe').forEach(function (frame) {
        function blockFrameContextMenu() {
            if (frame.contentDocument) blockContextMenu(frame.contentDocument);
        }
        frame.addEventListener('load', blockFrameContextMenu);
        blockFrameContextMenu();
    });

    document.addEventListener('keydown', function (event) {
        const key = event.key.toLowerCase();
        const preventBrowserShortcut =
            event.key === 'F12' ||
            ((event.ctrlKey || event.metaKey) && event.shiftKey && ['i', 'j', 'c', 'k'].includes(key)) ||
            ((event.ctrlKey || event.metaKey) && ['u', 's'].includes(key));

        if (preventBrowserShortcut) event.preventDefault();
    });

    document.querySelectorAll('img').forEach(function (image) {
        image.setAttribute('draggable', 'false');
    });

    const appFrame = document.querySelector('.metis-frame');
    const sidebar = document.getElementById('metisSidebar');
    const sidebarScrim = document.getElementById('metisScrim');
    const mainContent = document.getElementById('metisContent');
    const searchInput = document.getElementById('metisSearch');
    const searchResults = document.getElementById('metisSearchResults');
    const themeButton = document.getElementById('metisTheme');
    const zoomResetButton = document.getElementById('metisZoomReset');

    if (!appFrame || !sidebar || !mainContent) return;

    function safeGet(key, fallback) {
        try { return localStorage.getItem(key) || fallback; } catch (_) { return fallback; }
    }
    function safeSet(key, value) {
        try { localStorage.setItem(key, value); } catch (_) { /* Preferencias opcionales */ }
    }

    function setSidebarOpen(open) {
        if (window.matchMedia('(max-width: 900px)').matches) {
            appFrame.classList.toggle('sidebar-open', open);
            sidebarScrim.hidden = !open;
        } else {
            appFrame.classList.toggle('sidebar-collapsed', !open);
        }
    }

    document.getElementById('metisMenuToggle')?.addEventListener('click', function () {
        const isMobile = window.matchMedia('(max-width: 900px)').matches;
        setSidebarOpen(isMobile ? !appFrame.classList.contains('sidebar-open') : appFrame.classList.contains('sidebar-collapsed'));
    });
    document.getElementById('metisClose')?.addEventListener('click', () => setSidebarOpen(false));
    sidebarScrim?.addEventListener('click', () => setSidebarOpen(false));
    window.addEventListener('resize', function () {
        if (!window.matchMedia('(max-width: 900px)').matches) {
            appFrame.classList.remove('sidebar-open');
            sidebarScrim.hidden = true;
        }
    });

    /* Buscar solo pantallas a las que el menú permite acceder. */
    const searchableLinks = Array.from(sidebar.querySelectorAll('a[data-search]'));
    function performSearch() {
        if (!searchInput || !searchResults) return;
        const searchTerm = searchInput.value.trim().toLocaleLowerCase('es');
        searchResults.replaceChildren();
        if (!searchTerm) { searchResults.hidden = true; return; }

        const matchingLinks = searchableLinks.filter(link => {
            const linkSearchText = (link.textContent || '') + ' ' + (link.dataset.search || '');
            return linkSearchText.toLocaleLowerCase('es').includes(searchTerm);
        });

        for (const link of matchingLinks.slice(0, 8)) {
            const resultLink = document.createElement('a');
            resultLink.href = link.href;
            resultLink.textContent = link.textContent.trim();
            searchResults.appendChild(resultLink);
        }
        if (matchingLinks.length === 0) {
            const noResultsMessage = document.createElement('p');
            noResultsMessage.textContent = 'No se encontró una pantalla con ese nombre.';
            searchResults.appendChild(noResultsMessage);
        }
        searchResults.hidden = false;
    }
    searchInput?.addEventListener('input', performSearch);
    searchInput?.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            const firstSearchResult = searchResults?.querySelector('a');
            if (firstSearchResult) { event.preventDefault(); window.location.assign(firstSearchResult.href); }
        }
        if (event.key === 'Escape') { searchResults.hidden = true; searchInput.blur(); }
    });
    document.addEventListener('click', function (event) {
        if (!event.target.closest('.metis-search-wrap') && searchResults) searchResults.hidden = true;
    });
    document.addEventListener('keydown', function (event) {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
            event.preventDefault(); searchInput?.focus(); searchInput?.select();
        }
        if (event.key === 'Escape') setSidebarOpen(false);
    });

    /* Zoom únicamente del área central (no cambia el zoom del navegador). */
    const minZoomPercent = 80;
    const maxZoomPercent = 120;
    function applyZoom(percent) {
        const zoomPercent = Math.min(maxZoomPercent, Math.max(minZoomPercent, percent));
        mainContent.style.zoom = String(zoomPercent / 100);
        if (zoomResetButton) zoomResetButton.textContent = zoomPercent + '%';
        safeSet('exdt_metis_zoom', String(zoomPercent));
    }
    applyZoom(parseInt(safeGet('exdt_metis_zoom', '100'), 10) || 100);
    document.getElementById('metisZoomOut')?.addEventListener('click', function () {
        applyZoom((parseInt(zoomResetButton.textContent, 10) || 100) - 10);
    });
    document.getElementById('metisZoomIn')?.addEventListener('click', function () {
        applyZoom((parseInt(zoomResetButton.textContent, 10) || 100) + 10);
    });
    zoomResetButton?.addEventListener('click', () => applyZoom(100));

    /* Cambiar modo claro/oscuro sin alterar módulos ni bases de datos. */
    function applyTheme(mode) {
        const themeMode = mode === 'dark' ? 'dark' : 'light';
        document.documentElement.dataset.bsTheme = themeMode;
        const logo = document.querySelector('.metis-logo');
        if (logo) {
            logo.src = themeMode === 'dark'
                ? '/exhibicion_DT/img/DeTodo-dark.png'
                : '/exhibicion_DT/img/DeTodo.png';
        }
        const themeIcon = themeButton?.querySelector('i');
        if (themeIcon) themeIcon.className = themeMode === 'dark' ? 'bi bi-sun' : 'bi bi-moon';
        safeSet('exdt_metis_theme', themeMode);
    }
    applyTheme(safeGet('exdt_metis_theme', 'light'));
    themeButton?.addEventListener('click', function () {
        applyTheme(document.documentElement.dataset.bsTheme === 'dark' ? 'light' : 'dark');
    });

    function applyAccent(accent) {
        const selectedAccent = ['blue', 'green', 'purple'].includes(accent) ? accent : 'blue';
        document.documentElement.dataset.metisAccent = selectedAccent;
        safeSet('exdt_metis_accent', selectedAccent);
    }
    applyAccent(safeGet('exdt_metis_accent', 'blue'));
    document.querySelectorAll('.metis-color-choice').forEach(function (button) {
        button.addEventListener('click', () => applyAccent(button.dataset.color));
    });

    /* Pantalla completa solo cuando el navegador permite esta función. */
    document.getElementById('metisFullscreen')?.addEventListener('click', async function () {
        try {
            if (document.fullscreenElement) await document.exitFullscreen();
            else await document.documentElement.requestFullscreen();
        } catch (error) {
            console.warn('No fue posible cambiar a pantalla completa.', error);
        }
    });
})();

/* Ajustar altura de Cobertura al cambiar de listado, edición o importación. */
document.addEventListener('DOMContentLoaded', function () {
    const coverageFrame = document.getElementById('metisCoberturaFrame');
    if (!coverageFrame) return;

    let resizeObserver = null;

    function ajustarAltura() {
        try {
            const frameDocument = coverageFrame.contentDocument;
            if (!frameDocument || !frameDocument.body) return;
            const frameBody = frameDocument.body;
            const frameHeight = Math.max(
                frameBody.scrollHeight,
                frameDocument.documentElement.scrollHeight,
                540
            );
            coverageFrame.style.height = (frameHeight + 12) + 'px';
        } catch (error) {
            coverageFrame.style.height = '850px';
        }
    }

    coverageFrame.addEventListener('load', function () {
        if (resizeObserver) resizeObserver.disconnect();
        ajustarAltura();
        try {
            if (coverageFrame.contentDocument && coverageFrame.contentDocument.body && 'ResizeObserver' in window) {
                resizeObserver = new ResizeObserver(ajustarAltura);
                resizeObserver.observe(coverageFrame.contentDocument.body);
            }
        } catch (_) { }
    });
    window.addEventListener('resize', ajustarAltura);
});

/* INYECCIÓN AUTOMÁTICA DEL FOOTER CENTRADO */
document.addEventListener('DOMContentLoaded', function () {
    const workspace = document.querySelector('.metis-workspace');
    if (workspace) {
        const footer = document.createElement('footer');
        footer.className = 'metis-footer';
        footer.innerHTML = `© ${new Date().getFullYear()} GRUPO MCC`;
        workspace.appendChild(footer);
    }
});
