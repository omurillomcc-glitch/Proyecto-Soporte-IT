<?php
declare(strict_types=1);


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}


$raiz = dirname(__DIR__, 2);
require_once $raiz . '/controlusuarios/db.php';
require_once $raiz . '/controlusuarios/auth.php';
require_login();

/* Obtiene la información del usuario autenticado actualmente y su rol */
$usuarioActual = me();
$rolActual = (string)($usuarioActual['rol'] ?? '');

/* Permiso de Bloqueo General validado en el servidor para restringir accesos no autorizados */
require_module_access('bloqueo');

/* Extrae el código del país del usuario y determina si corresponde a Nicaragua o Honduras por defecto */
$codigoPais = strtoupper(trim((string)($usuarioActual['pais_code'] ?? '')));
$paisSesion = in_array($codigoPais, ['NI', 'NICARAGUA'], true) ? 'NICARAGUA' : 'HONDURAS';

/* Requiere e incluye la conexión dedicada a SQL Server para el módulo de exhibición */
require_once $raiz . '/exhibiciontotal/conexion_exhibicion.php';
if (!isset($sqlsrv_conn_exhibicion) || $sqlsrv_conn_exhibicion === false) {
    http_response_code(503);
    exit('Conexión SQL Server no disponible.');
}

/* Genera un token CSRF seguro si aún no se encuentra establecido en la sesión */
if (empty($_SESSION['rcp_csrf'])) {
 
$_SESSION['rcp_csrf'] = bin2hex(random_bytes(32));
}

session_write_close();

/* Compatibilidad con instalaciones de PHP que no cuentan con la extensión mbstring instalada */
function rcp_longitud_texto(string $texto): int
{
    return function_exists('mb_strlen') ? mb_strlen($texto, 'UTF-8') : strlen($texto);
}

/* Convierte texto a mayúsculas soportando UTF-8 si mbstring está disponible, de lo contrario usa la función estándar */
function rcp_mayusculas(string $texto): string
{
    return function_exists('mb_strtoupper') ? mb_strtoupper($texto, 'UTF-8') : strtoupper($texto);
}

/* Carga el archivo  que contiene las funciones de consulta y manipulación de datos */
require_once __DIR__ . '/repo.php';

/* Valida y retorna la región o país seleccionado, verificando permisos si el usuario no es propietario */
function rcp_pais(string $solicitado): string
{
    global $paisSesion;
    $solicitado = strtoupper(trim($solicitado));
    $paisElegido = in_array($solicitado, ['HONDURAS', 'NICARAGUA'], true)
        ? $solicitado : $paisSesion;
    require_once $GLOBALS['raiz'] . '/controlusuarios/accesos_menu.php';
    $conexion = $GLOBALS['conn'] ?? null;
    $id = (int)($_SESSION['usuario_id'] ?? 0);
    $esPropietario = $conexion instanceof mysqli && am_es_propietario($conexion, $id);
    if (!$esPropietario && $paisElegido !== $paisSesion) {
        http_response_code(403);
        throw new InvalidArgumentException('La región solicitada no está autorizada.');
    }
    return $paisElegido;
}

/* Captura los errores devueltos por SQL Server, los registra en el log del sistema y lanza una excepción genérica */
function rcp_error_sql(string $etapa): never
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);
    $detalle = is_array($errores) ? json_encode($errores, JSON_UNESCAPED_UNICODE) : 'Sin detalle';
    error_log('RCP ' . $etapa . ': ' . $detalle);
    throw new RuntimeException('No se pudo completar la operación en SQL Server.');
}

/* Ejecuta una consulta SQL en SQL Server utilizando parámetros y maneja los errores mediante rcp_error_sql si falla */
function rcp_ejecutar($conexion, string $sql, array $params = [])
{
    $consulta = sqlsrv_query($conexion, $sql, $params);
    if ($consulta === false) {
        rcp_error_sql('consulta');
    }
    return $consulta;
}

/* Valida que un valor de texto o numérico cumpla con los límites de longitud permitidos y no contenga caracteres inválidos o de control */
function rcp_validar_texto(mixed $valor, int $limite, string $campo): string
{
    if (!is_string($valor) && !is_numeric($valor)) {
        throw new InvalidArgumentException("El campo {$campo} no es válido.");
    }
    $valor = trim((string)$valor);
    if ($valor === '' || rcp_longitud_texto($valor) > $limite) {
        throw new InvalidArgumentException("Revise el campo {$campo}.");
    }
    if (preg_match('/[\x00-\x1F\x7F]/u', $valor)) {
        throw new InvalidArgumentException("El campo {$campo} contiene caracteres no permitidos.");
    }
    return $valor;
}