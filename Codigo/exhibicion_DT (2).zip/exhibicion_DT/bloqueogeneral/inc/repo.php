<?php
declare(strict_types=1);

/* Definición de la tabla principal y la compañía por defecto para los bloqueos */
const RCP_TABLA = '[vistasMCC].[dbo].[TB_DT_RCP_ARTICULOBLOQUEOGENERAL]';
const RCP_COMPANIA = 'DETODO';

/* 
 
  La base cambia según el país y nunca proviene directamente del navegador.
 */
function rcp_base_articulos(string $pais): string
{
    return $pais === 'NICARAGUA' ? '[ACANICARAGUA2]' : '[DETODO]';
}

/* 
  Normaliza una columna o expresión para consultas SQL, aplicando TRIM, 
  conversión a VARCHAR y COLLATE DATABASE_DEFAULT para evitar conflictos de collation.
 */
function rcp_clave_sql(string $alias): string
{
    return "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$alias}))) COLLATE DATABASE_DEFAULT";
}

function rcp_plu_variantes_sql(string $columna, string $pais): string
{
    $plu = "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$columna})))";
    $sinPais = "CASE WHEN UPPER(RIGHT({$plu}, 2)) IN ('HN', 'NI')
        THEN LEFT({$plu}, LEN({$plu}) - 2) ELSE {$plu} END";
    $sinCeros = "CONVERT(VARCHAR(20), TRY_CONVERT(DECIMAL(20, 0), {$sinPais}))";
    $relleno = "CASE WHEN TRY_CONVERT(DECIMAL(20, 0), {$sinPais}) IS NOT NULL
            AND LEN({$sinPais}) <= 12
        THEN RIGHT('000000000000' + {$sinPais}, 12) END";
    $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
    return "({$plu} COLLATE DATABASE_DEFAULT, {$sinPais} COLLATE DATABASE_DEFAULT,
        {$sinCeros} COLLATE DATABASE_DEFAULT, {$relleno} COLLATE DATABASE_DEFAULT,
        ({$sinPais} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$sinCeros} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$relleno} + '{$sufijo}') COLLATE DATABASE_DEFAULT)";
}

function rcp_plu_candidatos(string $plu, string $pais): array
{
    $plu = trim($plu);
    $base = preg_replace('/(?:HN|NI)$/i', '', $plu) ?? $plu;
    $candidatos = [$plu, $base];
    if ($base !== '' && ctype_digit($base) && strlen($base) <= 12) {
        $sinCeros = ltrim($base, '0') ?: '0';
        $relleno = str_pad($base, 12, '0', STR_PAD_LEFT);
        $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
        array_push($candidatos, $sinCeros, $relleno,
            $base . $sufijo, $sinCeros . $sufijo, $relleno . $sufijo);
    }
    return array_values(array_unique($candidatos));
}


function rcp_sql_bloqueos(): string
{
    $pluSql = rcp_clave_sql('B.vPlu');
    $refSql = rcp_clave_sql('B.vReferencia');
    return "
        WITH Bloqueos AS (
            SELECT
                B.vIdPais, B.vIdCompany,
                {$pluSql} AS vPlu,
                {$refSql} AS vReferencia,
                MIN(B.FechaRegistro) AS FechaRegistro,
                COUNT_BIG(*) AS cantidadOriginal
            FROM " . RCP_TABLA . " B
            WHERE B.vIdPais = ? AND B.vIdCompany = ?
            GROUP BY B.vIdPais, B.vIdCompany, {$pluSql}, {$refSql}
        )
    ";
}

function rcp_sql_catalogo_apply(string $pais, string $alias = 'B'): string
{
    $base = rcp_base_articulos($pais);
    return "
        OUTER APPLY (
            SELECT TOP (1)
                CONVERT(VARCHAR(100), A.CODARTICULO) AS CODARTICULO,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS DESCRIPCION,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), D.DESCRIPCION))) AS DEPARTAMENTO,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), SC.DESCRIPCION))) AS SECCION,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), F.DESCRIPCION))) AS FAMILIA
            FROM {$base}.dbo.ARTICULOS A
            INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
                ON CL.CODARTICULO = A.CODARTICULO
            LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
            LEFT JOIN {$base}.dbo.SECCIONES SC
                ON SC.NUMDPTO = A.DPTO AND SC.NUMSECCION = A.SECCION
            LEFT JOIN {$base}.dbo.FAMILIAS F
                ON F.NUMDPTO = A.DPTO AND F.NUMSECCION = A.SECCION
                AND F.NUMFAMILIA = A.FAMILIA
            WHERE CL.PLU = {$alias}.vPlu
            ORDER BY CASE
                    WHEN A.REFPROVEEDOR = {$alias}.vReferencia COLLATE DATABASE_DEFAULT THEN 0
                    ELSE 1
                END,
                CASE WHEN A.DESCATALOGADO = 'F' THEN 0 ELSE 1 END,
                A.CODARTICULO
        ) P
        OUTER APPLY (
            SELECT TOP (1)
                CONVERT(VARCHAR(100), A.CODARTICULO) AS CODARTICULO,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS DESCRIPCION,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), D.DESCRIPCION))) AS DEPARTAMENTO,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), SC.DESCRIPCION))) AS SECCION,
                LTRIM(RTRIM(CONVERT(NVARCHAR(255), F.DESCRIPCION))) AS FAMILIA
            FROM {$base}.dbo.ARTICULOS A
            LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
            LEFT JOIN {$base}.dbo.SECCIONES SC
                ON SC.NUMDPTO = A.DPTO AND SC.NUMSECCION = A.SECCION
            LEFT JOIN {$base}.dbo.FAMILIAS F
                ON F.NUMDPTO = A.DPTO AND F.NUMSECCION = A.SECCION
                AND F.NUMFAMILIA = A.FAMILIA
            WHERE (P.CODARTICULO IS NULL OR P.FAMILIA IS NULL)
              AND A.REFPROVEEDOR = {$alias}.vReferencia COLLATE DATABASE_DEFAULT
            ORDER BY CASE WHEN A.DESCATALOGADO = 'F' THEN 0 ELSE 1 END,
                A.CODARTICULO
        ) R
    ";
}

/* Genera los datos completos para listados y filtros que dependen del catálogo. */
function rcp_sql_datos(string $pais): string
{
    return rcp_sql_bloqueos() . ",
        Datos AS (
            SELECT
                B.vIdPais AS pais, B.vIdCompany AS compania,
                B.vPlu AS plu, B.vReferencia AS referencia,
                CONVERT(VARCHAR(10), B.FechaRegistro, 23) AS fecha,
                B.cantidadOriginal AS repetidosOrigen,
                COALESCE(P.CODARTICULO, R.CODARTICULO) AS codarticulo,
                COALESCE(R.DESCRIPCION, P.DESCRIPCION) AS descripcion,
                COALESCE(R.DEPARTAMENTO, P.DEPARTAMENTO) AS departamento,
                COALESCE(R.SECCION, P.SECCION) AS seccion,
                COALESCE(R.FAMILIA, P.FAMILIA) AS familia
            FROM Bloqueos B
            " . rcp_sql_catalogo_apply($pais) . "
        )
    ";
}

/* Define el mapeo de los nombres de columnas permitidos para los filtros del grid. */
function rcp_columnas_filtro(): array
{
    return [
        'plu' => 'D.plu', 'referencia' => 'D.referencia',
        'descripcion' => 'D.descripcion', 'departamento' => 'D.departamento',
        'seccion' => 'D.seccion', 'familia' => 'D.familia',
        'fecha' => 'D.fecha'
    ];
}

/* 

 Al abrir una columna se conservan los filtros de las demás, omitiendo el propio.
 */
function rcp_sql_filtros(array $filtros, array &$params, string $omitir = ''): string
{
    $condiciones = '';
    foreach (rcp_columnas_filtro() as $campo => $columna) {
        if ($campo === $omitir) {
            continue;
        }
        $valor = trim((string)($filtros[$campo] ?? ''));
        if ($valor === '') {
            continue;
        }
        if (rcp_longitud_texto($valor) > 1500) {
            throw new InvalidArgumentException('El filtro supera el tamaño permitido.');
        }
        $expresion = "LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(255), {$columna}), N''))) COLLATE DATABASE_DEFAULT";
        if (str_starts_with($valor, '__LIKE__')) {
            $buscado = trim(substr($valor, 8));
            if ($buscado !== '') {
                $condiciones .= " AND {$expresion} LIKE ? COLLATE DATABASE_DEFAULT";
                $params[] = '%' . $buscado . '%';
            }
            continue;
        }
        $valores = array_values(array_unique(array_filter(array_map('trim', explode('||', $valor)), 'strlen')));
        if (count($valores) > 60) {
            throw new InvalidArgumentException('Se seleccionaron demasiadas opciones del filtro.');
        }
        if ($valores) {
            $marcadores = implode(', ', array_fill(0, count($valores), '?'));
            $condiciones .= " AND {$expresion} IN ({$marcadores})";
            array_push($params, ...$valores);
        }
    }
    return $condiciones;
}

/* 
 * Obtiene el listado paginado de registros bloqueados aplicando filtros y ordenamiento.
 */
function rcp_listado($conexion, string $pais, int $pagina, int $porPagina, array $filtros = [], string $ordenCampo = 'fecha', string $ordenDir = 'desc'): array
{
    $pagina = max(1, $pagina);
    $porPagina = in_array($porPagina, [50, 100, 250, 500, 1000], true) ? $porPagina : 50;
    $offset = ($pagina - 1) * $porPagina;

    $columnas = rcp_columnas_filtro();
    $hayFiltros = false;
    foreach ($columnas as $campo => $_) {
        if (trim((string)($filtros[$campo] ?? '')) !== '') {
            $hayFiltros = true;
            break;
        }
    }

    if ($ordenCampo !== 'numero' && !isset($columnas[$ordenCampo])) {
        $ordenCampo = 'fecha';
    }
    $direccion = strtolower($ordenDir) === 'asc' ? 'ASC' : 'DESC';
    $optimizarPagina = !$hayFiltros && $ordenCampo === 'fecha';
    if ($optimizarPagina) {
        $params = [$pais, RCP_COMPANIA, $offset, $porPagina];
        $sql = rcp_sql_bloqueos() . ",
            Pagina AS (
                SELECT B.*, COUNT_BIG(*) OVER() AS totalFiltrado
                FROM Bloqueos B
                ORDER BY B.FechaRegistro {$direccion},
                    B.vPlu COLLATE DATABASE_DEFAULT ASC,
                    B.vReferencia COLLATE DATABASE_DEFAULT ASC
                OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
            ),
            Datos AS (
                SELECT
                    B.vIdPais AS pais, B.vIdCompany AS compania,
                    B.vPlu AS plu, B.vReferencia AS referencia,
                    CONVERT(VARCHAR(10), B.FechaRegistro, 23) AS fecha,
                    B.cantidadOriginal AS repetidosOrigen,
                    B.totalFiltrado,
                    COALESCE(P.CODARTICULO, R.CODARTICULO) AS codarticulo,
                    COALESCE(R.DESCRIPCION, P.DESCRIPCION) AS descripcion,
                    COALESCE(R.DEPARTAMENTO, P.DEPARTAMENTO) AS departamento,
                    COALESCE(R.SECCION, P.SECCION) AS seccion,
                    COALESCE(R.FAMILIA, P.FAMILIA) AS familia
                FROM Pagina B
                " . rcp_sql_catalogo_apply($pais) . "
            )
            SELECT D.*
            FROM Datos D
            ORDER BY CONVERT(NVARCHAR(255), D.fecha) COLLATE DATABASE_DEFAULT {$direccion},
                D.plu ASC, D.referencia ASC
        ";
    } else {
        /* Los filtros/órdenes de catálogo deben calcularse antes de paginar. */
        $params = [$pais, RCP_COMPANIA];
        $sql = rcp_sql_datos($pais) . "
            SELECT D.*, COUNT_BIG(*) OVER() AS totalFiltrado
            FROM Datos D
            WHERE 1 = 1
        ";
        $sql .= rcp_sql_filtros($filtros, $params);

        if ($ordenCampo === 'numero' || $ordenCampo === 'plu') {
            $prefijo = "LEFT(D.plu, PATINDEX('%[^0-9]%', D.plu + 'X') - 1)";
            $numero = "TRY_CONVERT(DECIMAL(38, 0), {$prefijo})";
            $sql .= " ORDER BY CASE WHEN {$numero} IS NULL THEN 1 ELSE 0 END ASC,
                {$numero} {$direccion}, D.plu COLLATE DATABASE_DEFAULT {$direccion},
                D.referencia COLLATE DATABASE_DEFAULT ASC";
        } else {
            $campoOrden = $columnas[$ordenCampo];
            $sql .= " ORDER BY CONVERT(NVARCHAR(255), {$campoOrden}) COLLATE DATABASE_DEFAULT {$direccion},
                D.plu ASC, D.referencia ASC";
        }

        $sql .= " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        $params[] = $offset;
        $params[] = $porPagina;
    }

    $stmt = rcp_ejecutar($conexion, $sql, $params);
    $filas = [];
    $total = 0;
    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $total = (int)($fila['totalFiltrado'] ?? 0);
        unset($fila['totalFiltrado']);
        $filas[] = $fila;
    }
    sqlsrv_free_stmt($stmt);
    return ['rows' => $filas, 'total' => $total, 'page' => $pagina,
        'per' => $porPagina, 'filtered' => $hayFiltros];
}

/* 
  Obtiene los valores únicos disponibles para un campo específico de los filtros.
 Todas las opciones provienen del listado completo y no de una página aislada.
 */
function rcp_valores_filtro($conexion, string $pais, string $campo, string $busqueda = '', array $filtros = []): array
{
    $columnas = rcp_columnas_filtro();
    if (!isset($columnas[$campo])) {
        throw new InvalidArgumentException('Columna de filtro no permitida.');
    }
    $busqueda = trim($busqueda);
    if (rcp_longitud_texto($busqueda) > 100) {
        throw new InvalidArgumentException('La búsqueda del filtro es demasiado larga.');
    }

    $params = [$pais, RCP_COMPANIA];
    $expresion = "LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(255), {$columnas[$campo]}), N''))) COLLATE DATABASE_DEFAULT";

    $camposCatalogo = ['descripcion', 'departamento', 'seccion', 'familia'];
    $hayFiltroCatalogo = false;
    foreach ($camposCatalogo as $campoCatalogo) {
        if ($campoCatalogo !== $campo && trim((string)($filtros[$campoCatalogo] ?? '')) !== '') {
            $hayFiltroCatalogo = true;
            break;
        }
    }

    if (in_array($campo, ['plu', 'referencia', 'fecha'], true) && !$hayFiltroCatalogo) {
        $sql = rcp_sql_bloqueos() . ",
            Valores AS (
                SELECT
                    B.vPlu AS plu,
                    B.vReferencia AS referencia,
                    CONVERT(VARCHAR(10), B.FechaRegistro, 23) AS fecha
                FROM Bloqueos B
            )
            SELECT DISTINCT TOP (301) {$expresion} AS valor
            FROM Valores D
            WHERE {$expresion} <> N''
        ";
    } else {
        $sql = rcp_sql_datos($pais) . "
            SELECT DISTINCT TOP (301) {$expresion} AS valor
            FROM Datos D
            WHERE {$expresion} <> N''
        ";
    }
    $sql .= rcp_sql_filtros($filtros, $params, $campo);
    if ($busqueda !== '') {
        $sql .= " AND {$expresion} LIKE ? COLLATE DATABASE_DEFAULT";
        $params[] = '%' . $busqueda . '%';
    }
    $sql .= " ORDER BY valor ASC";

    $stmt = rcp_ejecutar($conexion, $sql, $params);
    $valores = [];
    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $valores[] = (string)($fila['valor'] ?? '');
    }
    sqlsrv_free_stmt($stmt);

    $hayMas = count($valores) > 300;
    if ($hayMas) {
        array_pop($valores);
    }

    return ['values' => $valores, 'has_more' => $hayMas];
}

/* 
 Busca productos activos dentro del catálogo del país que coincidan con un texto de búsqueda,
 comprobando además si ya se encuentran bloqueados en la tabla general.
 */
function rcp_buscar_productos($conexion, string $pais, string $texto): array
{
    $base = rcp_base_articulos($pais);
    $texto = rcp_validar_texto($texto, 100, 'búsqueda');
    $sql = "
        SELECT TOP (20)
            CONVERT(VARCHAR(100), CL.PLU) AS plu,
            CONVERT(VARCHAR(100), A.REFPROVEEDOR) AS referencia,
            CONVERT(VARCHAR(100), A.CODARTICULO) AS codarticulo,
            A.DESCRIPCION AS descripcion,
            D.DESCRIPCION AS departamento,
            SC.DESCRIPCION AS seccion,
            F.DESCRIPCION AS familia,
            CASE WHEN EXISTS (
                SELECT 1 FROM " . RCP_TABLA . " B
                WHERE B.vIdPais = ? AND B.vIdCompany = ?
                  AND " . rcp_clave_sql('B.vPlu') . " = " . rcp_clave_sql('CL.PLU') . "
                  AND " . rcp_clave_sql('B.vReferencia') . " = " . rcp_clave_sql('A.REFPROVEEDOR') . "
            ) THEN 1 ELSE 0 END AS bloqueado
        FROM {$base}.dbo.ARTICULOS A
        INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
            ON CL.CODARTICULO = A.CODARTICULO
        LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
        LEFT JOIN {$base}.dbo.SECCIONES SC
            ON SC.NUMDPTO = A.DPTO AND SC.NUMSECCION = A.SECCION
        LEFT JOIN {$base}.dbo.FAMILIAS F
            ON F.NUMDPTO = A.DPTO
            AND F.NUMSECCION = A.SECCION AND F.NUMFAMILIA = A.FAMILIA
        WHERE A.DESCATALOGADO = 'F'
          AND UPPER(LTRIM(RTRIM(ISNULL(A.DESCRIPCION, '')))) <> 'PACKING ARTICULO'
          AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
          AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%ARTICULOS DE GASTO%'
          AND UPPER(LTRIM(RTRIM(ISNULL(SC.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
          AND UPPER(LTRIM(RTRIM(ISNULL(F.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'
          AND (
            " . rcp_clave_sql('CL.PLU') . " LIKE ?
            OR " . rcp_clave_sql('A.REFPROVEEDOR') . " LIKE ?
          )
        ORDER BY A.CODARTICULO
    ";
    $stmt = rcp_ejecutar($conexion, $sql, [$pais, RCP_COMPANIA, $texto . '%', $texto . '%']);
    $filas = [];
    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $filas[] = $fila;
    }
    sqlsrv_free_stmt($stmt);
    return $filas;
}

/* Obtiene el listado de tiendas (almacenes numéricos) que poseen stock de un artículo en específico. */
function rcp_tiendas($conexion, string $pais, string $codigoArticulo): array
{
    $base = rcp_base_articulos($pais);
    $codigoArticulo = rcp_validar_texto($codigoArticulo, 100, 'código de artículo');
    $sql = "
        SELECT DISTINCT TOP (100)
            CONVERT(VARCHAR(100), S.CODALMACEN) AS codigo,
            ALM.NOMBREALMACEN AS tienda
        FROM {$base}.dbo.STOCKS S
        LEFT JOIN {$base}.dbo.ALMACEN ALM ON ALM.CODALMACEN = S.CODALMACEN
        WHERE " . rcp_clave_sql('S.CODARTICULO') . " = ? COLLATE DATABASE_DEFAULT
          AND LTRIM(RTRIM(CONVERT(VARCHAR(100), S.CODALMACEN))) LIKE '[0-9][0-9]'
          -- AQUI AGREGAS LAS REGLAS PARA EXCLUIR LAS TIENDAS QUE NO SE DESEAN INCLUIR EN EL LISTADO:
          AND UPPER(LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, '')))) NOT LIKE '%NO USRA%'
          AND UPPER(LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, '')))) NOT LIKE '%ACA JOE%'
          AND UPPER(LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, '')))) NOT LIKE '%ALMACEN%'
          AND UPPER(LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, '')))) NOT LIKE '%MERCADEO%'
          AND UPPER(LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN, '')))) NOT LIKE '%OPERACIONES%'
        ORDER BY codigo
    ";
    $stmt = rcp_ejecutar($conexion, $sql, [$codigoArticulo]);
    $filas = [];
    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $filas[] = $fila;
    }
    sqlsrv_free_stmt($stmt);
    return $filas;
}

/* Verifica si un producto existe y está vigente (no descatalogado) en  la base del país. */
function rcp_producto_existe($conexion, string $pais, string $plu, string $referencia): bool
{
    $base = rcp_base_articulos($pais);
    $sql = "SELECT TOP (1) 1 AS existe
        FROM {$base}.dbo.ARTICULOS A
        INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
            ON CL.CODARTICULO = A.CODARTICULO
        WHERE A.DESCATALOGADO = 'F'
          AND CL.PLU IN (" . implode(', ', array_fill(0, count($candidatos = rcp_plu_candidatos($plu, $pais)), '? COLLATE DATABASE_DEFAULT')) . ")
          AND " . rcp_clave_sql('A.REFPROVEEDOR') . " = ? COLLATE DATABASE_DEFAULT";
    $stmt = rcp_ejecutar($conexion, $sql, [...$candidatos, $referencia]);
    $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);
    return $fila !== null && $fila !== false;
}

/* Inserta un nuevo registro de bloqueo de artículo de forma segura evitando duplicados. */
function rcp_insertar($conexion, string $pais, string $plu, string $referencia): bool
{
    $sql = "
        INSERT INTO " . RCP_TABLA . " (vIdPais, vIdCompany, vPlu, vReferencia, FechaRegistro)
        SELECT ?, ?, ?, ?, CAST(GETDATE() AS date)
        WHERE NOT EXISTS (
            SELECT 1 FROM " . RCP_TABLA . " B WITH (UPDLOCK, HOLDLOCK)
            WHERE B.vIdPais = ? AND B.vIdCompany = ?
              AND " . rcp_clave_sql('B.vPlu') . " = ? COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('B.vReferencia') . " = ? COLLATE DATABASE_DEFAULT
        )
    ";
    $params = [$pais, RCP_COMPANIA, $plu, $referencia, $pais, RCP_COMPANIA, $plu, $referencia];
    $stmt = rcp_ejecutar($conexion, $sql, $params);
    $insertados = sqlsrv_rows_affected($stmt);
    sqlsrv_free_stmt($stmt);
    return $insertados === 1;
}

/* Modifica los datos de un bloqueo existente controlando transacciones y bloqueos de concurrencia. */
function rcp_editar($conexion, string $pais, string $pluOriginal, string $refOriginal, string $plu, string $referencia): void
{
    if (!sqlsrv_begin_transaction($conexion)) {
        rcp_error_sql('inicio transacción');
    }
    try {
        $sqlOriginal = "SELECT COUNT_BIG(*) AS total FROM " . RCP_TABLA . " WITH (UPDLOCK, HOLDLOCK)
            WHERE vIdPais = ? AND vIdCompany = ?
              AND " . rcp_clave_sql('vPlu') . " = ? COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('vReferencia') . " = ? COLLATE DATABASE_DEFAULT";
        $stmt = rcp_ejecutar($conexion, $sqlOriginal, [$pais, RCP_COMPANIA, $pluOriginal, $refOriginal]);
        $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmt);
        if ((int)($fila['total'] ?? 0) !== 1) {
            throw new InvalidArgumentException('No se pudo identificar un único registro para editar.');
        }

        $sqlDestino = "SELECT COUNT_BIG(*) AS total FROM " . RCP_TABLA . " WITH (UPDLOCK, HOLDLOCK)
            WHERE vIdPais = ? AND vIdCompany = ?
              AND " . rcp_clave_sql('vPlu') . " = ? COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('vReferencia') . " = ? COLLATE DATABASE_DEFAULT";
        $stmt = rcp_ejecutar($conexion, $sqlDestino, [$pais, RCP_COMPANIA, $plu, $referencia]);
        $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmt);
        $mismo = ($plu === $pluOriginal && $referencia === $refOriginal);
        if ((int)($fila['total'] ?? 0) > ($mismo ? 1 : 0)) {
            throw new InvalidArgumentException('Ya existe un bloqueo con ese PLU y referencia.');
        }

        $sqlUpdate = "UPDATE " . RCP_TABLA . "
            SET vPlu = ?, vReferencia = ?
            WHERE vIdPais = ? AND vIdCompany = ?
              AND " . rcp_clave_sql('vPlu') . " = ? COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('vReferencia') . " = ? COLLATE DATABASE_DEFAULT";
        $stmt = rcp_ejecutar($conexion, $sqlUpdate, [$plu, $referencia, $pais, RCP_COMPANIA, $pluOriginal, $refOriginal]);
        $afectadas = sqlsrv_rows_affected($stmt);
        sqlsrv_free_stmt($stmt);
        if ($afectadas !== 1) {
            throw new RuntimeException('La actualización no afectó un único registro.');
        }
        if (!sqlsrv_commit($conexion)) {
            rcp_error_sql('confirmación');
        }
    } catch (Throwable $error) {
        sqlsrv_rollback($conexion);
        throw $error;
    }
}

function rcp_desbloquear($conexion, string $pais, string $plu, string $referencia): void
{
    if (!sqlsrv_begin_transaction($conexion)) {
        rcp_error_sql('inicio transacción');
    }
    try {
        $condicion = 'vIdPais = ? AND vIdCompany = ?
            AND ' . rcp_clave_sql('vPlu') . ' = ? COLLATE DATABASE_DEFAULT
            AND ' . rcp_clave_sql('vReferencia') . ' = ? COLLATE DATABASE_DEFAULT';
        $stmt = rcp_ejecutar($conexion,
            'SELECT COUNT_BIG(*) AS total FROM ' . RCP_TABLA . ' WITH (UPDLOCK, HOLDLOCK) WHERE ' . $condicion,
            [$pais, RCP_COMPANIA, $plu, $referencia]);
        $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmt);
        if ((int)($fila['total'] ?? 0) !== 1) {
            throw new InvalidArgumentException('No se pudo identificar un único bloqueo para desbloquear.');
        }

        $stmt = rcp_ejecutar($conexion, 'DELETE FROM ' . RCP_TABLA . ' WHERE ' . $condicion,
            [$pais, RCP_COMPANIA, $plu, $referencia]);
        $afectadas = sqlsrv_rows_affected($stmt);
        sqlsrv_free_stmt($stmt);
        if ($afectadas !== 1) {
            throw new RuntimeException('La eliminación no afectó un único bloqueo.');
        }
        if (!sqlsrv_commit($conexion)) {
            rcp_error_sql('confirmación');
        }
    } catch (Throwable $error) {
        sqlsrv_rollback($conexion);
        throw $error;
    }
}

/* 
 Realiza la importación masiva de un lote de registros (hasta 300),
 validando formato, existencia en el catálogo y evitando duplicados antes de insertar.
 */
function rcp_importar_lote($conexion, string $pais, array $filas): array
{
    if (!$filas || count($filas) > 300) {
        throw new InvalidArgumentException('El lote debe contener entre 1 y 300 registros.');
    }

    $valores = [];
    $params = [];
    $unicos = [];
    foreach ($filas as $fila) {
        if (!is_array($fila)) {
            throw new InvalidArgumentException('El archivo contiene una fila inválida.');
        }
        $plu = rcp_validar_texto($fila['plu'] ?? null, 100, 'PLU');
        $referencia = rcp_validar_texto($fila['referencia'] ?? null, 100, 'referencia');
        $fecha = trim((string)($fila['fecha'] ?? ''));
        if ($fecha !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) {
            throw new InvalidArgumentException('Formato de fecha inválido; use AAAA-MM-DD.');
        }
        if ($fecha !== '') {
            $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
            if ($dt === false || $dt->format('Y-m-d') !== $fecha) {
                throw new InvalidArgumentException('FechaRegistro contiene una fecha inválida.');
            }
        }
        $clave = rcp_mayusculas($plu) . "\x1F" . rcp_mayusculas($referencia);
        if (isset($unicos[$clave])) {
            continue;
        }
        $unicos[$clave] = true;
        $valores[] = '(?, ?, ?)';
        array_push($params, $plu, $referencia, $fecha);
    }

    /* Solo se incorporan artículos reconocidos en la base del país. */
    /* Los bloqueos históricos existentes se aceptan al reimportar el archivo. */
    $pares = [];
    $paremetrosValidacion = [];
    $yaValidados = [];
    foreach ($filas as $fila) {
        $pluValidar = trim((string)$fila['plu']);
        $refValidar = trim((string)$fila['referencia']);
        $claveValidar = rcp_mayusculas($pluValidar) . "\x1F" . rcp_mayusculas($refValidar);
        if (!isset($unicos[$claveValidar]) || isset($yaValidados[$claveValidar])) {
            continue;
        }
        $yaValidados[$claveValidar] = true;
        $pares[] = '(?, ?)';
        $paremetrosValidacion[] = $pluValidar;
        $paremetrosValidacion[] = $refValidar;
    }
    $base = rcp_base_articulos($pais);
    $sqlValidar = "
        SELECT TOP (5) F.plu, F.referencia
        FROM (VALUES " . implode(', ', $pares) . ") F(plu, referencia)
        WHERE NOT EXISTS (
            SELECT 1 FROM {$base}.dbo.ARTICULOS A
            INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
                ON CL.CODARTICULO = A.CODARTICULO
            WHERE A.DESCATALOGADO = 'F'
              AND " . rcp_clave_sql('CL.PLU') . " = F.plu COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('A.REFPROVEEDOR') . " = F.referencia COLLATE DATABASE_DEFAULT
        )
        AND NOT EXISTS (
            SELECT 1 FROM " . RCP_TABLA . " B
            WHERE B.vIdPais = ? AND B.vIdCompany = ?
              AND " . rcp_clave_sql('B.vPlu') . " = F.plu COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('B.vReferencia') . " = F.referencia COLLATE DATABASE_DEFAULT
        )
    ";
    $stmtValidacion = rcp_ejecutar($conexion, $sqlValidar,
        [...$paremetrosValidacion, $pais, RCP_COMPANIA]);
    $invalidos = [];
    while ($item = sqlsrv_fetch_array($stmtValidacion, SQLSRV_FETCH_ASSOC)) {
        $invalidos[] = (string)$item['plu'] . ' / ' . (string)$item['referencia'];
    }
    sqlsrv_free_stmt($stmtValidacion);
    if ($invalidos) {
        throw new InvalidArgumentException(
            'No se encontraron en el catálogo los siguientes artículos: ' . implode(', ', $invalidos)
        );
    }

    $sql = "
        ;WITH Fuente AS (
            SELECT V.plu, V.referencia, MIN(NULLIF(V.fecha, '')) AS fecha
            FROM (VALUES " . implode(', ', $valores) . ") AS V(plu, referencia, fecha)
            GROUP BY V.plu, V.referencia
        )
        INSERT INTO " . RCP_TABLA . " (vIdPais, vIdCompany, vPlu, vReferencia, FechaRegistro)
        SELECT ?, ?, F.plu, F.referencia,
               COALESCE(TRY_CONVERT(date, F.fecha, 23), CAST(GETDATE() AS date))
        FROM Fuente F
        WHERE NOT EXISTS (
            SELECT 1 FROM " . RCP_TABLA . " B WITH (UPDLOCK, HOLDLOCK)
            WHERE B.vIdPais = ? AND B.vIdCompany = ?
              AND " . rcp_clave_sql('B.vPlu') . " = F.plu COLLATE DATABASE_DEFAULT
              AND " . rcp_clave_sql('B.vReferencia') . " = F.referencia COLLATE DATABASE_DEFAULT
        )
    ";
    array_push($params, $pais, RCP_COMPANIA, $pais, RCP_COMPANIA);

    if (!sqlsrv_begin_transaction($conexion)) {
        rcp_error_sql('inicio importación');
    }
    try {
        $stmt = rcp_ejecutar($conexion, $sql, $params);
        $insertados = sqlsrv_rows_affected($stmt);
        sqlsrv_free_stmt($stmt);
        if ($insertados < 0) {
            throw new RuntimeException('No se pudo verificar el resultado de la importación.');
        }
        if (!sqlsrv_commit($conexion)) {
            rcp_error_sql('confirmación importación');
        }
    } catch (Throwable $error) {
        sqlsrv_rollback($conexion);
        throw $error;
    }
    return ['procesados' => count($filas), 'validos' => count($unicos),
        'insertados' => $insertados, 'existentes' => count($unicos) - $insertados];
}