<?php
declare(strict_types=1);

/* Configura las cabeceras HTTP de la respuesta para que sea JSON en UTF-8, sin caché y previniendo sniffing MIME */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

/* Registra cambios o acciones importantes en el sistema de auditoría con su respectivo detalle y país */
function rcp_registrar_cambio(string $accion, string $detalle, string $pais): void
{
    try {
        require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';
        if (!registrar_auditoria('BLOQUEO_GENERAL', $accion, $detalle, $pais)) {
            error_log('No se pudo registrar auditoría: ' . $accion);
        }
    } catch (Throwable $e) {
        error_log('Auditoría RCP: ' . $e->getMessage());
    }
}

/* Envía una respuesta JSON con el código de estado HTTP especificado y finaliza la ejecución */
function responder(array $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

try {
    /* Carga los archivos de inicialización y configuración general */
    require_once __DIR__ . '/inc/init.php';
    $pais = rcp_pais((string)($_GET['pais'] ?? ''));
    $accion = (string)($_GET['action'] ?? 'list');
    $connSql = $sqlsrv_conn_exhibicion;

    /* Maneja las peticiones mediante el método HTTP GET */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        switch ($accion) {
            case 'list':
                $filtros = [];
                foreach (['plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'] as $columna) {
                    $filtros[$columna] = (string)($_GET['f_' . $columna] ?? '');
                }
                $datos = rcp_listado($connSql, $pais, (int)($_GET['page'] ?? 1),
                    (int)($_GET['per'] ?? 50), $filtros,
                    (string)($_GET['sort'] ?? 'fecha'), (string)($_GET['dir'] ?? 'desc'));
                responder(['ok' => true] + $datos);
            case 'options':
                $filtros = [];
                foreach (['plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'] as $columna) {
                    $filtros[$columna] = (string)($_GET['f_' . $columna] ?? '');
                }
                $datos = rcp_valores_filtro($connSql, $pais,
                    (string)($_GET['field'] ?? ''), (string)($_GET['q'] ?? ''), $filtros);
                responder(['ok' => true] + $datos);
            case 'products':
                responder(['ok' => true, 'rows' => rcp_buscar_productos($connSql, $pais,
                    (string)($_GET['q'] ?? ''))]);
            case 'stores':
                responder(['ok' => true, 'rows' => rcp_tiendas($connSql, $pais,
                    (string)($_GET['codigo'] ?? ''))]);
            default:
                responder(['ok' => false, 'message' => 'Acción no disponible.'], 404);
        }
    }

    /* Valida que el método HTTP de la solicitud sea POST para las operaciones de modificación */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Allow: GET, POST');
        responder(['ok' => false, 'message' => 'Método no permitido.'], 405);
    }
    
    /* Valida el token CSRF recibido en las cabeceras HTTP frente al almacenado en sesión */
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!hash_equals((string)($_SESSION['rcp_csrf'] ?? ''), $token)) {
        responder(['ok' => false, 'message' => 'La sesión venció. Actualice la página.'], 403);
    }

    /* Comprueba que el tamaño del cuerpo de la solicitud no exceda el límite permitido */
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 150000) {
        throw new InvalidArgumentException('La solicitud supera el tamaño permitido.');
    }
    $cuerpo = file_get_contents('php://input');
    if (!is_string($cuerpo) || strlen($cuerpo) > 150000) {
        throw new InvalidArgumentException('La solicitud supera el tamaño permitido.');
    }
    
    /* Decodifica los datos JSON enviados en la solicitud de forma estricta */
    $datos = json_decode($cuerpo, true, 64, JSON_THROW_ON_ERROR);
    if (!is_array($datos)) {
        throw new InvalidArgumentException('Datos de solicitud inválidos.');
    }
    
    /* El país recibido debe coincidir con el país seleccionado en la pantalla */
    $pais = rcp_pais((string)($datos['pais'] ?? ''));

    /* Ejecuta la acción correspondiente solicitada mediante POST */
    switch ($accion) {
        case 'add':
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            if (!rcp_producto_existe($connSql, $pais, $plu, $ref)) {
                throw new InvalidArgumentException('El PLU y la referencia no coinciden con un artículo activo de Exhibición.');
            }
            $insertado = rcp_insertar($connSql, $pais, $plu, $ref);
            if ($insertado) rcp_registrar_cambio('ARTICULO_BLOQUEADO', 'PLU: ' . $plu . ' | REFERENCIA: ' . $ref, $pais);
            responder(['ok' => true, 'insertado' => $insertado,
                'message' => $insertado ? 'Artículo bloqueado registrado.' : 'El bloqueo ya existe.']);
        case 'edit':
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            $origenPlu = rcp_validar_texto($datos['plu_original'] ?? null, 100, 'PLU original');
            $origenRef = rcp_validar_texto($datos['referencia_original'] ?? null, 100, 'referencia original');
            if (!rcp_producto_existe($connSql, $pais, $plu, $ref)) {
                throw new InvalidArgumentException('El PLU y la referencia no coinciden con un artículo activo de Exhibición.');
            }
            rcp_editar($connSql, $pais, $origenPlu, $origenRef, $plu, $ref);
            rcp_registrar_cambio('BLOQUEO_EDITADO', 'PLU: ' . $origenPlu . ' -> ' . $plu . ' | REFERENCIA: ' . $origenRef . ' -> ' . $ref, $pais);
            responder(['ok' => true, 'message' => 'Artículo actualizado.']);
        case 'unlock':
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            rcp_desbloquear($connSql, $pais, $plu, $ref);
            rcp_registrar_cambio('ARTICULO_DESBLOQUEADO', 'PLU: ' . $plu . ' | REFERENCIA: ' . $ref, $pais);
            responder(['ok' => true, 'message' => 'Artículo desbloqueado.']);
        case 'import':
            if (!isset($datos['rows']) || !is_array($datos['rows'])) {
                throw new InvalidArgumentException('El lote de importación es inválido.');
            }
            $resultadoImportacion = rcp_importar_lote($connSql, $pais, $datos['rows']);
            rcp_registrar_cambio('BLOQUEO_IMPORTACION',
                'Lote: ' . count($datos['rows']) . ' artículos | RESULTADO: ' . json_encode($resultadoImportacion, JSON_UNESCAPED_UNICODE),
                $pais);
            responder(['ok' => true] + $resultadoImportacion);
        default:
            responder(['ok' => false, 'message' => 'Acción no disponible.'], 404);
    }
} catch (InvalidArgumentException | JsonException $error) {
    responder(['ok' => false, 'message' => $error->getMessage()], 422);
} catch (Throwable $error) {
    /* Genera un código único de diagnóstico para errores inesperados y los registra en el log */
    $codigo = strtoupper(bin2hex(random_bytes(4)));
    error_log(sprintf(
        'Bloqueo RCP [%s] %s: %s en %s:%d',
        $codigo,
        get_class($error),
        $error->getMessage(),
        basename($error->getFile()),
        $error->getLine()
    ));
    responder([
        'ok' => false,
        'message' => 'No se pudo completar la consulta. Código de diagnóstico: ' . $codigo,
    ], 500);
}