'use strict';

const $ = (id) => document.getElementById(id);
const conf = window.RCP;
const estado = { page: 1, per: 50, total: 0, mode: 'add', original: null, loading: false, pendiente: false, filtros: {}, sort: 'fecha', dir: 'desc', filas: [], modalPais: null };
const CLAVE_ESTADO = 'rcp_listado_estado_v3';
const CLAVE_POSICION = 'rcp_listado_posicion_v3';
let posicionAntesGuardar = null;

function guardarEstado() {
    try {
        sessionStorage.setItem(CLAVE_ESTADO, JSON.stringify({
            pais: pais(), page: estado.page, per: estado.per, filtros: estado.filtros,
            sort: estado.sort, dir: estado.dir
        }));
    } catch (_) { /* El listado continúa sin almacenamiento del navegador. */ }
}

function ventanaDesplazamiento() {
    try {
        if (window.parent !== window && window.frameElement?.id === 'metisBloqueoFrame') {
            return window.parent;
        }
    } catch (_) {}
    return window;
}

function capturarPosicion() {
    const value1 = ventanaDesplazamiento();
    return {
        y: value1.scrollY,
        x: value1.scrollX,
        tablaX: document.querySelector('.table-wrap')?.scrollLeft ?? 0
    };
}

function guardarPosicion() {
    try { sessionStorage.setItem(CLAVE_POSICION, JSON.stringify(capturarPosicion())); }
    catch (_) { /* El listado continúa sin almacenamiento del navegador. */ }
}

function restaurarPosicion(posicion) {
    if (!posicion) return;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        const element1 = document.querySelector('.table-wrap');
        if (element1) element1.scrollLeft = Number(posicion.tablaX) || 0;
        ventanaDesplazamiento().scrollTo({ left: Number(posicion.x) || 0,
            top: Number(posicion.y) || 0, behavior: 'instant' });
    }));
}

function restaurarEstado() {
    try {
        const state1 = JSON.parse(sessionStorage.getItem(CLAVE_ESTADO) || 'null');
        if (!state1 || typeof state1 !== 'object') return;
        if (['HONDURAS', 'NICARAGUA'].includes(state1.pais)
            && Array.from($('pais').options).some(opcion => opcion.value === state1.pais)) {
            $('pais').value = state1.pais;
        }
        if (Number.isInteger(state1.page) && state1.page > 0 && state1.page <= 100000) estado.page = state1.page;
        if ([50, 100, 250, 500, 1000].includes(state1.per)) estado.per = state1.per;
        if (['numero', 'plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'].includes(state1.sort)) estado.sort = state1.sort;
        if (['asc', 'desc'].includes(state1.dir)) estado.dir = state1.dir;
        if (state1.filtros && typeof state1.filtros === 'object' && !Array.isArray(state1.filtros)) {
            for (const [campo, valor] of Object.entries(state1.filtros)) {
                if (['plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'].includes(campo) && typeof valor === 'string' && valor.length <= 1500) {
                    estado.filtros[campo] = valor;
                }
            }
        }
    } catch (_) { /* Utilizar los parámetros iniciales. */ }
    $('porPagina').value = String(estado.per);
}


function mensaje(texto, tipo = '') {
    $('mensaje').textContent = texto;
    $('mensaje').className = 'message ' + tipo;
}

function htmlSeguro(valor) {
    const div = document.createElement('div');
    div.textContent = String(valor ?? '');
    return div.innerHTML;
}

function pais() { return $('pais').value; }

async function api(accion, opciones = {}) {
    const url = new URL(conf.api, location.href);
    url.searchParams.set('action', accion);
    if (opciones.params) {
        for (const [clave, valor] of Object.entries(opciones.params)) url.searchParams.set(clave, valor);
    }
    const options1 = { credentials: 'same-origin', cache: 'no-store' };
    if (opciones.signal) options1.signal = opciones.signal;
    if (opciones.body) {
        options1.method = 'POST';
        options1.headers = { 'Content-Type': 'application/json', 'X-CSRF-Token': conf.csrf };
        options1.body = JSON.stringify({ pais: pais(), ...opciones.body });
    }
    const res = await fetch(url, options1);
    const value2 = await res.text();
    let value3;
    try {
        value3 = JSON.parse(value2);
    } catch (_) {
        throw new Error(`El servidor devolvió una respuesta no válida (HTTP ${res.status}). Revise el registro de Apache.`);
    }
    if (!res.ok || !value3.ok) throw new Error(value3.message || 'La operación no pudo completarse.');
    return value3;
}

function renderTabla(filas) {
    estado.filas = filas;
    const element2 = $('tabla');
    element2.replaceChildren();
    if (!filas.length) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="11" class="empty">No se encontraron artículos bloqueados.</td>';
        element2.append(tr);
        return;
    }
    for (const [indice, fila] of filas.entries()) {
        const tr = document.createElement('tr');
        const value4 = (dato) => htmlSeguro(dato ?? '—');
        const value5 = (estado.page - 1) * estado.per + indice;
        const value6 = estado.sort === 'numero' && estado.dir === 'desc'
            ? estado.total - value5
            : value5 + 1;
        tr.innerHTML = `
            <td class="num-col">${value6}</td>
            <td data-field="plu">${value4(fila.plu)}</td>
            <td data-field="referencia">${value4(fila.referencia)}</td>
            <td data-field="descripcion" class="description">${value4(fila.descripcion)}</td>
            <td data-field="departamento">${value4(fila.departamento)}</td>
            <td data-field="seccion">${value4(fila.seccion)}</td>
            <td data-field="familia">${value4(fila.familia)}</td>
            <td data-field="fecha">${value4(fila.fecha)}</td>
            <td></td>
            <td><span class="badge">Bloqueado</span></td>
            <td></td>`;
        const value7 = tr.children[8];
        value7.classList.add('stores-cell');
        if (fila.codarticulo) {
            const ver = document.createElement('button');
            ver.className = 'tiny';
            ver.type = 'button';
            ver.textContent = 'Ver tiendas';
            ver.setAttribute('aria-expanded', 'false');
            const element3 = document.createElement('div');
            element3.className = 'store-inline';
            element3.hidden = true;
            ver.addEventListener('click', async () => {
                const value8 = element3.hidden;
                element3.hidden = !value8;
                ver.setAttribute('aria-expanded', String(value8));
                ver.textContent = value8 ? 'Ocultar tiendas' : 'Ver tiendas';
                if (value8 && !element3.dataset.cargado) {
                    element3.textContent = 'Consultando tiendas...';
                    try {
                        const state2 = await api('stores', { params: { pais: pais(), codigo: fila.codarticulo } });
                        element3.replaceChildren();
                        if (!state2.rows.length) element3.textContent = 'No se encontraron tiendas.';
                        for (const value9 of state2.rows) {
                            const element4 = document.createElement('div');
                            element4.className = 'store-inline-row';
                            element4.textContent = `${value9.codigo} · ${value9.tienda || 'Tienda sin nombre'}`;
                            element3.append(element4);
                        }
                        element3.dataset.cargado = '1';
                    } catch (error1) { element3.textContent = error1.message; }
                }
            });
            value7.append(ver, element3);
        } else value7.textContent = '—';

        const value10 = tr.lastElementChild;
        if (Number(fila.repetidosOrigen) > 1) {
            const element5 = document.createElement('span');
            element5.className = 'duplicate-note';
            element5.title = 'Existen varios registros iguales en la tabla original. No se editarán automáticamente.';
            element5.textContent = 'Repetido en origen';
            value10.append(element5);
        } else {
            const element6 = document.createElement('button');
            element6.type = 'button'; element6.className = 'tiny'; element6.textContent = 'Editar';
            element6.addEventListener('click', () => abrirEdicion(fila));
            value10.append(element6);
        }
        element2.append(tr);
    }
}

async function cargar() {
    if (estado.loading) { estado.pendiente = true; return; }
    estado.loading = true;
    const value11 = capturarPosicion();
    guardarEstado();
    mensaje('Consultando Bloqueo General...');
    const value12 = new AbortController();
    const value13 = window.setTimeout(() => value12.abort(), 45000);
    try {
        const options2 = {
            pais: pais(), page: estado.page,
            per: estado.per, sort: estado.sort, dir: estado.dir
        };
        for (const [campo, valor] of Object.entries(estado.filtros)) {
            options2['f_' + campo] = valor;
        }
        const state3 = await api('list', { params: options2, signal: value12.signal });
        if (estado.page > 1 && !state3.rows.length) {
            // Si desaparecen filas, volver únicamente a la página anterior.
            estado.page--;
            estado.pendiente = true;
            return;
        }
        estado.total = Number(state3.total) || 0;
        const value14 = Boolean(state3.filtered);
        renderTabla(state3.rows);
        restaurarPosicion(value11);
        // La paginación se conserva aun cuando exista un filtro activo.
        const boundedValue1 = Math.max(1, Math.ceil(estado.total / estado.per));
        $('resumen').textContent = `${estado.total.toLocaleString('es-HN')} bloqueos ${value14 ? 'filtrados' : 'registrados'}`;
        $('pagina').textContent = `${estado.page} de ${boundedValue1}`;
        $('primera').disabled = estado.page <= 1;
        $('anterior').disabled = estado.page <= 1;
        $('siguiente').disabled = estado.page >= boundedValue1;
        $('ultima').disabled = estado.page >= boundedValue1;
        guardarEstado();
        document.querySelectorAll('.filter-trigger').forEach(boton => {
            boton.classList.toggle('is-active', Boolean(estado.filtros[boton.dataset.field]));
        });
        mensaje('');
    } catch (error2) {
        const value15 = error2.name === 'AbortError'
            ? 'La consulta superó el límite de 45 segundos. Verifique la conexión e inténtelo de nuevo.'
            : error2.message;
        const element7 = document.createElement('tr');
        const element8 = document.createElement('td');
        element8.colSpan = 11;
        element8.className = 'empty error';
        element8.textContent = `No se pudieron cargar los artículos. ${value15}`;
        element7.append(element8);
        $('tabla').replaceChildren(element7);
        mensaje(value15, 'error');
    } finally {
        window.clearTimeout(value13);
        estado.loading = false;
        if (estado.pendiente) { estado.pendiente = false; cargar(); }
    }
}

// Filtros globales: las opciones se consultan a SQL Server sin aplicar paginación.
let columnaExcel = '';
let valoresExcel = [];
let numeroConsultaExcel = 0;
let temporizadorExcel = null;
let hayMasValoresExcel = false;
let seleccionarTodoExcel = false;
const cacheOpcionesExcel = new Map();

function invalidarCacheExcel() {
    cacheOpcionesExcel.clear();
}

function claveCacheExcel(campo) {
    const value16 = Object.entries(estado.filtros)
        .filter(([nombre]) => nombre !== campo)
        .sort(([a], [b]) => a.localeCompare(b));
    return JSON.stringify([pais(), campo, value16]);
}

function guardarCacheExcel(clave, busqueda, datos) {
    const value17 = clave + '\u0000' + busqueda;
    cacheOpcionesExcel.delete(value17);
    cacheOpcionesExcel.set(value17, {
        values: [...datos.values],
        hasMore: datos.hasMore
    });
    while (cacheOpcionesExcel.size > 30) {
        cacheOpcionesExcel.delete(cacheOpcionesExcel.keys().next().value);
    }
}

function renderizarCacheExcel() {
    const element9 = $('excelBuscar').value.trim();
    const value18 = claveCacheExcel(columnaExcel);
    const value19 = cacheOpcionesExcel.get(value18 + '\u0000' + element9);
    if (value19) {
        valoresExcel = [...value19.values];
        hayMasValoresExcel = value19.hasMore;
        dibujarExcel();
        return true;
    }

    const value20 = cacheOpcionesExcel.get(value18 + '\u0000');
    if (element9 !== '' && value20 && !value20.hasMore && !/[%_\[\]]/.test(element9)) {
        const value21 = element9.toLocaleLowerCase('es');
        valoresExcel = value20.values.filter(valor =>
            valor.toLocaleLowerCase('es').includes(value21)
        );
        hayMasValoresExcel = false;
        dibujarExcel();
        return true;
    }
    return false;
}

function cerrarExcel() {
    $('excelMenu').hidden = true;
    numeroConsultaExcel++;
    clearTimeout(temporizadorExcel);
}

function abrirExcel(boton) {
    columnaExcel = boton.dataset.field;
    $('excelTitulo').textContent = boton.dataset.label || 'Filtrar';
    const element10 = $('excelMenu').querySelector('.excel-hint');
    if (element10) element10.textContent = 'Opciones de todos los registros, no solo de esta página. Escribe para buscar cualquier valor.';
    const value22 = String(estado.filtros[columnaExcel] || '');
    $('excelBuscar').value = value22.startsWith('__LIKE__') ? value22.slice(8) : '';
    $('excelOrden').value = estado.sort === columnaExcel ? estado.dir : 'asc';
    valoresExcel = [];
    hayMasValoresExcel = false;
    seleccionarTodoExcel = false;
    $('excelMenu').hidden = false;
    cargarOpcionesExcel();
    $('excelBuscar').focus();
}

async function cargarOpcionesExcel() {
    const value23 = columnaExcel;
    const value24 = ++numeroConsultaExcel;
    const element11 = $('excelBuscar').value.trim();
    const value25 = claveCacheExcel(value23);
    if (renderizarCacheExcel()) return;

    const element12 = $('excelOpciones');
    element12.textContent = 'Consultando todos los registros...';
    $('excelTodos').checked = false;
    seleccionarTodoExcel = false;
    try {
        const state4 = { pais: pais(), field: value23, q: element11 };
        // Conservar filtros de otras columnas, para que las opciones sean coherentes.
        for (const [nombre, valor] of Object.entries(estado.filtros)) {
            if (nombre !== value23 && valor) {
                state4['f_' + nombre] = valor;
            }
        }
        const value26 = await api('options', { params: state4 });
        // Ignorar respuestas de búsquedas anteriores o de un filtro ya cerrado.
        if (value24 !== numeroConsultaExcel || $('excelMenu').hidden || value23 !== columnaExcel) return;
        valoresExcel = Array.isArray(value26.values) ? value26.values.map(String) : [];
        hayMasValoresExcel = Boolean(value26.has_more);
        guardarCacheExcel(value25, element11, {
            values: valoresExcel,
            hasMore: hayMasValoresExcel
        });
        dibujarExcel();
    } catch (error3) {
        if (value24 !== numeroConsultaExcel || $('excelMenu').hidden) return;
        element12.textContent = error3.message;
    }
}

function dibujarExcel() {
    const element13 = $('excelOpciones');
    element13.replaceChildren();
    const value27 = String(estado.filtros[columnaExcel] || '').split('||');
    const asc = $('excelOrden').value === 'asc';
    const itemCount1 = [...valoresExcel]
        .sort((a, b) => asc
            ? a.localeCompare(b, 'es', { numeric: true })
            : b.localeCompare(a, 'es', { numeric: true }));
    for (const value28 of itemCount1) {
        const element14 = document.createElement('label');
        element14.className = 'excel-option';
        const element15 = document.createElement('input');
        element15.type = 'checkbox';
        element15.className = 'excel-item';
        element15.value = value28;
        element15.checked = value27.includes(value28);
        const element16 = document.createElement('span');
        element16.textContent = value28;
        element14.append(element15, element16);
        element13.append(element14);
    }
    if (!itemCount1.length) element13.textContent = 'No se encontraron valores.';
    if (hayMasValoresExcel) {
        const element17 = document.createElement('small');
        element17.textContent = 'Hay más valores. Escribe arriba para buscarlos en todos los registros.';
        element13.append(element17);
    }
    $('excelTodos').checked = itemCount1.length > 0
        && [...element13.querySelectorAll('.excel-item')].every(c => c.checked);
}

$('excelBuscar').addEventListener('input', () => {
    clearTimeout(temporizadorExcel);
    numeroConsultaExcel++;
    if (renderizarCacheExcel()) return;
    temporizadorExcel = setTimeout(cargarOpcionesExcel, 180);
});
$('excelOrden').addEventListener('change', dibujarExcel);
$('excelTodos').addEventListener('change', function () {
    seleccionarTodoExcel = this.checked;
    $('excelOpciones').querySelectorAll('.excel-item').forEach(c => { c.checked = this.checked; });
});
// Seleccionar manualmente una opción cancela el modo 'todas las coincidencias'.
$('excelOpciones').addEventListener('change', (event) => {
    if (event.target.matches('.excel-item')) {
        seleccionarTodoExcel = false;
        const elements1 = [...$('excelOpciones').querySelectorAll('.excel-item')];
        $('excelTodos').checked = elements1.length > 0 && elements1.every(c => c.checked);
    }
});
$('excelAplicar').addEventListener('click', () => {
    const elements2 = [...$('excelOpciones').querySelectorAll('.excel-item:checked')].map(c => c.value);
    const element18 = $('excelBuscar').value.trim();
    // "Seleccionar todo" significa todas las coincidencias del servidor,
    // no solo las opciones visibles en el navegador.
    if (seleccionarTodoExcel) {
        if (element18) estado.filtros[columnaExcel] = '__LIKE__' + element18;
        else delete estado.filtros[columnaExcel];
    } else if (elements2.length) {
        if (elements2.length > 60) {
            alert('Para seleccionar más de 60 valores, usa Seleccionar todo o escribe la búsqueda.');
            return;
        }
        estado.filtros[columnaExcel] = elements2.join('||');
    } else if (element18) {
        estado.filtros[columnaExcel] = '__LIKE__' + element18;
    } else {
        delete estado.filtros[columnaExcel];
    }
    estado.sort = columnaExcel;
    estado.dir = $('excelOrden').value;
    estado.page = 1;
    cerrarExcel();
    guardarEstado();
    cargar();
});
$('excelLimpiar').addEventListener('click', () => {
    delete estado.filtros[columnaExcel];
    estado.page = 1;
    cerrarExcel();
    guardarEstado();
    cargar();
});
$('excelCerrar').addEventListener('click', cerrarExcel);
document.addEventListener('click', event => {
    if (!$('excelMenu').hidden && !event.target.closest('#excelMenu,.filter-trigger')) cerrarExcel();
});
document.querySelectorAll('.filter-trigger').forEach(b => b.addEventListener('click', () => abrirExcel(b)));

// El número se basa en el orden numérico del PLU y permite ambos sentidos.
const thNumero = document.querySelector('th.num-col');
if (thNumero) {
    const control = document.createElement('button');
    control.type = 'button';
    control.className = 'filter-trigger';
    control.textContent = '↕';
    control.title = 'Ordenar número: ascendente o descendente';
    control.setAttribute('aria-label', 'Orden numérico ascendente o descendente');
    thNumero.append(' ', control);
    control.addEventListener('click', () => {
        estado.dir = estado.sort === 'numero' && estado.dir === 'asc' ? 'desc' : 'asc';
        estado.sort = 'numero';
        estado.page = 1;
        guardarEstado();
        cargar();
    });
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarExcel(); });

function abrirAgregar() {
    estado.mode = 'add'; estado.original = null; estado.modalPais = pais();
    $('formArticulo').reset();
    $('desbloquearArticulo').hidden = true;
    $('paisModal').value = estado.modalPais; $('companiaModal').value = 'DETODO'; $('fechaModal').value = 'Automática';
    $('modalTitulo').textContent = 'Agregar artículo';
    $('errorArticulo').textContent = '';
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('modalArticulo').showModal();
}

function abrirEdicion(fila) {
    estado.mode = 'edit'; estado.modalPais = pais();
    $('desbloquearArticulo').hidden = false;
    $('paisModal').value = estado.modalPais; $('companiaModal').value = 'DETODO'; $('fechaModal').value = fila.fecha || '—';
    estado.original = { plu: fila.plu, referencia: fila.referencia };
    $('modalTitulo').textContent = 'Editar bloqueo';
    $('plu').value = fila.plu;
    $('referencia').value = fila.referencia;
    $('errorArticulo').textContent = '';
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('modalArticulo').showModal();
}

async function desbloquearArticulo() {
    if (estado.mode !== 'edit' || !estado.original) return;
    if (!window.confirm('¿Desea desbloquear este artículo? Dejará de aparecer en Bloqueo General.')) return;
    const element19 = $('desbloquearArticulo');
    const element20 = $('guardarArticulo');
    element19.disabled = true;
    element20.disabled = true;
    $('errorArticulo').textContent = '';
    try {
        const value29 = await api('unlock', { body: {
            plu: estado.original.plu,
            referencia: estado.original.referencia
        } });
        invalidarCacheExcel();
        $('modalArticulo').close();
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        mensaje(value29.message, 'success');
    } catch (error4) {
        $('errorArticulo').textContent = error4.message;
    } finally {
        element19.disabled = false;
        element20.disabled = false;
    }
}

async function guardarArticulo(evento) {
    evento.preventDefault();
    const element21 = $('guardarArticulo');
    const element22 = { plu: $('plu').value.trim(), referencia: $('referencia').value.trim() };
    if (!element22.plu || !element22.referencia) {
        $('errorArticulo').textContent = 'Ingrese el PLU y la referencia.';
        return;
    }
    if (estado.mode === 'edit') {
        element22.plu_original = estado.original.plu;
        element22.referencia_original = estado.original.referencia;
    }
    if (estado.modalPais !== pais()) { $('errorArticulo').textContent = 'El país cambió. Vuelva a abrir el formulario.'; return; }
    element21.disabled = true;
    $('errorArticulo').textContent = '';
    try {
        const value30 = await api(estado.mode, { body: element22 });
        invalidarCacheExcel();
        $('modalArticulo').close();
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        guardarEstado();
        mensaje(value30.message, 'success');
    } catch (error5) { $('errorArticulo').textContent = error5.message; }
    finally { element21.disabled = false; }
}

$('desbloquearArticulo').addEventListener('click', desbloquearArticulo);

// Procesamiento del CSV sin conversión numérica para conservar ceros iniciales del PLU.
function leerCsv(texto, separador) {
    const value31 = [];
    let value32 = [], value33 = '', value34 = false;
    for (let i = 0; i < texto.length; i++) {
        const c = texto[i];
        if (c === '"') {
            if (value34 && texto[i + 1] === '"') { value33 += '"'; i++; }
            else value34 = !value34;
        } else if (c === separador && !value34) {
            value32.push(value33); value33 = '';
        } else if ((c === '\n' || c === '\r') && !value34) {
            if (c === '\r' && texto[i + 1] === '\n') i++;
            value32.push(value33);
            if (value32.some((f) => f.trim() !== '')) value31.push(value32);
            value32 = []; value33 = '';
        } else value33 += c;
    }
    if (value34) throw new Error('El CSV contiene comillas sin cerrar.');
    value32.push(value33);
    if (value32.some((f) => f.trim() !== '')) value31.push(value32);
    return value31;
}

function normalizarColumna(texto) {
    return texto.replace(/^\uFEFF/, '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function formatoFecha(valor) {
    valor = String(valor || '').trim();
    if (!valor) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(valor)) return valor;
    const value35 = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(valor);
    if (value35) return `${value35[3]}-${value35[2].padStart(2, '0')}-${value35[1].padStart(2, '0')}`;
    throw new Error('FechaRegistro debe tener el formato AAAA-MM-DD o DD/MM/AAAA.');
}

function prepararCsv(texto) {
    texto = texto.replace(/^\uFEFF/, '');
    const value36 = texto.split(/\r?\n/, 1)[0] || '';
    const value37 = (value36.match(/;/g) || []).length > (value36.match(/,/g) || []).length ? ';' : ',';
    const itemCount2 = leerCsv(texto, value37);
    if (itemCount2.length < 2) throw new Error('El archivo debe tener encabezados y por lo menos un registro.');
    const mappedItems1 = itemCount2.shift().map(normalizarColumna);
    const value38 = (...nombres) => mappedItems1.findIndex((v) => nombres.includes(v));
    const value39 = value38('vplu', 'plu');
    const value40 = value38('vreferencia', 'referencia');
    const value41 = value38('vidpais', 'pais');
    const value42 = value38('vidcompany', 'company', 'compania');
    const value43 = value38('fecharegistro', 'fecha');
    if (value39 === -1 || value40 === -1) throw new Error('El archivo debe contener las columnas vPlu y vReferencia.');
    const itemCount3 = [];
    const seenItems1 = new Set();
    for (let i = 0; i < itemCount2.length; i++) {
        const value44 = itemCount2[i];
        const plu = String(value44[value39] || '').trim();
        const itemCount4 = String(value44[value40] || '').trim();
        if (!plu || !itemCount4) throw new Error(`Fila ${i + 2}: PLU o referencia vacío.`);
        if (plu.length > 100 || itemCount4.length > 100) throw new Error(`Fila ${i + 2}: campo demasiado largo.`);
        if (value41 !== -1) {
            const value45 = String(value44[value41] || '').trim().toUpperCase();
            if (value45 && value45 !== pais()) throw new Error(`Fila ${i + 2}: el país no coincide con el seleccionado.`);
        }
        if (value42 !== -1) {
            const value46 = String(value44[value42] || '').trim().toUpperCase();
            if (value46 && value46 !== 'DETODO') throw new Error(`Fila ${i + 2}: compañía diferente de DETODO.`);
        }
        const value47 = value43 >= 0 ? formatoFecha(value44[value43] || '') : '';
        const value48 = (pais() + '\u001f' + 'DETODO' + '\u001f' + plu + '\u001f' + itemCount4).toLocaleUpperCase();
        if (seenItems1.has(value48)) continue;
        seenItems1.add(value48);
        itemCount3.push({ plu, referencia: itemCount4, fecha: value47 });
    }
    return { rows: itemCount3, repetidosArchivo: itemCount2.length - itemCount3.length };
}

async function importar() {
    const element23 = $('archivo').files[0];
    const element24 = $('estadoImportacion');
    const element25 = $('ejecutarImportacion');
    if (!element23) { element24.textContent = 'Seleccione un archivo CSV.'; return; }
    if (element23.size > 8 * 1024 * 1024) {
        element24.textContent = 'El archivo supera 8 MB. Divídalo en archivos más pequeños.'; return;
    }
    element25.disabled = true;
    $('pais').disabled = true;
    $('progreso').hidden = false;
    $('progreso').value = 0;
    try {
        const value49 = await element23.text();
        const { rows, repetidosArchivo } = prepararCsv(value49);
        if (!rows.length) throw new Error('No hay registros válidos para importar.');
        let value50 = 0, value51 = 0;
        const value52 = 300;
        for (let value53 = 0; value53 < rows.length; value53 += value52) {
            const itemCount5 = rows.slice(value53, value53 + value52);
            const value54 = await api('import', { body: { rows: itemCount5 } });
            invalidarCacheExcel();
            value50 += value54.insertados;
            value51 += value54.existentes;
            const procesados = Math.min(value53 + itemCount5.length, rows.length);
            $('progreso').value = 100 * procesados / rows.length;
            element24.textContent = `Importando ${procesados.toLocaleString('es-HN')} / ${rows.length.toLocaleString('es-HN')} registros...`;
        }
        element24.textContent = `Importación finalizada. Nuevos: ${value50}. Existentes: ${value51}. Repetidos en archivo: ${repetidosArchivo}.`;
        // Conservar página, filtros y desplazamiento tras importar.
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        guardarEstado();
    } catch (error) {
        element24.textContent = `Importación interrumpida: ${error.message}. Los lotes completados previamente permanecen guardados.`;
    } finally { element25.disabled = false; $('pais').disabled = false; }
}

$('btnAgregar').addEventListener('click', abrirAgregar);
$('btnImportar').addEventListener('click', () => {
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('archivo').value = '';
    $('estadoImportacion').textContent = '';
    $('progreso').hidden = true;
    $('modalImportar').showModal();
});
$('btnActualizar').addEventListener('click', () => {
    invalidarCacheExcel();
    cargar();
});
$('btnLimpiarFiltros').addEventListener('click', () => {
    estado.filtros = {}; estado.sort = 'fecha'; estado.dir = 'desc'; estado.page = 1;
    guardarEstado(); cargar();
});
$('porPagina').addEventListener('change', () => {
    estado.per = Number($('porPagina').value);
    estado.page = 1; guardarEstado(); cargar();
});
$('pais').addEventListener('change', () => {
    estado.page = 1; estado.filtros = {}; guardarEstado(); cargar();
});
$('primera').addEventListener('click', () => { estado.page = 1; guardarEstado(); cargar(); });
$('anterior').addEventListener('click', () => {
    if (estado.page > 1) { estado.page--; guardarEstado(); cargar(); }
});
$('siguiente').addEventListener('click', () => {
    if (estado.page < Math.ceil(estado.total / estado.per)) {
        estado.page++; guardarEstado(); cargar();
    }
});
$('ultima').addEventListener('click', () => {
    estado.page = Math.max(1, Math.ceil(estado.total / estado.per));
    guardarEstado(); cargar();
});
$('formArticulo').addEventListener('submit', guardarArticulo);
$('ejecutarImportacion').addEventListener('click', importar);
for (const cerrar of document.querySelectorAll('[data-close]')) {
    cerrar.addEventListener('click', () => $(cerrar.dataset.close).close());
}
// Conservar también la posición al actualizar el navegador.
restaurarEstado();
let tareaScroll = false;
ventanaDesplazamiento().addEventListener('scroll', () => {
    if (tareaScroll) return;
    tareaScroll = true;
    requestAnimationFrame(() => { guardarPosicion(); tareaScroll = false; });
}, { passive: true });
document.querySelector('.table-wrap')?.addEventListener('scroll', guardarPosicion, { passive: true });
let posicionInicial = null;
try { posicionInicial = JSON.parse(sessionStorage.getItem(CLAVE_POSICION) || 'null'); }
catch (_) { /* No hay posición guardada. */ }
cargar().then(() => restaurarPosicion(posicionInicial));
