'use strict';

// Sincronización visual con el tema y fondo del menú Metis.
(() => {
    const value1 = document.documentElement;
    const value2 = (value) => {
        if (!value || value === 'transparent') return false;
        const value3 = value.match(/^rgba?\(([^)]*)\)$/i);
        if (!value3) return true;
        const filteredItems1 = value3[1].split(/[,\s/]+/).filter(Boolean);
        return filteredItems1.length < 4 || Number(filteredItems1[3]) > 0;
    };

    const value4 = (value) => {
        if (!value) return null;
        const value5 = value.match(/^rgba?\(([^)]*)\)$/i);
        if (!value5) return null;
        const filteredItems2 = value5[1].split(/[,\s/]+/).filter(Boolean).map(Number);
        return filteredItems2.length >= 3 && filteredItems2.slice(0, 3).every(Number.isFinite)
            ? filteredItems2.slice(0, 3) : null;
    };

    const value6 = (value) => {
        const rgb = value4(value);
        if (!rgb) return false;
        const value7 = (rgb[0] * .2126) + (rgb[1] * .7152) + (rgb[2] * .0722);
        return value7 < 120;
    };

    const value8 = (element, win) => {
        for (let value9 = element; value9 && value9.nodeType === 1; value9 = value9.parentElement) {
            const value10 = win.getComputedStyle(value9).backgroundColor;
            if (value2(value10)) return value10;
        }
        return '';
    };

    const value11 = (doc, win) => {
        const element1 = [doc.documentElement, doc.body, doc.querySelector('.metis-app'), doc.querySelector('.metis-frame')].filter(Boolean);
        const value12 = [
            '--metis-accent', '--metis-primary', '--metis-color', '--accent-color',
            '--accent', '--primary', '--theme-primary', '--primary-color', '--metis-accent-color'
        ];
        for (const el of element1) {
            const css = win.getComputedStyle(el);
            for (const value13 of value12) {
                const value14 = css.getPropertyValue(value13).trim();
                if (value14 && value14 !== 'inherit' && value14 !== 'initial' && value14 !== 'transparent') return value14;
            }
        }
        // El enlace activo adopta el color de acento seleccionado en Metis.
        const element2 = doc.querySelector('.metis-nav-link.is-active');
        if (element2) {
            const value15 = win.getComputedStyle(element2).color;
            const rgb = value4(value15);
            if (rgb && Math.max(...rgb) - Math.min(...rgb) > 35) return value15;
        }
        const mappedItems1 = [doc.documentElement, doc.body].map(e =>
            e.getAttribute('data-accent') || e.getAttribute('data-color') || ''
        ).find(Boolean);
        const options1 = { blue: '#2563eb', purple: '#7251dd', green: '#16845d' };
        if (options1[mappedItems1]) return options1[mappedItems1];
        return win.getComputedStyle(doc.documentElement).getPropertyValue('--bs-primary').trim();
    };

    const value16 = () => {
        let value17;
        let value18;
        try {
            if (window.parent === window) return;
            value18 = window.parent;
            value17 = value18.document;
            if (!value17 || !value17.documentElement) return;
        } catch (_) {
            return; // No se accede al documento de otro origen.
        }

        const value19 = [
            value17.querySelector('.metis-main'),
            value17.querySelector('.metis-workspace'),
            value17.querySelector('.metis-frame'),
            value17.body,
            value17.documentElement
        ].filter(Boolean);
        const mappedItems2 = value19.map(el => value8(el, value18)).find(Boolean) || '';
        if (mappedItems2) value1.style.setProperty('--rcp-page', mappedItems2);

        const value20 = (
            value17.documentElement.getAttribute('data-bs-theme') ||
            value17.body.getAttribute('data-bs-theme') ||
            value17.documentElement.getAttribute('data-theme') ||
            ''
        ).toLowerCase();
        const value21 = value20 === 'dark' || (!value20 && value6(mappedItems2));
        value1.dataset.rcpTheme = value21 ? 'dark' : 'light';

        const value22 = value11(value17, value18);
        if (value22) {
            const element3 = document.createElement('span');
            element3.style.color = value22;
            element3.style.position = 'absolute';
            element3.style.visibility = 'hidden';
            document.body.append(element3);
            const value23 = window.getComputedStyle(element3).color;
            element3.remove();
            const rgb = value4(value23);
            if (rgb) {
                value1.style.setProperty('--rcp-accent', value23);
                value1.style.setProperty('--rcp-accent-rgb', rgb.join(','));
            }
        }
    };

    const value24 = () => {
        value16();
        try {
            if (window.parent === window) return;
            const doc = window.parent.document;
            const element4 = [doc.documentElement, doc.body, doc.querySelector('.metis-app'), doc.querySelector('.metis-workspace'), doc.querySelector('.metis-main')].filter(Boolean);
            let value25 = false;
            const value26 = () => {
                if (value25) return;
                value25 = true;
                requestAnimationFrame(() => { value25 = false; value16(); });
            };
            const mutationObserver1 = new MutationObserver(value26);
            for (const value27 of new Set(element4)) {
                mutationObserver1.observe(value27, { attributes: true, attributeFilter: ['class', 'style', 'data-bs-theme', 'data-theme', 'data-accent', 'data-color'] });
            }
            window.parent.addEventListener('storage', value26);
            window.parent.addEventListener('focus', value26);
            window.parent.document.addEventListener('click', event => {
                if (event.target.closest('#metisTheme, #metisAccentMenu, .metis-color-choice')) {
                    setTimeout(value26, 70);
                }
            });
            window.addEventListener('pageshow', value26);
        } catch (_) { /* El modo independiente mantiene el tema local. */ }
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', value24);
    else value24();
})();

(() => {
    const value28 = window.frameElement;
    if (!value28 || value28.id !== 'metisBloqueoFrame') return;

    const value29 = () => {
        const doc = document;
        if (!doc) return;
        const element5 = doc.querySelector('.shell');
        if (!element5) return;

        doc.documentElement.dataset.externalModalBackdrop = 'true';
        value28.scrolling = 'no';
        doc.documentElement.style.setProperty('overflow-y', 'visible', 'important');
        doc.body.style.setProperty('overflow-y', 'visible', 'important');
        doc.documentElement.style.setProperty('min-height', '0', 'important');
        doc.body.style.setProperty('min-height', '0', 'important');

        let value30 = false;
        let value31 = null;
        let value32 = null;
        const text1 = 'metis-bloqueo-general-modal-backdrop';

        function limpiarSombraModal() {
            value28.ownerDocument.getElementById(text1)?.remove();
            value31 = null;
            value32 = null;
        }

        function obtenerSombraModal() {
            if (value31) return value31;
            const value33 = value28.ownerDocument;
            value31 = value33.createElement('div');
            value31.id = text1;
            value31.setAttribute('aria-hidden', 'true');
            Object.assign(value31.style, {
                position: 'fixed',
                inset: '0',
                zIndex: '2147483000',
                pointerEvents: 'none'
            });
            for (let i = 0; i < 4; i++) {
                const value34 = value33.createElement('div');
                Object.assign(value34.style, {
                    position: 'fixed',
                    background: 'rgba(13, 22, 40, .56)',
                    backdropFilter: 'blur(3px)',
                    pointerEvents: 'auto'
                });
                value34.addEventListener('click', () => {
                    if (value32 instanceof HTMLDialogElement) value32.close();
                    else doc.getElementById('excelCerrar')?.click();
                });
                value31.append(value34);
            }
            value33.body.append(value31);
            return value31;
        }

        function actualizarSombraModal(ventana) {
            if (!ventana) {
                limpiarSombraModal();
                return;
            }

            value32 = ventana;
            const bounds1 = value28.getBoundingClientRect();
            const bounds2 = ventana.getBoundingClientRect();
            const value35 = bounds1.width / value28.clientWidth || 1;
            const value36 = bounds1.height / value28.clientHeight || 1;
            const value37 = bounds1.left + bounds2.left * value35;
            const value38 = bounds1.top + bounds2.top * value36;
            const value39 = value37 + bounds2.width * value35;
            const value40 = value38 + bounds2.height * value36;
            const value41 = window.parent.innerWidth;
            const value42 = window.parent.innerHeight;
            const value43 = obtenerSombraModal().children;
            const value44 = [
                { left: '0', top: '0', width: value41 + 'px', height: Math.max(0, value38) + 'px' },
                { left: '0', top: Math.max(0, value40) + 'px', width: value41 + 'px', height: Math.max(0, value42 - value40) + 'px' },
                { left: '0', top: Math.max(0, value38) + 'px', width: Math.max(0, value37) + 'px', height: Math.max(0, Math.min(value42, value40) - Math.max(0, value38)) + 'px' },
                { left: Math.max(0, value39) + 'px', top: Math.max(0, value38) + 'px', width: Math.max(0, value41 - value39) + 'px', height: Math.max(0, Math.min(value42, value40) - Math.max(0, value38)) + 'px' }
            ];
            [...value43].forEach((panel, indice) => Object.assign(panel.style, value44[indice]));
        }

        function actualizar() {
            if (value30) return;
            value30 = true;
            requestAnimationFrame(() => {
                value30 = false;
                const bounds3 = Math.ceil(element5.getBoundingClientRect().bottom + 12);
                if (Math.abs(value28.getBoundingClientRect().height - bounds3) > 2) {
                    value28.style.setProperty('height', Math.max(250, bounds3) + 'px', 'important');
                }
                ubicarVentanas();
            });
        }

        function ubicarVentanas() {
            const elements1 = [...doc.querySelectorAll('dialog.modal[open], #excelMenu:not([hidden])')];
            const match1 = elements1.find(ventana => ventana.matches('dialog.modal[open]'));
            const bounds4 = value28.getBoundingClientRect();
            const boundedValue1 = Math.max(0, -bounds4.top);
            const boundedValue2 = Math.min(value28.clientHeight, window.parent.innerHeight - bounds4.top);
            const boundedValue3 = Math.max(0, boundedValue2 - boundedValue1);
            if (!boundedValue3) {
                actualizarSombraModal(null);
                return;
            }

            const value45 = (boundedValue1 + boundedValue2) / 2;
            const boundedValue4 = Math.max(1, Math.min(820, window.parent.innerHeight * 0.9, boundedValue3 - 24));
            for (const value46 of elements1) {
                value46.style.top = value45 + 'px';
                value46.style.left = '50%';
                value46.style.bottom = 'auto';
                value46.style.margin = '0';
                value46.style.transform = 'translate(-50%, -50%)';
                value46.style.maxHeight = boundedValue4 + 'px';
            }
            actualizarSombraModal(match1 || null);
        }

        new ResizeObserver(actualizar).observe(element5);
        for (const value47 of doc.querySelectorAll('dialog.modal, #excelMenu')) {
            new MutationObserver(() => requestAnimationFrame(ubicarVentanas))
                .observe(value47, { attributes: true, attributeFilter: ['open', 'hidden'] });
        }
        window.parent.addEventListener('resize', actualizar);
        window.parent.addEventListener('scroll', ubicarVentanas, { passive: true });
        window.addEventListener('pagehide', limpiarSombraModal);
        window.addEventListener('pageshow', () => requestAnimationFrame(actualizar));
        actualizar();
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', value29);
    else value29();
})();
