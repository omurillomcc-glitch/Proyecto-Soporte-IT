<?php

declare(strict_types=1);

ini_set('max_execution_time', '120');

set_time_limit(120);

ini_set('memory_limit', '512M');

if (session_status() === PHP_SESSION_NONE) {

    session_name('APP_EXHIBICION');

    session_start();

}

require_once dirname(__DIR__) . '/controlusuarios/db.php';

require_once dirname(__DIR__) . '/controlusuarios/auth.php';

/* Conexión MySQL utilizada para validar las tiendas autorizadas. */

if (isset($conn) && $conn instanceof mysqli) {

    $GLOBALS['stock_mysql_conn'] = $conn;

}

/* FUNCIONES DE LIMPIEZA */

function h(mixed $value): string

{
 return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');

}

function stock_clean_text(string $value): string

{
    return trim($value);
}


function stock_clean_codalmacen(string $value): string

{
    return preg_replace('/\D+/', '', trim($value));
}

/* LEER FILTROS DESDE GET */

function stock_filters_from_get(): array

{

    return [

        'region'            => stock_clean_text((string)($_GET['region'] ?? '')),

        'referencia'        => stock_clean_text((string)($_GET['referencia'] ?? '')),

        'descripcion'       => stock_clean_text((string)($_GET['descripcion'] ?? '')),

        'departamento'      => stock_clean_text((string)($_GET['departamento'] ?? '')),

        'seccion'           => stock_clean_text((string)($_GET['seccion'] ?? '')),

        'familia'           => stock_clean_text((string)($_GET['familia'] ?? '')),

        'codbarras'         => stock_clean_text((string)($_GET['codbarras'] ?? '')),

        'plu'               => stock_clean_text((string)($_GET['plu'] ?? '')),

        'inventario_tienda' => stock_clean_text((string)($_GET['inventario_tienda'] ?? '')),       

        'codarticulo'       => stock_clean_text((string)($_GET['codarticulo'] ?? '')),

        'codalmacen'        => stock_clean_text((string)($_GET['codalmacen'] ?? '')),

    ];

}


/* NORMALIZAR PAÍS HN O NICARAGUA */

function stock_normalizar_pais(string $pais): string

{
    $pais = strtoupper(trim($pais));

    return match ($pais) {

        'HN', 'HONDURAS'  => 'HN',

        'NI', 'NICARAGUA' => 'NI',

        default           => $pais,

    };

}

/* CONTEXTO DEL USUARIO SI ESTA LOGEADO A HONDURAS O NICARAGUA */

function stock_context_from_session(): array

{
    require_module_access('consulta_con_stock');

    $me = me();

    $paisCode  = stock_normalizar_pais((string)($me['pais_code'] ?? ''));

    $rol       = trim((string)($me['rol'] ?? ''));

    $usuarioId = (int)($me['id'] ?? 0);

    if ($paisCode === 'NI') {

        return [

            'db'        => 'ACANICARAGUA2',

            'region'    => 'NICARAGUA',

            'paisCode'  => 'NI',

            'rol'       => $rol,

            'usuarioId' => $usuarioId,

        ];

    }

    return [

        'db'        => 'DETODO',

        'region'    => 'HONDURAS',

        'paisCode'  => 'HN',

        'rol'       => $rol,

        'usuarioId' => $usuarioId,

    ];

}
/* OBTENER TIENDAS DEL USUARIO ASIGNADAS */

function stock_get_user_stores(mysqli $conn, int $usuarioId, string $paisCode): array

{

    if ($usuarioId <= 0) {

        return [];

    }

    $sql = "

        SELECT DISTINCT codalmacen, pais

        FROM usuario_tienda

        WHERE usuario_id = ?

          AND COALESCE(TRIM(codalmacen), '') <> ''

        ORDER BY codalmacen

    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {

        return [];

    }

    $stmt->bind_param('i', $usuarioId);

    $stmt->execute();

    $res = $stmt->get_result();

    $stores = [];

    while ($row = $res->fetch_assoc()) {

        $cod  = stock_clean_codalmacen((string)($row['codalmacen'] ?? ''));

        $pais = stock_normalizar_pais((string)($row['pais'] ?? ''));

        if ($cod === '') {

            continue;

        }

        if ($pais !== '' && $paisCode !== '' && $pais !== $paisCode) {

            continue;

        }

        if (!preg_match('/^\d{2}$/', $cod)) {

            continue;

        }
        $stores[] = $cod;

    }

    $stmt->close();

    $stores = array_values(array_unique($stores));

    sort($stores);

    return $stores;

}

/* VERIFICAR SI HAY ALGÚN FILTRO */

function stock_tiene_filtro_clave(array $filters): bool

{

    foreach ($filters as $value) {

        if (trim((string)$value) !== '') {

            return true;

        }

    }
    return false;
}

/* EXPRESIÓN LIMPIA PARA CODALMACEN */

function stock_sql_codalmacen(string $campoSql): string

{
    return "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$campoSql})))";
}
/* SEPARAR VALORES DEL FILTRO EXCEL PARA QUE NO QUEDEN VACIOS */

function stock_excel_values(string $valor): array

{

    $valor = trim($valor);

    if ($valor === '') {
        return [];
    }

    return array_values(array_filter(

        array_map('trim', explode('||', $valor)),

        fn($v) => $v !== ''

    ));
}


/* FILTRO EXACTO / BUSCADOR TIPO EXCEL */

function stock_add_excel_exact_filter(

    string &$sql,

    array &$params,

    string $campoSql,

    string $valor

): void {

    $valor = trim($valor);

    /* CASO 1: EL USUARIO ESCRIBIÓ EN EL BUSCADOR Y NO SELECCIONÓ CHECKBOX */

    if (str_starts_with($valor, '__LIKE__')) {

        $texto = trim(str_replace('__LIKE__', '', $valor));

        if ($texto !== '') {

            $sql .= "

                AND LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))

                    COLLATE DATABASE_DEFAULT

                    LIKE ?

                    COLLATE DATABASE_DEFAULT

            ";

            $params[] = '%' . $texto . '%';

        }



        return;

    }

    /* CASO 2: EL USUARIO SELECCIONÓ UNO O VARIOS VALORES */

    $valores = stock_excel_values($valor);

    if (empty($valores)) {

        return;

    }

    $partes = [];

    foreach ($valores as $v) {

        $partes[] = "

            LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql})))

            COLLATE DATABASE_DEFAULT

            =

            ?

            COLLATE DATABASE_DEFAULT

        ";



        $params[] = trim((string)$v);

    }



    $sql .= " AND (" . implode(" OR ", $partes) . ")";

}



/* FILTRO COINCIDENCIA */

function stock_add_excel_like_filter(

    string &$sql,

    array &$params,

    string $campoSql,

    string $valor

): void {

    $valores = stock_excel_values($valor);



    if (empty($valores)) {

        return;

    }

    $partes = [];

    foreach ($valores as $v) {

        $partes[] = "LTRIM(RTRIM(CONVERT(VARCHAR(255), {$campoSql}))) COLLATE DATABASE_DEFAULT LIKE ? COLLATE DATABASE_DEFAULT";

        $params[] = '%' . trim((string)$v) . '%';

    }
    $sql .= " AND (" . implode(" OR ", $partes) . ")";

}
/* CONSTRUIR ALCANCE POR ROL */

function stock_build_scope_clause(array $ctx, mysqli $conn, array $filters, string $storeColumn = 'S.CODALMACEN'): array

{

    $rol       = (string)($ctx['rol'] ?? '');

    $usuarioId = (int)($ctx['usuarioId'] ?? 0);

    $paisCode  = (string)($ctx['paisCode'] ?? '');

    $codAlmacenScopeSql = stock_sql_codalmacen($storeColumn);

    /* PROPIETARIO: acceso global dentro del país asignado. */
    if (in_array($rol, ['propietario', 'super_admin'], true)) {
        return ['', []];
    }
    /* ADMIN ZONA */

    if ($rol === 'admin_zona') {

        if (!stock_tiene_filtro_clave($filters)) {

            return [' AND 1 = 0 ', []];

        }
        $stores = stock_get_user_stores($conn, $usuarioId, $paisCode);

        if (empty($stores)) {

            return [' AND 1 = 0 ', []];

        }

        $placeholders = implode(',', array_fill(0, count($stores), '?'));

        return [

            " AND {$codAlmacenScopeSql} LIKE '[0-9][0-9]'

              AND {$codAlmacenScopeSql} IN ($placeholders) ",

            $stores

        ];

    }

    /* USUARIO NORMAL */

    $stores = stock_get_user_stores($conn, $usuarioId, $paisCode);

    if (empty($stores)) {

        return [' AND 1 = 0 ', []];

    }

    $placeholders = implode(',', array_fill(0, count($stores), '?'));

    return [

        " AND {$codAlmacenScopeSql} LIKE '[0-9][0-9]'

          AND {$codAlmacenScopeSql} IN ($placeholders) ",

        $stores

    ];

}

/* CONSULTA DE ARTÍCULOS SIN EXISTENCIAS EN LA TIENDA */

function stock_build_query(array $filters): array

{

    $ctx = stock_context_from_session();

    $dbOrigen = $ctx['db'];

    $region   = $ctx['region'];
    $codAlmacenSql = stock_sql_codalmacen('ALM.CODALMACEN');
    if (

        !isset($GLOBALS['stock_mysql_conn']) ||

        !($GLOBALS['stock_mysql_conn'] instanceof mysqli)

    ) {

        throw new RuntimeException('No se encontró una conexión mysqli válida.');

    }
    $mysqlConn = $GLOBALS['stock_mysql_conn'];

    /* RESTRICCIÓN POR ROL */

    [$scopeSql, $scopeParams] = stock_build_scope_clause($ctx, $mysqlConn, $filters, 'ALM.CODALMACEN');

/* WHERE INTERNO */

    $whereSql = "

        WHERE 1 = 1

        {$scopeSql}

        AND {$codAlmacenSql} LIKE '[0-9][0-9]'

        AND UPPER(LTRIM(RTRIM(REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')))) <> 'PACKING ARTICULO'

        AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'

        AND UPPER(LTRIM(RTRIM(ISNULL(D.DESCRIPCION, '')))) NOT LIKE '%ARTICULOS DE GASTO%'

        AND UPPER(LTRIM(RTRIM(ISNULL(SC.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'

        AND UPPER(LTRIM(RTRIM(ISNULL(F.DESCRIPCION, '')))) NOT LIKE '%NO USAR%'

    ";

    /* PARÁMETROS INICIALES */

    $params = array_merge([$region], $scopeParams);

    /* Una tienda exacta restringe el catálogo al almacén seleccionado. */
    if (preg_match('/^[0-9]{2}$/', (string)$filters['codalmacen'])) {
        $whereSql .= ' AND ALM.CODALMACEN = ? ';
        $params[] = $filters['codalmacen'];
    } else {
        stock_add_excel_exact_filter($whereSql, $params, $codAlmacenSql, $filters['codalmacen']);
    }

    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '')",

        $filters['referencia']

    );
    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '')",

        $filters['descripcion']

    );

    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "ISNULL(D.DESCRIPCION, '')",

        $filters['departamento']

    );

    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "ISNULL(SC.DESCRIPCION, '')",

        $filters['seccion']

    );



    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "ISNULL(F.DESCRIPCION, '')",

        $filters['familia']

    );



    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '')",

        $filters['codbarras']

    );

    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "UPPER(ISNULL(CONVERT(VARCHAR(100), CL.PLU), ''))",

        strtoupper($filters['plu'])

    );



    stock_add_excel_exact_filter(

        $whereSql,

        $params,

        "UPPER(CONVERT(VARCHAR(100), AA.CODARTICULO))",

        strtoupper($filters['codarticulo'])

    );
    /* Consulta solo lectura. */

   $sql = "

SELECT *

FROM

(
    SELECT

        ? AS REGION,

        AA.CODARTICULO,

        {$codAlmacenSql} AS CODALMACEN,

        LTRIM(RTRIM(ISNULL(ALM.NOMBREALMACEN,''))) AS ALMACEN,

        REPLACE(REPLACE(ISNULL(A.REFPROVEEDOR, ''), CHAR(10), ''), CHAR(13), '') AS REFERENCIA,

        REPLACE(REPLACE(ISNULL(AA.CODBARRAS, ''), CHAR(10), ''), CHAR(13), '') AS CODBARRAS,

        ISNULL(CONVERT(VARCHAR(100), CL.PLU), '') AS PLU,

        REPLACE(REPLACE(ISNULL(A.DESCRIPCION, ''), CHAR(10), ''), CHAR(13), '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,

        ISNULL(SC.DESCRIPCION, '') AS SECCION,

        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        COALESCE(SUM(S.STOCK), 0) AS INVENTARIO_TIENDA

    FROM {$dbOrigen}.dbo.ALMACEN ALM

    CROSS JOIN {$dbOrigen}.dbo.ARTICULOSLIN AA

    INNER JOIN {$dbOrigen}.dbo.ARTICULOS A

        ON A.CODARTICULO = AA.CODARTICULO

       AND A.DESCATALOGADO = 'F'

    LEFT JOIN {$dbOrigen}.dbo.STOCKS S

        ON S.CODARTICULO = AA.CODARTICULO

       AND S.TALLA = AA.TALLA

       AND S.COLOR = AA.COLOR

       AND S.CODALMACEN = ALM.CODALMACEN

    LEFT JOIN {$dbOrigen}.dbo.ARTICULOSCAMPOSLIBRES CL

        ON CL.CODARTICULO = AA.CODARTICULO

    LEFT JOIN {$dbOrigen}.dbo.DEPARTAMENTO D

        ON D.NUMDPTO = A.DPTO

    LEFT JOIN {$dbOrigen}.dbo.SECCIONES SC

        ON SC.NUMDPTO = A.DPTO

       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN {$dbOrigen}.dbo.FAMILIAS F

        ON F.NUMDPTO = A.DPTO

       AND F.NUMSECCION = A.SECCION

       AND F.NUMFAMILIA = A.FAMILIA

    {$whereSql}

    GROUP BY

        AA.CODARTICULO,

        {$codAlmacenSql},

        ALM.NOMBREALMACEN,

        A.REFPROVEEDOR,

        AA.CODBARRAS,

        CL.PLU,

        A.DESCRIPCION,

        D.DESCRIPCION,

        SC.DESCRIPCION,

        F.DESCRIPCION

) Q

WHERE Q.INVENTARIO_TIENDA = 0

";
    /* FILTROS DESPUÉS DEL GROUP BY */

    stock_add_excel_exact_filter(

        $sql,

        $params,

        "Q.REGION",

        $filters['region']

    );
      stock_add_excel_exact_filter(

        $sql,

        $params,

        "Q.INVENTARIO_TIENDA",

        $filters['inventario_tienda']

    );

    return [$sql, $params, $ctx];

}