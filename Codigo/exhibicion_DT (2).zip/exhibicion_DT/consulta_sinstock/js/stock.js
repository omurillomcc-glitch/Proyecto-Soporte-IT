/* Filtros tipo Excel: opciones de todos los registros. */
(() => {
  const element1 = document.getElementById('stockExcelMenu');
  const element2 = document.getElementById('stock-filters');
  if (!element1 || !element2) return;

  const element3 = document.getElementById('stockExcelSearch');
  const element4 = document.getElementById('stockExcelOptions');
  const all = document.getElementById('stockExcelAll');
  const element5 = document.getElementById('stockExcelSort');
  const element6 = document.getElementById('stockExcelTitle');
  let text1 = '';
  let value1 = [];
  let seenItems1 = new Set();
  let value2 = false;
  let value3 = 0;
  let value4;

  const element7 = () => element2.querySelector(`[data-filter="${text1}"]`);
  const value5 = () => {
    const inputValue1 = element3.value.trim().toLocaleLowerCase('es');
    const filteredItems1 = value1.filter(value => value.toLocaleLowerCase('es').includes(inputValue1));
    const value6 = text1 === 'inventario_tienda';
    filteredItems1.sort((a, b) => value6
      ? (Number(a) - Number(b)) || a.localeCompare(b, 'es', {numeric: true})
      : a.localeCompare(b, 'es', {numeric: true, sensitivity: 'base'}));
    if (element5.value === 'DESC') filteredItems1.reverse();
    return filteredItems1;
  };

  function updateAll(visible) {
    all.checked = visible.length > 0 && visible.every(value => seenItems1.has(value));
    all.indeterminate = !all.checked && visible.some(value => seenItems1.has(value));
  }

  function draw() {
    const itemCount1 = value5();
    const value7 = document.createDocumentFragment();
    if (!itemCount1.length) {
      const element8 = document.createElement('span');
      element8.className = 'stock-options-empty';
      element8.textContent = 'No se encontraron valores.';
      value7.append(element8);
    }
    for (const value8 of itemCount1) {
      const element9 = document.createElement('label');
      element9.className = 'pg-filter-option stock-excel-option';
      const element10 = document.createElement('input');
      element10.type = 'checkbox';
      element10.checked = seenItems1.has(value8);
      const element11 = document.createElement('span');
      element11.className = 'stock-option-value';
      element11.textContent = value8 || '(Vacío)';
      element10.addEventListener('change', () => {
        value2 = true;
        if (element10.checked) seenItems1.add(value8);
        else seenItems1.delete(value8);
        updateAll(itemCount1);
      });
      element9.append(element10, element11);
      value7.append(element9);
    }
    element4.replaceChildren(value7);
    updateAll(itemCount1);
  }

  function close() {
    element1.hidden = true;
    value3 += 1;
  }

  async function loadOptions() {
    const value9 = ++value3;
    element4.textContent = 'Cargando valores...';
    const url = new URL('/exhibicion_DT/consulta_sinstock/opciones.php', location.origin);
    new URLSearchParams(location.search).forEach((value, key) => url.searchParams.set(key, value));
    url.searchParams.set('field', text1);
    url.searchParams.set('search', element3.value.trim());
    url.searchParams.set('tienda_seleccionada', document.getElementById('stockStore')?.value || '');
    url.searchParams.delete('export');
    try {
      const response1 = await fetch(url, {credentials: 'same-origin'});
      if (!response1.ok) throw new Error('No se pudieron consultar los valores');
      const responseData1 = await response1.json();
      if (value9 !== value3) return;
      value1 = Array.isArray(responseData1) ? responseData1.map(value => String(value ?? '')) : [];
      draw();
    } catch (_) {
      if (value9 !== value3) return;
      value1 = [];
      element4.textContent = 'No se pudieron cargar los valores del filtro.';
    }
  }

  document.querySelectorAll('.stock-filter-button').forEach(button => {
    button.addEventListener('click', async () => {
      text1 = button.dataset.field || '';
      const value10 = element7();
      if (!value10) return;
      element6.textContent = 'Filtrar ' + (button.dataset.label || 'columna');
      element3.value = '';
      const element12 = element2.querySelector('[name="sort"]').value;
      const element13 = element2.querySelector('[name="dir"]').value;
      element5.value = element12 === text1 ? element13 : 'ASC';
      seenItems1 = new Set((value10.value || '').split('||').filter(Boolean));
      value2 = false;
      element1.hidden = false;
      all.checked = false;
      all.indeterminate = false;
      await loadOptions();
    });
  });

  element3.addEventListener('input', () => {
    window.clearTimeout(value4);
    value4 = window.setTimeout(loadOptions, 250);
  });
  element5.addEventListener('change', draw);
  all.addEventListener('change', () => {
    value2 = true;
    const value11 = value5();
    for (const value12 of value11) {
      if (all.checked) seenItems1.add(value12);
      else seenItems1.delete(value12);
    }
    draw();
  });

  document.getElementById('stockExcelClose').addEventListener('click', close);
  document.getElementById('stockExcelApply').addEventListener('click', () => {
    const value13 = element7();
    if (!value13) return;
    const inputValue2 = element3.value.trim();
    value13.value = inputValue2 && !value2
      ? '__LIKE__' + inputValue2
      : [...seenItems1].join('||');
    element2.querySelector('[name="sort"]').value = text1;
    element2.querySelector('[name="dir"]').value = element5.value;
    element2.submit();
  });
  document.getElementById('stockExcelClear').addEventListener('click', () => {
    const value14 = element7();
    if (!value14) return;
    value14.value = '';
    element2.submit();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !element1.hidden) close();
  });
})();

/* Sincronización del color de Metis, también si el módulo está en iframe. */
(() => {
  const value15 = document.documentElement;
  const element14 = document.querySelector('.stock-view');
  if (!element14) return;
  let value16;
  try {
    if (window.parent !== window) value16 = window.parent.document.documentElement;
  } catch (_) { /* Otro origen: se conserva el color local. */ }
  const value17 = value16 || value15;
  const value18 = () => {
    const value19 = (value17.ownerDocument.defaultView || window).getComputedStyle(value17);
    const value20 = value19.getPropertyValue('--metis-primary').trim();
    if (value20) element14.style.setProperty('--pg-accent', value20);
    else element14.style.removeProperty('--pg-accent');
    if (value16) {
      value15.setAttribute('data-bs-theme', value16.getAttribute('data-bs-theme') || 'light');
      value15.setAttribute('data-metis-accent', value16.getAttribute('data-metis-accent') || 'blue');
    }
  };
  value18();
  new MutationObserver(value18).observe(value17, { attributes: true, attributeFilter: ['data-metis-accent', 'data-bs-theme', 'class', 'style'] });
  if (value16 && value16.ownerDocument.body) {
    new MutationObserver(value18).observe(value16.ownerDocument.body, { attributes: true, attributeFilter: ['class', 'style'] });
  }
})();
