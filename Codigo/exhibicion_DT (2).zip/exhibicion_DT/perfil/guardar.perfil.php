<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}

/* Indicar que la respuesta será JSON */
header('Content-Type: application/json; charset=utf-8');

/* Cargar archivos necesarios */
require_once __DIR__ . '/../controlusuarios/auth.php';
require_once __DIR__ . '/../controlusuarios/db.php';

/* Función auxiliar para responder en JSON y terminar el script */
function json_response(bool $ok, string $msg, array $extra = []): never
{
    echo json_encode(array_merge([
        'ok'  => $ok,
        'msg' => $msg
    ], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    /* Validar que el usuario haya iniciado sesión */
    require_login();

    /* Obtener datos del usuario autenticado desde la sesión */
    app_require_csrf();
    $me = me();

    /* Verificar que exista conexión a la base de datos */
    if (!isset($conn) || !($conn instanceof mysqli)) {
        json_response(false, 'No hay conexión a la base de datos.');
    }

    /* Este archivo solo acepta peticiones POST */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        json_response(false, 'Método no permitido.');
    }

    /* Obtener datos necesarios */
    $id      = (int)($me['id'] ?? 0);
    $rol     = (string)($me['rol'] ?? '');
    $usuario = trim((string)($_POST['usuario'] ?? ''));
    $pass    = (string)($_POST['pass'] ?? '');

    /* Validar que el id de sesión sea válido */
    if ($id <= 0) {
        json_response(false, 'Sesión inválida.');
    }

    /* Validar permisos */
    if (!in_array($rol, ['super_admin'], true)) {
        json_response(false, 'No tienes permisos para editar el perfil.');
    }

    /* Validar que el usuario no venga vacío */
    if ($usuario === '') {
        json_response(false, 'Debes ingresar el usuario.');
    }

    /* Validar formato del nombre de usuario */
    if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]{3,30}$/u', $usuario)) {
        json_response(false, 'El usuario solo debe contener letras y espacios.');
    }

    /* La contraseña se administra exclusivamente desde el módulo Usuarios. */
    if ($pass !== '') {
        http_response_code(403);
        json_response(false, 'Solo un administrador autorizado puede restablecer contraseñas desde Usuarios.');
    }

    /* Definir nombres de tabla y columnas */
    $tabla      = 'usuarios';
    $colId      = 'id';
    $colUsuario = 'usuario';

    /* Verificar si el nuevo nombre de usuario ya existe en otro registro */
    $sqlCheck = "SELECT {$colId} FROM {$tabla} WHERE {$colUsuario} = ? AND {$colId} <> ? LIMIT 1";
    $stmtCheck = $conn->prepare($sqlCheck);

    /* Si falla el prepare, devolver error */
    if (!$stmtCheck) {
        json_response(false, 'Error al preparar validación.', [
            'detalle' => 'Consulta no disponible'
        ]);
    }

    /* Ejecutar validación del usuario repetido */
    $stmtCheck->bind_param('si', $usuario, $id);
    $stmtCheck->execute();
    $resCheck = $stmtCheck->get_result();

    /* Si ya existe otro usuario con ese nombre, detener proceso */
    if ($resCheck && $resCheck->num_rows > 0) {
        $stmtCheck->close();
        json_response(false, 'Ese nombre de usuario ya está en uso.');
    }

    /* Cerrar statement de validación */
    $stmtCheck->close();

    /* Editar únicamente el nombre de usuario; no modificar hashes aquí. */
    $sql = "UPDATE {$tabla} SET {$colUsuario} = ? WHERE {$colId} = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        json_response(false, 'No se pudo preparar la actualización del perfil.');
    }
    $stmt->bind_param('si', $usuario, $id);

    /* Ejecutar la actualización */
    if (!$stmt->execute()) {
        $stmtError = $stmt->error;
        $stmt->close();

        json_response(false, 'No se pudo actualizar el perfil.', [
            'detalle' => 'No se pudo guardar el cambio'
        ]);
    }

    /* Cerrar statement después de ejecutar */
    $stmt->close();

    /* Actualizar el usuario en la sesión */
    $_SESSION['usuario'] = $usuario;

    /* Respuesta exitosa */
    require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';
    try {
        registrar_auditoria('PERFIL', 'PERFIL_ACTUALIZADO',
            'Usuario: ' . $usuario . ' | Contraseña: SIN CAMBIOS (administrada desde Usuarios)',
            null, null, null, null, $conn);
    } catch (Throwable $e) {
        error_log('Auditoría perfil: ' . $e->getMessage());
    }
    json_response(true, 'Perfil actualizado correctamente.');

} catch (Throwable $e) {
    /* Captura de error general */
    json_response(false, 'Error interno del servidor.', [
        'detalle' => 'Error interno'
    ]);
}