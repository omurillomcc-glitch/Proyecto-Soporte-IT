

(function(){
 const photoModal=document.getElementById('pfPhotoModal'),photoInput=document.getElementById('pfPhotoInput'),img=document.getElementById('pfPhotoPreview');
 const previewBox=document.getElementById('pfPreviewBox'),photoError=document.getElementById('pfPhotoError'),uploadButton=document.getElementById('pfUpload');
 let cropper=null,url=null;
 function close(){photoModal.hidden=true;photoInput.value='';previewBox.hidden=true;photoError.textContent='';uploadButton.disabled=true;if(cropper){cropper.destroy();cropper=null;}if(url){URL.revokeObjectURL(url);url=null;}}
 document.getElementById('pfOpenCamera')?.addEventListener('click',()=>{photoModal.hidden=false;});
 document.getElementById('pfModalClose')?.addEventListener('click',close);
 document.getElementById('pfCancel')?.addEventListener('click',close);
 photoModal?.addEventListener('click',e=>{if(e.target===photoModal)close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!photoModal.hidden)close();});
 photoInput?.addEventListener('change',()=>{
  photoError.textContent='';uploadButton.disabled=true;previewBox.hidden=true;
  if(cropper){cropper.destroy();cropper=null;}if(url){URL.revokeObjectURL(url);url=null;}
  const f=photoInput.files?.[0];if(!f)return;
  if(f.size>2*1024*1024 || !['image/jpeg','image/png','image/webp'].includes(f.type)){photoError.textContent='Formato no permitido o archivo mayor de 2 MB.';photoInput.value='';return;}
  url=URL.createObjectURL(f);img.src=url;previewBox.hidden=false;uploadButton.disabled=false;
  img.onload=()=>{if(typeof Cropper==='function')cropper=new Cropper(img,{aspectRatio:1,viewMode:1,autoCropArea:.9,responsive:true});};
 });
 document.getElementById('pfPhotoForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const photoForm=e.currentTarget;if(!photoInput.files?.length)return;
  uploadButton.disabled=true;photoError.textContent='';
  try{
   const imageBlob=await new Promise(resolve=>{
    if(cropper){const croppedCanvas=cropper.getCroppedCanvas({width:400,height:400});croppedCanvas?.toBlob(resolve,'image/jpeg',.9);}
    else resolve(photoInput.files[0]);
   });
   if(!imageBlob)throw Error('No se pudo procesar la imagen.');
   const fd=new FormData(photoForm);fd.set('foto',imageBlob,'avatar.jpg');
   const r=await fetch('/exhibicion_DT/perfil/subir_foto.php',{method:'POST',body:fd,credentials:'same-origin'});
   const response=await r.json();if(!r.ok||!response.ok)throw Error(response.msg||'Error al guardar la imagen.');
   location.reload();
  }catch(ex){photoError.textContent=ex.message||'No se pudo guardar la foto.';uploadButton.disabled=false;}
 });
 document.getElementById('pfEye')?.addEventListener('click',()=>{const f=document.getElementById('pfPass');f.type=f.type==='password'?'text':'password';});
 document.getElementById('pfSecurityForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const securityForm=e.currentTarget,msg=document.getElementById('pfSecurityMsg'),btn=document.getElementById('pfSave');
  const username=document.getElementById('pfUsuario').value.trim(),password=document.getElementById('pfPass').value;
  if(!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]{3,30}$/u.test(username)){msg.textContent='Nombre de usuario inválido.';msg.dataset.ok='false';return;}
  if(password!==''&&(password.length<10||password.length>64||new TextEncoder().encode(password).length>72||/[\u0000-\u001F\u007F]/.test(password))){msg.textContent='Contraseña de 10 a 64 caracteres imprimibles, máximo 72 bytes.';msg.dataset.ok='false';return;}
  btn.disabled=true;
  try{
   const r=await fetch('/exhibicion_DT/perfil/guardar.perfil.php',{method:'POST',body:new FormData(securityForm),credentials:'same-origin'});
   const securityResponse=await r.json();msg.textContent=securityResponse.msg||'Respuesta del servidor';msg.dataset.ok=String(!!securityResponse.ok);
   if(!r.ok||!securityResponse.ok) return;
   setTimeout(()=>location.reload(),750);
  }catch(ex){msg.textContent='No se pudo contactar al servidor.';msg.dataset.ok='false';}
  finally{btn.disabled=false;}
 });
})();
