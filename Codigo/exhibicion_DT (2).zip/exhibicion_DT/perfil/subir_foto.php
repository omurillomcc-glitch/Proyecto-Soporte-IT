<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function fotoResponder(int $status, string $msg, bool $ok = false): never {
    http_response_code($status);
    echo json_encode(['ok' => $ok, 'msg' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fotoResponder(405, 'Método no permitido.');
require_login();
if (!hash_equals((string)($_SESSION['perfil_foto_csrf'] ?? ''), (string)($_POST['csrf_token'] ?? '')) || empty($_SESSION['perfil_foto_csrf'])) {
    fotoResponder(403, 'Formulario vencido. Recarga la pantalla.');
}
if (!isset($conn) || !($conn instanceof mysqli)) fotoResponder(500, 'Conexión local no disponible.');
$usuarioId = (int)$_SESSION['usuario_id'];
if ($usuarioId <= 0) fotoResponder(401, 'Sesión inválida.');
if (!isset($_FILES['foto']) || !is_array($_FILES['foto'])) fotoResponder(400, 'Selecciona una imagen.');
$f = $_FILES['foto'];
if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) fotoResponder(400, 'No se pudo recibir la imagen.');
if (($f['size'] ?? 0) <= 0 || $f['size'] > 2 * 1024 * 1024) fotoResponder(400, 'La imagen debe pesar máximo 2 MB.');
if (!is_uploaded_file((string)$f['tmp_name'])) fotoResponder(400, 'Archivo de origen inválido.');
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$validos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
if (!isset($validos[$mime])) fotoResponder(400, 'Formato no permitido.');
$dimensiones = @getimagesize($f['tmp_name']);
if ($dimensiones === false || $dimensiones[0] < 16 || $dimensiones[1] < 16 || $dimensiones[0] > 6000 || $dimensiones[1] > 6000) {
    fotoResponder(400, 'Dimensiones de imagen no válidas.');
}
$col = $conn->query("SHOW COLUMNS FROM usuarios LIKE 'foto_perfil'");
if (!$col || !$col->num_rows) fotoResponder(500, 'Falta la columna foto_perfil en usuarios. Ejecuta perfil/SQL/01_agregar_foto_perfil.sql.');
$directorio = dirname(__DIR__) . '/uploads/avatars/';
if (!is_dir($directorio) && !mkdir($directorio, 0755, true) && !is_dir($directorio)) fotoResponder(500, 'No se pudo crear el directorio de fotografías.');
$nombreNuevo = 'avatar_' . bin2hex(random_bytes(16)) . '.' . $validos[$mime];
$rutaNueva = $directorio . $nombreNuevo;
if (!move_uploaded_file($f['tmp_name'], $rutaNueva)) fotoResponder(500, 'No se pudo guardar la foto.');
@chmod($rutaNueva, 0644);
// Evitar borrar la imagen anterior si la transacción falla.
$stmt = $conn->prepare('SELECT foto_perfil FROM usuarios WHERE id = ? LIMIT 1');
if (!$stmt) { @unlink($rutaNueva); fotoResponder(500, 'No fue posible localizar al usuario.'); }
$stmt->bind_param('i', $usuarioId);
$stmt->execute();
$actual = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$actual) { @unlink($rutaNueva); fotoResponder(404, 'Usuario no encontrado.'); }
$stmt = $conn->prepare('UPDATE usuarios SET foto_perfil = ? WHERE id = ?');
if (!$stmt) { @unlink($rutaNueva); fotoResponder(500, 'No se pudo preparar la actualización.'); }
$stmt->bind_param('si', $nombreNuevo, $usuarioId);
$ok = $stmt->execute();
$stmt->close();
if (!$ok) { @unlink($rutaNueva); fotoResponder(500, 'No se pudo actualizar la foto.'); }
$anterior = (string)($actual['foto_perfil'] ?? '');
if ($anterior !== '' && preg_match('/^avatar_[a-f0-9]{32}\.(jpg|jpeg|png|webp)$/', $anterior) && is_file($directorio . $anterior)) {
    @unlink($directorio . $anterior);
}
require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';
try {
    registrar_auditoria('PERFIL', 'FOTO_ACTUALIZADA', 'El usuario actualizó su fotografía de perfil.', null, null, null, null, $conn);
} catch (Throwable $e) { error_log('Auditoría foto: ' . $e->getMessage()); }
fotoResponder(200, 'Foto actualizada correctamente.', true);
