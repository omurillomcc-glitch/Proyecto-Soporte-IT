<?php
declare(strict_types=1);


if (session_status() === PHP_SESSION_NONE) {
    session_name('APP_EXHIBICION');
    session_start();
}
require_once dirname(__DIR__) . '/controlusuarios/auth.php';
require_once dirname(__DIR__) . '/controlusuarios/db.php';
require_login();
$me = me();

if (!function_exists('pf_esc')) {
    function pf_esc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('pf_fecha')) {
    function pf_fecha($v): string {
        if (empty($v)) return 'No disponible';
        $t = strtotime((string)$v);
        return $t === false ? 'No disponible' : date('d/m/Y h:i A', $t);
    }
}

$id = (int)($me['id'] ?? $_SESSION['usuario_id'] ?? 0);
$usuario = trim((string)($me['usuario'] ?? ''));
$rol = strtolower(trim((string)($me['rol'] ?? '')));
$rolTexto = match ($rol) {
    'super_admin' => 'Superadministrador',
    'admin_zona' => 'Administrador de zona',
    'tienda' => 'Usuario de tienda',
    default => ucwords(str_replace('_',' ',$rol ?: 'Usuario'))
};
$estadoActivo = (int)($me['estado'] ?? 0) === 1;
$pais = trim((string)($me['pais'] ?? $me['pais_code'] ?? ''));
$zona = trim((string)($me['zona'] ?? ''));
$nombre = trim((string)($me['nombre_completo'] ?? $me['nombre'] ?? ''));
$foto = '';
$creado = '';
$ultimo = '';
$tiendas = [];
$avisoTiendas = '';

/* Obtener datos solo del usuario autenticado, según columnas reales. */
if ($conn instanceof mysqli && $id > 0) {
    $cols = [];
    $r = $conn->query('SHOW COLUMNS FROM usuarios');
    if ($r) { while ($c = $r->fetch_assoc()) $cols[] = $c['Field']; $r->free(); }
    $permitidas = array_values(array_intersect(['nombre_completo','nombre','foto_perfil','creado_en','ultimo_login'], $cols));
    if ($permitidas) {
        $campos = implode(', ', array_map(fn($s) => '`'.$s.'`', $permitidas));
        $stmt = $conn->prepare("SELECT {$campos} FROM usuarios WHERE id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i',$id);
            if ($stmt->execute()) {
                $dato = $stmt->get_result()->fetch_assoc() ?: [];
                $nombre = trim((string)($dato['nombre_completo'] ?? $dato['nombre'] ?? $nombre));
                $foto = basename((string)($dato['foto_perfil'] ?? ''));
                $creado = (string)($dato['creado_en'] ?? '');
                $ultimo = (string)($dato['ultimo_login'] ?? '');
            }
            $stmt->close();
        }
    }

    $tc = [];
    $r = $conn->query('SHOW COLUMNS FROM usuario_tienda');
    if ($r) { while ($c = $r->fetch_assoc()) $tc[] = $c['Field']; $r->free(); }
    if (in_array('usuario_id',$tc,true) && in_array('codalmacen',$tc,true)) {
        $seleccion = array_values(array_intersect(['codalmacen','nombrealmacen','nombre_tienda','zona','poblacion','pais'], $tc));
        $campos = implode(', ',array_map(fn($s) => '`'.$s.'`',$seleccion));
        $stmt = $conn->prepare("SELECT DISTINCT {$campos} FROM usuario_tienda WHERE usuario_id = ? ORDER BY codalmacen");
        if ($stmt) {
            $stmt->bind_param('i',$id);
            if ($stmt->execute()) {
                $res = $stmt->get_result();
                while ($t = $res->fetch_assoc()) {
                    $tiendas[] = [
                        'codigo' => trim((string)($t['codalmacen'] ?? '')),
                        'nombre' => trim((string)($t['nombrealmacen'] ?? $t['nombre_tienda'] ?? '')),
                        'zona' => trim((string)($t['zona'] ?? $t['poblacion'] ?? '')),
                        'pais' => trim((string)($t['pais'] ?? $pais))
                    ];
                }
            }
            $stmt->close();
        }
    } else {
        $avisoTiendas = 'La tabla de asignaciones no tiene las columnas necesarias.';
    }
}
if ($nombre === '') $nombre = $usuario !== '' ? $usuario : 'Usuario';
$partes = preg_split('/\s+/u',$nombre) ?: [];
$iniciales = '';
foreach (array_slice($partes,0,2) as $p) $iniciales .= mb_strtoupper(mb_substr($p,0,1,'UTF-8'),'UTF-8');
$iniciales = $iniciales ?: 'U';
$base = '/exhibicion_DT';
$fotoUrl = '';
if ($foto !== '' && preg_match('/^avatar_[a-zA-Z0-9_-]+\.(?:jpg|jpeg|png|webp)$/i',$foto)
    && is_file(dirname(__DIR__).'/uploads/avatars/'.$foto)) {
    $fotoUrl = $base.'/uploads/avatars/'.rawurlencode($foto);
}
if (empty($_SESSION['perfil_foto_csrf'])) $_SESSION['perfil_foto_csrf'] = bin2hex(random_bytes(32));
$puedeEditar = $rol === 'super_admin';
?>
<link rel="stylesheet" href="/exhibicion_DT/cropperjs/cropper.min.css">
<link href="perfil/css/perfil.css" rel="stylesheet">

<div class="pf-ref">
  <div class="pf-panel">
    
   
    <div class="pf-header">
      <div class="pf-user-meta">
        <div class="pf-avatar-box">
          <div class="pf-photo-visual">
            <?php if ($fotoUrl): ?>
              <img src="<?= pf_esc($fotoUrl) ?>" alt="Fotografía del perfil">
            <?php else: ?>
              <span><?= pf_esc($iniciales) ?></span>
            <?php endif; ?>
          </div>
          <button type="button" class="pf-camera" id="pfOpenCamera" aria-label="Cambiar foto" title="Cambiar foto">
            <i class="bi bi-camera-fill"></i>
          </button>
        </div>

        <div class="pf-user-titles">
          <h1><?= pf_esc($nombre) ?></h1>
          <p class="pf-handle">@<?= pf_esc($usuario) ?></p>

          <div class="pf-pills">
            <span class="pf-pill pf-pill-role">
              <i class="bi bi-shield-check"></i> <?= pf_esc($rolTexto) ?>
            </span>
            <span class="pf-pill <?= $estadoActivo ? 'ok' : 'off' ?>">
              <span class="pf-dot"></span> <?= $estadoActivo ? 'Cuenta activa' : 'Cuenta bloqueada' ?>
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- Navegación por Pestañas -->
    <div class="pf-tabs-nav">
      <button type="button" class="pf-tab-btn active" onclick="switchPfTab(event, 'tab-info')">
        <i class="bi bi-person-vcard"></i> Información Personal
      </button>
      <button type="button" class="pf-tab-btn" onclick="switchPfTab(event, 'tab-acceso')">
        <i class="bi bi-shield-lock"></i> Acceso al Sistema
      </button>
      <button type="button" class="pf-tab-btn" onclick="switchPfTab(event, 'tab-tiendas')">
        <i class="bi bi-shop"></i> Mis Tiendas (<?= count($tiendas) ?>)
      </button>
      <button type="button" class="pf-tab-btn" onclick="switchPfTab(event, 'tab-seguridad')">
        <i class="bi bi-key"></i> Seguridad
      </button>
    </div>

    <!-- Contenido de las Pestañas -->
    
    <div id="tab-info" class="pf-tab-content active">
      <div class="pf-info-grid">
        <div class="pf-info-card"><span>Nombre completo</span><strong><?= pf_esc($nombre) ?></strong></div>
        <div class="pf-info-card"><span>Usuario</span><strong><?= pf_esc($usuario) ?></strong></div>
        <div class="pf-info-card"><span>País</span><strong><?= pf_esc($pais ?: 'No disponible') ?></strong></div>
        <div class="pf-info-card"><span>Zona</span><strong><?= pf_esc($zona ?: 'No disponible') ?></strong></div>
      </div>
    </div>

    <div id="tab-acceso" class="pf-tab-content">
      <div class="pf-info-grid">
        <div class="pf-info-card"><span>Rol asignado</span><strong><?= pf_esc($rolTexto) ?></strong></div>
        <div class="pf-info-card"><span>Estado</span><strong class="<?= $estadoActivo ? 'text-ok' : 'text-off' ?>"><?= $estadoActivo ? 'Activo' : 'Bloqueado' ?></strong></div>
        <div class="pf-info-card"><span>Último acceso</span><strong><?= pf_esc(pf_fecha($ultimo)) ?></strong></div>
        <div class="pf-info-card"><span>Fecha de registro</span><strong><?= pf_esc(pf_fecha($creado)) ?></strong></div>
      </div>
    </div>

    <div id="tab-tiendas" class="pf-tab-content">
      <?php if ($tiendas): ?>
        <div class="pf-table-box">
          <table class="pf-clean-table">
            <thead>
              <tr>
                <th>Código</th>
                <th>Nombre de tienda</th>
                <th>Zona</th>
                <th>País</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($tiendas as $t): ?>
                <tr>
                  <td><span class="pf-code"><?= pf_esc($t['codigo']) ?></span></td>
                  <td><strong><?= pf_esc($t['nombre'] ?: 'Tienda '.$t['codigo']) ?></strong></td>
                  <td><?= pf_esc($t['zona'] ?: 'No registrada') ?></td>
                  <td><?= pf_esc($t['pais'] ?: 'No registrado') ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="pf-alert">
          <i class="bi bi-info-circle-fill"></i>
          <span><?= pf_esc($avisoTiendas ?: ($rol === 'super_admin' ? 'No hay asignaciones individuales registradas; el acceso global depende de los permisos de superadministrador.' : 'No hay tiendas asignadas a este usuario.')) ?></span>
        </div>
      <?php endif; ?>
    </div>


    <div id="tab-seguridad" class="pf-tab-content">
      <?php if ($puedeEditar): ?>
        <form id="pfSecurityForm" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= pf_esc(app_csrf_token()) ?>">
          <div class="pf-form-grid">
            <div class="pf-field">
              <label for="pfUsuario">Nombre de usuario</label>
              <div class="pf-input-wrap">
                <i class="bi bi-person"></i>
                <input type="text" name="usuario" id="pfUsuario" value="<?= pf_esc($usuario) ?>" required maxlength="30"  autocomplete="username">
              </div>
            </div>

            <input type="hidden" id="pfPass" name="pass" value="">
            <div class="pf-field">
              <small>Las contraseñas se administran desde el menú Usuarios por personal autorizado.</small>
            </div>
          </div>

          <div class="pf-form-actions">
            <button class="pf-btn-save" type="submit" id="pfSave">
              <i class="bi bi-floppy-fill"></i> Guardar cambios
            </button>
            <div class="pf-feedback" id="pfSecurityMsg" aria-live="polite"></div>
          </div>
        </form>
      <?php else: ?>
        <div class="pf-alert">
          <i class="bi bi-shield-lock-fill"></i>
          <span>Puedes consultar la información de tu cuenta. Los cambios de credenciales están reservados al personal autorizado.</span>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<!-- Modal Foto -->
<div class="pf-photo-modal" id="pfPhotoModal" hidden>
  <div class="pf-photo-dialog" role="dialog" aria-modal="true" aria-labelledby="pfModalTitle">
    <div class="pf-photo-dialog-header">
      <h3 id="pfModalTitle">Actualizar foto de perfil</h3>
      <button type="button" class="pf-close" id="pfModalClose" aria-label="Cerrar">&times;</button>
    </div>
    
    <form id="pfPhotoForm" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= pf_esc($_SESSION['perfil_foto_csrf']) ?>">
      
      <label class="pf-upload-zone" for="pfPhotoInput">
        <i class="bi bi-cloud-arrow-up-fill"></i>
        <span>Seleccionar fotografía</span>
        <small>Formatos: JPG, PNG, WEBP (Máximo 2 MB)</small>
      </label>
      <input type="file" name="foto" id="pfPhotoInput" accept="image/jpeg,image/png,image/webp" hidden>
      
      <div class="pf-preview" id="pfPreviewBox" hidden>
        <img id="pfPhotoPreview" alt="Vista previa de fotografía">
      </div>
      
      <p id="pfPhotoError" class="pf-modal-error" role="alert"></p>
      
      <div class="pf-modal-actions">
        <button type="button" id="pfCancel" class="pf-btn-cancel">Cancelar</button>
        <button type="submit" id="pfUpload" class="pf-btn-submit" disabled>Guardar foto</button>
      </div>
    </form>
  </div>
</div>

<script src="/exhibicion_DT/cropperjs/cropper.min.js"></script>
<script>
function switchPfTab(evt, tabId) {
  var i, tabContents, tabButtons;
  tabContents = document.getElementsByClassName("pf-tab-content");
  for (i = 0; i < tabContents.length; i++) {
    tabContents[i].classList.remove("active");
  }
  tabButtons = document.getElementsByClassName("pf-tab-btn");
  for (i = 0; i < tabButtons.length; i++) {
    tabButtons[i].classList.remove("active");
  }
  document.getElementById(tabId).classList.add("active");
  evt.currentTarget.classList.add("active");
}
</script>
<script src="perfil/js/perfil.js?v=<?= (string)filemtime(__DIR__ . '/js/perfil.js') ?>"></script>