<?php
declare(strict_types=1);

require_once __DIR__ . '/controlusuarios/auth.php';
require_once __DIR__ . '/controlusuarios/db.php';
require_once __DIR__ . '/controlusuarios/accesos_menu.php';
require_login();
$miId = (int)$_SESSION['usuario_id'];
$soyPropietario = am_es_propietario($conn, $miId);
$acceso = static fn(string $modulo): bool => am_puede($conn, $miId, $modulo);

$usuario   = (string) ($_SESSION['usuario'] ?? 'Usuario');
$rol       = (string) ($_SESSION['rol'] ?? '');
$paisCode  = strtoupper(trim((string) ($_SESSION['pais_code'] ?? '')));
$zona      = (string) ($_SESSION['zona'] ?? '');
$tienda    = (string) ($_SESSION['tienda'] ?? '');
$fotoMenuUrl = '';

if ($conn instanceof mysqli && $miId > 0) {
    $colFoto = $conn->query("SHOW COLUMNS FROM usuarios LIKE 'foto_perfil'");
    $tieneColumnaFoto = $colFoto && $colFoto->num_rows > 0;
    if ($colFoto) {
        $colFoto->free();
    }

    if ($tieneColumnaFoto) {
        $stmtFoto = $conn->prepare('SELECT foto_perfil FROM usuarios WHERE id = ? LIMIT 1');
        if ($stmtFoto) {
            $stmtFoto->bind_param('i', $miId);
            if ($stmtFoto->execute()) {
                $datoFoto = $stmtFoto->get_result()->fetch_assoc() ?: [];
                $nombreFoto = basename((string) ($datoFoto['foto_perfil'] ?? ''));
                if (preg_match('/^avatar_[a-f0-9]{32}\.(?:jpg|jpeg|png|webp)$/i', $nombreFoto)
                    && is_file(__DIR__ . '/uploads/avatars/' . $nombreFoto)) {
                    $fotoMenuUrl = '/exhibicion_DT/uploads/avatars/' . rawurlencode($nombreFoto);
                }
            }
            $stmtFoto->close();
        }
    }
}

$esAdministrador = in_array($rol, ['super_admin', 'admin_zona'], true);

$vistas = [
    // 'inicio' => null,
    'dashboard' => __DIR__ . '/exhibiciontotal/dashboard.php',
    'modulo1'   => __DIR__ . '/exhibiciontotal/exhibicion.php',
    'modulo3'   => __DIR__ . '/exhibiciontotal/exhibicion_sin_stock.php',
    'consulta_con_stock' => __DIR__ . '/consulta_stock/index.php',
    'consulta_sin_stock' => __DIR__ . '/consulta_sinstock/index.php',
    'usuarios'  => __DIR__ . '/controlusuarios/usuarios.php',
    'modulo2'   => __DIR__ . '/auditoria/auditoria.php',
    'perfil'    => __DIR__ . '/perfil/perfil.php',
    'permisos'  => __DIR__ . '/controlusuarios/permisos.php',
    'cobertura' => null,
    'bloqueo'   => null,
    'bloqueo_tienda'=> null,
    'cobertura_importar' => null,
    'puntas_gondolas'    => null,
];

$vista = (string) ($_GET['vista'] ?? 'dashboard');

if (!array_key_exists($vista, $vistas)) {
    $vista = 'dashboard';
}

if ($vista === 'permisos' && !$soyPropietario) {
    http_response_code(403);
    exit('Acceso denegado.');
}
if ($vista !== 'permisos' && !$acceso($vista)) {
    http_response_code(403);
    exit('No tienes permiso para abrir esta pantalla.');
}

$archivoVista = $vistas[$vista];
$flashOk  = (string) ($_SESSION['flash_ok'] ?? '');
$flashErr = (string) ($_SESSION['flash_err'] ?? '');
unset($_SESSION['flash_ok'], $_SESSION['flash_err']);

$paisNombre = match ($paisCode) {
    'HN' => 'Honduras',
    'NI' => 'Nicaragua',
    default => (string) ($_SESSION['pais'] ?? $paisCode),
};

$titulos = [
    // 'inicio' => 'Inicio',
    'dashboard' => 'Dashboard',
    'modulo1'   => 'Exhibición DT',
    'modulo3'   => 'Exhibición sin stock',
    'consulta_con_stock' => 'Consulta con Stock',
    'consulta_sin_stock' => 'Consulta sinStock',
    'usuarios'  => 'Control de usuarios',
    'modulo2'   => 'Auditoría',
    'perfil'    => 'Mi perfil',
    'permisos'  => 'Permisos por usuario',
    'cobertura' => 'Cobertura de Tiendas',
    'bloqueo'   => 'Bloqueo General',
    'bloqueo_tienda' => 'Bloqueo Tienda',
    'cobertura_importar' => 'Importar cobertura',
    'puntas_gondolas'    => 'Puntas Góndolas',
];

function menu_escapar(mixed $dato): string
{
    return htmlspecialchars((string) $dato, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function menu_url(string $vista): string
{
    return '/exhibicion_DT/index.php?vista=' . rawurlencode($vista);
}

function menu_renderizar(?string $archivo): void
{
    global $conn;
    if ($archivo !== null && is_file($archivo)) {
        include $archivo;
        return;
    }

    echo '<div class="alert alert-warning">No se encontró el archivo de esta pantalla.</div>';
}
?>
<!doctype html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title><?= menu_escapar($titulos[$vista]) ?></title>
    <link rel="icon" type="image/png" sizes="32x32" href="/exhibicion_DT/faviconDT/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/exhibicion_DT/faviconDT/favicon-16x16.png">
    <!-- Bootstrap CSS local -->
<link rel="stylesheet" href="bootstrap-5.3.8/css/bootstrap.min.css">

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="/exhibicion_DT/bootstrap-icons/bootstrap-icons.min.css">

<link rel="stylesheet" href="index.css">

</head>
<body class="metis-app">

<div class="metis-frame">
    <div class="metis-scrim" id="metisScrim" hidden></div>

    <aside class="metis-sidebar" id="metisSidebar" aria-label="Menú principal">
        <div class="metis-brand">
            <a href="<?= menu_url('dashboard') ?>" class="metis-brand-link" aria-label="Dashboard de Exhibición DT">
                <img src="/exhibicion_DT/img/DeTodo.png" alt="Logo" class="metis-logo">
                <span><strong></strong></span>
            </a>
            <button type="button" class="metis-icon-button metis-mobile-close" id="metisClose" aria-label="Cerrar menú">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <div class="metis-nav-scroll">
            <div class="metis-nav-label">PRINCIPAL</div>
            <nav class="metis-nav" aria-label="Pantallas disponibles">
                <?php if ($acceso('dashboard')): ?>
                    <a href="<?= menu_url('dashboard') ?>" data-search="dashboard estadísticas" class="metis-nav-link <?= $vista === 'dashboard' ? 'is-active' : '' ?>">
                        <i class="bi bi-graph-up-arrow"></i><span>Dashboard</span>
                    </a>
                <?php endif; ?>

                <?php if ($acceso('modulo1')): ?>
                <a href="<?= menu_url('modulo1') ?>" data-search="exhibicion dt registro articulos" class="metis-nav-link <?= $vista === 'modulo1' ? 'is-active' : '' ?>">
                   <i class="bi bi-boxes"></i><span>Exhibición DT</span>
                </a>
                <?php endif; ?>
                <?php if ($acceso('modulo3')): ?>
                <a href="<?= menu_url('modulo3') ?>" data-search="sin stock registro exhibicion" class="metis-nav-link <?= $vista === 'modulo3' ? 'is-active' : '' ?>">
                    <i class="bi bi-inbox"></i><span>Sin Stock (registro)</span>
                </a>
                <?php endif; ?>
                
            </nav>

            <?php if (
                $acceso('bloqueo') || $acceso('bloqueo_tienda') ||
                $acceso('consulta_con_stock') || $acceso('consulta_sin_stock') ||
                $acceso('cobertura') || $acceso('puntas_gondolas')
            ): ?>
            <div class="metis-nav-label">OTROS MÓDULOS</div>
            <nav class="metis-nav" aria-label="Módulos pendientes">
                <?php if ($acceso('bloqueo') || $acceso('bloqueo_tienda')): ?>
                <button class="metis-nav-link metis-nav-toggle <?= $vista === 'bloqueo' ? 'is-active' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#metisBloqueos" aria-expanded="<?= $vista === 'bloqueo' ? 'true' : 'false' ?>" aria-controls="metisBloqueos">
                    <i class="bi bi-clipboard-x"></i><span>Bloqueos</span><i class="bi bi-chevron-down metis-chevron"></i>
                </button>
               <div class="collapse metis-subnav <?= in_array($vista, ['bloqueo', 'bloqueo_tienda'], true) ? 'show' : '' ?>" id="metisBloqueos">
                <?php if ($acceso('bloqueo')): ?>
                <a href="<?= menu_url('bloqueo') ?>" data-search="bloqueo general rcp importar articulos" class="metis-nav-link <?= $vista === 'bloqueo' ? 'is-active' : '' ?>">Bloqueo General</a>
                    <?php endif; ?>
    
                <?php if ($acceso('bloqueo_tienda')): ?>
                <a href="<?= menu_url('bloqueo_tienda') ?>" data-search="bloqueo tienda rcp" class="metis-nav-link <?= $vista === 'bloqueo_tienda' ? 'is-active' : '' ?>">Bloqueo Tienda</a>
                <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php if ($acceso('consulta_con_stock') || $acceso('consulta_sin_stock')): ?>
                <button class="metis-nav-link metis-nav-toggle <?= in_array($vista, ['consulta_con_stock', 'consulta_sin_stock'], true) ? 'is-active' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#metisConsultas" aria-expanded="<?= in_array($vista, ['consulta_con_stock', 'consulta_sin_stock'], true) ? 'true' : 'false' ?>" aria-controls="metisConsultas">
                    <i class="bi bi-search"></i><span>Consultas de stock</span><i class="bi bi-chevron-down metis-chevron"></i>
                </button>
                <div class="collapse metis-subnav <?= in_array($vista, ['consulta_con_stock', 'consulta_sin_stock'], true) ? 'show' : '' ?>" id="metisConsultas">
                    <?php if ($acceso('consulta_con_stock')): ?>
                    <a href="<?= menu_url('consulta_con_stock') ?>" data-search="consulta con stock inventario" class="metis-nav-link <?= $vista === 'consulta_con_stock' ? 'is-active' : '' ?>">Con Stock</a>
                    <?php endif; ?>
                    <?php if ($acceso('consulta_sin_stock')): ?>
                    <a href="<?= menu_url('consulta_sin_stock') ?>" data-search="consulta sin stock inventario" class="metis-nav-link <?= $vista === 'consulta_sin_stock' ? 'is-active' : '' ?>">Sin Stock</a>

                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if ($acceso('cobertura')): ?>
                <button class="metis-nav-link metis-nav-toggle <?= in_array($vista, ['cobertura', 'cobertura_importar'], true) ? 'is-active' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#metisCobertura" aria-expanded="<?= in_array($vista, ['cobertura', 'cobertura_importar'], true) ? 'true' : 'false' ?>" aria-controls="metisCobertura">
                    <i class="bi bi-geo-alt"></i><span>Cobertura de Tiendas</span><i class="bi bi-chevron-down metis-chevron"></i>
                </button>
                <div class="collapse metis-subnav <?= in_array($vista, ['cobertura', 'cobertura_importar'], true) ? 'show' : '' ?>" id="metisCobertura">
                    <a href="<?= menu_url('cobertura') ?>" data-search="cobertura tiendas ver listado" class="metis-nav-link <?= $vista === 'cobertura' ? 'is-active' : '' ?>">Ver cobertura</a>
                </div>
                <?php endif; ?>

                <?php if ($acceso('puntas_gondolas')): ?>
                <button class="metis-nav-link metis-nav-toggle <?= $vista === 'puntas_gondolas' ? 'is-active' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#metisPuntas" aria-expanded="<?= $vista === 'puntas_gondolas' ? 'true' : 'false' ?>" aria-controls="metisPuntas">
                  <i class="bi bi-collection"></i><span>Puntas Góndolas</span><i class="bi bi-chevron-down metis-chevron"></i>
                </button>
                <div class="collapse metis-subnav <?= $vista === 'puntas_gondolas' ? 'show' : '' ?>" id="metisPuntas">
                    <a href="<?= menu_url('puntas_gondolas') ?>" data-search="ver puntas gondolas" class="metis-nav-link <?= $vista === 'puntas_gondolas' ? 'is-active' : '' ?>">Ver puntas</a>
                </div>
                <?php endif; ?>

            </nav>
            <?php endif; ?>

            <div class="metis-nav-label">ADMINISTRACIÓN</div>
            <nav class="metis-nav" aria-label="Administración">
                <?php if ($acceso('usuarios')): ?>
                    <a href="<?= menu_url('usuarios') ?>" data-search="usuarios control administracion" class="metis-nav-link <?= $vista === 'usuarios' ? 'is-active' : '' ?>">
                        <i class="bi bi-people"></i><span>Control de Usuarios</span>
                    </a>
                <?php endif; ?>
                <?php if ($acceso('modulo2')): ?>
                    <a href="<?= menu_url('modulo2') ?>" data-search="auditoria registros" class="metis-nav-link <?= $vista === 'modulo2' ? 'is-active' : '' ?>">
                    <i class="bi bi-clipboard-data"></i><span>Auditoría</span>
                    </a>
                <?php endif; ?>
                <?php if ($soyPropietario): ?>
                    <a href="<?= menu_url('permisos') ?>" data-search="permisos accesos usuario" class="metis-nav-link <?= $vista === 'permisos' ? 'is-active' : '' ?>">
               <i class="bi bi-person-gear"></i><span>Permisos por usuario</span>
                    </a>
                <?php endif; ?>
                <a href="<?= menu_url('perfil') ?>" data-search="perfil configuracion usuario" class="metis-nav-link <?= $vista === 'perfil' ? 'is-active' : '' ?>">
                    <i class="bi bi-person-workspace"></i><span>Perfil</span>
                </a>
            </nav>
        </div>

        <div class="metis-sidebar-footer">
            <a class="metis-nav-link metis-logout" href="/exhibicion_DT/controlusuarios/logout.php">
                <i class="bi bi-box-arrow-right"></i><span>Cerrar sesión</span>
            </a>
        </div>
    </aside>

    <div class="metis-workspace">
        <!-- Barra superior: buscar, zoom, tema, colores y pantalla completa -->
        <header class="metis-topbar">
            <div class="metis-topbar-left">
                <button type="button" class="metis-icon-button" id="metisMenuToggle" aria-label="Abrir o cerrar menú" title="Menú">
                    <i class="bi bi-list"></i>
                </button>
                <div class="metis-search-wrap">
                    <i class="bi bi-search"></i>
                    <input id="metisSearch" type="search" autocomplete="off" placeholder="Buscar pantalla... (Ctrl + K)" aria-label="Buscar pantalla">
                    <div class="metis-search-results" id="metisSearchResults" hidden></div>
                </div>
            </div>

            <div class="metis-topbar-actions">
                <div class="metis-zoom-controls" aria-label="Zoom de contenido">
                    <button type="button" class="metis-icon-button" id="metisZoomOut" title="Reducir zoom" aria-label="Reducir zoom"><i class="bi bi-dash-lg"></i></button>
                    <button type="button" class="metis-zoom-level" id="metisZoomReset" title="Restablecer zoom">100%</button>
                    <button type="button" class="metis-icon-button" id="metisZoomIn" title="Aumentar zoom" aria-label="Aumentar zoom"><i class="bi bi-plus-lg"></i></button>
                </div>
                <button type="button" class="metis-icon-button" id="metisTheme" title="Cambiar tema claro/oscuro" aria-label="Cambiar tema"><i class="bi bi-moon"></i></button>
                <div class="dropdown">
                    <button type="button" class="metis-icon-button" id="metisAccentMenu" data-bs-toggle="dropdown" aria-expanded="false" title="Cambiar color" aria-label="Cambiar color"><i class="bi bi-palette"></i></button>
                    <div class="dropdown-menu dropdown-menu-end metis-accent-menu" aria-labelledby="metisAccentMenu">
                        <div class="metis-dropdown-heading">Color principal</div>
                        <button type="button" class="metis-color-choice" data-color="blue"><span style="background:#2563eb"></span>Azul</button>
                        <button type="button" class="metis-color-choice" data-color="purple"><span style="background:#7251dd"></span>Morado</button>
                        <button type="button" class="metis-color-choice" data-color="green"><span style="background:#16845d"></span>Verde</button>
                    </div>
                </div>
                <button type="button" class="metis-icon-button metis-fullscreen" id="metisFullscreen" title="Pantalla completa" aria-label="Pantalla completa"><i class="bi bi-arrows-fullscreen"></i></button>
                <div class="dropdown">
                    <button type="button" class="metis-user-button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if ($fotoMenuUrl !== ''): ?>
                            <img class="metis-user-avatar" src="<?= menu_escapar($fotoMenuUrl) ?>" alt="Foto de perfil">
                        <?php else: ?>
                            <span class="metis-user-avatar"><?= menu_escapar(strtoupper(substr($usuario !== '' ? $usuario : 'U', 0, 1))) ?></span>
                        <?php endif; ?>
                        <span class="metis-user-text"><strong><?= menu_escapar($usuario) ?></strong><small><?= menu_escapar(str_replace('_', ' ', $rol)) ?></small></span>
                        <i class="bi bi-chevron-down"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?= menu_url('perfil') ?>"><i class="bi bi-person me-2"></i>Mi perfil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/exhibicion_DT/controlusuarios/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <main class="metis-main" id="metisContent">
            <?php if ($vista === 'inicio'): ?>
            <div class="metis-page-heading">
                <div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($flashOk !== ''): ?>
                <div class="alert alert-success" role="alert"><?= menu_escapar($flashOk) ?></div>
            <?php endif; ?>
            <?php if ($flashErr !== ''): ?>
                <div class="alert alert-danger" role="alert"><?= menu_escapar($flashErr) ?></div>
            <?php endif; ?>

            <?php if ($vista === 'inicio'): ?>
                <section class="metis-welcome">
                    <div>
                        <span class="metis-welcome-tag">PANEL PRINCIPAL</span>
                        <h2>Bienvenido a Exhibición DT</h2>
                        <p>Selecciona un módulo autorizado para tu cuenta.</p>
                        <div class="metis-user-meta">
                            <span><i class="bi bi-person-badge"></i> <?= menu_escapar($rol) ?></span>
                            <?php if ($tienda !== ''): ?><span><i class="bi bi-shop"></i> <?= menu_escapar($tienda) ?></span><?php endif; ?>
                            <?php if ($zona !== ''): ?><span><i class="bi bi-pin-map"></i> <?= menu_escapar($zona) ?></span><?php endif; ?>
                        </div>
                    </div>
                    <img src="/exhibicion_DT/img/logo.png" alt="Logo de la empresa">
                </section>

                <section class="metis-shortcuts" aria-label="Accesos directos">
                    <?php foreach ([
                        'modulo1' => ['bi-box-seam', 'Exhibición DT'],
                        'modulo3' => ['bi-clipboard2-check', 'Sin Stock'],
                        'consulta_con_stock' => ['bi-box-seam', 'Consulta con Stock'],
                        'consulta_sin_stock' => ['bi-box-seam', 'Consulta sin Stock'],
                        'cobertura' => ['bi-geo-alt', 'Cobertura de Tiendas'],
                        'puntas_gondolas' => ['bi-shop', 'Puntas Góndolas'],
                        'bloqueo' => ['bi-shield-lock', 'Bloqueo General'],
                        'bloqueo_tienda' => ['bi-shield-lock', 'Bloqueo Tienda'],
                        'usuarios' => ['bi-people', 'Control de usuarios'],
                        'modulo2' => ['bi-journal-text', 'Auditoría'],
                    ] as $codigo => [$icono, $etiqueta]): ?>
                        <?php if ($acceso($codigo)): ?>
                            <a href="<?= menu_url($codigo) ?>" class="metis-shortcut">
                                <span class="metis-shortcut-icon"><i class="bi <?= menu_escapar($icono) ?>"></i></span>
                                <strong><?= menu_escapar($etiqueta) ?></strong>
                                <small>Abrir módulo</small><i class="bi bi-arrow-right"></i>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </section>
            <?php elseif ($vista === 'bloqueo'): ?>
                <!-- El módulo RCP conserva sus archivos y controles de acceso. -->
                <section class="metis-module-panel metis-cobertura-panel metis-bloqueo-panel">
                    <iframe
                        id="metisBloqueoFrame"
                        class="metis-cobertura-frame"
                        title="Bloqueo General RCP"
                        src="/exhibicion_DT/bloqueogeneral/index.php"
                        loading="eager"
                        referrerpolicy="same-origin"
                    ></iframe>
                </section>
             
            <?php elseif ($vista === 'bloqueo_tienda'): ?>
                <section class="metis-module-panel metis-cobertura-panel metis-bloqueo-panel">
                    <iframe
                        id="metisBloqueoTiendaFrame"
                        class="metis-cobertura-frame"
                        title="Bloqueo Tienda RCP"
                        src="/exhibicion_DT/bloqueotienda/index.php"
                        loading="eager"
                        referrerpolicy="same-origin"></iframe>
                </section>
            <?php elseif (in_array($vista, ['cobertura', 'cobertura_importar'], true)): ?>
                <!-- Cobertura conserva sesiones y formularios. -->
                <section class="metis-module-panel metis-cobertura-panel">
                    <iframe
                        id="metisCoberturaFrame"
                        class="metis-cobertura-frame"
                        title="<?= menu_escapar($titulos[$vista]) ?>"
                        src="/exhibicion_DT/cobertura/<?= $vista === 'cobertura_importar' ? 'importar.php' : 'index.php' ?>"
                        loading="eager"
                        referrerpolicy="same-origin"
                    ></iframe>
                </section>
            <?php elseif ($vista === 'puntas_gondolas'): ?>
                <!-- Puntas Góndolas con iframe -->
                <section class="metis-module-panel metis-cobertura-panel metis-bloqueo-panel">
                    <iframe
                        id="metisPuntasGondolasFrame"
                        class="metis-cobertura-frame"
                        title="Puntas Góndolas"
                        src="/exhibicion_DT/puntas/index.php"
                        loading="eager"
                        referrerpolicy="same-origin"
                    ></iframe>
                </section>
            <?php else: ?>
                <section class="metis-module-panel <?= $vista === 'permisos' ? 'metis-permisos-panel' : '' ?>">
                    <?php menu_renderizar($archivoVista); ?>
                </section>
            <?php endif; ?>
        </main>
    </div>
</div>

<!-- Bootstrap JS local -->
<script src="bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>


<script src="/exhibicion_DT/index.js?v=<?= filemtime(__DIR__ . '/index.js') ?>"></script>

</body>
</html>