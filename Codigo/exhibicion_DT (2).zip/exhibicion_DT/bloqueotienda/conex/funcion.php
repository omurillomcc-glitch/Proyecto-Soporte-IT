<?php
declare(strict_types=1);

/* Bloqueo individual: país, compañía, tienda, PLU y referencia. */
const RCP_TABLA = '[vistasMCC].[dbo].[TB_DT_RCP_ARTICULOBLOQUEOTIENDA]';
const RCP_COMPANIA = 'DETODO';

function rcp_base_articulos(string $pais): string
{
    return $pais === 'NICARAGUA' ? '[ACANICARAGUA2]' : '[DETODO]';
}

function rcp_clave_sql(string $columna): string
{
    return "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$columna}))) COLLATE DATABASE_DEFAULT";
}

function rcp_plu_variantes_sql(string $columna, string $pais): string
{
    $plu = "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$columna})))";
    $sinPais = "CASE WHEN UPPER(RIGHT({$plu}, 2)) IN ('HN', 'NI')
        THEN LEFT({$plu}, LEN({$plu}) - 2) ELSE {$plu} END";
    $sinCeros = "CONVERT(VARCHAR(20), TRY_CONVERT(DECIMAL(20, 0), {$sinPais}))";
    $relleno = "CASE WHEN TRY_CONVERT(DECIMAL(20, 0), {$sinPais}) IS NOT NULL
            AND LEN({$sinPais}) <= 12
        THEN RIGHT('000000000000' + {$sinPais}, 12) END";
    $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
    return "({$plu} COLLATE DATABASE_DEFAULT, {$sinPais} COLLATE DATABASE_DEFAULT,
        {$sinCeros} COLLATE DATABASE_DEFAULT, {$relleno} COLLATE DATABASE_DEFAULT,
        ({$sinPais} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$sinCeros} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$relleno} + '{$sufijo}') COLLATE DATABASE_DEFAULT)";
}

function rcp_plu_candidatos(string $plu, string $pais): array
{
    $plu = trim($plu);
    $base = preg_replace('/(?:HN|NI)$/i', '', $plu) ?? $plu;
    $candidatos = [$plu, $base];
    if ($base !== '' && ctype_digit($base) && strlen($base) <= 12) {
        $sinCeros = ltrim($base, '0') ?: '0';
        $relleno = str_pad($base, 12, '0', STR_PAD_LEFT);
        $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
        array_push($candidatos, $sinCeros, $relleno,
            $base . $sufijo, $sinCeros . $sufijo, $relleno . $sufijo);
    }
    return array_values(array_unique($candidatos));
}

function rcp_sql_bloqueos(): string
{
    $tienda = rcp_clave_sql('B.vStoreId');
    $plu = rcp_clave_sql('B.vPlu');
    $ref = rcp_clave_sql('B.vReferencia');
    return "
        WITH Bloqueos AS (
            SELECT B.vIdPais, B.vIdCompany,
                   {$tienda} AS tienda,
                   {$plu} AS vPlu,
                   {$ref} AS vReferencia,
                   MIN(B.FechaRegistro) AS FechaRegistro,
                   COUNT_BIG(*) AS cantidadOriginal
            FROM " . RCP_TABLA . " B
            WHERE B.vIdPais = ? AND B.vIdCompany = ?
            GROUP BY B.vIdPais, B.vIdCompany, {$tienda}, {$plu}, {$ref}
        )
    ";
}

function rcp_sql_catalogo_apply(string $pais, string $alias = 'B'): string
{
    $base = rcp_base_articulos($pais);
    return "
            OUTER APPLY (
                SELECT TOP (1)
                      CONVERT(VARCHAR(100), A.CODARTICULO) AS CODARTICULO,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS DESCRIPCION,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), D.DESCRIPCION))) AS DEPARTAMENTO,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), SC.DESCRIPCION))) AS SECCION,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), F.DESCRIPCION))) AS FAMILIA
                FROM {$base}.dbo.ARTICULOS A
                INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
                    ON CL.CODARTICULO = A.CODARTICULO
                LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
                LEFT JOIN {$base}.dbo.SECCIONES SC
                    ON SC.NUMDPTO = A.DPTO AND SC.NUMSECCION = A.SECCION
                LEFT JOIN {$base}.dbo.FAMILIAS F
                    ON F.NUMDPTO = A.DPTO AND F.NUMSECCION = A.SECCION
                    AND F.NUMFAMILIA = A.FAMILIA
                WHERE CL.PLU = {$alias}.vPlu
                ORDER BY CASE
                       WHEN A.REFPROVEEDOR = {$alias}.vReferencia COLLATE DATABASE_DEFAULT THEN 0
                       ELSE 1
                    END,
                    CASE WHEN A.DESCATALOGADO = 'F' THEN 0 ELSE 1 END,
                    A.CODARTICULO
            ) P
            OUTER APPLY (
                SELECT TOP (1)
                      CONVERT(VARCHAR(100), A.CODARTICULO) AS CODARTICULO,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS DESCRIPCION,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), D.DESCRIPCION))) AS DEPARTAMENTO,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), SC.DESCRIPCION))) AS SECCION,
                      LTRIM(RTRIM(CONVERT(NVARCHAR(255), F.DESCRIPCION))) AS FAMILIA
                FROM {$base}.dbo.ARTICULOS A
                LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
                LEFT JOIN {$base}.dbo.SECCIONES SC
                    ON SC.NUMDPTO = A.DPTO AND SC.NUMSECCION = A.SECCION
                LEFT JOIN {$base}.dbo.FAMILIAS F
                    ON F.NUMDPTO = A.DPTO AND F.NUMSECCION = A.SECCION
                    AND F.NUMFAMILIA = A.FAMILIA
                WHERE (P.CODARTICULO IS NULL OR P.FAMILIA IS NULL)
                  AND A.REFPROVEEDOR = {$alias}.vReferencia COLLATE DATABASE_DEFAULT
                ORDER BY CASE WHEN A.DESCATALOGADO = 'F' THEN 0 ELSE 1 END,
                    A.CODARTICULO
            ) R
    ";
}

function rcp_sql_datos(string $pais): string
{
    $base = rcp_base_articulos($pais);
    return rcp_sql_bloqueos() . ",
        Datos AS (
            SELECT B.vIdPais AS pais, B.vIdCompany AS compania,
                   B.tienda, B.vPlu AS plu, B.vReferencia AS referencia,
                   CONVERT(VARCHAR(10), B.FechaRegistro, 23) AS fecha,
                   B.cantidadOriginal AS repetidosOrigen,
                   LTRIM(RTRIM(CONVERT(NVARCHAR(200), ALM.NOMBREALMACEN))) AS nombre_tienda,
                   COALESCE(P.CODARTICULO, R.CODARTICULO) AS codarticulo,
                   COALESCE(R.DESCRIPCION, P.DESCRIPCION) AS descripcion,
                   COALESCE(R.DEPARTAMENTO, P.DEPARTAMENTO) AS departamento,
                   COALESCE(R.SECCION, P.SECCION) AS seccion,
                   COALESCE(R.FAMILIA, P.FAMILIA) AS familia
            FROM Bloqueos B
            LEFT JOIN {$base}.dbo.ALMACEN ALM
                ON " . rcp_clave_sql('ALM.CODALMACEN') . " = B.tienda COLLATE DATABASE_DEFAULT
            " . rcp_sql_catalogo_apply($pais) . "
        )
    ";
}

function rcp_columnas_filtro(): array
{
    return [
        'tienda' => 'D.tienda', 'plu' => 'D.plu',
        'referencia' => 'D.referencia', 'descripcion' => 'D.descripcion',
        'departamento' => 'D.departamento', 'seccion' => 'D.seccion',
        'familia' => 'D.familia', 'fecha' => 'D.fecha',
    ];
}

function rcp_sql_filtros(array $filtros, array &$params, string $omitir = ''): string
{
    $sql = '';
    foreach (rcp_columnas_filtro() as $campo => $columna) {
        if ($campo === $omitir) continue;
        $valor = trim((string)($filtros[$campo] ?? ''));
        if ($valor === '') continue;
        if (rcp_longitud_texto($valor) > 1500) {
            throw new InvalidArgumentException('El filtro es demasiado largo.');
        }
        $exp = "LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(255), {$columna}), N''))) COLLATE DATABASE_DEFAULT";
        if (str_starts_with($valor, '__LIKE__')) {
            $valor = trim(substr($valor, 8));
            if ($valor !== '') {
                $sql .= " AND {$exp} LIKE ? COLLATE DATABASE_DEFAULT";
                $params[] = '%' . $valor . '%';
            }
            continue;
        }
        $valores = array_values(array_unique(array_filter(array_map('trim', explode('||', $valor)), 'strlen')));
        if (count($valores) > 60) {
            throw new InvalidArgumentException('Seleccione menos opciones del filtro.');
        }
        if ($valores) {
            $sql .= " AND {$exp} IN (" . implode(', ', array_fill(0, count($valores), '?')) . ')';
            array_push($params, ...$valores);
        }
    }
    return $sql;
}

/* Aplica el alcance autorizado antes de ordenar y paginar. */
function rcp_sql_alcance_tiendas(array &$params, string $columna = 'D.tienda'): string
{
    $permitidas = $GLOBALS['rcp_tiendas_permitidas'] ?? null;
    if ($permitidas === null) return '';
    if (!$permitidas) return ' AND 1 = 0';
    $marcas = implode(',', array_fill(0, count($permitidas), '?'));
    array_push($params, ...$permitidas);
    return " AND {$columna} COLLATE DATABASE_DEFAULT IN ({$marcas})";
}

function rcp_listado($conn, string $pais, int $pagina, int $porPagina, array $filtros = [], string $ordenCampo = 'fecha', string $ordenDir = 'desc'): array
{
    $pagina = max(1, $pagina);
    $porPagina = in_array($porPagina, [50, 100, 250, 500, 1000], true) ? $porPagina : 50;
    $columnas = rcp_columnas_filtro();
    $hayFiltros = count(array_filter(
        $filtros,
        static fn($valor): bool => trim((string)$valor) !== ''
    )) > 0;
    if ($ordenCampo !== 'numero' && !isset($columnas[$ordenCampo])) $ordenCampo = 'fecha';
    $direccion = strtolower($ordenDir) === 'asc' ? 'ASC' : 'DESC';
    $paginaRapida = !$hayFiltros && $ordenCampo === 'fecha';
    if ($paginaRapida) {
        $params = [$pais, RCP_COMPANIA];
        $alcance = rcp_sql_alcance_tiendas($params, 'B.tienda');
        $params[] = ($pagina - 1) * $porPagina;
        $params[] = $porPagina;
        $sql = rcp_sql_bloqueos() . ",
            Pagina AS (
                SELECT B.*, COUNT_BIG(*) OVER() AS totalFiltrado
                FROM Bloqueos B
                WHERE 1 = 1 {$alcance}
                ORDER BY B.FechaRegistro {$direccion}, B.tienda ASC,
                    B.vPlu ASC, B.vReferencia ASC
                OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
            ),
            Datos AS (
                SELECT B.vIdPais AS pais, B.vIdCompany AS compania,
                       B.tienda, B.vPlu AS plu, B.vReferencia AS referencia,
                       CONVERT(VARCHAR(10), B.FechaRegistro, 23) AS fecha,
                       B.cantidadOriginal AS repetidosOrigen,
                       B.totalFiltrado,
                       LTRIM(RTRIM(CONVERT(NVARCHAR(200), ALM.NOMBREALMACEN))) AS nombre_tienda,
                       COALESCE(P.CODARTICULO, R.CODARTICULO) AS codarticulo,
                       COALESCE(R.DESCRIPCION, P.DESCRIPCION) AS descripcion,
                       COALESCE(R.DEPARTAMENTO, P.DEPARTAMENTO) AS departamento,
                       COALESCE(R.SECCION, P.SECCION) AS seccion,
                       COALESCE(R.FAMILIA, P.FAMILIA) AS familia
                FROM Pagina B
                LEFT JOIN " . rcp_base_articulos($pais) . ".dbo.ALMACEN ALM
                    ON " . rcp_clave_sql('ALM.CODALMACEN') . " = B.tienda COLLATE DATABASE_DEFAULT
                " . rcp_sql_catalogo_apply($pais) . "
            )
            SELECT D.*
            FROM Datos D
            ORDER BY D.fecha {$direccion}, D.tienda ASC, D.plu ASC, D.referencia ASC
        ";
    } else {
        $params = [$pais, RCP_COMPANIA];
        $sql = rcp_sql_datos($pais) . ' SELECT D.*, COUNT_BIG(*) OVER() AS totalFiltrado FROM Datos D WHERE 1=1';
        $sql .= rcp_sql_alcance_tiendas($params);
        $sql .= rcp_sql_filtros($filtros, $params);
        if (in_array($ordenCampo, ['plu', 'numero'], true)) {
            $prefijo = "LEFT(D.plu, PATINDEX('%[^0-9]%', D.plu + 'X') - 1)";
            $numero = "TRY_CONVERT(DECIMAL(38,0), {$prefijo})";
            $sql .= " ORDER BY CASE WHEN {$numero} IS NULL THEN 1 ELSE 0 END, {$numero} {$direccion}, D.plu {$direccion}, D.tienda ASC, D.referencia ASC";
        } else {
            $col = $columnas[$ordenCampo];
            $sql .= " ORDER BY CONVERT(NVARCHAR(255), {$col}) COLLATE DATABASE_DEFAULT {$direccion}, D.tienda ASC, D.plu ASC, D.referencia ASC";
        }
        $sql .= ' OFFSET ? ROWS FETCH NEXT ? ROWS ONLY';
        $params[] = ($pagina - 1) * $porPagina;
        $params[] = $porPagina;
    }
    $stmt = rcp_ejecutar($conn, $sql, $params);
    $rows = []; $total = 0;
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $total = (int)($row['totalFiltrado'] ?? 0);
        unset($row['totalFiltrado']);
        $rows[] = $row;
    }
    sqlsrv_free_stmt($stmt);
    if ($pagina === 1 && !$rows) $total = 0;
    return ['rows' => $rows, 'total' => $total, 'page' => $pagina,
        'per' => $porPagina, 'filtered' => $hayFiltros];
}

function rcp_valores_filtro($conn, string $pais, string $campo, string $busqueda = '', array $filtros = []): array
{
    $columnas = rcp_columnas_filtro();
    if (!isset($columnas[$campo])) throw new InvalidArgumentException('Columna no permitida.');
    $busqueda = trim($busqueda);
    if (rcp_longitud_texto($busqueda) > 100) throw new InvalidArgumentException('Búsqueda demasiado larga.');
    $params = [$pais, RCP_COMPANIA];
    $expr = "LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(255), {$columnas[$campo]}), N''))) COLLATE DATABASE_DEFAULT";
    $sql = rcp_sql_datos($pais) . " SELECT DISTINCT {$expr} AS valor FROM Datos D WHERE {$expr} <> N''";
    $sql .= rcp_sql_alcance_tiendas($params);
    $sql .= rcp_sql_filtros($filtros, $params, $campo);
    if ($busqueda !== '') {
        $sql .= " AND {$expr} LIKE ? COLLATE DATABASE_DEFAULT";
        $params[] = '%' . $busqueda . '%';
    }
    $sql .= ' ORDER BY valor ASC';
    $stmt = rcp_ejecutar($conn, $sql, $params);
    $values = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) $values[] = (string)($row['valor'] ?? '');
    sqlsrv_free_stmt($stmt);
    return ['values' => $values, 'has_more' => false];
}

function rcp_tiendas_disponibles($conn, string $pais): array
{
    $base = rcp_base_articulos($pais);
    $permitidas = $GLOBALS['rcp_tiendas_permitidas'] ?? null;
    if ($permitidas !== null && !$permitidas) return [];
    
    $params = [];
    $sql = "SELECT DISTINCT CONVERT(VARCHAR(12), A.CODALMACEN) AS codigo,
            CONVERT(NVARCHAR(200), A.NOMBREALMACEN) AS nombre
            FROM {$base}.dbo.ALMACEN A
            WHERE TRY_CONVERT(INT, A.CODALMACEN) IS NOT NULL
              AND LEN(LTRIM(RTRIM(CONVERT(VARCHAR(12), A.CODALMACEN)))) BETWEEN 1 AND 4
              -- Excluimos almacenes/tiendas no deseados según su nombre
              AND UPPER(LTRIM(RTRIM(ISNULL(A.NOMBREALMACEN, '')))) NOT LIKE '%NO USRA%'
              AND UPPER(LTRIM(RTRIM(ISNULL(A.NOMBREALMACEN, '')))) NOT LIKE '%ACA JOE%'
              AND UPPER(LTRIM(RTRIM(ISNULL(A.NOMBREALMACEN, '')))) NOT LIKE '%ALMACEN%'
              AND UPPER(LTRIM(RTRIM(ISNULL(A.NOMBREALMACEN, '')))) NOT LIKE '%MERCADEO%'
              AND UPPER(LTRIM(RTRIM(ISNULL(A.NOMBREALMACEN, '')))) NOT LIKE '%OPERACIONES%'";

    if ($permitidas !== null) {
        $sql .= ' AND ' . rcp_clave_sql('A.CODALMACEN') . ' IN ('
            . implode(',', array_fill(0, count($permitidas), '?')) . ')';
        $params = $permitidas;
    }

    $sql .= ' ORDER BY codigo';
    $stmt = rcp_ejecutar($conn, $sql, $params);
    $rows = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) $rows[] = $row;
    sqlsrv_free_stmt($stmt);
    return $rows;
}

/* Convierte un código, nombre o etiqueta del catálogo al vStoreId real. */
function rcp_resolver_tienda($conn, string $pais, mixed $valor, ?array $catalogo = null): string
{
    $entrada = rcp_validar_texto($valor, 220, 'tienda');
    if (preg_match('/^\d{1,4}$/D', $entrada)) {
        rcp_verificar_alcance_tienda($entrada);
        return $entrada;
    }
    $catalogo ??= rcp_tiendas_disponibles($conn, $pais);
    $normalizar = static function (string $texto): string {
        return rcp_mayusculas(trim((string)preg_replace('/\s+/u', ' ', $texto)));
    };
    $busqueda = $normalizar($entrada);
    $coincidencias = [];

    foreach ($catalogo as $tienda) {
        $codigo = trim((string)($tienda['codigo'] ?? ''));
        $nombre = trim((string)($tienda['nombre'] ?? ''));
        if ($codigo === '' || !preg_match('/^\d{1,4}$/D', $codigo)) continue;

        // El código tiene prioridad sobre nombres que parezcan números.
        if ($codigo === $entrada) return $codigo;
        if ($nombre !== '' && (
            $normalizar($nombre) === $busqueda
            || $normalizar($codigo . ' · ' . $nombre) === $busqueda
        )) {
            $coincidencias[$codigo] = true;
        }
    }

    if (count($coincidencias) === 1) {
        $codigo = (string)array_key_first($coincidencias);
        rcp_verificar_alcance_tienda($codigo);
        return $codigo;
    }
    if (count($coincidencias) > 1) {
        throw new InvalidArgumentException('Varias tiendas tienen ese nombre. Indique el código de la tienda.');
    }
    throw new InvalidArgumentException('Tienda no encontrada o sin autorización. Revise el código o nombre.');
}

function rcp_tienda_existe($conn, string $pais, string $tienda): bool
{
    rcp_verificar_alcance_tienda($tienda);
    $base = rcp_base_articulos($pais);
    $stmt = rcp_ejecutar($conn, "SELECT TOP (1) 1 AS ok FROM {$base}.dbo.ALMACEN A
        WHERE " . rcp_clave_sql('A.CODALMACEN') . " = ? COLLATE DATABASE_DEFAULT", [$tienda]);
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);
    return is_array($row);
}

function rcp_producto_existe($conn, string $pais, string $plu, string $ref): bool
{
    $base = rcp_base_articulos($pais);
    $candidatos = rcp_plu_candidatos($plu, $pais);
    $stmt = rcp_ejecutar($conn, "SELECT TOP (1) 1 AS ok FROM {$base}.dbo.ARTICULOS A
        INNER JOIN {$base}.dbo.ARTICULOSCAMPOSLIBRES CL ON CL.CODARTICULO=A.CODARTICULO
        WHERE A.DESCATALOGADO = 'F'
          AND CL.PLU IN (" . implode(', ', array_fill(0, count($candidatos), '? COLLATE DATABASE_DEFAULT')) . ")
          AND " . rcp_clave_sql('A.REFPROVEEDOR') . " = ? COLLATE DATABASE_DEFAULT",
        [...$candidatos, $ref]);
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    sqlsrv_free_stmt($stmt);
    return is_array($row);
}
function rcp_insertar($conn, string $pais, string $tienda, string $plu, string $ref): bool
{
    $sql = 'INSERT INTO ' . RCP_TABLA . ' (vIdPais, vIdCompany, vStoreId, vPlu, vReferencia, FechaRegistro)
        SELECT ?, ?, ?, ?, ?, CAST(GETDATE() AS DATE)
        WHERE NOT EXISTS (SELECT 1 FROM ' . RCP_TABLA . ' B WITH (UPDLOCK,HOLDLOCK)
          WHERE B.vIdPais=? AND B.vIdCompany=?
          AND ' . rcp_clave_sql('B.vStoreId') . '=? COLLATE DATABASE_DEFAULT
          AND ' . rcp_clave_sql('B.vPlu') . '=? COLLATE DATABASE_DEFAULT
          AND ' . rcp_clave_sql('B.vReferencia') . '=? COLLATE DATABASE_DEFAULT)';
    $params = [$pais, RCP_COMPANIA, $tienda, $plu, $ref, $pais, RCP_COMPANIA, $tienda, $plu, $ref];
    $stmt = rcp_ejecutar($conn, $sql, $params);
    $n = sqlsrv_rows_affected($stmt);
    sqlsrv_free_stmt($stmt);
    if ($n === false || $n < 0) throw new RuntimeException('No se pudo confirmar la inserción.');
    
    $insertado = ($n === 1);
    
    if ($insertado) {
        $baseArt = rcp_base_articulos($pais);
        
        // 1. Obtener la descripción del artículo
        $sqlCat = "SELECT TOP (1) LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS descripcion 
                   FROM {$baseArt}.dbo.ARTICULOS A
                   INNER JOIN {$baseArt}.dbo.ARTICULOSCAMPOSLIBRES CL ON CL.CODARTICULO = A.CODARTICULO
                   WHERE CL.PLU = ? COLLATE DATABASE_DEFAULT";
        $stmtCat = rcp_ejecutar($conn, $sqlCat, [$plu]);
        $rowCat = sqlsrv_fetch_array($stmtCat, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtCat);
        $nombreArticulo = $rowCat['descripcion'] ?? 'N/D';

        // 2. Obtener el nombre de la tienda
        $sqlTienda = "SELECT TOP (1) LTRIM(RTRIM(CONVERT(NVARCHAR(200), NOMBREALMACEN))) AS nombre 
                      FROM {$baseArt}.dbo.ALMACEN 
                      WHERE " . rcp_clave_sql('CODALMACEN') . " = ? COLLATE DATABASE_DEFAULT";
        $stmtTienda = rcp_ejecutar($conn, $sqlTienda, [$tienda]);
        $rowTienda = sqlsrv_fetch_array($stmtTienda, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtTienda);
        $nombreTienda = $rowTienda['nombre'] ?? $tienda;

        $detalleFormateado = "Creado:\n- Tienda: {$nombreTienda}\n- PLU: {$plu}\n- Referencia: {$ref}";
        $mensajeFinal = sprintf(
            "PLU: %s\nArtículo: %s\n%s\nREGION: %s",
            $plu,
            $nombreArticulo,
            $detalleFormateado,
            strtoupper($pais)
        );

        if (function_exists('rcp_registrar')) {
            rcp_registrar('RCP_BLOQUEO_AGREGADO', $mensajeFinal, $pais);
        }
    }
    
    return $insertado;
}

function rcp_editar($conn, string $pais, string $tiendaOrigen, string $pluOrigen,
                     string $refOrigen, string $tienda, string $plu, string $ref): void
{
    if (!sqlsrv_begin_transaction($conn)) rcp_error_sql('inicio transacción');
    try {
        $cond = 'vIdPais=? AND vIdCompany=? AND ' . rcp_clave_sql('vStoreId') . '=? COLLATE DATABASE_DEFAULT
             AND ' . rcp_clave_sql('vPlu') . '=? COLLATE DATABASE_DEFAULT
             AND ' . rcp_clave_sql('vReferencia') . '=? COLLATE DATABASE_DEFAULT';
        $sqlCount = 'SELECT COUNT_BIG(*) AS total FROM ' . RCP_TABLA . ' WITH (UPDLOCK,HOLDLOCK) WHERE ' . $cond;
        $s = rcp_ejecutar($conn, $sqlCount, [$pais, RCP_COMPANIA, $tiendaOrigen, $pluOrigen, $refOrigen]);
        $o = sqlsrv_fetch_array($s, SQLSRV_FETCH_ASSOC); sqlsrv_free_stmt($s);
        if ((int)($o['total'] ?? 0) !== 1) throw new InvalidArgumentException('El registro original no es único.');
        
        $s = rcp_ejecutar($conn, $sqlCount, [$pais, RCP_COMPANIA, $tienda, $plu, $ref]);
        $d = sqlsrv_fetch_array($s, SQLSRV_FETCH_ASSOC); sqlsrv_free_stmt($s);
        $mismo = $tienda === $tiendaOrigen && $plu === $pluOrigen && $ref === $refOrigen;
        if ((int)($d['total'] ?? 0) > ($mismo ? 1 : 0)) throw new InvalidArgumentException('El bloqueo ya existe en esa tienda.');
        
        $stmt = rcp_ejecutar($conn, 'UPDATE ' . RCP_TABLA . ' SET vStoreId=?, vPlu=?, vReferencia=? WHERE ' . $cond,
            [$tienda, $plu, $ref, $pais, RCP_COMPANIA, $tiendaOrigen, $pluOrigen, $refOrigen]);
        $n = sqlsrv_rows_affected($stmt); sqlsrv_free_stmt($stmt);
        if ($n !== 1) throw new RuntimeException('No se pudo actualizar un único registro.');
        
        if (!sqlsrv_commit($conn)) rcp_error_sql('confirmación');

        $baseArt = rcp_base_articulos($pais);

        // Obtener nombres de tiendas (origen y destino) para el control de cambios
        $sqlTiendas = "SELECT CODALMACEN, LTRIM(RTRIM(CONVERT(NVARCHAR(200), NOMBREALMACEN))) AS nombre 
                       FROM {$baseArt}.dbo.ALMACEN 
                       WHERE " . rcp_clave_sql('CODALMACEN') . " IN (?, ?) COLLATE DATABASE_DEFAULT";
        $stmtT = rcp_ejecutar($conn, $sqlTiendas, [$tiendaOrigen, $tienda]);
        $nombresTiendas = [];
        while ($tRow = sqlsrv_fetch_array($stmtT, SQLSRV_FETCH_ASSOC)) {
            $nombresTiendas[trim((string)$tRow['CODALMACEN'])] = $tRow['nombre'];
        }
        sqlsrv_free_stmt($stmtT);

        $nombreTiendaOrigen = $nombresTiendas[$tiendaOrigen] ?? $tiendaOrigen;
        $nombreTiendaDestino = $nombresTiendas[$tienda] ?? $tienda;

        $cambios = [];
        if ($tiendaOrigen !== $tienda) $cambios[] = "Tienda: {$nombreTiendaOrigen} -> {$nombreTiendaDestino}";
        if ($pluOrigen !== $plu) $cambios[] = "PLU: {$pluOrigen} -> {$plu}";
        if ($refOrigen !== $ref) $cambios[] = "Referencia: {$refOrigen} -> {$ref}";

        if ($cambios) {
            $sqlCat = "SELECT TOP (1) LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS descripcion 
                       FROM {$baseArt}.dbo.ARTICULOS A
                       INNER JOIN {$baseArt}.dbo.ARTICULOSCAMPOSLIBRES CL ON CL.CODARTICULO = A.CODARTICULO
                       WHERE CL.PLU = ? COLLATE DATABASE_DEFAULT";
            $stmtCat = rcp_ejecutar($conn, $sqlCat, [$plu]);
            $rowCat = sqlsrv_fetch_array($stmtCat, SQLSRV_FETCH_ASSOC);
            sqlsrv_free_stmt($stmtCat);
            
            $nombreArticulo = $rowCat['descripcion'] ?? 'N/D';

            $detalleFormateado = "Modificado:\n- " . implode("\n- ", $cambios);
            $mensajeFinal = sprintf(
                "PLU: %s\nArtículo: %s\n%s\nREGION: %s",
                $plu,
                $nombreArticulo,
                $detalleFormateado,
                strtoupper($pais)
            );

            if (function_exists('rcp_registrar')) {
                rcp_registrar('RCP_BLOQUEO_EDITADO', $mensajeFinal, $pais);
            }
        }
    } catch (Throwable $e) {
        sqlsrv_rollback($conn);
        throw $e;
    }
}

function rcp_desbloquear($conn, string $pais, string $tienda, string $plu, string $ref): void
{
    if (!sqlsrv_begin_transaction($conn)) rcp_error_sql('inicio transacción');
    try {
        $condicion = 'vIdPais=? AND vIdCompany=? AND ' . rcp_clave_sql('vStoreId') . '=? COLLATE DATABASE_DEFAULT
            AND ' . rcp_clave_sql('vPlu') . '=? COLLATE DATABASE_DEFAULT
            AND ' . rcp_clave_sql('vReferencia') . '=? COLLATE DATABASE_DEFAULT';
        $stmt = rcp_ejecutar($conn,
            'SELECT COUNT_BIG(*) AS total FROM ' . RCP_TABLA . ' WITH (UPDLOCK,HOLDLOCK) WHERE ' . $condicion,
            [$pais, RCP_COMPANIA, $tienda, $plu, $ref]);
        $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmt);
        if ((int)($fila['total'] ?? 0) !== 1) {
            throw new InvalidArgumentException('No se pudo identificar un único bloqueo para desbloquear.');
        }

        $stmt = rcp_ejecutar($conn, 'DELETE FROM ' . RCP_TABLA . ' WHERE ' . $condicion,
            [$pais, RCP_COMPANIA, $tienda, $plu, $ref]);
        $afectadas = sqlsrv_rows_affected($stmt);
        sqlsrv_free_stmt($stmt);
        if ($afectadas !== 1) throw new RuntimeException('No se pudo eliminar un único bloqueo.');
        
        if (!sqlsrv_commit($conn)) rcp_error_sql('confirmación');

        $baseArt = rcp_base_articulos($pais);
        
        // Obtener descripción del artículo
        $sqlCat = "SELECT TOP (1) LTRIM(RTRIM(CONVERT(NVARCHAR(255), A.DESCRIPCION))) AS descripcion 
                   FROM {$baseArt}.dbo.ARTICULOS A
                   INNER JOIN {$baseArt}.dbo.ARTICULOSCAMPOSLIBRES CL ON CL.CODARTICULO = A.CODARTICULO
                   WHERE CL.PLU = ? COLLATE DATABASE_DEFAULT";
        $stmtCat = rcp_ejecutar($conn, $sqlCat, [$plu]);
        $rowCat = sqlsrv_fetch_array($stmtCat, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtCat);
        $nombreArticulo = $rowCat['descripcion'] ?? 'N/D';

        // Obtener el nombre de la tienda
        $sqlTienda = "SELECT TOP (1) LTRIM(RTRIM(CONVERT(NVARCHAR(200), NOMBREALMACEN))) AS nombre 
                      FROM {$baseArt}.dbo.ALMACEN 
                      WHERE " . rcp_clave_sql('CODALMACEN') . " = ? COLLATE DATABASE_DEFAULT";
        $stmtTienda = rcp_ejecutar($conn, $sqlTienda, [$tienda]);
        $rowTienda = sqlsrv_fetch_array($stmtTienda, SQLSRV_FETCH_ASSOC);
        sqlsrv_free_stmt($stmtTienda);
        $nombreTienda = $rowTienda['nombre'] ?? $tienda;

        $detalleFormateado = "Desbloqueado:\n- Tienda: {$nombreTienda}\n- PLU: {$plu}\n- Referencia: {$ref}";
        $mensajeFinal = sprintf(
            "PLU: %s\nArtículo: %s\n%s\nREGION: %s",
            $plu,
            $nombreArticulo,
            $detalleFormateado,
            strtoupper($pais)
        );

        if (function_exists('rcp_registrar')) {
            rcp_registrar('RCP_BLOQUEO_ELIMINADO', $mensajeFinal, $pais);
        }

    } catch (Throwable $e) {
        sqlsrv_rollback($conn);
        throw $e;
    }
}

/* Importación parametrizada en lotes de 150 para conservar el rendimiento. */
function rcp_importar_lote($conn, string $pais, array $filas): array
{
    if (!$filas || count($filas) > 150) throw new InvalidArgumentException('El lote debe contener entre 1 y 150 registros.');
    $unicos = []; $params = []; $marcas = [];
    $catalogo = null;
    foreach ($filas as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Fila de importación inválida.');
        $entradaTienda = rcp_validar_texto($row['tienda'] ?? null, 220, 'tienda');
        if (!preg_match('/^\d{1,4}$/D', $entradaTienda)) {
            $catalogo ??= rcp_tiendas_disponibles($conn, $pais);
        }
        $tienda = rcp_resolver_tienda($conn, $pais, $entradaTienda, $catalogo);
        rcp_verificar_alcance_tienda($tienda);
        $plu = rcp_validar_texto($row['plu'] ?? null, 100, 'PLU');
        $ref = rcp_validar_texto($row['referencia'] ?? null, 100, 'referencia');
        $fecha = trim((string)($row['fecha'] ?? ''));
        if ($fecha !== '') {
            $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
            if (!$dt || $dt->format('Y-m-d') !== $fecha) {
                throw new InvalidArgumentException('FechaRegistro inválida; utilice AAAA-MM-DD.');
            }
        }
        $key = rcp_mayusculas($tienda . "\x1f" . $plu . "\x1f" . $ref);
        if (isset($unicos[$key])) continue;
        $unicos[$key] = [$tienda,$plu,$ref,$fecha];
        $marcas[] = '(?,?,?,?)';
        array_push($params,$tienda,$plu,$ref,$fecha);
    }
    $values = array_values($unicos);
    $base = rcp_base_articulos($pais);

    // Validar las tiendas del lote en una sola consulta.
    $tiendas = array_values(array_unique(array_column($values, 0)));
    $marcasTienda = implode(',',array_fill(0,count($tiendas),'?'));
    $s = rcp_ejecutar($conn, "SELECT DISTINCT " . rcp_clave_sql('A.CODALMACEN') . " AS codigo
            FROM {$base}.dbo.ALMACEN A WHERE " . rcp_clave_sql('A.CODALMACEN') . " IN ({$marcasTienda})", $tiendas);
    $validas = [];
    while ($r=sqlsrv_fetch_array($s,SQLSRV_FETCH_ASSOC)) $validas[]=(string)$r['codigo'];
    sqlsrv_free_stmt($s);
    $invalidas = array_diff($tiendas,$validas);
    if ($invalidas) throw new InvalidArgumentException('Tienda no encontrada: ' . implode(', ',array_slice($invalidas,0,5)));

    // Verificar el catálogo completo por lote; los bloqueos históricos existentes se conservan.
    $pares = []; $parms = [];
    foreach ($values as [$tienda,$plu,$ref,$fecha]) {
        $pares[]='(?,?,?)'; array_push($parms,$tienda,$plu,$ref);
    }
    $sqlValidar = 'SELECT TOP (5) F.tienda,F.plu,F.referencia FROM (VALUES ' . implode(',',$pares) . ') F(tienda,plu,referencia)
        WHERE NOT EXISTS (SELECT 1 FROM ' . $base . '.dbo.ARTICULOS A
            INNER JOIN ' . $base . '.dbo.ARTICULOSCAMPOSLIBRES CL ON CL.CODARTICULO=A.CODARTICULO
            WHERE A.DESCATALOGADO = \'F\'
              AND ' . rcp_clave_sql('CL.PLU') . ' = F.plu COLLATE DATABASE_DEFAULT
              AND ' . rcp_clave_sql('A.REFPROVEEDOR') . ' = F.referencia COLLATE DATABASE_DEFAULT)
          AND NOT EXISTS (SELECT 1 FROM ' . RCP_TABLA . ' B
            WHERE B.vIdPais=? AND B.vIdCompany=?
              AND ' . rcp_clave_sql('B.vStoreId') . ' = F.tienda COLLATE DATABASE_DEFAULT
              AND ' . rcp_clave_sql('B.vPlu') . ' = F.plu COLLATE DATABASE_DEFAULT
              AND ' . rcp_clave_sql('B.vReferencia') . ' = F.referencia COLLATE DATABASE_DEFAULT)';
    $s = rcp_ejecutar($conn,$sqlValidar,[...$parms,$pais,RCP_COMPANIA]);
    $invalidos=[];
    while ($r=sqlsrv_fetch_array($s,SQLSRV_FETCH_ASSOC)) $invalidos[]=$r['plu'].' / '.$r['referencia'];
    sqlsrv_free_stmt($s);
    if ($invalidos) throw new InvalidArgumentException('Artículos inexistentes: '.implode(', ',$invalidos));

    $sql = ';WITH Fuente AS (SELECT V.tienda,V.plu,V.referencia,MIN(NULLIF(V.fecha,\'\')) AS fecha
        FROM (VALUES ' . implode(',',$marcas) . ') V(tienda,plu,referencia,fecha)
        GROUP BY V.tienda,V.plu,V.referencia)
        INSERT INTO ' . RCP_TABLA . '(vIdPais,vIdCompany,vStoreId,vPlu,vReferencia,FechaRegistro)
        SELECT ?,?,F.tienda,F.plu,F.referencia,COALESCE(TRY_CONVERT(DATE,F.fecha,23),CAST(GETDATE() AS DATE))
        FROM Fuente F WHERE NOT EXISTS (SELECT 1 FROM ' . RCP_TABLA . ' B WITH(UPDLOCK,HOLDLOCK)
            WHERE B.vIdPais=? AND B.vIdCompany=?
              AND ' . rcp_clave_sql('B.vStoreId') . ' = F.tienda COLLATE DATABASE_DEFAULT
              AND ' . rcp_clave_sql('B.vPlu') . ' = F.plu COLLATE DATABASE_DEFAULT
              AND ' . rcp_clave_sql('B.vReferencia') . ' = F.referencia COLLATE DATABASE_DEFAULT)';
    $params=[...$params,$pais,RCP_COMPANIA,$pais,RCP_COMPANIA];
    if (!sqlsrv_begin_transaction($conn)) rcp_error_sql('inicio importación');
    try {
        $s=rcp_ejecutar($conn,$sql,$params);
        $insertados=sqlsrv_rows_affected($s); sqlsrv_free_stmt($s);
        if ($insertados === false || $insertados < 0) throw new RuntimeException('No se pudo verificar la importación.');
        if (!sqlsrv_commit($conn)) rcp_error_sql('confirmación importación');
    } catch(Throwable $e) {sqlsrv_rollback($conn);throw $e;}
    return ['procesados'=>count($filas),'validos'=>count($values),
        'insertados'=>$insertados,'existentes'=>count($values)-$insertados];
}
