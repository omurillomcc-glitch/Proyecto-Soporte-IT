<?php
declare(strict_types=1);

/* Sesión segura compartida con Metis y permiso independiente. */
$raiz = dirname(__DIR__, 2);
require_once $raiz . '/controlusuarios/auth.php';
require_once $raiz . '/controlusuarios/db.php';
require_login();
require_module_access('bloqueo_tienda');

$usuarioActual = me();
$codigoPais = strtoupper(trim((string)($usuarioActual['pais_code'] ?? '')));
$paisSesion = in_array($codigoPais, ['NI', 'NICARAGUA'], true) ? 'NICARAGUA' : 'HONDURAS';

require_once $raiz . '/exhibiciontotal/conexion_exhibicion.php';
if (!isset($sqlsrv_conn_exhibicion) || $sqlsrv_conn_exhibicion === false) {
    http_response_code(503);
    exit('Conexión SQL Server no disponible.');
}

if (empty($_SESSION['rcp_tienda_csrf'])) {
    $_SESSION['rcp_tienda_csrf'] = bin2hex(random_bytes(32));
}

session_write_close();

function rcp_longitud_texto(string $texto): int
{
    return function_exists('mb_strlen') ? mb_strlen($texto, 'UTF-8') : strlen($texto);
}

function rcp_mayusculas(string $texto): string
{
    return function_exists('mb_strtoupper') ? mb_strtoupper($texto, 'UTF-8') : strtoupper($texto);
}

function rcp_pais(string $solicitado): string
{
    global $paisSesion, $raiz, $conn;
    $solicitado = strtoupper(trim($solicitado));
    $pais = in_array($solicitado, ['HONDURAS', 'NICARAGUA'], true) ? $solicitado : $paisSesion;
    require_once dirname(__DIR__, 2) . '/controlusuarios/accesos_menu.php';
    $propietario = $conn instanceof mysqli
        && am_es_propietario($conn, (int)($_SESSION['usuario_id'] ?? 0));
    if (!$propietario && $pais !== $paisSesion) {
        throw new DomainException('No tienes autorización para consultar ese país.');
    }
    return $pais;
}

function rcp_error_sql(string $etapa): never
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);
    error_log('Bloqueo Tienda / ' . $etapa . ': ' . json_encode($errores, JSON_UNESCAPED_UNICODE));
    throw new RuntimeException('No se pudo completar la consulta SQL Server.');
}

function rcp_ejecutar($conexion, string $sql, array $params = [])
{
    $consulta = sqlsrv_query($conexion, $sql, $params);
    if ($consulta === false) {
        rcp_error_sql('consulta');
    }
    return $consulta;
}

function rcp_validar_texto(mixed $valor, int $limite, string $campo): string
{
    if (!is_string($valor) && !is_numeric($valor)) {
        throw new InvalidArgumentException("El campo {$campo} no es válido.");
    }
    $texto = trim((string)$valor);
    if ($texto === '' || rcp_longitud_texto($texto) > $limite
        || preg_match('/[\x00-\x1F\x7F]/u', $texto)) {
        throw new InvalidArgumentException("Revise el campo {$campo}.");
    }
    return $texto;
}

function rcp_validar_tienda(mixed $valor): string
{
    $tienda = rcp_validar_texto($valor, 12, 'tienda');
    if (!preg_match('/^\d{1,4}$/D', $tienda)) {
        throw new InvalidArgumentException('La tienda debe tener un código numérico válido.');
    }
    return $tienda;
}


/* Las cuentas de tienda y zona solo acceden a sus almacenes asignados. */
/* Las cuentas de tienda y zona solo acceden a sus almacenes asignados. Propietarios y super_admin tienen acceso total. */
function rcp_cargar_alcance_tiendas(string $pais): void
{
    global $conn, $usuarioActual, $raiz;
    
    $id = (int)($_SESSION['usuario_id'] ?? 0);
    $rol = (string)($usuarioActual['rol'] ?? '');

    // Verificar si es propietario o super_admin usando las funciones de accesos_menu.php
    require_once dirname(__DIR__, 2) . '/controlusuarios/accesos_menu.php';
    if (($conn instanceof mysqli && am_es_propietario($conn, $id)) || $rol === 'super_admin') {
        $GLOBALS['rcp_tiendas_permitidas'] = null; // null indica acceso total sin restricciones
        return;
    }

    if (!in_array($rol, ['tienda', 'admin_zona'], true)) {
        $GLOBALS['rcp_tiendas_permitidas'] = []; 
        return;
    }

    if (!$conn instanceof mysqli) {
        throw new RuntimeException('No hay conexión de permisos.');
    }

    $paisCodigo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
    $stmt = $conn->prepare(
        'SELECT DISTINCT TRIM(codalmacen) AS codigo FROM usuario_tienda WHERE usuario_id = ? AND pais = ?'
    );
    if (!$stmt) throw new RuntimeException('No se pudieron consultar los permisos de tienda.');
    $stmt->bind_param('is', $id, $paisCodigo);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('No se pudieron consultar los permisos de tienda.');
    }
    $rows = $stmt->get_result();
    $codigos = [];
    while ($row = $rows->fetch_assoc()) {
        $codigo = trim((string)($row['codigo'] ?? ''));
        if (preg_match('/^\d{1,4}$/D', $codigo)) $codigos[$codigo] = true;
    }
    $stmt->close();
    $GLOBALS['rcp_tiendas_permitidas'] = array_keys($codigos);
}

function rcp_verificar_alcance_tienda(string $tienda): void
{
    global $conn, $usuarioActual, $raiz;
    $id = (int)($_SESSION['usuario_id'] ?? 0);
    $rol = (string)($usuarioActual['rol'] ?? '');

    // Permitir acceso total si es propietario o super_admin
    require_once dirname(__DIR__, 2) . '/controlusuarios/accesos_menu.php';
    if (($conn instanceof mysqli && am_es_propietario($conn, $id)) || $rol === 'super_admin') {
        return; // Salimos sin error porque tiene privilegios totales
    }

    $permitidas = $GLOBALS['rcp_tiendas_permitidas'];
    if ($permitidas !== null && !in_array($tienda, $permitidas, true)) {
        throw new DomainException('No tienes acceso a la tienda seleccionada.');
    }
}

require_once dirname(__DIR__) . '/conex/funcion.php';
