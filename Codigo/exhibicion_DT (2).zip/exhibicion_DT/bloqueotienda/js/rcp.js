'use strict';

const $ = (id) => document.getElementById(id);
const conf = window.RCP;
const estado = { page: 1, per: 50, total: 0, mode: 'add', original: null, loading: false, pendiente: false, filtros: {}, sort: 'fecha', dir: 'desc', filas: [], modalPais: null };
const CLAVE_ESTADO = 'rcp_tienda_estado_v1';
const CLAVE_POSICION = 'rcp_tienda_posicion_v1';
let posicionAntesGuardar = null;
let catalogoTiendas = [];

function normalizarNombreTienda(valor) {
    return String(valor ?? '').trim().replace(/\s+/g, ' ').toLocaleUpperCase('es');
}

function etiquetaTienda(codigo) {
    const match1 = catalogoTiendas.find(t => t.codigo === String(codigo));
    return match1 ? `${match1.codigo} · ${match1.nombre}` : String(codigo ?? '');
}

/* Un nombre duplicado exige el código para evitar bloquear otra tienda. */
function resolverCodigoTienda(valor) {
    const value1 = String(valor ?? '').trim();
    const value2 = normalizarNombreTienda(value1);
    const match2 = catalogoTiendas.find(t => t.codigo === value1);
    if (match2) return match2.codigo;
    const filteredItems1 = catalogoTiendas.filter(t => t.nombre && (
        normalizarNombreTienda(t.nombre) === value2
        || normalizarNombreTienda(`${t.codigo} · ${t.nombre}`) === value2
    ));
    const seenItems1 = [...new Set(filteredItems1.map(t => t.codigo))];
    if (seenItems1.length === 1) return seenItems1[0];
    if (seenItems1.length > 1) throw new Error(`El nombre «${value1}» corresponde a varias tiendas. Ingresa el código.`);
    throw new Error(`La tienda «${value1}» no existe en el catálogo autorizado. Ingresa el código o nombre correcto.`);
}

function guardarEstado() {
    try {
        sessionStorage.setItem(CLAVE_ESTADO, JSON.stringify({
            pais: pais(), page: estado.page, per: estado.per, filtros: estado.filtros,
            sort: estado.sort, dir: estado.dir
        }));
    } catch (_) { /* El listado continúa sin almacenamiento del navegador. */ }
}

function ventanaDesplazamiento() {
    try {
        if (window.parent !== window && window.frameElement?.id === 'metisBloqueoTiendaFrame') {
            return window.parent;
        }
    } catch (_) {}
    return window;
}

function capturarPosicion() {
    const value3 = ventanaDesplazamiento();
    return {
        y: value3.scrollY,
        x: value3.scrollX,
        tablaX: document.querySelector('.table-wrap')?.scrollLeft ?? 0
    };
}

function guardarPosicion() {
    try { sessionStorage.setItem(CLAVE_POSICION, JSON.stringify(capturarPosicion())); }
    catch (_) { /* El listado continúa sin almacenamiento del navegador. */ }
}

function restaurarPosicion(posicion) {
    if (!posicion) return;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        const element1 = document.querySelector('.table-wrap');
        if (element1) element1.scrollLeft = Number(posicion.tablaX) || 0;
        ventanaDesplazamiento().scrollTo({ left: Number(posicion.x) || 0,
            top: Number(posicion.y) || 0, behavior: 'instant' });
    }));
}

function restaurarEstado() {
    try {
        const state1 = JSON.parse(sessionStorage.getItem(CLAVE_ESTADO) || 'null');
        if (!state1 || typeof state1 !== 'object') return;
        if (['HONDURAS', 'NICARAGUA'].includes(state1.pais)
            && Array.from($('pais').options).some(opcion => opcion.value === state1.pais)) {
            $('pais').value = state1.pais;
        }
        if (Number.isInteger(state1.page) && state1.page > 0 && state1.page <= 100000) estado.page = state1.page;
        if ([50, 100, 250, 500, 1000].includes(state1.per)) estado.per = state1.per;
        if (['numero', 'tienda', 'plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'].includes(state1.sort)) estado.sort = state1.sort;
        if (['asc', 'desc'].includes(state1.dir)) estado.dir = state1.dir;
        if (state1.filtros && typeof state1.filtros === 'object' && !Array.isArray(state1.filtros)) {
            for (const [campo, valor] of Object.entries(state1.filtros)) {
                if (['tienda', 'plu', 'referencia', 'descripcion', 'departamento', 'seccion', 'familia', 'fecha'].includes(campo) && typeof valor === 'string' && valor.length <= 1500) {
                    estado.filtros[campo] = valor;
                }
            }
        }
    } catch (_) { /* Utilizar los parámetros iniciales. */ }
    $('porPagina').value = String(estado.per);
}


function mensaje(texto, tipo = '') {
    $('mensaje').textContent = texto;
    $('mensaje').className = 'message ' + tipo;
}

function htmlSeguro(valor) {
    const div = document.createElement('div');
    div.textContent = String(valor ?? '');
    return div.innerHTML;
}

function pais() { return $('pais').value; }

function normalizarPais(valor) {
    const value4 = String(valor ?? '').trim().toUpperCase();
    if (value4 === 'HN') return 'HONDURAS';
    if (value4 === 'NI') return 'NICARAGUA';
    return value4;
}

async function api(accion, opciones = {}) {
    const url = new URL(conf.api, location.href);
    url.searchParams.set('action', accion);
    if (opciones.params) {
        for (const [clave, valor] of Object.entries(opciones.params)) url.searchParams.set(clave, valor);
    }
    const options1 = { credentials: 'same-origin', cache: 'no-store' };
    if (opciones.body) {
        options1.method = 'POST';
        options1.headers = { 'Content-Type': 'application/json', 'X-CSRF-Token': conf.csrf };
        options1.body = JSON.stringify({ pais: pais(), ...opciones.body });
    }
    const res = await fetch(url, options1);
    const responseData1 = await res.json().catch(() => ({ ok: false, message: 'Respuesta inválida del servidor.' }));
    if (!res.ok || !responseData1.ok) throw new Error(responseData1.message || 'La operación no pudo completarse.');
    return responseData1;
}

function renderTabla(filas) {
    estado.filas = filas;
    const element2 = $('tabla');
    element2.replaceChildren();
    if (!filas.length) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="11" class="empty">No hay artículos bloqueados para la selección.</td>';
        element2.append(tr);
        return;
    }
    for (const [indice, fila] of filas.entries()) {
        const tr = document.createElement('tr');
        const value5 = dato => htmlSeguro(dato ?? '—');
        const value6 = (estado.page - 1) * estado.per + indice;
        const value7 = estado.sort === 'numero' && estado.dir === 'desc'
            ? estado.total - value6 : value6 + 1;
        tr.innerHTML = `
            <td class="num-col">${value7}</td>
            <td class="store-code" data-field="tienda">${value5(fila.tienda)}<small>${value5(fila.nombre_tienda || '')}</small></td>
            <td data-field="plu">${value5(fila.plu)}</td>
            <td data-field="referencia">${value5(fila.referencia)}</td>
            <td data-field="descripcion" class="description">${value5(fila.descripcion)}</td>
            <td data-field="departamento">${value5(fila.departamento)}</td>
            <td data-field="seccion">${value5(fila.seccion)}</td>
            <td data-field="familia">${value5(fila.familia)}</td>
            <td data-field="fecha">${value5(fila.fecha)}</td>
            <td><span class="badge">Bloqueado</span></td>
            <td></td>`;
        const value8 = tr.lastElementChild;
        if (Number(fila.repetidosOrigen) > 1) {
            const element3 = document.createElement('span');
            element3.className = 'duplicate-note';
            element3.title = 'Hay duplicados existentes en SQL Server; no se edita un registro ambiguo.';
            element3.textContent = 'Repetido en origen';
            value8.append(element3);
        } else {
            const element4 = document.createElement('button');
            element4.type = 'button';
            element4.className = 'tiny';
            element4.textContent = 'Editar';
            element4.addEventListener('click', () => abrirEdicion(fila));
            value8.append(element4);
        }
        element2.append(tr);
    }
}

async function cargarTiendas() {
    const value9 = pais();
    const value10 = estado.filtros.tienda || '';
    const state2 = await api('stores', { params: { pais: value9 } });
    if (pais() !== value9) return;
    const value11 = Array.isArray(state2.rows) ? state2.rows : [];
    catalogoTiendas = value11.map(tienda => ({
        codigo: String(tienda.codigo ?? '').trim(),
        nombre: String(tienda.nombre ?? '').trim()
    })).filter(tienda => tienda.codigo);
    const element5 = $('tiendaFiltro');
    const element6 = $('listaTiendas');
    element5.replaceChildren(new Option('Todas las tiendas', ''));
    element6.replaceChildren();
    for (const value12 of catalogoTiendas) {
        const value13 = value12.codigo + (value12.nombre ? ` · ${value12.nombre}` : '');
        element5.append(new Option(value13, value12.codigo));
        element6.append(new Option(value13));
    }
    const inputValue1 = [...element5.options].some(o => o.value === value10);
    if (!inputValue1) delete estado.filtros.tienda;
    element5.value = inputValue1 ? value10 : '';
}

async function cargar() {
    if (estado.loading) { estado.pendiente = true; return; }
    estado.loading = true;
    const value14 = capturarPosicion();
    guardarEstado();
    mensaje('Consultando Bloqueo Tienda...');
    try {
        const options2 = {
            pais: pais(), page: estado.page,
            per: estado.per, sort: estado.sort, dir: estado.dir
        };
        for (const [campo, valor] of Object.entries(estado.filtros)) {
            options2['f_' + campo] = valor;
        }
        const state3 = await api('list', { params: options2 });
        if (estado.page > 1 && !state3.rows.length) {
            // Si desaparecen filas, volver únicamente a la página anterior.
            estado.page--;
            estado.pendiente = true;
            return;
        }
        estado.total = Number(state3.total) || 0;
        const value15 = Boolean(state3.filtered);
        renderTabla(state3.rows);
        restaurarPosicion(value14);
        // La paginación se conserva aun cuando exista un filtro activo.
        const boundedValue1 = Math.max(1, Math.ceil(estado.total / estado.per));
        $('resumen').textContent = `${estado.total.toLocaleString('es-HN')} bloqueos ${value15 ? 'filtrados' : 'registrados'}`;
        $('pagina').textContent = `${estado.page} de ${boundedValue1}`;
        $('primera').disabled = estado.page <= 1;
        $('anterior').disabled = estado.page <= 1;
        $('siguiente').disabled = estado.page >= boundedValue1;
        $('ultima').disabled = estado.page >= boundedValue1;
        guardarEstado();
        $('tiendaFiltro').value = [...$('tiendaFiltro').options].some(o => o.value === (estado.filtros.tienda || '')) ? (estado.filtros.tienda || '') : '';
        document.querySelectorAll('.filter-trigger').forEach(boton => {
            boton.classList.toggle('is-active', Boolean(estado.filtros[boton.dataset.field]));
        });
        mensaje('');
    } catch (error1) {
        mensaje(error1.message, 'error');
    } finally {
        estado.loading = false;
        if (estado.pendiente) { estado.pendiente = false; cargar(); }
    }
}

// Filtros globales: las opciones se consultan a SQL Server sin aplicar paginación.
let columnaExcel = '';
let valoresExcel = [];
let numeroConsultaExcel = 0;
let temporizadorExcel = null;
let hayMasValoresExcel = false;
let seleccionarTodoExcel = false;

function cerrarExcel() {
    $('excelMenu').hidden = true;
    numeroConsultaExcel++;
    clearTimeout(temporizadorExcel);
}

function abrirExcel(boton) {
    columnaExcel = boton.dataset.field;
    $('excelTitulo').textContent = boton.dataset.label || 'Filtrar';
    const element7 = $('excelMenu').querySelector('.excel-hint');
    if (element7) element7.textContent = 'Opciones de todos los registros, no solo de esta página. Escribe para buscar cualquier valor.';
    const value16 = String(estado.filtros[columnaExcel] || '');
    $('excelBuscar').value = value16.startsWith('__LIKE__') ? value16.slice(8) : '';
    $('excelOrden').value = estado.sort === columnaExcel ? estado.dir : 'asc';
    valoresExcel = [];
    hayMasValoresExcel = false;
    seleccionarTodoExcel = false;
    $('excelMenu').hidden = false;
    cargarOpcionesExcel();
    $('excelBuscar').focus();
}

async function cargarOpcionesExcel() {
    const value17 = columnaExcel;
    const value18 = ++numeroConsultaExcel;
    const element8 = $('excelBuscar').value.trim();
    const element9 = $('excelOpciones');
    element9.textContent = 'Consultando todos los registros...';
    $('excelTodos').checked = false;
    seleccionarTodoExcel = false;
    try {
        const state4 = { pais: pais(), field: value17, q: element8 };
        // Conservar filtros de otras columnas, para que las opciones sean coherentes.
        for (const [nombre, valor] of Object.entries(estado.filtros)) {
            if (nombre !== value17 && valor) {
                state4['f_' + nombre] = valor;
            }
        }
        const value19 = await api('options', { params: state4 });
        // Ignorar respuestas de búsquedas anteriores o de un filtro ya cerrado.
        if (value18 !== numeroConsultaExcel || $('excelMenu').hidden || value17 !== columnaExcel) return;
        valoresExcel = Array.isArray(value19.values) ? value19.values.map(String) : [];
        hayMasValoresExcel = Boolean(value19.has_more);
        dibujarExcel();
    } catch (error2) {
        if (value18 !== numeroConsultaExcel || $('excelMenu').hidden) return;
        element9.textContent = error2.message;
    }
}

function dibujarExcel() {
    const element10 = $('excelOpciones');
    element10.replaceChildren();
    const value20 = String(estado.filtros[columnaExcel] || '').split('||');
    const asc = $('excelOrden').value === 'asc';
    const itemCount1 = [...valoresExcel]
        .sort((a, b) => asc
            ? a.localeCompare(b, 'es', { numeric: true })
            : b.localeCompare(a, 'es', { numeric: true }));
    for (const value21 of itemCount1) {
        const element11 = document.createElement('label');
        element11.className = 'excel-option';
        const element12 = document.createElement('input');
        element12.type = 'checkbox';
        element12.className = 'excel-item';
        element12.value = value21;
        element12.checked = value20.includes(value21);
        const element13 = document.createElement('span');
        element13.textContent = value21;
        element11.append(element12, element13);
        element10.append(element11);
    }
    if (!itemCount1.length) element10.textContent = 'No se encontraron valores.';
    if (hayMasValoresExcel) {
        const element14 = document.createElement('small');
        element14.textContent = 'Hay más valores. Escribe arriba para buscarlos en todos los registros.';
        element10.append(element14);
    }
    $('excelTodos').checked = itemCount1.length > 0
        && [...element10.querySelectorAll('.excel-item')].every(c => c.checked);
}

$('excelBuscar').addEventListener('input', () => {
    clearTimeout(temporizadorExcel);
    temporizadorExcel = setTimeout(cargarOpcionesExcel, 300);
});
$('excelOrden').addEventListener('change', dibujarExcel);
$('excelTodos').addEventListener('change', function () {
    seleccionarTodoExcel = this.checked;
    $('excelOpciones').querySelectorAll('.excel-item').forEach(c => { c.checked = this.checked; });
});
// Seleccionar manualmente una opción cancela el modo 'todas las coincidencias'.
$('excelOpciones').addEventListener('change', (event) => {
    if (event.target.matches('.excel-item')) {
        seleccionarTodoExcel = false;
        const elements1 = [...$('excelOpciones').querySelectorAll('.excel-item')];
        $('excelTodos').checked = elements1.length > 0 && elements1.every(c => c.checked);
    }
});
$('excelAplicar').addEventListener('click', () => {
    const elements2 = [...$('excelOpciones').querySelectorAll('.excel-item:checked')].map(c => c.value);
    const element15 = $('excelBuscar').value.trim();
    // "Seleccionar todo" significa todas las coincidencias del servidor,
    // no solo las opciones visibles en el navegador.
    if (seleccionarTodoExcel) {
        if (element15) estado.filtros[columnaExcel] = '__LIKE__' + element15;
        else delete estado.filtros[columnaExcel];
    } else if (elements2.length) {
        if (elements2.length > 60) {
            alert('Para seleccionar más de 60 valores, usa Seleccionar todo o escribe la búsqueda.');
            return;
        }
        estado.filtros[columnaExcel] = elements2.join('||');
    } else if (element15) {
        estado.filtros[columnaExcel] = '__LIKE__' + element15;
    } else {
        delete estado.filtros[columnaExcel];
    }
    estado.sort = columnaExcel;
    estado.dir = $('excelOrden').value;
    estado.page = 1;
    cerrarExcel();
    guardarEstado();
    cargar();
});
$('excelLimpiar').addEventListener('click', () => {
    delete estado.filtros[columnaExcel];
    estado.page = 1;
    cerrarExcel();
    guardarEstado();
    cargar();
});
$('excelCerrar').addEventListener('click', cerrarExcel);
document.addEventListener('click', event => {
    if (!$('excelMenu').hidden && !event.target.closest('#excelMenu,.filter-trigger')) cerrarExcel();
});
document.querySelectorAll('.filter-trigger').forEach(b => b.addEventListener('click', () => abrirExcel(b)));

// El número se basa en el orden numérico del PLU y permite ambos sentidos.
const thNumero = document.querySelector('th.num-col');
if (thNumero) {
    const control = document.createElement('button');
    control.type = 'button';
    control.className = 'filter-trigger';
    control.textContent = '↕';
    control.title = 'Ordenar número: ascendente o descendente';
    control.setAttribute('aria-label', 'Orden numérico ascendente o descendente');
    thNumero.append(' ', control);
    control.addEventListener('click', () => {
        estado.dir = estado.sort === 'numero' && estado.dir === 'asc' ? 'desc' : 'asc';
        estado.sort = 'numero';
        estado.page = 1;
        guardarEstado();
        cargar();
    });
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarExcel(); });

function abrirAgregar() {
    estado.mode = 'add'; estado.original = null; estado.modalPais = pais();
    $('formArticulo').reset();
    $('desbloquearArticulo').hidden = true;
    $('tiendaModal').value = estado.filtros.tienda ? etiquetaTienda(estado.filtros.tienda) : '';
    $('paisModal').value = estado.modalPais; $('companiaModal').value = 'DETODO'; $('fechaModal').value = 'Automática';
    $('modalTitulo').textContent = 'Agregar artículo';
    $('errorArticulo').textContent = '';
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('modalArticulo').showModal();
}

function abrirEdicion(fila) {
    estado.mode = 'edit'; estado.modalPais = pais();
    $('desbloquearArticulo').hidden = false;
    $('paisModal').value = estado.modalPais; $('companiaModal').value = 'DETODO'; $('fechaModal').value = fila.fecha || '—';
    estado.original = { tienda: fila.tienda, plu: fila.plu, referencia: fila.referencia };
    $('tiendaModal').value = etiquetaTienda(fila.tienda);
    $('modalTitulo').textContent = 'Editar bloqueo';
    $('plu').value = fila.plu;
    $('referencia').value = fila.referencia;
    $('errorArticulo').textContent = '';
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('modalArticulo').showModal();
}

async function desbloquearArticulo() {
    if (estado.mode !== 'edit' || !estado.original) return;
    if (!window.confirm('¿Desea desbloquear este artículo en la tienda seleccionada? Dejará de aparecer en Bloqueo Tienda.')) return;
    const element16 = $('desbloquearArticulo');
    const element17 = $('guardarArticulo');
    element16.disabled = true;
    element17.disabled = true;
    $('errorArticulo').textContent = '';
    try {
        const value22 = await api('unlock', { body: {
            tienda: estado.original.tienda,
            plu: estado.original.plu,
            referencia: estado.original.referencia
        } });
        $('modalArticulo').close();
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        mensaje(value22.message, 'success');
    } catch (error3) {
        $('errorArticulo').textContent = error3.message;
    } finally {
        element16.disabled = false;
        element17.disabled = false;
    }
}

async function guardarArticulo(evento) {
    evento.preventDefault();
    const element18 = $('guardarArticulo');
    const element19 = { tienda: $('tiendaModal').value.trim(), plu: $('plu').value.trim(), referencia: $('referencia').value.trim() };
    if (!element19.tienda || !element19.plu || !element19.referencia) {
        $('errorArticulo').textContent = 'Ingrese la tienda, PLU y referencia.';
        return;
    }
    try {
        element19.tienda = resolverCodigoTienda(element19.tienda);
    } catch (error4) {
        $('errorArticulo').textContent = error4.message;
        return;
    }
    if (estado.mode === 'edit') {
        element19.tienda_original = estado.original.tienda;
        element19.plu_original = estado.original.plu;
        element19.referencia_original = estado.original.referencia;
    }
    if (estado.modalPais !== pais()) { $('errorArticulo').textContent = 'El país cambió. Vuelva a abrir el formulario.'; return; }
    element18.disabled = true;
    $('errorArticulo').textContent = '';
    try {
        const value23 = await api(estado.mode, { body: element19 });
        $('modalArticulo').close();
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        guardarEstado();
        mensaje(value23.message, 'success');
    } catch (error5) { $('errorArticulo').textContent = error5.message; }
    finally { element18.disabled = false; }
}

$('desbloquearArticulo').addEventListener('click', desbloquearArticulo);

// Procesamiento del CSV sin conversión numérica para conservar ceros iniciales del PLU.
function leerCsv(texto, separador) {
    const value24 = [];
    let value25 = [], value26 = '', value27 = false;
    for (let i = 0; i < texto.length; i++) {
        const c = texto[i];
        if (c === '"') {
            if (value27 && texto[i + 1] === '"') { value26 += '"'; i++; }
            else value27 = !value27;
        } else if (c === separador && !value27) {
            value25.push(value26); value26 = '';
        } else if ((c === '\n' || c === '\r') && !value27) {
            if (c === '\r' && texto[i + 1] === '\n') i++;
            value25.push(value26);
            if (value25.some((f) => f.trim() !== '')) value24.push(value25);
            value25 = []; value26 = '';
        } else value26 += c;
    }
    if (value27) throw new Error('El CSV contiene comillas sin cerrar.');
    value25.push(value26);
    if (value25.some((f) => f.trim() !== '')) value24.push(value25);
    return value24;
}

function normalizarColumna(texto) {
    return texto.replace(/^\uFEFF/, '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function formatoFecha(valor) {
    valor = String(valor || '').trim();
    if (!valor) return '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(valor)) return valor;
    const value28 = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(valor);
    if (value28) return `${value28[3]}-${value28[2].padStart(2, '0')}-${value28[1].padStart(2, '0')}`;
    throw new Error('FechaRegistro debe tener el formato AAAA-MM-DD o DD/MM/AAAA.');
}

function prepararCsv(texto) {
    texto = texto.replace(/^\uFEFF/, '');
    const value29 = texto.split(/\r?\n/, 1)[0] || '';
    const value30 = (value29.match(/;/g) || []).length > (value29.match(/,/g) || []).length ? ';' : ',';
    const itemCount2 = leerCsv(texto, value30);
    if (itemCount2.length < 2) throw new Error('El archivo debe tener encabezados y por lo menos un registro.');
    const mappedItems1 = itemCount2.shift().map(normalizarColumna);
    const value31 = (...nombres) => mappedItems1.findIndex((v) => nombres.includes(v));
    const value32 = value31('vstoreid', 'storeid', 'tienda', 'codalmacen');
    const value33 = value31('vplu', 'plu');
    const value34 = value31('vreferencia', 'referencia');
    const value35 = value31('vidpais', 'pais');
    const value36 = value31('vidcompany', 'company', 'compania');
    const value37 = value31('fecharegistro', 'fecha');
    if (value32 === -1 || value33 === -1 || value34 === -1) throw new Error('El CSV debe contener vStoreId, vPlu y vReferencia.');
    const itemCount3 = [];
    const seenItems2 = new Set();
    for (let i = 0; i < itemCount2.length; i++) {
        const value38 = itemCount2[i];
        const value39 = String(value38[value32] || '').trim();
        let value40;
        try { value40 = resolverCodigoTienda(value39); }
        catch (error6) { throw new Error(`Fila ${i + 2}: ${error6.message}`); }
        const plu = String(value38[value33] || '').trim();
        const itemCount4 = String(value38[value34] || '').trim();
        if (!plu || !itemCount4) throw new Error(`Fila ${i + 2}: PLU o referencia vacío.`);
        if (plu.length > 100 || itemCount4.length > 100) throw new Error(`Fila ${i + 2}: campo demasiado largo.`);
        if (value35 !== -1) {
            const value41 = normalizarPais(value38[value35]);
            if (value41 && value41 !== normalizarPais(pais())) {
                throw new Error(`Fila ${i + 2}: el país del archivo (${value41}) no coincide con el seleccionado (${pais()}).`);
            }
        }
        if (value36 !== -1) {
            const value42 = String(value38[value36] || '').trim().toUpperCase();
            if (value42 && value42 !== 'DETODO') throw new Error(`Fila ${i + 2}: compañía diferente de DETODO.`);
        }
        const value43 = value37 >= 0 ? formatoFecha(value38[value37] || '') : '';
        const value44 = (pais() + '\u001f' + 'DETODO' + '\u001f' + value40 + '\u001f' + plu + '\u001f' + itemCount4).toLocaleUpperCase();
        if (seenItems2.has(value44)) continue;
        seenItems2.add(value44);
        itemCount3.push({ tienda: value40, plu, referencia: itemCount4, fecha: value43 });
    }
    return { rows: itemCount3, repetidosArchivo: itemCount2.length - itemCount3.length };
}

async function importar() {
    const element20 = $('archivo').files[0];
    const element21 = $('estadoImportacion');
    const element22 = $('ejecutarImportacion');
    if (!element20) { element21.textContent = 'Seleccione un archivo CSV.'; return; }
    if (element20.size > 8 * 1024 * 1024) {
        element21.textContent = 'El archivo supera 8 MB. Divídalo en archivos más pequeños.'; return;
    }
    element22.disabled = true;
    $('pais').disabled = true;
    $('progreso').hidden = false;
    $('progreso').value = 0;
    let value45 = false;
    try {
        const value46 = await element20.text();
        const { rows, repetidosArchivo } = prepararCsv(value46);
        if (!rows.length) throw new Error('No hay registros válidos para importar.');
        let value47 = 0, value48 = 0;
        const value49 = 150;
        value45 = true;
        for (let value50 = 0; value50 < rows.length; value50 += value49) {
            const itemCount5 = rows.slice(value50, value50 + value49);
            const resultado = await api('import', { body: { rows: itemCount5 } });
            value47 += resultado.insertados;
            value48 += resultado.existentes;
            const procesados = Math.min(value50 + itemCount5.length, rows.length);
            $('progreso').value = 100 * procesados / rows.length;
            element21.textContent = `Importando ${procesados.toLocaleString('es-HN')} / ${rows.length.toLocaleString('es-HN')} registros...`;
        }
        element21.textContent = `Importación finalizada. Nuevos: ${value47}. Existentes: ${value48}. Repetidos en archivo: ${repetidosArchivo}.`;
        // Conservar página, filtros y desplazamiento tras importar.
        await cargar();
        restaurarPosicion(posicionAntesGuardar);
        guardarEstado();
    } catch (error) {
        element21.textContent = value45
            ? `Importación interrumpida: ${error.message}. Los lotes completados previamente permanecen guardados.`
            : `No se importó ningún registro: ${error.message}`;
    } finally { element22.disabled = false; $('pais').disabled = false; }
}

$('btnAgregar').addEventListener('click', abrirAgregar);
$('btnImportar').addEventListener('click', () => {
    posicionAntesGuardar = capturarPosicion();
    guardarPosicion();
    $('archivo').value = '';
    $('estadoImportacion').textContent = '';
    $('progreso').hidden = true;
    $('modalImportar').showModal();
});
$('btnActualizar').addEventListener('click', () => cargar());
$('btnLimpiarFiltros').addEventListener('click', () => {
    estado.filtros = {}; estado.sort = 'fecha'; estado.dir = 'desc'; estado.page = 1;
    $('tiendaFiltro').value = '';
    guardarEstado(); cargar();
});
$('porPagina').addEventListener('change', () => {
    estado.per = Number($('porPagina').value);
    estado.page = 1; guardarEstado(); cargar();
});
$('pais').addEventListener('change', async () => {
    estado.page = 1; estado.filtros = {};
    guardarEstado();
    try { await cargarTiendas(); await cargar(); }
    catch (error) { mensaje(error.message, 'error'); }
});
$('tiendaFiltro').addEventListener('change', () => {
    const codigo = $('tiendaFiltro').value;
    if (codigo) estado.filtros.tienda = codigo;
    else delete estado.filtros.tienda;
    estado.page = 1;
    guardarEstado();
    cargar();
});
$('primera').addEventListener('click', () => { estado.page = 1; guardarEstado(); cargar(); });
$('anterior').addEventListener('click', () => {
    if (estado.page > 1) { estado.page--; guardarEstado(); cargar(); }
});
$('siguiente').addEventListener('click', () => {
    if (estado.page < Math.ceil(estado.total / estado.per)) {
        estado.page++; guardarEstado(); cargar();
    }
});
$('ultima').addEventListener('click', () => {
    estado.page = Math.max(1, Math.ceil(estado.total / estado.per));
    guardarEstado(); cargar();
});
$('formArticulo').addEventListener('submit', guardarArticulo);
$('ejecutarImportacion').addEventListener('click', importar);
for (const cerrar of document.querySelectorAll('[data-close]')) {
    cerrar.addEventListener('click', () => $(cerrar.dataset.close).close());
}
// Conservar también la posición al actualizar el navegador.
restaurarEstado();
let tareaScroll = false;
ventanaDesplazamiento().addEventListener('scroll', () => {
    if (tareaScroll) return;
    tareaScroll = true;
    requestAnimationFrame(() => { guardarPosicion(); tareaScroll = false; });
}, { passive: true });
document.querySelector('.table-wrap')?.addEventListener('scroll', guardarPosicion, { passive: true });
let posicionInicial = null;
try { posicionInicial = JSON.parse(sessionStorage.getItem(CLAVE_POSICION) || 'null'); }
catch (_) { /* No hay posición guardada. */ }
cargarTiendas().then(cargar).then(() => restaurarPosicion(posicionInicial))
    .catch(error => mensaje(error.message, 'error'));
