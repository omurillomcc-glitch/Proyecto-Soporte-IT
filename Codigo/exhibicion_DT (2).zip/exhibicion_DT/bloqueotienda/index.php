<?php
declare(strict_types=1);
require_once __DIR__ . '/inc/init.php';

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$propietarioBloqueo = $conn instanceof mysqli && am_es_propietario($conn, (int)($_SESSION['usuario_id'] ?? 0));
$config = [
    'csrf' => (string)$_SESSION['rcp_tienda_csrf'],
    'pais' => $paisSesion,
    'api' => 'api.php',
];
?>hon
<!DOCTYPE html>
<html lang="es" data-rcp-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Bloqueo Tienda</title>
    <link rel="stylesheet" href="assets/bloqueo.css?v=14">
    <script src="js/bloqueo.js?v=8" defer></script>
</head>
<body>
<main class="shell">
    <div class="rcp-hoja-excel" aria-label="Hoja de Bloqueo Tienda">
        <!--header class="topbar rcp-sheet-heading">
            <div class="page-heading">
                <span class="rcp-heading-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="4" y="9" width="16" height="11" rx="1.5"></rect>
                        <path d="M3 9l2-5h14l2 5H3ZM9 20v-6h6v6"></path>
                    </svg>
                </span>
                <h1>Bloqueo Tienda</h1>
                <span class="rcp-heading-divider" aria-hidden="true"></span>
                <span class="rcp-heading-detail">Gestión de artículos bloqueados por tienda</span>
            </div>
            <a class="back-link" href="../index.php?vista=inicio" aria-label="Volver al inicio">
                <span aria-hidden="true">←</span> Volver al inicio
            </a>
        </header>-->
    <div class="actions" aria-label="Acciones del módulo">
        <label class="field country-field">
            <span>País</span>
            <select id="pais">
                <?php if ($propietarioBloqueo || $paisSesion === 'HONDURAS'): ?>
                <option value="HONDURAS" <?= $paisSesion === 'HONDURAS' ? 'selected' : '' ?>>Honduras</option>
                <?php endif; ?>
                <?php if ($propietarioBloqueo || $paisSesion === 'NICARAGUA'): ?>
                <option value="NICARAGUA" <?= $paisSesion === 'NICARAGUA' ? 'selected' : '' ?>>Nicaragua</option>
                <?php endif; ?>
            </select>
        </label>
        <label class="field country-field store-filter"><span>Tienda</span>
            <select id="tiendaFiltro"><option value="">Todas las tiendas</option></select>
        </label>
        <div class="filters">
            <button class="outline clear-button" id="btnLimpiarFiltros" type="button">
                <span aria-hidden="true"></span> Limpiar
            </button>
            <label class="size-label"><span>Filas</span>
                <select id="porPagina">
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="250">250</option>
                    <option value="500">500</option>
                    <option value="1000">1000</option>
                </select>
            </label>
        </div>
        <div class="action-buttons">
            <button class="primary" id="btnAgregar" type="button"><span aria-hidden="true"></span> Agregar artículo</button>
            <button class="outline" id="btnImportar" type="button"><span aria-hidden="true"></span> Importar CSV</button>
            <button class="outline" id="btnActualizar" type="button"><span aria-hidden="true"></span> Actualizar</button>
        </div>
    </div>

    <section class="panel" aria-label="Listado de bloqueos por tienda">

        <div id="mensaje" class="message" role="status" aria-live="polite"></div>
        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th class="num-col">N°</th>
                    <?php foreach ([
                        'tienda' => 'Tienda',
                        'plu' => 'PLU',
                        'referencia' => 'Referencia',
                        'descripcion' => 'Descripción',
                        'departamento' => 'Departamento',
                        'seccion' => 'Sección',
                        'familia' => 'Familia',
                        'fecha' => 'Registro',
                    ] as $campo => $titulo): ?>
                    <th>
                        <span class="th-filter">
                            <?= e($titulo) ?>
                            <button type="button" class="filter-trigger" data-field="<?= e($campo) ?>" data-label="<?= e($titulo) ?>" aria-label="Filtrar <?= e($titulo) ?>" title="Filtro tipo Excel">
                                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 2h13L9.2 7.1v5.1l-2.4 1.8V7.1L1.5 2z"/></svg>
                            </button>
                        </span>
                    </th>
                    <?php endforeach; ?>
                    <th>Estado</th>
                    <th>Acción</th>
                </tr>
                </thead>
                <tbody id="tabla"><tr><td colspan="11" class="empty">Cargando artículos...</td></tr></tbody>
            </table>
        </div>
        <div class="pagination">
            <span id="resumen">—</span>
            <div class="page-controls" aria-label="Paginación">
                <button id="primera" class="outline" type="button" title="Primera página" aria-label="Primera página">«</button>
                <button id="anterior" class="outline" type="button" title="Página anterior" aria-label="Página anterior">‹</button>
                <span id="pagina">1 de 1</span>
                <button id="siguiente" class="outline" type="button" title="Página siguiente" aria-label="Página siguiente">›</button>
                <button id="ultima" class="outline" type="button" title="Última página" aria-label="Última página">»</button>
            </div>
        </div>
    </section>
    </div>
    <p class="footnote">La tabla muestra únicamente artículos registrados en Bloqueo Tienda RCP. Los datos se consultan sin duplicarlos.</p>
</main>

<div id="excelMenu" class="excel-menu" hidden role="group" aria-label="Opciones de filtro">
    <div class="excel-head">
        <div><span class="modal-eyebrow">FILTRO DE COLUMNA</span><strong id="excelTitulo">Filtrar</strong></div>
        <button type="button" class="close" id="excelCerrar" aria-label="Cerrar filtro">×</button>
    </div>
    <label class="field"><span>Orden</span>
        <select id="excelOrden"><option value="asc">Ordenar A → Z</option><option value="desc">Ordenar Z → A</option></select>
    </label>
    <input id="excelBuscar" type="search" placeholder="Buscar valor..." aria-label="Buscar valores" autocomplete="off">
    <label class="excel-all"><input id="excelTodos" type="checkbox"> Seleccionar todo</label>
    <div id="excelOpciones" class="excel-opciones"></div>
    <small class="excel-hint">Filtro global: consulta todos los registros, aunque muestres 50 por página.</small>
    <div class="excel-actions"><button type="button" class="outline" id="excelLimpiar">Limpiar</button><button type="button" class="primary" id="excelAplicar">Aplicar</button></div>
</div>

<dialog id="modalArticulo" class="modal">
    <form id="formArticulo" method="dialog">
        <div class="modal-head">
            <span class="rcp-modal-icon" aria-hidden="true">＋</span>
            <div><h2 id="modalTitulo">Agregar artículo</h2><p class="rcp-modal-subtitle">Datos del artículo bloqueado</p></div>
            <button class="close" type="button" data-close="modalArticulo" aria-label="Cerrar">×</button>
        </div>
        <div class="modal-body">
            <div class="form-grid">
                <label class="field">País<input id="paisModal" readonly></label>
                <label class="field">Tienda<input id="tiendaModal" list="listaTiendas" required maxlength="220" autocomplete="off" placeholder="Código o nombre de tienda"><datalist id="listaTiendas"></datalist></label>
                <label class="field">Compañía<input id="companiaModal" readonly></label>
                <label class="field">Fecha de registro<input id="fechaModal" readonly></label>
                 
                <label class="field">PLU<input id="plu" required maxlength="100" autocomplete="off" placeholder="Código PLU"></label>
                <label class="field">Referencia<input id="referencia" required maxlength="100" autocomplete="off" placeholder="Referencia del artículo"></label>
            </div>
            <p class="help">Escribe el código o nombre y selecciona la tienda. Ingrese PLU, Referencia. Se omiten duplicados.</p>
            <p id="errorArticulo" class="form-error" role="alert"></p>
        </div>
        <div class="modal-actions">
            <button class="outline" type="button" data-close="modalArticulo">Cancelar</button>
            <button class="outline" type="button" id="desbloquearArticulo" hidden>Desbloquear</button>
            <button class="primary" type="submit" id="guardarArticulo">Guardar artículo</button>
        </div>
    </form>
</dialog>

<dialog id="modalImportar" class="modal">
    <div class="modal-head">
        <span class="rcp-modal-icon" aria-hidden="true">⇧</span>
        <div><h2>Importación masiva</h2><p class="rcp-modal-subtitle">Cargar artículos desde un archivo CSV</p></div>
        <button class="close" type="button" data-close="modalImportar" aria-label="Cerrar">×</button>
    </div>
    <div class="modal-body">
        <p class="help">Selecciona un CSV UTF-8 exportado desde Excel. Debe contener <strong>vStoreId</strong> (código o nombre de tienda), <strong>vPlu</strong> y <strong>vReferencia</strong>; admite además vIdPais, vIdCompany y FechaRegistro.</p>
        <label class="field file-field"><span>Archivo CSV</span><input type="file" id="archivo" accept=".csv,text/csv"></label>
        <p class="help">Los duplicados se omiten. No se modifican registros existentes.</p>
        <div id="estadoImportacion" class="status-import" role="status" aria-live="polite"></div>
        <progress id="progreso" value="0" max="100" hidden></progress>
    </div>
    <div class="modal-actions">
        <button class="outline" type="button" data-close="modalImportar">Cerrar</button>
        <button class="primary" type="button" id="ejecutarImportacion">Importar artículos</button>
    </div>
</dialog>

<script>window.RCP = <?= json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="js/rcp.js?v=14" defer></script>
</body>
</html>
