<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function responder(array $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function rcp_registrar_cambio(string $accion, string $detalle, string $pais, string $tienda = ''): void
{
    try {
        require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';
        if (!registrar_auditoria('BLOQUEO_TIENDA', $accion, $detalle, $pais, null, $tienda, $tienda)) {
            error_log('Bloqueo Tienda: no se guardó la auditoría ' . $accion);
        }
    } catch (Throwable $e) {
        error_log('Auditoría Bloqueo Tienda: ' . $e->getMessage());
    }
}

try {
    require_once __DIR__ . '/inc/init.php';
    $accion = (string)($_GET['action'] ?? 'list');
    $pais = rcp_pais((string)($_GET['pais'] ?? ''));
    $conexion = $sqlsrv_conn_exhibicion;
    rcp_cargar_alcance_tiendas($pais);

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
        switch ($accion) {
            case 'list':
                $filtros = [];
                foreach (array_keys(rcp_columnas_filtro()) as $campo) {
                    $filtros[$campo] = (string)($_GET['f_' . $campo] ?? '');
                }
                responder(['ok' => true] + rcp_listado($conexion, $pais,
                    (int)($_GET['page'] ?? 1), (int)($_GET['per'] ?? 50), $filtros,
                    (string)($_GET['sort'] ?? 'fecha'), (string)($_GET['dir'] ?? 'desc')));
            case 'options':
                $filtros = [];
                foreach (array_keys(rcp_columnas_filtro()) as $campo) {
                    $filtros[$campo] = (string)($_GET['f_' . $campo] ?? '');
                }
                responder(['ok' => true] + rcp_valores_filtro($conexion, $pais,
                    (string)($_GET['field'] ?? ''), (string)($_GET['q'] ?? ''), $filtros));
            case 'stores':
                responder(['ok' => true, 'rows' => rcp_tiendas_disponibles($conexion, $pais)]);
            default:
                responder(['ok' => false, 'message' => 'Acción no encontrada.'], 404);
        }
    }

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: GET, POST');
        responder(['ok' => false, 'message' => 'Método no permitido.'], 405);
    }

    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $esperado = (string)($_SESSION['rcp_tienda_csrf'] ?? '');
    if ($esperado === '' || !hash_equals($esperado, $token)) {
        responder(['ok' => false, 'message' => 'Sesión vencida. Actualiza la pantalla.'], 403);
    }
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 150000) {
        throw new InvalidArgumentException('La solicitud es demasiado grande.');
    }
    $cuerpo = file_get_contents('php://input');
    if (!is_string($cuerpo) || strlen($cuerpo) > 150000) {
        throw new InvalidArgumentException('La solicitud es demasiado grande.');
    }
    $datos = json_decode($cuerpo, true, 64, JSON_THROW_ON_ERROR);
    if (!is_array($datos)) throw new InvalidArgumentException('Datos inválidos.');
    $pais = rcp_pais((string)($datos['pais'] ?? ''));
    rcp_cargar_alcance_tiendas($pais);

    switch ($accion) {
        case 'add':
            $tienda = rcp_resolver_tienda($conexion, $pais, $datos['tienda'] ?? null);
            rcp_verificar_alcance_tienda($tienda);
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            if (!rcp_tienda_existe($conexion, $pais, $tienda)) {
                throw new InvalidArgumentException('La tienda no existe en el catálogo.');
            }
            if (!rcp_producto_existe($conexion, $pais, $plu, $ref)) {
                throw new InvalidArgumentException('El PLU y la referencia no pertenecen a un artículo activo.');
            }
            $nuevo = rcp_insertar($conexion, $pais, $tienda, $plu, $ref);
            if ($nuevo) rcp_registrar_cambio('ARTICULO_BLOQUEADO_TIENDA',
                'Tienda: ' . $tienda . ' | PLU: ' . $plu . ' | Referencia: ' . $ref, $pais, $tienda);
            responder(['ok' => true, 'insertado' => $nuevo,
                'message' => $nuevo ? 'Bloqueo de tienda agregado.' : 'El artículo ya está bloqueado en esta tienda.']);
        case 'edit':
            $tienda = rcp_resolver_tienda($conexion, $pais, $datos['tienda'] ?? null);
            rcp_verificar_alcance_tienda($tienda);
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            $origenTienda = rcp_validar_tienda($datos['tienda_original'] ?? null);
            rcp_verificar_alcance_tienda($origenTienda);
            $origenPlu = rcp_validar_texto($datos['plu_original'] ?? null, 100, 'PLU original');
            $origenRef = rcp_validar_texto($datos['referencia_original'] ?? null, 100, 'referencia original');
            if (!rcp_tienda_existe($conexion, $pais, $tienda)
                || !rcp_producto_existe($conexion, $pais, $plu, $ref)) {
                throw new InvalidArgumentException('Revise la tienda y el artículo en el catálogo.');
            }
            if ($tienda === $origenTienda && $plu === $origenPlu && $ref === $origenRef) {
                responder(['ok' => true, 'message' => 'No se detectaron cambios.']);
            }
            rcp_editar($conexion, $pais, $origenTienda, $origenPlu, $origenRef, $tienda, $plu, $ref);
            rcp_registrar_cambio('BLOQUEO_TIENDA_EDITADO',
                "Tienda: {$origenTienda} → {$tienda} | PLU: {$origenPlu} → {$plu} | Referencia: {$origenRef} → {$ref}", $pais, $tienda);
            responder(['ok' => true, 'message' => 'Bloqueo de tienda actualizado.']);
        case 'unlock':
            $tienda = rcp_validar_tienda($datos['tienda'] ?? null);
            rcp_verificar_alcance_tienda($tienda);
            $plu = rcp_validar_texto($datos['plu'] ?? null, 100, 'PLU');
            $ref = rcp_validar_texto($datos['referencia'] ?? null, 100, 'referencia');
            rcp_desbloquear($conexion, $pais, $tienda, $plu, $ref);
            rcp_registrar_cambio('ARTICULO_DESBLOQUEADO_TIENDA',
                'Tienda: ' . $tienda . ' | PLU: ' . $plu . ' | Referencia: ' . $ref, $pais, $tienda);
            responder(['ok' => true, 'message' => 'Artículo desbloqueado en la tienda.']);
        case 'import':
            if (!isset($datos['rows']) || !is_array($datos['rows'])) {
                throw new InvalidArgumentException('El lote no es válido.');
            }
            $r = rcp_importar_lote($conexion, $pais, $datos['rows']);
            rcp_registrar_cambio('BLOQUEO_TIENDA_IMPORTACION',
                'Lote: ' . count($datos['rows']) . ' | Nuevos: ' . $r['insertados']
                . ' | Existentes: ' . $r['existentes'], $pais);
            responder(['ok' => true] + $r);
        default:
            responder(['ok' => false, 'message' => 'Acción no encontrada.'], 404);
    }
} catch (DomainException $e) {
    responder(['ok' => false, 'message' => $e->getMessage()], 403);
} catch (InvalidArgumentException | JsonException $e) {
    responder(['ok' => false, 'message' => $e->getMessage()], 422);
} catch (Throwable $e) {
    $codigo = strtoupper(bin2hex(random_bytes(4)));
    error_log('Bloqueo Tienda [' . $codigo . ']: ' . $e->getMessage());
    responder(['ok' => false, 'message' => 'No se pudo completar la operación. Código: ' . $codigo], 500);
}
