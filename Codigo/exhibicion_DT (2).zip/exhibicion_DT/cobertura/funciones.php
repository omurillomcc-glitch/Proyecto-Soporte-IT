<?php
declare(strict_types=1);

const TABLA_COBERTURA = 'vistasMCC.dbo.TB_TD_RCP_COBERTURA_TIENDA';
const LIMITE_EXCEL = 500;

function mayus(string $valor): string {
    $valor = trim(preg_replace('/\s+/u', ' ', $valor) ?? $valor);
    if (function_exists('mb_strtoupper')) return mb_strtoupper($valor, 'UTF-8');
    return strtoupper(strtr($valor, ['á'=>'Á','é'=>'É','í'=>'Í','ó'=>'Ó','ú'=>'Ú','ñ'=>'Ñ','ü'=>'Ü']));
}

function texto_valido(string $texto, int $max): bool {
    $longitud = function_exists('mb_strlen') ? mb_strlen($texto, 'UTF-8') : strlen($texto);
    return $longitud > 0 && $longitud <= $max
        && preg_match('/\A[\p{L}\p{N} .,()\/\-&\x{0027}]+\z/u', $texto) === 1;
}


function normalizar_codigo_origen(string $codigo, string $pais): ?string
{
    $codigo = strtoupper(trim($codigo));

    // Aceptar únicamente códigos con guion bajo.
    if (preg_match('/^(01|02)_([0-9]{1,2})$/', $codigo, $partes)) {
        if ($partes[1] !== $pais) {
            return null;
        }

        $codigo = $partes[2];
    }

    // Solo almacenes con códigos numéricos de 1-2 dígitos.
    if (!preg_match('/^[0-9]{1,2}$/D', $codigo)) {
        return null;
    }

    return $pais . '_' . str_pad($codigo, 2, '0', STR_PAD_LEFT);
}


function validar_codigo_excel(string $codigo): bool {
    return preg_match('/\A(?:01|02)_[A-Z0-9]{2,7}\z/D', $codigo) === 1;
}
function nombre_pais(string $codigo): string {
    if (str_starts_with($codigo, '01_')) return 'Honduras';
    if (str_starts_with($codigo, '02_')) return 'Nicaragua';
    return 'Desconocido';
}

/** Catálogo oficial de las dos bases, sin modificar los almacenes. */
function catalogo_origen(): array
{
    global $paisAccesoCobertura;
    $catalogo = [];
    
    //  LOS CODIGOS A EXCLUIR 
    // Deben coincidir con el formato final del código normalizado
    $excluidos = [
        '02_10', 
        '02_11',
        '02_21',
        '02_22',
        '01_45',
        '01_48',
        '02_01',
        '02_02',
        '02_03',

     
    ];

    $permitidos = cobertura_codigos_permitidos();
    foreach (['01' => 'DETODO', '02' => 'ACANICARAGUA2'] as $pais => $base) {
        if ($paisAccesoCobertura !== null && $paisAccesoCobertura !== $pais) continue;
        // Los nombres de base son literales internos, nunca vienen del usuario.
        $stmt = query_sql(
            "SELECT CODALMACEN, NOMBREALMACEN FROM {$base}.dbo.ALMACEN "
            . 'WHERE CODALMACEN IS NOT NULL AND NOMBREALMACEN IS NOT NULL'
        );

        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $codigo = normalizar_codigo_origen((string) $row['CODALMACEN'], $pais);
            $nombre = trim((string) $row['NOMBREALMACEN']);

            if ($codigo === null || $nombre === '') {
                continue;
            }
            if ($permitidos !== null && !in_array($codigo, $permitidos, true)) {
                continue;
            }

            // FILTRO QUE VALIDA Si el código está en la lista negra, lo saltamos
            if (in_array($codigo, $excluidos, true)) {
                continue;
            }

            // Un mismo código no puede representar dos nombres distintos SOLO ACEPTA GUION BAJO.
          if (isset($catalogo[$codigo])) {
         if (mayus($catalogo[$codigo]['nombre']) !== mayus($nombre)) {
        error_log(
            'Código de almacén ambiguo: ' . $codigo .
            ' | Nombre existente: ' . $catalogo[$codigo]['nombre'] .
            ' | Nombre nuevo: ' . $nombre
        );continue;
         }
 continue;
}
            $catalogo[$codigo] = [
                'codigo' => $codigo,
                'nombre' => $nombre,
                'pais' => $pais,
            ];
        }
        sqlsrv_free_stmt($stmt);
    }

    ksort($catalogo, SORT_NATURAL);
    return $catalogo;
}

function cobertura_existente(string $codigo): ?array {
    cobertura_exigir_codigo($codigo);
    $stmt = query_sql('SELECT CODTIENDA, TIENDA_DETODO, COBERTURA, [TAMAÑO] AS TAMANO, M2S
                       FROM ' . TABLA_COBERTURA . ' WHERE CODTIENDA = ?', [$codigo]);
    $resultado = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC) ?: null;
    sqlsrv_free_stmt($stmt);
    return $resultado;
}

function existentes_todos(): array {
    [$restriccion, $parametros] = cobertura_restriccion_sql();
    $stmt = query_sql('SELECT CODTIENDA, COBERTURA, [TAMAÑO] AS TAMANO, M2S FROM '
        . TABLA_COBERTURA . ' WHERE CODTIENDA IS NOT NULL' . $restriccion, $parametros);
    $mapa = [];
    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $codigo = trim((string)$r['CODTIENDA']);
        $mapa[$codigo] = $r;
    }
    sqlsrv_free_stmt($stmt);
    return $mapa;
}

function validar_datos(string $codigo, string $nombreExcel, string $cobertura, string $tamano, string $m2s, array $catalogo): array {
    $codigo = mayus($codigo);
    $cobertura = mayus($cobertura);
    $tamano = mayus($tamano);
    $nombreExcel = trim($nombreExcel);
    $m2s = trim(str_replace(',', '.', $m2s));
    if (!validar_codigo_excel($codigo)) throw new InvalidArgumentException('Código inválido; use 01_XX o 02_XX.');
    if (!isset($catalogo[$codigo])) throw new InvalidArgumentException('El código no existe en el catálogo oficial de SQL Server.');
    if (mayus($nombreExcel) !== mayus($catalogo[$codigo]['nombre'])) {
        throw new InvalidArgumentException('El nombre no coincide con el nombre oficial del almacén.');
    }
    if (!texto_valido($cobertura, 50)) throw new InvalidArgumentException('Cobertura inválida: máximo 50 caracteres; solo texto, números y puntuación permitida.');
    if (!in_array($tamano, ['PEQUEÑA', 'MEDIANA', 'GRANDE', 'PEQUEÑO', 'MEDIANO'], true)) throw new InvalidArgumentException('Tamaño no válido.');
    if (!preg_match('/\A\d{1,9}(?:\.\d{1,2})?\z/D', $m2s) || (float)$m2s <= 0) {
        throw new InvalidArgumentException('M2S debe ser un número mayor que cero con máximo dos decimales.');
    }
    return ['codigo'=>$codigo, 'nombre'=>$catalogo[$codigo]['nombre'], 'pais'=>$catalogo[$codigo]['pais'],
        'cobertura'=>$cobertura, 'tamano'=>$tamano, 'm2s'=>number_format((float)$m2s, 2, '.', '')];
}

function estado_fila(array $fila, ?array $actual): string {
    if (!$actual) return 'NUEVA';
    $cobertura = mayus((string)($actual['COBERTURA'] ?? ''));
    $tamano = mayus((string)($actual['TAMANO'] ?? ''));
    $m2s = $actual['M2S'] === null ? '' : number_format((float)$actual['M2S'], 2, '.', '');
    return ($cobertura === $fila['cobertura'] && $tamano === $fila['tamano'] && $m2s === $fila['m2s'])
        ? 'SIN CAMBIOS' : 'ACTUALIZAR';
}

/** Guarda en la tabla existente SIN crear columnas ni índices SQL. */
function guardar_filas(array $filas, string $modo = 'ambos', ?array $catalogo = null): array {
    if (!in_array($modo, ['ambos', 'nueva', 'editar'], true)) {
        throw new InvalidArgumentException('Modo de guardado no válido.');
    }
    global $db;
    if ($catalogo === null) {
        $catalogo = catalogo_origen();
    }
    foreach ($filas as $fila) {
        cobertura_exigir_codigo((string)($fila['codigo'] ?? ''));
    }
    if (!sqlsrv_begin_transaction($db)) throw new RuntimeException('No se pudo iniciar la transacción.');
    $totales = ['nuevas'=>0, 'actualizadas'=>0, 'sin_cambios'=>0];
    $auditar = [];
    try {
        // No se neceita crear  nada de índices ni tablas nuevas.
        $lock = query_sql(
            "DECLARE @resultado INT; "
            . "EXEC @resultado = sp_getapplock "
            . "@Resource = 'COBERTURA_TIENDAS_APP', "
            . "@LockMode = 'Exclusive', "
            . "@LockOwner = 'Transaction', "
            . "@LockTimeout = 10000; "
            . "SELECT @resultado AS resultado;"
        );
        $resultadoLock = sqlsrv_fetch_array($lock, SQLSRV_FETCH_NUMERIC);
        sqlsrv_free_stmt($lock);
        if ($resultadoLock === null || (int) $resultadoLock[0] < 0) {
            throw new RuntimeException('No se pudo reservar la operación de guardado.');
        }
        foreach ($filas as $fila) {
            $fila = validar_datos((string)$fila['codigo'], (string)$fila['nombre'], (string)$fila['cobertura'],
                (string)$fila['tamano'], (string)$fila['m2s'], $catalogo);
            
            $stmt = query_sql('SELECT TOP (1) CODTIENDA, COBERTURA, [TAMAÑO] AS TAMANO, M2S FROM ' . TABLA_COBERTURA .
                ' WITH (UPDLOCK, HOLDLOCK) WHERE CODTIENDA = ?',
                [$fila['codigo']]);
            $actual = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC) ?: null;
            sqlsrv_free_stmt($stmt);

            if ($modo === 'nueva' && $actual) {
                throw new InvalidArgumentException('La tienda ya existe: ' . $fila['codigo']);
            }
            if ($modo === 'editar' && !$actual) {
                throw new InvalidArgumentException('La tienda ya no existe: ' . $fila['codigo']);
            }
            $estado = estado_fila($fila, $actual);
            
            if (!$actual) {
                query_sql('INSERT INTO ' . TABLA_COBERTURA .
                    ' (CODTIENDA, TIENDA_DETODO, COBERTURA, [TAMAÑO], M2S) VALUES (?, ?, ?, ?, ?)',
                    [$fila['codigo'], $fila['nombre'], $fila['cobertura'], $fila['tamano'], $fila['m2s']]);
                $totales['nuevas']++;
                $auditar[] = ['tipo'=>'AGREGAR_COBERTURA', 'fila'=>$fila, 'anterior'=>null];
            } elseif ($estado === 'ACTUALIZAR') {
                // CODTIENDA y TIENDA_DETODO nunca se actualizan.
                query_sql('UPDATE ' . TABLA_COBERTURA .
                    ' SET COBERTURA = ?, [TAMAÑO] = ?, M2S = ? WHERE CODTIENDA = ?',
                    [$fila['cobertura'], $fila['tamano'], $fila['m2s'], $actual['CODTIENDA']]);
                $totales['actualizadas']++;
                $auditar[] = ['tipo'=>'EDITAR_COBERTURA', 'fila'=>$fila, 'anterior'=>$actual];
            } else {
                $totales['sin_cambios']++;
            }
        }
        if (!sqlsrv_commit($db)) throw new RuntimeException('No se pudo confirmar la transacción.');
    } catch (Throwable $e) {
        sqlsrv_rollback($db);
        throw $e;
    }
 if (!empty($auditar)) {
    try {
        require_once dirname(__DIR__) . '/auditoria/auditoria_helper.php';

        foreach ($auditar as $evento) {
            $fila   = $evento['fila'] ?? [];
            $previo = $evento['anterior'] ?? null;
            $tipo   = $evento['tipo'] ?? 'MODIFICACION';

            $codigo   = $fila['codigo'] ?? 'S/N';
            $nombre   = $fila['nombre'] ?? 'Desconocido';
            $pais     = $fila['pais'] ?? '';

            // Si es un registro nuevo
            if ($previo === null) {
                $descripcion = "Creación de cobertura — Cobertura: {$fila['cobertura']} | Tamaño: {$fila['tamano']} | M2S: {$fila['m2s']}";
            } else {
                // Detectar cambios individuales de forma limpia
                $cambios = [];
                if (($previo['COBERTURA'] ?? '') !== ($fila['cobertura'] ?? '')) {
                    $cambios[] = "Cobertura: '{$previo['COBERTURA']}' A '{$fila['cobertura']}'";
                }
                if (($previo['TAMANO'] ?? '') !== ($fila['tamano'] ?? '')) {
                    $cambios[] = "Tamaño: '{$previo['TAMANO']}' A '{$fila['tamano']}'";
                }
                if (($previo['M2S'] ?? '') !== ($fila['m2s'] ?? '')) {
                    $cambios[] = "M2S: '{$previo['M2S']}' A '{$fila['m2s']}'";
                }

                $detalleCambios = !empty($cambios) ? implode(' | ', $cambios) : "Actualización de datos generales";
                
                // Formato limpio sin repetir Tienda (usando CODALMACEN implícito mediante el código)
                $descripcion = "Modificación: {$detalleCambios}";
            }

            $region = ($pais === '01') ? 'HONDURAS' : 'NICARAGUA';

            registrar_auditoria('COBERTURA', $tipo, $descripcion, $region, null, $nombre, $codigo);
        }
    } catch (Throwable $errorAuditoria) {
        error_log('Error en auditoría de cobertura: ' . $errorAuditoria->getMessage());
    }
}
    return $totales;
}