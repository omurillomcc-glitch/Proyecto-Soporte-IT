<?php
declare(strict_types=1);

/*
 * COBERTURA DE TIENDAS - CONFIGURACIÓN
 * Reutiliza el login, MySQL y SQL Server.
 * No crea ni modifica tablas o columnas.
 */
ini_set('display_errors', '0');
error_reporting(E_ALL);

$raiz = dirname(__DIR__);
require_once $raiz . '/controlusuarios/auth.php';
require_login();
require_once $raiz . '/controlusuarios/db.php';

// Comprobar acceso en cada ruta de Cobertura.
require_module_access('cobertura');
$usuario = me();
$usuarioId = (int)($usuario['id'] ?? 0);
$rol = (string)($usuario['rol'] ?? '');
$puedeEditar = true;
// Los administradores autorizados se mantienen en su país; el Propietario ve ambos.
require_once $raiz . '/controlusuarios/accesos_menu.php';
$esPropietarioCobertura = am_es_propietario($conn, $usuarioId);
$paisOrigenCobertura = strtoupper(trim((string)($usuario['pais_code'] ?? '')));
if (!$esPropietarioCobertura && !in_array($paisOrigenCobertura, ['HN', 'NI'], true)) {
    http_response_code(403);
    exit('El usuario no tiene un país válido asignado.');
}
$paisAccesoCobertura = $esPropietarioCobertura ? null
    : ($paisOrigenCobertura === 'NI' ? '02' : '01');

require_once $raiz . '/controlusuarios/alcance_tiendas.php';
$almacenesPermitidosCobertura = $esPropietarioCobertura ? null
    : at_almacenes_permitidos($conn, $usuario);
$puedeImportarCobertura = am_puede($conn, $usuarioId, 'cobertura_importar');

// Los controles por tienda se aplican también a las consultas SQL y guardados.
function cobertura_codigos_permitidos(): ?array
{
    global $almacenesPermitidosCobertura, $paisAccesoCobertura;
    if ($almacenesPermitidosCobertura === null) return null;
    if (!in_array($paisAccesoCobertura, ['01', '02'], true)) return [];
    $codigos = [];
    foreach ($almacenesPermitidosCobertura as $almacen) {
        $normal = at_normalizar_codigo((string)$almacen);
        if ($normal !== '') $codigos[$paisAccesoCobertura . '_' . $normal] = true;
    }
    return array_keys($codigos);
}

function cobertura_exigir_codigo(string $codigo): void
{
    global $paisAccesoCobertura;
    $codigo = strtoupper(trim($codigo));
    if (!preg_match('/^(01|02)_([0-9]{1,4})$/D', $codigo, $partes)) {
        throw new DomainException('Código de tienda no autorizado.');
    }
    if ($paisAccesoCobertura !== null && $partes[1] !== $paisAccesoCobertura) {
        throw new DomainException('No tienes acceso al país solicitado.');
    }
    $codigos = cobertura_codigos_permitidos();
    if ($codigos !== null) {
        $normal = at_normalizar_codigo($partes[2]);
        if (!in_array($partes[1] . '_' . $normal, $codigos, true)) {
            throw new DomainException('No tienes acceso a esa tienda.');
        }
    }
}

function cobertura_restriccion_sql(): array
{
    global $paisAccesoCobertura;
    $codigos = cobertura_codigos_permitidos();
    if ($codigos !== null) {
        if (!$codigos) return [' AND 1 = 0', []];
        if (count($codigos) > 900) throw new RuntimeException('Demasiadas tiendas asignadas.');
        $marcadores = implode(', ', array_fill(0, count($codigos), '?'));
        return [" AND CODTIENDA IN (" . $marcadores . ")", $codigos];
    }
    if ($paisAccesoCobertura !== null) {
        return [" AND CODTIENDA LIKE ?", [$paisAccesoCobertura . '[_]%']];
    }
    return ['', []];
}

// Misma conexión que utiliza Exhibición DT; NO se copian las credenciales.
require_once $raiz . '/exhibiciontotal/conexion_exhibicion.php';
$db = $sqlsrv_conn_exhibicion ?? null;

if ($db === false || $db === null) {
    http_response_code(503);
    exit('No se pudo conectar a SQL Server.');
}

if (empty($_SESSION['cobertura_csrf'])) {
    $_SESSION['cobertura_csrf'] = bin2hex(random_bytes(32));
}

function csrf(): string
{
    return (string) $_SESSION['cobertura_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="'
        . htmlspecialchars(csrf(), ENT_QUOTES, 'UTF-8') . '">';
}

function check_csrf(): void
{
    if (!hash_equals(csrf(), (string) ($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        exit('Solicitud no autorizada. Actualiza la página.');
    }
}

function require_editor(): void
{
    global $puedeEditar;
    if (!$puedeEditar) {
        http_response_code(403);
        exit('No puedes modificar la cobertura.');
    }
}

function h(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function cobertura_parametros_retorno(array $source): array
{
    $pais = $source['volver_pais'] ?? $source['pais'] ?? '';
    $pais = is_scalar($pais) ? (string) $pais : '';
    if (!in_array($pais, ['', '01', '02'], true)) $pais = '';

    $buscar = $source['volver_buscar'] ?? $source['buscar'] ?? '';
    $buscar = is_scalar($buscar) ? trim((string) $buscar) : '';
    if (strlen($buscar) > 100) $buscar = substr($buscar, 0, 100);

    $pagina = $source['volver_pagina'] ?? $source['pagina'] ?? 1;
    $pagina = is_scalar($pagina) ? (int) $pagina : 1;
    $pagina = max(1, min(10000, $pagina));

    return ['pais' => $pais, 'buscar' => $buscar, 'pagina' => $pagina];
}

function cobertura_campos_retorno(array $source): string
{
    $parametros = cobertura_parametros_retorno($source);
    return '<input type="hidden" name="volver_pais" value="' . h($parametros['pais']) . '">'
        . '<input type="hidden" name="volver_buscar" value="' . h($parametros['buscar']) . '">'
        . '<input type="hidden" name="volver_pagina" value="' . h($parametros['pagina']) . '">';
}

function cobertura_url_retorno(array $source, ?string $marca = null, ?array $totales = null): string
{
    $parametros = cobertura_parametros_retorno($source);
    if ($marca !== null) $parametros[$marca] = 1;
    if ($totales !== null) {
        $parametros['nuevas'] = max(0, (int) ($totales['nuevas'] ?? 0));
        $parametros['actualizadas'] = max(0, (int) ($totales['actualizadas'] ?? 0));
        $parametros['sin_cambios'] = max(0, (int) ($totales['sin_cambios'] ?? 0));
    }
    return 'index.php?' . http_build_query($parametros);
}

function go(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}

function query_sql(string $sql, array $parametros = []): mixed
{
    global $db;
    $resultado = sqlsrv_query($db, $sql, $parametros);
    if ($resultado === false) {
        error_log('SQL Cobertura: ' . json_encode(sqlsrv_errors(), JSON_UNESCAPED_UNICODE));
        throw new RuntimeException('Ocurrió un error al consultar SQL Server.');
    }
    return $resultado;
}

require_once __DIR__ . '/funciones.php';
