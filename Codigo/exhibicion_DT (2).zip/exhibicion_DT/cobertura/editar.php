<?php
declare(strict_types=1);

/** Permite editar solo los tres campos de cobertura de una tienda. */
require_once __DIR__ . '/bootstrap.php';
require_editor();

$codigo = mayus((string) ($_GET['codigo'] ?? ''));

if (!validar_codigo_excel($codigo)) {
    http_response_code(400);
    exit('Código de tienda inválido.');
}

$tienda = cobertura_existente($codigo);
if ($tienda === null) {
    http_response_code(404);
    exit('Tienda no encontrada.');
}

$titulo = 'Editar cobertura';
require __DIR__ . '/encabezado.php';
?>

<div class="exh-wrap">
    <div class="exh-panel">
        <div class="exh-card">
            
            <!-- Encabezado de la tarjeta -->
            <div class="exh-sheet-heading">
                <div class="exh-sheet-name">
                    <i class="fa-solid fa-pen-to-square"></i>
                    <strong><?= h($titulo) ?></strong>
                    <span class="exh-sheet-divider"></span>
                    <small>Modificar especificaciones de la tienda</small>
                </div>
                <div class="exh-sheet-meta">
                    <i class="fa-solid fa-lock"></i>
                    <span>El código y nombre son de solo lectura.</span>
                </div>
            </div>

            <!-- Formulario de edición -->
            <form method="post" action="guardar.php" autocomplete="off" style="padding: 20px;">
                <?= csrf_field() ?>
                <?= cobertura_campos_retorno($_GET) ?>
                <input type="hidden" name="accion" value="editar">
                <input type="hidden" name="codigo" value="<?= h($codigo) ?>">

                <div class="grid" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; margin-bottom: 20px;">
                    <div class="campo">
                        <label for="codigoVisible">Código de tienda</label>
                        <input id="codigoVisible" value="<?= h($tienda['CODTIENDA']) ?>" readonly>
                    </div>

                    <div class="campo" style="grid-column: 1 / -1;">
                        <label for="nombreVisible">Nombre de la tienda</label>
                        <input id="nombreVisible" value="<?= h($tienda['TIENDA_DETODO']) ?>" readonly>
                    </div>

                    <div class="campo">
                        <label for="cobertura">Cobertura *</label>
                        <input
                            id="cobertura"
                            name="cobertura"
                            value="<?= h($tienda['COBERTURA']) ?>"
                            maxlength="50"
                            required
                        >
                    </div>

                    <div class="campo">
                        <label for="tamano">Tamaño *</label>
                        <select id="tamano" name="tamano" required>
                            <?php foreach (['PEQUEÑO', 'MEDIANO', 'GRANDE'] as $opcion): ?>
                                <option <?= mayus((string) $tienda['TAMANO']) === $opcion ? 'selected' : '' ?>>
                                    <?= h($opcion) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="campo" style="grid-column: 1 / -1;">
                        <label for="m2s">Metros cuadrados (M2S) *</label>
                        <input
                            id="m2s"
                            name="m2s"
                            inputmode="decimal"
                            value="<?= $tienda['M2S'] === null
                                ? ''
                                : h(number_format((float) $tienda['M2S'], 2, '.', '')) ?>"
                            required
                        >
                    </div>
                </div>

                <div class="acciones-form" style="display: flex; gap: 10px; border-top: 1px solid var(--exh-border); padding-top: 16px;">
                    <button type="submit" class="exh-btn-label exh-btn-primary">Guardar cambios</button>
                    <a class="exh-btn-label" id="btnLimpiar" href="<?= h(cobertura_url_retorno($_GET)) ?>">Cancelar</a>
                </div>
            </form>

        </div>
    </div>
</div>

<?php require __DIR__ . '/pie.php'; ?>