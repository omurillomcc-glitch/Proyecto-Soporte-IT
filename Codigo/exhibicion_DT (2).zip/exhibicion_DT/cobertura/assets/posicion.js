(() => {
    'use strict';

    const text1 = 'coberturaPosicionListado';
    const element1 = () => document.querySelector('.exh-table-shell');
    const value1 = () => {
        try {
            return window.parent !== window ? window.parent : window;
        } catch (_) {
            return window;
        }
    };
    const value2 = () => {
        try {
            return value1().sessionStorage;
        } catch (_) {
            return null;
        }
    };
    const value3 = () => {
        try {
            const responseData1 = JSON.parse(value2()?.getItem(text1) || 'null');
            return responseData1 && Date.now() - responseData1.fecha < 30 * 60 * 1000 ? responseData1 : null;
        } catch (_) {
            return null;
        }
    };
    const value4 = () => {
        const value5 = value2();
        if (!value5) return;
        const value6 = value3();
        const value7 = value1();
        const value8 = element1();
        const options1 = {
            x: value8 ? value7.scrollX : (value6?.x ?? value7.scrollX),
            y: value8 ? value7.scrollY : (value6?.y ?? value7.scrollY),
            tablaX: value8 ? value8.scrollLeft : (value6?.tablaX || 0),
            fecha: Date.now()
        };
        try {
            value5.setItem(text1, JSON.stringify(options1));
        } catch (_) {}
    };
    const value9 = posicion => {
        if (!posicion) return;
        const value10 = () => {
            const value11 = element1();
            if (value11) value11.scrollLeft = Number(posicion.tablaX) || 0;
            value1().scrollTo({
                left: Number(posicion.x) || 0,
                top: Number(posicion.y) || 0,
                behavior: 'instant'
            });
        };
        requestAnimationFrame(() => requestAnimationFrame(() => {
            value10();
            window.setTimeout(value10, 180);
            window.setTimeout(value10, 450);
        }));
    };

    let value12 = false;
    let value13 = false;
    const value14 = () => {
        if (value12 || value13) return;
        value12 = true;
        requestAnimationFrame(() => {
            value12 = false;
            value4();
        });
    };

    document.addEventListener('DOMContentLoaded', () => {
        const url = new URL(window.location.href);
        const value15 = /\/cobertura\/index\.php$/.test(url.pathname);
        if (value15 && (url.searchParams.has('ok') || url.searchParams.has('importado'))) {
            const value16 = value2();
            const value17 = value3();
            try {
                value16?.removeItem(text1);
            } catch (_) {}
            value13 = Boolean(value17);
            value9(value17);
            if (value17) {
                window.setTimeout(() => {
                    value13 = false;
                    try {
                        value16?.removeItem(text1);
                    } catch (_) {}
                }, 600);
            }
        }

        const value18 = value1();
        value18.addEventListener('scroll', value14, { passive: true });
        element1()?.addEventListener('scroll', value14, { passive: true });
        document.addEventListener('submit', value4, true);
        document.addEventListener('click', event => {
            if (event.target.closest('a[href*="nueva.php"], a[href*="importar.php"]')) value4();
        }, true);
    });
})();
