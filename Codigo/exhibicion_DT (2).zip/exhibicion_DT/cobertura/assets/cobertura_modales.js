(() => {
    'use strict';

    const element1 = document.getElementById('modalNuevaTienda');
    const element2 = document.getElementById('modalEditarTienda');
    if (!element1 || !element2) return;

    const element3 = document.getElementById('codigoNueva');
    const element4 = document.getElementById('cobTiendasEstado');
    const element5 = document.getElementById('cobTiendaPreview');
    const element6 = document.getElementById('cobGuardarNueva');
    let itemCount1 = null;
    let value1 = null;
    let value2 = null;
    let value3 = null;

    function posicionarModalVisible() {
        if (!value2) return;
        try {
            const value4 = window.frameElement;
            if (!value4 || window.parent === window) return;
            const bounds1 = value4.getBoundingClientRect();
            const value5 = window.parent.innerHeight;
            const boundedValue1 = Math.max(0, -bounds1.top);
            const fin = Math.min(value4.clientHeight, value5 - bounds1.top);
            const boundedValue2 = Math.max(0, fin - boundedValue1);
            if (!boundedValue2) return;
            value2.style.top = `${boundedValue1}px`;
            value2.style.bottom = 'auto';
            value2.style.height = `${boundedValue2}px`;
            const element7 = value2.querySelector('.cob-modal-dialog');
            if (element7) {
                element7.style.maxHeight = `${Math.max(1, Math.min(820, value5 * 0.9, boundedValue2 - 24))}px`;
            }
        } catch (_) {
            // En acceso directo se usa el alto completo del navegador.
        }
    }

    function mostrarModal(modal) {
        if (value2) cerrarModal();
        value3 = document.activeElement;
        value2 = modal;
        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('cob-modal-open');
        posicionarModalVisible();
        const element8 = modal.querySelector('.cob-modal-dialog');
        element8?.focus();
        if (modal === element1) {
            cargarTiendas();
            element3.focus();
        } else {
            document.getElementById('cobEditarCobertura').focus();
        }
    }

    function cerrarModal() {
        if (!value2) return;
        value2.hidden = true;
        value2.style.top = '';
        value2.style.bottom = '';
        value2.style.height = '';
        const element9 = value2.querySelector('.cob-modal-dialog');
        if (element9) element9.style.maxHeight = '';
        value2.setAttribute('aria-hidden', 'true');
        value2 = null;
        document.body.classList.remove('cob-modal-open');
        if (value3 && value3.isConnected) value3.focus();
    }

    function actualizarPreview() {
        const state1 = (itemCount1 || []).find(t => t.codigo === element3.value);
        element5.hidden = !state1;
        if (!state1) return;
        document.getElementById('cobTiendaNombre').textContent = state1.nombre;
        document.getElementById('cobTiendaDetalle').textContent = `${state1.codigo} · ${state1.pais}`;
    }

    function dibujarTiendas() {
        if (!itemCount1) return;
        const inputValue1 = element3.value;
        const filteredItems1 = itemCount1.filter(t => !t.registrada);
        element3.replaceChildren();
        const element10 = document.createElement('option');
        element10.value = '';
        element10.textContent = filteredItems1.length ? 'Seleccionar tienda...' : 'No hay tiendas pendientes de agregar';
        element3.append(element10);

        for (const state2 of itemCount1) {
            const element11 = document.createElement('option');
            element11.value = state2.codigo;
            element11.disabled = Boolean(state2.registrada);
            element11.textContent = `${state2.codigo} · ${state2.nombre} (${state2.pais})${state2.registrada ? ' — Ya registrada' : ''}`;
            element3.append(element11);
        }

        element3.disabled = filteredItems1.length === 0;
        element3.value = filteredItems1.some(t => t.codigo === inputValue1) ? inputValue1 : '';
        element6.disabled = filteredItems1.length === 0;
        element4.textContent = `${itemCount1.length} tienda(s) del catálogo · ${filteredItems1.length} disponible(s) para agregar`;
        actualizarPreview();
    }

    async function cargarTiendas() {
        if (itemCount1) return dibujarTiendas();
        if (value1) return value1;
        element4.textContent = 'Consultando el catálogo oficial...';
        element6.disabled = true;
        element3.disabled = true;
        value1 = (async () => {
            try {
                const response1 = await fetch('tiendas_disponibles.php', {
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' },
                    cache: 'no-store'
                });
                if (!response1.ok) throw new Error('No se pudo consultar el catálogo');
                const responseData1 = await response1.json();
                if (!Array.isArray(responseData1.tiendas)) throw new Error('Respuesta inválida');
                itemCount1 = responseData1.tiendas;
                dibujarTiendas();
            } catch (_) {
                element4.textContent = 'No fue posible cargar las tiendas. Cierra y vuelve a abrir el formulario.';
                element6.disabled = true;
            } finally {
                value1 = null;
            }
        })();
        return value1;
    }

    function prepararEdicion(boton) {
        const d = boton.dataset;
        document.getElementById('cobEditarCodigoReal').value = d.codigo || '';
        document.getElementById('cobEditarCodigoVisible').value = d.codigo || '';
        document.getElementById('cobEditarNombreVisible').value = d.nombre || '';
        document.getElementById('cobEditarNombrePreview').textContent = d.nombre || 'Tienda';
        document.getElementById('cobEditarPaisPreview').textContent = `${d.codigo || ''} · ${d.pais || ''}`;
        document.getElementById('cobEditarCobertura').value = d.cobertura || '';
        const element12 = document.getElementById('cobEditarTamano');
        const value6 = String(d.tamano || '').trim().toLocaleUpperCase('es');
        element12.querySelectorAll('option[data-temporal="1"]').forEach(opcion => opcion.remove());
        if (value6 && !Array.from(element12.options).some(opcion => opcion.value === value6)) {
            const value7 = new Option(value6, value6);
            value7.dataset.temporal = '1';
            element12.add(value7);
        }
        element12.value = value6;
        document.getElementById('cobEditarM2s').value = d.m2s || '';
        mostrarModal(element2);
    }

    document.addEventListener('click', (evento) => {
        const value8 = evento.target.closest('[data-cob-modal]');
        if (value8) {
            if (value8.dataset.cobModal === 'nueva') mostrarModal(element1);
            if (value8.dataset.cobModal === 'editar') prepararEdicion(value8);
            return;
        }
        if (evento.target.closest('[data-cob-close]')) cerrarModal();
        if (value2 && evento.target === value2) cerrarModal();
    });

    document.addEventListener('keydown', (evento) => {
        if (!value2) return;
        if (evento.key === 'Escape') { evento.preventDefault(); cerrarModal(); }
        if (evento.key !== 'Tab') return;
        const elements1 = Array.from(value2.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href]'));
        if (!elements1.length) return;
        const value9 = elements1[0];
        const value10 = elements1[elements1.length - 1];
        if (evento.shiftKey && document.activeElement === value9) { evento.preventDefault(); value10.focus(); }
        if (!evento.shiftKey && document.activeElement === value10) { evento.preventDefault(); value9.focus(); }
    });

    window.addEventListener('resize', posicionarModalVisible);
    try { if (window.parent !== window) window.parent.addEventListener('scroll', posicionarModalVisible, { passive: true }); } catch (_) {}
    element3.addEventListener('change', actualizarPreview);
    const searchParams1 = new URLSearchParams(window.location.search);
    if (searchParams1.get('modal') === 'nueva') mostrarModal(element1);
})();
