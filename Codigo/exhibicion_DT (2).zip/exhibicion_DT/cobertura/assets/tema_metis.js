(() => {
    'use strict';

    if (window.parent === window) return;

    const value1 = document.documentElement;
    value1.classList.add('cobertura-dentro-del-menu');

    try {
        const value2 = window.parent.document;
        const value3 = value2.documentElement;
        const value4 = value2.body;
        const value5 = window.frameElement;
        value1.setAttribute('data-metis-frame', '1');

        const value6 = [
            '--metis-primary', '--metis-primary-soft', '--metis-bg',
            '--metis-panel', '--metis-border', '--metis-text',
            '--metis-muted', '--metis-hover'
        ];

        function sincronizarTema() {
            const value7 = value3.getAttribute('data-bs-theme') || 'light';
            value1.setAttribute('data-bs-theme', value7);
            value1.setAttribute('data-metis-accent', value3.getAttribute('data-metis-accent') || 'blue');
            const value8 = window.parent.getComputedStyle(value3);
            const value9 = window.parent.getComputedStyle(value4);
            for (const value10 of value6) {
                const value11 = value8.getPropertyValue(value10).trim() || value9.getPropertyValue(value10).trim();
                if (value11) value1.style.setProperty(value10, value11);
            }
        }

        sincronizarTema();
        const mutationObserver1 = new MutationObserver(sincronizarTema);
        mutationObserver1.observe(value3, { attributes: true, attributeFilter: ['data-bs-theme', 'data-metis-accent', 'class', 'style'] });
        mutationObserver1.observe(value4, { attributes: true, attributeFilter: ['class', 'style'] });

        // El iframe conserva el fondo del menú, sin una tarjeta exterior.
        if (value5 && value5.id === 'metisCoberturaFrame') {
            const text1 = 'cobertura-metis-sin-marco';
            if (!value2.getElementById(text1)) {
                const value12 = value2.createElement('style');
                value12.id = text1;
                value12.textContent = `
                    body.metis-app .metis-main:has(#metisCoberturaFrame) {
                        background: var(--metis-bg, #f6f8fc) !important;
                        border: 0 !important;
                        box-shadow: none !important;
                    }
                    body.metis-app .metis-module-panel:has(#metisCoberturaFrame) {
                        background: transparent !important;
                        border: 0 !important;
                        outline: 0 !important;
                        border-radius: 0 !important;
                        box-shadow: none !important;
                        padding: 0 !important;
                        margin: 0 !important;
                    }
                    body.metis-app #metisCoberturaFrame {
                        display: block !important;
                        width: 100% !important;
                        border: 0 !important;
                        border-radius: 0 !important;
                        outline: 0 !important;
                        box-shadow: none !important;
                        background: var(--metis-bg, #f6f8fc) !important;
                    }
                `;
                value2.head.appendChild(value12);
            }

            const text2 = 'cobertura-modal-backdrop';
            let value13 = null;
            let value14 = null;
            let value15 = false;

            function limpiarSombra() {
                value2.getElementById(text2)?.remove();
                value13 = null;
                value14 = null;
            }

            function actualizarSombra() {
                value15 = false;
                const element1 = document.querySelector('.cob-modal:not([hidden])');
                const element2 = element1?.querySelector('.cob-modal-dialog');
                if (!value5.isConnected || !element2) {
                    limpiarSombra();
                    return;
                }

                value14 = element1;
                const bounds1 = value5.getBoundingClientRect();
                const bounds2 = element2.getBoundingClientRect();
                const value16 = bounds1.width / value5.clientWidth || 1;
                const value17 = bounds1.height / value5.clientHeight || 1;
                const value18 = bounds1.left + bounds2.left * value16;
                const value19 = bounds1.top + bounds2.top * value17;
                const value20 = value18 + bounds2.width * value16;
                const value21 = value19 + bounds2.height * value17;
                const value22 = window.parent.innerWidth;
                const value23 = window.parent.innerHeight;

                if (!value13) {
                    value13 = value2.createElement('div');
                    value13.id = text2;
                    value13.setAttribute('aria-hidden', 'true');
                    Object.assign(value13.style, {
                        position: 'fixed',
                        inset: '0',
                        zIndex: '2147483000',
                        pointerEvents: 'none'
                    });
                    for (let i = 0; i < 4; i++) {
                        const value24 = value2.createElement('div');
                        Object.assign(value24.style, {
                            position: 'fixed',
                            background: 'rgba(13, 22, 40, .56)',
                            backdropFilter: 'blur(3px)',
                            pointerEvents: 'auto'
                        });
                        value24.addEventListener('click', () => {
                            if (value14) {
                                value14.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                            }
                        });
                        value13.append(value24);
                    }
                    value4.append(value13);
                }

                const value25 = [
                    { left: '0', top: '0', width: value22 + 'px', height: Math.max(0, value19) + 'px' },
                    { left: '0', top: Math.max(0, value21) + 'px', width: value22 + 'px', height: Math.max(0, value23 - value21) + 'px' },
                    { left: '0', top: Math.max(0, value19) + 'px', width: Math.max(0, value18) + 'px', height: Math.max(0, Math.min(value23, value21) - Math.max(0, value19)) + 'px' },
                    { left: Math.max(0, value20) + 'px', top: Math.max(0, value19) + 'px', width: Math.max(0, value22 - value20) + 'px', height: Math.max(0, Math.min(value23, value21) - Math.max(0, value19)) + 'px' }
                ];
                [...value13.children].forEach((panel, indice) => Object.assign(panel.style, value25[indice]));
            }

            function programarSombra() {
                if (value15) return;
                value15 = true;
                window.parent.requestAnimationFrame(actualizarSombra);
            }

            if (value5.id === 'metisCoberturaFrame') {
                value1.dataset.externalModalBackdrop = 'true';
                const value26 = () => {
                    const elements1 = document.querySelectorAll('.cob-modal');
                    for (const value27 of elements1) {
                        new MutationObserver(programarSombra).observe(value27, {
                            attributes: true,
                            attributeFilter: ['hidden', 'style']
                        });
                        const element3 = value27.querySelector('.cob-modal-dialog');
                        if (element3 && 'ResizeObserver' in window) {
                            new ResizeObserver(programarSombra).observe(element3);
                        }
                    }
                    programarSombra();
                };
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', value26, { once: true });
                } else {
                    value26();
                }
                window.parent.addEventListener('resize', programarSombra);
                window.parent.addEventListener('scroll', programarSombra, { passive: true });
                window.addEventListener('pagehide', limpiarSombra);
                window.addEventListener('pageshow', programarSombra);
            }

            const value28 = () => {
                const boundedValue1 = Math.max(580, Math.ceil(document.documentElement.scrollHeight + 8));
                if (Math.abs(value5.getBoundingClientRect().height - boundedValue1) > 5) {
                    value5.style.height = `${boundedValue1}px`;
                }
            };
            window.addEventListener('load', value28);
            document.addEventListener('DOMContentLoaded', () => {
                value28();
                programarSombra();
                if ('ResizeObserver' in window) {
                    new ResizeObserver(() => {
                        value28();
                        programarSombra();
                    }).observe(document.body);
                }
            });
        }
    } catch (error) {
        // La pantalla también funciona si se abre fuera de Metis.
    }
})();
