<?php
declare(strict_types=1);

/** Guarda una tienda nueva o edita únicamente sus campos de cobertura. */
require_once __DIR__ . '/bootstrap.php';
require_editor();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit('Método no permitido.');
}

check_csrf();

$accion = (string) ($_POST['accion'] ?? '');
$codigoEntrada = mayus((string) ($_POST['codigo'] ?? ''));
$codigo = $codigoEntrada;

try {
    if (!in_array($accion, ['nueva', 'editar'], true)) {
        throw new InvalidArgumentException('Operación no válida.');
    }

    $catalogo = catalogo_origen();
    if (!isset($catalogo[$codigo])) {
        throw new InvalidArgumentException('No se encontró la tienda en el catálogo oficial.');
    }

    $existente = cobertura_existente($codigo);

    if ($accion === 'nueva' && $existente !== null) {
        throw new InvalidArgumentException('La tienda ya existe. Debes editarla.');
    }

    if ($accion === 'editar' && $existente === null) {
        throw new InvalidArgumentException('La tienda no existe.');
    }

    $datos = validar_datos(
        $codigo,
        (string) $catalogo[$codigo]['nombre'],
        (string) ($_POST['cobertura'] ?? ''),
        (string) ($_POST['tamano'] ?? ''),
        (string) ($_POST['m2s'] ?? ''),
        $catalogo
    );

    guardar_filas([$datos], $accion, $catalogo);
    go(cobertura_url_retorno($_POST, 'ok'));
} catch (InvalidArgumentException $error) {
    http_response_code(422);
    $titulo = 'No se pudo guardar';
    require __DIR__ . '/encabezado.php';
    ?>
    <div class="aviso error"><?= h($error->getMessage()) ?></div>
    <a class="boton secundario" href="<?= h(cobertura_url_retorno($_POST)) ?>">Volver al listado</a>
    <?php
    require __DIR__ . '/pie.php';
} catch (Throwable $error) {
    error_log('Error al guardar cobertura: ' . $error->getMessage());
    http_response_code(500);
    exit('No se pudo guardar. Revisa el registro de errores de PHP.');
}
