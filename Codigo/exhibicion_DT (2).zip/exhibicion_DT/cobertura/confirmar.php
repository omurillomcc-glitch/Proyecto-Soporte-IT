<?php
declare(strict_types=1);

/** Confirma la importación masiva después de la vista previa. */
require_once __DIR__ . '/bootstrap.php';
require_module_access('cobertura_importar');
require_editor();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit('Método no permitido.');
}

check_csrf();
$pendiente = $_SESSION['cobertura_import'] ?? null;

$pendienteValido = is_array($pendiente)
    && !empty($pendiente['filas'])
    && !empty($pendiente['token'])
    && hash_equals((string) $pendiente['token'], (string) ($_POST['token'] ?? ''))
    && (time() - (int) ($pendiente['desde'] ?? 0) <= 900);

if (!$pendienteValido) {
    http_response_code(409);
    exit('La vista previa expiró o no es válida. Vuelve a importar el Excel.');
}

// Consumir el token: el botón de confirmar no se puede procesar dos veces.
unset($_SESSION['cobertura_import']);

try {
    $totales = guardar_filas($pendiente['filas']);
    go(cobertura_url_retorno($_POST, 'importado', $totales));
} catch (Throwable $error) {
    error_log('Error confirmando importación: ' . $error->getMessage());
    http_response_code(500);
    exit('No se importó el Excel. Revisa que el catálogo no haya cambiado y consulta el log de PHP.');
}