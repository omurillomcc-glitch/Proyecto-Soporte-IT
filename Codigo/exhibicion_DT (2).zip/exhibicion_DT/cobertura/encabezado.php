<?php
$titulo = (string) ($titulo ?? 'Cobertura de tiendas');
$parametrosRetornoCobertura = cobertura_parametros_retorno($_POST ?: $_GET);
$consultaRetornoCobertura = http_build_query([
    'volver_pais' => $parametrosRetornoCobertura['pais'],
    'volver_buscar' => $parametrosRetornoCobertura['buscar'],
    'volver_pagina' => $parametrosRetornoCobertura['pagina'],
]);
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($titulo) ?> | Exhibición DT</title>
    <link rel="stylesheet" href="assets/estilo.css?v=20261104r4">
    <link rel="stylesheet" href="../fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../bootstrap-icons/bootstrap-icons.min.css">
    <script defer src="assets/tema_metis.js?v=20261124"></script>
    <script defer src="assets/posicion.js?v=2"></script>
</head>
<body>
<header class="barra">
    <div class="ancho barra-interior">
        <a class="marca" href="/exhibicion_DT/index.php">Exhibición DT</a>
        <nav aria-label="Navegación de Cobertura">
            <a href="/exhibicion_DT/index.php">Volver al menú</a>
            <a href="index.php">Ver cobertura</a>
            <?php if ($puedeEditar): ?>
                <a href="nueva.php?<?= h($consultaRetornoCobertura) ?>">Agregar tienda</a>
                <?php if ($puedeImportarCobertura): ?><a href="importar.php?<?= h($consultaRetornoCobertura) ?>">Importar Excel</a><?php endif; ?>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="ancho">