<?php
declare(strict_types=1);




/** Formulario para agregar una tienda del catálogo oficial. */
require_once __DIR__ . '/bootstrap.php';
require_editor();

$titulo = 'Agregar tienda';
$catalogo = catalogo_origen();
$registrados = existentes_todos();

require __DIR__ . '/encabezado.php';
?>

<section class="panel cob-fallback-panel">
    <h1>Agregar tienda</h1>
    <p class="nota">Selecciona una tienda del catálogo oficial. Su código y nombre no se pueden modificar.</p>
    <form method="post" action="guardar.php" autocomplete="off">
        <?= csrf_field() ?>
        <?= cobertura_campos_retorno($_GET) ?>
        <input type="hidden" name="accion" value="nueva">
        <div class="grid">
            <div class="campo" style="grid-column:1 / -1">
                <label for="codigo">Tienda oficial *</label>
                <select id="codigo" name="codigo" required>
                    <option value="">Seleccionar tienda...</option>
                    <?php foreach ($catalogo as $tienda): ?>
                        <?php if (isset($registrados[$tienda['codigo']])) continue; ?>
                        <option value="<?= h($tienda['codigo']) ?>"><?= h($tienda['codigo'] . ' · ' . $tienda['nombre'] . ' (' . nombre_pais($tienda['codigo']) . ')') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="cobertura">Cobertura *</label>
                <input id="cobertura" name="cobertura" maxlength="50" placeholder="Ej.: 2 SEMANAS" required>
            </div>
            <div class="campo">
                <label for="tamano">Tamaño *</label>
                <select id="tamano" name="tamano" required><option value="">Seleccionar</option><option>PEQUEÑO</option><option>MEDIANO</option><option>GRANDE</option></select>
            </div>
            <div class="campo">
                <label for="m2s">Metros cuadrados (M2S) *</label>
                <input id="m2s" name="m2s" inputmode="decimal" placeholder="Ej.: 125.50" required>
            </div>
        </div>
        <div class="acciones-form">
            <button type="submit">Guardar tienda</button>
            <a class="boton secundario" href="<?= h(cobertura_url_retorno($_GET)) ?>">Cancelar</a>
        </div>
    </form>
</section>

<?php require __DIR__ . '/pie.php'; ?>