<?php
declare(strict_types=1);

/**
 * Importación masiva de Cobertura de tiendas desde Excel.
 *
 * Primero valida todas las filas y muestra un resumen. No guarda nada
 * hasta que el administrador confirme explícitamente los cambios.
 */
require_once __DIR__ . '/bootstrap.php';
require_module_access('cobertura_importar');
require_editor();

$titulo = 'Importación masiva de Excel';
$parametrosRetorno = cobertura_parametros_retorno($_POST ?: $_GET);
$consultaRetorno = http_build_query([
    'volver_pais' => $parametrosRetorno['pais'],
    'volver_buscar' => $parametrosRetorno['buscar'],
    'volver_pagina' => $parametrosRetorno['pagina'],
]);
$errores = [];
$vistaPrevia = [];
$resumen = ['NUEVA' => 0, 'ACTUALIZAR' => 0, 'SIN CAMBIOS' => 0];

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    check_csrf();

    // Invalida cualquier importación anterior, incluso si este archivo tiene errores.
    unset($_SESSION['cobertura_import']);
    $archivo = $_FILES['archivo'] ?? null;

    if (!$archivo || ($archivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $errores[] = 'Selecciona un archivo Excel válido.';
    } elseif ((int) $archivo['size'] > 8 * 1024 * 1024) {
        $errores[] = 'El archivo supera el máximo permitido de 8 MB.';
    } elseif (strtolower(pathinfo((string) $archivo['name'], PATHINFO_EXTENSION)) !== 'xlsx') {
        $errores[] = 'Solo se permiten archivos con extensión .xlsx.';
    } elseif (!is_uploaded_file((string) $archivo['tmp_name'])) {
        $errores[] = 'El archivo no es una carga válida.';
    } elseif (!is_file(dirname(__DIR__) . '/vendor/autoload.php')) {
        $errores[] = 'Falta PhpSpreadsheet. Instala las dependencias de Composer en exhibicion_DT.';
    } else {
        try {
            // Comprobar la estructura del ZIP antes de abrirlo como hoja de cálculo.
            $zip = new ZipArchive();
            if ($zip->open((string) $archivo['tmp_name']) !== true) {
                throw new InvalidArgumentException('El Excel está dañado o no es un XLSX válido.');
            }

            $tamanoDescomprimido = 0;
            if ($zip->numFiles > 200 || $zip->locateName('xl/workbook.xml') === false) {
                $zip->close();
                throw new InvalidArgumentException('El Excel contiene una estructura no permitida.');
            }

            for ($posicion = 0; $posicion < $zip->numFiles; $posicion++) {
                $info = $zip->statIndex($posicion);
                $tamanoDescomprimido += (int) ($info['size'] ?? 0);

                if ($tamanoDescomprimido > 40 * 1024 * 1024) {
                    $zip->close();
                    throw new InvalidArgumentException('El Excel descomprimido es demasiado grande.');
                }
            }
            $zip->close();

            // Usamos la biblioteca PhpSpreadsheet instalada en el proyecto.
            require_once dirname(__DIR__) . '/vendor/autoload.php';
            $lector = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            $lector->setReadDataOnly(true);
            $lector->setLoadSheetsOnly(['IMPORTAR']);

            $libro = $lector->load((string) $archivo['tmp_name']);
            $hoja = $libro->getSheetByName('IMPORTAR');

            if (!$hoja) {
                throw new InvalidArgumentException('El archivo debe tener una hoja llamada IMPORTAR.');
            }

            $ultimaFila = $hoja->getHighestDataRow();
            if ($ultimaFila < 2) {
                throw new InvalidArgumentException('El Excel no contiene tiendas.');
            }

            if ($ultimaFila - 1 > LIMITE_EXCEL) {
                throw new InvalidArgumentException('Máximo ' . LIMITE_EXCEL . ' tiendas por archivo.');
            }

            $columnas = ['A', 'B', 'C', 'D', 'E'];
            $encabezados = ['CODTIENDA', 'TIENDA_DETODO', 'COBERTURA', 'TAMAÑO', 'M2S'];
            $valoresExcel = $hoja->rangeToArray('A1:E' . $ultimaFila, null, false, false);

            foreach ($columnas as $indice => $columna) {
                $tituloColumna = mayus((string) ($valoresExcel[0][$indice] ?? ''));
                if ($tituloColumna !== $encabezados[$indice]) {
                    throw new InvalidArgumentException(
                        'La columna ' . $columna . ' debe llamarse ' . $encabezados[$indice] . '.'
                    );
                }
            }

            $catalogo = catalogo_origen();
            $existentes = existentes_todos();
            $codigosVistos = [];

            for ($numeroFila = 2; $numeroFila <= $ultimaFila; $numeroFila++) {
                $valores = [];
                $tieneValores = false;

                foreach ($columnas as $indice => $columna) {
                    $valorCelda = $valoresExcel[$numeroFila - 1][$indice] ?? null;

                    // Las fórmulas y caracteres iniciales de fórmula están prohibidos.
                    if (is_string($valorCelda) && str_starts_with($valorCelda, '=')) {
                        $celda = $hoja->getCell($columna . $numeroFila);
                        if ($celda->getDataType() === \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_FORMULA) {
                            $errores[] = "Fila {$numeroFila}: no se permiten fórmulas.";
                            continue 2;
                        }
                    }

                    $valor = trim((string) ($valorCelda ?? ''));
                    if ($valor !== '' && preg_match('/\A[=+@]/u', $valor)) {
                        $errores[] = "Fila {$numeroFila}: carácter inicial no permitido.";
                        continue 2;
                    }

                    $valores[] = $valor;
                    $tieneValores = $tieneValores || $valor !== '';
                }

                if (!$tieneValores) {
                    continue;
                }

                try {
                    $datos = validar_datos(
                        $valores[0],
                        $valores[1],
                        $valores[2],
                        $valores[3],
                        $valores[4],
                        $catalogo
                    );

                    if (isset($codigosVistos[$datos['codigo']])) {
                        throw new InvalidArgumentException('Código duplicado dentro del Excel.');
                    }
                    $codigosVistos[$datos['codigo']] = true;

                    $actual = $existentes[$datos['codigo']] ?? null;
                    $estado = estado_fila($datos, $actual);
                    $resumen[$estado]++;

                    $vistaPrevia[] = [
                        'fila' => $datos,
                        'estado' => $estado,
                        'anterior' => $actual,
                    ];
                } catch (InvalidArgumentException $error) {
                    $errores[] = "Fila {$numeroFila}: " . $error->getMessage();
                }

                if (count($errores) >= 30) {
                    $errores[] = 'Se detuvo la revisión después de encontrar 30 errores.';
                    break;
                }
            }

            $libro->disconnectWorksheets();

            if (!$vistaPrevia && !$errores) {
                $errores[] = 'No hay filas válidas para importar.';
            }

            // Una fila incorrecta impide guardar cualquier fila del archivo.
            if (!$errores) {
                $_SESSION['cobertura_import'] = [
                    'token' => bin2hex(random_bytes(16)),
                    'desde' => time(),
                    'filas' => array_column($vistaPrevia, 'fila'),
                ];
            }
        } catch (Throwable $error) {
            error_log('Error al validar Excel de cobertura: ' . $error->getMessage());
            $errores[] = $error instanceof InvalidArgumentException
                ? $error->getMessage()
                : 'No se pudo leer el Excel. Verifica el formato del archivo.';
        }
    }
}

require __DIR__ . '/encabezado.php';
?>

<section class="panel ancho-panel">
    <p class="nota">
        La importación comprueba cada código y nombre contra DETODO o ACANICARAGUA2,
        valida todos los campos y permite revisar los cambios antes de guardarlos.
        No modifica ninguna base de almacenes de origen.
    </p>

    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <?= cobertura_campos_retorno($_POST ?: $_GET) ?>

        <div class="campo">
            <label for="archivo">
                Archivo de Excel (.xlsx, máximo 8 MB y <?= LIMITE_EXCEL ?> registros)
            </label>
            <input id="archivo" name="archivo" type="file" accept=".xlsx" required>
        </div>

        <div class="acciones-form">
            <button type="submit">Validar y mostrar vista previa</button>
            <a
                class="boton secundario"
                href="plantilla_importacion_cobertura_tiendas_actualizada.xlsx"
                download
            >Descargar plantilla</a>
        </div>
    </form>
</section>

<?php if ($errores): ?>
    <div class="aviso error">
        <strong>No se guardó ningún registro.</strong>
        <ul class="errores">
            <?php foreach ($errores as $mensaje): ?>
                <li><?= h($mensaje) ?></li>
            <?php endforeach; ?>
        </ul>
        Corrige el Excel y vuelve a subirlo.
    </div>
<?php endif; ?>

<?php if ($vistaPrevia && !$errores): ?>
    <div class="resumen">
        <div><strong><?= count($vistaPrevia) ?></strong><div class="nota">Válidas</div></div>
        <div><strong><?= $resumen['NUEVA'] ?></strong><div class="nota">Nuevas</div></div>
        <div><strong><?= $resumen['ACTUALIZAR'] ?></strong><div class="nota">Para actualizar</div></div>
        <div><strong><?= $resumen['SIN CAMBIOS'] ?></strong><div class="nota">Sin cambios</div></div>
    </div>

    <div class="aviso">
        Revisa los datos antes de confirmar. Las tiendas existentes se actualizarán
        únicamente si aceptas. Una fila inválida cancela todo el archivo.
    </div>

    <div class="tabla-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Estado</th>
                    <th>Código</th>
                    <th>País</th>
                    <th>Tienda oficial</th>
                    <th>Valores actuales</th>
                    <th>Cobertura nueva</th>
                    <th>Tamaño nuevo</th>
                    <th>M2S nuevo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (array_slice($vistaPrevia, 0, 100) as $item): ?>
                    <?php
                    $fila = $item['fila'];
                    $anterior = $item['anterior'];
                    $valoresAnteriores = $anterior === null ? '—' : implode(' / ', [
                        (string) ($anterior['COBERTURA'] ?? ''),
                        (string) ($anterior['TAMANO'] ?? ''),
                        (string) ($anterior['M2S'] ?? ''),
                    ]);
                    $claseEstado = strtolower(str_replace(' ', '-', $item['estado']));
                    ?>
                    <tr>
                        <td>
                            <span class="estado estado-<?= h($claseEstado) ?>">
                                <?= h($item['estado']) ?>
                            </span>
                        </td>
                        <td><?= h($fila['codigo']) ?></td>
                        <td><?= h(nombre_pais($fila['codigo'])) ?></td>
                        <td><?= h($fila['nombre']) ?></td>
                        <td><?= h($valoresAnteriores) ?></td>
                        <td><?= h($fila['cobertura']) ?></td>
                        <td><?= h($fila['tamano']) ?></td>
                        <td><?= h($fila['m2s']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php if (count($vistaPrevia) > 100): ?>
        <p class="nota">
            Se muestran las primeras 100 filas. Al confirmar se procesarán
            las <?= count($vistaPrevia) ?> filas revisadas.
        </p>
    <?php endif; ?>

    <form method="post" action="confirmar.php" class="acciones-form">
        <?= csrf_field() ?>
        <?= cobertura_campos_retorno($_POST ?: $_GET) ?>
        <input
            type="hidden"
            name="token"
            value="<?= h($_SESSION['cobertura_import']['token']) ?>"
        >
        <button type="submit">Confirmar importación (<?= count($vistaPrevia) ?>)</button>
        <a class="boton secundario" href="importar.php?<?= h($consultaRetorno) ?>">Cancelar</a>
    </form>
<?php endif; ?>

<?php require __DIR__ . '/pie.php'; ?>