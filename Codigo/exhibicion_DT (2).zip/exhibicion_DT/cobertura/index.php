<?php
declare(strict_types=1);



// Consulta de coberturas registradas.
require_once __DIR__ . '/bootstrap.php';

$titulo = 'Cobertura de tiendas';
$pais = (string) ($_GET['pais'] ?? '');
if (!in_array($pais, ['', '01', '02'], true)) {
    $pais = '';
}
if ($paisAccesoCobertura !== null) $pais = $paisAccesoCobertura;

$buscar = trim((string) ($_GET['buscar'] ?? ''));
if (strlen($buscar) > 100) {
    $buscar = substr($buscar, 0, 100);
}

$pagina = max(1, min(10000, (int) ($_GET['pagina'] ?? 1)));
$porPagina = 100;
$condiciones = ' WHERE CODTIENDA IS NOT NULL';
[$restriccionTiendas, $parametros] = cobertura_restriccion_sql();
$condiciones .= $restriccionTiendas;

// El país autorizado se aplica también a la consulta SQL.

if ($pais !== '') {
    $condiciones .= ' AND CODTIENDA LIKE ?';
    $parametros[] = $pais . '[_]%';
}

if ($buscar !== '') {
    $literal = str_replace(['[', '%', '_'], ['[[]', '[%]', '[_]'], $buscar);
    $condiciones .= ' AND (CODTIENDA LIKE ? OR TIENDA_DETODO LIKE ? OR COBERTURA LIKE ?)';
    array_push($parametros, "%{$literal}%", "%{$literal}%", "%{$literal}%");
}

$conteo = query_sql(
    'SELECT COUNT(*) AS cantidad FROM ' . TABLA_COBERTURA . $condiciones,
    $parametros
);
$total = (int) (sqlsrv_fetch_array($conteo, SQLSRV_FETCH_ASSOC)['cantidad'] ?? 0);
sqlsrv_free_stmt($conteo);

$ultimaPagina = max(1, (int) ceil($total / $porPagina));
$pagina = min($pagina, $ultimaPagina);
$desplazamiento = ($pagina - 1) * $porPagina;

$consulta = 'SELECT CODTIENDA, TIENDA_DETODO, COBERTURA, [TAMAÑO] AS TAMANO, M2S '
    . 'FROM ' . TABLA_COBERTURA . $condiciones
    . ' ORDER BY CODTIENDA OFFSET ? ROWS FETCH NEXT ? ROWS ONLY';

$registros = query_sql($consulta, [...$parametros, $desplazamiento, $porPagina]);

require __DIR__ . '/encabezado.php';
?>



<div class="exh-wrap">
    <div class="exh-panel">
        <div class="exh-card">
            
            <!--<div class="exh-sheet-heading">
                <div class="exh-sheet-name">
                    <i class="fa-solid fa-store"></i>
                    <strong><?= h($titulo) ?></strong>
                    <span class="exh-sheet-divider"></span>
                    <small>Gestión de coberturas y especificaciones</small>
                </div>
                <div class="exh-sheet-meta">
                    <i class="fa-solid fa-circle-info"></i>
                    <span>El código y el nombre oficiales no se pueden editar.</span>
                </div>
            </div>-->

            <?php if (isset($_GET['importado'])): ?>
                <div class="exh-alert exh-alert-ok">
                    <i class="fa-solid fa-check-circle"></i>
                    Importación guardada: <?= (int) ($_GET['nuevas'] ?? 0) ?> nuevas,
                    <?= (int) ($_GET['actualizadas'] ?? 0) ?> actualizadas y
                    <?= (int) ($_GET['sin_cambios'] ?? 0) ?> sin cambios.
                </div>
            <?php elseif (isset($_GET['ok'])): ?>
                <div class="exh-alert exh-alert-ok">
                    <i class="fa-solid fa-check-circle"></i> Registro guardado correctamente.
                </div>
            <?php endif; ?>

            <form class="exh-toolbar" method="get">
                <div class="exh-view-controls">
                    <div class="exh-searchbox">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input
                            type="text"
                            id="buscar"
                            name="buscar"
                            value="<?= h($buscar) ?>"
                            placeholder="Buscar por código, tienda o cobertura..."
                        >
                    </div>
                </div>

                <div class="exh-toolbar-separator"></div>

                <button type="submit" class="exh-btn-label exh-btn-primary">Filtrar</button>
                <a id="btnLimpiar" class="exh-btn-label" href="index.php">Limpiar</a>

                 <div class="exh-mini-form">
                    <label for="pais">País:</label>
                    <select id="pais" name="pais">
                        <?php if ($paisAccesoCobertura === null): ?><option value="">Todos</option><?php endif; ?>
                        <?php if ($paisAccesoCobertura === null || $paisAccesoCobertura === '01'): ?><option value="01" <?= $pais === '01' ? 'selected' : '' ?>>Honduras</option><?php endif; ?>
                        <?php if ($paisAccesoCobertura === null || $paisAccesoCobertura === '02'): ?><option value="02" <?= $pais === '02' ? 'selected' : '' ?>>Nicaragua</option><?php endif; ?>
                    </select>
                </div>

                <?php if ($puedeEditar): ?>
                    <button class="btn-masivo-mini" type="button" data-cob-modal="nueva">
                        <i class=""></i> Agregar tienda
                    </button>
                <?php endif; ?>
            </form>

            <div class="exh-table-shell">
                <table class="exh-table">
                    <thead>
                        <tr>
                            <th class="center">N°</th>
                            <th>
                                <div class="exh-th-wrap">
                                    <span>Código</span>
                                    <button class="exh-filter-trigger" type="button"></button>
                                </div>
                            </th>
                            <th>País</th>
                            <th>Nombre de la tienda</th>
                            <th>Cobertura</th>
                            <th>Tamaño</th>
                            <th>M2S</th>
                            <?php if ($puedeEditar): ?><th class="center">Acción</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = $desplazamiento + 1;
                        while ($fila = sqlsrv_fetch_array($registros, SQLSRV_FETCH_ASSOC)): 
                            $codigoOriginal = (string) $fila['CODTIENDA'];
                            $paisNombre = function_exists('nombre_pais') ? nombre_pais($codigoOriginal) : '';
                        ?>
                            <tr>
                                <td class="exh-col-num"><span><?= $i++ ?></span></td>
                                <td><strong><?= h($codigoOriginal) ?></strong></td>
                                <td>
                                    <?= h($paisNombre) ?>
                                </td>
                                <td><?= h($fila['TIENDA_DETODO']) ?></td>
                                <td><?= h($fila['COBERTURA']) ?></td>
                                <td><?= h($fila['TAMANO']) ?></td>
                                <td>
                                    <?= $fila['M2S'] === null 
                                        ? '—' 
                                        : h(number_format((float) $fila['M2S'], 2, '.', ',')) ?>
                                </td>
                                <?php if ($puedeEditar): ?>
                                    <td class="center">
                                        <button
                                            type="button"
                                            class="exh-btn-icon exh-btn-primary"
                                            data-cob-modal="editar"
                                            data-codigo="<?= h($codigoOriginal) ?>"
                                            data-nombre="<?= h($fila['TIENDA_DETODO']) ?>"
                                            data-pais="<?= h($paisNombre) ?>"
                                            data-cobertura="<?= h($fila['COBERTURA']) ?>"
                                            data-tamano="<?= h($fila['TAMANO']) ?>"
                                            data-m2s="<?= $fila['M2S'] === null ? '' : h(number_format((float) $fila['M2S'], 2, '.', '')) ?>"
                                            aria-label="Editar <?= h($fila['TIENDA_DETODO']) ?>"
                                            title="Editar tienda"
                                        >
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endwhile; ?>

                        <?php if ($total === 0): ?>
                            <tr>
                                <td colspan="<?= $puedeEditar ? 8 : 7 ?>" class="exh-empty">
                                    No se encontraron tiendas registradas.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="exh-sheet-footer">
                <div class="exh-footer-info">
                    <i class="fa-solid fa-list-check"></i>
                    <span><strong><?= number_format($total) ?></strong> tienda(s) en total</span>
                </div>

                <?php if ($ultimaPagina > 1): ?>
                    <nav class="exh-pagination" aria-label="Paginación de tiendas">
                        <?php if ($pagina > 1): ?>
                            <a href="?<?= h(http_build_query(['pais' => $pais, 'buscar' => $buscar, 'pagina' => $pagina - 1])) ?>">
                                <i class="fa-solid fa-angle-left"></i>
                            </a>
                        <?php endif; ?>

                        <span class="active"><?= $pagina ?> / <?= $ultimaPagina ?></span>

                        <?php if ($pagina < $ultimaPagina): ?>
                            <a href="?<?= h(http_build_query(['pais' => $pais, 'buscar' => $buscar, 'pagina' => $pagina + 1])) ?>">
                                <i class="fa-solid fa-angle-right"></i>
                            </a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>


<?php if ($puedeEditar): ?>
<div class="cob-modal" id="modalNuevaTienda" hidden aria-hidden="true">
    <div class="cob-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="tituloNuevaTienda" tabindex="-1">
        <div class="cob-modal-head">
            <span class="cob-modal-icon"><i class="fa-solid fa-store"></i></span>
            <div class="cob-modal-heading">
                <h2 id="tituloNuevaTienda">Agregar tienda</h2>
                <p>Registrar cobertura de una tienda oficial</p>
            </div>
            <button type="button" class="cob-modal-close" data-cob-close aria-label="Cerrar modal"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form action="guardar.php" method="post" autocomplete="off">
            <?= csrf_field() ?>
            <?= cobertura_campos_retorno(['pais' => $pais, 'buscar' => $buscar, 'pagina' => $pagina]) ?>
            <input type="hidden" name="accion" value="nueva">
            <div class="cob-modal-content">
                <div class="cob-modal-notice"><i class="fa-solid fa-circle-check"></i><span>El código y el nombre se obtienen de la base de  producción  y no pueden modificarse.</span></div>
                <div class="cob-modal-field">
                    <label for="codigoNueva">Tienda del catálogo <span>*</span></label>
                    <select name="codigo" id="codigoNueva" required disabled><option value="">Cargando tiendas disponibles...</option></select>
                    <small id="cobTiendasEstado" class="cob-field-hint" aria-live="polite"></small>
                </div>
                <div id="cobTiendaPreview" class="cob-store-preview" hidden>
                    <span class="cob-store-logo"><i class="fa-solid fa-shop"></i></span>
                    <div><strong id="cobTiendaNombre"></strong><small id="cobTiendaDetalle"></small></div>
                    <i class="fa-solid fa-circle-check cob-store-check"></i>
                </div>
                <div class="cob-form-grid">
                    <div class="cob-modal-field">
                        <label for="nuevaCobertura">Cobertura <span>*</span></label>
                        <input name="cobertura" id="nuevaCobertura" maxlength="50" placeholder="Ej.: 2 SEMANAS" required>
                    </div>
                    <div class="cob-modal-field">
                        <label for="nuevoTamano">Tamaño <span>*</span></label>
                        <select name="tamano" id="nuevoTamano" required>
                            <option value="">Seleccionar tamaño</option>
                            <option value="PEQUEÑA">Pequeña</option>
                            <option value="MEDIANA">Mediana</option>
                            <option value="GRANDE">Grande</option>
                        </select>
                    </div>
                    <div class="cob-modal-field cob-form-wide">
                        <label for="nuevoM2s">Metros cuadrados (M2S) <span>*</span></label>
                        <input name="m2s" id="nuevoM2s" inputmode="decimal" maxlength="12" placeholder="Ej.: 125.50" required>
                    </div>
                </div>
            </div>
            <div class="cob-modal-actions">
                <button type="button" class="cob-btn cob-btn-cancel" data-cob-close>Cancelar</button>
                <button type="submit" class="cob-btn cob-btn-save" id="cobGuardarNueva"><i class="fa-solid fa-floppy-disk"></i> Guardar tienda</button>
            </div>
        </form>
    </div>
</div>

<div class="cob-modal" id="modalEditarTienda" hidden aria-hidden="true">
    <div class="cob-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="tituloEditarTienda" tabindex="-1">
        <div class="cob-modal-head">
            <span class="cob-modal-icon"><i class="fa-solid fa-pen-to-square"></i></span>
            <div class="cob-modal-heading">
                <h2 id="tituloEditarTienda">Editar cobertura</h2>
                <p>Actualizar datos disponibles de la tienda</p>
            </div>
            <button type="button" class="cob-modal-close" data-cob-close aria-label="Cerrar modal"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form action="guardar.php" method="post" autocomplete="off">
            <?= csrf_field() ?>
            <?= cobertura_campos_retorno(['pais' => $pais, 'buscar' => $buscar, 'pagina' => $pagina]) ?>
            <input type="hidden" name="accion" value="editar">
            <input type="hidden" name="codigo" id="cobEditarCodigoReal">
            <div class="cob-modal-content">
                <div class="cob-store-preview cob-store-preview-edit">
                    <span class="cob-store-logo"><i class="fa-solid fa-shop"></i></span>
                    <div><strong id="cobEditarNombrePreview"></strong><small id="cobEditarPaisPreview"></small></div>
                    <i class="fa-solid fa-lock cob-store-lock"></i>
                </div>
                <div class="cob-form-grid">
                    <div class="cob-modal-field">
                        <label for="cobEditarCodigoVisible">Código de tienda</label>
                        <input id="cobEditarCodigoVisible" readonly class="cob-readonly">
                    </div>
                    <div class="cob-modal-field">
                        <label for="cobEditarNombreVisible">Nombre oficial</label>
                        <input id="cobEditarNombreVisible" readonly class="cob-readonly">
                    </div>
                    <div class="cob-modal-field">
                        <label for="cobEditarCobertura">Cobertura <span>*</span></label>
                        <input name="cobertura" id="cobEditarCobertura" maxlength="50" required>
                    </div>
                    <div class="cob-modal-field">
                        <label for="cobEditarTamano">Tamaño <span>*</span></label>
                        <select name="tamano" id="cobEditarTamano" required>
                            <option value="PEQUEÑA">Pequeña</option>
                            <option value="MEDIANA">Mediana</option>
                            <option value="GRANDE">Grande</option>
                        </select>
                    </div>
                    <div class="cob-modal-field cob-form-wide">
                        <label for="cobEditarM2s">Metros cuadrados (M2S) <span>*</span></label>
                        <input name="m2s" id="cobEditarM2s" inputmode="decimal" maxlength="12" required>
                    </div>
                </div>
            </div>
            <div class="cob-modal-actions">
                <button type="button" class="cob-btn cob-btn-cancel" data-cob-close>Cancelar</button>
                <button type="submit" class="cob-btn cob-btn-save"><i class="fa-solid fa-floppy-disk"></i> Guardar cambios</button>
            </div>
        </form>
    </div>
</div>
<script defer src="assets/cobertura_modales.js?v=20261124"></script>
<?php endif; ?>

<?php require __DIR__ . '/pie.php'; ?>