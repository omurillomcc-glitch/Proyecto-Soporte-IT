<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_editor();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

try {
    $catalogo = catalogo_origen();
    $registrados = existentes_todos();
    $registradosNormalizados = [];
    foreach (array_keys($registrados) as $codigo) {
        $registradosNormalizados[strtoupper(trim((string) $codigo))] = true;
    }

    $tiendas = [];
    foreach ($catalogo as $tienda) {
        $codigo = (string) $tienda['codigo'];
        $tiendas[] = [
            'codigo' => $codigo,
            'nombre' => (string) $tienda['nombre'],
            'pais' => nombre_pais($codigo),
            'registrada' => isset($registradosNormalizados[$codigo]),
        ];
    }

    echo json_encode(['tiendas' => $tiendas], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
} catch (Throwable $error) {
    error_log('Cobertura catálogo: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'No se pudieron cargar las tiendas disponibles.']);
}
