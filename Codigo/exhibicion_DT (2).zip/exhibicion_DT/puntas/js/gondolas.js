'use strict';
/* Listado, edición e importación de Puntas Góndolas. */
(() => {
  const cfg = window.PUNTAS_CONFIG;
  const $ = id => document.getElementById(id);
  const state1 = { pais: cfg.pais, page: 1, per: 50, total: 0, sort: 'plu', dir: 'asc', filters: {}, rows: [], editing: false, busy: false };
  let value1 = null;
  const value2 = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function capturarPosicion() {
    let value3 = window;
    try {
      if (window.parent !== window) value3 = window.parent;
    } catch (_) {}
    return {
      x: value3.scrollX,
      y: value3.scrollY,
      tablaX: document.querySelector('.pg-table-wrap')?.scrollLeft ?? 0
    };
  }
  function restaurarPosicion(posicion) {
    if (!posicion) return;
    const value4 = () => {
      const element1 = document.querySelector('.pg-table-wrap');
      if (element1) element1.scrollLeft = posicion.tablaX;
      let value5 = window;
      try {
        if (window.parent !== window) value5 = window.parent;
      } catch (_) {}
      value5.scrollTo({ left: posicion.x, top: posicion.y, behavior: 'instant' });
    };
    requestAnimationFrame(() => requestAnimationFrame(() => {
      value4();
      window.setTimeout(value4, 150);
    }));
  }
  const url = (action, params = {}) => cfg.api + '?' + new URLSearchParams({action, pais:state1.pais, ...params});
  const value6 = (str, error = false) => {
    $('mensaje').hidden = !str;
    $('mensaje').textContent = str;
    $('mensaje').classList.toggle('error', error);
  };
  const value7 = plu => new RegExp(`^\\d{12}${state1.pais === 'HONDURAS' ? 'HN' : 'NI'}$`).test(plu);
  const text1 = 'El PLU debe tener 12 dígitos y terminar en ' + (state1.pais === 'HONDURAS' ? 'HN' : 'NI') + '. Ejemplo: 002009008001' + (state1.pais === 'HONDURAS' ? 'HN' : 'NI') + '.';
  async function request(action, data = null) {
    const value8 = data === null ? { credentials:'same-origin',cache:'no-store' } : {
      method: 'POST', credentials:'same-origin', cache:'no-store',
      headers: { 'Content-Type':'application/json', 'X-CSRF-Token':cfg.csrf },
      body: JSON.stringify(data)
    };
    const response1 = await fetch(url(action), value8);
    const value9 = response1.headers.get('content-type') || '';
    if (!value9.includes('application/json')) {
      throw new Error('El servidor devolvió una página en lugar de JSON. Comprueba la sesión y el registro de errores de PHP.');
    }
    const responseData1 = await response1.json();
    if (!response1.ok || !responseData1.ok) throw new Error(responseData1.message || 'No se pudo completar la operación.');
    if (data !== null) cache1.clear();
    return responseData1;
  }

  function render(rows) {
    state1.rows = rows;
    const value10 = (state1.page - 1) * state1.per;
    $('tabla').innerHTML = rows.length ? rows.map((r, i) => {
      const value11 = Number(r.activo) === 1;
      return `<tr><td class="pg-num">${value10+i+1}</td>
        <td class="pg-code">${value2(r.plu)}</td>
        <td>${value2(r.referencia)}</td><td>${value2(r.descripcion)}</td>
        <td>${value2(r.departamento)}</td><td>${value2(r.seccion)}</td><td>${value2(r.familia)}</td>
        <td>${value2(r.unidades_punta)}</td>
        <td><span class="pg-status ${value11?'on':'off'}">${value11?'1 · Activo':'0 · Inactivo'}</span></td>
        <td>${value2(r.exhibicion)}</td>
        <td><button class="pg-edit" type="button" data-index="${i}">Editar</button></td></tr>`;
    }).join('') : '<tr><td colspan="11" class="pg-empty">No hay registros para los filtros seleccionados.</td></tr>';
    const boundedValue1 = Math.max(1, Math.ceil(state1.total / state1.per));
    $('pagina').textContent = `${state1.page} de ${boundedValue1}`;
    $('resumen').textContent = `${state1.total.toLocaleString('es-HN')} registros`;
    $('primera').disabled = $('anterior').disabled = state1.page === 1;
    $('siguiente').disabled = $('ultima').disabled = state1.page >= boundedValue1;
    document.querySelectorAll('.pg-edit').forEach(btn => btn.addEventListener('click', () => abrirEdicion(state1.rows[Number(btn.dataset.index)])));
  }

  async function cargar() {
    value6('Consultando Puntas Góndolas...');
    const state2 = { page:state1.page, per:state1.per, sort:state1.sort, dir:state1.dir };
    for (const [campo,valor] of Object.entries(state1.filters)) state2['f_'+campo] = valor;
    try {
      const response2 = await fetch(url('list',state2), {credentials:'same-origin',cache:'no-store'});
      if (!(response2.headers.get('content-type') || '').includes('application/json')) throw new Error('Sesión vencida o error PHP. Verifica el registro del servidor.');
      const state3 = await response2.json();
      if (!response2.ok || !state3.ok) throw new Error(state3.message || 'Error al consultar.');
      state1.page = Number(state3.page); state1.total = Number(state3.total); state1.per = Number(state3.per);
      render(state3.rows || []); value6('');
      document.querySelectorAll('.pg-filter-trigger').forEach(button => {
        button.classList.toggle('is-active', Boolean(state1.filters[button.dataset.field]));
      });
    } catch (e) {
      $('tabla').innerHTML = '<tr><td colspan="11" class="pg-empty">No se pudieron cargar los registros.</td></tr>';
      value6(e.message, true);
    }
  }

  function abrir(id) { const d=$(id); if (!d.open) d.showModal(); }
  function cerrar(id) { const d=$(id); if (d.open) d.close(); }
  const element2 = str => { $('errorArticulo').hidden = !str; $('errorArticulo').textContent = str; };
  function nuevo() {
    value1 = capturarPosicion();
    state1.editing = false;
    $('formArticulo').reset(); $('paisModal').value = state1.pais;
    $('plu').readOnly = false; $('tituloModal').textContent = 'Agregar artículo';
    $('datosArticulo').textContent = 'Escribe el PLU para verificar su información en el catálogo.';
    element2(''); abrir('modalArticulo'); $('plu').focus();
  }
  function abrirEdicion(row) {
    value1 = capturarPosicion();
    state1.editing = true;
    $('formArticulo').reset(); $('paisModal').value = state1.pais;
    $('plu').value = row.plu; $('plu').readOnly = true;
    $('unidades').value = row.unidades_punta;
    $('activo').value = String(row.activo);
    $('exhibicion').value = row.exhibicion;
    $('tituloModal').textContent = 'Editar artículo';
    $('datosArticulo').innerHTML = `<strong>${value2(row.referencia)}</strong> · ${value2(row.descripcion)}<div>${value2(row.departamento)} / ${value2(row.seccion)} / ${value2(row.familia)}</div>`;
    element2(''); abrir('modalArticulo');
  }

  let value12 = 0;
  async function consultarCatalogo() {
    if (state1.editing) return;
    const plu = $('plu').value.trim();
    const value13 = ++value12;
    if (!plu) { $('datosArticulo').textContent = 'Escribe el PLU para consultar el catálogo.'; return; }
    if (!value7(plu)) { $('datosArticulo').textContent = text1; return; }
    try {
      const response3 = await fetch(url('catalog',{plu}), {credentials:'same-origin',cache:'no-store'});
      if (!(response3.headers.get('content-type')||'').includes('application/json')) throw new Error('No se pudo consultar el catálogo.');
      const responseData2 = await response3.json();
      if (!responseData2.ok) throw new Error(responseData2.message || 'Catálogo no disponible.');
      if (value13 !== value12) return;
      if (!responseData2.articulo) { $('datosArticulo').textContent = 'PLU no encontrado en el catálogo.'; return; }
      const a = responseData2.articulo;
      $('datosArticulo').innerHTML = `<strong>${value2(a.referencia)}</strong> · ${value2(a.descripcion)}<div>${value2(a.departamento)} / ${value2(a.seccion)} / ${value2(a.familia)}</div>` +
        (a.varias_referencias ? '<div style="color:var(--pg-danger)">Atención: este PLU aparece con más de una referencia; la tabla Puntas guarda únicamente el PLU.</div>' : '');
    } catch (e) { if (value13===value12) $('datosArticulo').textContent = e.message; }
  }

  async function guardar(ev) {
    ev.preventDefault();
    if (state1.busy) return;
    const options1 = {
      pais:state1.pais,modo:state1.editing?'edit':'add',plu:$('plu').value.trim(),
      unidades_punta:$('unidades').value,activo:$('activo').value,exhibicion:$('exhibicion').value
    };
    if (!value7(options1.plu)) { element2(text1); return; }
    state1.busy=true; $('guardar').disabled=true; element2('');
    try {
      const r = await request('save', options1);
      cerrar('modalArticulo');
      await cargar();
      restaurarPosicion(value1);
      value1 = null;
      value6(r.resultado==='insertado'?'Artículo agregado.':r.resultado==='actualizado'?'Artículo actualizado.':'El artículo ya existe.');
    } catch(e) {element2(e.message);} finally {state1.busy=false;$('guardar').disabled=false;}
  }

  // Lee CSV con comillas dobles, separadores y saltos de línea entrecomillados.
  function csvParse(text) {
    text = text.replace(/^\uFEFF/, '');
    const value14 = text.split(/\r?\n/,1)[0] || '';
    const value15 = (value14.match(/;/g)||[]).length > (value14.match(/,/g)||[]).length ? ';' : ',';
    const value16=[];let value17=[],value18='',value19=false;
    for (let i=0;i<text.length;i++) {
      const c=text[i];
      if (c==='"') {if (value19&&text[i+1]==='"'){value18+='"';i++;}else value19=!value19;}
      else if(c===value15&&!value19){value17.push(value18);value18='';}
      else if((c==='\r'||c==='\n')&&!value19){if(c==='\r'&&text[i+1]==='\n')i++;value17.push(value18);if(value17.some(x=>x.trim()))value16.push(value17);value17=[];value18='';}
      else value18+=c;
    }
    if(value19)throw new Error('CSV inválido: comillas sin cerrar.');
    value17.push(value18);if(value17.some(x=>x.trim()))value16.push(value17);
    return value16;
  }
  function leerRegistros(texto) {
    const csv=csvParse(texto);
    if(csv.length<2)throw new Error('El archivo debe contener encabezado y registros.');
    const value20=s=>String(s||'').trim().toUpperCase().replace(/\s+/g,'_');
    const mappedItems1=csv.shift().map(value20);
    const value21=['PLU','UNIDADES_PUNTA','ACTIVO','EXHIBICION'];
    for(const c of value21)if(!mappedItems1.includes(c))throw new Error('Falta la columna '+c+'.');
    const seenItems1=new Set();
    return csv.map((valores,i)=>{
      if(valores.length!==mappedItems1.length)throw new Error('Fila '+(i+2)+': número de columnas incorrecto.');
      const d={}; mappedItems1.forEach((h,j)=>d[h]=valores[j].trim());
      if(!d.PLU)throw new Error('Fila '+(i+2)+': PLU vacío.');
      if(!value7(d.PLU))throw new Error('Fila '+(i+2)+': '+text1);
      if(seenItems1.has(d.PLU))throw new Error('Fila '+(i+2)+': PLU repetido en el archivo.');
      seenItems1.add(d.PLU);
      if(d.PAIS&&!([state1.pais,...(state1.pais==='HONDURAS'?['HN','01']:['NI','02'])].includes(d.PAIS.toUpperCase()))) {
        throw new Error('Fila '+(i+2)+': pertenece a un país diferente.');
      }
      return {pais:d.PAIS||state1.pais,plu:d.PLU,unidades_punta:d.UNIDADES_PUNTA,activo:d.ACTIVO,exhibicion:d.EXHIBICION};
    });
  }
  async function importar() {
    if (state1.busy) return;
    const element3=$('archivo').files[0];
    if(!element3){$('estadoImportacion').textContent='Selecciona un archivo CSV.';return;}
    if(element3.size>8*1024*1024){$('estadoImportacion').textContent='El archivo supera los 8 MB.';return;}
    state1.busy=true;$('ejecutar').disabled=true;
    try {
      const itemCount1=leerRegistros(await element3.text());
      if(itemCount1.length>30000)throw new Error('El archivo supera 30,000 registros. Divídelo en archivos más pequeños.');
      let value22=0,value23=0,value24=0,value25=0,itemCount2=[];
      $('progreso').hidden=false;
      for(let i=0;i<itemCount1.length;i+=300){
        const itemCount3=itemCount1.slice(i,i+300);
        const r=await request('import',{pais:state1.pais,rows:itemCount3});
        value22+=r.insertados||0;value23+=r.actualizados||0;
        value24+=r.sin_cambios||0;value25+=r.rechazados||0;
        itemCount2.push(...(r.errores||[]));
        $('progreso').value=Math.round(Math.min(100,(i+itemCount3.length)/itemCount1.length*100));
        $('estadoImportacion').textContent=`Procesados ${Math.min(i+300,itemCount1.length)} de ${itemCount1.length}...`;
      }
      $('estadoImportacion').textContent=`Finalizado. Nuevos: ${value22} · Actualizados: ${value23} · Sin cambios: ${value24} · Rechazados: ${value25}` + (itemCount2.length?'\n'+itemCount2.slice(0,8).join('\n'):'');
      await cargar();
      restaurarPosicion(value1);
      value1 = null;
    } catch(e){$('estadoImportacion').textContent=e.message;} finally {state1.busy=false;$('ejecutar').disabled=false;}
  }

  $('pais').addEventListener('change',()=>{cerrarFiltro();state1.pais=$('pais').value;state1.page=1;state1.filters={};cargar();});
  $('per').addEventListener('change',()=>{state1.per=Number($('per').value);state1.page=1;cargar();});
  $('limpiar').addEventListener('click',()=>{state1.filters={};state1.page=1;cargar();});
  $('actualizar').addEventListener('click',()=>cargar());
  $('agregar').addEventListener('click',nuevo);
  $('importar').addEventListener('click',()=>{ value1=capturarPosicion();$('archivo').value='';$('estadoImportacion').textContent='';$('progreso').hidden=true;$('progreso').value=0;abrir('modalImportar'); });
  $('formArticulo').addEventListener('submit',guardar);
  $('plu').addEventListener('blur',consultarCatalogo);
  $('ejecutar').addEventListener('click',importar);
  for(const [accion,id] of [['primera',1],['anterior',-1],['siguiente',1],['ultima',Infinity]]) {
    $(accion).addEventListener('click',()=>{
      if(accion==='primera')state1.page=1;
      else if(accion==='ultima')state1.page=Math.max(1,Math.ceil(state1.total/state1.per));
      else state1.page=Math.max(1,state1.page+(accion==='anterior'?-1:1));
      cargar();
    });
  }
  document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>cerrar(btn.dataset.close)));
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close();}));
  cargar();

  let text2 = '';
  let value26 = null;
  let value27 = 0;
  let value28 = [];
  const cache1 = new Map();

  function claveCacheFiltro(campo, busqueda) {
    const value29 = Object.entries(state1.filters)
      .filter(([nombre]) => nombre !== campo)
      .sort(([a],[b]) => a.localeCompare(b));
    return JSON.stringify([state1.pais, campo, value29, busqueda]);
  }

  function dibujarDatosFiltro(datos) {
    value28 = [...datos.values];
    for (const value30 of seenItems2) {
      if (!value28.includes(value30)) value28.push(value30);
    }
    dibujarOpcionesFiltro(Boolean(datos.hasMore));
  }

  function renderizarCacheFiltro(campo, busqueda) {
    const value31 = cache1.get(claveCacheFiltro(campo, busqueda));
    if (value31) {
      dibujarDatosFiltro(value31);
      return true;
    }
    const value32 = cache1.get(claveCacheFiltro(campo, ''));
    if (busqueda !== '' && value32 && !value32.hasMore && !/[%_\[\]]/.test(busqueda)) {
      const value33 = busqueda.toLocaleLowerCase('es');
      dibujarDatosFiltro({
        values: value32.values.filter(valor => valor.toLocaleLowerCase('es').includes(value33)),
        hasMore: false
      });
      return true;
    }
    return false;
  }

  function guardarCacheFiltro(campo, busqueda, datos) {
    const value34 = claveCacheFiltro(campo, busqueda);
    cache1.delete(value34);
    cache1.set(value34, {
      values: [...datos.values],
      hasMore: Boolean(datos.hasMore)
    });
    while (cache1.size > 30) {
      cache1.delete(cache1.keys().next().value);
    }
  }
  let value35 = false;
  let seenItems2 = new Set();

  function cerrarFiltro() {
    $('filtroMenu').hidden = true;
    value27++;
    clearTimeout(value26);
  }

  function abrirFiltro(button) {
    text2 = button.dataset.field;
    $('filtroTitulo').textContent = button.dataset.label || 'Filtrar';
    const value36 = String(state1.filters[text2] || '');
    $('filtroBuscar').value = value36.startsWith('__LIKE__') ? value36.slice(8) : '';
    $('filtroOrden').value = state1.sort === text2 ? state1.dir : 'asc';
    value35 = false;
    seenItems2 = new Set();
    if (value36.startsWith('__IN__')) {
      try { seenItems2 = new Set(JSON.parse(value36.slice(6))); } catch (_) { seenItems2 = new Set(); }
    }
    $('filtroTodos').checked = false;
    $('filtroMenu').hidden = false;
    cargarOpcionesFiltro();
    $('filtroBuscar').focus();
  }

  async function cargarOpcionesFiltro() {
    const value37 = text2;
    const value38 = ++value27;
    const element4 = $('filtroBuscar').value.trim();
    if (renderizarCacheFiltro(value37, element4)) return;
    const options2 = {field:value37,q:element4};
    for (const [nombre,valor] of Object.entries(state1.filters)) {
      if (nombre !== value37 && valor) options2['f_'+nombre] = valor;
    }
    const element5 = $('filtroOpciones');
    element5.textContent = 'Consultando todos los registros...';
    $('filtroTodos').checked = false;
    value35 = false;
    try {
      const response4 = await fetch(url('options',options2),{credentials:'same-origin',cache:'no-store'});
      if (!(response4.headers.get('content-type')||'').includes('application/json')) throw new Error('No se pudieron consultar las opciones del filtro.');
      const responseData3 = await response4.json();
      if (!response4.ok || !responseData3.ok) throw new Error(responseData3.message || 'No se pudieron consultar las opciones del filtro.');
      if (value38 !== value27 || $('filtroMenu').hidden || value37 !== text2) return;
      const options3 = {
        values: Array.isArray(responseData3.values) ? responseData3.values.map(String) : [],
        hasMore: Boolean(responseData3.has_more)
      };
      guardarCacheFiltro(value37, element4, options3);
      dibujarDatosFiltro(options3);
    } catch (error1) {
      if (value38 === value27 && !$('filtroMenu').hidden) element5.textContent = error1.message;
    }
  }

  function dibujarOpcionesFiltro(hayMas) {
    const element6 = $('filtroOpciones');
    element6.replaceChildren();
    const element7 = $('filtroOrden').value === 'asc';
    const itemCount4 = [...value28].sort((a,b) => element7
      ? a.localeCompare(b,'es',{numeric:true})
      : b.localeCompare(a,'es',{numeric:true}));
    for (const value39 of itemCount4) {
      const element8 = document.createElement('label');
      element8.className = 'pg-filter-option';
      const element9 = document.createElement('input');
      element9.type = 'checkbox';
      element9.className = 'pg-filter-item';
      element9.value = value39;
      element9.checked = seenItems2.has(value39);
      const element10 = document.createElement('span');
      element10.textContent = value39;
      element8.append(element9,element10);
      element6.append(element8);
    }
    if (!itemCount4.length) element6.textContent = 'No se encontraron valores.';
    if (hayMas) {
      const element11 = document.createElement('small');
      element11.textContent = 'Hay más valores. Escribe arriba para buscarlos en todos los registros.';
      element6.append(element11);
    }
    $('filtroTodos').checked = itemCount4.length > 0
      && [...element6.querySelectorAll('.pg-filter-item')].every(item => item.checked);
  }

  $('filtroBuscar').addEventListener('input',()=>{
    clearTimeout(value26);
    seenItems2 = new Set();
    value27++;
    if (renderizarCacheFiltro(text2, $('filtroBuscar').value.trim())) return;
    value26=setTimeout(cargarOpcionesFiltro,180);
  });
  $('filtroOrden').addEventListener('change',()=>dibujarOpcionesFiltro(false));
  $('filtroTodos').addEventListener('change',function(){
    value35=this.checked;
    seenItems2 = new Set();
    $('filtroOpciones').querySelectorAll('.pg-filter-item').forEach(item=>{
      item.checked=this.checked;
      if (this.checked) seenItems2.add(item.value);
    });
  });
  $('filtroOpciones').addEventListener('change',event=>{
    if (!event.target.matches('.pg-filter-item')) return;
    value35=false;
    if (event.target.checked) seenItems2.add(event.target.value);
    else seenItems2.delete(event.target.value);
    const elements1=[...$('filtroOpciones').querySelectorAll('.pg-filter-item')];
    $('filtroTodos').checked=elements1.length>0&&elements1.every(item=>item.checked);
  });
  $('filtroAplicar').addEventListener('click',()=>{
    const elements2=[...$('filtroOpciones').querySelectorAll('.pg-filter-item:checked')].map(item=>item.value);
    const element12=$('filtroBuscar').value.trim();
    if (!value35 && elements2.length > 60) {
      $('filtroOpciones').textContent='Selecciona hasta 60 valores o usa “Seleccionar todo” con una búsqueda.';
      return;
    }
    if (value35) {
      if (element12) state1.filters[text2]='__LIKE__'+element12;
      else delete state1.filters[text2];
    } else if (elements2.length) {
      state1.filters[text2]='__IN__'+JSON.stringify(elements2);
    } else if (element12) {
      state1.filters[text2]='__LIKE__'+element12;
    } else {
      delete state1.filters[text2];
    }
    state1.sort=text2;
    state1.dir=$('filtroOrden').value;
    state1.page=1;
    cerrarFiltro();
    cargar();
  });
  $('filtroLimpiar').addEventListener('click',()=>{
    delete state1.filters[text2];
    state1.page=1;
    cerrarFiltro();
    cargar();
  });
  $('filtroCerrar').addEventListener('click',cerrarFiltro);
  document.querySelectorAll('.pg-filter-trigger').forEach(button=>button.addEventListener('click',()=>abrirFiltro(button)));
  document.addEventListener('click',event=>{
    if (!$('filtroMenu').hidden && !event.target.closest('#filtroMenu,.pg-filter-trigger')) cerrarFiltro();
  });
  document.addEventListener('keydown',event=>{if(event.key==='Escape')cerrarFiltro();});
})();
