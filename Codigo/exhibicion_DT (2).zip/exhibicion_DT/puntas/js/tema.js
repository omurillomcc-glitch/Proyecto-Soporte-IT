'use strict';
/* Sincroniza el módulo con el tema del menú Metis. */
(() => {
  const value1 = document.documentElement;

  function sincronizar() {
    try {
      if (window.parent === window) return;
      const value2 = window.parent.document.documentElement;
      const value3 = window.parent.getComputedStyle(value2);
      const value4 = value3.getPropertyValue('--metis-primary').trim();
      const value5 = value3.getPropertyValue('--metis-bg').trim();
      value1.dataset.pgTheme = value2.getAttribute('data-bs-theme') === 'dark' ? 'dark' : 'light';
      if (value4) {
        const element1 = document.createElement('span');
        element1.style.color = value4;
        document.body.append(element1);
        const value6 = getComputedStyle(element1).color;
        element1.remove();
        const itemCount1 = value6.match(/[\d.]+/g);
        value1.style.setProperty('--pg-accent', value6);
        if (itemCount1 && itemCount1.length >= 3) value1.style.setProperty('--pg-accent-rgb', itemCount1.slice(0, 3).join(','));
      }
      if (value5) value1.style.setProperty('--pg-page', value5);
    } catch (_) {
      // Sin acceso al documento padre se mantienen los estilos locales.
    }
  }

  function ajustarAltura() {
    try {
      const value7 = window.frameElement;
      if (!value7) return;
      const element2 = document.querySelector('.pg-shell');
      const bounds1 = Math.max(680, Math.ceil((element2 ? element2.getBoundingClientRect().bottom : document.body.scrollHeight) + 12));
      if (value7.style.height !== `${bounds1}px`) value7.style.height = `${bounds1}px`;
      ubicarVentanas(value7);
    } catch (_) {
      // La altura fija del iframe sigue disponible como respaldo.
    }
  }

  function sombraModal(iframe, ventana) {
    try {
      const value8 = iframe.ownerDocument;
      const text1 = 'pgModalBackdrop';
      let value9 = value8.getElementById(text1);

      if (!ventana) {
        value9?.remove();
        return;
      }

      if (!value9) {
        value9 = value8.createElement('div');
        value9.id = text1;
        value9.setAttribute('aria-hidden', 'true');
        Object.assign(value9.style, {
          position: 'fixed',
          inset: '0',
          zIndex: '2147483000',
          pointerEvents: 'none'
        });
        for (let i = 0; i < 4; i++) {
          const value10 = value8.createElement('div');
          Object.assign(value10.style, {
            position: 'fixed',
            background: 'rgba(13, 22, 40, .56)',
            backdropFilter: 'blur(3px)',
            pointerEvents: 'auto'
          });
          value10.addEventListener('click', () => {
            iframe.contentDocument?.querySelector('dialog.pg-dialog[open]')?.close();
          });
          value9.append(value10);
        }
        value8.body.append(value9);
      }

      const bounds2 = iframe.getBoundingClientRect();
      const bounds3 = ventana.getBoundingClientRect();
      const value11 = bounds2.width / iframe.clientWidth || 1;
      const value12 = bounds2.height / iframe.clientHeight || 1;
      const value13 = bounds2.left + bounds3.left * value11;
      const value14 = bounds2.top + bounds3.top * value12;
      const value15 = value13 + bounds3.width * value11;
      const value16 = value14 + bounds3.height * value12;
      const value17 = window.parent.innerWidth;
      const value18 = window.parent.innerHeight;
      const value19 = [
        { left: '0', top: '0', width: value17 + 'px', height: Math.max(0, value14) + 'px' },
        { left: '0', top: Math.max(0, value16) + 'px', width: value17 + 'px', height: Math.max(0, value18 - value16) + 'px' },
        { left: '0', top: Math.max(0, value14) + 'px', width: Math.max(0, value13) + 'px', height: Math.max(0, Math.min(value18, value16) - Math.max(0, value14)) + 'px' },
        { left: Math.max(0, value15) + 'px', top: Math.max(0, value14) + 'px', width: Math.max(0, value17 - value15) + 'px', height: Math.max(0, Math.min(value18, value16) - Math.max(0, value14)) + 'px' }
      ];
      [...value9.children].forEach((panel, indice) => Object.assign(panel.style, value19[indice]));
    } catch (_) {
      // Si no se puede acceder a la página contenedora, permanece el backdrop nativo del diálogo.
    }
  }

  function limpiarSombraModal(iframe = window.frameElement) {
    try {
      iframe?.ownerDocument.getElementById('pgModalBackdrop')?.remove();
    } catch (_) {
      // Si no se puede acceder a la página contenedora, no hay una sombra externa que limpiar.
    }
  }

  function ubicarVentanas(iframe = window.frameElement) {
    try {
      if (!iframe || window.parent === window) return;
      const bounds4 = iframe.getBoundingClientRect();
      const boundedValue1 = Math.max(0, -bounds4.top);
      const boundedValue2 = Math.min(iframe.clientHeight, window.parent.innerHeight - bounds4.top);
      const boundedValue3 = Math.max(0, boundedValue2 - boundedValue1);
      if (!boundedValue3) {
        sombraModal(iframe, null);
        return;
      }
      const top = (boundedValue1 + boundedValue2) / 2;
      const boundedValue4 = Math.max(1, Math.min(820, window.parent.innerHeight * 0.9, boundedValue3 - 24));
      const elements1 = [...document.querySelectorAll('.pg-dialog[open], #filtroMenu:not([hidden])')];
      for (const value20 of elements1) {
        value20.style.top = `${top}px`;
        value20.style.left = '50%';
        value20.style.bottom = 'auto';
        value20.style.margin = '0';
        value20.style.transform = 'translate(-50%, -50%)';
        value20.style.maxHeight = `${boundedValue4}px`;
      }
      sombraModal(iframe, elements1.find(ventana => ventana.matches('dialog.pg-dialog[open]')) || null);
    } catch (_) {
      // Los diálogos mantienen la posición local si el módulo se abre fuera del menú.
    }
  }

  sincronizar();
  document.addEventListener('DOMContentLoaded', () => {
    const value21 = window.frameElement;
    if (value21 && window.parent !== window) {
      document.documentElement.dataset.externalModalBackdrop = 'true';
      value21.scrolling = 'no';
      document.documentElement.style.setProperty('overflow-y', 'visible', 'important');
      document.body.style.setProperty('overflow-y', 'visible', 'important');
      document.documentElement.style.setProperty('min-height', '0', 'important');
      document.body.style.setProperty('min-height', '0', 'important');
      window.addEventListener('pagehide', () => limpiarSombraModal(value21));
      window.addEventListener('pageshow', () => window.requestAnimationFrame(() => ubicarVentanas(value21)));
    }
    ajustarAltura();
    if (typeof ResizeObserver !== 'undefined') {
      const resizeObserver1 = new ResizeObserver(() => window.requestAnimationFrame(ajustarAltura));
      resizeObserver1.observe(document.querySelector('.pg-shell') || document.body);
    }
    for (const value22 of document.querySelectorAll('.pg-dialog, #filtroMenu')) {
      new MutationObserver(() => window.requestAnimationFrame(() => ubicarVentanas(value21)))
        .observe(value22, { attributes: true, attributeFilter: ['open', 'hidden'] });
    }
    try {
      window.parent.addEventListener('resize', ajustarAltura);
      window.parent.addEventListener('scroll', () => ubicarVentanas(value21), { passive: true });
    } catch (_) {
      // La posición local se conserva si el documento padre no está disponible.
    }
  });
  window.addEventListener('resize', ajustarAltura);

  try {
    if (window.parent !== window) {
      const mutationObserver1 = new MutationObserver(sincronizar);
      mutationObserver1.observe(window.parent.document.documentElement, {
        attributes: true,
        attributeFilter: ['data-bs-theme', 'data-metis-accent', 'style']
      });
    }
  } catch (_) {
    // No se sincronizan cambios de un origen distinto.
  }
})();
