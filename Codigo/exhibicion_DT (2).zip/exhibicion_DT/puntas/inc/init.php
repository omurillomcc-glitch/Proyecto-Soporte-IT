<?php
/* Acceso y conexiones compartidos con Exhibición DT. */
$raiz = dirname(__DIR__, 2);
require_once $raiz . '/controlusuarios/auth.php';
require_once $raiz . '/controlusuarios/db.php';
require_module_access('puntas_gondolas');

$actual = me();
$rol = (string)($actual['rol'] ?? '');
$propietario = am_es_propietario($conn, (int)($_SESSION['usuario_id'] ?? 0));

// La tabla Puntas Góndola no contiene tienda: no exponer datos generales a cuentas de tienda.
if (!$propietario && $rol === 'tienda') {
    http_response_code(403);
    exit('Este módulo contiene datos generales por país y no se puede limitar a una tienda.');
}

$paisCodigo = strtoupper(trim((string)($actual['pais_code'] ?? $_SESSION['pais_code'] ?? '')));
$paisSesion = in_array($paisCodigo, ['NI', 'NICARAGUA'], true) ? 'NICARAGUA' : 'HONDURAS';

require_once $raiz . '/exhibiciontotal/conexion_exhibicion.php';
if (!isset($sqlsrv_conn_exhibicion) || $sqlsrv_conn_exhibicion === false) {
    http_response_code(503);
    exit('No se pudo abrir la conexión SQL Server.');
}

if (empty($_SESSION['puntas_csrf'])) {
    $_SESSION['puntas_csrf'] = bin2hex(random_bytes(32));
}

session_write_close();

function pg_pais(string $solicitado): string
{
    global $paisSesion, $propietario;
    $pais = strtoupper(trim($solicitado));
    if ($pais === '') $pais = $paisSesion;
    if (!in_array($pais, ['HONDURAS', 'NICARAGUA'], true)) {
        throw new InvalidArgumentException('País inválido.');
    }
    if (!$propietario && $pais !== $paisSesion) {
        throw new DomainException('No está autorizado para consultar este país.');
    }
    return $pais;
}

require_once __DIR__ . '/repo.php';
