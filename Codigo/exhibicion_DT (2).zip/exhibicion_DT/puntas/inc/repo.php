<?php
/* Consultas limitadas a Puntas Góndola y al catálogo de Exhibición. */
const PG_TABLA = '[vistasMCC].[dbo].[TB_DT_RCP_PUNTAS_GONDOLA]';

function pg_ejecutar($db, string $sql, array $parametros = [])
{
    $stmt = sqlsrv_query($db, $sql, $parametros);
    if ($stmt === false) {
        error_log('Puntas Góndola SQL: ' . json_encode(sqlsrv_errors(SQLSRV_ERR_ERRORS), JSON_UNESCAPED_UNICODE));
        throw new RuntimeException('No se pudo consultar SQL Server.');
    }
    return $stmt;
}

function pg_fila($stmt): ?array
{
    $fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    return is_array($fila) ? $fila : null;
}

function pg_base(string $pais): string
{
    return $pais === 'NICARAGUA' ? '[ACANICARAGUA2]' : '[DETODO]';
}

function pg_variantes(string $pais): array
{
    return $pais === 'NICARAGUA' ? ['NICARAGUA', 'NI', '02'] : ['HONDURAS', 'HN', '01'];
}

function pg_columna_exhibicion($db): void
{
    static $comprobada = false;
    if ($comprobada) {
        return;
    }

    $stmt = pg_ejecutar($db, "SELECT COLUMNPROPERTY(OBJECT_ID('vistasMCC.dbo.TB_DT_RCP_PUNTAS_GONDOLA'), 'EXHIBICION', 'ColumnId') AS disponible");
    $fila = pg_fila($stmt);
    sqlsrv_free_stmt($stmt);
    if ($fila === null || $fila['disponible'] === null) {
        throw new RuntimeException('La columna EXHIBICION no existe o no es accesible. Verifique el SQL de instalación.');
    }
    $comprobada = true;
}

function pg_texto(mixed $valor, int $largo, string $campo): string
{
    if (!is_scalar($valor)) throw new InvalidArgumentException("{$campo} inválido.");
    $texto = trim((string)$valor);
    if ($texto === '' || strlen($texto) > $largo || preg_match('/[\x00-\x1f\x7f]/', $texto)) {
        throw new InvalidArgumentException("Revise {$campo}.");
    }
    return $texto;
}

function pg_plu(mixed $valor, ?string $pais = null): string
{
    $texto = pg_texto($valor, 20, 'el PLU');
    if (!preg_match('/^\d{12}(HN|NI)$/D', $texto, $partes)) {
        throw new InvalidArgumentException('El PLU debe tener 12 dígitos seguidos del código HN o NI; por ejemplo, 002009008001HN.');
    }
    if ($pais !== null && $partes[1] !== ($pais === 'NICARAGUA' ? 'NI' : 'HN')) {
        throw new InvalidArgumentException('El sufijo del PLU debe corresponder al país seleccionado.');
    }
    return $texto;
}

function pg_entero(mixed $valor, int $maximo, string $campo): int
{
    if (!is_scalar($valor) || !preg_match('/^\d+$/D', trim((string)$valor))) {
        throw new InvalidArgumentException("{$campo} debe ser un entero no negativo.");
    }
    $numero = filter_var((string)$valor, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => $maximo]]);
    if ($numero === false) throw new InvalidArgumentException("{$campo} fuera del rango permitido.");
    return $numero;
}

function pg_activo(mixed $valor): int
{
    if ((string)$valor !== '0' && (string)$valor !== '1') {
        throw new InvalidArgumentException('Activo debe ser 1 o 0.');
    }
    return (int)$valor;
}

function pg_campos(array $dato, ?string $pais = null): array
{
    return [
        pg_plu($dato['plu'] ?? '', $pais),
        pg_entero($dato['unidades_punta'] ?? null, 2147483647, 'Unidades Punta'),
        pg_activo($dato['activo'] ?? null),
        pg_entero($dato['exhibicion'] ?? null, 2147483647, 'Exhibición'),
    ];
}

function pg_plu_variantes_sql(string $columna, string $pais): string
{
    $plu = "LTRIM(RTRIM(CONVERT(VARCHAR(100), {$columna})))";
    $sinPais = "CASE WHEN UPPER(RIGHT({$plu}, 2)) IN ('HN', 'NI')
        THEN LEFT({$plu}, LEN({$plu}) - 2) ELSE {$plu} END";
    $sinCeros = "CONVERT(VARCHAR(20), TRY_CONVERT(DECIMAL(20, 0), {$sinPais}))";
    $relleno = "CASE WHEN TRY_CONVERT(DECIMAL(20, 0), {$sinPais}) IS NOT NULL
            AND LEN({$sinPais}) <= 12
        THEN RIGHT('000000000000' + {$sinPais}, 12) END";
    $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
    return "({$plu} COLLATE DATABASE_DEFAULT, {$sinPais} COLLATE DATABASE_DEFAULT,
        {$sinCeros} COLLATE DATABASE_DEFAULT, {$relleno} COLLATE DATABASE_DEFAULT,
        ({$sinPais} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$sinCeros} + '{$sufijo}') COLLATE DATABASE_DEFAULT,
        ({$relleno} + '{$sufijo}') COLLATE DATABASE_DEFAULT)";
}

function pg_plu_candidatos(string $plu, string $pais): array
{
    $plu = trim($plu);
    $base = preg_replace('/(?:HN|NI)$/i', '', $plu) ?? $plu;
    $candidatos = [$plu, $base];
    if ($base !== '' && ctype_digit($base) && strlen($base) <= 12) {
        $sinCeros = ltrim($base, '0') ?: '0';
        $relleno = str_pad($base, 12, '0', STR_PAD_LEFT);
        $sufijo = $pais === 'NICARAGUA' ? 'NI' : 'HN';
        array_push($candidatos, $sinCeros, $relleno,
            $base . $sufijo, $sinCeros . $sufijo, $relleno . $sufijo);
    }
    return array_values(array_unique($candidatos));
}

// La referencia es informativa: la tabla principal solo guarda PAIS y PLU.
function pg_catalogo_sql(string $pais): string
{
    $base = pg_base($pais);
    return "OUTER APPLY (
        SELECT TOP (1)
            CONVERT(NVARCHAR(100), ISNULL(A.REFPROVEEDOR, '')) AS referencia,
            CONVERT(NVARCHAR(250), ISNULL(A.DESCRIPCION, '')) AS descripcion,
            CONVERT(NVARCHAR(150), ISNULL(D.DESCRIPCION, '')) AS departamento,
            CONVERT(NVARCHAR(150), ISNULL(S.DESCRIPCION, '')) AS seccion,
            CONVERT(NVARCHAR(150), ISNULL(F.DESCRIPCION, '')) AS familia
        FROM {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
        INNER JOIN {$base}.dbo.ARTICULOS A ON A.CODARTICULO = CL.CODARTICULO
        LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO = A.DPTO
        LEFT JOIN {$base}.dbo.SECCIONES S ON S.NUMDPTO = A.DPTO AND S.NUMSECCION = A.SECCION
        LEFT JOIN {$base}.dbo.FAMILIAS F ON F.NUMDPTO = A.DPTO AND F.NUMSECCION = A.SECCION AND F.NUMFAMILIA = A.FAMILIA
        WHERE CL.PLU = P.PLU
        ORDER BY CASE WHEN A.DESCATALOGADO = 'F' THEN 0 ELSE 1 END, A.CODARTICULO
    ) C";
}

function pg_datos_select_sql(string $pais, bool $usarPagina = false): string
{
    $catalogo = pg_catalogo_sql($pais);
    $tabla = $usarPagina ? 'Pagina' : PG_TABLA;
    return "
        SELECT CONVERT(NVARCHAR(50), P.PAIS) AS pais,
               LTRIM(RTRIM(CONVERT(VARCHAR(20), P.PLU))) AS plu,
               P.UNIDADES_PUNTA AS unidades_punta,
               CONVERT(INT, P.ACTIVO) AS activo,
               P.EXHIBICION AS exhibicion,
               ISNULL(C.referencia, '') AS referencia,
               ISNULL(C.descripcion, '') AS descripcion,
               ISNULL(C.departamento, '') AS departamento,
               ISNULL(C.seccion, '') AS seccion,
               ISNULL(C.familia, '') AS familia
        FROM {$tabla} P
        {$catalogo}
        WHERE UPPER(LTRIM(RTRIM(CONVERT(VARCHAR(50), P.PAIS)))) IN (?, ?, ?)
    ";
}

function pg_datos_sql(string $pais): string
{
    return "WITH Datos AS (" . pg_datos_select_sql($pais) . ")";
}

function pg_columnas(): array
{
    return [
        'plu' => 'D.plu',
        'referencia' => 'D.referencia',
        'descripcion' => 'D.descripcion',
        'departamento' => 'D.departamento',
        'seccion' => 'D.seccion',
        'familia' => 'D.familia',
        'unidades_punta' => 'D.unidades_punta',
        'activo' => 'D.activo',
        'exhibicion' => 'D.exhibicion',
    ];
}

function pg_condiciones(array $filtros, array &$params, string $omitir = ''): string
{
    $sql = '';
    foreach (pg_columnas() as $campo => $columna) {
        if ($campo === $omitir) continue;
        $valor = trim((string)($filtros[$campo] ?? ''));
        if ($valor === '') continue;
        if (strlen($valor) > 6000) throw new InvalidArgumentException('Filtro demasiado largo.');
        $numerico = in_array($campo, ['unidades_punta', 'activo', 'exhibicion'], true);
        if (str_starts_with($valor, '__LIKE__')) {
            $busqueda = trim(substr($valor, 8));
            if ($busqueda === '') continue;
            if (strlen($busqueda) > 100) throw new InvalidArgumentException('Filtro demasiado largo.');
            $expresion = "CONVERT(NVARCHAR(400), {$columna}) COLLATE DATABASE_DEFAULT";
            $sql .= " AND {$expresion} LIKE ?";
            $params[] = '%' . str_replace(['[', '%', '_'], ['[[]', '[%]', '[_]'], $busqueda) . '%';
        } elseif (str_starts_with($valor, '__IN__')) {
            $seleccionJson = substr($valor, 6);
            try {
                $valores = json_decode($seleccionJson, true, 8, JSON_THROW_ON_ERROR);
            } catch (JsonException $e) {
                throw new InvalidArgumentException('Filtro inválido.', 0, $e);
            }
            if (!str_starts_with($seleccionJson, '[') || !is_array($valores) || count($valores) > 60) {
                throw new InvalidArgumentException('Se seleccionaron demasiadas opciones.');
            }
            foreach ($valores as $v) {
                if (!is_string($v) || $v === '' || strlen($v) > 400) {
                    throw new InvalidArgumentException('Filtro inválido.');
                }
            }
            $valores = array_values(array_unique($valores));
            if (!$valores) continue;
            if ($numerico) {
                foreach ($valores as $v) {
                    if (!preg_match('/^\d+$/D', $v)) throw new InvalidArgumentException('Filtro numérico inválido.');
                }
                $valores = array_map('intval', $valores);
            }
            $sql .= " AND {$columna} IN (" . implode(', ', array_fill(0, count($valores), '?')) . ')';
            array_push($params, ...$valores);
        } elseif ($numerico) {
            if (!preg_match('/^\d+$/D', $valor)) throw new InvalidArgumentException('Filtro numérico inválido.');
            $sql .= " AND {$columna} = ?";
            $params[] = (int)$valor;
        } else {
            $sql .= " AND CONVERT(NVARCHAR(400), {$columna}) COLLATE DATABASE_DEFAULT LIKE ?";
            $params[] = '%' . str_replace(['[', '%', '_'], ['[[]', '[%]', '[_]'], $valor) . '%';
        }
    }
    return $sql;
}

function pg_listar($db, string $pais, int $pagina, int $porPagina, array $filtros, string $orden, string $direccion): array
{
    pg_columna_exhibicion($db);
    $pagina = max(1, $pagina);
    $paginaSolicitada = $pagina;
    $porPagina = in_array($porPagina, [50, 100, 200, 500], true) ? $porPagina : 50;
    $columnas = pg_columnas();
    if (!isset($columnas[$orden])) $orden = 'plu';
    $direccion = strtolower($direccion) === 'desc' ? 'DESC' : 'ASC';
    $params = pg_variantes($pais);
    $filtroSQL = pg_condiciones($filtros, $params);
    $cte = pg_datos_sql($pais);

    $hayFiltros = count(array_filter(
        $filtros,
        static fn($valor): bool => trim((string)$valor) !== ''
    )) > 0;
    $fastPath = !$hayFiltros && $orden === 'plu';
    $ordenExtra = ($orden === 'plu') ? '' : ', D.plu ASC';
    $variantes = pg_variantes($pais);

    $consultarPagina = static function (int $numeroPagina) use (
        $db, $pais, $porPagina, $params, $filtroSQL, $cte, $fastPath,
        $variantes, $direccion, $columnas, $orden, $ordenExtra
    ): array {
        $offset = ($numeroPagina - 1) * $porPagina;

        if ($fastPath) {
            $paramsDatos = array_merge($variantes, [$offset, $porPagina], $variantes);
            $sql = "WITH Pagina AS (
                        SELECT P.PAIS, P.PLU, P.UNIDADES_PUNTA, P.ACTIVO, P.EXHIBICION,
                               COUNT_BIG(*) OVER() AS __pg_total
                        FROM " . PG_TABLA . " P
                        WHERE UPPER(LTRIM(RTRIM(CONVERT(VARCHAR(50), P.PAIS)))) IN (?, ?, ?)
                        ORDER BY P.PLU {$direccion}
                        OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
                    ),
                    Datos AS (" . pg_datos_select_sql($pais, true) . ")
                    SELECT D.*, (SELECT MAX(__pg_total) FROM Pagina) AS __pg_total
                    FROM Datos D ORDER BY D.plu {$direccion}";
        } else {
            $paramsDatos = array_merge($params, [$offset, $porPagina]);
            $sql = $cte . " SELECT D.*, COUNT_BIG(*) OVER() AS __pg_total
                    FROM Datos D WHERE 1=1 {$filtroSQL}
                    ORDER BY {$columnas[$orden]} {$direccion}{$ordenExtra}
                    OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        }

        $stmt = pg_ejecutar($db, $sql, $paramsDatos);
        $rows = [];
        while ($fila = pg_fila($stmt)) $rows[] = $fila;
        sqlsrv_free_stmt($stmt);
        return $rows;
    };

    $rows = $consultarPagina($pagina);
    if ($rows) {
        $total = (int)$rows[0]['__pg_total'];
    } else {
        if ($fastPath) {
            $conteo = pg_ejecutar($db,
                "SELECT COUNT_BIG(*) AS total FROM " . PG_TABLA . " P
                 WHERE UPPER(LTRIM(RTRIM(CONVERT(VARCHAR(50), P.PAIS)))) IN (?, ?, ?)",
                $variantes);
        } else {
            $conteo = pg_ejecutar($db,
                $cte . " SELECT COUNT_BIG(*) AS total FROM Datos D WHERE 1=1 {$filtroSQL}",
                $params);
        }
        $total = (int)(pg_fila($conteo)['total'] ?? 0);
        sqlsrv_free_stmt($conteo);

        $maxPagina = max(1, (int)ceil($total / $porPagina));
        $pagina = min($pagina, $maxPagina);
        if ($pagina !== $paginaSolicitada) {
            $rows = $consultarPagina($pagina);
        }
    }

    foreach ($rows as &$fila) {
        unset($fila['__pg_total']);
    }
    unset($fila);

    return ['rows' => $rows, 'total' => $total, 'page' => $pagina, 'per' => $porPagina];
}

function pg_valores_filtro($db, string $pais, string $campo, string $busqueda, array $filtros): array
{
    $columnas = pg_columnas();
    if (!isset($columnas[$campo])) throw new InvalidArgumentException('Columna de filtro inválida.');
    $busqueda = trim($busqueda);
    if (strlen($busqueda) > 100) throw new InvalidArgumentException('La búsqueda del filtro es demasiado larga.');

    $expresion = "LTRIM(RTRIM(CONVERT(NVARCHAR(400), {$columnas[$campo]})))";
    $params = pg_variantes($pais);
    $condiciones = pg_condiciones($filtros, $params, $campo);
    if ($busqueda !== '') {
        $condiciones .= " AND {$expresion} COLLATE DATABASE_DEFAULT LIKE ?";
        $params[] = '%' . str_replace(['[', '%', '_'], ['[[]', '[%]', '[_]'], $busqueda) . '%';
    }
    $sql = pg_datos_sql($pais) . "
        SELECT DISTINCT TOP (301) {$expresion} AS valor
        FROM Datos D
        WHERE {$expresion} <> N'' {$condiciones}
        ORDER BY valor ASC";
    $stmt = pg_ejecutar($db, $sql, $params);
    $valores = [];
    while ($fila = pg_fila($stmt)) $valores[] = (string)($fila['valor'] ?? '');
    sqlsrv_free_stmt($stmt);
    $hayMas = count($valores) > 300;
    if ($hayMas) array_pop($valores);
    return ['values' => $valores, 'has_more' => $hayMas];
}

function pg_buscar_catalogo($db, string $pais, string $plu): ?array
{
    $base = pg_base($pais);
    $sql = "SELECT TOP (2)
            CONVERT(NVARCHAR(100), ISNULL(A.REFPROVEEDOR, '')) AS referencia,
            CONVERT(NVARCHAR(250), ISNULL(A.DESCRIPCION, '')) AS descripcion,
            CONVERT(NVARCHAR(150), ISNULL(D.DESCRIPCION, '')) AS departamento,
            CONVERT(NVARCHAR(150), ISNULL(S.DESCRIPCION, '')) AS seccion,
            CONVERT(NVARCHAR(150), ISNULL(F.DESCRIPCION, '')) AS familia
        FROM {$base}.dbo.ARTICULOSCAMPOSLIBRES CL
        INNER JOIN {$base}.dbo.ARTICULOS A ON A.CODARTICULO=CL.CODARTICULO
        LEFT JOIN {$base}.dbo.DEPARTAMENTO D ON D.NUMDPTO=A.DPTO
        LEFT JOIN {$base}.dbo.SECCIONES S ON S.NUMDPTO=A.DPTO AND S.NUMSECCION=A.SECCION
        LEFT JOIN {$base}.dbo.FAMILIAS F ON F.NUMDPTO=A.DPTO AND F.NUMSECCION=A.SECCION AND F.NUMFAMILIA=A.FAMILIA
        WHERE CL.PLU IN (" . implode(', ', array_fill(0, count($candidatos = pg_plu_candidatos($plu, $pais)), '? COLLATE DATABASE_DEFAULT')) . ")
        ORDER BY CASE WHEN A.DESCATALOGADO='F' THEN 0 ELSE 1 END, A.CODARTICULO";
    $stmt = pg_ejecutar($db, $sql, $candidatos);
    $rows = [];
    while ($fila = pg_fila($stmt)) $rows[] = $fila;
    sqlsrv_free_stmt($stmt);
    if (!$rows) return null;
    $rows[0]['varias_referencias'] = count($rows) > 1 && $rows[0]['referencia'] !== $rows[1]['referencia'];
    return $rows[0];
}

function pg_registrar(string $accion, string $detalle, string $pais): void
{
    try {
        require_once dirname(__DIR__, 2) . '/auditoria/auditoria_helper.php';
        if (!registrar_auditoria('Puntas Gondolas', $accion, $detalle, $pais)) {
            error_log('Puntas Góndolas: no se guardó el evento de auditoría.');
        }
    } catch (Throwable $e) {
        error_log('Puntas Góndolas auditoría: ' . $e->getMessage());
    }
}

// La comprobación con HOLDLOCK evita insertar dos veces la misma clave dentro de la transacción.
function pg_guardar($db, string $pais, array $dato, bool $soloEditar = false): array
{
    pg_columna_exhibicion($db);
    [$plu, $unidades, $activo, $exhibicion] = pg_campos($dato, $pais);
    
    // Obtener información del catálogo para enriquecer el detalle de la auditoría
    $catalogoInfo = pg_buscar_catalogo($db, $pais, $plu);
    if (!$soloEditar && $catalogoInfo === null) {
        throw new InvalidArgumentException('PLU no encontrado en el catálogo del país.');
    }
    
    $descripcionArticulo = $catalogoInfo['descripcion'] ?? '';
    $referenciaArticulo = $catalogoInfo['referencia'] ?? '';

    if (!sqlsrv_begin_transaction($db)) throw new RuntimeException('No se pudo iniciar la transacción.');
    try {
        $params = array_merge(pg_variantes($pais), [$plu]);
        $stmt = pg_ejecutar($db, 'SELECT PAIS, PLU, UNIDADES_PUNTA, ACTIVO, EXHIBICION FROM ' . PG_TABLA .
            ' WITH (UPDLOCK, HOLDLOCK) WHERE UPPER(LTRIM(RTRIM(CONVERT(VARCHAR(50), PAIS)))) IN (?, ?, ?) AND LTRIM(RTRIM(CONVERT(VARCHAR(20), PLU))) = ?', $params);
        $filas = [];
        while ($fila = pg_fila($stmt)) $filas[] = $fila;
        sqlsrv_free_stmt($stmt);
        
        if (count($filas) > 1) throw new RuntimeException('Ya existen registros duplicados para este país y PLU. Revisión requerida.');
        if (!$filas && $soloEditar) throw new InvalidArgumentException('El artículo no está registrado para editar.');
        
        $detalleAccion = '';
        if ($filas) {
            $fila = $filas[0];
            $oldUnidades = (int)$fila['UNIDADES_PUNTA'];
            $oldActivo = (int)$fila['ACTIVO'];
            $oldExhibicion = (int)$fila['EXHIBICION'];

            if ($oldUnidades === $unidades && $oldActivo === $activo && $oldExhibicion === $exhibicion) {
                $tipo = 'sin_cambios';
            } else {
                $actualizado = pg_ejecutar($db, 'UPDATE ' . PG_TABLA . ' SET UNIDADES_PUNTA=?, ACTIVO=?, EXHIBICION=? WHERE PAIS=? AND PLU=?',
                    [$unidades, $activo, $exhibicion, (string)$fila['PAIS'], (string)$fila['PLU']]);
                sqlsrv_free_stmt($actualizado);
                $tipo = 'actualizado';

                // Registrar solo los campos que cambiaron (Edición)
                $cambios = [];
                if ($oldUnidades !== $unidades) {
                    $cambios[] = "Unidades Punta: {$oldUnidades} A {$unidades}";
                }
                if ($oldActivo !== $activo) {
                    $cambios[] = "Activo: {$oldActivo} A {$activo}";
                }
                if ($oldExhibicion !== $exhibicion) {
                    $cambios[] = "Exhibición: {$oldExhibicion} A {$exhibicion}";
                }
                $detalleAccion = "Modificado: " . implode(' | ', $cambios);
            }
        } else {
            $insertado = pg_ejecutar($db, 'INSERT INTO ' . PG_TABLA . ' (PAIS, PLU, UNIDADES_PUNTA, ACTIVO, EXHIBICION) VALUES (?, ?, ?, ?, ?)',
                [$pais, $plu, $unidades, $activo, $exhibicion]);
            sqlsrv_free_stmt($insertado);
            $tipo = 'insertado';
            
            // Registrar los valores con los que se creó el registro
            $detalleAccion = "Creado con -> Unidades Punta: {$unidades} | Activo: {$activo} | Exhibición: {$exhibicion}";
        }
        
        if (!sqlsrv_commit($db)) throw new RuntimeException('No se pudo confirmar el guardado.');
    } catch (Throwable $e) {
        sqlsrv_rollback($db);
        throw $e;
    }

    // Registrar en auditoría si hubo una inserción o actualización real
    if ($tipo !== 'sin_cambios') {
        $infoArticulo = $descripcionArticulo !== '' ? " | Artículo: {$descripcionArticulo}" : ($referenciaArticulo !== '' ? " | Ref: {$referenciaArticulo}" : '');
        $mensajeFinal = "PLU: {$plu}{$infoArticulo} | {$detalleAccion}";
        
        pg_registrar(
            $tipo === 'insertado' ? 'PUNTAS_AGREGADO' : 'PUNTAS_EDITADO',
            $mensajeFinal,
            $pais
        );
    }

    return ['resultado' => $tipo, 'plu' => $plu];
}

function pg_importar($db, string $pais, array $rows): array
{
    if (count($rows) < 1 || count($rows) > 300) throw new InvalidArgumentException('El lote debe tener entre 1 y 300 artículos.');
    $resumen = ['insertados' => 0, 'actualizados' => 0, 'sin_cambios' => 0, 'rechazados' => 0, 'errores' => []];
    $vistos = [];
    foreach ($rows as $i => $row) {
        try {
            if (!is_array($row)) throw new InvalidArgumentException('Registro inválido.');
            $plu = pg_plu($row['plu'] ?? '', $pais);
            if (isset($vistos[$plu])) throw new InvalidArgumentException('PLU duplicado en el mismo lote.');
            $vistos[$plu] = true;
            $salida = pg_guardar($db, $pais, $row);
            $resumen[$salida['resultado'] === 'insertado' ? 'insertados' : ($salida['resultado'] === 'actualizado' ? 'actualizados' : 'sin_cambios')]++;
        } catch (InvalidArgumentException | RuntimeException $e) {
            $resumen['rechazados']++;
            if (count($resumen['errores']) < 12) $resumen['errores'][] = 'Fila ' . ($i + 1) . ': ' . $e->getMessage();
        }
    }
    pg_registrar('PUNTAS_IMPORTACION', 'Lote de ' . count($rows) . ' | Nuevos: ' . $resumen['insertados'] . ' | Actualizados: ' . $resumen['actualizados'] . ' | Rechazados: ' . $resumen['rechazados'], $pais);
    return $resumen;
}
