<?php
/* API de lectura, alta, edición e importación. */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');

function pg_responder(array $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

try {
    require_once __DIR__ . '/inc/init.php';
    $db = $sqlsrv_conn_exhibicion;
    $accion = (string)($_GET['action'] ?? 'list');
    $metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($metodo === 'GET') {
        $pais = pg_pais((string)($_GET['pais'] ?? ''));
        if ($accion === 'list') {
            $filtros = [];
            foreach (array_keys(pg_columnas()) as $campo) {
                $filtros[$campo] = (string)($_GET['f_' . $campo] ?? '');
            }
            pg_responder(['ok' => true] + pg_listar($db, $pais,
                (int)($_GET['page'] ?? 1), (int)($_GET['per'] ?? 50),
                $filtros, (string)($_GET['sort'] ?? 'plu'), (string)($_GET['dir'] ?? 'asc')));
        }
        if ($accion === 'options') {
            $filtros = [];
            foreach (array_keys(pg_columnas()) as $campo) {
                $filtros[$campo] = (string)($_GET['f_' . $campo] ?? '');
            }
            pg_responder(['ok' => true] + pg_valores_filtro($db, $pais,
                (string)($_GET['field'] ?? ''), (string)($_GET['q'] ?? ''), $filtros));
        }
        if ($accion === 'catalog') {
            $plu = pg_plu((string)($_GET['plu'] ?? ''), $pais);
            pg_responder(['ok' => true, 'articulo' => pg_buscar_catalogo($db, $pais, $plu)]);
        }
        pg_responder(['ok' => false, 'message' => 'Acción no permitida.'], 404);
    }

    if ($metodo !== 'POST') {
        header('Allow: GET, POST');
        pg_responder(['ok' => false, 'message' => 'Método no permitido.'], 405);
    }
    if (!in_array($accion, ['save', 'import'], true)) pg_responder(['ok' => false, 'message' => 'Acción no permitida.'], 404);
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($token === '' || !hash_equals((string)($_SESSION['puntas_csrf'] ?? ''), $token)) {
        pg_responder(['ok' => false, 'message' => 'Sesión vencida. Actualiza la página.'], 403);
    }
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 250000) {
        throw new InvalidArgumentException('Lote demasiado grande.');
    }
    $cuerpo = file_get_contents('php://input');
    if (!is_string($cuerpo) || strlen($cuerpo) > 250000) throw new InvalidArgumentException('Solicitud demasiado grande.');
    $datos = json_decode($cuerpo, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($datos)) throw new InvalidArgumentException('Datos inválidos.');
    $pais = pg_pais((string)($datos['pais'] ?? ''));
    if ($accion === 'save') {
        $modo = (string)($datos['modo'] ?? 'add');
        if (!in_array($modo, ['add', 'edit'], true)) throw new InvalidArgumentException('Operación inválida.');
        $r = pg_guardar($db, $pais, $datos, $modo === 'edit');
        pg_responder(['ok' => true] + $r);
    }
    if (!isset($datos['rows']) || !is_array($datos['rows'])) throw new InvalidArgumentException('Faltan los registros.');
    foreach ($datos['rows'] as $fila) {
        if (!is_array($fila)) throw new InvalidArgumentException('Fila inválida.');
        $origen = trim((string)($fila['pais'] ?? ''));
        if ($origen !== '') {
            $normal = strtoupper($origen);
            if (!in_array($normal, pg_variantes($pais), true)) {
                throw new InvalidArgumentException('El CSV contiene un país diferente al seleccionado.');
            }
        }
    }
    pg_responder(['ok' => true] + pg_importar($db, $pais, $datos['rows']));
} catch (DomainException $e) {
    pg_responder(['ok' => false, 'message' => $e->getMessage()], 403);
} catch (InvalidArgumentException | JsonException $e) {
    pg_responder(['ok' => false, 'message' => $e->getMessage()], 422);
} catch (Throwable $e) {
    $codigo = strtoupper(bin2hex(random_bytes(4)));
    error_log('Puntas Góndola [' . $codigo . ']: ' . $e->getMessage());
    pg_responder(['ok' => false, 'message' => 'No se pudo completar la operación. Código: ' . $codigo], 500);
}
