<?php
/* Interfaz de Puntas Góndolas. */
require_once __DIR__ . '/inc/init.php';
$ajustes = [
    'pais' => $paisSesion,
    'propietario' => $propietario,
    'api' => 'api.php',
    'csrf' => (string)$_SESSION['puntas_csrf'],
];
?>
<!doctype html>
<html lang="es" data-pg-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Puntas Góndolas</title>
    <!-- Estilos locales de Bootstrap -->
     <link rel="stylesheet" href="../bootstrap-icons/bootstrap-icons.min.css">
     
    <link rel="stylesheet" href="assets/puntas.css?v=17">
  
    <script src="js/gondolas.js?v=13" defer></script>
</head>
<body>
<main class="pg-shell">
    <section class="pg-sheet">
     
        <div class="pg-toolbar">
            <label class="pg-field pg-country"><span>País</span>
                <select id="pais" <?= !$propietario ? 'disabled' : '' ?>>
                    <option value="HONDURAS" <?= $paisSesion === 'HONDURAS' ? 'selected' : '' ?>>Honduras</option>
                    <option value="NICARAGUA" <?= $paisSesion === 'NICARAGUA' ? 'selected' : '' ?>>Nicaragua</option>
                </select>
            </label>
            <div class="pg-filters-tools">
                <button id="limpiar" class="pg-btn pg-outline pg-clear-button" type="button"><span aria-hidden="true"></span>Limpiar</button>
                <label class="pg-size-label"><span>Filas</span><select id="per"><option>50</option><option>100</option><option>200</option><option>500</option></select></label>
            </div>
            <div class="pg-toolbar-actions">
                <button id="agregar" class="pg-btn pg-primary" type="button"><span aria-hidden="true"></span>Agregar artículo</button>
                <button id="importar" class="pg-btn pg-outline" type="button"><span aria-hidden="true"></span>Importar CSV</button>
                <button id="actualizar" class="pg-btn pg-outline" type="button"><span aria-hidden="true"></span>Actualizar</button>
            </div>
        </div>
        <div id="mensaje" class="pg-message" hidden role="status" aria-live="polite"></div>
        <div class="pg-table-wrap">
            <table class="pg-table">
                <thead>
                    <tr>
                        <th>N.º</th>
                        <?php foreach ([
                            'plu' => 'PLU',
                            'referencia' => 'Referencia',
                            'descripcion' => 'Descripción',
                            'departamento' => 'Departamento',
                            'seccion' => 'Sección',
                            'familia' => 'Familia',
                            'unidades_punta' => 'Unidades Punta',
                            'activo' => 'Activo',
                            'exhibicion' => 'Exhibición',
                        ] as $campo => $titulo): ?>
                        <th><span class="pg-th-filter"><?= htmlspecialchars($titulo, ENT_QUOTES) ?>
                            <button type="button" class="pg-filter-trigger" data-field="<?= htmlspecialchars($campo, ENT_QUOTES) ?>" data-label="<?= htmlspecialchars($titulo, ENT_QUOTES) ?>" aria-label="Filtrar <?= htmlspecialchars($titulo, ENT_QUOTES) ?>" title="Filtro tipo Excel">
                                <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 2h13L9.2 7.1v5.1l-2.4 1.8V7.1L1.5 2z"/></svg>
                            </button>
                        </span></th>
                        <?php endforeach; ?>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody id="tabla"><tr><td colspan="11" class="pg-empty">Consultando registros...</td></tr></tbody>
            </table>
        </div>
        <footer class="pg-pagination"><span id="resumen">—</span><div class="pg-page-buttons" aria-label="Paginación">
            <button id="primera" class="pg-btn pg-outline" type="button" title="Primera página" aria-label="Primera página">«</button>
            <button id="anterior" class="pg-btn pg-outline" type="button" title="Página anterior" aria-label="Página anterior">‹</button>
            <span id="pagina">1 de 1</span>
            <button id="siguiente" class="pg-btn pg-outline" type="button" title="Página siguiente" aria-label="Página siguiente">›</button>
            <button id="ultima" class="pg-btn pg-outline" type="button" title="Última página" aria-label="Última página">»</button>
        </div></footer>
    </section>
    <p class="pg-note">Los datos descriptivos provienen del catálogo de Exhibición. La tabla Puntas Góndolas guarda país, PLU, unidades, activo y exhibición. No se eliminan registros.</p>
</main>

<div id="filtroMenu" class="pg-filter-menu" hidden role="group" aria-label="Opciones de filtro">
    <div class="pg-filter-head">
        <div><span class="pg-overline">FILTRO DE COLUMNA</span><strong id="filtroTitulo">Filtrar</strong></div>
        <button type="button" class="pg-filter-close" id="filtroCerrar" aria-label="Cerrar filtro">×</button>
    </div>
    <label class="pg-field">Orden
        <select id="filtroOrden"><option value="asc">Ordenar A → Z</option><option value="desc">Ordenar Z → A</option></select>
    </label>
    <input id="filtroBuscar" class="pg-filter-search" type="search" placeholder="Buscar valor..." aria-label="Buscar valores" autocomplete="off">
    <label class="pg-select-all"><input id="filtroTodos" type="checkbox"> Seleccionar todo</label>
    <div id="filtroOpciones" class="pg-filter-options"></div>
    <small class="pg-filter-hint">Opciones de todos los registros, no solo de esta página. Escribe para buscar cualquier valor.</small>
    <div class="pg-filter-actions"><button type="button" class="pg-btn pg-outline" id="filtroLimpiar">Limpiar</button><button type="button" class="pg-btn pg-primary" id="filtroAplicar">Aplicar</button></div>
</div>

<dialog id="modalArticulo" class="pg-dialog">
    <form id="formArticulo">
        <header class="pg-modal-head">
            <span class="pg-modal-icon" aria-hidden="true">＋</span>
            <div><h2 id="tituloModal">Agregar artículo</h2><p class="pg-modal-subtitle">Datos del artículo en punta de góndola</p></div>
            <button class="pg-close" type="button" data-close="modalArticulo" aria-label="Cerrar">×</button>
        </header>
        <div class="pg-modal-body">
            <div class="pg-form-grid">
                <label class="pg-field">País<input id="paisModal" readonly></label>
                <label class="pg-field">PLU<input id="plu" maxlength="14" pattern="[0-9]{12}(HN|NI)" required placeholder="002009008001HN" autocomplete="off" title="12 dígitos seguidos del código de país HN o NI"></label>
                <label class="pg-field">Unidades Punta<input id="unidades" type="number" step="1" min="0" max="2147483647" required></label>
                <label class="pg-field">Activo<select id="activo"><option value="1">1 · Activo</option><option value="0">0 · Inactivo</option></select></label>
                <label class="pg-field">Exhibición<input id="exhibicion" type="number" step="1" min="0" max="2147483647" required></label>
            </div>
            <p class="pg-hint">Formato permitido: 12 dígitos y el sufijo del país (HN o NI). Ejemplo: 002009008001HN.</p>
            <div id="datosArticulo" class="pg-catalog-info">Consulta primero para verificar el PLU y sus datos descriptivos.</div>
            <p class="pg-hint">Activo: 1 habilitado, 0 inactivo. La referencia es informativa y no se guarda en esta tabla.</p>
            <div id="errorArticulo" class="pg-form-error" role="alert" hidden></div>
        </div>
        <footer class="pg-modal-actions"><button class="pg-btn pg-outline" type="button" data-close="modalArticulo">Cancelar</button><button class="pg-btn pg-primary" type="submit" id="guardar">Guardar artículo</button></footer>
    </form>
</dialog>

<dialog id="modalImportar" class="pg-dialog">
    <header class="pg-modal-head">
        <span class="pg-modal-icon" aria-hidden="true">⇧</span>
        <div><h2>Importación masiva</h2><p class="pg-modal-subtitle">Cargar artículos desde un archivo CSV</p></div>
        <button class="pg-close" type="button" data-close="modalImportar" aria-label="Cerrar">×</button>
    </header>
    <div class="pg-modal-body">
        <p class="pg-hint">Selecciona un CSV UTF-8 exportado desde Excel. Debe contener <strong>PAIS, PLU, UNIDADES_PUNTA, ACTIVO, EXHIBICION</strong>.</p>
        <label class="pg-field pg-file-field"><span>Archivo CSV</span><input id="archivo" type="file" accept=".csv,text/csv"></label>
        <p class="pg-hint">Los registros existentes se actualizan; los idénticos se omiten.</p>
        <div id="estadoImportacion" class="pg-import-status" role="status" aria-live="polite"></div>
        <progress id="progreso" max="100" value="0" hidden></progress>
    </div>
    <footer class="pg-modal-actions"><button class="pg-btn pg-outline" type="button" data-close="modalImportar">Cerrar</button><button class="pg-btn pg-primary" id="ejecutar" type="button">Importar artículos</button></footer>
</dialog>

<script src="../bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>

  <script src="js/tema.js?v=12" defer></script>

<script>window.PUNTAS_CONFIG = <?= json_encode($ajustes, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script>
document.addEventListener('contextmenu', function (event) {
    event.preventDefault();
}, true);
</script>

</body>
</html>
