<?php
/* Consulta de inventario para ver stock mayor a 0 */
require_once dirname(__DIR__) . '/exhibiciontotal/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_con_stock.php';
require_module_access('consulta_con_stock');

function stock_e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function stock_url(array $changes = []): string {
    $query = array_merge($_GET, $changes);
    unset($query['export'], $query['options'], $query['almacen']);
    $query['vista'] = 'consulta_con_stock';
    return 'index.php?' . http_build_query($query);
}
/* La exportación se ejecuta directamente para enviar el CSV antes del html. */
function stock_export_url(): string {
    $query = $_GET;
    unset($query['options'], $query['almacen']);
    $query['vista'] = 'consulta_con_stock';
    $query['export'] = 'csv';
    $query['page'] = 1;
    return '/exhibicion_DT/consulta_stock/index.php?' . http_build_query($query);
}
$columns = [
    'codarticulo'=>'CODARTICULO', 'plu'=>'PLU', 'codbarras'=>'CODBARRA',
    'referencia'=>'Referencia', 'descripcion'=>'Descripción',
    'departamento'=>'Departamento', 'seccion'=>'Sección', 'familia'=>'Familia',
    'inventario_tienda'=>'Inventario Tienda'
];
$fields = [
    'codarticulo'=>'CODARTICULO','plu'=>'PLU','codbarras'=>'CODBARRAS',
    'referencia'=>'REFERENCIA','descripcion'=>'DESCRIPCION',
    'departamento'=>'DEPARTAMENTO','seccion'=>'SECCION','familia'=>'FAMILIA',
    'inventario_tienda'=>'INVENTARIO_TIENDA'
];
$filters = stock_filters_from_get();
unset($filters['almacen']);
$perPage = (int)($_GET['per_page'] ?? 100);
if (!in_array($perPage, [100,200,400,500], true)) $perPage = 100;
$page = max(1, (int)($_GET['page'] ?? 1));
$sort = (string)($_GET['sort'] ?? '');
$dir = strtoupper((string)($_GET['dir'] ?? 'ASC'));
if (!in_array($dir, ['ASC','DESC'], true)) $dir = 'ASC';
$selectedStore = trim((string)($_GET['tienda_seleccionada'] ?? ''));
$rows = []; $hasNext = false; $totalRows = 0; $totalPages = 1; $error = '';

/* Las tiendas se obtienen del país y de los permisos del usuario. */
$ctx = stock_context_from_session();
$stores = [];
try {
    if (in_array($ctx['rol'], ['propietario','super_admin'], true)) {
        $db = $ctx['db']; // Base elegida por la sesión, nunca desde GET.
        $stmt = sqlsrv_query($sqlsrv_conn_exhibicion,
            "SELECT DISTINCT LTRIM(RTRIM(CONVERT(VARCHAR(20),CODALMACEN))) AS COD,
                    LTRIM(RTRIM(CONVERT(VARCHAR(150),NOMBREALMACEN))) AS NOMBRE
             FROM {$db}.dbo.ALMACEN
             WHERE LTRIM(RTRIM(CONVERT(VARCHAR(20),CODALMACEN))) LIKE '[0-9][0-9]'
             ORDER BY COD");
        if ($stmt === false) throw new RuntimeException('No se pudieron cargar almacenes.');
        while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) $stores[$r['COD']] = $r['NOMBRE'];
        sqlsrv_free_stmt($stmt);
    } else {
        $allowed = stock_get_user_stores($conn, (int)$ctx['usuarioId'], $ctx['paisCode']);
        if ($allowed) {
            $db = $ctx['db'];
            $marks = implode(',', array_fill(0,count($allowed),'?'));
            $stmt = sqlsrv_query($sqlsrv_conn_exhibicion,
                "SELECT LTRIM(RTRIM(CONVERT(VARCHAR(20),CODALMACEN))) AS COD,
                        LTRIM(RTRIM(CONVERT(VARCHAR(150),NOMBREALMACEN))) AS NOMBRE
                 FROM {$db}.dbo.ALMACEN
                 WHERE LTRIM(RTRIM(CONVERT(VARCHAR(20),CODALMACEN))) IN ($marks)", $allowed);
            if ($stmt === false) throw new RuntimeException('No se pudieron cargar almacenes.');
            while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) $stores[$r['COD']] = $r['NOMBRE'];
            sqlsrv_free_stmt($stmt);
        }
    }
    ksort($stores);
    $excludedStoreNames = ['joe', 'operaciones','NO USRA']; // TIENDAS A OCULTAR
    $stores = array_filter($stores, static function ($name) use ($excludedStoreNames): bool {
        foreach ($excludedStoreNames as $excludedName) {
            if (stripos((string)$name, $excludedName) !== false) return false;
        }
        return true;
    });
    /* Los usuarios de tienda estan fijos para que salga solo su única tienda asignada. */
    if ($ctx['rol'] === 'tienda') {
        $selectedStore = $stores ? (string)array_key_first($stores) : '';
    } else {
        /* El almacén seleccionado es un filtro exacto, no una búsqueda parcial. */
        $selectedStore = trim((string)($_GET['tienda_seleccionada'] ?? ''));
    }
    if ($selectedStore !== '' && !array_key_exists($selectedStore, $stores)) {
        throw new RuntimeException('Almacén no autorizado.');
    }
    /* Elegir una tienda autorizada por defecto para no consultar todas a la vez. */
    if ($selectedStore === '' && $stores) {
        $selectedStore = (string)array_key_first($stores);
    }
    if ($selectedStore !== '') $filters['codalmacen'] = $selectedStore;

    /* No ejecutar una consulta global cuando no hay almacenes autorizados. */
    if (!$stores) {
        throw new RuntimeException('No hay almacenes disponibles para este usuario.');
    }
    [$sql,$params] = stock_build_query($filters);
    $export = ($_GET['export'] ?? '') === 'csv';

    /* Contar registros filtrados en la misma consulta, sin ejecutar otra consulta SQL. */
    if (!$export) {
        $sql = preg_replace(
            '/^\s*SELECT\s+\*\s+FROM\b/i',
            'SELECT Q.*, COUNT_BIG(*) OVER() AS TOTAL_REGISTROS FROM',
            $sql,
            1,
            $replacements
        );
        if ($replacements !== 1) {
            throw new RuntimeException('No se pudo preparar la paginación.');
        }
    }

    $orderColumns = [];
    if (isset($fields[$sort])) {
        $orderColumns[$fields[$sort]] = 'Q.['.$fields[$sort].'] '.$dir;
    }
    foreach (['CODALMACEN', 'CODARTICULO', 'CODBARRAS', 'PLU'] as $column) {
        if (!isset($orderColumns[$column])) {
            $orderColumns[$column] = 'Q.['.$column.'] ASC';
        }
    }
    $sql .= ' ORDER BY '.implode(', ', $orderColumns);
    if (!$export) {
        $sql .= ' OFFSET ? ROWS FETCH NEXT ? ROWS ONLY';
        $params[] = ($page - 1) * $perPage;
        $params[] = $perPage;
    }
    $stmt = sqlsrv_query($sqlsrv_conn_exhibicion,$sql,$params,['QueryTimeout'=>300]);
    if ($stmt === false) { error_log('Stock SQL: '.print_r(sqlsrv_errors(),true)); throw new RuntimeException('Consulta SQL fallida.'); }
    if ($export) {
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="consulta_con_stock.csv"');
        $out = fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF");
        fputcsv($out,array_merge(['N°'],array_values($columns)));
        $rowNumber = 0;
        while ($r=sqlsrv_fetch_array($stmt,SQLSRV_FETCH_ASSOC)) {
            $line=[++$rowNumber];
            foreach ($fields as $field) {
                $value=(string)($r[$field]??'');
                if (preg_match('/^\s*[=+@\-]/u',$value)) $value="'".$value;
                $line[]=$value;
            }
            fputcsv($out,$line);
        }
        sqlsrv_free_stmt($stmt); fclose($out); exit;
    }
    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        if ($totalRows === 0 && isset($r['TOTAL_REGISTROS'])) {
            $totalRows = (int)$r['TOTAL_REGISTROS'];
        }
        unset($r['TOTAL_REGISTROS']);
        $rows[] = $r;
    }
    sqlsrv_free_stmt($stmt);
    $totalPages = max(1, (int)ceil($totalRows / $perPage));
    $hasNext = $page < $totalPages;
} catch (Throwable $e) {
    error_log('Consulta con Stock: '.$e->getMessage());
    $error='No fue posible cargar la consulta. Revise el registro de errores del servidor.';
}
?>

<link rel="stylesheet" href="/exhibicion_DT/consulta_stock/CSS/stock.css?v=12">

<main class="stock-view pg-shell">
    <?php if ($error !== ''): ?>
        <div class="stock-message" role="alert"><?= stock_e($error) ?></div>
    <?php endif; ?>

    <section class="pg-sheet">
        <div class="pg-toolbar">
            <!-- seleccionar almacen en el encabezado. -->
            <form method="get" action="index.php" id="stock-filters" class="stock-store-form">
                <input type="hidden" name="vista" value="consulta_con_stock">
                <input type="hidden" name="per_page" value="<?= $perPage ?>">
                <input type="hidden" name="sort" value="<?= stock_e($sort) ?>">
                <input type="hidden" name="dir" value="<?= stock_e($dir) ?>">
                <?php foreach (array_merge(['region' => 'País', 'codalmacen' => 'Código tienda'], $columns) as $key => $label): ?>
                    <input type="hidden" name="<?= stock_e($key) ?>" data-filter="<?= stock_e($key) ?>" value="<?= stock_e($filters[$key] ?? '') ?>">
                <?php endforeach; ?>
                <label class="pg-country" <?= $ctx['rol'] === 'tienda' ? '' : 'for="stockStore"' ?>>
                    <span>Almacén</span>
                    <?php if ($ctx['rol'] === 'tienda'): ?>
                        <span><?= stock_e($selectedStore . ' . ' . ($stores[$selectedStore] ?? '')) ?></span>
                        <input type="hidden" id="stockStore" name="tienda_seleccionada" value="<?= stock_e($selectedStore) ?>">
                    <?php else: ?>
                        <select id="stockStore" name="tienda_seleccionada" onchange="this.form.submit()">
                            <option value="">Seleccione un almacén</option>
                            <?php foreach ($stores as $code => $name): ?>
                                <option value="<?= stock_e($code) ?>" <?= $selectedStore === (string)$code ? 'selected' : '' ?>><?= stock_e($code . ' . ' . $name) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </label>
            </form>

            <div class="pg-filters-tools">
                <a class="pg-btn pg-outline" href="index.php?<?= stock_e(http_build_query(['vista' => 'consulta_con_stock', 'tienda_seleccionada' => $selectedStore])) ?>">Limpiar</a>
                <form method="get" action="index.php" class="stock-page-form">
                    <input type="hidden" name="vista" value="consulta_con_stock">
                    <?php foreach ($_GET as $k => $v): if (in_array($k, ['vista', 'per_page', 'page', 'export', 'options'], true) || !is_scalar($v)) continue; ?>
                        <input type="hidden" name="<?= stock_e($k) ?>" value="<?= stock_e($v) ?>">
                    <?php endforeach; ?>
                    <label class="pg-size-label"><span>Filas</span>
                        <select name="per_page" onchange="this.form.submit()">
                            <?php foreach ([100, 200, 400, 500] as $n): ?>
                                <option value="<?= $n ?>" <?= $perPage === $n ? 'selected' : '' ?>><?= $n ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </form>
            </div>

            <div class="pg-toolbar-actions">
                <a class="pg-btn pg-outline" href="<?= stock_e(stock_url()) ?>">Actualizar</a>
                <a class="pg-btn pg-outline stock-export" href="<?= stock_e(stock_export_url()) ?>"><i class="bi bi-file-earmark-excel" aria-hidden="true"></i> Exportar Excel</a>
            </div>
        </div>

        <!-- En móviles los filtros se abren sin desplazar la tabla. -->
        <details class="stock-mobile-filter-panel">
            <summary>Filtrar y ordenar artículos</summary>
            <div class="stock-mobile-filter-grid">
                <?php foreach ($columns as $key => $label): ?>
                    <button type="button" class="pg-btn pg-outline stock-filter-button stock-mobile-filter-chip <?= ($filters[$key] ?? '') !== '' ? 'is-active' : '' ?>"
                        data-field="<?= stock_e($key) ?>" data-label="<?= stock_e($label) ?>">
                        <i class="bi bi-funnel" aria-hidden="true"></i> <?= stock_e($label) ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <div class="stock-mobile-sort">
                <label>Ordenar por
                    <select aria-label="Ordenar por columna" onchange="document.querySelector('#stock-filters [name=sort]').value=this.value;document.getElementById('stock-filters').submit()">
                        <option value="" <?= $sort === '' ? 'selected' : '' ?>>Orden predeterminado</option>
                        <?php foreach ($columns as $key => $label): ?>
                            <option value="<?= stock_e($key) ?>" <?= $sort === $key ? 'selected' : '' ?>><?= stock_e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Dirección
                    <select aria-label="Dirección de orden" onchange="document.querySelector('#stock-filters [name=dir]').value=this.value;document.getElementById('stock-filters').submit()">
                        <option value="ASC" <?= $dir === 'ASC' ? 'selected' : '' ?>>Ascendente</option>
                        <option value="DESC" <?= $dir === 'DESC' ? 'selected' : '' ?>>Descendente</option>
                    </select>
                </label>
            </div>
        </details>

        <div class="pg-table-wrap">
            <table class="pg-table stock-table">
                <thead><tr>
                    <th scope="col">N.º</th>
                    <?php foreach ($columns as $key => $label): ?>
                        <th scope="col" class="<?= $key === 'inventario_tienda' ? 'stock-inventory-heading' : '' ?>">
                            <span class="pg-th-filter">
                                <a class="stock-sort-link" href="<?= stock_e(stock_url(['sort' => $key, 'dir' => $sort === $key && $dir === 'ASC' ? 'DESC' : 'ASC', 'page' => 1])) ?>"><?= stock_e($label) ?></a>
                                <button type="button" class="pg-filter-trigger stock-filter-button <?= ($filters[$key] ?? '') !== '' ? 'is-active' : '' ?>"
                                    data-field="<?= stock_e($key) ?>" data-label="<?= stock_e($label) ?>"
                                    aria-label="Filtrar <?= stock_e($label) ?>" title="Filtro tipo Excel">
                                    <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 2h13L9.2 7.1v5.1l-2.4 1.8V7.1L1.5 2z"/></svg>
                                </button>
                            </span>
                        </th>
                    <?php endforeach; ?>
                </tr></thead>
                <tbody>
                    <?php if (!$rows): ?>
                            <tr><td colspan="<?= count($columns) + 1 ?>" class="pg-empty" style="text-align: center;">No se encontraron artículos con stock mayor a cero.</td></tr>
                        <?php endif; ?>
                    <?php foreach ($rows as $index => $r): ?>
                        <tr>
                            <td class="pg-num"><?= ($page - 1) * $perPage + $index + 1 ?></td>
                            <?php foreach ($fields as $key => $field): ?>
                                <td class="<?= $key === 'inventario_tienda' ? 'stock-inventory-value' : '' ?>"><?= stock_e($r[$field] ?? '') ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <footer class="pg-pagination">
            <span><?= number_format($totalRows, 0, '.', ',') ?> registros</span>
            <div class="pg-page-buttons" aria-label="Paginación">
                <?php if ($page > 1): ?>
                    <a class="pg-btn pg-outline" href="<?= stock_e(stock_url(['page' => 1])) ?>" title="Primera página" aria-label="Primera página">«</a>
                    <a class="pg-btn pg-outline" href="<?= stock_e(stock_url(['page' => $page - 1])) ?>" title="Página anterior" aria-label="Página anterior">‹</a>
                <?php else: ?>
                    <button class="pg-btn pg-outline" type="button" disabled title="Primera página" aria-label="Primera página">«</button>
                    <button class="pg-btn pg-outline" type="button" disabled title="Página anterior" aria-label="Página anterior">‹</button>
                <?php endif; ?>
                <span><?= $page ?> de <?= $totalPages ?></span>
                <?php if ($hasNext): ?>
                    <a class="pg-btn pg-outline" href="<?= stock_e(stock_url(['page' => $page + 1])) ?>" title="Página siguiente" aria-label="Página siguiente">›</a>
                    <a class="pg-btn pg-outline" href="<?= stock_e(stock_url(['page' => $totalPages])) ?>" title="Última página" aria-label="Última página">»</a>
                <?php else: ?>
                    <button class="pg-btn pg-outline" type="button" disabled title="Página siguiente" aria-label="Página siguiente">›</button>
                    <button class="pg-btn pg-outline" type="button" disabled title="Última página" aria-label="Última página">»</button>
                <?php endif; ?>
            </div>
        </footer>
    </section>

    <p class="pg-note"> Las existencias corresponden al almacén seleccionado. Esta consulta es de solo lectura; no se modifican ni eliminan registros.</p>

    <div class="pg-filter-menu" id="stockExcelMenu" hidden role="group" aria-label="Opciones de filtro">
        <div class="pg-filter-head">
            <div><span class="pg-overline">FILTRO DE COLUMNA</span><strong id="stockExcelTitle">Filtrar</strong></div>
            <button type="button" class="pg-filter-close" id="stockExcelClose" aria-label="Cerrar filtro">×</button>
        </div>
        <label class="pg-filter-order">Orden
            <select id="stockExcelSort"><option value="ASC">Ordenar A → Z</option><option value="DESC">Ordenar Z → A</option></select>
        </label>
        <input type="search" id="stockExcelSearch" class="pg-filter-search" placeholder="Buscar valor..." aria-label="Buscar valores" autocomplete="off">
        <label class="pg-select-all"><input type="checkbox" id="stockExcelAll"> Seleccionar todo</label>
        <div id="stockExcelOptions" class="pg-filter-options"></div>
        <small class="pg-filter-hint">Opciones de todos los registros, no solo de esta página. Escribe para buscar cualquier valor.</small>
        <div class="pg-filter-actions">
            <button type="button" class="pg-btn pg-outline" id="stockExcelClear">Limpiar</button>
            <button type="button" class="pg-btn pg-primary" id="stockExcelApply">Aplicar</button>
        </div>
    </div>
</main>
<script src="/exhibicion_DT/consulta_stock/JS/stock.js?v=14"></script>
