<?php
/* Devuelve los valores de filtros de toda la consulta, sin paginación. */
require_once dirname(__DIR__) . '/exhibiciontotal/conexion_exhibicion.php';
require_once __DIR__ . '/consulta_con_stock.php';
require_module_access('consulta_con_stock');
header('Content-Type: application/json; charset=UTF-8');
$fields = [
    'region'=>'REGION','codalmacen'=>'CODALMACEN','almacen'=>'ALMACEN',
    'codarticulo'=>'CODARTICULO','plu'=>'PLU','codbarras'=>'CODBARRAS',
    'referencia'=>'REFERENCIA','descripcion'=>'DESCRIPCION',
    'departamento'=>'DEPARTAMENTO','seccion'=>'SECCION','familia'=>'FAMILIA',
    'inventario_tienda'=>'INVENTARIO_TIENDA'
];
$field = (string)($_GET['field'] ?? '');
if (!isset($fields[$field])) { http_response_code(400); echo '[]'; exit; }
try {
    $filters = stock_filters_from_get();
    $filters['almacen'] = trim((string)($_GET['almacen'] ?? ''));
    $filters[$field] = ''; // Mostrar alternativas aunque la columna ya esté filtrada.
    $store = trim((string)($_GET['tienda_seleccionada'] ?? ''));
    $ctx = stock_context_from_session();
    if ($store !== '') {
        if (!preg_match('/^[0-9]{2}$/', $store)) throw new RuntimeException('Tienda inválida.');
        if (!in_array($ctx['rol'], ['propietario','super_admin'], true)) {
            $allowed = stock_get_user_stores($conn, (int)$ctx['usuarioId'], $ctx['paisCode']);
            if (!in_array($store, $allowed, true)) throw new RuntimeException('Tienda no autorizada.');
        }
        $filters['codalmacen'] = $store;
    }
    [$sql,$params] = stock_build_query($filters);
    if ($filters['almacen'] !== '') stock_add_excel_exact_filter($sql,$params,'Q.ALMACEN',$filters['almacen']);
    $column = $fields[$field];
    $search = trim((string)($_GET['search'] ?? ''));
    $optionSql = "SELECT DISTINCT TOP (300) LTRIM(RTRIM(CONVERT(NVARCHAR(255), X.[$column]))) AS VALOR
                  FROM ($sql) X";
    if ($search !== '') {
        $escapedSearch = strtr($search, ['~' => '~~', '%' => '~%', '_' => '~_', '[' => '~[']);
        $optionSql .= " WHERE LTRIM(RTRIM(CONVERT(NVARCHAR(255), X.[$column])))
                            COLLATE DATABASE_DEFAULT
                            LIKE ? COLLATE DATABASE_DEFAULT ESCAPE '~'";
        $params[] = '%' . $escapedSearch . '%';
    }
    $sql = $optionSql . ' ORDER BY VALOR';
    $stmt = sqlsrv_query($sqlsrv_conn_exhibicion, $sql, $params, ['QueryTimeout'=>300]);
    if ($stmt === false) throw new RuntimeException(print_r(sqlsrv_errors(), true));
    $values=[];
    while ($r=sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) $values[]=(string)($r['VALOR']??'');
    sqlsrv_free_stmt($stmt);
    echo json_encode($values, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
    error_log('Opciones de stock: '.$e->getMessage());
    http_response_code(500); echo '[]';
}
