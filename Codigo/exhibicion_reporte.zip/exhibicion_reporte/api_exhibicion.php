<?php
declare(strict_types=1);


error_reporting(0);
ini_set('display_errors', '0');

ini_set('max_execution_time', '120');
set_time_limit(120);

/*  LIMPIAR BUFFER
    */
while (ob_get_level() > 0) {
    ob_end_clean();
}

/* CABECERAS JSON
    */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

/*  VALIDAR TOKEN
    */
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    echo json_encode(['ok' => false, 'error' => 'Metodo no permitido.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$rutaCredenciales = dirname(__DIR__, 2) .
    DIRECTORY_SEPARATOR . 'privado_consulta' .
    DIRECTORY_SEPARATOR . 'conexiones_sqlsrv.php';
$rutaCredenciales = realpath($rutaCredenciales) ?: $rutaCredenciales;

if (!is_file($rutaCredenciales) || !is_readable($rutaCredenciales)) {
    error_log('Exhibicion: no se encontro la configuracion privada.');
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'Servicio no disponible.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$configuracionPrivada = require $rutaCredenciales;
$tokenPermitido = trim((string) ($configuracionPrivada['api_key'] ?? ''));

$headers = function_exists('getallheaders') ? getallheaders() : [];
$tokenRecibido = (string) (
    $headers['X-API-KEY']
    ?? $headers['x-api-key']
    ?? ''
);

if ($tokenRecibido === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
    if (preg_match('/\ABearer\s+(.*)\z/i', (string) $_SERVER['HTTP_AUTHORIZATION'], $coincidencia)) {
        $tokenRecibido = trim($coincidencia[1]);
    }
}

if (
    $tokenPermitido === ''
    || $tokenRecibido === ''
    || !hash_equals($tokenPermitido, $tokenRecibido)
) {
    http_response_code(403);
    echo json_encode([
        'ok' => false,
        'error' => 'No autorizado.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$sqlConfig = $configuracionPrivada['sqlserver'] ?? null;
if (!is_array($sqlConfig)) {
    error_log('Exhibicion: configuracion SQL Server incompleta.');
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'Servicio no disponible.'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (!function_exists('sqlsrv_connect')) {
    error_log('Exhibicion: la extension SQLSRV no esta habilitada.');
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'Servicio no disponible.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$servidor = trim((string) ($sqlConfig['servidor'] ?? ''));
$base = trim((string) ($sqlConfig['base'] ?? ''));
$usuario = trim((string) ($sqlConfig['usuario'] ?? ''));
$clave = (string) ($sqlConfig['clave'] ?? '');

if ($servidor === '' || $base === '' || $usuario === '' || $clave === '') {
    error_log('Exhibicion: faltan credenciales SQL Server.');
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'Servicio no disponible.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sqlsrvConn = sqlsrv_connect($servidor, [
    'Database' => $base,
    'UID' => $usuario,
    'PWD' => $clave,
    'CharacterSet' => 'UTF-8',
    'Encrypt' => true,
    'TrustServerCertificate' => true,
    'LoginTimeout' => 10,
]);

if ($sqlsrvConn === false) {
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);
    if (is_array($errores)) {
        foreach ($errores as $error) {
            error_log(
                'Exhibicion SQL [' .
                ($error['SQLSTATE'] ?? 'N/A') .
                '] Codigo ' . ($error['code'] ?? 'N/A') .
                ': ' . ($error['message'] ?? 'Error desconocido')
            );
        }
    }
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => 'Servicio no disponible.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sql = "
WITH DATOS_EXHIBICION AS (

    /* 
       HONDURAS / DETODO
        */

    SELECT
        E.REGION,
        CONVERT(VARCHAR(50), E.CODALMACEN) AS CODALMACEN,
        ISNULL(ALM.NOMBREALMACEN, '') AS TIENDA,

        ISNULL(E.CODBARRAS, '') AS CODBARRAS,

        ISNULL(A.REFPROVEEDOR, '') AS REFERENCIA,
        ISNULL(A.DESCRIPCION, '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,
        ISNULL(SC.DESCRIPCION, '') AS SECCION,
        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        TRIM(CONVERT(VARCHAR(100), E.PLU)) AS PLU,

        ISNULL(E.UXC, 0) AS UXC,
        ISNULL(E.EXHIBICION, 0) AS EXHIBICION,

        CONVERT(VARCHAR(100), E.CODARTICULO) AS CODARTICULO

    FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

    LEFT JOIN DETODO.dbo.ARTICULOS A
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), A.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN DETODO.dbo.ALMACEN ALM
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), ALM.CODALMACEN))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) COLLATE DATABASE_DEFAULT

    LEFT JOIN DETODO.dbo.DEPARTAMENTO D
        ON D.NUMDPTO = A.DPTO

    LEFT JOIN DETODO.dbo.SECCIONES SC
        ON SC.NUMDPTO = A.DPTO
       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN DETODO.dbo.FAMILIAS F
        ON F.NUMDPTO = A.DPTO
       AND F.NUMSECCION = A.SECCION
       AND F.NUMFAMILIA = A.FAMILIA

    WHERE E.REGION NOT IN ('NICARAGUA', 'NI')
      AND CONVERT(VARCHAR(50), E.CODALMACEN) LIKE '[0-9][0-9]'

    UNION ALL

    /* 
       NICARAGUA / ACANICARAGUA2
        */

    SELECT
        E.REGION,
        CONVERT(VARCHAR(50), E.CODALMACEN) AS CODALMACEN,
        ISNULL(ALM.NOMBREALMACEN, '') AS TIENDA,

        ISNULL(E.CODBARRAS, '') AS CODBARRAS,

        ISNULL(A.REFPROVEEDOR, '') AS REFERENCIA,
        ISNULL(A.DESCRIPCION, '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,
        ISNULL(SC.DESCRIPCION, '') AS SECCION,
        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        TRIM(CONVERT(VARCHAR(100), E.PLU)) AS PLU,

        ISNULL(E.UXC, 0) AS UXC,
        ISNULL(E.EXHIBICION, 0) AS EXHIBICION,

        CONVERT(VARCHAR(100), E.CODARTICULO) AS CODARTICULO

    FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

    LEFT JOIN ACANICARAGUA2.dbo.ARTICULOS A
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), A.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN ACANICARAGUA2.dbo.ALMACEN ALM
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), ALM.CODALMACEN))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) COLLATE DATABASE_DEFAULT

    LEFT JOIN ACANICARAGUA2.dbo.DEPARTAMENTO D
        ON D.NUMDPTO = A.DPTO

    LEFT JOIN ACANICARAGUA2.dbo.SECCIONES SC
        ON SC.NUMDPTO = A.DPTO
       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN ACANICARAGUA2.dbo.FAMILIAS F
        ON F.NUMDPTO = A.DPTO
       AND F.NUMSECCION = A.SECCION
       AND F.NUMFAMILIA = A.FAMILIA

    WHERE E.REGION IN ('NICARAGUA', 'NI')
      AND CONVERT(VARCHAR(50), E.CODALMACEN) LIKE '[0-9][0-9]'
)

SELECT
    REGION,
    CODALMACEN,
    TIENDA,
    CODBARRAS,
    REFERENCIA,
    DESCRIPCION,
    DEPARTAMENTO,
    SECCION,
    FAMILIA,
    PLU,
    UXC,
    EXHIBICION,
    CODARTICULO
FROM DATOS_EXHIBICION
ORDER BY
    REGION,
    CODALMACEN,
    CODARTICULO,
    PLU
";

/*  EJECUTAR CONSULTA
    */
$stmt = sqlsrv_query($sqlsrvConn, $sql, [], [
    'QueryTimeout' => 60,
    'Scrollable' => SQLSRV_CURSOR_FORWARD
]);

if ($stmt === false) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'Error interno al consultar la exhibición.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/*  RESPUESTA JSON PARA POWER BI
    */

echo '[';

$primero = true;
$contador = 0;

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    if (!$primero) {
        echo ',';
    }

    echo json_encode([
        'REGION'       => trim((string)($row['REGION'] ?? '')),
        'CODALMACEN'   => trim((string)($row['CODALMACEN'] ?? '')),
        'TIENDA'       => trim((string)($row['TIENDA'] ?? '')),
        'CODBARRAS'    => trim((string)($row['CODBARRAS'] ?? '')),
        'REFERENCIA'   => trim((string)($row['REFERENCIA'] ?? '')),
        'DESCRIPCION'  => trim((string)($row['DESCRIPCION'] ?? '')),
        'DEPARTAMENTO' => trim((string)($row['DEPARTAMENTO'] ?? '')),
        'SECCION'      => trim((string)($row['SECCION'] ?? '')),
        'FAMILIA'      => trim((string)($row['FAMILIA'] ?? '')),
        'PLU'          => trim((string)($row['PLU'] ?? '')),
        'UXC'          => (float)($row['UXC'] ?? 0),
        'EXHIBICION'   => (float)($row['EXHIBICION'] ?? 0),
        'CODARTICULO'  => trim((string)($row['CODARTICULO'] ?? '')),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $primero = false;
    $contador++;

    if ($contador % 500 === 0) {
        if (function_exists('ob_flush')) {
            @ob_flush();
        }
        flush();
    }
}

echo ']';

/* =CERRAR CONEXIÓN
    */
sqlsrv_free_stmt($stmt);
sqlsrv_close($sqlsrvConn);
exit;