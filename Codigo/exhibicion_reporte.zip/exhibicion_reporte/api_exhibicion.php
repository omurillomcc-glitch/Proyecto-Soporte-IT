<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: api_exhibicion.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - API para Power BI.
| - Mostrar los registros guardados en DT-ESTANDARESEXHIBICION.
| - No perder registros si no cruzan con ARTICULOS.
|--------------------------------------------------------------------------
*/

/* =========================================================
   1) CONFIGURACIÓN GENERAL
   ========================================================= */
error_reporting(0);
ini_set('display_errors', '0');

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/* =========================================================
   2) LIMPIAR BUFFER
   ========================================================= */
while (ob_get_level() > 0) {
    ob_end_clean();
}

/* =========================================================
   3) CABECERAS JSON
   ========================================================= */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

/* =========================================================
   4) VALIDAR TOKEN
   ========================================================= */
$tokenPermitido = 'EXHIBICION_POWERBI_2026';

$headers = getallheaders();
$tokenRecibido = $headers['X-API-KEY'] ?? $headers['x-api-key'] ?? '';

if ($tokenRecibido === '') {
    $tokenUrl = $_GET['token'] ?? '';
    $modoUrl  = $_GET['modo'] ?? '';

    if ($tokenUrl === $tokenPermitido && $modoUrl === 'testing') {
        $tokenRecibido = $tokenPermitido;
    }
}

if ($tokenRecibido !== $tokenPermitido) {
    http_response_code(403);
    echo json_encode([
        'ok' => false,
        'error' => 'No autorizado.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   5) CONEXIÓN SQL SERVER
   ========================================================= */
require_once __DIR__ . '/conexion_sqlsrv.php';

/* =========================================================
   6) CONSULTA PRINCIPAL
   ---------------------------------------------------------
   IMPORTANTE:
   - La base es DT-ESTANDARESEXHIBICION.
   - Se usa LEFT JOIN, no INNER JOIN.
   - Así Power BI ve todos los guardados.
   - Si un artículo no cruza, igual aparece.
   ========================================================= */
$sql = "
WITH DATOS_EXHIBICION AS (

    /* =====================================================
       HONDURAS / DETODO
       ===================================================== */
    SELECT
        E.REGION,
        CONVERT(VARCHAR(50), E.CODALMACEN) AS CODALMACEN,
        ISNULL(ALM.NOMBREALMACEN, '') AS TIENDA,

        ISNULL(E.CODBARRAS, '') AS CODBARRAS,

        ISNULL(A.REFPROVEEDOR, '') AS REFERENCIA,
        ISNULL(A.DESCRIPCION, '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,
        ISNULL(SC.DESCRIPCION, '') AS SECCION,
        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        TRIM(CONVERT(VARCHAR(100), E.PLU)) AS PLU,

        ISNULL(E.UXC, 0) AS UXC,
        ISNULL(E.EXHIBICION, 0) AS EXHIBICION,

        CONVERT(VARCHAR(100), E.CODARTICULO) AS CODARTICULO

    FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

    LEFT JOIN DETODO.dbo.ARTICULOS A
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), A.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN DETODO.dbo.ALMACEN ALM
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), ALM.CODALMACEN))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) COLLATE DATABASE_DEFAULT

    LEFT JOIN DETODO.dbo.DEPARTAMENTO D
        ON D.NUMDPTO = A.DPTO

    LEFT JOIN DETODO.dbo.SECCIONES SC
        ON SC.NUMDPTO = A.DPTO
       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN DETODO.dbo.FAMILIAS F
        ON F.NUMDPTO = A.DPTO
       AND F.NUMSECCION = A.SECCION
       AND F.NUMFAMILIA = A.FAMILIA

    WHERE E.REGION NOT IN ('NICARAGUA', 'NI')
      AND CONVERT(VARCHAR(50), E.CODALMACEN) LIKE '[0-9][0-9]'

    UNION ALL

    /* =====================================================
       NICARAGUA / ACANICARAGUA2
       ===================================================== */
    SELECT
        E.REGION,
        CONVERT(VARCHAR(50), E.CODALMACEN) AS CODALMACEN,
        ISNULL(ALM.NOMBREALMACEN, '') AS TIENDA,

        ISNULL(E.CODBARRAS, '') AS CODBARRAS,

        ISNULL(A.REFPROVEEDOR, '') AS REFERENCIA,
        ISNULL(A.DESCRIPCION, '') AS DESCRIPCION,

        ISNULL(D.DESCRIPCION, '') AS DEPARTAMENTO,
        ISNULL(SC.DESCRIPCION, '') AS SECCION,
        ISNULL(F.DESCRIPCION, '') AS FAMILIA,

        TRIM(CONVERT(VARCHAR(100), E.PLU)) AS PLU,

        ISNULL(E.UXC, 0) AS UXC,
        ISNULL(E.EXHIBICION, 0) AS EXHIBICION,

        CONVERT(VARCHAR(100), E.CODARTICULO) AS CODARTICULO

    FROM vistasMCC.dbo.[DT-ESTANDARESEXHIBICION] E

    LEFT JOIN ACANICARAGUA2.dbo.ARTICULOS A
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), A.CODARTICULO))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODARTICULO))) COLLATE DATABASE_DEFAULT

    LEFT JOIN ACANICARAGUA2.dbo.ALMACEN ALM
        ON LTRIM(RTRIM(CONVERT(VARCHAR(100), ALM.CODALMACEN))) COLLATE DATABASE_DEFAULT
           =
           LTRIM(RTRIM(CONVERT(VARCHAR(100), E.CODALMACEN))) COLLATE DATABASE_DEFAULT

    LEFT JOIN ACANICARAGUA2.dbo.DEPARTAMENTO D
        ON D.NUMDPTO = A.DPTO

    LEFT JOIN ACANICARAGUA2.dbo.SECCIONES SC
        ON SC.NUMDPTO = A.DPTO
       AND SC.NUMSECCION = A.SECCION

    LEFT JOIN ACANICARAGUA2.dbo.FAMILIAS F
        ON F.NUMDPTO = A.DPTO
       AND F.NUMSECCION = A.SECCION
       AND F.NUMFAMILIA = A.FAMILIA

    WHERE E.REGION IN ('NICARAGUA', 'NI')
      AND CONVERT(VARCHAR(50), E.CODALMACEN) LIKE '[0-9][0-9]'
)

SELECT
    REGION,
    CODALMACEN,
    TIENDA,
    CODBARRAS,
    REFERENCIA,
    DESCRIPCION,
    DEPARTAMENTO,
    SECCION,
    FAMILIA,
    PLU,
    UXC,
    EXHIBICION,
    CODARTICULO
FROM DATOS_EXHIBICION
ORDER BY
    REGION,
    CODALMACEN,
    CODARTICULO,
    PLU
";

/* =========================================================
   7) EJECUTAR CONSULTA
   ========================================================= */
$stmt = sqlsrv_query($sqlsrvConn, $sql, [], [
    'QueryTimeout' => 0,
    'Scrollable' => SQLSRV_CURSOR_FORWARD
]);

if ($stmt === false) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'Error interno al consultar la exhibición.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* =========================================================
   8) RESPUESTA JSON PARA POWER BI
   ========================================================= */
echo '[';

$primero = true;
$contador = 0;

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    if (!$primero) {
        echo ',';
    }

    echo json_encode([
        'REGION'       => trim((string)($row['REGION'] ?? '')),
        'CODALMACEN'   => trim((string)($row['CODALMACEN'] ?? '')),
        'TIENDA'       => trim((string)($row['TIENDA'] ?? '')),
        'CODBARRAS'    => trim((string)($row['CODBARRAS'] ?? '')),
        'REFERENCIA'   => trim((string)($row['REFERENCIA'] ?? '')),
        'DESCRIPCION'  => trim((string)($row['DESCRIPCION'] ?? '')),
        'DEPARTAMENTO' => trim((string)($row['DEPARTAMENTO'] ?? '')),
        'SECCION'      => trim((string)($row['SECCION'] ?? '')),
        'FAMILIA'      => trim((string)($row['FAMILIA'] ?? '')),
        'PLU'          => trim((string)($row['PLU'] ?? '')),
        'UXC'          => (float)($row['UXC'] ?? 0),
        'EXHIBICION'   => (float)($row['EXHIBICION'] ?? 0),
        'CODARTICULO'  => trim((string)($row['CODARTICULO'] ?? '')),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $primero = false;
    $contador++;

    if ($contador % 500 === 0) {
        if (function_exists('ob_flush')) {
            @ob_flush();
        }
        flush();
    }
}

echo ']';

/* =========================================================
   9) CERRAR CONEXIÓN
   ========================================================= */
sqlsrv_free_stmt($stmt);
sqlsrv_close($sqlsrvConn);
exit;