<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ARCHIVO: conexion_sqlsrv.php
|--------------------------------------------------------------------------
| OBJETIVO:
| - Conectar la API de exhibición a SQL Server.
| - Esta conexión será usada solo para lectura desde Power BI.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| PASO 1: DATOS DEL SERVIDOR SQL
|--------------------------------------------------------------------------
| Usa aquí los mismos datos que tienes en tu aplicación de exhibición.
|--------------------------------------------------------------------------
*/

$serverName = "10.0.1.157";

// Ejemplos:
// $serverName = "10.0.1.157";
// $serverName = "10.0.1.157\\SQLEXPRESS";

$connectionInfo = [
    "Database" => "vistasMCC",
    "UID" => "DT-Csa",
    "PWD" => "dt.2026#",
    "CharacterSet" => "UTF-8",
    "TrustServerCertificate" => true,
];

/*
|--------------------------------------------------------------------------
| PASO 2: CONECTAR A SQL SERVER
|--------------------------------------------------------------------------
*/

$sqlsrvConn = sqlsrv_connect($serverName, $connectionInfo);

/*
|--------------------------------------------------------------------------
| PASO 3: VALIDAR CONEXIÓN
|--------------------------------------------------------------------------
*/

if ($sqlsrvConn === false) {
    http_response_code(500);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'ok' => false,
        'error' => 'No se pudo conectar a SQL Server.',
        'detalle' => sqlsrv_errors()
    ], JSON_UNESCAPED_UNICODE);

    exit;
}