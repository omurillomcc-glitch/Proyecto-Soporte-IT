

/* =========================================================
   LOCAL STORAGE
========================================================= */

let personas =
    JSON.parse(
        localStorage.getItem(
            'mcc_soporte_personas'
        )
    ) || [];

/* =========================================================
   CAMPOS
========================================================= */

const selectPersona =
    document.getElementById(
        'personaSelect'
    );

const inputNombre =
    document.getElementById(
        'nombre'
    );

const inputTelefono =
    document.getElementById(
        'telefono'
    );

const inputCorreo =
    document.getElementById(
        'correo'
    );

const selectPais =
    document.getElementById(
        'paisTelefono'
    );

const selectNivel =
    document.getElementById(
        'nivel'
    );

/* =========================================================
   AUTOCOMPLETAR
========================================================= */

selectPersona.addEventListener(
    'change',
    function(){

        const opcion =
            this.options[
                this.selectedIndex
            ];

        inputNombre.value =
            opcion.dataset.nombre || '';

        inputTelefono.value =
            opcion.dataset.telefono || '';

        inputCorreo.value =
            opcion.dataset.correo || '';

        if(
            inputTelefono.value.startsWith(
                '+505'
            )
        ){

            selectPais.value = '505';

        }else{

            selectPais.value = '504';

        }

    }
);

/* =========================================================
   VALIDAR NOMBRE
========================================================= */

inputNombre.addEventListener(
    'input',
    function(){

        this.value =
            this.value
            .replace(
                /[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g,
                ''
            )
            .replace(
                /\s{2,}/g,
                ' '
            );

    }
);

/* =========================================================
   TELÉFONO
========================================================= */

inputTelefono.addEventListener(
    'input',
    function(){

        let valor =
            this.value.replace(
                /[^\d]/g,
                ''
            );

        if(
            valor.startsWith('504')
            ||
            valor.startsWith('505')
        ){

            valor =
                valor.substring(3);

        }

        valor =
            valor.substring(0,8);

        if(valor.length > 4){

            valor =
                valor.substring(0,4)
                +
                '-'
                +
                valor.substring(4);

        }

        this.value =
            '+' +
            selectPais.value +
            ' ' +
            valor;

    }
);

/* =========================================================
   CORREO
========================================================= */

inputCorreo.addEventListener(
    'input',
    function(){

        this.value =
            this.value.replace(
                /\s/g,
                ''
            );

    }
);

/* =========================================================
   GUARDAR
========================================================= */

function guardarPersona(){

    const nombre =
        inputNombre.value.trim();

    const telefono =
        inputTelefono.value.trim();

    const correo =
        inputCorreo.value.trim();

    const nivel =
        selectNivel.value;

    if(
        !nombre
        ||
        !telefono
        ||
        !correo
    ){

        alert(
            'Complete todos los campos.'
        );

        return;
    }

    // =========================================================
    // NUEVA VALIDACIÓN: EVITAR DUPLICADOS EN EL MISMO NIVEL
    // =========================================================
    const existeDuplicado = personas.some(
        p => 
            p.nombre.toUpperCase() === nombre.toUpperCase() 
            && 
            String(p.nivel) === String(nivel)
    );

    if (existeDuplicado) {
        // Convierte el valor numérico del nivel a su letra correspondiente para el mensaje
        let letraNivel = 'A';
        if (String(nivel) === '2') letraNivel = 'B';
        if (String(nivel) === '3') letraNivel = 'C';

        alert(
            `¡Error! ${nombre} ya se encuentra registrado en el Nivel ${letraNivel}.`
        );
        
        return; // Detiene la función para que no se guarde el duplicado
    }
    // =========================================================

    personas.push({

        id:Date.now(),

        nombre,
        telefono,
        correo,
        nivel

    });

    localStorage.setItem(
        'mcc_soporte_personas',
        JSON.stringify(personas)
    );

    limpiarFormulario();

    mostrarPersonas();

}


/* =========================================================
   MOSTRAR PERSONAS
========================================================= */

function mostrarPersonas(){

    for(let i = 1; i <= 3; i++){

        const lista =
            document.getElementById(
                'lista' + i
            );

        const contador =
            document.getElementById(
                'count' + i
            );

        lista.innerHTML = '';

        const personasNivel =
            personas.filter(
                p =>
                    String(p.nivel)
                    ===
                    String(i)
            );

        if(
            personasNivel.length === 0
        ){

            lista.innerHTML = `

                <div class="empty">

                    <div class="empty-icon">
                        👥
                    </div>

                    SIN PERSONAL
                    <br>
                    ASIGNADO

                </div>

            `;

        }else{

            personasNivel.forEach(
                function(p){

                    const div =
                        document.createElement(
                            'div'
                        );

                    div.className =
                        'person';

                    div.innerHTML = `

                        <div class="person-name">
                            ${escaparHTML(
                                p.nombre
                            )}
                        </div>

                        <div class="person-phone">
                            <i class="bi bi-telephone-fill"></i>
                            ${escaparHTML(
                                p.telefono
                            )}
                        </div>

                        <div class="person-mail">
                            <i class="bi bi-envelope-fill"></i>
                            ${escaparHTML(
                                p.correo
                            )}
                        </div>

                        <div class="no-captura">

                            <button
                                class="btn-eliminar"
                                onclick="eliminarPersona(${p.id})"
                            >
                                Eliminar
                            </button>

                        </div>

                    `;

                    lista.appendChild(div);

                }
            );

        }

        contador.textContent =

            personasNivel.length

            +

            (
                personasNivel.length === 1
                ?
                ' CONTACTO'
                :
                ' CONTACTOS'
            );

    }

}

/* =========================================================
   ELIMINAR
========================================================= */

function eliminarPersona(id){

    personas =
        personas.filter(
            p => p.id !== id
        );

    localStorage.setItem(
        'mcc_soporte_personas',
        JSON.stringify(personas)
    );

    mostrarPersonas();

}

/* =========================================================
   LIMPIAR FORMULARIO
========================================================= */

function limpiarFormulario(){

    selectPersona.value = '';

    inputNombre.value = '';

    inputTelefono.value = '';

    inputCorreo.value = '';

    selectPais.value = '504';

    selectNivel.value = '1';

}

/* =========================================================
   LIMPIAR TODO
========================================================= */

function limpiarTodo(){

    if(
        confirm(
            '¿Desea eliminar todos los contactos?'
        )
    ){

        personas = [];

        localStorage.setItem(
            'mcc_soporte_personas',
            JSON.stringify(personas)
        );

        mostrarPersonas();

        limpiarFormulario();

    }

}

/* =========================================================
   DESCARGAR PNG
========================================================= */

function descargarPNG(){

    const poster =
        document.getElementById(
            'poster'
        );

    html2canvas(
        poster,
        {

            scale:2,

            useCORS:true,

            backgroundColor:null,

            ignoreElements:
                function(element){

                    return element.classList.contains(
                        'no-captura'
                    );

                }

        }

    ).then(function(canvas){

        const enlace =
            document.createElement(
                'a'
            );

        enlace.download =
            'soporte-mcc.png';

        enlace.href =
            canvas.toDataURL(
                'image/png'
            );

        enlace.click();

    });

}

/* =========================================================
   SEGURIDAD HTML
========================================================= */

function escaparHTML(texto){

    return String(texto)

        .replaceAll(
            '&',
            '&amp;'
        )

        .replaceAll(
            '<',
            '&lt;'
        )

        .replaceAll(
            '>',
            '&gt;'
        )

        .replaceAll(
            '"',
            '&quot;'
        )

        .replaceAll(
            "'",
            '&#039;'
        );

}

/* =========================================================
   CARGAR
========================================================= */

mostrarPersonas();
