<?php
require_once __DIR__ . '/usuarios/validar_sesion.php';

cerrar_sesion();
header('Location: /app_descuento/usuarios/login.html?logout=1', true, 303);
exit;
