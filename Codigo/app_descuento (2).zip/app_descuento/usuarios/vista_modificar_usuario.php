<?php
/* ARCHIVO: vista_modificar_usuario.php */

/* VALIDAR SESIÓN */
require_once __DIR__ . "/validar_sesion.php";

/* VALIDAR PERMISO */
$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para modificar usuarios.</div>';
    exit;
}
?>

<link rel="stylesheet" href="/app_descuento/usuarios/CSS/agregar_usuario.css">

<link rel="stylesheet" href="/app_descuento/usuarios/CSS/modificar_usuario.css">

<!-- CONTENIDO PRINCIPAL -->
<div class="section-wrap">

    <!-- ENCABEZADO -->
    <div class="section-head-card">
        <div class="section-head d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-pencil-square me-2"></i>Modificar usuario
                </h4>

                <p class="section-sub">
                    Edita usuario, nombre, rol y contraseña opcional.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-shield-lock"></i> Solo Admin
            </span>
        </div>
    </div>

    <!-- CARD PRINCIPAL -->
    <div class="card section-card mt-3">
        <div class="card-body">

            <!-- BUSCADOR -->
            <div class="section-divider">
                <i class="bi bi-search me-2"></i>Buscar
            </div>

            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Buscar por usuario o nombre</label>

                    <input
                        id="txtBuscar"
                        type="text"
                        class="form-control"
                        placeholder="Escriba para buscar..."
                    >
                </div>
            </div>

            <!-- MENSAJE -->
            <div id="msgList" class="mt-3"></div>

            <!-- TABLA -->
            <div class="table-responsive mt-3">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Rol</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>

                    <tbody id="tbodyUsuarios">
                        <tr>
                            <td colspan="5" class="text-muted">Cargando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN -->
            <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">

                <div class="text-muted small" id="lblPagerInfo"></div>

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <select id="selLimit" class="form-select">
                        <option value="100" selected>100 por página</option>
                        <option value="150">150 por página</option>
                        <option value="200">200 por página</option>
                    </select>

                    <nav>
                        <ul class="pagination mb-0" id="pagination"></ul>
                    </nav>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- MODAL EDITAR -->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-person-gear me-2"></i>Editar usuario
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="formEditar" autocomplete="off">

                    <input type="hidden" name="id" id="editId">

                    <div class="row g-3">

                        <!-- ID -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">ID</label>

                            <input
                                type="text"
                                class="form-control"
                                id="editIdShow"
                                readonly
                            >
                        </div>

                        <!-- USUARIO -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Usuario</label>

                            <input
                                type="text"
                                class="form-control"
                                name="usuario"
                                id="editUsuario"
                                maxlength="30"
                                required
                            >

                            <div class="form-hint">
                                Solo letras. Debe ser único.
                            </div>
                        </div>

                        <!-- NOMBRE -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Nombre</label>

                            <input
                                type="text"
                                class="form-control"
                                name="nombre"
                                id="editNombre"
                                maxlength="100"
                                required
                            >

                            <div class="form-hint">
                                Solo letras y espacios.
                            </div>
                        </div>

                        <!-- ROL -->
                        <div class="col-12 col-md-6">
                            <label class="form-label">Rol</label>

                            <select class="form-select" name="rol" id="editRol" required>
                                <option value="usuario">Usuario</option>
                                <option value="admin">Administrador</option>
                            </select>
                        </div>

                        <!-- CONTRASEÑA -->
                        <div class="col-12">
                            <label class="form-label">Nueva contraseña opcional</label>

                            <div class="input-group">
                                <input
                                    type="password"
                                    class="form-control"
                                    name="password"
                                    id="editPass"
                                    placeholder="Deja vacío para no cambiar"
                                >

                                <button
                                    class="btn btn-outline-secondary"
                                    type="button"
                                    id="btnTogglePass"
                                >
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>

                            <div class="form-hint">
                                Si la llenas: mínimo 6 caracteres. Letras, números y punto.
                            </div>
                        </div>

                    </div>

                    <!-- MENSAJE MODAL -->
                    <div id="msgEdit" class="mt-3"></div>

                </form>
            </div>

            <div class="modal-footer">
                <button class="btn btn-soft" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>

                <button class="btn btn-main" form="formEditar" type="submit">
                    <i class="bi bi-check2-circle me-1"></i> Guardar cambios
                </button>
            </div>

        </div>
    </div>
</div>

<script src="/app_descuento/usuarios/JS/modificar_usuario.js"></script>