<?php
header('Content-Type: application/json; charset=utf-8');
/* INICIAR SESIÓN */
require_once __DIR__ . '/validar_sesion.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    echo json_encode(['ok' => true, 'csrf_token' => csrf_token()], JSON_UNESCAPED_UNICODE);
    exit;
}


require_once __DIR__ . "/conexion.php";

/* RESPUESTA INICIAL */
$response = [
    "ok"  => false,
    "msg" => ""
];


/* FUNCIÓN PARA REGISTRAR AUDITORÍA */
function registrar_auditoria(mysqli $conn, int $usuario_id, string $accion, string $detalle): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    $stmt = $conn->prepare(
        "INSERT INTO auditoria (usuario_id, accion, detalle, ip)
         VALUES (?, ?, ?, ?)"
    );

    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $accion, $detalle, $ip);
        $stmt->execute();
        $stmt->close();
    }
}


/* PROCESO PRINCIPAL DEL LOGIN */
try {

    /* Validar que la petición sea POST */
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método no permitido.");
    }


    /* Recibir usuario y contraseña */
    $usuario  = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');


    /* Validar campos vacíos */
    if ($usuario === "" || $password === "") {
        throw new Exception("Usuario y contraseña son obligatorios.");
    }


    /* Validar largo máximo del usuario */
    if (mb_strlen($usuario, 'UTF-8') > 30) {
        throw new Exception("El usuario no puede tener más de 30 letras.");
    }


    /* Validar que el usuario solo tenga letras */
    if (!preg_match('/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$/u', $usuario)) {
        throw new Exception("El usuario solo puede contener letras.");
    }


    /* Validar mínimo de contraseña */
    if (strlen($password) < 6) {
        throw new Exception("Usuario o contraseña incorrectos.");
    }


    /* Buscar usuario en la base de datos */
    $stmt = $conn->prepare(
        "SELECT id, usuario, password, nombre, rol, estado, intentos, bloqueado_hasta,
                (bloqueado_hasta IS NOT NULL AND bloqueado_hasta > NOW()) AS bloqueo_activo,
                GREATEST(1, CEIL(TIMESTAMPDIFF(SECOND, NOW(), bloqueado_hasta) / 60)) AS minutos_bloqueo
         FROM usuarios
         WHERE usuario = ?
         LIMIT 1"
    );

    if (!$stmt) {
        throw new Exception("Error preparando consulta.");
    }

    $stmt->bind_param("s", $usuario);
    $stmt->execute();

    $result = $stmt->get_result();


    /* Validar si el usuario existe */
    if (!$result || $result->num_rows === 0) {
        $stmt->close();
        throw new Exception("Usuario o contraseña incorrectos.");
    }


    /* Obtener datos del usuario */
    $row = $result->fetch_assoc();
    $stmt->close();

    $userId = (int)$row['id'];

    if ((int)$row['bloqueo_activo'] === 1) {
        throw new Exception(
            "Cuenta temporalmente bloqueada. Intente nuevamente en "
            . (int)$row['minutos_bloqueo'] . " minutos."
        );
    }

    if (!empty($row['bloqueado_hasta'])) {
        $stmt = $conn->prepare(
            "UPDATE usuarios SET intentos = 0, bloqueado_hasta = NULL WHERE id = ?"
        );
        if (!$stmt) {
            throw new Exception("No se pudo actualizar el estado de intentos.");
        }
        $stmt->bind_param("i", $userId);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new Exception("No se pudo actualizar el estado de intentos.");
        }
        $stmt->close();
    }


    /* Validar si el usuario está bloqueado */
    if ($row['estado'] === 'bloqueado') {
        registrar_auditoria(
            $conn,
            $userId,
            "LOGIN_BLOQUEADO",
            "Intento de login con usuario bloqueado: {$row['usuario']}"
        );

        throw new Exception("Usuario bloqueado. Contacte al administrador.");
    }


    /* Validar contraseña encriptada */
    if (!password_verify($password, $row['password'])) {
        $stmt = $conn->prepare(
            "UPDATE usuarios
             SET intentos = intentos + 1,
                 bloqueado_hasta = CASE
                     WHEN intentos + 1 >= 3 THEN DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                     ELSE NULL
                 END
             WHERE id = ?"
        );
        if (!$stmt) {
            throw new Exception("No se pudo registrar el intento de inicio de sesión.");
        }
        $stmt->bind_param("i", $userId);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new Exception("No se pudo registrar el intento de inicio de sesión.");
        }
        $stmt->close();

        $stmt = $conn->prepare(
            "SELECT intentos, (bloqueado_hasta > NOW()) AS bloqueo_activo
             FROM usuarios WHERE id = ? LIMIT 1"
        );
        if (!$stmt) {
            throw new Exception("No se pudo verificar el bloqueo temporal.");
        }
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $estadoIntentos = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        registrar_auditoria(
            $conn,
            $userId,
            "LOGIN_FAIL",
            "Contraseña incorrecta para usuario: {$row['usuario']}"
        );

        if ($estadoIntentos && (int)$estadoIntentos['bloqueo_activo'] === 1) {
            throw new Exception("Cuenta bloqueada por 15 minutos tras 3 intentos fallidos.");
        }
        throw new Exception("Usuario o contraseña incorrectos.");
    }

    $stmt = $conn->prepare(
        "UPDATE usuarios SET intentos = 0, bloqueado_hasta = NULL WHERE id = ?"
    );
    if (!$stmt) {
        throw new Exception("No se pudo restablecer el contador de intentos.");
    }
    $stmt->bind_param("i", $userId);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new Exception("No se pudo restablecer el contador de intentos.");
    }
    $stmt->close();


    /* Regenerar ID de sesión por seguridad */
    session_regenerate_id(true);


    /* Guardar datos del usuario en sesión */
    $_SESSION['usuario_id'] = $userId;
    $_SESSION['usuario']    = $row['usuario'];
    $_SESSION['nombre']     = $row['nombre'];
    $_SESSION['rol']        = $row['rol'];


    /* Guardar tiempo de sesión */
  $_SESSION['CREATED'] = time();
  $_SESSION['LAST_ACTIVITY'] = time();


    /* Registrar login correcto en auditoría */
    registrar_auditoria(
        $conn,
        $userId,
        "LOGIN_OK",
        "Inicio de sesión correcto: {$row['usuario']}"
    );


    /* Respuesta correcta al frontend */
    $response["ok"]  = true;
    $response["msg"] = "Login correcto.";


} catch (Exception $e) {

    /* Respuesta si ocurre error */
    $response["msg"] = ($e instanceof mysqli_sql_exception ? 'No se pudo completar la solicitud.' : $e->getMessage());
}


/* DEVOLVER RESPUESTA JSON */
echo json_encode($response);