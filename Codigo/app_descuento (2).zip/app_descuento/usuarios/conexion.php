<?php

/* Credenciales almacenadas fuera de la carpeta pública del proyecto. */
$archivoCredenciales = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR
    . 'privado_descuento' . DIRECTORY_SEPARATOR . 'credenciales.php';

$credenciales = require $archivoCredenciales;
$mysql = $credenciales['mysql'] ?? null;

if (!is_array($mysql)) {
    $conn = null;
    return;
}

$conn = new mysqli(
    (string) $mysql['host'],
    (string) $mysql['usuario'],
    (string) $mysql['clave'],
    (string) $mysql['base']
);

if ($conn->connect_error) {
    $conn = null;
    return;
}

$conn->set_charset("utf8mb4");