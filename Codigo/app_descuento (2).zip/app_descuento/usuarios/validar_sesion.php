<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');

if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: frame-ancestors 'none'; base-uri 'self'; object-src 'none'");
    header('Cache-Control: private, no-store, max-age=0');
}

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    ini_set('session.cookie_httponly', '1');
    session_name('APP_DESCUENTO');
    $https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

if (session_status() === PHP_SESSION_ACTIVE) {
    $now = time();
    if (empty($_SESSION['APP_ROTATED_AT']) || $now - (int)$_SESSION['APP_ROTATED_AT'] >= 300) {
        session_regenerate_id(true);
        $_SESSION['APP_ROTATED_AT'] = $now;
    }
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function cerrar_sesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 3600,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

function require_login(): void
{
    if (empty($_SESSION['usuario_id'])) {
        header('Location: /app_descuento/usuarios/login.html', true, 303);
        exit;
    }
    $now = time();
    $created = (int)($_SESSION['CREATED'] ?? 0);
    $activity = (int)($_SESSION['LAST_ACTIVITY'] ?? $created);
    if ($created <= 0 || $now - $created > 28800 || ($activity > 0 && $now - $activity > 3600)) {
        cerrar_sesion();
        header('Location: /app_descuento/usuarios/login.html?expired=1', true, 303);
        exit;
    }
    $_SESSION['LAST_ACTIVITY'] = $now;
}

function require_admin(): void
{
    require_login();
    if (!in_array((string)($_SESSION['rol'] ?? ''), ['admin'], true)) {
        http_response_code(403);
        exit('Acceso denegado.');
    }
}

function csrf_token(): string
{
    return (string)($_SESSION['csrf_token'] ?? '');
}

function origen_confiable(string $url): bool
{
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) {
        return false;
    }
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    $originHost = strtolower((string)$parts['host']);
    $originPort = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    return hash_equals($host, $originHost . $originPort)
        || (isset($parts['port']) === false && hash_equals($host, $originHost));
}

function proteger_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return;
    }
    $fetchSite = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
    if (in_array($fetchSite, ['cross-site', 'none'], true)) {
        http_response_code(403);
        exit('Solicitud no autorizada.');
    }
    $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if (($origin !== '' && !origen_confiable($origin))
        || ($origin === '' && ($referer === '' || !origen_confiable($referer)))) {
        http_response_code(403);
        exit('Solicitud no autorizada.');
    }
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($token) || $token === '' || !hash_equals(csrf_token(), $token)) {
        http_response_code(403);
        exit('La solicitud expiró o no es válida.');
    }
}

proteger_post();
$scriptName = strtolower(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')));
if (!in_array($scriptName, ['login.php', 'logout.php'], true)) {
    require_login();
}
