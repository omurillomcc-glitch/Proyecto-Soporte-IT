<?php



require_once __DIR__ . "/validar_sesion.php";


$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para agregar usuarios.</div>';
    exit;
}
?>


<link rel="stylesheet" href="/app_descuento/usuarios/CSS/agregar_usuario.css">


<div class="section-wrap">

    <!-- HEADER COMO CARD -->
    <div class="section-head-card">
        <div class="section-head">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-person-plus me-2"></i>Agregar usuario
                </h4>

                <p class="section-sub">
                    Crea usuarios para el sistema y asigna su rol.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-gear-fill"></i> Configuración
            </span>
        </div>
    </div>

    <!-- CARD DEL FORMULARIO -->
    <div class="card section-card mt-3">
        <div class="card-body section-card-body">

            <div class="section-divider">Datos del usuario</div>

            <form id="formAgregarUsuario" autocomplete="off">
                <div class="row g-3">

                    <!-- USUARIO -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Usuario</label>

                        <input
                            type="text"
                            class="form-control"
                            name="usuario"
                            maxlength="30"
                            required
                        >

                        <div class="form-hint">
                            Solo letras, máximo 30 caracteres.
                        </div>
                    </div>

                    <!-- NOMBRE COMPLETO -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Nombre completo</label>

                        <input
                            type="text"
                            class="form-control"
                            name="nombre"
                            maxlength="60"
                            required
                        >

                        <div class="form-hint">
                            Solo letras y espacios.
                        </div>
                    </div>

                    <!-- CONTRASEÑA -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Contraseña</label>

                        <div class="input-group">
                            <input
                                type="password"
                                class="form-control"
                                name="password"
                                maxlength="20"
                                required
                            >

                            <button
                                class="btn btn-outline-secondary"
                                type="button"
                                id="btnTogglePass"
                                aria-label="Ver contraseña"
                            >
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>

                        <div class="form-hint">
                            Mínimo 6 caracteres. Letras, números y punto.
                        </div>
                    </div>

                    <!-- ROL -->
                    <div class="col-12 col-md-6">
                        <label class="form-label">Rol</label>

                        <select class="form-select" name="rol" required>
                            <option value="usuario" selected>Usuario</option>
                            <option value="admin">Administrador</option>
                        </select>

                        <div class="form-hint">
                            Define permisos del usuario.
                        </div>
                    </div>

                </div>

                <!-- BOTONES -->
                <div class="section-actions mt-4">
                    <button type="submit" class="btn btn-main">
                        <i class="bi bi-check2-circle me-1"></i> Guardar
                    </button>

                    <button type="reset" class="btn btn-soft">
                        <i class="bi bi-x-circle me-1"></i> Cancelar
                    </button>
                </div>

                <!-- MENSAJE -->
                <div id="msgAddUser" class="mt-3"></div>

            </form>

        </div>
    </div>

</div>

<script src="/app_descuento/usuarios/JS/agregar_usuario.js"></script>