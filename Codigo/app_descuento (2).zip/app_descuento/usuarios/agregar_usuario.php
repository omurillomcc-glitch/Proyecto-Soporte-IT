<?php

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . '/validar_sesion.php';

require_once __DIR__. "/conexion.php";


$response = [
    "ok"  => false,
    "msg" => ""
];

try {

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        throw new Exception("Método no permitido.");
    }

    if (!isset($_SESSION["usuario_id"]) || !isset($_SESSION["rol"])) {
        throw new Exception("No autorizado. Inicia sesión.");
    }

    if ($_SESSION["rol"] !== "admin") {
        throw new Exception("No autorizado. Solo administradores pueden agregar usuarios.");
    }

    $admin_id = (int)$_SESSION["usuario_id"];

    $usuario  = trim($_POST["usuario"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $nombre   = trim($_POST["nombre"] ?? "");
    $rol      = trim($_POST["rol"] ?? "usuario");

    if ($usuario === "" || $password === "" || $nombre === "") {
        throw new Exception("Todos los campos son obligatorios.");
    }

    if (mb_strlen($usuario, "UTF-8") > 30) {
        throw new Exception("El usuario no puede tener más de 30 letras.");
    }

    if (!preg_match("/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+$/u", $usuario)) {
        throw new Exception("El usuario solo puede contener letras.");
    }

    $nombre = preg_replace('/\s+/', ' ', $nombre);

    if (!preg_match("/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]+$/u", $nombre)) {
        throw new Exception("El nombre solo puede contener letras y espacios.");
    }

    if (strlen($password) < 6) {
        throw new Exception("La contraseña debe tener al menos 6 caracteres.");
    }

    if (!preg_match("/^[A-Za-z0-9.]+$/", $password)) {
        throw new Exception("La contraseña solo puede contener letras, números y punto (.)");
    }

    if ($rol !== "admin" && $rol !== "usuario") {
        throw new Exception("Rol inválido.");
    }

    $stmt = $conn->prepare("
        SELECT id 
        FROM usuarios 
        WHERE usuario = ? 
        LIMIT 1
    ");

    if (!$stmt) {
        throw new Exception("Error preparando consulta.");
    }

    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->close();
        throw new Exception("El usuario ya existe.");
    }

    $stmt->close();

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    $conn->begin_transaction();

    $stmt = $conn->prepare("
        INSERT INTO usuarios 
            (usuario, password, nombre, rol) 
        VALUES 
            (?, ?, ?, ?)
    ");

    if (!$stmt) {
        $conn->rollback();
        throw new Exception("Error preparando inserción.");
    }

    $stmt->bind_param(
        "ssss",
        $usuario,
        $passwordHash,
        $nombre,
        $rol
    );

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        throw new Exception("Error al guardar el usuario.");
    }

    $nuevoUsuarioId = (int)$conn->insert_id;

    $stmt->close();

    $accion = "USUARIO_AGREGADO";

    $detalle = "USUARIO={$usuario} | ID={$nuevoUsuarioId} | NOMBRE={$nombre} | ROL={$rol}";

    $ip = $_SERVER["REMOTE_ADDR"] ?? null;

    $stmt = $conn->prepare("
        INSERT INTO auditoria
            (usuario_id, accion, detalle, ip)
        VALUES
            (?, ?, ?, ?)
    ");

    if (!$stmt) {
        $conn->rollback();
        throw new Exception("Usuario creado, pero falló auditoría.");
    }

    $stmt->bind_param(
        "isss",
        $admin_id,
        $accion,
        $detalle,
        $ip
    );

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        throw new Exception("Usuario creado, pero falló auditoría.");
    }

    $stmt->close();

    $conn->commit();

    $response["ok"] = true;
    $response["msg"] = "Usuario agregado correctamente.";

} catch (Exception $e) {

    if (isset($conn) && $conn instanceof mysqli) {
        @ $conn->rollback();
    }

    $response["msg"] = ($e instanceof mysqli_sql_exception ? 'No se pudo completar la solicitud.' : $e->getMessage());
}

echo json_encode(
    $response,
    JSON_UNESCAPED_UNICODE
);