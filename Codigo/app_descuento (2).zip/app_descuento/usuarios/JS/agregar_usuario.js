var _0xb473b71a1c59=["Zm9ybUFncmVnYXJVc3Vhcmlv","bXNnQWRkVXNlcg==","YnRuVG9nZ2xlUGFzcw==","aW5wdXRbbmFtZT0icGFzc3dvcmQiXQ==","aW5wdXRbbmFtZT0idXN1YXJpbyJd","aW5wdXRbbmFtZT0ibm9tYnJlIl0=","YnV0dG9uW3R5cGU9InN1Ym1pdCJd","YnV0dG9uW3R5cGU9InJlc2V0Il0=","aW5wdXQ=","","Y2xpY2s=","cGFzc3dvcmQ=","dGV4dA==","PGkgY2xhc3M9ImJpIGJpLWV5ZS1zbGFzaCI+PC9pPg==","PGkgY2xhc3M9ImJpIGJpLWV5ZSI+PC9pPg==","c3VibWl0","TGEgY29udHJhc2XDsWEgZGViZSB0ZW5lciBtw61uaW1vIDYgY2FyYWN0ZXJlcy4=","ZGFuZ2Vy","PHNwYW4gY2xhc3M9InNwaW5uZXItYm9yZGVyIHNwaW5uZXItYm9yZGVyLXNtIG1lLTIiPjwvc3Bhbj5HdWFyZGFuZG8uLi4=","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3MvYWdyZWdhcl91c3VhcmlvLnBocA==","UE9TVA==","c2FtZS1vcmlnaW4=","VXN1YXJpbyBhZ3JlZ2FkbyBjb3JyZWN0YW1lbnRlLg==","c3VjY2Vzcw==","Tm8gc2UgcHVkbyBndWFyZGFyIGVsIHVzdWFyaW8u","Tm8gc2UgcHVkbyBjb25lY3RhciBjb24gZWwgc2Vydmlkb3Iu","YmktY2hlY2stY2lyY2xl","YmktZXhjbGFtYXRpb24tdHJpYW5nbGU="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(function () {
    const form = document.getElementById(_0xb473b71a1c59[0]);
    if (!form) {
        return;
    }
    const msg = document.getElementById(_0xb473b71a1c59[1]);
    const toggle = document.getElementById(_0xb473b71a1c59[2]);
    const passInput = form.querySelector(_0xb473b71a1c59[3]);
    const inputUsuario = form.querySelector(_0xb473b71a1c59[4]);
    const inputNombre = form.querySelector(_0xb473b71a1c59[5]);
    const btnSubmit = form.querySelector(_0xb473b71a1c59[6]);
    const btnReset = form.querySelector(_0xb473b71a1c59[7]);
    inputUsuario.addEventListener(_0xb473b71a1c59[8], function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, _0xb473b71a1c59[9]);
    });
    inputNombre.addEventListener(_0xb473b71a1c59[8], function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]/g, _0xb473b71a1c59[9]);
    });
    passInput.addEventListener(_0xb473b71a1c59[8], function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, _0xb473b71a1c59[9]);
    });
    toggle.addEventListener(_0xb473b71a1c59[10], function () {
        const isPass = passInput.type === _0xb473b71a1c59[11];
        passInput.type = isPass ? _0xb473b71a1c59[12] : _0xb473b71a1c59[11];
        toggle.innerHTML = isPass
            ? _0xb473b71a1c59[13] : _0xb473b71a1c59[14];
    });
    form.addEventListener(_0xb473b71a1c59[15], async function (e) {
        e.preventDefault();
        msg.innerHTML = _0xb473b71a1c59[9];
        if ((passInput.value || _0xb473b71a1c59[9]).length < 6) {
            showMessage(_0xb473b71a1c59[16], _0xb473b71a1c59[17]);
            return;
        }
        const originalBtn = btnSubmit.innerHTML;
        try {
            btnSubmit.disabled = true;
            btnReset.disabled = true;
            btnSubmit.innerHTML = _0xb473b71a1c59[18];
            const fd = new FormData(form);
            const res = await fetch(_0xb473b71a1c59[19], {
                method: _0xb473b71a1c59[20],
                body: fd,
                credentials: _0xb473b71a1c59[21]
            });
            const data = await res.json();
            if (data.ok) {
                showMessage(data.msg || _0xb473b71a1c59[22], _0xb473b71a1c59[23]);
                form.reset();
                inputUsuario.focus();
            }
            else {
                showMessage(data.msg || _0xb473b71a1c59[24], _0xb473b71a1c59[17]);
            }
        }
        catch (err) {
            showMessage(_0xb473b71a1c59[25], _0xb473b71a1c59[17]);
        }
        finally {
            btnSubmit.disabled = false;
            btnReset.disabled = false;
            btnSubmit.innerHTML = originalBtn;
        }
    });
    function showMessage(text, type) {
        msg.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0 fade show">
                <i class="bi ${type === _0xb473b71a1c59[23]
            ? _0xb473b71a1c59[26] : _0xb473b71a1c59[27]} me-1"></i>
                ${text}
            </div>
        `;
        if (type === _0xb473b71a1c59[23]) {
            setTimeout(() => {
                msg.innerHTML = _0xb473b71a1c59[9];
            }, 4000);
        }
    }
})();
