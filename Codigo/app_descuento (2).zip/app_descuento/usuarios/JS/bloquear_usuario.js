var _0x5c98eb4bec49=["dGJvZHlVc3Vhcmlvcw==","dHh0QnVzY2Fy","bXNnTGlzdA==","c2VsTGltaXQ=","bGJsUGFnZXJJbmZv","cGFnaW5hdGlvbg==","bW9kYWxDb25maXJt","Y29uZmlybVRleHQ=","bXNnQ29uZmlybQ==","YnRuQ29uZmlybQ==","MTAw","aW5wdXQ=","Y2hhbmdl","Y2xpY2s=","","bm8tc3RvcmU=","c2FtZS1vcmlnaW4=","ZGFuZ2Vy","YmxvcXVlYWRv","MA==","aW5hY3Rpdm8=","YnV0dG9uW2RhdGEtaWRd","ZGF0YS1pZA==","ZGF0YS1hY3Q=","YmxvcXVlYXI=","aWQ=","YWNjaW9u","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3MvYmxvcXVlYXJfdXN1YXJpby5waHA/YWN0aW9uPXRvZ2dsZQ==","UE9TVA==","c3VjY2Vzcw==","QWN0dWFsaXphZG8gY29ycmVjdGFtZW50ZS4=","Tm8gc2UgcHVkbyBhY3R1YWxpemFyLg==","Tm8gc2UgcHVkbyBjb25lY3RhciBjb24gZWwgc2Vydmlkb3Iu","wqs=","MQ==","wrs=","bGk=","ZGlzYWJsZWQ=","YWN0aXZl","YQ==","cGFnZS1saW5r","Iw==","cGFnZS1pdGVtIGRpc2FibGVk","c3Bhbg==","Li4u","YmktY2hlY2stY2lyY2xl","YmktZXhjbGFtYXRpb24tdHJpYW5nbGU=","Jg==","JmFtcDs=","PA==","Jmx0Ow==","Pg==","Jmd0Ow==","Ig==","JnF1b3Q7","Jw==","JiMwMzk7"].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(function () {
    const tbody = document.getElementById(_0x5c98eb4bec49[0]);
    const txtBuscar = document.getElementById(_0x5c98eb4bec49[1]);
    const msgList = document.getElementById(_0x5c98eb4bec49[2]);
    const selLimit = document.getElementById(_0x5c98eb4bec49[3]);
    const lblPagerInfo = document.getElementById(_0x5c98eb4bec49[4]);
    const pagination = document.getElementById(_0x5c98eb4bec49[5]);
    const modalConfirmEl = document.getElementById(_0x5c98eb4bec49[6]);
    const confirmText = document.getElementById(_0x5c98eb4bec49[7]);
    const msgConfirm = document.getElementById(_0x5c98eb4bec49[8]);
    const btnConfirm = document.getElementById(_0x5c98eb4bec49[9]);
    if (!tbody || !txtBuscar || !modalConfirmEl) {
        return;
    }
    const modalConfirm = new bootstrap.Modal(modalConfirmEl);
    let cacheUsuarios = [];
    let page = 1;
    let limit = parseInt(selLimit.value || _0x5c98eb4bec49[10], 10);
    let pendingId = null;
    let pendingAccion = null;
    let timerBusqueda = null;
    txtBuscar.addEventListener(_0x5c98eb4bec49[11], function () {
        clearTimeout(timerBusqueda);
        timerBusqueda = setTimeout(function () {
            page = 1;
            cargarUsuarios();
        }, 250);
    });
    selLimit.addEventListener(_0x5c98eb4bec49[12], function () {
        limit = parseInt(selLimit.value || _0x5c98eb4bec49[10], 10);
        page = 1;
        cargarUsuarios();
    });
    btnConfirm.addEventListener(_0x5c98eb4bec49[13], async function () {
        if (!pendingId || !pendingAccion) {
            return;
        }
        await toggleEstado(pendingId, pendingAccion);
    });
    async function cargarUsuarios() {
        msgList.innerHTML = _0x5c98eb4bec49[14];
        lblPagerInfo.textContent = _0x5c98eb4bec49[14];
        pagination.innerHTML = _0x5c98eb4bec49[14];
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-muted">Cargando...</td>
            </tr>
        `;
        try {
            const q = encodeURIComponent((txtBuscar.value || _0x5c98eb4bec49[14]).trim());
            const url = `/app_descuento/usuarios/bloquear_usuario.php?action=list&page=${page}&limit=${limit}&q=${q}`;
            const res = await fetch(url, {
                cache: _0x5c98eb4bec49[15],
                credentials: _0x5c98eb4bec49[16]
            });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error(data.msg || `HTTP ${res.status}`);
            }
            cacheUsuarios = data.usuarios || [];
            const total = parseInt(data.total || 0, 10);
            const pages = parseInt(data.pages || 1, 10);
            if (page > pages) {
                page = pages;
            }
            const from = total === 0 ? 0 : ((page - 1) * limit + 1);
            const to = Math.min(page * limit, total);
            lblPagerInfo.textContent =
                `Mostrando ${from}-${to} de ${total} (página ${page} de ${pages})`;
            renderTabla();
            renderPaginacion(pages);
        }
        catch (e) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-danger">No se pudo cargar.</td>
                </tr>
            `;
            showAlert(msgList, _0x5c98eb4bec49[17], e.message);
        }
    }
    function renderTabla() {
        if (cacheUsuarios.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-muted">Sin resultados.</td>
                </tr>
            `;
            return;
        }
        tbody.innerHTML = cacheUsuarios.map(function (u) {
            const estadoTexto = String(u.estado || _0x5c98eb4bec49[14]).toLowerCase();
            const esBloqueado = estadoTexto === _0x5c98eb4bec49[18] ||
                estadoTexto === _0x5c98eb4bec49[19] ||
                estadoTexto === _0x5c98eb4bec49[20];
            const badgeEstado = esBloqueado
                ? `
                    <span class="estado-badge estado-bloqueado">
                        <i class="bi bi-lock-fill"></i> Bloqueado
                    </span>
                `
                : `
                    <span class="estado-badge estado-activo">
                        <i class="bi bi-check-circle-fill"></i> Activo
                    </span>
                `;
            const btnAccion = esBloqueado
                ? `
                    <button class="btn btn-soft btn-action btn-sm" data-id="${u.id}" data-act="desbloquear">
                        <i class="bi bi-unlock-fill me-1"></i> Desbloquear
                    </button>
                `
                : `
                    <button class="btn btn-main btn-action btn-sm" data-id="${u.id}" data-act="bloquear">
                        <i class="bi bi-lock-fill me-1"></i> Bloquear
                    </button>
                `;
            return `
                <tr>
                    <td class="fw-semibold">${escapeHtml(u.id)}</td>
                    <td class="fw-semibold">${escapeHtml(u.usuario)}</td>
                    <td>${escapeHtml(u.nombre)}</td>
                    <td>${escapeHtml(u.rol)}</td>
                    <td>${badgeEstado}</td>
                    <td class="text-end">${btnAccion}</td>
                </tr>
            `;
        }).join(_0x5c98eb4bec49[14]);
        tbody.querySelectorAll(_0x5c98eb4bec49[21]).forEach(function (btn) {
            btn.addEventListener(_0x5c98eb4bec49[13], function () {
                const id = btn.getAttribute(_0x5c98eb4bec49[22]);
                const accion = btn.getAttribute(_0x5c98eb4bec49[23]);
                abrirConfirmacion(id, accion);
            });
        });
    }
    function abrirConfirmacion(id, accion) {
        pendingId = id;
        pendingAccion = accion;
        msgConfirm.innerHTML = _0x5c98eb4bec49[14];
        const u = cacheUsuarios.find(function (x) {
            return String(x.id) === String(id);
        });
        const nombre = u ? `${u.usuario} (ID ${u.id})` : `ID ${id}`;
        if (accion === _0x5c98eb4bec49[24]) {
            confirmText.innerHTML =
                `¿Seguro que deseas <b>bloquear</b> a <b>${escapeHtml(nombre)}</b>?`;
        }
        else {
            confirmText.innerHTML =
                `¿Seguro que deseas <b>desbloquear</b> a <b>${escapeHtml(nombre)}</b>?`;
        }
        btnConfirm.disabled = false;
        btnConfirm.innerHTML = `<i class="bi bi-check2-circle me-1"></i> Confirmar`;
        modalConfirm.show();
    }
    async function toggleEstado(id, accion) {
        try {
            btnConfirm.disabled = true;
            btnConfirm.innerHTML =
                `<span class="spinner-border spinner-border-sm me-2"></span>Procesando...`;
            const fd = new FormData();
            fd.append(_0x5c98eb4bec49[25], id);
            fd.append(_0x5c98eb4bec49[26], accion);
            const res = await fetch(_0x5c98eb4bec49[27], {
                method: _0x5c98eb4bec49[28],
                body: fd,
                credentials: _0x5c98eb4bec49[16]
            });
            const data = await res.json();
            if (res.ok && data.ok) {
                showAlert(msgConfirm, _0x5c98eb4bec49[29], data.msg || _0x5c98eb4bec49[30]);
                await cargarUsuarios();
                setTimeout(function () {
                    modalConfirm.hide();
                }, 450);
            }
            else {
                showAlert(msgConfirm, _0x5c98eb4bec49[17], data.msg || _0x5c98eb4bec49[31]);
            }
        }
        catch (e) {
            showAlert(msgConfirm, _0x5c98eb4bec49[17], _0x5c98eb4bec49[32]);
        }
        finally {
            btnConfirm.disabled = false;
            btnConfirm.innerHTML = `<i class="bi bi-check2-circle me-1"></i> Confirmar`;
        }
    }
    function renderPaginacion(pages) {
        pagination.innerHTML = _0x5c98eb4bec49[14];
        if (pages <= 1) {
            return;
        }
        const maxBtns = 7;
        const half = Math.floor(maxBtns / 2);
        let start = Math.max(1, page - half);
        let end = Math.min(pages, start + maxBtns - 1);
        start = Math.max(1, end - maxBtns + 1);
        pagination.appendChild(pageItem(_0x5c98eb4bec49[33], page - 1, page === 1));
        if (start > 1) {
            pagination.appendChild(pageItem(_0x5c98eb4bec49[34], 1, false, page === 1));
            if (start > 2) {
                pagination.appendChild(ellipsisItem());
            }
        }
        for (let p = start; p <= end; p++) {
            pagination.appendChild(pageItem(String(p), p, false, p === page));
        }
        if (end < pages) {
            if (end < pages - 1) {
                pagination.appendChild(ellipsisItem());
            }
            pagination.appendChild(pageItem(String(pages), pages, false, page === pages));
        }
        pagination.appendChild(pageItem(_0x5c98eb4bec49[35], page + 1, page === pages));
    }
    function pageItem(label, target, disabled = false, active = false) {
        const li = document.createElement(_0x5c98eb4bec49[36]);
        li.className = `page-item ${disabled ? _0x5c98eb4bec49[37] : _0x5c98eb4bec49[14]} ${active ? _0x5c98eb4bec49[38] : _0x5c98eb4bec49[14]}`;
        const a = document.createElement(_0x5c98eb4bec49[39]);
        a.className = _0x5c98eb4bec49[40];
        a.href = _0x5c98eb4bec49[41];
        a.textContent = label;
        a.addEventListener(_0x5c98eb4bec49[13], function (e) {
            e.preventDefault();
            if (disabled) {
                return;
            }
            page = target;
            cargarUsuarios();
        });
        li.appendChild(a);
        return li;
    }
    function ellipsisItem() {
        const li = document.createElement(_0x5c98eb4bec49[36]);
        li.className = _0x5c98eb4bec49[42];
        const span = document.createElement(_0x5c98eb4bec49[43]);
        span.className = _0x5c98eb4bec49[40];
        span.textContent = _0x5c98eb4bec49[44];
        li.appendChild(span);
        return li;
    }
    function showAlert(el, type, text) {
        el.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0">
                <i class="bi ${type === _0x5c98eb4bec49[29] ? _0x5c98eb4bec49[45] : _0x5c98eb4bec49[46]} me-1"></i>
                ${escapeHtml(text)}
            </div>
        `;
    }
    function escapeHtml(str) {
        return String(str ?? _0x5c98eb4bec49[14])
            .replaceAll(_0x5c98eb4bec49[47], _0x5c98eb4bec49[48])
            .replaceAll(_0x5c98eb4bec49[49], _0x5c98eb4bec49[50])
            .replaceAll(_0x5c98eb4bec49[51], _0x5c98eb4bec49[52])
            .replaceAll(_0x5c98eb4bec49[53], _0x5c98eb4bec49[54])
            .replaceAll(_0x5c98eb4bec49[55], _0x5c98eb4bec49[56]);
    }
    cargarUsuarios();
})();
