var _0x1252b03092dc=["Zm9ybUxvZ2lu","bXNnTG9naW4=","dG9nZ2xlUGFzc0ljb24=","YnRuU3VibWl0","YnRuQ2xlYXI=","aW5wdXRbbmFtZT0idXN1YXJpbyJd","aW5wdXRbbmFtZT0icGFzc3dvcmQiXQ==","aQ==","aW5wdXQ=","","Y2xpY2s=","cGFzc3dvcmQ=","dGV4dA==","YmkgYmktZXllLXNsYXNo","YmkgYmktZXll","c3VibWl0","TGEgY29udHJhc2XDsWEgZGViZSB0ZW5lciBhbCBtZW5vcyA2IGNhcmFjdGVyZXMu","ZGFuZ2Vy","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3MvbG9naW4ucGhw","R0VU","c2FtZS1vcmlnaW4=","bm8tc3RvcmU=","Tm8gc2UgcHVkbyBwcmVwYXJhciBsYSBzZXNpw7Nu","U2VzacOzbiBubyB2w6FsaWRh","Y3NyZl90b2tlbg==","UE9TVA==","UmVzcHVlc3RhIGludsOhbGlkYQ==","c3VjY2Vzcw==","L2FwcF9kZXNjdWVudG8v","Tm8gc2UgcHVkbyBjb25lY3RhciBjb24gZWwgc2Vydmlkb3Iu","YmktY2hlY2stY2lyY2xlLWZpbGw=","YmktZXhjbGFtYXRpb24tdHJpYW5nbGUtZmlsbA=="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(function () {
    const form = document.getElementById(_0x1252b03092dc[0]);
    const msg = document.getElementById(_0x1252b03092dc[1]);
    const toggle = document.getElementById(_0x1252b03092dc[2]);
    const btnSubmit = document.getElementById(_0x1252b03092dc[3]);
    const btnClear = document.getElementById(_0x1252b03092dc[4]);
    const inputUsuario = form.querySelector(_0x1252b03092dc[5]);
    const passInput = form.querySelector(_0x1252b03092dc[6]);
    const icon = toggle.querySelector(_0x1252b03092dc[7]);
    inputUsuario.addEventListener(_0x1252b03092dc[8], function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, _0x1252b03092dc[9]);
    });
    passInput.addEventListener(_0x1252b03092dc[8], function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, _0x1252b03092dc[9]);
    });
    toggle.addEventListener(_0x1252b03092dc[10], () => {
        const isPass = passInput.type === _0x1252b03092dc[11];
        passInput.type = isPass ? _0x1252b03092dc[12] : _0x1252b03092dc[11];
        icon.className = isPass ? _0x1252b03092dc[13] : _0x1252b03092dc[14];
    });
    btnClear.addEventListener(_0x1252b03092dc[10], () => {
        msg.innerHTML = _0x1252b03092dc[9];
        form.reset();
        inputUsuario.focus();
    });
    form.addEventListener(_0x1252b03092dc[15], async (e) => {
        e.preventDefault();
        msg.innerHTML = _0x1252b03092dc[9];
        if ((passInput.value || _0x1252b03092dc[9]).length < 6) {
            showMessage(_0x1252b03092dc[16], _0x1252b03092dc[17]);
            return;
        }
        btnSubmit.disabled = true;
        const original = btnSubmit.innerHTML;
        btnSubmit.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span> Entrando...`;
        try {
            const csrfResponse = await fetch(_0x1252b03092dc[18], {
                method: _0x1252b03092dc[19],
                credentials: _0x1252b03092dc[20],
                cache: _0x1252b03092dc[21]
            });
            if (!csrfResponse.ok)
                throw new Error(_0x1252b03092dc[22]);
            const csrf = await csrfResponse.json();
            if (!csrf.ok || !csrf.csrf_token)
                throw new Error(_0x1252b03092dc[23]);
            const fd = new FormData(form);
            fd.append(_0x1252b03092dc[24], csrf.csrf_token);
            const res = await fetch(_0x1252b03092dc[18], {
                method: _0x1252b03092dc[25],
                body: fd,
                credentials: _0x1252b03092dc[20],
                cache: _0x1252b03092dc[21]
            });
            if (!res.ok)
                throw new Error(_0x1252b03092dc[26]);
            const data = await res.json();
            if (data.ok) {
                showMessage(data.msg, _0x1252b03092dc[27]);
                setTimeout(() => {
                    window.location.href = window.location.origin + _0x1252b03092dc[28];
                }, 800);
            }
            else {
                showMessage(data.msg, _0x1252b03092dc[17]);
            }
        }
        catch (err) {
            showMessage(_0x1252b03092dc[29], _0x1252b03092dc[17]);
        }
        finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = original;
        }
    });
    function showMessage(text, type) {
        msg.innerHTML = `
          <div class="alert alert-${type} mb-0 fade show d-flex align-items-center">
            <i class="bi ${type === _0x1252b03092dc[27] ? _0x1252b03092dc[30] : _0x1252b03092dc[31]} me-2"></i>
            <div>${text}</div>
          </div>
        `;
    }

    document.addEventListener('contextmenu', function (event) {
        event.preventDefault();
    });

    window.addEventListener('keydown', function (event) {
        const tecla = event.key.toLowerCase();
        const atajoBloqueado = tecla === 'f12'
            || (event.ctrlKey && tecla === 'u')
            || (event.ctrlKey && event.shiftKey && tecla === 'i');

        if (atajoBloqueado) {
            event.preventDefault();
            event.stopPropagation();
        }
    }, true);
})();
