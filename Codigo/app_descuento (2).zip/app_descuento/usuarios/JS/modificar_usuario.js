var _0x221fca2b8797=["dGJvZHlVc3Vhcmlvcw==","dHh0QnVzY2Fy","bXNnTGlzdA==","c2VsTGltaXQ=","bGJsUGFnZXJJbmZv","cGFnaW5hdGlvbg==","bW9kYWxFZGl0YXI=","Zm9ybUVkaXRhcg==","bXNnRWRpdA==","ZWRpdElk","ZWRpdElkU2hvdw==","ZWRpdFVzdWFyaW8=","ZWRpdE5vbWJyZQ==","ZWRpdFJvbA==","ZWRpdFBhc3M=","YnRuVG9nZ2xlUGFzcw==","MTAw","aW5wdXQ=","","Y2xpY2s=","cGFzc3dvcmQ=","dGV4dA==","PGkgY2xhc3M9ImJpIGJpLWV5ZS1zbGFzaCI+PC9pPg==","PGkgY2xhc3M9ImJpIGJpLWV5ZSI+PC9pPg==","Y2hhbmdl","bm8tc3RvcmU=","c2FtZS1vcmlnaW4=","ZGFuZ2Vy","YnV0dG9uW2RhdGEtaWRd","ZGF0YS1pZA==","wqs=","wrs=","bGk=","YWN0aXZl","ZGlzYWJsZWQ=","YQ==","cGFnZS1saW5r","Iw==","RXJyb3I=","Tm8gc2UgcHVkbyBhYnJpciBlbCB1c3VhcmlvLg==","c3VibWl0","TGEgY29udHJhc2XDsWEgZGViZSB0ZW5lciBhbCBtZW5vcyA2IGNhcmFjdGVyZXMu","TGEgY29udHJhc2XDsWEgc29sbyBwZXJtaXRlIGxldHJhcywgbsO6bWVyb3MgeSBwdW50by4=","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3MvbW9kaWZpY2FyX3VzdWFyaW8ucGhwP2FjdGlvbj11cGRhdGU=","UE9TVA==","c3VjY2Vzcw==","QWN0dWFsaXphZG8gY29ycmVjdGFtZW50ZS4=","Tm8gc2UgcHVkbyBhY3R1YWxpemFyLg==","Tm8gc2UgcHVkbyBjb25lY3RhciBjb24gZWwgc2Vydmlkb3Iu","YmktY2hlY2stY2lyY2xl","YmktZXhjbGFtYXRpb24tdHJpYW5nbGU=","Jg==","JmFtcDs=","PA==","Jmx0Ow==","Pg==","Jmd0Ow==","Ig==","JnF1b3Q7","Jw==","JiMwMzk7"].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(function () {
    const tbody = document.getElementById(_0x221fca2b8797[0]);
    const txtBuscar = document.getElementById(_0x221fca2b8797[1]);
    const msgList = document.getElementById(_0x221fca2b8797[2]);
    const selLimit = document.getElementById(_0x221fca2b8797[3]);
    const lblPagerInfo = document.getElementById(_0x221fca2b8797[4]);
    const pagination = document.getElementById(_0x221fca2b8797[5]);
    const modalEditarEl = document.getElementById(_0x221fca2b8797[6]);
    const formEditar = document.getElementById(_0x221fca2b8797[7]);
    const msgEdit = document.getElementById(_0x221fca2b8797[8]);
    const editId = document.getElementById(_0x221fca2b8797[9]);
    const editIdShow = document.getElementById(_0x221fca2b8797[10]);
    const editUsuario = document.getElementById(_0x221fca2b8797[11]);
    const editNombre = document.getElementById(_0x221fca2b8797[12]);
    const editRol = document.getElementById(_0x221fca2b8797[13]);
    const editPass = document.getElementById(_0x221fca2b8797[14]);
    const btnTogglePass = document.getElementById(_0x221fca2b8797[15]);
    if (!tbody || !txtBuscar || !modalEditarEl || !formEditar) {
        return;
    }
    const modalEditar = new bootstrap.Modal(modalEditarEl);
    let cacheUsuarios = [];
    let page = 1;
    let limit = parseInt(selLimit.value || _0x221fca2b8797[16], 10);
    editUsuario.addEventListener(_0x221fca2b8797[17], function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g, _0x221fca2b8797[18]);
    });
    editNombre.addEventListener(_0x221fca2b8797[17], function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ\s]/g, _0x221fca2b8797[18]);
    });
    editPass.addEventListener(_0x221fca2b8797[17], function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, _0x221fca2b8797[18]);
    });
    btnTogglePass.addEventListener(_0x221fca2b8797[19], function () {
        const isPass = editPass.type === _0x221fca2b8797[20];
        editPass.type = isPass ? _0x221fca2b8797[21] : _0x221fca2b8797[20];
        btnTogglePass.innerHTML = isPass
            ? _0x221fca2b8797[22] : _0x221fca2b8797[23];
    });
    let timerBusqueda = null;
    txtBuscar.addEventListener(_0x221fca2b8797[17], function () {
        clearTimeout(timerBusqueda);
        timerBusqueda = setTimeout(function () {
            page = 1;
            cargarUsuarios();
        }, 250);
    });
    selLimit.addEventListener(_0x221fca2b8797[24], function () {
        limit = parseInt(selLimit.value || _0x221fca2b8797[16], 10);
        page = 1;
        cargarUsuarios();
    });
    async function cargarUsuarios() {
        msgList.innerHTML = _0x221fca2b8797[18];
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-muted">Cargando...</td>
            </tr>
        `;
        try {
            const q = encodeURIComponent((txtBuscar.value || _0x221fca2b8797[18]).trim());
            const url = `/app_descuento/usuarios/modificar_usuario.php?action=list&page=${page}&limit=${limit}&q=${q}`;
            const res = await fetch(url, {
                cache: _0x221fca2b8797[25],
                credentials: _0x221fca2b8797[26]
            });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error(data.msg || `HTTP ${res.status}`);
            }
            cacheUsuarios = data.usuarios || [];
            const total = parseInt(data.total || 0, 10);
            const pages = parseInt(data.pages || 1, 10);
            if (page > pages) {
                page = pages;
                return cargarUsuarios();
            }
            const from = total === 0 ? 0 : ((page - 1) * limit + 1);
            const to = Math.min(page * limit, total);
            lblPagerInfo.textContent =
                `Mostrando ${from}-${to} de ${total} (página ${page} de ${pages})`;
            renderTabla();
            renderPagination(pages);
        }
        catch (e) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-danger">No se pudo cargar.</td>
                </tr>
            `;
            showAlert(msgList, _0x221fca2b8797[27], e.message);
            lblPagerInfo.textContent = _0x221fca2b8797[18];
            pagination.innerHTML = _0x221fca2b8797[18];
        }
    }
    function renderTabla() {
        if (cacheUsuarios.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-muted">Sin resultados.</td>
                </tr>
            `;
            return;
        }
        tbody.innerHTML = cacheUsuarios.map(function (u) {
            return `
                <tr>
                    <td>${escapeHtml(u.id)}</td>
                    <td class="fw-semibold">${escapeHtml(u.usuario)}</td>
                    <td>${escapeHtml(u.nombre)}</td>
                    <td>${escapeHtml(u.rol)}</td>
                    <td class="text-end">
                        <button class="btn btn-soft btn-sm btn-action" data-id="${escapeHtml(u.id)}">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                    </td>
                </tr>
            `;
        }).join(_0x221fca2b8797[18]);
        tbody.querySelectorAll(_0x221fca2b8797[28]).forEach(function (btn) {
            btn.addEventListener(_0x221fca2b8797[19], function () {
                abrirEditar(btn.getAttribute(_0x221fca2b8797[29]));
            });
        });
    }
    function renderPagination(pages) {
        pagination.innerHTML = _0x221fca2b8797[18];
        if (pages <= 1) {
            return;
        }
        pagination.appendChild(makeItem(_0x221fca2b8797[30], page - 1, false, page === 1));
        let start = Math.max(1, page - 3);
        let end = Math.min(pages, page + 3);
        if (page <= 4) {
            end = Math.min(pages, 7);
        }
        if (page >= pages - 3) {
            start = Math.max(1, pages - 6);
        }
        for (let i = start; i <= end; i++) {
            pagination.appendChild(makeItem(String(i), i, i === page, false));
        }
        pagination.appendChild(makeItem(_0x221fca2b8797[31], page + 1, false, page === pages));
    }
    function makeItem(label, targetPage, active = false, disabled = false) {
        const li = document.createElement(_0x221fca2b8797[32]);
        li.className = `page-item ${active ? _0x221fca2b8797[33] : _0x221fca2b8797[18]} ${disabled ? _0x221fca2b8797[34] : _0x221fca2b8797[18]}`;
        const a = document.createElement(_0x221fca2b8797[35]);
        a.className = _0x221fca2b8797[36];
        a.href = _0x221fca2b8797[37];
        a.textContent = label;
        if (!disabled) {
            a.addEventListener(_0x221fca2b8797[19], function (e) {
                e.preventDefault();
                page = targetPage;
                cargarUsuarios();
            });
        }
        li.appendChild(a);
        return li;
    }
    async function abrirEditar(id) {
        msgEdit.innerHTML = _0x221fca2b8797[18];
        editPass.value = _0x221fca2b8797[18];
        try {
            const res = await fetch(`/app_descuento/usuarios/modificar_usuario.php?action=get&id=${encodeURIComponent(id)}`, {
                cache: _0x221fca2b8797[25],
                credentials: _0x221fca2b8797[26]
            });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error(data.msg || _0x221fca2b8797[38]);
            }
            const u = data.usuario;
            editId.value = u.id;
            editIdShow.value = u.id;
            editUsuario.value = u.usuario;
            editNombre.value = u.nombre;
            editRol.value = u.rol;
            modalEditar.show();
        }
        catch (e) {
            showAlert(msgList, _0x221fca2b8797[27], _0x221fca2b8797[39]);
        }
    }
    formEditar.addEventListener(_0x221fca2b8797[40], async function (e) {
        e.preventDefault();
        msgEdit.innerHTML = _0x221fca2b8797[18];
        const p = (editPass.value || _0x221fca2b8797[18]).trim();
        if (p.length > 0) {
            if (p.length < 6) {
                showAlert(msgEdit, _0x221fca2b8797[27], _0x221fca2b8797[41]);
                return;
            }
            if (!/^[A-Za-z0-9.]+$/.test(p)) {
                showAlert(msgEdit, _0x221fca2b8797[27], _0x221fca2b8797[42]);
                return;
            }
        }
        try {
            const fd = new FormData(formEditar);
            const res = await fetch(_0x221fca2b8797[43], {
                method: _0x221fca2b8797[44],
                body: fd,
                credentials: _0x221fca2b8797[26]
            });
            const data = await res.json();
            if (res.ok && data.ok) {
                showAlert(msgEdit, _0x221fca2b8797[45], data.msg || _0x221fca2b8797[46]);
                await cargarUsuarios();
                setTimeout(function () {
                    modalEditar.hide();
                }, 450);
            }
            else {
                showAlert(msgEdit, _0x221fca2b8797[27], data.msg || _0x221fca2b8797[47]);
            }
        }
        catch (e) {
            showAlert(msgEdit, _0x221fca2b8797[27], _0x221fca2b8797[48]);
        }
    });
    function showAlert(el, type, text) {
        el.innerHTML = `
            <div class="alert alert-${type} py-2 mb-0">
                <i class="bi ${type === _0x221fca2b8797[45] ? _0x221fca2b8797[49] : _0x221fca2b8797[50]} me-1"></i>
                ${escapeHtml(text)}
            </div>
        `;
    }
    function escapeHtml(str) {
        return String(str ?? _0x221fca2b8797[18])
            .replaceAll(_0x221fca2b8797[51], _0x221fca2b8797[52])
            .replaceAll(_0x221fca2b8797[53], _0x221fca2b8797[54])
            .replaceAll(_0x221fca2b8797[55], _0x221fca2b8797[56])
            .replaceAll(_0x221fca2b8797[57], _0x221fca2b8797[58])
            .replaceAll(_0x221fca2b8797[59], _0x221fca2b8797[60]);
    }
    cargarUsuarios();
})();
