<?php
require_once __DIR__ . "/validar_sesion.php";

/* VALIDAR PERMISO */
$rolSesion = $_SESSION["rol"] ?? "";

if (!in_array($rolSesion, ["admin"], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger">No tienes permiso para bloquear o desbloquear usuarios.</div>';
    exit;
}
?>


<link rel="stylesheet" href="/app_descuento/usuarios/CSS/agregar_usuario.css">

<link rel="stylesheet" href="/app_descuento/usuarios/CSS/bloquear_usuario.css">

<div class="section-wrap">

    
    <div class="section-head-card">
        <div class="section-head d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <h4 class="section-title">
                    <i class="bi bi-lock me-2"></i>Bloquear / Desbloquear
                </h4>

                <p class="section-sub">
                    Controla el acceso del usuario: activo o bloqueado.
                </p>
            </div>

            <span class="section-badge">
                <i class="bi bi-shield-lock"></i> Solo Admin
            </span>
        </div>
    </div>

  
    <div class="card section-card mt-3">
        <div class="card-body">

            <!-- BUSCADOR -->
            <div class="section-divider">
                <i class="bi bi-search me-2"></i>Buscar
            </div>

            <div class="row g-3">
                <div class="col-12">
                    <label class="form-label">Buscar por usuario o nombre</label>

                    <input
                        id="txtBuscar"
                        type="text"
                        class="form-control"
                        placeholder="Escriba para buscar..."
                    >
                </div>
            </div>

            <!-- MENSAJE -->
            <div id="msgList" class="mt-3"></div>

            <!-- TABLA -->
            <div class="table-responsive mt-3">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Rol</th>
                            <th>Estado</th>
                            <th class="text-end">Acción</th>
                        </tr>
                    </thead>

                    <tbody id="tbodyUsuarios">
                        <tr>
                            <td colspan="6" class="text-muted">Cargando...</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN -->
            <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">
                <div class="text-muted small" id="lblPagerInfo"></div>

                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <select id="selLimit" class="form-select">
                        <option value="100" selected>100 por página</option>
                        <option value="150">150 por página</option>
                        <option value="200">200 por página</option>
                    </select>

                    <nav>
                        <ul class="pagination mb-0" id="pagination"></ul>
                    </nav>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- MODAL DE CONFIRMACIÓN -->
<div class="modal fade" id="modalConfirm" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    <i class="bi bi-exclamation-triangle me-2"></i>Confirmar acción
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div id="confirmText" class="mb-2"></div>

                <div class="small text-muted">
                    Esto afectará el acceso del usuario al sistema.
                </div>

                <div id="msgConfirm" class="mt-3"></div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-soft" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-1"></i> Cancelar
                </button>

                <button class="btn btn-main" id="btnConfirm">
                    <i class="bi bi-check2-circle me-1"></i> Confirmar
                </button>
            </div>

        </div>
    </div>
</div>

<script src="/app_descuento/usuarios/JS/bloquear_usuario.js"></script>