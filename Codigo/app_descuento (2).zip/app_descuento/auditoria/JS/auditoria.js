var _0x1f931bb45929=["Zm9ybS1hdWRpdG9yaWE=","YXVkaXRvcmlhLXRib2R5LXdyYXA=","YnRuLWxpbXBpYXI=","YXVkLXBhZ2luYXRpb24=","dG90YWwtYmFkZ2U=","L2FwcF9kZXNjdWVudG8vYXVkaXRvcmlhL2F1ZGl0b3JpYS5waHA=","cGFnZQ==","YWpheA==","Pw==","I2F1ZC1wYWdpbmF0aW9uIGJ1dHRvbg==","W25hbWU9InBhZ2UiXQ==","PHRyPjx0ZCBjb2xzcGFuPSc2JyBjbGFzcz0ndGV4dC1jZW50ZXIgcHktNCB0ZXh0LW11dGVkJz48aSBjbGFzcz0nYmkgYmktaG91cmdsYXNzLXNwbGl0Jz48L2k+IENhcmdhbmRvLi4uPC90ZD48L3RyPg==","dW5kZWZpbmVk","IHJlZ2lzdHJvcw==","RXJyb3I6","PHRyPjx0ZCBjb2xzcGFuPSc2JyBjbGFzcz0ndGV4dC1jZW50ZXIgdGV4dC1kYW5nZXIgcHktNCc+RXJyb3IgY2FyZ2FuZG8gZGF0b3MuPC90ZD48L3RyPg==","c3VibWl0","Y2xpY2s=","MQ=="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(function () {
    const form = document.getElementById(_0x1f931bb45929[0]);
    const tbody = document.getElementById(_0x1f931bb45929[1]);
    const btnLimpiar = document.getElementById(_0x1f931bb45929[2]);
    const pagination = document.getElementById(_0x1f931bb45929[3]);
    const totalBadge = document.getElementById(_0x1f931bb45929[4]);
    const AUDITORIA_URL = window.location.origin + _0x1f931bb45929[5];
    function buildUrl(page = 1) {
        const fd = new FormData(form);
        fd.set(_0x1f931bb45929[6], page);
        fd.set(_0x1f931bb45929[7], 1);
        return AUDITORIA_URL + _0x1f931bb45929[8] + new URLSearchParams(fd).toString();
    }
    function attachPaginationEvents() {
        document.querySelectorAll(_0x1f931bb45929[9]).forEach(btn => {
            btn.onclick = () => {
                const p = parseInt(btn.dataset.page, 10);
                if (!isNaN(p)) {
                    load(p);
                }
            };
        });
    }
    function load(page = 1) {
        form.querySelector(_0x1f931bb45929[10]).value = page;
        tbody.innerHTML = _0x1f931bb45929[11];
        fetch(buildUrl(page))
            .then(r => r.json())
            .then(data => {
            tbody.innerHTML = data.tbody;
            pagination.innerHTML = data.pagination;
            if (totalBadge && typeof data.total !== _0x1f931bb45929[12]) {
                totalBadge.innerHTML = data.total + _0x1f931bb45929[13];
            }
            attachPaginationEvents();
        })
            .catch(err => {
            console.error(_0x1f931bb45929[14], err);
            tbody.innerHTML = _0x1f931bb45929[15];
        });
    }
    form.addEventListener(_0x1f931bb45929[16], e => {
        e.preventDefault();
        load(1);
    });
    btnLimpiar.addEventListener(_0x1f931bb45929[17], () => {
        form.reset();
        form.querySelector(_0x1f931bb45929[10]).value = 1;
        load(1);
    });
    const initialPage = parseInt(form.querySelector(_0x1f931bb45929[10]).value || _0x1f931bb45929[18], 10);
    load(initialPage);
})();
