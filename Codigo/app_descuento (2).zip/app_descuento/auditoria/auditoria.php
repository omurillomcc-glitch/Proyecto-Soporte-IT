<?php



require_once __DIR__ . "/../usuarios/validar_sesion.php";
require_once __DIR__ . "/../usuarios/conexion.php";


$rolActual = $_SESSION['rol'] ?? '';

if (!in_array($rolActual, ['admin'], true)) {
    http_response_code(403);
    echo '<div class="alert alert-danger m-3">Acceso denegado. Solo administradores.</div>';
    exit;
}

/* FUNCIONES BÁSICAS */
function limpiar($v): string {
    return trim((string)$v);
}

function h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* FORMATEAR IP */
function ip_label_html(?string $ip): string {
    $ip = (string)($ip ?? '');

    if ($ip === '') {
        return '<span class="ip-badge">-</span>';
    }

    if ($ip === '::1') {
        return '<span class="ip-badge">LOCALHOST</span>';
    }

    return '<span class="ip-badge mono">' . h($ip) . '</span>';
}

/* EXTRAER VALOR DEL DETALLE */
function aud_get_value(string $detalle, string $key): string {
    if (preg_match('/\b' . preg_quote($key, '/') . '=([^|]+)(?:\||$)/i', $detalle, $m)) {
        return trim($m[1]);
    }

    return '';
}

/* BADGES DE ACCIONES */
function badge_accion_html(?string $accion, ?string $detalle = ''): string {
    if (!$accion) {
        return "<span class='badge bg-secondary'><i class='bi bi-question-circle'></i> N/A</span>";
    }

    $detalle = (string)($detalle ?? '');
    $esMasivo = stripos($detalle, 'MASIVO=SI') !== false;

    /* DESCUENTOS */
    if ($accion === 'DESCUENTO_MASIVO') {
        return "<span class='badge bg-success'><i class='bi bi-people-fill'></i> Descuento masivo asignado</span>";
    }

    if ($accion === 'DESCUENTO_CAMBIADO_MASIVO') {
        return "<span class='badge bg-warning text-dark'><i class='bi bi-arrow-repeat'></i> Descuento masivo cambiado</span>";
    }

    if ($accion === 'DESCUENTO_ELIMINADO_MASIVO' || ($accion === 'DESCUENTO_ELIMINADO' && $esMasivo)) {
        return "<span class='badge bg-danger'><i class='bi bi-people-fill'></i><i class='bi bi-trash3'></i> Descuento masivo eliminado</span>";
    }

    if ($accion === 'DESCUENTO_ASIGNADO') {
        return "<span class='badge bg-success'><i class='bi bi-plus-circle-fill'></i> Descuento asignado</span>";
    }

    if ($accion === 'DESCUENTO_CAMBIADO') {
        return "<span class='badge bg-warning text-dark'><i class='bi bi-pencil-square'></i> Descuento cambiado</span>";
    }

    if ($accion === 'DESCUENTO_ELIMINADO') {
        return "<span class='badge bg-danger'><i class='bi bi-trash3-fill'></i> Descuento eliminado</span>";
    }

    /* USUARIOS */
    return match ($accion) {
        'USUARIO_AGREGADO'      => "<span class='badge bg-success'><i class='bi bi-person-plus-fill'></i> Usuario agregado</span>",
        'USUARIO_EDITADO'       => "<span class='badge bg-info text-dark'><i class='bi bi-person-gear'></i> Usuario editado</span>",
        'USUARIO_BLOQUEADO'     => "<span class='badge bg-secondary'><i class='bi bi-person-lock'></i> Usuario bloqueado</span>",
        'USUARIO_DESBLOQUEADO'  => "<span class='badge bg-info text-dark'><i class='bi bi-unlock-fill'></i> Usuario desbloqueado</span>",
        'ICG_USUARIO_CREADO'    => "<span class='badge bg-primary'><i class='bi bi-person-fill-add'></i> ICG creado</span>",
        'ICG_USUARIO_EDITADO'   => "<span class='badge bg-info text-dark'><i class='bi bi-pencil-square'></i> ICG editado</span>",
        default                 => "<span class='badge bg-primary'><i class='bi bi-info-circle'></i> " . h($accion) . "</span>",
    };
}

/* RENDERIZAR PARA QUE EL DETALLE SE VEA BONITO */
function render_detalle_bonito(?string $detalleRaw): string {
    $detalleRaw = trim((string)($detalleRaw ?? ''));

    if ($detalleRaw === '') {
        return '<span class="text-muted">Sin detalle</span>';
    }

    /* 1: USUARIO ICG CREADO */
    if (stripos($detalleRaw, 'ICG_USUARIO=SI') !== false) {
        $empresa    = h(aud_get_value($detalleRaw, 'EMPRESA') ?: '-');
        $codcliente = h(aud_get_value($detalleRaw, 'CODCLIENTE') ?: '-');
        $nombre     = h(aud_get_value($detalleRaw, 'NOMBRE') ?: '-');
        $identidad  = h(aud_get_value($detalleRaw, 'IDENTIDAD') ?: '-');

        return "
            <div class='detail-box detail-icg'>
                <div class='detail-head'>
                    <strong><i class='bi bi-person-fill-add'></i> Usuario ICG</strong>
                    <span>{$empresa}</span>
                </div>
                <div class='detail-grid'>
                    <div><small>Nombre</small><b>{$nombre}</b></div>
                    <div><small>CODCLIENTE</small><b class='mono'>{$codcliente}</b></div>
                    <div><small>Identidad</small><b class='mono'>{$identidad}</b></div>
                </div>
            </div>
        ";
    }

    /* 2: USUARIO DEL SISTEMA */
    if (stripos($detalleRaw, 'USUARIO=') !== false) {
        $usuario = h(aud_get_value($detalleRaw, 'USUARIO') ?: '-');
        $id      = h(aud_get_value($detalleRaw, 'ID') ?: '-');
        $nombre  = h(aud_get_value($detalleRaw, 'NOMBRE') ?: '');
        $rol     = h(aud_get_value($detalleRaw, 'ROL') ?: '');
        $estado  = h(aud_get_value($detalleRaw, 'ESTADO') ?: '');

        /* IMPORTANTE: */
        return "
            <div class='detail-box detail-user simple-detail'>
                <div class='detail-line'>
                    <span><i class='bi bi-person-circle'></i> Usuario</span>
                    <b>{$usuario}</b>
                </div>

                 <!-- OcultadO
                <div class='detail-line'>
                    <span>ID</span>
                    <b class='mono'>{$id}</b>
                </div>
                -->

                " . ($nombre !== '' ? "
                <div class='detail-line'>
                    <span>Nombre</span>
                    <b>{$nombre}</b>
                </div>" : "") . "

                " . ($rol !== '' ? "
                <div class='detail-line'>
                    <span>Rol</span>
                    <b>{$rol}</b>
                </div>" : "") . "
            </div>
        ";
    }

    /* 3: DESCUENTOS */
    if (
        stripos($detalleRaw, 'ICG=') !== false ||
        stripos($detalleRaw, 'CODCLIENTE=') !== false ||
        stripos($detalleRaw, 'IDGRUPO=') !== false ||
        stripos($detalleRaw, 'MASIVO=') !== false
    ) {
        $empresa    = h(aud_get_value($detalleRaw, 'ICG') ?: '-');
        $codigo     = h(aud_get_value($detalleRaw, 'CODCLIENTE') ?: '-');
        $idgrupoRaw = aud_get_value($detalleRaw, 'IDGRUPO');
        $idgrupo    = (int)($idgrupoRaw !== '' ? $idgrupoRaw : 0);
        $identidad  = h(aud_get_value($detalleRaw, 'IDENTIDAD') ?: '-');
        $masivo     = h(aud_get_value($detalleRaw, 'MASIVO') ?: '');

        $porcentaje = match ($idgrupo) {
            12, 15  => '10%',
            13, 16  => '20%',
            17      => '40%',
            14, 18  => '50%',
            0       => 'Sin descuento',
            default => (string)$idgrupo,
        };

        return "
            <div class='detail-box detail-discount'>
                <div class='detail-head'>
                    <strong><i class='bi bi-cash-coin'></i> Descuento</strong>
                    <span>{$porcentaje}</span>
                </div>
                <div class='detail-grid'>
                    <div><small>Empresa</small><b class='mono'>{$empresa}</b></div>
                    <div><small>Código</small><b class='mono'>{$codigo}</b></div>
                    <div><small>Identidad</small><b class='mono'>{$identidad}</b></div>
                    " . ($masivo !== '' ? "<div><small>Masivo</small><b class='mono'>{$masivo}</b></div>" : "") . "
                </div>
            </div>
        ";
    }

    return '<div class="small text-muted pre-wrap">' . h($detalleRaw) . '</div>';
}

/* RECIBIR FILTROS */
$desde   = limpiar($_GET['desde'] ?? '');
$hasta   = limpiar($_GET['hasta'] ?? '');
$accion  = limpiar($_GET['accion'] ?? '');
$q       = limpiar($_GET['q'] ?? '');

$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = max(10, min((int)($_GET['perPage'] ?? 100), 200));
$offset  = ($page - 1) * $perPage;

/* ARMAR SQL DINÁMICO */
$where = ["a.accion NOT IN ('LOGIN_OK','LOGIN_FAIL')"];
$params = [];
$types = "";

if ($desde) {
    $where[] = "a.created_at >= CONCAT(?,' 00:00:00')";
    $params[] = $desde;
    $types .= "s";
}

if ($hasta) {
    $where[] = "a.created_at <= CONCAT(?,' 23:59:59')";
    $params[] = $hasta;
    $types .= "s";
}

if ($accion) {
    $where[] = "a.accion = ?";
    $params[] = $accion;
    $types .= "s";
}

if ($q) {
    $where[] = "(a.detalle LIKE ? OR a.ip LIKE ? OR a.accion LIKE ? OR u.nombre LIKE ? OR u.usuario LIKE ?)";
    $params = array_merge($params, ["%$q%", "%$q%", "%$q%", "%$q%", "%$q%"]);
    $types .= "sssss";
}

$whereSql = count($where) ? "WHERE " . implode(" AND ", $where) : "";

/* TOTAL DE REGISTROS */
$sqlCount = "
    SELECT COUNT(*) AS total
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    $whereSql
";

$stmt = $conn->prepare($sqlCount);

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$total = (int)($result->fetch_assoc()['total'] ?? 0);
$stmt->close();

$totalPages = max(1, (int)ceil($total / $perPage));

/* PAGINACIÓN */
$range = 2;
$start = max(1, $page - $range);
$end   = min($totalPages, $page + $range);

/* CONSULTAR REGISTROS */
$sql = "
    SELECT
        a.id,
        a.usuario_id,
        u.nombre,
        u.usuario,
        a.accion,
        a.detalle,
        a.ip,
        a.created_at
    FROM auditoria a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    $whereSql
    ORDER BY a.created_at DESC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

$types2 = $types . "ii";
$params2 = array_merge($params, [$perPage, $offset]);

$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

/* ACCIONES PARA SELECT */
$acciones = [];
$rAcc = $conn->query("
    SELECT DISTINCT accion
    FROM auditoria
    WHERE accion NOT IN ('LOGIN_OK','LOGIN_FAIL')
    ORDER BY accion ASC
");

if ($rAcc) {
    while ($a = $rAcc->fetch_assoc()) {
        $acciones[] = $a['accion'];
    }
}

/* RENDERIZAR FILAS */
function render_auditoria_rows(array $rows): string {
    if (!$rows) {
        return "<tr><td colspan='6' class='text-center text-muted py-4'>No hay registros para mostrar.</td></tr>";
    }

    ob_start();

    foreach ($rows as $r) {
        $fecha = (string)($r['created_at'] ?? '');
        $fechaDia = $fecha ? date('Y-m-d', strtotime($fecha)) : '-';
        $fechaHora = $fecha ? date('H:i:s', strtotime($fecha)) : '-';
        $usuarioNombre = $r['nombre'] ?? 'Desconocido';
        $usuarioLogin = $r['usuario'] ?? '';
        ?>
        <tr>
            <td data-label="ID" class="mono id-cell">#<?= h((string)$r['id']) ?></td>

            <td data-label="Fecha">
                <div class="date-cell">
                    <i class="bi bi-clock"></i>
                    <div>
                        <b><?= h($fechaDia) ?></b>
                        <small><?= h($fechaHora) ?></small>
                    </div>
                </div>
            </td>

            <td data-label="Usuario">
                <div class="user-cell">
                    <div class="user-avatar"><i class="bi bi-person-fill"></i></div>
                    <div>
                        <b><?= h($usuarioNombre) ?></b>
                        <?= $usuarioLogin !== '' ? '<small>@' . h($usuarioLogin) . '</small>' : '' ?>
                    </div>
                </div>
            </td>

            <td data-label="Acción" class="action-cell"><?= badge_accion_html($r['accion'] ?? '', $r['detalle'] ?? '') ?></td>
            <td data-label="IP"><?= ip_label_html($r['ip'] ?? '') ?></td>
            <td data-label="Detalle" class="detail-td"><?= render_detalle_bonito($r['detalle'] ?? '') ?></td>
        </tr>
        <?php
    }

    return ob_get_clean();
}

/* RESPUESTA AJAX */
if (isset($_GET['ajax'])) {
    $tbody = render_auditoria_rows($rows);

    ob_start();
    ?>

    <?php if ($page > 1): ?>
        <li class="page-item">
            <button class="page-link" data-page="<?= $page - 1 ?>">Anterior</button>
        </li>
    <?php endif; ?>

    <?php if ($start > 1): ?>
        <li class="page-item">
            <button class="page-link" data-page="1">1</button>
        </li>
        <li class="page-item disabled"><span class="page-link">...</span></li>
    <?php endif; ?>

    <?php for ($p = $start; $p <= $end; $p++): ?>
        <li class="page-item <?= $p == $page ? 'active' : '' ?>">
            <button class="page-link" data-page="<?= $p ?>"><?= $p ?></button>
        </li>
    <?php endfor; ?>

    <?php if ($end < $totalPages): ?>
        <li class="page-item disabled"><span class="page-link">...</span></li>
        <li class="page-item">
            <button class="page-link" data-page="<?= $totalPages ?>"><?= $totalPages ?></button>
        </li>
    <?php endif; ?>

    <?php if ($page < $totalPages): ?>
        <li class="page-item">
            <button class="page-link" data-page="<?= $page + 1 ?>">Siguiente</button>
        </li>
    <?php endif; ?>

    <?php
    $pagination = ob_get_clean();

    echo json_encode([
        'tbody' => $tbody,
        'pagination' => $pagination,
        'total' => $total
    ], JSON_UNESCAPED_UNICODE);

    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Auditoría</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <link rel="stylesheet" href="/app_descuento/auditoria/CSS/auditoria.css">
    <link rel="stylesheet" href="/app_descuento/css/responsive.css">
</head>

<body class="p-4">

<div class="audit-wrap">
    <div class="audit-card">

        <!-- ENCABEZADO -->
        <div class="audit-header">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="header-icon">
                        <i class="bi bi-clipboard-data"></i>
                    </div>
                    <div>
                        <h4 class="mb-0 fw-bold"></h4>
                        <div class="text-muted small">Registro de acciones del sistema</div>
                    </div>
                </div>

                <div class="total-box" id="total-badge">
                    <?= (int)$total ?> registros
                </div>
            </div>
        </div>

        <div class="p-3 p-md-4">

            <!-- FILTROS -->
            <form class="filter-box row g-2 align-items-end" id="form-auditoria">
                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Desde</label>
                    <input type="date" name="desde" class="form-control" value="<?= h($desde) ?>">
                </div>

                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Hasta</label>
                    <input type="date" name="hasta" class="form-control" value="<?= h($hasta) ?>">
                </div>

                <div class="col-12 col-md-3">
                    <label class="form-label small text-muted">Acción</label>
                    <select name="accion" class="form-select">
                        <option value="">Todas</option>

                        <?php foreach ($acciones as $ac): ?>
                            <option value="<?= h($ac) ?>" <?= $accion === $ac ? 'selected' : '' ?>>
                                <?= h($ac) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 col-md-3">
                    <label class="form-label small text-muted">Buscar</label>
                    <input type="text" name="q" class="form-control" placeholder="Nombre, identidad, código..." value="<?= h($q) ?>">
                </div>

                <div class="col-12 col-md-2">
                    <label class="form-label small text-muted">Por página</label>
                    <select name="perPage" class="form-select">
                        <?php foreach ([10, 25, 50, 100, 200] as $n): ?>
                            <option value="<?= $n ?>" <?= (int)$perPage === $n ? 'selected' : '' ?>><?= $n ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-12 d-flex gap-2 flex-wrap mt-2">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i> Filtrar
                    </button>

                    <button class="btn btn-outline-secondary" type="button" id="btn-limpiar">
                        <i class="bi bi-x-circle"></i> Limpiar
                    </button>
                </div>

                <input type="hidden" name="page" value="<?= (int)$page ?>">
            </form>

            <!-- TABLA -->
            <div class="table-box table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>IP</th>
                            <th>Detalle</th>
                        </tr>
                    </thead>

                    <tbody id="auditoria-tbody-wrap">
                        <?= render_auditoria_rows($rows) ?>
                    </tbody>
                </table>
            </div>

            <!-- PAGINACIÓN -->
            <nav class="mt-3">
                <ul class="pagination justify-content-end flex-wrap" id="aud-pagination"></ul>
            </nav>

        </div>
    </div>
</div>

<script src="/app_descuento/auditoria/JS/auditoria.js"></script>

</body>
</html>
