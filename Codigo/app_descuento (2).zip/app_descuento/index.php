<?php
/* VALIDAR SESIÓN */

require_once __DIR__ . "/usuarios/validar_sesion.php";


/* VALIDAR ROL PARA MOSTRAR MENÚ DE ADMINISTRACIÓN */

$rolUsuario = $_SESSION['rol'] ?? '';

$puedeAdministrar = in_array($rolUsuario, ['admin'], true);
$paginaInicio = $puedeAdministrar ? '/app_descuento/dashboard.php' : '/app_descuento/home.php';
?>

<!doctype html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
  <title>Descuento Colaborador</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <link rel="stylesheet" href="/app_descuento/css/index.css">
  <link rel="stylesheet" href="/app_descuento/css/responsive.css">

  <!-- Fuente -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="/app_descuento/img/descuentol.jpg">

</head>

<body data-default-page="<?= htmlspecialchars($paginaInicio, ENT_QUOTES, 'UTF-8') ?>">

<div class="d-flex">

  <!-- SIDEBAR DESKTOP -->
  <aside class="sidebar text-white p-3 d-none d-lg-flex flex-column">

    <!-- LOGO -->
    <div class="brand d-flex justify-content-center py-4">
      <img src="/app_descuento/img/logo.png" alt="Logo Corporativo" class="logo-sidebar">
    </div>

    <!-- MENÚ PRINCIPAL DESKTOP -->
    <nav class="d-grid gap-2 d-flex flex-column h-100">

      <!-- INICIO -->
      <a class="menu-link active" href="#" data-page="<?= htmlspecialchars($paginaInicio, ENT_QUOTES, 'UTF-8') ?>">
        <i class="bi bi-house"></i>
        <span>Inicio</span>
      </a>

      <!-- COLABORADORES -->
      <a class="menu-link" href="#" data-page="/app_descuento/colaboradores/colaboradores.php">
        <i class="bi bi-people"></i>
        <span>Colaboradores</span>
      </a>
      <?php if ($puedeAdministrar): ?>

        <!-- AUDITORÍA -->
        <a class="menu-link" href="#" data-page="/app_descuento/auditoria/auditoria.php">
          <i class="bi bi-clipboard-data"></i>
          <span>Auditoría</span>
        </a>

        <!-- BOTÓN PADRE DEL SUBMENÚ USUARIOS -->
        <a
          class="menu-link d-flex justify-content-between align-items-center"
          data-bs-toggle="collapse"
          href="#usersMenuDesk"
          role="button"
          aria-expanded="false"
          aria-controls="usersMenuDesk"
          id="btnUsersDesk"
        >
          <span>
            <i class="bi bi-person-gear"></i>
            Control de usuarios
          </span>
          <i class="bi bi-chevron-down small"></i>
        </a>

        <div class="collapse submenu" id="usersMenuDesk">

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_agregar_usuario.php">
            <i class="bi bi-person-plus"></i>
            <span>Agregar usuario</span>
          </a>

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_modificar_usuario.php">
            <i class="bi bi-pencil-square"></i>
            <span>Modificar usuario</span>
          </a>

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuariosICG/icg_usuarios.php">
            <i class="bi bi-person-vcard"></i>
            <span>Usuarios ICG</span>
          </a>

          <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_bloquear_usuario.php">
            <i class="bi bi-lock"></i>
            <span>Bloquear / Desbloquear</span>
          </a>

        </div>

      <?php endif; ?>

      <hr class="border-light opacity-10">

      <!-- SALIR -->
      <a class="menu-link mt-auto" href="/app_descuento/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Salir</span>
      </a>

    </nav>
  </aside>


  <!-- CONTENIDO PRINCIPAL -->
  <div class="flex-grow-1">

    <!-- TOPBAR -->
    <div class="topbar py-2 px-3 d-flex justify-content-between align-items-center">

      <!-- BOTÓN MENÚ MÓVIL -->
      <button
        class="btn btn-primary d-lg-none"
        data-bs-toggle="offcanvas"
        data-bs-target="#mobileSidebar"
        aria-controls="mobileSidebar"
        type="button"
      >
        <i class="bi bi-list"></i>
      </button>

      <!-- TÍTULO -->
      <span class="fw-semibold">Panel Administrativo</span>

      <!-- BOTONES DERECHA -->
      <div class="d-flex align-items-center gap-2 topbar-buttons">
        <a href="#" class="btn btn-primary btn-sm btn-colaboradores d-none d-md-inline-flex" data-page="/app_descuento/colaboradores/colaboradores.php">
          <i class="bi bi-people"></i>
          Colaboradores
        </a>

        <a href="/app_descuento/logout.php" class="btn btn-danger btn-sm btn-salir">
          <i class="bi bi-box-arrow-right"></i>
          Salir
        </a>
      </div>
    </div>

    <!-- CONTENEDOR DINÁMICO -->
    <div class="p-4" id="contenido-principal">

      <!-- CONTENIDO INICIAL MIENTRAS CARGA DASHBOARD -->
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body">
          <h4>Bienvenidos</h4>
          <p class="text-muted mb-0">Cargando panel...</p>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- SIDEBAR MÓVIL -->
<div
  class="offcanvas offcanvas-start text-white"
  tabindex="-1"
  id="mobileSidebar"
  class="mobile-sidebar"
>

  <div class="offcanvas-header">
    <h5 class="mb-0">Mi Sistema</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
  </div>

  <div class="offcanvas-body d-grid gap-2">

    <!-- INICIO MÓVIL -->
    <a class="menu-link" href="#" data-page="<?= htmlspecialchars($paginaInicio, ENT_QUOTES, 'UTF-8') ?>">
      <i class="bi bi-house"></i>
      <span>Inicio</span>
    </a>

    <!-- COLABORADORES MÓVIL -->
    <a class="menu-link" href="#" data-page="/app_descuento/colaboradores/colaboradores.php">
      <i class="bi bi-people"></i>
      <span>Colaboradores</span>
    </a>
    <?php if ($puedeAdministrar): ?>

      <!-- AUDITORÍA MÓVIL -->
      <a class="menu-link" href="#" data-page="/app_descuento/auditoria/auditoria.php">
        <i class="bi bi-clipboard-data"></i>
        <span>Auditoría</span>
      </a>

      <!-- BOTÓN PADRE DEL SUBMENÚ USUARIOS MÓVIL -->
      <a
        class="menu-link d-flex justify-content-between align-items-center"
        data-bs-toggle="collapse"
        href="#usersMenuMob"
        role="button"
        aria-expanded="false"
        aria-controls="usersMenuMob"
        id="btnUsersMob"
      >
        <span>
          <i class="bi bi-person-gear"></i>
          Control de usuarios
        </span>
        <i class="bi bi-chevron-down small"></i>
      </a>

      <!-- SUBMENÚ USUARIOS MÓVIL -->
      <div class="collapse submenu" id="usersMenuMob">

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_agregar_usuario.php">
          <i class="bi bi-person-plus"></i>
          <span>Agregar usuario</span>
        </a>

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_modificar_usuario.php">
          <i class="bi bi-pencil-square"></i>
          <span>Modificar usuario</span>
        </a>

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuariosICG/icg_usuarios.php">
          <i class="bi bi-person-vcard"></i>
          <span>Usuarios ICG</span>
        </a>

        <a class="menu-link submenu-link" href="#" data-page="/app_descuento/usuarios/vista_bloquear_usuario.php">
          <i class="bi bi-lock"></i>
          <span>Bloquear / Desbloquear</span>
        </a>

      </div>

    <?php endif; ?>

    <hr class="border-light opacity-10">

    <!-- SALIR MÓVIL -->
    <a class="menu-link" href="/app_descuento/logout.php">
      <i class="bi bi-box-arrow-right"></i>
      <span>Salir</span>
    </a>

  </div>
</div>


<!-- SCRIPTS GENERALES -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js para gráficos del dashboard -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>


<script src="/app_descuento/js/index.js"></script>

</body>
</html>