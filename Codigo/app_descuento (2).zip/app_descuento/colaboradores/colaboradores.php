<?php
require_once __DIR__ . "/../usuarios/validar_sesion.php";
?>


<link rel="stylesheet" href="/app_descuento/colaboradores/CSS/colaboradores.css">

<!-- CONTENEDOR PRINCIPAL -->
<div class="container py-4">
  <div class="card card-soft p-3 p-md-4">

    <!-- TOPBAR / CABECERA -->
    <div class="topbar">
      <div class="title-wrap">
        <h4 class="mb-0">Colaboradores</h4>
        <div class="subtitle">Evolution + ICG (Mendels, Acajoe, Detodo y Chesters)</div>
      </div>
      <div class="top-actions">
        <span id="estado" class="badge badge-soft">Listo</span>
      </div>
    </div>

    <div class="split">

      <!-- PANEL IZQUIERDO -->
      <aside class="side">
        <div class="side-card">
          <div class="side-title">Filtros</div>

          <!-- Selector de filtro -->
          <label class="form-label mt-2">Filtro</label>
          <select id="filtro" class="form-select">
            <option value="todos">Todos</option>
            <option value="con">Con descuento</option>
            <option value="sin">Sin descuento</option>
          </select>

          <!-- Campo de búsqueda -->
          <label class="form-label mt-3">Buscar</label>
          <input id="buscar" class="form-control" placeholder="Ej: Maria o 0801-1990">


          <button id="btnMasivo" type="button" class="btn btn-success w-100 mt-2">
  Asignar masivo
</button>

          <!-- Botón que dispara la carga manual -->
          <button id="btnCargar" type="button" class="btn w-100 mt-3">Cargar</button>

          <!-- Texto de ayuda -->
          <div class="help mt-3">
            Tip: puedes buscar por nombre o identidad con o sin guiones.
          </div>
        </div>

        <!-- PANEL DE PAGINACIÓN -->
        <div class="side-card mt-3">
          <div class="side-title"></div>
          <div id="paginacionInfo" class="small text-muted"></div>

          <div class="pager mt-2">
            <button type="button" class="btn btn-pill" id="btnPrev">Anterior</button>
            <button type="button" class="btn btn-pill" id="btnNext">Siguiente</button>
          </div>

          <div class="mt-2" id="paginacionNumeros"></div>
        </div>
      </aside>

      <!-- PANEL DERECHO / TABLA -->
      <section class="main">
        <div class="table-wrap">
          <div class="table-head">
            <div class="table-title">Listado</div>
            <div class="table-meta" id="tableMeta"></div>
          </div>

          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead>
                <tr>
                  <th class="col-num">N°</th>
                  <th class="col-codigo">Código</th>
                  <th class="col-identidad">Identidad</th>
                  <th class="col-nombre">Nombre</th>
                  <th class="col-empresa">Empresa</th>
                  <th>Desc.</th>
                  <th class="col-tipo">Tipo</th>
                  <th class="col-accion">Acción</th>
                </tr>
              </thead>
              <tbody id="tbody">
                <tr><td colspan="8" class="text-secondary">Presiona <b>Cargar</b>.</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>

  </div>
</div>

<!-- MODAL PARA ASIGNAR / CAMBIAR DESCUENTO -->
<div class="modal fade" id="modalGrupo" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content modal-round-lg">
      <div class="modal-header">
        <h5 class="modal-title">Asignar o Cambiar</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <div class="mb-2">
          <div class="small text-secondary">Empresa</div>
          <div id="m_empresa_show" class="mono"></div>
        </div>

        <div class="mb-2">
          <div class="small text-secondary">Identidad</div>
          <div id="m_identidad_show" class="mono"></div>
        </div>

        <div class="mb-3">
          <label class="form-label">Tipo de descuento (ICG)</label>
          <select id="m_idgrupo" class="form-select">
            <option value="">Seleccione...</option>
          </select>
          <div class="form-text">Listado desde ICG según la empresa seleccionada.</div>
        </div>

        <div class="mb-2">
          <div class="small text-secondary">Tipo actual</div>
          <div id="m_tipo_actual" class="fw-semibold">-</div>
        </div>

        <div id="m_msg" class="small"></div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" id="m_guardar" class="btn btn-primary">Guardar</button>
      </div>
    </div>
  </div>
</div>


<!-- MODAL MASIVO -->
<div class="modal fade" id="modalMasivo" tabindex="-1">
<div class="modal-dialog modal-dialog-centered modal-lg modal-move">
    <div class="modal-content modal-round-lg">
      <div class="modal-header">
        <h5 class="modal-title">Asignar descuento masivo</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <label class="form-label">Empresa</label>
        <select id="masivo_empresa" class="form-select mb-3">
          <option value="mendels">Mendels</option>
          <option value="acajoe">Acajoe</option>
          <option value="detodo">Detodo</option>
          <option value="chesters">Chesters</option>
        </select>

        <label class="form-label">Descuento</label>
        <select id="masivo_idgrupo" class="form-select mb-3">
          <option value="">Seleccione descuento...</option>
        </select>

        <label class="form-label">Identidades</label>
        <textarea id="masivo_identidades" class="form-control" rows="8"
          placeholder="Pegue una identidad por línea&#10;1503-2007-00954&#10;0501-2003-07712"></textarea>

        <div class="form-text">
          Puedes pegar identidades separadas por línea, coma o punto y coma.
        </div>

        <div id="masivo_msg" class="small mt-3"></div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" id="btnAplicarMasivo" class="btn btn-success">Procesar descuento</button>
      </div>
    </div>
  </div>
</div>



<script src="/app_descuento/colaboradores/JS/colaboradores.js?v=perf-1"></script>