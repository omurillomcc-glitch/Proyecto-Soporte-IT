<?php
declare(strict_types=1);

/* ARCHIVO: colaboradores/db_icg.php */

/* UBICAR EL ARCHIVO config.php */
$configPath = __DIR__ . "/config.php";

/* VALIDAR QUE EXISTA config.php */
if (!file_exists($configPath)) {
    http_response_code(500);
    die("Error: config.php no existe en colaboradores/");
}

/* CARGAR CONFIGURACIÓN */
$cfg = require $configPath;

/* VALIDAR ESTRUCTURA BÁSICA DE CONFIG */
if (!is_array($cfg) || !isset($cfg['icg']) || !is_array($cfg['icg'])) {
    http_response_code(500);
    die("Error: config.php inválido (falta bloque icg).");
}

/* FUNCIÓN PARA NORMALIZAR NOMBRE DE EMPRESA */
function icg_normalizar_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));
    $empresa = preg_replace('/[\s\-_]+/', '', $empresa);
    return $empresa ?? '';
}

/* FUNCIÓN PARA RESOLVER ALIAS DE CONEXIÓN */
function icg_resolver_alias_conexion(string $empresa): string
{
    if ($empresa === 'acajoe') {
        return 'mendels';
    }

    return $empresa;
}

/* FUNCIÓN PRINCIPAL icg_pdo() */
function icg_pdo(string $empresa): PDO
{
    /* 1: CARGAR CONFIG YA VALIDADA */
    static $cfg = null;

    if ($cfg === null) {
        $configPath = __DIR__ . "/config.php";

        if (!file_exists($configPath)) {
            throw new Exception("config.php no existe en colaboradores/");
        }

        $cfg = require $configPath;

        if (!is_array($cfg) || !isset($cfg['icg']) || !is_array($cfg['icg'])) {
            throw new Exception("config.php inválido (falta bloque icg).");
        }
    }

    /* 2: GUARDAR EMPRESA ORIGINAL */
    $empresaOriginal = $empresa;

    /* 3: NORMALIZAR EMPRESA */
    $empresaNormalizada = icg_normalizar_empresa($empresaOriginal);

    if ($empresaNormalizada === '') {
        throw new Exception("Empresa vacía o inválida.");
    }

    /* 4: RESOLVER ALIAS DE CONEXIÓN */
    $empresaConexion = icg_resolver_alias_conexion($empresaNormalizada);

    /* 5: LEER MAPA DE BASES */
    $map = $cfg['icg']['db_map'] ?? [];

    if (!is_array($map) || empty($map)) {
        throw new Exception("Config ICG incompleta: falta db_map.");
    }

    /* 6: VALIDAR EMPRESA EN EL MAPA */
    if (!isset($map[$empresaConexion])) {
        $validas = implode(', ', array_keys($map));

        throw new Exception(
            "Empresa inválida para conexión ICG. " .
            "Original='{$empresaOriginal}', " .
            "normalizada='{$empresaNormalizada}', " .
            "conexion='{$empresaConexion}'. " .
            "Válidas: {$validas}"
        );
    }

    /* 7: OBTENER NOMBRE DE BASE DE DATOS */
    $db = (string)($map[$empresaConexion] ?? '');

    /* 8: LEER DATOS DE CONEXIÓN */
    $server = (string)($cfg['icg']['server'] ?? '');
    $user   = (string)($cfg['icg']['user'] ?? '');
    $pass   = (string)($cfg['icg']['pass'] ?? '');

    /* 9: VALIDAR DATOS MÍNIMOS */
    if ($server === '' || $db === '' || $user === '') {
        throw new Exception(
            "Config ICG incompleta (server/db/user). " .
            "server='{$server}', db='{$db}', user='" . ($user !== '' ? '[OK]' : '') . "'"
        );
    }

    /* 10: CONSTRUIR DSN PARA SQL SERVER */
    $dsn = "sqlsrv:Server={$server};Database={$db};TrustServerCertificate=1";

    /* 11: CREAR Y RETORNAR CONEXIÓN PDO */
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}