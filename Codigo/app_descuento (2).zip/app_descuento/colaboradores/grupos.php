<?php
/* ARCHIVO: /api/descuento.php */

/* RESPUESTA JSON */
header('Content-Type: application/json; charset=utf-8');

/* INICIAR LA MISMA SESIÓN DE LA APP */
require_once __DIR__ . '/../usuarios/validar_sesion.php';

/* VALIDAR SESIÓN PARA AJAX */
if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        "ok" => false,
        "msg" => "Sesión expirada. Inicie sesión nuevamente.",
        "tiene_descuento" => false,
        "data" => null
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* CONEXIÓN A ICG */
require_once __DIR__ . '/db_icg.php';

/* FUNCIÓN DE ERROR */
function fail($msg, $extra = []) {
    echo json_encode(
        ["ok" => false, "msg" => $msg] + $extra,
        JSON_UNESCAPED_UNICODE
    );
    exit;
}

/* LEER PARÁMETROS */
$empresa   = strtolower(trim($_GET['empresa'] ?? 'mendels'));
$identidad = trim($_GET['identidad'] ?? '');

/* VALIDAR EMPRESA */
$empresasPermitidas = ['mendels', 'acajoe', 'detodo', 'chesters'];

if (!in_array($empresa, $empresasPermitidas, true)) {
    fail("Empresa inválida.");
}

/* VALIDAR IDENTIDAD */
if ($identidad === '') {
    fail("Falta identidad.");
}

/* CONECTAR A ICG */
[$conn, $db] = icg_conn($empresa);

if (!$conn) {
    fail("No conecta a ICG ($db)", ["errors" => sqlsrv_errors()]);
}

/* CONSULTA SQL */
$sql = "
SELECT TOP 1
  c.CODCLIENTE,
  c.NOMBRECLIENTE,
  c.CIF,
  x.IDGRUPO,
  g.DESCRIPCION AS tipo_descuento
FROM CLIENTES c
INNER JOIN (
  SELECT
    TRY_CAST(d.VALOR AS INT) AS CODCLIENTE,
    d.IDGRUPO
  FROM CONDICIONESGRUPOSCLIENTES d
  WHERE d.CAMPO = 'CODCLIENTE'
) x
  ON x.CODCLIENTE = c.CODCLIENTE
INNER JOIN GRUPOSCLIENTES g
  ON g.IDGRUPO = x.IDGRUPO
WHERE
  REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(c.CIF,''))), '-', ''), ' ', '') =
  REPLACE(REPLACE(?, '-', ''), ' ', '')
ORDER BY x.IDGRUPO DESC
";

/* EJECUTAR CONSULTA */
$stmt = sqlsrv_query($conn, $sql, [$identidad]);

if (!$stmt) {
    fail("Error consultando descuento", ["errors" => sqlsrv_errors()]);
}

/* OBTENER RESULTADO */
$row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

/* RESPUESTA FINAL */
echo json_encode([
    "ok" => true,
    "empresa" => $empresa,
    "bd" => $db,
    "tiene_descuento" => $row ? true : false,
    "data" => $row ?: null
], JSON_UNESCAPED_UNICODE);

/* CERRAR CONEXIÓN */
sqlsrv_close($conn);
exit;