var _0x354058e88bd9=["L2FwcF9kZXNjdWVudG8vY29sYWJvcmFkb3Jlcy8=","ZW1wbGVhZG9zX2FsbC5waHA=","Z3VhcmRhcl9kZXNjdWVudG8ucGhw","Z3J1cG9zX2Rlc2N1ZW50by5waHA=","Z3VhcmRhcl9kZXNjdWVudG9fbWFzaXZvLnBocA==","ZmlsdHJv","YnRuQ2FyZ2Fy","dGJvZHk=","ZXN0YWRv","YnVzY2Fy","cGFnaW5hY2lvbkluZm8=","YnRuUHJldg==","YnRuTmV4dA==","cGFnaW5hY2lvbk51bWVyb3M=","dGFibGVNZXRh","bW9kYWxHcnVwbw==","bV9lbXByZXNhX3Nob3c=","bV9pZGVudGlkYWRfc2hvdw==","bV9pZGdydXBv","bV90aXBvX2FjdHVhbA==","bV9tc2c=","bV9ndWFyZGFy","bW9kYWxNYXNpdm8=","YnRuTWFzaXZv","bWFzaXZvX2VtcHJlc2E=","bWFzaXZvX2lkZ3J1cG8=","bWFzaXZvX2lkZW50aWRhZGVz","bWFzaXZvX21zZw==","YnRuQXBsaWNhck1hc2l2bw==","LmZvcm0tdGV4dA==","","JmFtcDs=","Jmx0Ow==","Jmd0Ow==","JnF1b3Q7","JiMzOTs=","bWVuZGVscw==","YWNham9l","ZGV0b2Rv","Y2hlc3RlcnM=","U2luIGRlc2N1ZW50bw==","MTAl","MjAl","NTAl","TGlzdGFkbyBkZXNkZSBJQ0cgcGFyYSBNZW5kZWxzIChncnVwb3MgMTIsIDEzIHkgMTQpLg==","NDAl","TGlzdGFkbyBkZXNkZSBJQ0cgcGFyYSBBY2Fqb2UgKGdydXBvcyAxNSwgMTYsIDE3IHkgMTgpLg==","TGlzdGFkbyBkZXNkZSBJQ0cgcGFyYSBEZXRvZG8u","TGlzdGFkbyBkZXNkZSBJQ0cgcGFyYSBDaGVzdGVycy4=","LQ==","TGlzdGFkbyBkZXNkZSBJQ0cgc2Vnw7puIGxhIGVtcHJlc2Egc2VsZWNjaW9uYWRhLg==","c21hbGw=","P2VtcHJlc2E9","JmlkZW50aWRhZD0=","bm8tc3RvcmU=","c2FtZS1vcmlnaW4=","Tm8gc2UgcHVkbyBjYXJnYXIgKHJlc3B1ZXN0YSBubyBKU09OKS4=","c21hbGwgdGV4dC1kYW5nZXI=","VVJMIGdydXBvczo=","UmVzcHVlc3RhIGdydXBvczo=","c2VsZWN0ZWQ=","YmVmb3JlZW5k","RXJyb3IgY2FyZ2FuZG8gZGVzY3VlbnRvcyBkZXNkZSBJQ0cu","UXVpdGFyIGRlc2N1ZW50byAoMCk=","Q29tcGxldGEgdG9kb3MgbG9zIGNhbXBvcy4=","UXVpdGFuZG8gZGVzY3VlbnRvcy4uLg==","QXBsaWNhbmRvIGRlc2N1ZW50b3MuLi4=","c21hbGwgdGV4dC1zZWNvbmRhcnk=","ZW1wcmVzYQ==","aWRncnVwbw==","aWRlbnRpZGFkZXM=","UE9TVA==","RXJyb3I=","RGVzY3VlbnRvcyBxdWl0YWRvcyBjb3JyZWN0YW1lbnRl","RGVzY3VlbnRvcyBhcGxpY2Fkb3MgY29ycmVjdGFtZW50ZQ==","c21hbGwgdGV4dC1zdWNjZXNz","Lm1vZGFsLWRpYWxvZw==","Lm1vZGFsLWhlYWRlcg==","bW92ZQ==","bW91c2Vkb3du","Zml4ZWQ=","MA==","cHg=","bW91c2Vtb3Zl","bW91c2V1cA==","YWN0aXZl","MQ==","LnBhZ2UtcGlsbA==","Q2FyZ2FuZG8uLi4=","dG9kb3M=","cGFnZQ==","cGVyX3BhZ2U=","bWF4X2V2bw==","MTUwMDAw","cQ==","Pw==","Y29u","c2lu","LmJ0bi1hYnJpci1ncnVwbw==","SWRlbnRpZGFkIHZhY8OtYSAoZWwgYm90w7NuIG5vIHRyYWUgZGF0YS1pZGVudGlkYWQpLg==","RW1wcmVzYSBpbnbDoWxpZGEu","SWRlbnRpZGFkIHZhY8OtYS4=","U2VsZWNjaW9uYSB1biBkZXNjdWVudG8gdsOhbGlkbyBwYXJhIGVzdGEgZW1wcmVzYS4=","R3VhcmRhbmRvLi4u","aWRlbnRpZGFk","IHwg","RGVzY3VlbnRvIGFjdHVhbGl6YWRvIGNvcnJlY3RhbWVudGU=","Y2xpY2s=","Y2hhbmdl","a2V5ZG93bg==","RW50ZXI="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(() => {
    if (window.__COLAB_VIEW__?.destroy)
        window.__COLAB_VIEW__.destroy();
    const VIEW = {};
    window.__COLAB_VIEW__ = VIEW;
    const BASE = _0x354058e88bd9[0];
    const ENDPOINT_LISTA = _0x354058e88bd9[1];
    const ENDPOINT_GUARDAR = _0x354058e88bd9[2];
    const ENDPOINT_GRUPOS = _0x354058e88bd9[3];
    const ENDPOINT_MASIVO = _0x354058e88bd9[4];
    const PER_PAGE = 100;
    const $ = (id) => document.getElementById(id);
    const $filtro = $(_0x354058e88bd9[5]);
    const $btnCargar = $(_0x354058e88bd9[6]);
    const $tb = $(_0x354058e88bd9[7]);
    const $estado = $(_0x354058e88bd9[8]);
    const $buscar = $(_0x354058e88bd9[9]);
    const $pagInfo = $(_0x354058e88bd9[10]);
    const $btnPrev = $(_0x354058e88bd9[11]);
    const $btnNext = $(_0x354058e88bd9[12]);
    const $pagNums = $(_0x354058e88bd9[13]);
    const $tableMeta = $(_0x354058e88bd9[14]);
    const modalEl = $(_0x354058e88bd9[15]);
    const modal = modalEl && window.bootstrap ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    const $mEmpresaShow = $(_0x354058e88bd9[16]);
    const $mIdentidadShow = $(_0x354058e88bd9[17]);
    const $mIdGrupo = $(_0x354058e88bd9[18]);
    const $mTipoActual = $(_0x354058e88bd9[19]);
    const $mMsg = $(_0x354058e88bd9[20]);
    const $mGuardar = $(_0x354058e88bd9[21]);
    const modalMasivoEl = $(_0x354058e88bd9[22]);
    const modalMasivo = modalMasivoEl && window.bootstrap
        ? bootstrap.Modal.getOrCreateInstance(modalMasivoEl)
        : null;
    const $btnMasivo = $(_0x354058e88bd9[23]);
    const $masivoEmpresa = $(_0x354058e88bd9[24]);
    const $masivoIdGrupo = $(_0x354058e88bd9[25]);
    const $masivoIdentidades = $(_0x354058e88bd9[26]);
    const $masivoMsg = $(_0x354058e88bd9[27]);
    const $btnAplicarMasivo = $(_0x354058e88bd9[28]);
    const $modalHelp = modalEl?.querySelector(_0x354058e88bd9[29]);
    if (!$tb || !$btnCargar || !$filtro || !$buscar || !$estado)
        return;
    if (!modal || !$mEmpresaShow || !$mIdentidadShow || !$mIdGrupo || !$mTipoActual || !$mMsg || !$mGuardar)
        return;
    let paginaActual = 1;
    let totalPages = 1;
    let totalRegistros = 0;
    let searchTimer = null;
    let loadController = null;
    let filaActiva = null;
    function esc(s) {
        return (s ?? _0x354058e88bd9[30]).toString().replace(/[&<>"']/g, m => ({ '&': _0x354058e88bd9[31], '<': _0x354058e88bd9[32], '>': _0x354058e88bd9[33], '"': _0x354058e88bd9[34], "'": _0x354058e88bd9[35] }[m]));
    }
    function setEstado(t) {
        $estado.textContent = t;
    }
    function empresaNorm(v) {
        v = (v || _0x354058e88bd9[30]).toString().trim().toLowerCase();
        const map = {
            "mendels": _0x354058e88bd9[36],
            "acajoe": _0x354058e88bd9[37],
            "detodo": _0x354058e88bd9[38],
            "de todo": _0x354058e88bd9[38],
            "de-todo": _0x354058e88bd9[38],
            "chesters": _0x354058e88bd9[39]
        };
        return map[v] || v;
    }
    const DESCUENTOS_EMPRESA = {
        mendels: {
            grupos: [0, 12, 13, 14],
            labels: {
                0: _0x354058e88bd9[40],
                12: _0x354058e88bd9[41],
                13: _0x354058e88bd9[42],
                14: _0x354058e88bd9[43]
            },
            ayuda: _0x354058e88bd9[44]
        },
        acajoe: {
            grupos: [0, 15, 16, 17, 18],
            labels: {
                0: _0x354058e88bd9[40],
                15: _0x354058e88bd9[41],
                16: _0x354058e88bd9[42],
                17: _0x354058e88bd9[45],
                18: _0x354058e88bd9[43]
            },
            ayuda: _0x354058e88bd9[46]
        },
        detodo: {
            grupos: [0, 12, 13, 14],
            labels: {
                0: _0x354058e88bd9[40],
                12: _0x354058e88bd9[41],
                13: _0x354058e88bd9[42],
                14: _0x354058e88bd9[43]
            },
            ayuda: _0x354058e88bd9[47]
        },
        chesters: {
            grupos: [0, 12, 13, 14],
            labels: {
                0: _0x354058e88bd9[40],
                12: _0x354058e88bd9[41],
                13: _0x354058e88bd9[42],
                14: _0x354058e88bd9[43]
            },
            ayuda: _0x354058e88bd9[48]
        }
    };
    function empresaCfg(empresa) {
        return DESCUENTOS_EMPRESA[empresa] || null;
    }
    function idgrupoLabel(idgrupo, empresa = _0x354058e88bd9[30]) {
        const n = parseInt(idgrupo, 10);
        const cfg = empresaCfg(empresa);
        if (cfg && cfg.labels && cfg.labels[n] !== undefined) {
            return cfg.labels[n];
        }
        if (n === 0)
            return _0x354058e88bd9[40];
        if (n === 12 || n === 15)
            return _0x354058e88bd9[41];
        if (n === 13 || n === 16)
            return _0x354058e88bd9[42];
        if (n === 17)
            return _0x354058e88bd9[45];
        if (n === 14 || n === 18)
            return _0x354058e88bd9[43];
        return _0x354058e88bd9[49];
    }
    function actualizarAyudaModal(empresa) {
        const cfg = empresaCfg(empresa);
        if ($modalHelp) {
            $modalHelp.textContent = cfg?.ayuda || _0x354058e88bd9[50];
        }
    }
    async function cargarDescuentosICG(empresa, identidad) {
        $mIdGrupo.innerHTML = `<option value="">Cargando...</option>`;
        $mGuardar.disabled = true;
        $mMsg.textContent = _0x354058e88bd9[30];
        $mMsg.className = _0x354058e88bd9[51];
        actualizarAyudaModal(empresa);
        try {
            const url = BASE + ENDPOINT_GRUPOS
                + _0x354058e88bd9[52] + encodeURIComponent(empresa)
                + _0x354058e88bd9[53] + encodeURIComponent(identidad);
            const res = await fetch(url, { cache: _0x354058e88bd9[54], credentials: _0x354058e88bd9[55] });
            const text = await res.text();
            let json = null;
            try {
                json = JSON.parse(text);
            }
            catch (e) { }
            if (!json || !json.ok) {
                $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
                $mGuardar.disabled = true;
                $mMsg.textContent = json?.msg ? `Error: ${json.msg}` : _0x354058e88bd9[56];
                $mMsg.className = _0x354058e88bd9[57];
                console.error(_0x354058e88bd9[58], url);
                console.error(_0x354058e88bd9[59], text);
                return false;
            }
            const data = json.data || {};
            const opciones = data.opciones || [];
            const actual = Number(data.idgrupo_actual ?? 0);
            $mTipoActual.textContent = idgrupoLabel(actual, empresa);
            $mIdGrupo.innerHTML = `<option value="">Seleccione descuento...</option>`;
            opciones.forEach(op => {
                const idg = Number(op.idgrupo ?? 0);
                const label = op.label ?? idgrupoLabel(idg, empresa);
                const selected = (idg === actual) ? _0x354058e88bd9[60] : _0x354058e88bd9[30];
                $mIdGrupo.insertAdjacentHTML(_0x354058e88bd9[61], `<option value="${idg}" ${selected}>${esc(label)}</option>`);
            });
            $mGuardar.disabled = false;
            return true;
        }
        catch (e) {
            console.error(e);
            $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
            $mGuardar.disabled = true;
            $mMsg.textContent = _0x354058e88bd9[62];
            $mMsg.className = _0x354058e88bd9[57];
            return false;
        }
    }
    function llenarMasivoGrupos() {
        const empresa = empresaNorm($masivoEmpresa.value || _0x354058e88bd9[30]);
        const cfg = empresaCfg(empresa);
        $masivoIdGrupo.innerHTML = `<option value="">Seleccione descuento...</option>`;
        if (!cfg)
            return;
        cfg.grupos.forEach(idg => {
            const texto = idg === 0
                ? _0x354058e88bd9[63] : `Asignar ${idgrupoLabel(idg, empresa)}`;
            $masivoIdGrupo.insertAdjacentHTML(_0x354058e88bd9[61], `<option value="${idg}">${esc(texto)}</option>`);
        });
    }
    function abrirMasivo() {
        llenarMasivoGrupos();
        $masivoIdentidades.value = _0x354058e88bd9[30];
        $masivoMsg.textContent = _0x354058e88bd9[30];
        modalMasivo.show();
    }
    async function aplicarMasivo() {
        const empresa = empresaNorm($masivoEmpresa.value || _0x354058e88bd9[30]);
        const idgrupoValor = $masivoIdGrupo.value;
        const idgrupo = parseInt(idgrupoValor || _0x354058e88bd9[30], 10);
        const identidades = ($masivoIdentidades.value || _0x354058e88bd9[30]).trim();
        const cfg = empresaCfg(empresa);
        if (!empresa || !cfg || !Number.isInteger(idgrupo) || !cfg.grupos.includes(idgrupo) || !identidades) {
            $masivoMsg.textContent = _0x354058e88bd9[64];
            $masivoMsg.className = _0x354058e88bd9[57];
            return;
        }
        $btnAplicarMasivo.disabled = true;
        $masivoMsg.textContent = idgrupo === 0
            ? _0x354058e88bd9[65] : _0x354058e88bd9[66];
        $masivoMsg.className = _0x354058e88bd9[67];
        try {
            const fd = new FormData();
            fd.append(_0x354058e88bd9[68], empresa);
            fd.append(_0x354058e88bd9[69], String(idgrupo));
            fd.append(_0x354058e88bd9[70], identidades);
            const res = await fetch(BASE + ENDPOINT_MASIVO, {
                method: _0x354058e88bd9[71],
                body: fd,
                credentials: _0x354058e88bd9[55]
            });
            const json = await res.json();
            if (!json.ok) {
                throw new Error(json.msg || _0x354058e88bd9[72]);
            }
            $masivoMsg.textContent = idgrupo === 0
                ? _0x354058e88bd9[73] : _0x354058e88bd9[74];
            $masivoMsg.className = _0x354058e88bd9[75];
            const botonesPorIdentidad = new Map(
                [...$tb.querySelectorAll('.btn-abrir-grupo')].map(btn => [
                    `${btn.dataset.empresa}|${btn.dataset.identidad}`,
                    btn
                ])
            );
            let necesitaRecarga = false;
            for (const detalle of json.data?.detalle || []) {
                const idgrupoNuevo = Number(detalle.idgrupo_nuevo);
                if (!Number.isInteger(idgrupoNuevo))
                    continue;
                const btn = botonesPorIdentidad.get(`${empresa}|${detalle.identidad}`);
                if (btn && actualizarFilaDescuento(btn.closest('tr'), idgrupoNuevo, empresa)) {
                    necesitaRecarga = true;
                }
            }
            if (necesitaRecarga)
                await cargar();
        }
        catch (e) {
            $masivoMsg.textContent = e.message;
            $masivoMsg.className = _0x354058e88bd9[57];
        }
        finally {
            $btnAplicarMasivo.disabled = false;
        }
    }
    function renderTabla(lista) {
        if (!lista || !lista.length) {
            $tb.innerHTML = `<tr><td colspan="8" class="text-secondary">Sin resultados.</td></tr>`;
            return;
        }
        const baseIndex = ((paginaActual - 1) * PER_PAGE);
        $tb.innerHTML = lista.map((r, idx) => {
            const num = baseIndex + idx + 1;
            const empresa = empresaNorm(r.empresa ?? _0x354058e88bd9[30]);
            const badge = r.tiene_descuento
                ? `<span class="badge bg-success">SI</span>`
                : `<span class="badge bg-secondary">NO</span>`;
            const tipo = (r.tipo_descuento && String(r.tipo_descuento).trim())
                ? esc(r.tipo_descuento)
                : (r.tiene_descuento ? idgrupoLabel(r.idgrupo_encontrado ?? 0, empresa) : _0x354058e88bd9[40]);
            return `
        <tr>
          <td class="text-muted fw-semibold">${num}</td>
          <td class="mono">${esc(r.codigo ?? _0x354058e88bd9[30])}</td>
          <td class="mono">${esc(r.identidad ?? _0x354058e88bd9[30])}</td>
          <td title="${esc(r.nombre ?? _0x354058e88bd9[30])}">${esc(r.nombre ?? _0x354058e88bd9[30])}</td>
          <td class="mono">${esc(r.empresa ?? _0x354058e88bd9[30])}</td>
          <td>${badge}</td>
          <td title="${esc(tipo)}">${esc(tipo)}</td>
          <td class="text-end">
            <button type="button"
              class="btn btn-sm btn-outline-primary btn-abrir-grupo"
              data-identidad="${esc(r.identidad_num ?? _0x354058e88bd9[30])}"
              data-identidad-show="${esc(r.identidad ?? _0x354058e88bd9[30])}"
              data-empresa="${esc(r.empresa ?? _0x354058e88bd9[30])}">
              Asignar o Cambiar
            </button>
          </td>
        </tr>
      `;
        }).join(_0x354058e88bd9[30]);
    }
    function renderPaginacion() {
        if (totalRegistros <= 0) {
            $pagInfo.textContent = _0x354058e88bd9[30];
            if ($tableMeta)
                $tableMeta.textContent = _0x354058e88bd9[30];
        }
        else {
            const desde = ((paginaActual - 1) * PER_PAGE) + 1;
            const hasta = Math.min(paginaActual * PER_PAGE, totalRegistros);
            $pagInfo.textContent = `Empleados ${desde}-${hasta} de ${totalRegistros} | Página ${paginaActual} de ${totalPages}`;
            if ($tableMeta) {
                $tableMeta.textContent = `${desde}-${hasta} de ${totalRegistros}`;
            }
        }
        $btnPrev.disabled = paginaActual <= 1;
        $btnNext.disabled = paginaActual >= totalPages;
    }
    function actualizarFilaDescuento(fila, idgrupo, empresa) {
        if (!fila?.isConnected)
            return false;

        const teniaDescuento = fila.cells[5].textContent.trim() === 'SI';
        const tieneDescuento = idgrupo !== 0;
        const filtro = $filtro.value;
        const saleDelFiltro =
            (filtro === 'con' && teniaDescuento && !tieneDescuento)
            || (filtro === 'sin' && !teniaDescuento && tieneDescuento);

        if (saleDelFiltro) {
            fila.remove();
            totalRegistros = Math.max(0, totalRegistros - 1);
            totalPages = Math.max(1, Math.ceil(totalRegistros / PER_PAGE));
            setEstado(filtro === 'con'
                ? `${totalRegistros} con descuento`
                : `${totalRegistros} sin descuento`);
        } else {
            fila.cells[5].innerHTML = tieneDescuento
                ? '<span class="badge bg-success">SI</span>'
                : '<span class="badge bg-secondary">NO</span>';
            fila.cells[6].textContent = idgrupoLabel(idgrupo, empresa);
        }

        renderPaginacion();
        renderPaginacionNumeros();
        return saleDelFiltro && !$tb.querySelector('.btn-abrir-grupo');
    }
    function makeDraggable(modalId) {
        const modal = document.getElementById(modalId);
        const dialog = modal.querySelector(_0x354058e88bd9[76]);
        const header = modal.querySelector(_0x354058e88bd9[77]);
        let isDown = false;
        let offsetX = 0;
        let offsetY = 0;
        header.style.cursor = _0x354058e88bd9[78];
        header.addEventListener(_0x354058e88bd9[79], (e) => {
            isDown = true;
            const rect = dialog.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            dialog.style.position = _0x354058e88bd9[80];
            dialog.style.margin = _0x354058e88bd9[81];
            dialog.style.left = rect.left + _0x354058e88bd9[82];
            dialog.style.top = rect.top + _0x354058e88bd9[82];
            dialog.style.zIndex = 9999;
        });
        document.addEventListener(_0x354058e88bd9[83], (e) => {
            if (!isDown)
                return;
            dialog.style.left = (e.clientX - offsetX) + _0x354058e88bd9[82];
            dialog.style.top = (e.clientY - offsetY) + _0x354058e88bd9[82];
        });
        document.addEventListener(_0x354058e88bd9[84], () => {
            isDown = false;
        });
    }
    function renderPaginacionNumeros() {
        if (!$pagNums)
            return;
        if (totalPages <= 1) {
            $pagNums.innerHTML = _0x354058e88bd9[30];
            return;
        }
        const maxBtns = 7;
        let start = Math.max(1, paginaActual - Math.floor(maxBtns / 2));
        let end = start + maxBtns - 1;
        if (end > totalPages) {
            end = totalPages;
            start = Math.max(1, end - maxBtns + 1);
        }
        const btn = (p, label = null, active = false) => `
      <button type="button" class="page-pill ${active ? _0x354058e88bd9[85] : _0x354058e88bd9[30]}" data-page="${p}">
        ${label ?? p}
      </button>
    `;
        let html = `<div class="pages">`;
        if (start > 1) {
            html += btn(1, _0x354058e88bd9[86], paginaActual === 1);
            if (start > 2)
                html += `<span class="dots">…</span>`;
        }
        for (let p = start; p <= end; p++) {
            html += btn(p, null, p === paginaActual);
        }
        if (end < totalPages) {
            if (end < totalPages - 1)
                html += `<span class="dots">…</span>`;
            html += btn(totalPages, String(totalPages), paginaActual === totalPages);
        }
        html += `</div>`;
        $pagNums.innerHTML = html;
    }
    VIEW.onPagNumsClick = (e) => {
        const b = e.target.closest(_0x354058e88bd9[87]);
        if (!b)
            return;
        const p = parseInt(b.dataset.page || _0x354058e88bd9[86], 10);
        if (!p || p === paginaActual)
            return;
        paginaActual = p;
        cargar();
    };
    async function cargar() {
        if (loadController) {
            loadController.abort();
        }
        loadController = new AbortController();
        const controller = loadController;
        setEstado(_0x354058e88bd9[88]);
        $tb.innerHTML = `<tr><td colspan="8" class="text-secondary">Cargando...</td></tr>`;
        const params = new URLSearchParams();
        params.set(_0x354058e88bd9[5], ($filtro.value || _0x354058e88bd9[89]));
        params.set(_0x354058e88bd9[90], String(paginaActual));
        params.set(_0x354058e88bd9[91], String(PER_PAGE));
        params.set(_0x354058e88bd9[92], _0x354058e88bd9[93]);
        const q = ($buscar.value || _0x354058e88bd9[30]).trim();
        if (q)
            params.set(_0x354058e88bd9[94], q);
        const url = BASE + ENDPOINT_LISTA + _0x354058e88bd9[95] + params.toString();
        try {
            const res = await fetch(url, {
                cache: _0x354058e88bd9[54],
                credentials: _0x354058e88bd9[55],
                signal: controller.signal
            });
            const data = await res.json();
            if (!data.ok) {
                setEstado(_0x354058e88bd9[72]);
                $tb.innerHTML = `<tr><td colspan="8" class="text-danger">${esc(data.msg || _0x354058e88bd9[72])}</td></tr>`;
                return;
            }
            const lista = data.data || [];
            totalRegistros = Number(data.total ?? 0) || 0;
            totalPages = Number(data.total_pages ?? 1) || 1;
            paginaActual = Number(data.page ?? paginaActual) || paginaActual;
            const filtroActual = $filtro.value || _0x354058e88bd9[89];
            let textoEstado = _0x354058e88bd9[30];
            if (filtroActual === _0x354058e88bd9[96]) {
                textoEstado = `${totalRegistros} con descuento`;
            }
            else if (filtroActual === _0x354058e88bd9[97]) {
                textoEstado = `${totalRegistros} sin descuento`;
            }
            else {
                textoEstado = `${totalRegistros} colaboradores`;
            }
            setEstado(textoEstado);
            renderTabla(lista);
            renderPaginacion();
            renderPaginacionNumeros();
        }
        catch (e) {
            if (e.name === 'AbortError')
                return;
            console.error(e);
            setEstado(_0x354058e88bd9[72]);
            $tb.innerHTML = `<tr><td colspan="8" class="text-danger">No se pudo conectar al backend.</td></tr>`;
        }
    }
    VIEW.onDocClick = async (e) => {
        const btn = e.target.closest(_0x354058e88bd9[98]);
        if (!btn)
            return;
        const identidadNum = (btn.dataset.identidad || _0x354058e88bd9[30]).trim();
        const identidadShow = (btn.dataset.identidadShow || _0x354058e88bd9[30]).trim();
        const empresa = empresaNorm(btn.dataset.empresa || _0x354058e88bd9[30]);
        filaActiva = btn.closest('tr');
        modalEl.dataset.identidad = identidadNum;
        modalEl.dataset.empresa = empresa;
        $mIdentidadShow.textContent = identidadShow || identidadNum || _0x354058e88bd9[49];
        $mEmpresaShow.textContent = empresa || _0x354058e88bd9[49];
        $mTipoActual.textContent = _0x354058e88bd9[88];
        $mMsg.textContent = _0x354058e88bd9[30];
        $mMsg.className = _0x354058e88bd9[51];
        actualizarAyudaModal(empresa);
        $mIdGrupo.innerHTML = `<option value="">Cargando descuentos...</option>`;
        $mGuardar.disabled = true;
        modal.show();
        if (!identidadNum) {
            $mIdGrupo.innerHTML = `<option value="">No se pudieron cargar</option>`;
            $mTipoActual.textContent = _0x354058e88bd9[49];
            $mMsg.textContent = _0x354058e88bd9[99];
            $mMsg.className = _0x354058e88bd9[57];
            return;
        }
        cargarDescuentosICG(empresa, identidadNum);
    };
    VIEW.onGuardar = async () => {
        const empresa = empresaNorm(modalEl.dataset.empresa || _0x354058e88bd9[30]);
        const identidad = (modalEl.dataset.identidad || _0x354058e88bd9[30]).trim();
        const idgrupo = parseInt(($mIdGrupo.value || _0x354058e88bd9[30]), 10);
        const cfg = empresaCfg(empresa);
        if (!empresa || !cfg) {
            $mMsg.textContent = _0x354058e88bd9[100];
            $mMsg.className = _0x354058e88bd9[57];
            return;
        }
        if (!identidad) {
            $mMsg.textContent = _0x354058e88bd9[101];
            $mMsg.className = _0x354058e88bd9[57];
            return;
        }
        if (!Number.isInteger(idgrupo) || !cfg.grupos.includes(idgrupo)) {
            $mMsg.textContent = _0x354058e88bd9[102];
            $mMsg.className = _0x354058e88bd9[57];
            return;
        }
        $mGuardar.disabled = true;
        $mMsg.textContent = _0x354058e88bd9[103];
        $mMsg.className = _0x354058e88bd9[67];
        try {
            const url = BASE + ENDPOINT_GUARDAR;
            const fd = new FormData();
            fd.append(_0x354058e88bd9[68], empresa);
            fd.append(_0x354058e88bd9[104], identidad);
            fd.append(_0x354058e88bd9[69], String(idgrupo));
            const res = await fetch(url, {
                method: _0x354058e88bd9[71],
                credentials: _0x354058e88bd9[55],
                body: fd
            });
            const json = await res.json();
            if (!json.ok) {
                throw new Error((json.msg || _0x354058e88bd9[72]) + (json?.extra?.error ? (_0x354058e88bd9[105] + json.extra.error) : _0x354058e88bd9[30]));
            }
            $mTipoActual.textContent = idgrupoLabel(idgrupo, empresa);
            $mMsg.textContent = json.msg || _0x354058e88bd9[106];
            $mMsg.className = _0x354058e88bd9[75];
            if (actualizarFilaDescuento(filaActiva, idgrupo, empresa))
                await cargar();
            setTimeout(() => modal.hide(), 650);
        }
        catch (err) {
            $mMsg.textContent = err.message || _0x354058e88bd9[72];
            $mMsg.className = _0x354058e88bd9[57];
        }
        finally {
            $mGuardar.disabled = false;
        }
    };
    VIEW.bind = () => {
        $btnCargar.addEventListener(_0x354058e88bd9[107], () => {
            clearTimeout(searchTimer);
            paginaActual = 1;
            cargar();
        });
        $filtro.addEventListener(_0x354058e88bd9[108], () => {
            clearTimeout(searchTimer);
            paginaActual = 1;
            cargar();
        });
        $buscar.addEventListener('input', () => {
            clearTimeout(searchTimer);
            paginaActual = 1;
            searchTimer = setTimeout(cargar, 300);
        });
        $buscar.addEventListener(_0x354058e88bd9[109], (e) => {
            if (e.key === _0x354058e88bd9[110]) {
                e.preventDefault();
                clearTimeout(searchTimer);
                paginaActual = 1;
                cargar();
            }
        });
        $btnPrev.addEventListener(_0x354058e88bd9[107], () => {
            if (paginaActual > 1) {
                paginaActual--;
                cargar();
            }
        });
        $btnNext.addEventListener(_0x354058e88bd9[107], () => {
            if (paginaActual < totalPages) {
                paginaActual++;
                cargar();
            }
        });
        document.addEventListener(_0x354058e88bd9[107], VIEW.onDocClick);
        $pagNums.addEventListener(_0x354058e88bd9[107], VIEW.onPagNumsClick);
        $mGuardar.addEventListener(_0x354058e88bd9[107], VIEW.onGuardar);
    };
    VIEW.destroy = () => {
        try {
            clearTimeout(searchTimer);
            if (loadController) {
                loadController.abort();
            }
            document.removeEventListener(_0x354058e88bd9[107], VIEW.onDocClick);
            $pagNums.removeEventListener(_0x354058e88bd9[107], VIEW.onPagNumsClick);
            $mGuardar.removeEventListener(_0x354058e88bd9[107], VIEW.onGuardar);
        }
        catch (e) { }
    };
    VIEW.bind();
    if ($btnMasivo) {
        $btnMasivo.addEventListener(_0x354058e88bd9[107], abrirMasivo);
    }
    if ($masivoEmpresa) {
        $masivoEmpresa.addEventListener(_0x354058e88bd9[108], llenarMasivoGrupos);
    }
    if ($btnAplicarMasivo) {
        $btnAplicarMasivo.addEventListener(_0x354058e88bd9[107], aplicarMasivo);
    }
    if (document.getElementById(_0x354058e88bd9[22])) {
        makeDraggable(_0x354058e88bd9[22]);
    }
})();
