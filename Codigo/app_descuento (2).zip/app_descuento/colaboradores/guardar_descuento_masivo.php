<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');


require_once __DIR__ . '/../usuarios/validar_sesion.php';

if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        'ok'   => false,
        'msg'  => 'Sesión expirada. Inicie sesión nuevamente.',
        'data' => null
    ], JSON_UNESCAPED_UNICODE);
    exit;
}


ob_start();


ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(0);
set_time_limit(300);

/*
 CARGAR CONEXIÓN ICG

*/
require_once __DIR__. "/db_icg.php";


function out(bool $ok, string $msg, $data = null): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    echo json_encode([
        "ok"   => $ok,
        "msg"  => $msg,
        "data" => $data,
    ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

    exit;
}

/*
 NORMALIZAR IDENTIDAD
 Convierte la identidad a solo números.
*/
function norm_id(string $s): string
{
    return preg_replace('/\D+/', '', trim($s)) ?: '';
}

/*
NORMALIZAR EMPRESA

*/
function norm_empresa(string $empresa): string
{
    $empresa = strtolower(trim($empresa));

    $map = [
        'mendels'  => 'mendels',
        'acajoe'   => 'acajoe',
        'detodo'   => 'detodo',
        'de todo'  => 'detodo',
        'de-todo'  => 'detodo',
        'chesters' => 'chesters',
    ];

    return $map[$empresa] ?? $empresa;
}

/*
CONFIGURACIÓN DE DESCUENTOS POR EMPRESA

*/
function config_descuentos(): array
{
    return [
        'mendels' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'acajoe' => [
            'grupos' => [15, 16, 17, 18],
            'labels' => [
                15 => '10%',
                16 => '20%',
                17 => '40%',
                18 => '50%',
            ],
        ],
        'detodo' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
        'chesters' => [
            'grupos' => [12, 13, 14],
            'labels' => [
                12 => '10%',
                13 => '20%',
                14 => '50%',
            ],
        ],
    ];
}

/*
 TEXTO DEL DESCUENTO

*/
function label_descuento(string $empresa, int $idgrupo, array $cfg): string
{
    return $cfg[$empresa]['labels'][$idgrupo] ?? '';
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        out(false, "Método no permitido.");
    }


    /*
     CARGAR CONFIGURACIÓN
    
    */
    $cfg = config_descuentos();

    /*
    RECIBIR EMPRESA
    
    */
    $empresaRaw = (string)($_POST['empresa'] ?? '');
    $empresa = norm_empresa($empresaRaw);

    if (!isset($cfg[$empresa])) {
        out(false, "Empresa inválida");
    }

    /* Leer el descuento que se asignará. */
    $idgrupo = (int)($_POST['idgrupo'] ?? 0);
    $gruposValidos = $cfg[$empresa]['grupos'];

    if ($idgrupo !== 0 && !in_array($idgrupo, $gruposValidos, true)) {
        http_response_code(400);
        out(false, "Grupo de descuento inválido para esta empresa");
    }

    /*
  RECIBIR IDENTIDADES
    
    */
    $identidadesRaw = (string)($_POST['identidades'] ?? '');

    if (trim($identidadesRaw) === '') {
        out(false, "Debes ingresar al menos una identidad");
    }

    /*
     LIMPIAR LISTA DE IDENTIDADES
    Acepta identidades separadas por:
    saltos de línea
    comas
    punto y coma
    
    */
    $partes = preg_split('/[\r\n,;]+/', $identidadesRaw);
    $identidades = [];

    foreach ($partes as $p) {
        $id = norm_id((string)$p);

        if ($id !== '') {
            /*
             Evita identidades duplicadas en el mismo envío.
            
            */
            $identidades[$id] = $id;
        }
    }

    $identidades = array_values($identidades);

    if (!$identidades) {
        out(false, "No se encontraron identidades válidas");
    }

    /*
    CONEXIÓN SQL SERVER / ICG
    
    */
    $pdo = icg_pdo($empresa);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /*
   GRUPOS VÁLIDOS EN SQL
    
    */
    $gruposSql = implode(',', array_map('intval', $gruposValidos));

    /*
   RESULTADO FINAL
    
    */
    $resultado = [
        "empresa"        => $empresa,
        "idgrupo"        => $idgrupo,
        "descuento"      => label_descuento($empresa, $idgrupo, $cfg),
        "procesados"     => 0,
        "aplicados"      => 0,
        "cambiados"      => 0,
        "eliminados"     => 0,
        "ya_existen"     => 0,
        "no_encontrados" => [],
        "errores"        => [],
        "detalle"        => [],
    ];

    /*
  INICIAR TRANSACCIÓN
    
    */
    $pdo->beginTransaction();

       /*
     CONSULTA PARA BUSCAR CLIENTE
     Busca el cliente por identidad limpia ignorando fichas inactivas.
     También trae si ya tiene un descuento válido de esa empresa.
    
    */
    $sqlClientes = "
        WITH ids AS (
            SELECT LTRIM(RTRIM([value])) AS identidad_num
            FROM OPENJSON(?)
            WHERE LTRIM(RTRIM([value])) <> ''
        ),
        grp_valid AS (
            SELECT
                TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) AS CODCLIENTE,
                MAX(IDGRUPO) AS IDGRUPO
            FROM CONDICIONESGRUPOSCLIENTES
            WHERE CAMPO = 'CODCLIENTE'
              AND IDGRUPO IN ($gruposSql)
              AND TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT) IS NOT NULL
            GROUP BY TRY_CAST(LTRIM(RTRIM(VALOR)) AS INT)
        ),
        clientes_candidatos AS (
        SELECT
            ids.identidad_num,
            c.CODCLIENTE,
            LTRIM(RTRIM(ISNULL(c.NOMBRECLIENTE,''))) AS NOMBRECLIENTE,
            LTRIM(RTRIM(ISNULL(c.NIF20,''))) AS NIF20,
            ISNULL(gv.IDGRUPO, 0) AS IDGRUPO_VALIDO,
            ROW_NUMBER() OVER (
                PARTITION BY ids.identidad_num
                ORDER BY
                    CASE WHEN ISNULL(c.BLOQUEADO, 'F') <> 'T' THEN 0 ELSE 1 END,
                    CASE WHEN gv.IDGRUPO IS NOT NULL AND gv.IDGRUPO <> 0 THEN 0 ELSE 1 END,
                    c.CODCLIENTE DESC
            ) AS prioridad
        FROM CLIENTES c
        INNER JOIN ids
            ON ids.identidad_num = REPLACE(
                REPLACE(
                    REPLACE(
                        REPLACE(
                            REPLACE(LTRIM(RTRIM(ISNULL(c.NIF20,''))), '-', ''),
                        ' ', ''),
                    '.', ''),
                '/', ''),
            CHAR(9), '')
        LEFT JOIN grp_valid gv
            ON gv.CODCLIENTE = c.CODCLIENTE
        WHERE ISNULL(c.BLOQUEADO, 'F') <> 'T'
        )
        SELECT identidad_num, CODCLIENTE, NOMBRECLIENTE, NIF20, IDGRUPO_VALIDO
        FROM clientes_candidatos
        WHERE prioridad = 1
    ";

    $stClientes = $pdo->prepare($sqlClientes);
    $identidadesJson = json_encode($identidades, JSON_UNESCAPED_UNICODE);
    if ($identidadesJson === false) {
        throw new RuntimeException("No se pudieron preparar las identidades.");
    }

    $stClientes->execute([$identidadesJson]);
    $clientesPorIdentidad = [];
    foreach ($stClientes->fetchAll(PDO::FETCH_ASSOC) as $cliente) {
        $clientesPorIdentidad[(string)$cliente['identidad_num']] = $cliente;
    }


    /*
    BORRAR DESCUENTOS ANTERIORES DE ESA EMPRESA
    
    */
    $stDel = $pdo->prepare("
        DELETE FROM CONDICIONESGRUPOSCLIENTES
        WHERE CAMPO = 'CODCLIENTE'
          AND LTRIM(RTRIM(VALOR)) = ?
          AND IDGRUPO IN ($gruposSql)
    ");

    /*
    OBTENER GRUPOOR
    
    */
    $stNext = $pdo->prepare("
        SELECT ISNULL(MAX(GRUPOOR), 0) + 1
        FROM CONDICIONESGRUPOSCLIENTES WITH (UPDLOCK, HOLDLOCK)
        WHERE IDGRUPO = ?
    ");

    /*
   INSERTAR NUEVO DESCUENTO
    
    */
    $stIns = $pdo->prepare("
        INSERT INTO CONDICIONESGRUPOSCLIENTES
            (IDGRUPO, GRUPOOR, GRUPOAND, INCLUIR, TABLA, CAMPO, OPERADOR, VALOR)
        VALUES
            (?, ?, 0, 'T', 0, 'CODCLIENTE', '=', ?)
    ");

    /*
 PROCESAR CADA IDENTIDAD
    
    */
    foreach ($identidades as $identidadNum) {

        $resultado["procesados"]++;

        /*
        BUSCAR CLIENTE
        
        */
        $cliente = $clientesPorIdentidad[$identidadNum] ?? null;

        if (!$cliente) {
            $resultado["no_encontrados"][] = $identidadNum;

            $resultado["detalle"][] = [
                "identidad"  => $identidadNum,
                "codcliente" => "",
                "nombre"     => "",
                "accion"     => "NO_ENCONTRADO",
                "mensaje"    => "Cliente no existe en ICG"
            ];

            continue;
        }

        /*
        DATOS DEL CLIENTE
        
        */
        $codcliente = (string)(int)trim((string)($cliente['CODCLIENTE'] ?? '0'));
        $nombre     = trim((string)($cliente['NOMBRECLIENTE'] ?? ''));
        $nif20      = trim((string)($cliente['NIF20'] ?? ''));
        $actual     = (int)($cliente['IDGRUPO_VALIDO'] ?? 0);

        /*
         SI YA TIENE EL MISMO DESCUENTO
        
        | No borra.
        | No inserta.
        | No cuenta como aplicado.
        | No se audita.
        
        */
        if ($actual === $idgrupo) {

            $resultado["ya_existen"]++;

            $resultado["detalle"][] = [
                "identidad"       => $identidadNum,
                "codcliente"      => $codcliente,
                "nombre"          => $nombre,
                "nif20_icg"       => $nif20,
                "idgrupo_actual"  => $actual,
                "idgrupo_nuevo"   => $idgrupo,
                "tipo_descuento"  => label_descuento($empresa, $idgrupo, $cfg),
                "accion"          => "YA_EXISTE",
                "mensaje"         => "Ya existe"
            ];

            continue;
        }

        /*
      BORRAR DESCUENTO ANTERIOR DE ESA EMPRESA
        
        */
        $stDel->execute([$codcliente]);
        if ($idgrupo === 0) {
            $resultado["eliminados"]++;
            $resultado["detalle"][] = [
                "identidad"       => $identidadNum,
                "codcliente"      => $codcliente,
                "nombre"          => $nombre,
                "nif20_icg"       => $nif20,
                "idgrupo_actual"  => $actual,
                "idgrupo_nuevo"   => 0,
                "tipo_descuento"  => "",
                "accion"          => "ELIMINADO",
                "mensaje"         => "Descuento quitado"
            ];
            continue;
        }
        /*
      OBTENER GRUPOOR ÚNICO
        
        */
        $stNext->execute([$idgrupo]);
        $grupoOr = (int)($stNext->fetchColumn() ?? 1);

        if ($grupoOr < 1) {
            $grupoOr = 1;
        }

        /*
      INSERTAR NUEVO DESCUENTO
        
        */
        $stIns->execute([$idgrupo, $grupoOr, $codcliente]);

        /*
      DEFINIR ACCIÓN DEL DETALLE
        
        */
        $resultado["aplicados"]++;

        if ($actual !== 0 && $actual !== $idgrupo) {
            $resultado["cambiados"]++;
            $accionDetalle = "CAMBIADO";
            $mensajeDetalle = "Descuento cambiado";
        } else {
            $accionDetalle = "APLICADO";
            $mensajeDetalle = "Descuento aplicado";
        }

        $resultado["detalle"][] = [
            "identidad"       => $identidadNum,
            "codcliente"      => $codcliente,
            "nombre"          => $nombre,
            "nif20_icg"       => $nif20,
            "idgrupo_actual"  => $actual,
            "idgrupo_nuevo"   => $idgrupo,
            "tipo_descuento"  => label_descuento($empresa, $idgrupo, $cfg),
            "grupoOr"         => $grupoOr,
            "accion"          => $accionDetalle,
            "mensaje"         => $mensajeDetalle
        ];
    }

    /*
     CONFIRMAR TRANSACCIÓN
    
    */
    $pdo->commit();

  
    try {
        require_once __DIR__ . "/../usuarios/conexion.php";

        if (isset($conn) && $conn instanceof mysqli) {

            $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';

            if ($ip === '::1' || $ip === '') {
                $ip = 'LOCALHOST';
            }

            $stmt = $conn->prepare("
                INSERT INTO auditoria (accion, detalle, usuario_id, ip)
                VALUES (?, ?, ?, ?)
            ");

            if ($stmt) {

                foreach ($resultado["detalle"] as $d) {

                    $accionItem = strtoupper(trim((string)($d["accion"] ?? '')));

                    /*
                     No auditar si no hubo cambio.
                    
                    */
                    if (in_array($accionItem, ['YA_EXISTE', 'NO_ENCONTRADO'], true)) {
                        continue;
                    }

                    /*
                     Definir acción para auditoría.
                    
                    */
                    if ($accionItem === 'ELIMINADO') {
                        $accionAud = "DESCUENTO_ELIMINADO";
                    } elseif ($accionItem === 'CAMBIADO') {
                        $accionAud = "DESCUENTO_CAMBIADO_MASIVO";
                    } else {
                        $accionAud = "DESCUENTO_MASIVO";
                    }

                    $codAud = (string)($d["codcliente"] ?? '');
                    $idAud  = (string)($d["identidad"] ?? '');
                    $grupoAnterior = (int)($d["idgrupo_actual"] ?? 0);
                    $grupoNuevo    = (int)($d["idgrupo_nuevo"] ?? 0);

                    $detalle = "ICG={$empresa}"
                        . " | CODCLIENTE={$codAud}"
                        . " | IDGRUPO={$grupoNuevo}"
                        . " | IDGRUPO_ANTERIOR={$grupoAnterior}"
                        . " | IDGRUPO_NUEVO={$grupoNuevo}"
                        . " | IDENTIDAD={$idAud}"
                        . " | MASIVO=SI";

                    $stmt->bind_param(
                        "ssis",
                        $accionAud,
                        $detalle,
                        $usuarioId,
                        $ip
                    );

                    $stmt->execute();
                }

                $stmt->close();
            }
        }
    } catch (Throwable $e) {
      
    }

   
    $aplicados     = (int)($resultado["aplicados"] ?? 0);
    $cambiados     = (int)($resultado["cambiados"] ?? 0);
    $eliminados    = (int)($resultado["eliminados"] ?? 0);
    $yaExisten     = (int)($resultado["ya_existen"] ?? 0);
    $noEncontrados = count($resultado["no_encontrados"] ?? []);

   
    if ($aplicados === 0 && $cambiados === 0 && $eliminados === 0 && $yaExisten > 0) {
        out(false, "Ya existe", $resultado);
    }

    /*
    NO HUBO CAMBIOS Y SOLO HUBO NO ENCONTRADOS
    
    */
    if ($aplicados === 0 && $cambiados === 0 && $eliminados === 0 && $yaExisten === 0 && $noEncontrados > 0) {
        out(false, "No se encontraron clientes válidos en ICG", $resultado);
    }

    /*
    SÍ HUBO CAMBIOS
    
    */
    out(true, "Proceso masivo finalizado", $resultado);

} catch (Throwable $e) {

    /*
   ROLLBACK SI FALLA
    
    */
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
    RESPUESTA DE ERROR
    
    */
    error_log('Descuentos guardar_descuento_masivo: ' . $e->getMessage());
    out(false, "Error al aplicar descuento masivo");
}