<?php

return require dirname(__DIR__, 3) . DIRECTORY_SEPARATOR
    . 'privado_descuento' . DIRECTORY_SEPARATOR . 'credenciales.php';