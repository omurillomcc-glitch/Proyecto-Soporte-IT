<?php
declare(strict_types=1);

require_once dirname(__DIR__) . "/usuarios/validar_sesion.php";
require_admin();
?>

<link rel="stylesheet" href="/app_descuento/usuariosICG/CSS/icg_usuarios.css">

<div class="container-fluid mt-4">

    <div class="card shadow-sm border-0 rounded-4">



        <div class="card-header bg-primary text-white rounded-top-4">
            <h5 class="mb-0">
                <i class="bi bi-person-fill-check"></i>
            </h5>
        </div>

        <div class="card-body">

            <!-- Botones principales -->
            <div class="d-flex gap-2 flex-wrap mb-4">

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalUsuarioUno">
                    <i class="bi bi-person-fill-add"></i>
                    Crear un usuario
                </button>

                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalUsuariosVarios">
                    <i class="bi bi-people-fill"></i>
                    Crear varios usuarios
                </button>

                <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#modalEditarICG">
                    <i class="bi bi-pencil-square"></i>
                    Editar usuario
                </button>

            </div>

            <!-- Resultado general -->
            <div id="respuestaICG"></div>

        </div>
    </div>
</div>


<!-- MODAL CREAR UN USUARIO -->
<div class="modal fade" id="modalUsuarioUno" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header bg-primary text-white rounded-top-4">
                <h5 class="modal-title">
                    <i class="bi bi-person-plus"></i>
                    Crear usuario en ICG
                </h5>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="formUno" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

                <div class="modal-body">

                    <!-- Mensaje dentro del modal -->
                    <div id="msgModalUno" class="alert d-none"></div>

                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label">Empresa</label>
                            <select name="empresa" class="form-select" required>
                                <option value="">Seleccione empresa</option>
                                <option value="detodo">Detodo</option>
                                <option value="mendels">Mendels</option>
                                <option value="acajoe">Acajoe</option>
                                <option value="chesters">Chesters</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Nombre completo</label>
                            <input
                                type="text"
                                name="nombrecliente"
                                class="form-control validar-letras"
                                maxlength="200"
                                required
                            >
                        </div>

                    <!-- IDENTIDAD EN SMALL SE ESCRIBE TEXTO -->


                        <div class="col-md-6">
                            <label class="form-label">Identidad</label>
                            <input
                                type="text"
                                name="nif20"
                                class="form-control validar-documento"
                                placeholder="0801-2000-12345"
                                maxlength="50"
                                required
                            >
                            <small class="text-muted">
                            
                            </small>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Provincia</label>
                            <input
                                type="text"
                                name="provincia"
                                class="form-control validar-letras"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">País</label>
                            <input
                                type="text"
                                name="pais"
                                class="form-control validar-letras"
                                value="HONDURAS"
                                maxlength="100"
                                required
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Población</label>
                            <input
                                type="text"
                                name="poblacion"
                                class="form-control validar-letras"
                                maxlength="100"
                                required
                            >
                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-warning" onclick="limpiarFormularioUno()">
                        <i class="bi bi-eraser"></i>
                        Limpiar
                    </button>

                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
    <i class="bi bi-x-circle"></i>
    Cancelar
</button>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i>
                        Guardar usuario
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>


<!-- MODAL CREAR VARIOS USUARIOS -->
<div class="modal fade" id="modalUsuariosVarios" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header bg-primary text-white rounded-top-4">
                <h5 class="modal-title">
                    <i class="bi bi-people"></i>
                    Crear varios usuarios en ICG
                </h5>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="formVarios" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

                <div class="modal-body">

                    <!-- Mensaje dentro del modal -->
                    <div id="msgModalVarios" class="alert d-none"></div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Empresa</label>
                            <select name="empresa" class="form-select" required>
                                <option value="">Seleccione empresa</option>
                                <option value="detodo">Detodo</option>
                                <option value="mendels">Mendels</option>
                                <option value="acajoe">Acajoe</option>
                                <option value="chesters">Chesters</option>
                            </select>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                            <thead class="table-primary">
                                <tr>
                                    <th>Nombre completo</th>
                                    <th>Identidad</th>
                                    <th>Provincia</th>
                                    <th>País</th>
                                    <th>Población</th>
                                    <th width="70">Quitar</th>
                                </tr>
                            </thead>

                            <tbody id="tbodyUsuarios">
                                <tr>
                                    <td>
                                        <input type="text" name="nombrecliente[]" class="form-control validar-letras" maxlength="200" required>
                                    </td>
                                    <td>
                                        <input type="text" name="nif20[]" class="form-control validar-documento" maxlength="50" placeholder="0801-2000-12345" required>
                                    </td>
                                    <td>
                                        <input type="text" name="provincia[]" class="form-control validar-letras" maxlength="100" required>
                                    </td>
                                    <td>
                                        <input type="text" name="pais[]" class="form-control validar-letras" value="HONDURAS" maxlength="100" required>
                                    </td>
                                    <td>
                                        <input type="text" name="poblacion[]" class="form-control validar-letras" maxlength="100" required>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>

                    <button type="button" class="btn btn-outline-primary" onclick="agregarFila()">
                        <i class="bi bi-plus-circle"></i>
                        Agregar fila
                    </button>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-warning" onclick="limpiarFormularioVarios()">
                        <i class="bi bi-eraser"></i>
                        Limpiar
                    </button>

                   <button type="button" class="btn btn-light" data-bs-dismiss="modal">
    <i class="bi bi-x-circle"></i>
    Cancelar
</button>

                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i>
                        Guardar todos
                    </button>

                </div>

            </form>

        </div>
    </div>
</div>



<!-- MODAL EDITAR USUARIO ICG -->
<div class="modal fade" id="modalEditarICG" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header bg-primary text-white rounded-top-4">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar usuario ICG</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <div id="msgModalEditar" class="alert d-none" role="alert"></div>
                <div class="row g-3 mb-3">
                    <div class="col-md-5">
                        <label class="form-label" for="empresaBuscarICG">Empresa</label>
                        <select id="empresaBuscarICG" class="form-select" required>
                            <option value="">Seleccione empresa</option>
                            <option value="detodo">Detodo</option>
                            <option value="mendels">Mendels</option>
                            <option value="acajoe">Acajoe</option>
                            <option value="chesters">Chesters</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label" for="tipoBuscarICG">Buscar por</label>
                        <select id="tipoBuscarICG" class="form-select">
                            <option value="nif20">Identidad</option>
                            <option value="codcliente">Código ICG</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label" for="valorBuscarICG">Identidad / código</label>
                        <div class="input-group">
                            <input type="text" id="valorBuscarICG" class="form-control" maxlength="50" autocomplete="off">
                            <button class="btn btn-outline-primary" type="button" id="btnBuscarICG">Buscar</button>
                        </div>
                    </div>
                </div>
                <form id="formEditarICG" autocomplete="off" class="d-none">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="empresa" id="empresaEditarICG">
                    <input type="hidden" name="codcliente" id="codigoEditarICG">
                    <div class="alert alert-light border py-2">Código ICG: <strong id="codigoVistaICG"></strong>. Solo se actualizará este registro.</div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre completo</label>
                            <input type="text" class="form-control validar-letras" name="nombrecliente" maxlength="200" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Identidad</label>
                            <input type="text" class="form-control validar-documento" name="nif20" maxlength="50" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Provincia</label>
                            <input type="text" class="form-control validar-letras" name="provincia" maxlength="100" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">País</label>
                            <input type="text" class="form-control validar-letras" name="pais" maxlength="100" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Población</label>
                            <input type="text" class="form-control validar-letras" name="poblacion" maxlength="100" required>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="/app_descuento/usuariosICG/JS/icg_usuarios.js"></script>