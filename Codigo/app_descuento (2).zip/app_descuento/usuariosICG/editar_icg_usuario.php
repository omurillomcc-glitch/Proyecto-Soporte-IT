<?php
/* Editar datos permitidos de un cliente ICG existente. No crea ni elimina registros. */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../usuarios/validar_sesion.php';
require_admin();

function responder_edicion(bool $ok, string $msg): void
{
    echo json_encode(['ok' => $ok, 'msg' => $msg], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    responder_edicion(false, 'Método no permitido.');
}

$empresa = strtolower(trim((string)($_POST['empresa'] ?? '')));
$codigoValor = (string)($_POST['codcliente'] ?? '');
$nombre = trim((string)($_POST['nombrecliente'] ?? ''));
$nif = strtoupper(trim((string)($_POST['nif20'] ?? '')));
$provincia = trim((string)($_POST['provincia'] ?? ''));
$pais = trim((string)($_POST['pais'] ?? ''));
$poblacion = trim((string)($_POST['poblacion'] ?? ''));

if (!in_array($empresa, ['detodo', 'mendels', 'acajoe', 'chesters'], true)) {
    responder_edicion(false, 'Empresa inválida.');
}
if (!ctype_digit($codigoValor) || (float)$codigoValor > 2147483647 || (int)$codigoValor < 1) {
    responder_edicion(false, 'Código ICG inválido.');
}
$codcliente = (int)$codigoValor;

function texto_valido_edicion(string $texto, int $maximo): bool
{
    return $texto !== '' && mb_strlen($texto, 'UTF-8') <= $maximo
        && (bool)preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/u', $texto);
}
foreach ([[$nombre, 200], [$provincia, 100], [$pais, 100], [$poblacion, 100]] as [$texto, $maximo]) {
    if (!texto_valido_edicion($texto, $maximo)) {
        responder_edicion(false, 'Nombre, provincia, país o población inválidos.');
    }
}
$nifNormalizado = strtoupper(str_replace(['-', ' ', '.', '/', '\\', "\t", "\r", "\n"], '', $nif));
if (strlen($nifNormalizado) < 5 || strlen($nifNormalizado) > 50 || !preg_match('/^[A-Z0-9]+$/', $nifNormalizado)) {
    responder_edicion(false, 'Identidad o documento inválido.');
}

require_once __DIR__ . '/../colaboradores/db_icg.php';
require_once __DIR__ . '/../usuarios/conexion.php';

try {
    $pdo = icg_pdo($empresa);
    $pdo->beginTransaction();
    try {
        // Solo localiza y bloquea el registro explícitamente seleccionado.
        $existe = $pdo->prepare('SELECT TOP (1) CODCLIENTE FROM CLIENTES WITH (UPDLOCK, HOLDLOCK) WHERE CODCLIENTE = :codigo');
        $existe->execute([':codigo' => $codcliente]);
        if (!$existe->fetch(PDO::FETCH_ASSOC)) {
            $pdo->rollBack();
            responder_edicion(false, 'El usuario seleccionado ya no existe.');
        }

        // La identidad no puede corresponder a otro cliente ICG.
        $duplicado = $pdo->prepare("SELECT TOP (1) CODCLIENTE FROM CLIENTES
            WHERE CODCLIENTE <> :codigo
            AND UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(NIF20, ''), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '')) = :nif");
        $duplicado->execute([':codigo' => $codcliente, ':nif' => $nifNormalizado]);
        if ($duplicado->fetch(PDO::FETCH_ASSOC)) {
            $pdo->rollBack();
            responder_edicion(false, 'Esta identidad ya corresponde a otro usuario en ICG.');
        }

        // Única escritura SQL Server: actualizar columnas permitidas en CLIENTES.
        $actualizar = $pdo->prepare('UPDATE CLIENTES
            SET NOMBRECLIENTE = :nombre, NIF20 = :nif, PROVINCIA = :provincia,
                PAIS = :pais, POBLACION = :poblacion
            WHERE CODCLIENTE = :codigo');
        $actualizar->execute([
            ':nombre' => $nombre, ':nif' => $nif, ':provincia' => $provincia,
            ':pais' => $pais, ':poblacion' => $poblacion, ':codigo' => $codcliente,
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }

    // Registrar la acción solo en auditoría MySQL local.
    try {
        $stmt = $conn->prepare("INSERT INTO auditoria (usuario_id, accion, detalle, ip, created_at)
            VALUES (?, 'ICG_USUARIO_EDITADO', ?, ?, NOW())");
        if ($stmt) {
            $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
            $detalle = 'ICG_USUARIO=SI | EMPRESA=' . $empresa . ' | CODCLIENTE=' . $codcliente;
            $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
            $stmt->bind_param('iss', $usuarioId, $detalle, $ip);
            $stmt->execute();
            $stmt->close();
        }
    } catch (Throwable $e) {
        error_log('ICG auditoria editar: ' . get_class($e));
    }
    responder_edicion(true, 'Usuario ICG actualizado correctamente.');
} catch (Throwable $e) {
    error_log('ICG editar usuario: ' . get_class($e));
    http_response_code(503);
    responder_edicion(false, 'No se pudo actualizar el usuario en ICG.');
}
