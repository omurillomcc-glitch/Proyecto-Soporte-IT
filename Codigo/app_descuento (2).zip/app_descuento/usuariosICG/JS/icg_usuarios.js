var _0x85dc19db3499=["","JmFtcDs=","Jmx0Ow==","Jmd0Ow==","JnF1b3Q7","JiMzOTs=","LQ==","ZC1ub25l","YWxlcnQgZC1ub25l","LnZhbGlkYXItbGV0cmFz","a2V5ZG93bg==","QmFja3NwYWNl","RGVsZXRl","VGFi","QXJyb3dMZWZ0","QXJyb3dSaWdodA==","SG9tZQ==","RW5k","aW5wdXQ=","cGFzdGU=","LnZhbGlkYXItZG9jdW1lbnRv","dGJvZHlVc3Vhcmlvcw==","YmVmb3JlZW5k","bXNnTW9kYWxWYXJpb3M=","aW5mbw==","PGkgY2xhc3M9ImJpIGJpLXBsdXMtY2lyY2xlIj48L2k+IFNlIGFncmVnw7MgdW5hIG51ZXZhIGZpbGEu","d2FybmluZw==","PGkgY2xhc3M9ImJpIGJpLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIj48L2k+IERlYmUgcXVlZGFyIGFsIG1lbm9zIHVuYSBmaWxhLg==","dHI=","c2Vjb25kYXJ5","PGkgY2xhc3M9ImJpIGJpLXRyYXNoIj48L2k+IEZpbGEgZWxpbWluYWRhLg==","Zm9ybVVubw==","bXNnTW9kYWxVbm8=","PGkgY2xhc3M9ImJpIGJpLWVyYXNlciI+PC9pPiBGb3JtdWxhcmlvIGxpbXBpYWRvLg==","Zm9ybVZhcmlvcw==","PGkgY2xhc3M9ImJpIGJpLWVyYXNlciI+PC9pPiBGb3JtdWxhcmlvIG1hc2l2byBsaW1waWFkby4=","Lm1vZGFsLWJhY2tkcm9w","bW9kYWwtb3Blbg==","bW9kYWxVc3VhcmlvVW5v","bW9kYWxVc3Vhcmlvc1Zhcmlvcw==","cmVzcHVlc3RhSUNH","ZGFuZ2Vy","PGkgY2xhc3M9ImJpIGJpLXgtY2lyY2xlIj48L2k+IA==","RXJyb3Iu","c3VjY2Vzcw==","PGkgY2xhc3M9ImJpIGJpLWNoZWNrLWNpcmNsZSI+PC9pPiBVc3VhcmlvIGd1YXJkYWRvIGV4aXRvc2FtZW50ZS4=","PGkgY2xhc3M9ImJpIGJpLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIj48L2k+IEVsIHVzdWFyaW8geWEgZXhpc3RlIGVuIElDRy4=","PGkgY2xhc3M9ImJpIGJpLXgtY2lyY2xlIj48L2k+IE5vIHNlIHB1ZG8gZ3VhcmRhciBlbCB1c3VhcmlvLg==","c3VibWl0","aW5wdXRbbmFtZT0ibmlmMjAiXQ==","PGkgY2xhc3M9ImJpIGJpLXgtY2lyY2xlIj48L2k+IERvY3VtZW50byBpbnbDoWxpZG8uIFVzZSBpZGVudGlkYWQgaG9uZHVyZcOxYSwgRE5JLCBjw6lkdWxhIG8gcGFzYXBvcnRlIHbDoWxpZG8u","PGkgY2xhc3M9ImJpIGJpLWhvdXJnbGFzcy1zcGxpdCI+PC9pPiBHdWFyZGFuZG8gdXN1YXJpby4uLg==","bW9kbw==","dW5v","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3NJQ0cvZ3VhcmRhcl9pY2dfdXN1YXJpby5waHA=","UE9TVA==","c2FtZS1vcmlnaW4=","PGkgY2xhc3M9ImJpIGJpLXgtY2lyY2xlIj48L2k+IEVycm9yIGFsIGNvbmVjdGFyIGNvbiBlbCBzZXJ2aWRvci4=","aW5wdXRbbmFtZT0ibmlmMjBbXSJd","PGkgY2xhc3M9ImJpIGJpLXgtY2lyY2xlIj48L2k+IEhheSB1biBkb2N1bWVudG8gaW52w6FsaWRvLiBSZXZpc2UgaWRlbnRpZGFkZXMsIEROSSwgY8OpZHVsYXMgbyBwYXNhcG9ydGVzLg==","PGkgY2xhc3M9ImJpIGJpLWhvdXJnbGFzcy1zcGxpdCI+PC9pPiBHdWFyZGFuZG8gdXN1YXJpb3MuLi4=","dmFyaW9z","c2hvdy5icy5tb2RhbA==","bW91c2Vkb3du","Lm1vZGFsLWhlYWRlcg==","Lm1vZGFs","Lm1vZGFsLWRpYWxvZw==","bW91c2Vtb3Zl","bW91c2V1cA==","aGlkZGVuLmJzLm1vZGFs","bW9kYWxFZGl0YXJJQ0c=","YnRuQnVzY2FySUNH","Zm9ybUVkaXRhcklDRw==","ZW1wcmVzYUJ1c2NhcklDRw==","dGlwb0J1c2NhcklDRw==","dmFsb3JCdXNjYXJJQ0c=","bXNnTW9kYWxFZGl0YXI=","QWNjZXNvIGRlbmVnYWRvIG8gc29saWNpdHVkIGV4cGlyYWRhLg==","Tm8gc2UgcHVkbyBjb21wbGV0YXIgbGEgc29saWNpdHVkLg==","Y2hhbmdl","Y2xpY2s=","U2VsZWNjaW9uZSBsYSBlbXByZXNhIGUgaW5ncmVzZSBsYSBpZGVudGlkYWQgbyBlbCBjw7NkaWdvIElDRy4=","QnVzY2FuZG8gdXN1YXJpby4uLg==","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3NJQ0cvYnVzY2FyX2ljZ191c3VhcmlvLnBocD8=","bm8tc3RvcmU=","VXN1YXJpbyBubyBlbmNvbnRyYWRvLg==","Y29kaWdvVmlzdGFJQ0c=","bm9tYnJlY2xpZW50ZQ==","bmlmMjA=","cHJvdmluY2lh","cGFpcw==","cG9ibGFjaW9u","UmV2aXNlIGxvcyBkYXRvcyBhbnRlcyBkZSBndWFyZGFyIGxvcyBjYW1iaW9zLg==","Tm8gc2UgcHVkbyBjb25zdWx0YXIgZWwgdXN1YXJpby4=","SWRlbnRpZGFkIG8gZG9jdW1lbnRvIGludsOhbGlkby4=","YnV0dG9uW3R5cGU9InN1Ym1pdCJd","R3VhcmRhbmRvIGNhbWJpb3MuLi4=","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3NJQ0cvZWRpdGFyX2ljZ191c3VhcmlvLnBocA==","VXN1YXJpbyBhY3R1YWxpemFkby4=","Tm8gc2UgcHVkbyBhY3R1YWxpemFyIGVsIHVzdWFyaW8u","Tm8gc2UgcHVkbyBndWFyZGFyLg=="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
function escapeICGHtml(value) {
    return String(value ?? _0x85dc19db3499[0]).replace(/[&<>"']/g, char => ({
        '&': _0x85dc19db3499[1], '<': _0x85dc19db3499[2], '>': _0x85dc19db3499[3], '"': _0x85dc19db3499[4], "'": _0x85dc19db3499[5]
    })[char]);
}
function limpiarSoloLetras(valor) {
    return valor.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, _0x85dc19db3499[0]);
}
function formatearDocumento(valor) {
    let limpio = valor.toUpperCase().replace(/[^A-Z0-9\-]/g, _0x85dc19db3499[0]);
    let soloNumeros = limpio.replace(/\D/g, _0x85dc19db3499[0]);
    if (/^[0-9\-]*$/.test(limpio)) {
        soloNumeros = soloNumeros.substring(0, 13);
        if (soloNumeros.length > 8) {
            return soloNumeros.substring(0, 4) + _0x85dc19db3499[6] +
                soloNumeros.substring(4, 8) + _0x85dc19db3499[6] +
                soloNumeros.substring(8);
        }
        if (soloNumeros.length > 4) {
            return soloNumeros.substring(0, 4) + _0x85dc19db3499[6] +
                soloNumeros.substring(4);
        }
        return soloNumeros;
    }
    return limpio;
}
function documentoValido(valor) {
    const limpio = valor.trim().toUpperCase();
    if (limpio === _0x85dc19db3499[0]) {
        return false;
    }
    const soloNumeros = limpio.replace(/\D/g, _0x85dc19db3499[0]);
    if (soloNumeros.length === 13 && /^[0-9\-]+$/.test(limpio)) {
        return true;
    }
    return /^[A-Z0-9\-]{5,50}$/.test(limpio);
}
function mostrarMsgModal(id, tipo, mensaje) {
    const box = document.getElementById(id);
    if (!box)
        return;
    box.className = `alert alert-${tipo}`;
    box.innerHTML = mensaje;
    box.classList.remove(_0x85dc19db3499[7]);
}
function ocultarMsgModal(id) {
    const box = document.getElementById(id);
    if (!box)
        return;
    box.className = _0x85dc19db3499[8];
    box.innerHTML = _0x85dc19db3499[0];
}
function aplicarValidacionesICG() {
    document.querySelectorAll(_0x85dc19db3499[9]).forEach(input => {
        input.addEventListener(_0x85dc19db3499[10], function (e) {
            const tecla = e.key;
            const especiales = [
                _0x85dc19db3499[11],
                _0x85dc19db3499[12],
                _0x85dc19db3499[13],
                _0x85dc19db3499[14],
                _0x85dc19db3499[15],
                _0x85dc19db3499[16],
                _0x85dc19db3499[17]
            ];
            if (especiales.includes(tecla))
                return;
            if (!/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]$/.test(tecla)) {
                e.preventDefault();
            }
        });
        input.addEventListener(_0x85dc19db3499[18], function () {
            this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, _0x85dc19db3499[0]);
        });
        input.addEventListener(_0x85dc19db3499[19], function () {
            setTimeout(() => {
                this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ\s]/g, _0x85dc19db3499[0]);
            }, 0);
        });
    });
    document.querySelectorAll(_0x85dc19db3499[20]).forEach(input => {
        input.addEventListener(_0x85dc19db3499[10], function (e) {
            const tecla = e.key;
            const especiales = [
                _0x85dc19db3499[11],
                _0x85dc19db3499[12],
                _0x85dc19db3499[13],
                _0x85dc19db3499[14],
                _0x85dc19db3499[15],
                _0x85dc19db3499[16],
                _0x85dc19db3499[17]
            ];
            if (especiales.includes(tecla))
                return;
            if (!/^[A-Za-z0-9-]$/.test(tecla)) {
                e.preventDefault();
                return;
            }
            const valorActual = this.value.toUpperCase();
            const soloNumeros = valorActual.replace(/\D/g, _0x85dc19db3499[0]);
            if (/^[0-9-]*$/.test(valorActual) && soloNumeros.length >= 13) {
                e.preventDefault();
                return;
            }
        });
        input.addEventListener(_0x85dc19db3499[18], function () {
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9-]/g, _0x85dc19db3499[0]);
            this.value = formatearDocumento(this.value);
        });
        input.addEventListener(_0x85dc19db3499[19], function () {
            setTimeout(() => {
                this.value = this.value.toUpperCase().replace(/[^A-Z0-9-]/g, _0x85dc19db3499[0]);
                this.value = formatearDocumento(this.value);
            }, 0);
        });
    });
}
aplicarValidacionesICG();
function filaMasivaHtml() {
    return `
        <tr>
            <td>
                <input type="text" name="nombrecliente[]" class="form-control validar-letras" maxlength="200" required>
            </td>
            <td>
                <input type="text" name="nif20[]" class="form-control validar-documento" maxlength="50" placeholder="0801-2000-12345" required>
            </td>
            <td>
                <input type="text" name="provincia[]" class="form-control validar-letras" maxlength="100" required>
            </td>
            <td>
                <input type="text" name="pais[]" class="form-control validar-letras" value="HONDURAS" maxlength="100" required>
            </td>
            <td>
                <input type="text" name="poblacion[]" class="form-control validar-letras" maxlength="100" required>
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm" onclick="eliminarFila(this)">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `;
}
function agregarFila() {
    const tbody = document.getElementById(_0x85dc19db3499[21]);
    tbody.insertAdjacentHTML(_0x85dc19db3499[22], filaMasivaHtml());
    aplicarValidacionesICG();
    mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[24], _0x85dc19db3499[25]);
}
function eliminarFila(btn) {
    const tbody = document.getElementById(_0x85dc19db3499[21]);
    if (tbody.rows.length <= 1) {
        mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[26], _0x85dc19db3499[27]);
        return;
    }
    btn.closest(_0x85dc19db3499[28]).remove();
    mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[29], _0x85dc19db3499[30]);
}
function limpiarFormularioUno() {
    const form = document.getElementById(_0x85dc19db3499[31]);
    form.reset();
    mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[26], _0x85dc19db3499[33]);
    aplicarValidacionesICG();
}
function limpiarFormularioVarios() {
    const form = document.getElementById(_0x85dc19db3499[34]);
    const tbody = document.getElementById(_0x85dc19db3499[21]);
    form.reset();
    tbody.innerHTML = filaMasivaHtml();
    aplicarValidacionesICG();
    mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[26], _0x85dc19db3499[35]);
}
function limpiarBootstrapModal() {
    document.querySelectorAll(_0x85dc19db3499[36]).forEach(el => el.remove());
    document.body.classList.remove(_0x85dc19db3499[37]);
    document.body.style.overflow = _0x85dc19db3499[0];
    document.body.style.paddingRight = _0x85dc19db3499[0];
}
function cancelarModalUno() {
    limpiarFormularioUno();
    const modalEl = document.getElementById(_0x85dc19db3499[38]);
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.hide();
    setTimeout(limpiarBootstrapModal, 300);
}
function cancelarModalVarios() {
    limpiarFormularioVarios();
    const modalEl = document.getElementById(_0x85dc19db3499[39]);
    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    modal.hide();
    setTimeout(limpiarBootstrapModal, 300);
}
function pintarRespuesta(data) {
    const respuesta = document.getElementById(_0x85dc19db3499[40]);
    if (!data.ok) {
        respuesta.innerHTML = `
            <div class="alert alert-danger">
                ${escapeICGHtml(data.msg)}
            </div>
        `;
        return;
    }
    let html = `
        <div class="alert alert-success">
            <h6 class="fw-bold mb-2">
                <i class="bi bi-check-circle"></i>
                Proceso finalizado
            </h6>

            <div><strong>Empresa:</strong> ${escapeICGHtml(data.empresa ?? _0x85dc19db3499[6])}</div>
            <div><strong>Insertados:</strong> ${escapeICGHtml(data.insertados)}</div>
            <div><strong>Duplicados:</strong> ${escapeICGHtml(data.duplicados)}</div>
            <div><strong>Errores:</strong> ${escapeICGHtml(data.errores)}</div>
        </div>

        <div class="table-responsive shadow-sm rounded-4">
            <table class="table table-bordered table-sm align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Estado</th>
                        <th>Empresa</th>
                        <th>CODCLIENTE</th>
                       <!-- <th>CODCONTABLE</th> -->
                        <th>Nombre</th>
                        <th>Identidad</th>
                        <th>Provincia</th>
                        <th>País</th>
                        <th>Población</th>
                        <th>Mensaje</th>
                    </tr>
                </thead>
                <tbody>
    `;
    data.detalle.forEach(row => {
        html += `
            <tr>
                <td>${escapeICGHtml(row.estado ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.empresa ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.codcliente ?? _0x85dc19db3499[6])}</td>
              <!-- <td>${row.codcontable ?? _0x85dc19db3499[6]}</td> -->
                <td>${escapeICGHtml(row.nombrecliente ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.nif20 ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.provincia ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.pais ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.poblacion ?? _0x85dc19db3499[6])}</td>
                <td>${escapeICGHtml(row.msg ?? _0x85dc19db3499[6])}</td>
            </tr>
        `;
    });
    html += `
                </tbody>
            </table>
        </div>
    `;
    respuesta.innerHTML = html;
}
function pintarResultadoModalUno(data) {
    if (!data.ok) {
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[41], _0x85dc19db3499[42] + (data.msg ?? _0x85dc19db3499[43]));
        return;
    }
    if (data.insertados > 0) {
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[44], _0x85dc19db3499[45]);
        return;
    }
    if (data.duplicados > 0) {
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[26], _0x85dc19db3499[46]);
        return;
    }
    if (data.errores > 0) {
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[41], _0x85dc19db3499[47]);
    }
}
function pintarResultadoModalVarios(data) {
    if (!data.ok) {
        mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[41], _0x85dc19db3499[42] + (data.msg ?? _0x85dc19db3499[43]));
        return;
    }
    mostrarMsgModal(_0x85dc19db3499[23], data.errores > 0 ? _0x85dc19db3499[26] : _0x85dc19db3499[44], `
        <i class="bi bi-check-circle"></i>
        Proceso finalizado.
        Insertados: ${data.insertados},
        Duplicados: ${data.duplicados},
        Errores: ${data.errores}.
        `);
}
document.getElementById(_0x85dc19db3499[31]).addEventListener(_0x85dc19db3499[48], function (e) {
    e.preventDefault();
    const form = this;
    const doc = form.querySelector(_0x85dc19db3499[49]);
    ocultarMsgModal(_0x85dc19db3499[32]);
    doc.value = formatearDocumento(doc.value);
    if (!documentoValido(doc.value)) {
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[41], _0x85dc19db3499[50]);
        doc.focus();
        return;
    }
    mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[24], _0x85dc19db3499[51]);
    const datos = new FormData(form);
    datos.append(_0x85dc19db3499[52], _0x85dc19db3499[53]);
    fetch(_0x85dc19db3499[54], {
        method: _0x85dc19db3499[55],
        body: datos,
        credentials: _0x85dc19db3499[56]
    })
        .then(res => res.text())
        .then(texto => {
        const data = JSON.parse(texto);
        pintarRespuesta(data);
        pintarResultadoModalUno(data);
        if (data.ok && data.insertados > 0) {
            setTimeout(() => {
                form.reset();
                const modal = bootstrap.Modal.getInstance(document.getElementById(_0x85dc19db3499[38]));
                modal.hide();
            }, 900);
        }
    })
        .catch(error => {
        console.error(error);
        mostrarMsgModal(_0x85dc19db3499[32], _0x85dc19db3499[41], _0x85dc19db3499[57]);
    });
});
document.getElementById(_0x85dc19db3499[34]).addEventListener(_0x85dc19db3499[48], function (e) {
    e.preventDefault();
    const form = this;
    const docs = form.querySelectorAll(_0x85dc19db3499[58]);
    ocultarMsgModal(_0x85dc19db3499[23]);
    for (const input of docs) {
        input.value = formatearDocumento(input.value);
        if (!documentoValido(input.value)) {
            mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[41], _0x85dc19db3499[59]);
            input.focus();
            return;
        }
    }
    mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[24], _0x85dc19db3499[60]);
    const datos = new FormData(form);
    datos.append(_0x85dc19db3499[52], _0x85dc19db3499[61]);
    fetch(_0x85dc19db3499[54], {
        method: _0x85dc19db3499[55],
        body: datos,
        credentials: _0x85dc19db3499[56]
    })
        .then(res => res.text())
        .then(texto => {
        const data = JSON.parse(texto);
        pintarRespuesta(data);
        pintarResultadoModalVarios(data);
        if (data.ok && data.insertados > 0) {
            setTimeout(() => {
                const modal = bootstrap.Modal.getInstance(document.getElementById(_0x85dc19db3499[39]));
                modal.hide();
            }, 1200);
        }
    })
        .catch(error => {
        console.error(error);
        mostrarMsgModal(_0x85dc19db3499[23], _0x85dc19db3499[41], _0x85dc19db3499[57]);
    });
});
document.getElementById(_0x85dc19db3499[38]).addEventListener(_0x85dc19db3499[62], function () {
    ocultarMsgModal(_0x85dc19db3499[32]);
});
document.getElementById(_0x85dc19db3499[39]).addEventListener(_0x85dc19db3499[62], function () {
    ocultarMsgModal(_0x85dc19db3499[23]);
});
var modalMoviendo = null;
var modalDialog = null;
var inicioX = 0;
var inicioY = 0;
var moverX = 0;
var moverY = 0;
document.addEventListener(_0x85dc19db3499[63], function (e) {
    const header = e.target.closest(_0x85dc19db3499[64]);
    if (!header)
        return;
    const modal = header.closest(_0x85dc19db3499[65]);
    const dialog = modal.querySelector(_0x85dc19db3499[66]);
    if (!modal || !dialog)
        return;
    modalMoviendo = modal;
    modalDialog = dialog;
    inicioX = e.clientX - moverX;
    inicioY = e.clientY - moverY;
    document.addEventListener(_0x85dc19db3499[67], moverModal);
    document.addEventListener(_0x85dc19db3499[68], detenerModal);
});
function moverModal(e) {
    if (!modalMoviendo || !modalDialog)
        return;
    moverX = e.clientX - inicioX;
    moverY = e.clientY - inicioY;
    modalDialog.style.transform = `translate(${moverX}px, ${moverY}px)`;
}
function detenerModal() {
    document.removeEventListener(_0x85dc19db3499[67], moverModal);
    document.removeEventListener(_0x85dc19db3499[68], detenerModal);
    modalMoviendo = null;
    modalDialog = null;
}
document.querySelectorAll(_0x85dc19db3499[65]).forEach(modal => {
    modal.addEventListener(_0x85dc19db3499[69], function () {
        const dialog = modal.querySelector(_0x85dc19db3499[66]);
        if (dialog) {
            dialog.style.transform = _0x85dc19db3499[0];
        }
        moverX = 0;
        moverY = 0;
        document.querySelectorAll(_0x85dc19db3499[36]).forEach(el => el.remove());
        document.body.classList.remove(_0x85dc19db3499[37]);
        document.body.style.overflow = _0x85dc19db3499[0];
        document.body.style.paddingRight = _0x85dc19db3499[0];
    });
});
(function iniciarEdicionICG() {
    const modal = document.getElementById(_0x85dc19db3499[70]);
    if (!modal)
        return;
    const buscar = document.getElementById(_0x85dc19db3499[71]);
    const form = document.getElementById(_0x85dc19db3499[72]);
    const empresa = document.getElementById(_0x85dc19db3499[73]);
    const tipo = document.getElementById(_0x85dc19db3499[74]);
    const valor = document.getElementById(_0x85dc19db3499[75]);
    const msg = document.getElementById(_0x85dc19db3499[76]);
    function mensaje(texto, clase) {
        msg.className = `alert alert-${clase}`;
        msg.textContent = texto;
    }
    function ocultarEdicion() {
        form.classList.add(_0x85dc19db3499[7]);
        form.reset();
    }
    async function respuestaJson(response) {
        if (!response.ok)
            throw new Error(response.status === 403 ? _0x85dc19db3499[77] : _0x85dc19db3499[78]);
        return response.json();
    }
    empresa.addEventListener(_0x85dc19db3499[79], ocultarEdicion);
    tipo.addEventListener(_0x85dc19db3499[79], ocultarEdicion);
    valor.addEventListener(_0x85dc19db3499[18], ocultarEdicion);
    modal.addEventListener(_0x85dc19db3499[62], () => { ocultarEdicion(); msg.className = _0x85dc19db3499[8]; });
    buscar.addEventListener(_0x85dc19db3499[80], async () => {
        ocultarEdicion();
        if (!empresa.value || !valor.value.trim()) {
            mensaje(_0x85dc19db3499[81], _0x85dc19db3499[26]);
            return;
        }
        buscar.disabled = true;
        mensaje(_0x85dc19db3499[82], _0x85dc19db3499[24]);
        try {
            const params = new URLSearchParams({ empresa: empresa.value, tipo: tipo.value, valor: valor.value.trim() });
            const data = await respuestaJson(await fetch(_0x85dc19db3499[83] + params.toString(), { credentials: _0x85dc19db3499[56], cache: _0x85dc19db3499[84] }));
            if (!data.ok || !data.usuario) {
                mensaje(data.msg || _0x85dc19db3499[85], _0x85dc19db3499[26]);
                return;
            }
            const u = data.usuario;
            form.elements.empresa.value = empresa.value;
            form.elements.codcliente.value = String(u.codcliente);
            document.getElementById(_0x85dc19db3499[86]).textContent = String(u.codcliente);
            for (const campo of [_0x85dc19db3499[87], _0x85dc19db3499[88], _0x85dc19db3499[89], _0x85dc19db3499[90], _0x85dc19db3499[91]]) {
                form.elements[campo].value = String(u[campo] ?? _0x85dc19db3499[0]);
            }
            form.classList.remove(_0x85dc19db3499[7]);
            mensaje(_0x85dc19db3499[92], _0x85dc19db3499[24]);
        }
        catch (error) {
            mensaje(error.message || _0x85dc19db3499[93], _0x85dc19db3499[41]);
        }
        finally {
            buscar.disabled = false;
        }
    });
    form.addEventListener(_0x85dc19db3499[48], async (event) => {
        event.preventDefault();
        const doc = form.elements.nif20;
        doc.value = formatearDocumento(doc.value);
        if (!documentoValido(doc.value)) {
            mensaje(_0x85dc19db3499[94], _0x85dc19db3499[41]);
            doc.focus();
            return;
        }
        const guardar = form.querySelector(_0x85dc19db3499[95]);
        guardar.disabled = true;
        mensaje(_0x85dc19db3499[96], _0x85dc19db3499[24]);
        try {
            const data = await respuestaJson(await fetch(_0x85dc19db3499[97], {
                method: _0x85dc19db3499[55], credentials: _0x85dc19db3499[56], body: new FormData(form)
            }));
            mensaje(data.msg || (data.ok ? _0x85dc19db3499[98] : _0x85dc19db3499[99]), data.ok ? _0x85dc19db3499[44] : _0x85dc19db3499[41]);
            if (data.ok)
                ocultarEdicion();
        }
        catch (error) {
            mensaje(error.message || _0x85dc19db3499[100], _0x85dc19db3499[41]);
        }
        finally {
            guardar.disabled = false;
        }
    });
})();
