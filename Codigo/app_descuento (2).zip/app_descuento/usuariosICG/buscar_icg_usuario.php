<?php
/* Consulta puntual de un usuario ICG. No modifica información. */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../usuarios/validar_sesion.php';
require_admin();
require_once __DIR__ . '/../colaboradores/db_icg.php';

function responder_busqueda(bool $ok, string $msg, ?array $usuario = null): void
{
    echo json_encode(['ok' => $ok, 'msg' => $msg, 'usuario' => $usuario], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    http_response_code(405);
    responder_busqueda(false, 'Método no permitido.');
}

$empresa = strtolower(trim((string)($_GET['empresa'] ?? '')));
$tipo = (string)($_GET['tipo'] ?? '');
$valor = trim((string)($_GET['valor'] ?? ''));
if (!in_array($empresa, ['detodo', 'mendels', 'acajoe', 'chesters'], true)) {
    responder_busqueda(false, 'Empresa inválida.');
}
if (!in_array($tipo, ['codcliente', 'nif20'], true)) {
    responder_busqueda(false, 'Tipo de búsqueda inválido.');
}
if ($valor === '' || strlen($valor) > 50) {
    responder_busqueda(false, 'Ingrese un código o documento válido.');
}

try {
    $pdo = icg_pdo($empresa);
    $campos = 'CODCLIENTE, NOMBRECLIENTE, NIF20, PROVINCIA, PAIS, POBLACION';
    if ($tipo === 'codcliente') {
        if (!ctype_digit($valor) || (float)$valor > 2147483647 || (int)$valor < 1) {
            responder_busqueda(false, 'Código ICG inválido.');
        }
        $stmt = $pdo->prepare("SELECT TOP (1) {$campos} FROM CLIENTES WHERE CODCLIENTE = :valor");
        $stmt->bindValue(':valor', (int)$valor, PDO::PARAM_INT);
    } else {
        $nif = strtoupper(preg_replace('/[- .\/\\\t\r\n]+/', '', $valor) ?? '');
        if (!preg_match('/^[A-Z0-9]{5,50}$/', $nif)) {
            responder_busqueda(false, 'Identidad o documento inválido.');
        }
        // Leer hasta dos registros para evitar seleccionar uno al azar si existen duplicados.
        $stmt = $pdo->prepare("SELECT TOP (2) {$campos} FROM CLIENTES WHERE
            UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(NIF20, ''), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '')) = :valor");
        $stmt->bindValue(':valor', $nif, PDO::PARAM_STR);
    }
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) responder_busqueda(false, 'No se encontró ningún usuario con esos datos.');
    if (count($rows) > 1) responder_busqueda(false, 'Hay documentos duplicados. Busque por código ICG.');
    $u = $rows[0];
    responder_busqueda(true, 'Usuario encontrado.', [
        'codcliente'    => (int)$u['CODCLIENTE'],
        'nombrecliente' => (string)($u['NOMBRECLIENTE'] ?? ''),
        'nif20'         => (string)($u['NIF20'] ?? ''),
        'provincia'     => (string)($u['PROVINCIA'] ?? ''),
        'pais'          => (string)($u['PAIS'] ?? ''),
        'poblacion'     => (string)($u['POBLACION'] ?? ''),
    ]);
} catch (Throwable $e) {
    error_log('ICG consulta usuario: ' . get_class($e));
    http_response_code(503);
    responder_busqueda(false, 'No fue posible consultar ICG.');
}
