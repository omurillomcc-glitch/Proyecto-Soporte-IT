<?php

declare(strict_types=1);


header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../usuarios/validar_sesion.php';
require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'msg' => 'Método no permitido.'], JSON_UNESCAPED_UNICODE);
    exit;
}


if (empty($_SESSION['usuario_id'])) {
    echo json_encode([
        'ok' => false,
        'msg' => 'Sesión expirada. Inicie sesión nuevamente.',
        'empresa' => null,
        'insertados' => 0,
        'duplicados' => 0,
        'errores' => 1,
        'detalle' => []
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* CARGAR CONEXIONES */
require_once dirname(__DIR__) . '/colaboradores/db_icg.php';
require_once dirname(__DIR__) . '/usuarios/conexion.php';

/* NORMALIZAR DOCUMENTO */
function normalizar_documento_icg(string $doc): string
{
    $doc = strtoupper(trim($doc));

    return str_replace(
        ['-', ' ', '.', '/', '\\', "\t", "\r", "\n"],
        '',
        $doc
    );
}

/* VALIDAR TEXTO */
function texto_valido_icg(string $texto, int $max): bool
{
    $texto = trim($texto);

    if ($texto === '') {
        return false;
    }

    if (mb_strlen($texto, 'UTF-8') > $max) {
        return false;
    }

    return (bool) preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/u', $texto);
}

/* VALIDAR DOCUMENTO */
function documento_valido_icg(string $doc): bool
{
    $docNormalizado = normalizar_documento_icg($doc);

    if ($docNormalizado === '') {
        return false;
    }

    if (strlen($docNormalizado) < 5 || strlen($docNormalizado) > 50) {
        return false;
    }

    return (bool) preg_match('/^[A-Z0-9]+$/', $docNormalizado);
}

/* NOMBRE BONITO DE EMPRESA */
function nombre_empresa_icg(string $empresa): string
{
    return match ($empresa) {
        'detodo'   => 'Detodo',
        'mendels'  => 'Mendels',
        'acajoe'   => 'Acajoe',
        'chesters' => 'Chesters',
        default    => $empresa,
    };
}


function guardar_auditoria_icg_usuario(
    mysqli $conn,
    string $empresa,
    int $codcliente,
    string $nombrecliente,
    string $nif20
): void {
    $usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    $empresaBonita = nombre_empresa_icg($empresa);

    $detalle = "ICG_USUARIO=SI | EMPRESA={$empresaBonita} | CODCLIENTE={$codcliente} | NOMBRE={$nombrecliente} | IDENTIDAD={$nif20}";

    $stmt = $conn->prepare("
        INSERT INTO auditoria (usuario_id, accion, detalle, ip, created_at)
        VALUES (?, 'ICG_USUARIO_CREADO', ?, ?, NOW())
    ");

    if (!$stmt) {
        return;
    }

    $stmt->bind_param('iss', $usuarioId, $detalle, $ip);
    $stmt->execute();
    $stmt->close();
}

/* RESPUESTA BASE */
$respuesta = [
    'ok' => true,
    'msg' => '',
    'empresa' => null,
    'insertados' => 0,
    'duplicados' => 0,
    'errores' => 0,
    'detalle' => []
];

try {

    /* VALIDAR EMPRESA */
    $empresa = strtolower(trim((string)($_POST['empresa'] ?? '')));

    $empresasPermitidas = ['detodo', 'mendels', 'acajoe', 'chesters'];

    if (!in_array($empresa, $empresasPermitidas, true)) {
        throw new Exception('Empresa no válida.');
    }

    $respuesta['empresa'] = nombre_empresa_icg($empresa);

    /* CONECTAR A ICG SEGÚN EMPRESA */
    $pdo = icg_pdo($empresa);

    /* DETECTAR MODO UNO O VARIOS */
    $modo = trim((string)($_POST['modo'] ?? 'uno'));

    $usuarios = [];

    /* ARMAR ARREGLO SI ES UN SOLO USUARIO */
    if ($modo === 'uno') {

        $usuarios[] = [
            'nombrecliente' => trim((string)($_POST['nombrecliente'] ?? '')),
            'nif20'         => strtoupper(trim((string)($_POST['nif20'] ?? ''))),
            'provincia'     => trim((string)($_POST['provincia'] ?? '')),
            'pais'          => trim((string)($_POST['pais'] ?? '')),
            'poblacion'     => trim((string)($_POST['poblacion'] ?? ''))
        ];

    } else {

        /* ARMAR ARREGLO SI SON VARIOS USUARIOS */
        $nombres     = $_POST['nombrecliente'] ?? [];
        $nifs        = $_POST['nif20'] ?? [];
        $provincias  = $_POST['provincia'] ?? [];
        $paises      = $_POST['pais'] ?? [];
        $poblaciones = $_POST['poblacion'] ?? [];

        if (!is_array($nombres) || !is_array($nifs) || !is_array($provincias) || !is_array($paises) || !is_array($poblaciones)) {
            throw new Exception('Datos inválidos.');
        }
        $total = count($nombres);
        if ($total < 1 || $total > 100) {
            throw new Exception('Se permiten entre 1 y 100 usuarios por operación.');
        }

        for ($i = 0; $i < $total; $i++) {
            $usuarios[] = [
                'nombrecliente' => trim((string)($nombres[$i] ?? '')),
                'nif20'         => strtoupper(trim((string)($nifs[$i] ?? ''))),
                'provincia'     => trim((string)($provincias[$i] ?? '')),
                'pais'          => trim((string)($paises[$i] ?? '')),
                'poblacion'     => trim((string)($poblaciones[$i] ?? ''))
            ];
        }
    }

    /* CONSULTA PARA VALIDAR DUPLICADO POR NIF20 */
    $sqlExiste = "
        SELECT TOP 1 CODCLIENTE
        FROM CLIENTES
        WHERE UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(NIF20, ''), '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), '')) =
              UPPER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(:nif20, '-', ''), ' ', ''), '.', ''), '/', ''), CHAR(9), ''))
    ";

    $stmtExiste = $pdo->prepare($sqlExiste);

    /* CONSULTA PARA GENERAR CODCLIENTE AUTOMÁTICO */
    $sqlCod = "
        SELECT ISNULL(MAX(CODCLIENTE), 0) + 1 AS nuevo_codigo
        FROM CLIENTES WITH (UPDLOCK, HOLDLOCK)
    ";

    /* CONSULTA PARA INSERTAR CLIENTE */
    $sqlInsert = "
        INSERT INTO CLIENTES
        (
            CODCLIENTE,
            CODCONTABLE,
            NOMBRECLIENTE,
            PROVINCIA,
            PAIS,
            POBLACION,
            NIF20
        )
        VALUES
        (
            :codcliente,
            101020100000,
            :nombrecliente,
            :provincia,
            :pais,
            :poblacion,
            :nif20
        )
    ";

    $stmtInsert = $pdo->prepare($sqlInsert);

    /* EVITAR DUPLICADOS EN EL MISMO FORMULARIO */
    $vistosEnPantalla = [];

    /* RECORRER USUARIOS */
    foreach ($usuarios as $u) {

        $nombrecliente = trim((string)$u['nombrecliente']);
        $nif20         = strtoupper(trim((string)$u['nif20']));
        $provincia     = trim((string)$u['provincia']);
        $pais          = trim((string)$u['pais']);
        $poblacion     = trim((string)$u['poblacion']);

        $docNormalizado = normalizar_documento_icg($nif20);

        /* VALIDAR NOMBRE */
        if (!texto_valido_icg($nombrecliente, 200)) {
            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Nombre inválido. Solo se permiten letras y espacios.'
            ];
            continue;
        }

        /* VALIDAR PROVINCIA */
        if (!texto_valido_icg($provincia, 100)) {
            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Provincia inválida. Solo se permiten letras y espacios.'
            ];
            continue;
        }

        /* VALIDAR PAÍS */
        if (!texto_valido_icg($pais, 100)) {
            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'País inválido. Solo se permiten letras y espacios.'
            ];
            continue;
        }

        /* VALIDAR POBLACIÓN */
        if (!texto_valido_icg($poblacion, 100)) {
            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Población inválida. Solo se permiten letras y espacios.'
            ];
            continue;
        }

        /* VALIDAR DOCUMENTO */
        if (!documento_valido_icg($nif20)) {
            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Documento inválido. Use identidad, DNI, cédula o pasaporte válido.'
            ];
            continue;
        }

        /* VALIDAR DUPLICADO EN EL MISMO FORMULARIO */
        if (isset($vistosEnPantalla[$docNormalizado])) {
            $respuesta['duplicados']++;
            $respuesta['detalle'][] = [
                'estado' => 'DUPLICADO',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Documento repetido en el formulario.'
            ];
            continue;
        }

        $vistosEnPantalla[$docNormalizado] = true;

        /* INICIAR TRANSACCIÓN EN SQL SERVER */
        $pdo->beginTransaction();

        try {

            /* VALIDAR SI YA EXISTE EN CLIENTES */
            $stmtExiste->execute([
                ':nif20' => $nif20
            ]);

            $existe = $stmtExiste->fetch(PDO::FETCH_ASSOC);

            if ($existe) {
                $pdo->rollBack();

                $respuesta['duplicados']++;
                $respuesta['detalle'][] = [
                    'estado' => 'YA EXISTE',
                    'empresa' => nombre_empresa_icg($empresa),
                    'codcliente' => $existe['CODCLIENTE'] ?? null,
                    'codcontable' => '101020100000',
                    'nombrecliente' => $nombrecliente,
                    'nif20' => $nif20,
                    'provincia' => $provincia,
                    'pais' => $pais,
                    'poblacion' => $poblacion,
                    'msg' => 'No se insertó.'
                ];
                continue;
            }

            /* GENERAR NUEVO CODCLIENTE */
            $stmtCod = $pdo->query($sqlCod);
            $rowCod = $stmtCod->fetch(PDO::FETCH_ASSOC);

            $codcliente = (int)($rowCod['nuevo_codigo'] ?? 0);

            if ($codcliente <= 0) {
                throw new Exception('No se pudo generar el CODCLIENTE.');
            }

            /* INSERTAR EN CLIENTES */
            $stmtInsert->execute([
                ':codcliente'    => $codcliente,
                ':nombrecliente' => $nombrecliente,
                ':provincia'     => $provincia,
                ':pais'          => $pais,
                ':poblacion'     => $poblacion,
                ':nif20'         => $nif20
            ]);

            /* CONFIRMAR TRANSACCIÓN SQL SERVER */
            $pdo->commit();

            /* GUARDAR AUDITORÍA MYSQL */
            try {
                guardar_auditoria_icg_usuario(
                    $conn,
                    $empresa,
                    $codcliente,
                    $nombrecliente,
                    $nif20
                );
            } catch (Throwable $e) {
                // No detenemos el proceso si falla auditoría.
            }

            /* AGREGAR RESULTADO INSERTADO */
            $respuesta['insertados']++;
            $respuesta['detalle'][] = [
                'estado' => 'INSERTADO',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => $codcliente,
                'codcontable' => '101020100000',
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'Usuario creado correctamente.'
            ];

        } catch (Throwable $e) {

            /* SI FALLA, REVERTIR TRANSACCIÓN */
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $respuesta['errores']++;
            $respuesta['detalle'][] = [
                'estado' => 'ERROR',
                'empresa' => nombre_empresa_icg($empresa),
                'codcliente' => null,
                'codcontable' => null,
                'nombrecliente' => $nombrecliente,
                'nif20' => $nif20,
                'provincia' => $provincia,
                'pais' => $pais,
                'poblacion' => $poblacion,
                'msg' => 'No se pudo guardar este usuario. Consulte al administrador.'
            ];
        }
    }

    /* RESPUESTA FINAL */
    $respuesta['msg'] = 'Proceso finalizado.';

    echo json_encode($respuesta, JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {

    /* ERROR GENERAL */
    echo json_encode([
        'ok' => false,
        'msg' => 'No se pudo guardar este usuario. Consulte al administrador.',
        'empresa' => null,
        'insertados' => 0,
        'duplicados' => 0,
        'errores' => 1,
        'detalle' => []
    ], JSON_UNESCAPED_UNICODE);
    exit;
}