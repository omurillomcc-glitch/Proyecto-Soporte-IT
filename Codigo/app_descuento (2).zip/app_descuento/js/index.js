var _0x3f689a613b62=["bWV0YVtuYW1lPSJjc3JmLXRva2VuIl0=","","R0VU","UE9TVA==","c2FtZS1vcmlnaW4=","WC1DU1JGLVRva2Vu","Y3NyZl90b2tlbg==","RE9NQ29udGVudExvYWRlZA==","Y29udGVuaWRvLXByaW5jaXBhbA==","RVJST1I6IE5vIGV4aXN0ZSBlbCBjb250ZW5lZG9yICNjb250ZW5pZG8tcHJpbmNpcGFs","Jg==","JmFtcDs=","PA==","Jmx0Ow==","Pg==","Jmd0Ow==","Ig==","JnF1b3Q7","Jw==","JiMwMzk7","c2NyaXB0","bG9hZA==","ZXJyb3I=","Lm1vZGFsLnNob3c=","Lm1vZGFsLWJhY2tkcm9w","bW9kYWwtb3Blbg==","Lm1lbnUtbGluaw==","YWN0aXZl","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3Mv","L2FwcF9kZXNjdWVudG8vdXN1YXJpb3NJQ0cv","YnRuVXNlcnNEZXNr","YnRuVXNlcnNNb2I=","bW9iaWxlU2lkZWJhcg==","c2hvdw==","dGV4dC9odG1s","bGlua1tyZWx+PSJzdHlsZXNoZWV0Il0=","aHJlZg==","L2FwcF9kZXNjdWVudG8v","bGlua1tkYXRhLXZpZXctc3R5bGVzaGVldF0=","bGluaw==","c3R5bGVzaGVldA==","dHJ1ZQ==","bm8tc3RvcmU=","L3VzdWFyaW9zL2xvZ2lu","bG9naW4uaHRtbA==","bG9naW4ucGhw","ZnVuY3Rpb24=","RkVUQ0g=","RmFpbGVk","Y2xpY2s=","YVtkYXRhLXBhZ2Vd","ZGF0YS1wYWdl","Y29udGV4dG1lbnU=","a2V5ZG93bg==","L2FwcF9kZXNjdWVudG8vaG9tZS5waHA="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
(() => {
    const csrf = document.querySelector(_0x3f689a613b62[0])?.content || _0x3f689a613b62[1];
    const originalFetch = window.fetch.bind(window);
    window.fetch = (input, init = {}) => {
        const method = String(init.method || _0x3f689a613b62[2]).toUpperCase();
        if (method === _0x3f689a613b62[3]) {
            init.credentials = init.credentials || _0x3f689a613b62[4];
            init.headers = new Headers(init.headers || {});
            init.headers.set(_0x3f689a613b62[5], csrf);
            if (init.body instanceof FormData && !init.body.has(_0x3f689a613b62[6])) {
                init.body.append(_0x3f689a613b62[6], csrf);
            }
        }
        return originalFetch(input, init);
    };
})();
document.addEventListener(_0x3f689a613b62[7], () => {
    const contenedor = document.getElementById(_0x3f689a613b62[8]);
    if (!contenedor) {
        alert(_0x3f689a613b62[9]);
        return;
    }
    function loader() {
        contenedor.innerHTML = `
      <div class="p-3">
        <div class="spinner-border text-primary" role="status" aria-label="Cargando"></div>
        <span class="ms-2">Cargando...</span>
      </div>
    `;
    }
    function escaparHtml(texto) {
        return String(texto ?? _0x3f689a613b62[1])
            .replaceAll(_0x3f689a613b62[10], _0x3f689a613b62[11])
            .replaceAll(_0x3f689a613b62[12], _0x3f689a613b62[13])
            .replaceAll(_0x3f689a613b62[14], _0x3f689a613b62[15])
            .replaceAll(_0x3f689a613b62[16], _0x3f689a613b62[17])
            .replaceAll(_0x3f689a613b62[18], _0x3f689a613b62[19]);
    }
    function mostrarError(pagina, status, statusText, body) {
        contenedor.innerHTML = `
      <div class="alert alert-danger">
        <b>Error cargando:</b> ${escaparHtml(pagina)}<br>
        <b>HTTP:</b> ${escaparHtml(status)} ${escaparHtml(statusText)}
        <hr>
        <pre class="mb-0 error-body error-body-lg">${escaparHtml(body || _0x3f689a613b62[1])}</pre>
      </div>
    `;
    }
    async function ejecutarScriptsEn(wrapper) {
        const scripts = wrapper.querySelectorAll(_0x3f689a613b62[20]);
        for (const oldScript of scripts) {
            const newScript = document.createElement(_0x3f689a613b62[20]);
            [...oldScript.attributes].forEach(attr => {
                newScript.setAttribute(attr.name, attr.value);
            });
            newScript.text = oldScript.textContent;
            if (newScript.src) {
                await new Promise((resolve, reject) => {
                    newScript.addEventListener(_0x3f689a613b62[21], resolve, { once: true });
                    newScript.addEventListener(_0x3f689a613b62[22], () => {
                        reject(new Error(`No se pudo cargar el script ${newScript.src}`));
                    }, { once: true });
                    oldScript.parentNode.replaceChild(newScript, oldScript);
                });
            }
            else {
                oldScript.parentNode.replaceChild(newScript, oldScript);
            }
        }
    }
    function limpiarModalesBootstrap() {
        document.querySelectorAll(_0x3f689a613b62[23]).forEach(modalEl => {
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }
        });
        document.querySelectorAll(_0x3f689a613b62[24]).forEach(backdrop => backdrop.remove());
        document.body.classList.remove(_0x3f689a613b62[25]);
        document.body.style.overflow = _0x3f689a613b62[1];
        document.body.style.paddingRight = _0x3f689a613b62[1];
    }
    function marcarMenuActivo(pagina) {
        document.querySelectorAll(_0x3f689a613b62[26]).forEach(link => {
            link.classList.remove(_0x3f689a613b62[27]);
        });
        document.querySelectorAll(`a[data-page="${pagina}"]`).forEach(link => {
            link.classList.add(_0x3f689a613b62[27]);
        });
    }
    function controlarSubmenuUsuarios(pagina) {
        const esUsuarios = pagina.includes(_0x3f689a613b62[28]) || pagina.includes(_0x3f689a613b62[29]);
        [_0x3f689a613b62[30], _0x3f689a613b62[31]].forEach(id => {
            const button = document.getElementById(id);
            if (button)
                button.classList.toggle(_0x3f689a613b62[27], esUsuarios);
        });
    }
    function cerrarMenuMovil() {
        const offcanvasEl = document.getElementById(_0x3f689a613b62[32]);
        if (offcanvasEl && offcanvasEl.classList.contains(_0x3f689a613b62[33]) && window.bootstrap) {
            const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasEl);
            if (offcanvas) {
                offcanvas.hide();
            }
        }
    }
    async function prepararVista(html) {
        const vista = new DOMParser().parseFromString(html, _0x3f689a613b62[34]);
        const estilos = [...vista.querySelectorAll(_0x3f689a613b62[35])]
            .map(link => new URL(link.getAttribute(_0x3f689a613b62[36]), window.location.href))
            .filter(url => url.origin === window.location.origin && url.pathname.startsWith(_0x3f689a613b62[37]));
        const hrefs = [...new Set(estilos.map(url => url.href))];
        const actuales = [...document.head.querySelectorAll(_0x3f689a613b62[38])];
        const hojasEnHead = [...document.head.querySelectorAll(_0x3f689a613b62[35])];
        const pendientes = [];
        hrefs.forEach(href => {
            if (hojasEnHead.some(link => link.href === href)) {
                return;
            }
            const link = document.createElement(_0x3f689a613b62[39]);
            link.rel = _0x3f689a613b62[40];
            link.href = href;
            link.dataset.viewStylesheet = _0x3f689a613b62[41];
            pendientes.push(new Promise((resolve, reject) => {
                link.addEventListener(_0x3f689a613b62[21], resolve, { once: true });
                link.addEventListener(_0x3f689a613b62[22], () => {
                    reject(new Error(`No se pudo cargar la hoja de estilos ${href}`));
                }, { once: true });
            }));
            document.head.appendChild(link);
        });
        await Promise.all(pendientes);
        actuales.forEach(link => {
            if (!hrefs.includes(link.href)) {
                link.remove();
            }
        });
        vista.querySelectorAll(_0x3f689a613b62[35]).forEach(link => link.remove());
        return vista.body.innerHTML;
    }
    async function cargarPagina(pagina) {
        limpiarModalesBootstrap();
        loader();
        try {
            const resp = await fetch(pagina, {
                cache: _0x3f689a613b62[42],
                credentials: _0x3f689a613b62[4]
            });
            const finalUrl = (resp.url || _0x3f689a613b62[1]).toLowerCase();
            if (resp.redirected &&
                (finalUrl.includes(_0x3f689a613b62[43]) ||
                    finalUrl.includes(_0x3f689a613b62[44]) ||
                    finalUrl.includes(_0x3f689a613b62[45]))) {
                contenedor.innerHTML = `
          <div class="alert alert-warning">
            Sesión expirada o redirección a login.<br>
            <a class="btn btn-primary btn-sm mt-2" href="/app_descuento/usuarios/login.html">
              Ir al login
            </a>
          </div>
        `;
                return;
            }
            if (resp.status === 401) {
                contenedor.innerHTML = `
          <div class="alert alert-warning">
            Sesión expirada. Vuelva a iniciar sesión.<br>
            <a class="btn btn-primary btn-sm mt-2" href="/app_descuento/usuarios/login.html">
              Ir al login
            </a>
          </div>
        `;
                return;
            }
            if (resp.status === 403) {
                const txt = await resp.text();
                contenedor.innerHTML = `
          <div class="alert alert-danger">
            No tienes permisos para ver esta sección.
            <hr>
            <pre class="mb-0 error-body error-body-sm">${escaparHtml(txt || _0x3f689a613b62[1])}</pre>
          </div>
        `;
                return;
            }
            const html = await resp.text();
            if (!resp.ok) {
                mostrarError(pagina, resp.status, resp.statusText, html);
                return;
            }
            contenedor.innerHTML = await prepararVista(html);
            await ejecutarScriptsEn(contenedor);
            if (typeof window.initDashboardCharts === _0x3f689a613b62[46]) {
                window.initDashboardCharts();
            }
            marcarMenuActivo(pagina);
            controlarSubmenuUsuarios(pagina);
        }
        catch (e) {
            mostrarError(pagina, _0x3f689a613b62[47], _0x3f689a613b62[48], e.message);
        }
    }
    document.addEventListener(_0x3f689a613b62[49], (e) => {
        const link = e.target.closest(_0x3f689a613b62[50]);
        if (!link) {
            return;
        }
        e.preventDefault();
        const pagina = link.getAttribute(_0x3f689a613b62[51]);
        if (!pagina) {
            return;
        }
        cargarPagina(pagina);
        cerrarMenuMovil();
    });
    document.addEventListener(_0x3f689a613b62[52], function (e) {
        e.preventDefault();
    });
    document.addEventListener(_0x3f689a613b62[53], function (e) {
        if (e.keyCode === 123) {
            e.preventDefault();
        }
        if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 67)) {
            e.preventDefault();
        }
        if (e.ctrlKey && e.keyCode === 85) {
            e.preventDefault();
        }
    });
    cargarPagina(document.body.dataset.defaultPage || _0x3f689a613b62[54]);
}  );
