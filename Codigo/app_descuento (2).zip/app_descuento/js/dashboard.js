var _0xb5b07ca5a02d=["cmdiYSgzNyw5OSwyMzUsLjk1KQ==","cmdiYSgzNyw5OSwyMzUsLjEyKQ==","c3BhcmtBY2Npb25lcw==","W10=","MmQ=","cmdiYSgzNyw5OSwyMzUsLjU1KQ==","cmdiYSgzNyw5OSwyMzUsLjA1KQ==","bGluZQ==","cmdiYSgzNyw5OSwyMzUsMSk=","ZG9udXRVc3Vhcmlvcw==","MA==","ZG91Z2hudXQ=","QWN0aXZvcw==","QmxvcXVlYWRvcw==","IzI1NjNlYg==","IzY0NzQ4Yg==","NzQl","Ym90dG9t","ZG9udXREZXNjdWVudG9z","QXNpZ25hZG9z","Q2FtYmlhZG9z","RWxpbWluYWRvcw==","TWFzaXZvcw==","IzIyYzU1ZQ==","I2Y1OWUwYg==","I2VmNDQ0NA==","YmFyQWNjaW9uZXM3ZA==","YmFy","","cmdiYSgxNSwyMyw0MiwuMDgp","YmFyVG9wRW1wcmVzYXM=","cmdiYSgxNCwxNjUsMjMzLC44NSk=","eQ==","RE9NQ29udGVudExvYWRlZA=="].map(function(_x){return new TextDecoder().decode(Uint8Array.from(atob(_x),function(_b){return _b.charCodeAt(0)}))});
function makeGradient(ctx, h) {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, _0xb5b07ca5a02d[0]);
    g.addColorStop(1, _0xb5b07ca5a02d[1]);
    return g;
}
window.initDashboardCharts = function () {
    if (!window.Chart)
        return;
    const sp = document.getElementById(_0xb5b07ca5a02d[2]);
    if (sp) {
        const labels = JSON.parse(sp.dataset.labels || _0xb5b07ca5a02d[3]);
        const values = JSON.parse(sp.dataset.values || _0xb5b07ca5a02d[3]);
        const ctx = sp.getContext(_0xb5b07ca5a02d[4]);
        const grad = ctx.createLinearGradient(0, 0, 0, 80);
        grad.addColorStop(0, _0xb5b07ca5a02d[5]);
        grad.addColorStop(1, _0xb5b07ca5a02d[6]);
        if (sp._chart)
            sp._chart.destroy();
        sp._chart = new Chart(sp, {
            type: _0xb5b07ca5a02d[7],
            data: {
                labels,
                datasets: [{
                        data: values,
                        borderColor: _0xb5b07ca5a02d[8],
                        backgroundColor: grad,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 0,
                        borderWidth: 3
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { display: false },
                    y: { display: false, beginAtZero: true }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: { displayColors: false }
                }
            }
        });
    }
    const u = document.getElementById(_0xb5b07ca5a02d[9]);
    if (u) {
        const activos = parseInt(u.dataset.activos || _0xb5b07ca5a02d[10], 10);
        const bloq = parseInt(u.dataset.bloq || _0xb5b07ca5a02d[10], 10);
        if (u._chart)
            u._chart.destroy();
        u._chart = new Chart(u, {
            type: _0xb5b07ca5a02d[11],
            data: {
                labels: [_0xb5b07ca5a02d[12], _0xb5b07ca5a02d[13]],
                datasets: [{
                        data: [activos, bloq],
                        backgroundColor: [_0xb5b07ca5a02d[14], _0xb5b07ca5a02d[15]],
                        borderWidth: 0,
                        hoverOffset: 6
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: _0xb5b07ca5a02d[16],
                plugins: {
                    legend: {
                        position: _0xb5b07ca5a02d[17],
                        labels: { usePointStyle: true, boxWidth: 10, padding: 14 }
                    }
                }
            }
        });
    }
    const d1 = document.getElementById(_0xb5b07ca5a02d[18]);
    if (d1) {
        const asig = parseInt(d1.dataset.asig || _0xb5b07ca5a02d[10], 10);
        const camb = parseInt(d1.dataset.camb || _0xb5b07ca5a02d[10], 10);
        const elim = parseInt(d1.dataset.elim || _0xb5b07ca5a02d[10], 10);
        const masivo = parseInt(d1.dataset.masivo || _0xb5b07ca5a02d[10], 10);
        if (d1._chart)
            d1._chart.destroy();
        d1._chart = new Chart(d1, {
            type: _0xb5b07ca5a02d[11],
            data: {
                labels: [_0xb5b07ca5a02d[19], _0xb5b07ca5a02d[20], _0xb5b07ca5a02d[21], _0xb5b07ca5a02d[22]],
                datasets: [{
                        data: [asig, camb, elim, masivo],
                        backgroundColor: [_0xb5b07ca5a02d[23], _0xb5b07ca5a02d[24], _0xb5b07ca5a02d[25], _0xb5b07ca5a02d[14]],
                        borderWidth: 0,
                        hoverOffset: 6
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: _0xb5b07ca5a02d[16],
                plugins: {
                    legend: {
                        position: _0xb5b07ca5a02d[17],
                        labels: { usePointStyle: true, boxWidth: 10, padding: 14 }
                    }
                }
            }
        });
    }
    const b1 = document.getElementById(_0xb5b07ca5a02d[26]);
    if (b1) {
        const labels = JSON.parse(b1.dataset.labels || _0xb5b07ca5a02d[3]);
        const values = JSON.parse(b1.dataset.values || _0xb5b07ca5a02d[3]);
        const ctx = b1.getContext(_0xb5b07ca5a02d[4]);
        const grad = makeGradient(ctx, 220);
        if (b1._chart)
            b1._chart.destroy();
        b1._chart = new Chart(b1, {
            type: _0xb5b07ca5a02d[27],
            data: {
                labels,
                datasets: [{
                        data: values,
                        backgroundColor: grad,
                        borderRadius: 10,
                        borderSkipped: false
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { callback: (v, i) => (labels[i] || _0xb5b07ca5a02d[28]).slice(5) }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: _0xb5b07ca5a02d[29] },
                        ticks: { precision: 0 }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
    const b2 = document.getElementById(_0xb5b07ca5a02d[30]);
    if (b2) {
        const labels = JSON.parse(b2.dataset.labels || _0xb5b07ca5a02d[3]);
        const values = JSON.parse(b2.dataset.values || _0xb5b07ca5a02d[3]);
        if (b2._chart)
            b2._chart.destroy();
        b2._chart = new Chart(b2, {
            type: _0xb5b07ca5a02d[27],
            data: {
                labels,
                datasets: [{
                        data: values,
                        backgroundColor: _0xb5b07ca5a02d[31],
                        borderRadius: 10,
                        borderSkipped: false
                    }]
            },
            options: {
                indexAxis: _0xb5b07ca5a02d[32],
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: { color: _0xb5b07ca5a02d[29] },
                        ticks: { precision: 0 }
                    },
                    y: {
                        grid: { display: false }
                    }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
};
document.addEventListener(_0xb5b07ca5a02d[33], function () {
    window.initDashboardCharts && window.initDashboardCharts();
});
