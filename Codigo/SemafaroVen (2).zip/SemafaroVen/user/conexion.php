<?php

require_once dirname(__DIR__) . '/seguridad.php';
$config = smf_credenciales()['mysql'];

foreach (['host', 'user', 'password', 'database'] as $campo) {
    if (!isset($config[$campo]) || (string)$config[$campo] === '') {
        smf_error_servicio('Falta un parametro MySQL.');
    }
}

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli(
        (string)$config['host'],
        (string)$config['user'],
        (string)$config['password'],
        (string)$config['database'],
        (int)($config['port'] ?? 3306)
    );
    $conn->set_charset('utf8mb4');
    if (function_exists('smf_revalidar_cuenta')) smf_revalidar_cuenta($conn);
} catch (Throwable $e) {
    smf_error_servicio('Conexion MySQL no disponible.');
}
unset($config);
