<?php
require_once __DIR__ . '/auth.php';
destruir_sesion();
header('Location: login.php');
exit;
