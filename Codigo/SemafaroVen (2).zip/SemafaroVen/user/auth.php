<?php
/* Sesiones, autorizacion y proteccion de solicitudes del Semaforo. */
if (!headers_sent()) {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'self'");
    header('Cache-Control: private, no-store, max-age=0');
}

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    ini_set('session.cookie_httponly', '1');
    $https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
    session_name('APP_SEMAFARO');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

if (session_status() === PHP_SESSION_ACTIVE) {
    $ahora = time();
    if (!isset($_SESSION['smf_rotacion']) || $ahora - (int)$_SESSION['smf_rotacion'] >= 300) {
        session_regenerate_id(true);
        $_SESSION['smf_rotacion'] = $ahora;
    }
}

function destruir_sesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 3600,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]);
    }
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}

function smf_cerrar_acceso(string $motivo = 'expirada'): void
{
    destruir_sesion();
    if (!headers_sent()) header('Location: /SemafaroVen/user/login.php?sesion=' . rawurlencode($motivo), true, 303);
    exit;
}

function require_login(): void
{
    if (empty($_SESSION['usuario']) || (int)($_SESSION['usuario_id'] ?? 0) <= 0) {
        header('Location: /SemafaroVen/user/login.php');
        exit;
    }
    $ahora = time();
    $inicio = (int)($_SESSION['login_time'] ?? 0);
    if ($inicio <= 0 || $ahora - $inicio > 28800) { // 8 h desde el inicio de sesion.
        smf_cerrar_acceso('expirada');
    }
    $ultima = (int)($_SESSION['smf_ultima_actividad'] ?? $inicio);
    if ($ahora - $ultima > 3600) { // 1 h sin actividad.
        smf_cerrar_acceso('inactividad');
    }
    $_SESSION['smf_ultima_actividad'] = $ahora;
}

function es_admin(): bool
{
    return in_array((string)($_SESSION['rol'] ?? ''), ['administrador', 'admin'], true);
}

function require_admin(): void
{
    require_login();
    if (!es_admin()) {
        http_response_code(403);
        exit('Acceso denegado.');
    }
}

/* Conserva los accesos historicos del menu, validandolos tambien en servidor. */
function smf_puede_ver_auditoria(): bool
{
    return es_admin() || in_array((string)($_SESSION['usuario'] ?? ''), ['admin', 'elopez', 'jcruz'], true);
}

function smf_csrf_token(): string
{
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/* La autoridad (host y puerto) del origen debe coincidir con la solicitud. */
function smf_origen_confiable(string $url): bool
{
    $origen = parse_url($url);
    if (!is_array($origen) || empty($origen['host']) || !in_array(strtolower($origen['scheme'] ?? ''), ['http', 'https'], true)) {
        return false;
    }
    $esperado = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($esperado === '') return false;
    $origenHost = strtolower((string)$origen['host']);
    if (str_contains($origenHost, ':')) $origenHost = '[' . $origenHost . ']';
    $origenPuerto = isset($origen['port']) ? ':' . (int)$origen['port'] : '';
    $candidato = $origenHost . $origenPuerto;
    if (hash_equals($esperado, $candidato)) return true;
    // Los navegadores omiten el puerto estandar 80/443.
    $esPuertoEstandar = (!isset($origen['port']) && in_array($origen['scheme'] . ':', ['http:', 'https:'], true));
    if ($esPuertoEstandar && hash_equals($esperado, $origenHost)) return true;
    return false;
}

function smf_proteger_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;
    $fetchSite = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
    if (in_array($fetchSite, ['cross-site', 'none'], true)) {
        http_response_code(403);
        exit('Solicitud no autorizada.');
    }
    $origen = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    $referencia = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if (($origen !== '' && !smf_origen_confiable($origen)) ||
        ($origen === '' && ($referencia === '' || !smf_origen_confiable($referencia)))) {
        http_response_code(403);
        exit('Solicitud no autorizada.');
    }
    $token = $_POST['csrf_token'] ?? null;
    if (!is_string($token) || !hash_equals(smf_csrf_token(), $token)) {
        http_response_code(403);
        exit('La solicitud expiró o no es válida. Actualice la página.');
    }
}

/* Cada 60 segundos se vuelve a validar la cuenta contra MySQL. */
function smf_revalidar_cuenta(mysqli $db): void
{
    if (empty($_SESSION['usuario_id']) || empty($_SESSION['usuario'])) return;
    require_login();
    $ahora = time();
    if ($ahora - (int)($_SESSION['smf_ultima_validacion'] ?? 0) < 60) return;

    try {
        $id = (int)$_SESSION['usuario_id'];
        $stmt = $db->prepare('SELECT usuario, nombre_completo, rol, estado, foto_perfil FROM usuarios WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    } catch (Throwable $e) {
        error_log('Semaforo: fallo en comprobacion de cuenta.');
        http_response_code(503);
        exit('Servicio temporalmente no disponible.');
    }
    if (!$row || (int)$row['estado'] !== 1 || (string)$row['usuario'] !== (string)$_SESSION['usuario']) {
        smf_cerrar_acceso('revocada');
    }
    $_SESSION['rol'] = (string)$row['rol'];
    $_SESSION['nombre_completo'] = (string)$row['nombre_completo'];
    $_SESSION['foto_perfil'] = $row['foto_perfil'] ?? null;
    $_SESSION['smf_ultima_validacion'] = $ahora;
}

/* El formulario de login y todos los modulos POST pasan este control. */
smf_csrf_token();
smf_proteger_post();
