<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/conexion.php';

$error = $_SESSION['login_error'] ?? '';
$usuarioGuardado = $_SESSION['login_usuario'] ?? '';
unset($_SESSION['login_error'], $_SESSION['login_usuario']);

function volverLogin(string $mensaje, string $usuario = ''): void {
    $_SESSION['login_error'] = $mensaje;
    $_SESSION['login_usuario'] = $usuario;

    $ruta = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: 'index.php';
    header('Location: ' . $ruta, true, 303);
    exit;
}

function auditoria(
    mysqli $conn,
    string $nombre,
    string $usuario,
    string $accion,
    string $detalle
): void {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA';

        $stmt = $conn->prepare("
            INSERT INTO auditoria
            (nombre_completo, usuario, accion, ip, fecha, detalle)
            VALUES (?, ?, ?, ?, NOW(), ?)
        ");

        if (!$stmt) return;

        $stmt->bind_param('sssss', $nombre, $usuario, $accion, $ip, $detalle);
        $stmt->execute();
        $stmt->close();

    } catch (Throwable $e) {
        error_log('Error auditoría login (Código: ' . $e->getCode() . ')');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario = trim((string)($_POST['usuario'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    // Ajustado para permitir letras, números, puntos y guiones
    if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ0-9._-]{3,50}$/u', $usuario)) {
        volverLogin('Usuario o contraseña incorrectos.', $usuario);
    }

    if (!preg_match('/^\S{6,30}$/u', $password)) {
        volverLogin('Usuario o contraseña incorrectos.', $usuario);
    }

    $stmt = $conn->prepare("
        SELECT id, usuario, nombre_completo, password, rol, estado,
               foto_perfil, COALESCE(intentos, 0) AS intentos, bloqueado_hasta
        FROM usuarios
        WHERE usuario = ?
        LIMIT 1
    ");

    if (!$stmt) {
        volverLogin('No fue posible validar el acceso en este momento.', $usuario);
    }

    $stmt->bind_param('s', $usuario);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Hash ficticio para igualar tiempos de respuesta si el usuario no existe (Anti Timing-Attack)
    $hashFicticio = '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG';

    if (!$user) {
        password_verify($password, $hashFicticio);
        volverLogin('Usuario o contraseña incorrectos.', $usuario);
    }

    // 1. Verificar si la cuenta está desactivada administrativamente
    if ((int)$user['estado'] !== 1) {
        password_verify($password, $hashFicticio);
        volverLogin('Cuenta inactiva. Contacte al administrador.', $usuario);
    }

    // 2. Verificar si tiene un bloqueo temporal activo de 15 minutos
    $ahora = time();
    $bloqueadoHasta = !empty($user['bloqueado_hasta']) ? strtotime((string)$user['bloqueado_hasta']) : 0;

    if ($bloqueadoHasta > $ahora) {
        $minutosRestantes = (int)ceil(($bloqueadoHasta - $ahora) / 60);
        volverLogin(
            "Demasiados intentos fallidos. Intente nuevamente en {$minutosRestantes} minuto(s).",
            $usuario
        );
    }

    // Si el bloqueo de 15 minutos ya expiró, reiniciamos el contador en memoria
    $intentosActuales = ($bloqueadoHasta > 0 && $bloqueadoHasta <= $ahora) ? 0 : (int)$user['intentos'];

    // 3. Validar la contraseña
    if (!password_verify($password, (string)$user['password'])) {

        $intentos = $intentosActuales + 1;
        $usuarioId = (int)$user['id'];

        if ($intentos >= 3) {
            // Bloquear por 15 minutos exactos
            $stmt = $conn->prepare("
                UPDATE usuarios
                SET intentos = ?, bloqueado_hasta = DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                WHERE id = ?
            ");
            if ($stmt) {
                $stmt->bind_param('ii', $intentos, $usuarioId);
                $stmt->execute();
                $stmt->close();
            }

            auditoria(
                $conn,
                (string)($user['nombre_completo'] ?? ''),
                (string)$user['usuario'],
                'LOGIN_BLOQUEADO_TEMP',
                'Intento fallido 3 de 3. Cuenta bloqueada temporalmente por 15 minutos.'
            );

            volverLogin(
                'Demasiados intentos fallidos. Intente nuevamente en 15 minutos.',
                $usuario
            );
        } else {
            // Sumar intento fallido sin bloquear aún
            $stmt = $conn->prepare("
                UPDATE usuarios
                SET intentos = ?, bloqueado_hasta = NULL
                WHERE id = ?
            ");
            if ($stmt) {
                $stmt->bind_param('ii', $intentos, $usuarioId);
                $stmt->execute();
                $stmt->close();
            }

            auditoria(
                $conn,
                (string)($user['nombre_completo'] ?? ''),
                (string)$user['usuario'],
                'LOGIN_FALLIDO',
                "Intento fallido {$intentos} de 3."
            );

            // Mensaje genérico para evitar que un atacante descubra usuarios válidos
            volverLogin('Usuario o contraseña incorrectos.', $usuario);
        }
    }

    // 4. Inicio de sesión exitoso: limpiar intentos y bloqueo
    $usuarioId = (int)$user['id'];

    $stmt = $conn->prepare("
        UPDATE usuarios
        SET ultimo_login = NOW(), intentos = 0, bloqueado_hasta = NULL
        WHERE id = ?
    ");

    if (!$stmt) {
        volverLogin('No fue posible actualizar el acceso.', $usuario);
    }

    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $stmt->close();

    session_regenerate_id(true);

    $_SESSION['usuario_id'] = $usuarioId;
    $_SESSION['usuario'] = (string)$user['usuario'];
    $_SESSION['nombre_completo'] = (string)$user['nombre_completo'];
    $_SESSION['rol'] = (string)$user['rol'];
    $_SESSION['foto_perfil'] = $user['foto_perfil'] ?? null;
    $_SESSION['login_time'] = time();
    $_SESSION['smf_ultima_actividad'] = time();
    $_SESSION['smf_ultima_validacion'] = time();
    $_SESSION['smf_rotacion'] = time();
    $_SESSION['tiendas'] = [];

    // Sincronizado con es_admin() de auth.php
    if (!es_admin()) {

        $stmt = $conn->prepare("
            SELECT codalmacen
            FROM usuario_tienda
            WHERE usuario_id = ?
            ORDER BY codalmacen
        ");

        if ($stmt) {
            $stmt->bind_param('i', $usuarioId);
            $stmt->execute();
            $resultado = $stmt->get_result();

            while ($fila = $resultado->fetch_assoc()) {
                $codigo = trim((string)($fila['codalmacen'] ?? ''));

                if ($codigo !== '') {
                    $_SESSION['tiendas'][] = $codigo;
                }
            }

            $stmt->close();
            $_SESSION['tiendas'] = array_values(array_unique($_SESSION['tiendas']));
        }
    }

    header('Location: ../index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semafaro | Grupo MCC</title>

    <link rel="stylesheet" href="/SemafaroVen/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="/SemafaroVen/user/css/style.css?v=<?= time() ?>">
    <link rel="shortcut icon" type="image/png" href="/SemafaroVen/img/sv.png">
</head>


<body>

<div class="container">

    <div class="login-side">
        <div class="wrapper">

            <div class="logo-login">
                <img src="img/logo.png" alt="Grupo MCC">
            </div>

            <h2>Bienvenidos</h2>

            <p class="subtitle">
                Ingresa tus credenciales para continuar.
            </p>

            <?php if ($error !== ''): ?>
                <div class="login-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></span>
                </div>
            <?php endif; ?>

            <form id="loginForm" method="POST" autocomplete="on">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(smf_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

                <div class="input-field">
                    <i class="fa-solid fa-user"></i>

                    <input
                        type="text"
                        id="usuario"
                        name="usuario"
                        value="<?= htmlspecialchars($usuarioGuardado, ENT_QUOTES, 'UTF-8') ?>"
                        autocomplete="username"
                        maxlength="50"
                        required
                    >

                    <label for="usuario">Usuario</label>
                </div>

                <div class="input-field">
                    <i class="fa-solid fa-lock"></i>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        autocomplete="current-password"
                        minlength="6"
                        maxlength="30"
                        required
                    >

                    <label for="password">Contraseña</label>

                    <span
                        class="toggle-password"
                        id="togglePassword"
                        title="Mostrar contraseña"
                    >
                        <i class="fa-solid fa-eye"></i>
                    </span>
                </div>

                <div class="forget">
                    <label class="remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <span>Recordar</span>
                    </label>
                </div>

                <button type="submit">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Ingresar
                </button>

                <div class="footer">
                    © <?= date('Y') ?> GRUPO MCC
                </div>

            </form>
        </div>
    </div>

    <div class="image-side">
        <div class="overlay">
            <div class="content">
                <h1></h1>
                <p>Integridad, Innovación, Pasión, Unión y Perseverancia.</p>
            </div>
        </div>
    </div>

</div>

<script src="/SemafaroVen/js/restringir-contexto.js?v=<?= time() ?>"></script>
<script src="/SemafaroVen/user/js/login.js?v=<?= time() ?>"></script>

</body>
</html>