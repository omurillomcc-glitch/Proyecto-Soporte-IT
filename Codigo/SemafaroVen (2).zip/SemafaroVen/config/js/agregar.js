const rol = document.getElementById('rol');
const grupoTiendas = document.getElementById('grupoTiendas');
const textoTienda = document.getElementById('textoTienda');
const checks = document.querySelectorAll('.check-tienda');
const buscarTienda = document.getElementById('buscarTienda');
const numeroTiendas = document.getElementById('numeroTiendas');
function actualizarSeleccionVisual() {
    let _0x8d08f4 = 0;
    checks.forEach(_0xb1b23e => {
        const _0xc908ab = _0xb1b23e.closest('.tienda-card');
        if (_0xb1b23e.checked) {
            _0x8d08f4++;
            _0xc908ab?.classList.add('selected');
        }
        else {
            _0xc908ab?.classList.remove('selected');
        }
    });
    if (numeroTiendas)
        numeroTiendas.textContent = _0x8d08f4;
}
if (buscarTienda) {
    buscarTienda.addEventListener('input', function () {
        const _0xf184c2 = this.value.toLowerCase().trim();
        document.querySelectorAll('.tienda-card').forEach(_0xabdd73 => {
            _0xabdd73.style.display =
                _0xabdd73.textContent.toLowerCase().includes(_0xf184c2)
                    ? 'flex'
                    : 'none';
        });
    });
}
document.getElementById('usuario').addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ]/g, '');
});
document.getElementById('nombre_completo').addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
});
document.getElementById('togglePass').addEventListener('click', function () {
    const _0x4cfaf3 = document.getElementById('password');
    const _0x178bf3 = _0x4cfaf3.type === 'text';
    _0x4cfaf3.type = _0x178bf3 ? 'password' : 'text';
    this.textContent = _0x178bf3 ? 'Ver' : 'Ocultar';
    this.setAttribute('aria-label', _0x178bf3 ? 'Mostrar contraseña' : 'Ocultar contraseña');
});
function actualizarRol() {
    const _0x17f544 = rol.value;
    if (_0x17f544 === 'administrador') {
        grupoTiendas.style.display = 'none';
        checks.forEach(_0x62bb45 => _0x62bb45.checked = false);
        textoTienda.textContent = '';
    }
    else if (_0x17f544 === 'gerente_comercial') {
        grupoTiendas.style.display = 'block';
        textoTienda.textContent = 'Puede seleccionar una o varias tiendas.';
    }
    else if (_0x17f544 === 'gerente_tienda') {
        grupoTiendas.style.display = 'block';
        textoTienda.textContent = 'Debe seleccionar solamente una tienda.';
        let _0xae00c6 = false;
        checks.forEach(_0x78ec5f => {
            if (_0x78ec5f.checked) {
                if (!_0xae00c6)
                    _0xae00c6 = true;
                else
                    _0x78ec5f.checked = false;
            }
        });
    }
    else {
        grupoTiendas.style.display = 'none';
    }
    actualizarSeleccionVisual();
}
rol.addEventListener('change', actualizarRol);
checks.forEach(_0xa68578 => {
    _0xa68578.addEventListener('change', function () {
        if (rol.value === 'gerente_tienda' && this.checked) {
            checks.forEach(_0x98bdd6 => {
                if (_0x98bdd6 !== this)
                    _0x98bdd6.checked = false;
            });
        }
        actualizarSeleccionVisual();
    });
});
document.getElementById('formUsuario').addEventListener('submit', function (_0x109b6d) {
    const _0x4644c0 = document.querySelectorAll('.check-tienda:checked');
    if (rol.value === 'gerente_comercial' && _0x4644c0.length === 0) {
        _0x109b6d.preventDefault();
        alert('Debe seleccionar al menos una tienda para el Gerente Comercial.');
    }
    if (rol.value === 'gerente_tienda' && _0x4644c0.length !== 1) {
        _0x109b6d.preventDefault();
        alert('El Gerente de Tienda debe tener exactamente una tienda.');
    }
});
document.getElementById('btnCancelar').addEventListener('click', function () {
    setTimeout(() => {
        actualizarRol();
        actualizarSeleccionVisual();
    }, 0);
});
actualizarRol();
actualizarSeleccionVisual();
