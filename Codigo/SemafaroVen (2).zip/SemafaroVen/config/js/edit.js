const rows = document.querySelectorAll('.user-row');
const original = document.getElementById('usuario_original');
const usuarioVisual = document.getElementById('usuario_visual');
const nombre = document.getElementById('nombre_completo');
const rol = document.getElementById('rol');
const status = document.getElementById('selectedStatus');
const password = document.getElementById('password');
const grupoTiendas = document.getElementById('grupoTiendas');
const textoTienda = document.getElementById('textoTienda');
const checks = document.querySelectorAll('.check-tienda');
const buscarTienda = document.getElementById('buscarTienda');
const numeroTiendas = document.getElementById('numeroTiendas');
function seleccionVisual() {
    let _0x2ae4a1 = 0;
    checks.forEach(_0x759a30 => {
        _0x759a30.closest('.tienda-card')?.classList.toggle('selected', _0x759a30.checked);
        if (_0x759a30.checked)
            _0x2ae4a1++;
    });
    if (numeroTiendas)
        numeroTiendas.textContent = _0x2ae4a1;
}
if (buscarTienda) {
    buscarTienda.addEventListener('input', function () {
        const _0x9665cf = this.value.toLowerCase().trim();
        document.querySelectorAll('.tienda-card').forEach(_0x1b5157 => {
            _0x1b5157.style.display =
                _0x1b5157.textContent.toLowerCase().includes(_0x9665cf)
                    ? 'flex'
                    : 'none';
        });
    });
}
function actualizarRol() {
    if (!rol || !grupoTiendas)
        return;
    if (rol.value === 'administrador') {
        grupoTiendas.style.display = 'none';
        checks.forEach(_0xcd65f9 => _0xcd65f9.checked = false);
        if (textoTienda)
            textoTienda.textContent = '';
    }
    else if (rol.value === 'gerente_comercial') {
        grupoTiendas.style.display = 'block';
        if (textoTienda) {
            textoTienda.textContent =
                'Puede seleccionar una o varias tiendas.';
        }
    }
    else if (rol.value === 'gerente_tienda') {
        grupoTiendas.style.display = 'block';
        if (textoTienda) {
            textoTienda.textContent =
                'Debe seleccionar solamente una tienda.';
        }
        let _0x9c2d8f = false;
        checks.forEach(_0xd6f023 => {
            if (_0xd6f023.checked) {
                if (!_0x9c2d8f)
                    _0x9c2d8f = true;
                else
                    _0xd6f023.checked = false;
            }
        });
    }
    else {
        grupoTiendas.style.display = 'none';
    }
    seleccionVisual();
}
function cargarTiendas(_0x392fb6) {
    checks.forEach(_0x99ebf4 => _0x99ebf4.checked = _0x392fb6.includes(_0x99ebf4.value));
    actualizarRol();
}
rows.forEach(_0x6a6c22 => {
    _0x6a6c22.addEventListener('click', () => {
        rows.forEach(_0xa5d1c5 => _0xa5d1c5.classList.remove('selected'));
        _0x6a6c22.classList.add('selected');
        original.value = _0x6a6c22.dataset.usuario;
        usuarioVisual.value = _0x6a6c22.dataset.usuario;
        nombre.value = _0x6a6c22.dataset.nombre;
        rol.value = _0x6a6c22.dataset.rol;
        password.value = '';
        const _0x95db6e = _0x6a6c22.dataset.estado === '1';
        status.textContent =
            _0x95db6e ? 'Activo' : 'Bloqueado';
        status.className =
            'status-badge ' +
                (_0x95db6e ? 'active' : 'blocked');
        const _0xfe80e7 = JSON.parse(_0x6a6c22.dataset.tiendas || '[]');
        cargarTiendas(_0xfe80e7);
    });
});
rol?.addEventListener('change', actualizarRol);
checks.forEach(_0x3e90ea => {
    _0x3e90ea.addEventListener('change', function () {
        if (rol.value === 'gerente_tienda' &&
            this.checked) {
            checks.forEach(_0x4fd497 => {
                if (_0x4fd497 !== this)
                    _0x4fd497.checked = false;
            });
        }
        seleccionVisual();
    });
});
document.getElementById('editForm')
    ?.addEventListener('submit', function (_0x0dcce5) {
    const _0x1ee3dd = document.querySelectorAll('.check-tienda:checked');
    if (rol.value === 'gerente_comercial' &&
        _0x1ee3dd.length === 0) {
        _0x0dcce5.preventDefault();
        alert('Debe seleccionar al menos una tienda para el Gerente Comercial.');
        return;
    }
    if (rol.value === 'gerente_tienda' &&
        _0x1ee3dd.length !== 1) {
        _0x0dcce5.preventDefault();
        alert('El Gerente de Tienda debe tener exactamente una tienda.');
    }
});
nombre?.addEventListener('input', function () {
    this.value =
        this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
});
document.getElementById('toggleEditPass')
    ?.addEventListener('click', function () {
    const _0xd16c11 = password.type === 'text';
    password.type =
        _0xd16c11 ? 'password' : 'text';
    this.textContent =
        _0xd16c11 ? 'Ver' : 'Ocultar';
});
rows[0]?.click();
seleccionVisual();
