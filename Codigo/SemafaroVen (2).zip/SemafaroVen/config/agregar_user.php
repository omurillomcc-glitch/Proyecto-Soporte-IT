<?php
require_once dirname(__DIR__) . '/user/auth.php';
require_login();

$baseUrl = $baseUrl ?? '/SemafaroVen';

if (($_SESSION['rol'] ?? '') !== 'administrador') {
    header("Location: {$baseUrl}/index.php?error=no_autorizado");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

require_once dirname(__DIR__) . '/user/conexion.php';
require_once dirname(__DIR__) . '/resumen/db.php';

$totalUsuarios = 0;
$resTotal = $conn->query("SELECT COUNT(*) AS total FROM usuarios");

if ($resTotal) {
    $row = $resTotal->fetch_assoc();
    $totalUsuarios = (int)($row['total'] ?? 0);
    $resTotal->free();
}

$tiendas = [];

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion !== false) {

    $sqlTiendas = "
        SELECT
            LTRIM(RTRIM(CODALMACEN)) AS CODALMACEN,
            LTRIM(RTRIM(NOMBREALMACEN)) AS NOMBREALMACEN,
            LTRIM(RTRIM(ISNULL(POBLACION,''))) AS POBLACION
        FROM MENDELS.dbo.ALMACEN
        WHERE CODALMACEN NOT LIKE '%[^0-9]%'
          AND UPPER(LTRIM(NOMBREALMACEN)) LIKE '%MENDEL%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%SPS%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%S.P.S%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TGU%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%TEGUCIGALPA%'
          AND UPPER(NOMBREALMACEN) NOT LIKE '%CENTRO%NI%'
        ORDER BY CODALMACEN
    ";

    $stmtTiendas = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlTiendas);

    if ($stmtTiendas !== false) {
        while ($t = sqlsrv_fetch_array($stmtTiendas, SQLSRV_FETCH_ASSOC)) {
            $tiendas[] = $t;
        }
        sqlsrv_free_stmt($stmtTiendas);
    }
}

require_once dirname(__DIR__) . '/layout_menu.php';
?>

<link rel="stylesheet" href="<?= $baseUrl ?>/config/css/useredit.css?v=<?= time() ?>">

<div class="user-page create-page">

<?php if (isset($_GET['ok'])): ?>
    <div class="alert success">
        <i class="bi bi-check-circle-fill"></i>
        <strong>Usuario creado correctamente.</strong>
        Los cambios han sido registrados.
    </div>
<?php endif; ?>

<?php
if (isset($_GET['error'])):
    $mensajeError = match($_GET['error']) {
        'usuario_invalido'  => 'El usuario no es válido.',
        'nombre_invalido'   => 'El nombre completo contiene caracteres no permitidos.',
        'password_invalido' => 'La contraseña debe tener entre 6 y 30 caracteres y no contener espacios.',
        'rol_invalido'      => 'El rol seleccionado no es válido.',
        'usuario_duplicado' => 'El nombre de usuario ya se encuentra registrado.',
        'tienda_requerida'  => 'Debe seleccionar al menos una tienda.',
        'una_sola_tienda'   => 'El Gerente de Tienda solamente puede tener una tienda.',
        'tienda_invalida'   => 'Una de las tiendas seleccionadas no es válida.',
        'guardar_fallo',
        'guardar'           => 'No se pudieron guardar los cambios.',
        'csrf'              => 'La sesión del formulario expiró. Actualice la página e inténtelo nuevamente.',
        default             => 'Ocurrió un error inesperado.'
    };
?>
    <div class="alert danger">
        <?= htmlspecialchars($mensajeError, ENT_QUOTES, 'UTF-8') ?>
    </div>
<?php endif; ?>

<div class="edit-layout create-layout">

    <aside class="panel user-list-panel create-side-panel">
        <div class="panel-head compact">
            <div><span class="eyebrow">Nuevo registro</span></div>
        </div>

        <div class="create-guide">
            <p>Complete la información para registrar una nueva cuenta.</p>

            <div class="guide-list">
                <div class="guide-item">
                    <span>1</span>
                    <div>
                        <strong>Datos personales</strong>
                        <small>Usuario y nombre completo.</small>
                    </div>
                </div>

                <div class="guide-item">
                    <span>2</span>
                    <div>
                        <strong>Seguridad</strong>
                        <small>Defina una contraseña válida.</small>
                    </div>
                </div>

                <div class="guide-item">
                    <span>3</span>
                    <div>
                        <strong>Permisos y tiendas</strong>
                        <small>Seleccione rol y tiendas correspondientes.</small>
                    </div>
                </div>
            </div>

            <div class="side-note">
                <strong><?= $totalUsuarios ?></strong>
                <span>usuarios registrados actualmente</span>
            </div>
        </div>
    </aside>

    <section class="panel edit-form-panel">

        <div class="panel-head form-title">
            <div>
                <h2>Información del usuario</h2>
                <p>Ingrese los datos requeridos para crear la nueva cuenta.</p>
            </div>
            <span class="status-badge active">Nuevo</span>
        </div>

        <form
            method="POST"
            action="<?= $baseUrl ?>/config/guadar_usuario.php"
            autocomplete="off"
            class="user-form"
            id="formUsuario"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
            >

            <div class="form-grid">

                <div class="form-group">
                    <label for="usuario">Usuario <span>*</span></label>
                    <input
                        type="text"
                        name="usuario"
                        id="usuario"
                        minlength="3"
                        maxlength="50"
                        required
                        placeholder="Ej: jperez"
                        autocomplete="off"
                    >
                </div>

                <div class="form-group">
                    <label for="nombre_completo">Nombre completo <span>*</span></label>
                    <input
                        type="text"
                        name="nombre_completo"
                        id="nombre_completo"
                        maxlength="100"
                        required
                        placeholder="Ingrese el nombre completo"
                        autocomplete="off"
                    >
                </div>

                <div class="form-group">
                    <label for="password">Contraseña <span>*</span></label>

                    <div class="password-box">
                        <input
                            type="password"
                            name="password"
                            id="password"
                            minlength="6"
                            maxlength="30"
                            required
                            placeholder="Ingrese la contraseña"
                            autocomplete="new-password"
                        >

                        <button
                            type="button"
                            id="togglePass"
                            class="eye-btn"
                            aria-label="Mostrar contraseña"
                        >
                            Ver
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="rol">Rol <span>*</span></label>

                    <select name="rol" id="rol" required>
                        <option value="">Seleccione un rol</option>
                        <option value="administrador">Administrador</option>
                        <option value="gerente_comercial">Gerente Comercial</option>
                        <option value="gerente_tienda">Gerente de Tienda</option>
                    </select>
                </div>

            </div>

            <div
                class="form-group"
                id="grupoTiendas"
                role="group"
                aria-labelledby="tiendasLabel"
                style="display:none; margin-top:20px;"
            >

                <div class="form-group-label" id="tiendasLabel">Tiendas asignadas <span>*</span></div>

                <div class="tiendas-container">

                    <?php if (empty($tiendas)): ?>

                        <div class="alert danger" style="margin:0;">
                            No se encontraron tiendas MENDELS.
                        </div>

                    <?php else: ?>

                        <div class="tiendas-toolbar">

                            <div class="tiendas-toolbar-copy">
                                <strong>Seleccionar tiendas</strong>
                                <small>Elija las tiendas que tendrá disponibles este usuario.</small>
                            </div>

                            <span class="tiendas-count" id="contadorTiendas">
                                <strong id="numeroTiendas">0</strong>
                                <span>seleccionadas</span>
                            </span>

                        </div>

                        <div class="tiendas-header">
                            <div class="tiendas-search-box">
                                <i class="bi bi-search"></i>
                                <label class="visually-hidden" for="buscarTienda">Buscar tiendas</label>
                                <input
                                    type="text"
                                    id="buscarTienda"
                                    class="search-tienda"
                                    placeholder="Buscar por tienda, código o ciudad..."
                                    autocomplete="off"
                                >
                            </div>
                        </div>

                        <div class="lista-tiendas" id="listaTiendasContenedor">

                            <?php foreach ($tiendas as $tienda):
                                $codigo = trim((string)$tienda['CODALMACEN']);
                                $nombre = trim((string)$tienda['NOMBREALMACEN']);
                                $poblacion = trim((string)$tienda['POBLACION']);
                            ?>

                                <label class="tienda-card">

                                    <input
                                        type="checkbox"
                                        name="tiendas[]"
                                        value="<?= htmlspecialchars($codigo, ENT_QUOTES, 'UTF-8') ?>"
                                        class="check-tienda"
                                    >

                                    <span class="tienda-check-ui" aria-hidden="true">
                                        <i class="bi bi-check-lg"></i>
                                    </span>

                                    <span class="tienda-main">

                                        <span class="tienda-topline">

                                            <span class="tienda-codigo">
                                                Tienda <?= htmlspecialchars($codigo) ?>
                                            </span>

                                            <?php if ($poblacion !== ''): ?>
                                                <span class="tienda-poblacion">
                                                    <i class="bi bi-geo-alt-fill"></i>
                                                    <?= htmlspecialchars($poblacion) ?>
                                                </span>
                                            <?php endif; ?>

                                        </span>

                                        <span class="tienda-nombre">
                                            <?= htmlspecialchars($nombre) ?>
                                        </span>

                                    </span>

                                </label>

                            <?php endforeach; ?>

                        </div>

                    <?php endif; ?>

                </div>

                <small id="textoTienda" class="tienda-helper"></small>

            </div>

            <div class="form-note">
                <span class="note-icon">i</span>
                Los campos marcados con <strong>*</strong> son obligatorios.
            </div>

            <div class="actions">

                <button type="reset" class="btn-secondary" id="btnCancelar">
                    <i class="bi bi-x-circle"></i>
                    Cancelar
                </button>

                <button type="submit" class="btn-primary">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                        <polyline points="17 21 17 13 7 13 7 21"></polyline>
                        <polyline points="7 3 7 8 15 8"></polyline>
                    </svg>
                    Guardar
                </button>

            </div>

        </form>

    </section>

</div>
</div>
<script src="<?= htmlspecialchars((string)$baseUrl, ENT_QUOTES, 'UTF-8') ?>/config/js/agregar.js" defer></script>
<?php require_once dirname(__DIR__) . '/layout_footer.php'; ?>