<?php
/* Carga de foto de perfil: solo archivos de imagen comprobados. */
require_once dirname(__DIR__) . '/user/auth.php';
require_login();
require_once dirname(__DIR__) . '/user/conexion.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    exit('Método no permitido.');
}

$archivo = $_FILES['foto'] ?? null;
if (!is_array($archivo) || is_array($archivo['name'] ?? null) ||
    ($archivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK ||
    !isset($archivo['tmp_name']) || !is_uploaded_file((string)$archivo['tmp_name'])) {
    http_response_code(400);
    exit('No se pudo recibir la imagen.');
}

$bytes = (int)($archivo['size'] ?? 0);
if ($bytes <= 0 || $bytes > 2 * 1024 * 1024) {
    http_response_code(400);
    exit('La imagen debe pesar menos de 2 MB.');
}

$temporal = (string)$archivo['tmp_name'];
$tipo = (new finfo(FILEINFO_MIME_TYPE))->file($temporal);
$tipos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$dimensiones = @getimagesize($temporal);
if (!is_string($tipo) || !isset($tipos[$tipo]) || !is_array($dimensiones) ||
    ($dimensiones['mime'] ?? '') !== $tipo ||
    ($dimensiones[0] ?? 0) < 1 || ($dimensiones[1] ?? 0) < 1 ||
    ($dimensiones[0] ?? 0) > 6000 || ($dimensiones[1] ?? 0) > 6000) {
    http_response_code(400);
    exit('Solo se permiten imágenes JPG, PNG y WEBP válidas.');
}

$destino = dirname(__DIR__) . '/uploads/avatars';
if (!is_dir($destino) && !@mkdir($destino, 0750, true) && !is_dir($destino)) {
    http_response_code(503);
    exit('No se pudo guardar la imagen.');
}

$nombre = 'avatar_' . bin2hex(random_bytes(16)) . '.' . $tipos[$tipo];
$ruta = $destino . DIRECTORY_SEPARATOR . $nombre;
if (!move_uploaded_file($temporal, $ruta)) {
    http_response_code(503);
    exit('No se pudo guardar la imagen.');
}

try {
    $id = (int)($_SESSION['usuario_id'] ?? 0);
    $stmt = $conn->prepare('UPDATE usuarios SET foto_perfil = ? WHERE id = ? AND estado = 1');
    $stmt->bind_param('si', $nombre, $id);
    $stmt->execute();
    $actualizados = $stmt->affected_rows;
    $stmt->close();
    if ($actualizados < 1) {
        @unlink($ruta);
        http_response_code(409);
        exit('No fue posible actualizar la foto del usuario.');
    }
    $_SESSION['foto_perfil'] = $nombre;
} catch (Throwable $e) {
    @unlink($ruta);
    error_log('Semaforo: error al guardar foto de perfil.');
    http_response_code(503);
    exit('No se pudo guardar la imagen.');
}

header('Location: perfil.php?tab=cuenta&status=success', true, 303);
exit;
