document.addEventListener('contextmenu', function (event) {
    event.preventDefault();
});

window.addEventListener('keydown', function (event) {
    const tecla = event.key.toLowerCase();
    const atajoBloqueado = tecla === 'f12'
        || (event.ctrlKey && tecla === 'u')
        || (event.ctrlKey && event.shiftKey && tecla === 'i');

    if (atajoBloqueado) {
        event.preventDefault();
        event.stopPropagation();
    }
}, true);
