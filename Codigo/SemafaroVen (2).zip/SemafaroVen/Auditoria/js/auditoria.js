(()=>{const _0x3a1307=document.getElementById('auditFilterToggle');const _0x233d81=document.getElementById('auditFilterPanel');if(_0x3a1307&&_0x233d81){_0x3a1307.addEventListener('click',()=>{const _0xfbb6ea=_0x233d81.classList.toggle('is-open');_0x3a1307.setAttribute('aria-expanded',_0xfbb6ea?'true':'false');});}const _0xf83570=Array.from(document.querySelectorAll('.audit-record'));if(!_0xf83570.length)return;const _0x38414d=_0x0434a9=>document.getElementById(_0x0434a9);const _0x946f01={date:_0x38414d('detailDate'),user:_0x38414d('detailUser'),name:_0x38414d('detailName'),module:_0x38414d('detailModule'),action:_0x38414d('detailAction'),actionIcon:_0x38414d('detailActionIcon'),actionText:_0x38414d('detailActionText'),ip:_0x38414d('detailIp'),description:_0x38414d('detailDescription')};function _0x6e808f(_0xf2a0b1){let _0x458a11={};try{_0x458a11=JSON.parse(_0xf2a0b1.dataset.record||'{}');}catch(_0x5cd62a){return;}_0xf83570.forEach(_0x8587d2=>_0x8587d2.classList.toggle('is-active',_0x8587d2===_0xf2a0b1));_0x946f01.date.textContent=_0x458a11.fecha||'—';_0x946f01.user.textContent=_0x458a11.usuario||'—';_0x946f01.name.textContent=_0x458a11.nombre?`(${_0x458a11.nombre})` : '';
        _0x946f01.module.textContent = _0x458a11.modulo || 'Usuarios';
        _0x946f01.action.className = `audit-action-pill ${_0x458a11.accionClase||'info'}`;
        _0x946f01.actionText.textContent = _0x458a11.accion || '—';
        const _0x0d5bc3 = {
            create: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 19a6 6 0 0 0-12 0"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M16 11h6"/></svg>',
            edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>',
            block: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><path d="M9 15h6"/></svg>',
            unlock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-2"/><path d="M12 14v3"/></svg>',
            info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
            metacreada: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            metaactualizada: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            diascreado: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>',
            diasactualizado: '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16"><path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/></svg>'
        };
        _0x946f01.actionIcon.innerHTML = _0x0d5bc3[_0x458a11.accionClase] || _0x0d5bc3.info;
        _0x946f01.ip.textContent = _0x458a11.ip || '—';
        _0x946f01.description.textContent = _0x458a11.detalle || 'Sin descripción registrada.';
        if (window.innerWidth <= 900)
            document.querySelector('.audit-workspace')?.classList.add('show-detail-mobile');
    }
    _0xf83570.forEach(_0xc8806b => _0xc8806b.addEventListener('click', () => _0x6e808f(_0xc8806b)));
    _0x6e808f(_0xf83570[0]);
    document.getElementById('auditBackBtn')?.addEventListener('click', () => {
        document.querySelector('.audit-workspace')?.classList.remove('show-detail-mobile');
    });
})();
