<?php
/* Conexion SQL Server. Solo mensajes neutros al navegador. */
require_once dirname(__DIR__) . '/seguridad.php';

if (!function_exists('sqlsrv_connect')) {
    smf_error_servicio('Extension sqlsrv no disponible.');
}
$config = smf_credenciales()['sqlserver'];
foreach (['server', 'database', 'user', 'password'] as $campo) {
    if (!isset($config[$campo]) || (string)$config[$campo] === '') {
        smf_error_servicio('Falta un parametro SQL Server.');
    }
}

$serverName = (string)$config['server'];
$connectionOptions = [
    'Database'                 => (string)$config['database'],
    'UID'                      => (string)$config['user'],
    'PWD'                      => (string)$config['password'],
    'CharacterSet'             => 'UTF-8',
    'Encrypt'                  => (bool)($config['encrypt'] ?? true),
    'TrustServerCertificate'   => (bool)($config['trust_server_certificate'] ?? true),
    'MultipleActiveResultSets' => true,
    'ConnectionPooling'        => true,
    'LoginTimeout'             => 60,
];
unset($config);

$sqlsrv_conn_exhibicion = sqlsrv_connect($serverName, $connectionOptions);
unset($serverName, $connectionOptions);

if ($sqlsrv_conn_exhibicion === false) {
    smf_error_servicio('Conexion SQL Server no disponible.');
}
