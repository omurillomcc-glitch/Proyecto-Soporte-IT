<?php



declare(strict_types=1);



require_once dirname(__DIR__) . '/user/auth.php';

require_login();

require_once dirname(__DIR__) . '/user/conexion.php';

require_once dirname(__DIR__) . '/resumen/db.php';

require_once dirname(__DIR__) . '/resumen/retail_helper.php';

require_once __DIR__ . '/dias_helper.php';



$baseUrl = $baseUrl ?? '/SemafaroVen';

$volverBase = $baseUrl . '/vendedores/dias_trabajados.php';



$rolesPermitidos = ['administrador', 'gerente_comercial', 'gerente_tienda'];

$rol = (string)($_SESSION['rol'] ?? '');

$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);

$puedeEditarIdentidades = in_array($rol, ['administrador', 'gerente_comercial'], true);



if (!in_array($rol, $rolesPermitidos, true) || $usuarioId <= 0) {

    header("Location: {$baseUrl}/index.php?error=no_autorizado");

    exit();

}



if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: {$volverBase}");

    exit();

}



$token = (string)($_POST['csrf_token'] ?? '');



if (

    empty($_SESSION['csrf_token']) ||

    !hash_equals((string)$_SESSION['csrf_token'], $token)

) {

    header("Location: {$volverBase}?error=csrf");

    exit();

}



/*

|--------------------------------------------------------------------------

| TIENDA AUTORIZADA

|--------------------------------------------------------------------------

*/

$tiendas = retail_obtener_tiendas_permitidas(

    $conn,

    $sqlsrv_conn_exhibicion ?? false,

    $rol,

    $usuarioId

);



$tienda = smf_entrada_texto($_POST['tienda'] ?? '', 30);



if ($tienda === '' || !isset($tiendas[$tienda])) {

    header("Location: {$volverBase}?error=tienda_invalida");

    exit();

}



$pagina = max(1, (int)($_POST['pagina'] ?? 1));

$perPage = (int)($_POST['per_page'] ?? 100);

if (!in_array($perPage, [100, 200, 500], true)) {

    $perPage = 100;

}



$semanaSolicitada = smf_entrada_texto($_POST['semana'] ?? '', 12);

$buscar = trim((string)($_POST['q'] ?? ''));

$registroVolver = trim((string)($_POST['registro'] ?? ''));



if (strlen($buscar) > 80) {

    $buscar = substr($buscar, 0, 80);

}



if (!preg_match('/^[A-Za-z0-9._-]{1,50}$/', $registroVolver)) {

    $registroVolver = '';

}



$volver = $volverBase

    . '?tienda=' . rawurlencode($tienda)

    . '&semana=' . rawurlencode($semanaSolicitada)

    . '&pagina=' . $pagina

    . '&per_page=' . $perPage;



if ($buscar !== '') {

    $volver .= '&q=' . rawurlencode($buscar);

}



if ($registroVolver !== '') {

    $volver .= '&registro=' . rawurlencode($registroVolver);

}



/*

|--------------------------------------------------------------------------

| PERIODO RETAIL AUTOMÁTICO DEL MES ACTUAL

|--------------------------------------------------------------------------

| NO se acepta año, mes o semana como autoridad desde el formulario.

| El servidor reconstruye las semanas válidas usando retail_helper.php.

*/

$tz = new DateTimeZone('America/Tegucigalpa');

$hoy = new DateTimeImmutable('today', $tz);

$anioVista = (int)$hoy->format('Y');

$mesVista = (int)$hoy->format('n');



$semanasMes = retail_obtener_semanas_mes($anioVista, $mesVista);



if (empty($semanasMes)) {

    header("Location: {$volver}&error=periodo");

    exit();

}



$semanasValidas = [];



foreach ($semanasMes as $semana) {

    $anio = (int)($semana['anio'] ?? 0);

    $num = (int)($semana['semana'] ?? 0);



    if ($anio > 0 && $num >= 1 && $num <= 53) {

        $semanasValidas[$anio . '-' . $num] = [

            'anio' => $anio,

            'semana' => $num,

            'fecha_inicio' => $semana['fecha_inicio'] ?? null,

            'fecha_fin' => $semana['fecha_fin'] ?? null,

        ];

    }

}



/*

|--------------------------------------------------------------------------

| VENDEDORES VÁLIDOS DE LA TIENDA

|--------------------------------------------------------------------------

*/

$vendedores = dias_obtener_vendedores_tienda(

    $sqlsrv_conn_exhibicion ?? false,

    (string)($tiendas[$tienda]['nombre'] ?? '')

);



if (empty($vendedores)) {

    header("Location: {$volver}&error=vendedor_invalido");

    exit();

}



$identidadesManuales = [];

$stmtIdentidades = $conn->prepare(

    "SELECT codvendedor, dni

     FROM dias_trabajados_identidades_manual

    WHERE tienda = ? OR tienda = '*'

    ORDER BY (tienda = '*') DESC"

);

if (!$stmtIdentidades) {

    header("Location: {$volver}&error=guardar");

    exit();

}

$stmtIdentidades->bind_param('s', $tienda);

if (!$stmtIdentidades->execute()) {

    $stmtIdentidades->close();

    header("Location: {$volver}&error=guardar");

    exit();

}

$stmtIdentidades->bind_result($codIdentidadDb, $dniIdentidadDb);

while ($stmtIdentidades->fetch()) {

    $cod = trim((string)$codIdentidadDb);

    $dniLocal = dias_normalizar_dni((string)$dniIdentidadDb);

    if ($cod !== '' && $dniLocal !== '') $identidadesManuales[$cod] = $dniLocal;

}

$stmtIdentidades->close();



$manualPost = $_POST['identidad_manual'] ?? [];

if (!is_array($manualPost)) $manualPost = [];

if (!$puedeEditarIdentidades) $manualPost = [];



$cambiosIdentidad = [];

foreach ($manualPost as $codManualRaw => $dniManualRaw) {

    $codManual = trim((string)$codManualRaw);

    if ($codManual === '' || !isset($vendedores[$codManual])) continue;



    $dniBase = dias_normalizar_dni((string)($vendedores[$codManual]['dni'] ?? ''));

    $anterior = $identidadesManuales[$codManual] ?? '';
    $actual = $anterior !== '' ? $anterior : $dniBase;

    $nuevoRaw = strtoupper(trim((string)$dniManualRaw));



    if ($nuevoRaw === '') continue; // Los campos vacíos de otros vendedores son opcionales.
    if (dias_normalizar_dni($nuevoRaw) === $actual) continue;

    if (!preg_match('/^[A-Z0-9]{5,20}$/', $nuevoRaw)) {

        header("Location: {$volver}&error=identidad_invalida");

        exit();

    }



    $nuevo = dias_normalizar_dni($nuevoRaw);

    if ($nuevo !== $actual) {

        $cambiosIdentidad[$codManual] = [

            'anterior' => $anterior,

            'nuevo' => $nuevo,

            'nombre' => (string)($vendedores[$codManual]['nombre'] ?? 'Vendedor')

        ];

    }

}



/*

|--------------------------------------------------------------------------

| PROCESAR SOLO CAMPOS ESCRITOS

|--------------------------------------------------------------------------

| Estructura:

| dias[2026-35][CODVENDEDOR] = 6.5

*/

$diasPost = $_POST['dias'] ?? [];

if (!is_array($diasPost)) {

    $diasPost = [];

}



$procesar = [];



foreach ($diasPost as $claveSemana => $valoresVendedores) {

    $claveSemana = trim((string)$claveSemana);



    if (!isset($semanasValidas[$claveSemana])) {

        header("Location: {$volver}&error=semana_invalida");

        exit();

    }



    if (!is_array($valoresVendedores)) {

        continue;

    }



    foreach ($valoresVendedores as $codVendedorRaw => $valorRaw) {

        $codVendedor = trim((string)$codVendedorRaw);

        $valor = trim((string)$valorRaw);



        if ($valor === '') {

            continue;

        }



        /*

         * Aceptar enteros o decimales entre 0 y 7.

         * Máximo 2 decimales: 0, 0.5, 1, 2.25, 6.75, 7.

         */

        $valorNormalizado = str_replace(',', '.', $valor);



        if (

            !preg_match(

                '/^(?:[0-6](?:\.\d{1,2})?|7(?:\.0{1,2})?)$/',

                $valorNormalizado

            )

        ) {

            header("Location: {$volver}&error=dias_invalidos");

            exit();

        }



        $diasDecimal = round((float)$valorNormalizado, 2);



        if ($diasDecimal < 0 || $diasDecimal > 7) {

            header("Location: {$volver}&error=dias_invalidos");

            exit();

        }



        if ($codVendedor === '' || !isset($vendedores[$codVendedor])) {

            header("Location: {$volver}&error=vendedor_invalido");

            exit();

        }



        $vendedor = $vendedores[$codVendedor];



        $dniBase = dias_normalizar_dni((string)($vendedor['dni'] ?? ''));

        $dniManual = '';



        $dniManualRaw = strtoupper(trim((string)($puedeEditarIdentidades

            ? ($manualPost[$codVendedor] ?? ($identidadesManuales[$codVendedor] ?? ''))

            : ($identidadesManuales[$codVendedor] ?? ''))));

        if ($dniManualRaw !== '') {

            if (!preg_match('/^[A-Z0-9]{5,20}$/', $dniManualRaw)) {

                header("Location: {$volver}&error=identidad_invalida");

                exit();

            }

            $dniManual = dias_normalizar_dni($dniManualRaw);

        } elseif ($dniBase === '') {

            if ($dniManualRaw === '') {

                header("Location: {$volver}&error=identidad_requerida");

                exit();

            }

        }



        $dni = $dniManual !== '' ? $dniManual : $dniBase;



        $procesar[] = [

            'anio' => (int)$semanasValidas[$claveSemana]['anio'],

            'semana' => (int)$semanasValidas[$claveSemana]['semana'],

            'codvendedor' => $codVendedor,

            'dni' => $dni,

            'nombre' => (string)($vendedor['nombre'] ?? 'Vendedor'),

            'dias' => $diasDecimal,

            'es_manual' => $dniManual !== '',

            'fecha_inicio' => $semanasValidas[$claveSemana]['fecha_inicio'] ?? null,

            'fecha_fin' => $semanasValidas[$claveSemana]['fecha_fin'] ?? null,

        ];

    }

}



if (empty($procesar) && empty($cambiosIdentidad)) {

    header("Location: {$volver}&info=sin_cambios");

    exit();

}



/*

|--------------------------------------------------------------------------

| VALIDAR IDENTIDADES Y COLISIONES REALES

|--------------------------------------------------------------------------

| - Un DNI manual no puede apropiarse del DNI de otro vendedor.

| - Si dos códigos comparten el mismo DNI en ICG, se permiten en pantalla.

| - Solo se rechaza cuando ambos intentan guardar la MISMA semana con el

|   mismo DNI, porque la tabla destino usa TIENDA+ANIO+SEMANA+DNI.

*/

// Una identidad puede corresponder a varios códigos (códigos temporales).
// Se conserva la validación de colisiones por tienda, semana e identidad
// para los días; SQL Server no almacena el código del vendedor en esa tabla.
$identidadesExistentes = [];
foreach ($vendedores as $cod => $ven) {
    $existente = dias_normalizar_dni((string)($identidadesManuales[$cod] ?? ''));
    if ($existente === '') $existente = dias_normalizar_dni((string)($ven['dni'] ?? ''));
    if ($existente !== '') $identidadesExistentes[$existente][] = (string)$cod;
}

/*
 * Al cambiar una identidad manual, mantener sincronizado el código semanal
 * que se había guardado en MySQL. Solo se migra si no comparte el DNI con
 * otro código de esta tienda, igual que en el traslado histórico de días.
 * Comprobar conflictos antes de modificar los registros de SQL Server.
 */
$migracionesCodigoSemanal = [];
foreach ($cambiosIdentidad as $codigoIdentidad => $cambioIdentidad) {
    $dniOrigen = (string)$cambioIdentidad['anterior'];
    $dniDestino = (string)$cambioIdentidad['nuevo'];
    if ($dniOrigen === '' || $dniOrigen === $dniDestino) {
        continue;
    }

    $dniCompartido = false;
    foreach (($identidadesExistentes[$dniOrigen] ?? []) as $otroCodigo) {
        if ((string)$otroCodigo !== (string)$codigoIdentidad) {
            $dniCompartido = true;
            break;
        }
    }
    if ($dniCompartido) {
        continue;
    }

    try {
        $stmtConflictoCodigo = $conn->prepare(
            "SELECT 1
             FROM dias_trabajados_codigos_semanales a
             INNER JOIN dias_trabajados_codigos_semanales b
               ON b.tienda = a.tienda AND b.anio = a.anio
              AND b.semana = a.semana
             WHERE a.tienda = ? AND a.dni = ? AND b.dni = ?
             LIMIT 1"
        );
        if (!$stmtConflictoCodigo) {
            throw new RuntimeException('No se pudo revisar la identidad semanal.');
        }
        $stmtConflictoCodigo->bind_param('sss', $tienda, $dniOrigen, $dniDestino);
        if (!$stmtConflictoCodigo->execute()) {
            $stmtConflictoCodigo->close();
            throw new RuntimeException('No se pudo validar la identidad semanal.');
        }
        $stmtConflictoCodigo->store_result();
        $hayChoqueCodigo = $stmtConflictoCodigo->num_rows > 0;
        $stmtConflictoCodigo->close();
        if ($hayChoqueCodigo) {
            throw new RuntimeException('Ya existe un código semanal para la nueva identidad.');
        }
        $migracionesCodigoSemanal[] = [$dniOrigen, $dniDestino];
    } catch (Throwable $e) {
        error_log('DÍAS: conflicto de identidad semanal: ' . $e->getMessage());
        header("Location: {$volver}&error=guardar");
        exit();
    }
}

$clavesDestino = [];



foreach ($procesar as $item) {

    $claveDestino = (int)$item['anio']

        . '-' . (int)$item['semana']

        . '-' . (string)$item['dni'];



    if (isset($clavesDestino[$claveDestino])) {

        header("Location: {$volver}&error=dni_conflicto");

        exit();

    }



    $clavesDestino[$claveDestino] = (string)$item['codvendedor'];

}



if (

    !isset($sqlsrv_conn_exhibicion) ||

    !$sqlsrv_conn_exhibicion ||

    !sqlsrv_begin_transaction($sqlsrv_conn_exhibicion)

) {

    header("Location: {$volver}&error=guardar");

    exit();

}



/*

|--------------------------------------------------------------------------

| UPSERT SEGURO

|--------------------------------------------------------------------------

*/

$formatearDias = static function (float $valor): string {

    return rtrim(

        rtrim(

            number_format($valor, 2, '.', ''),

            '0'

        ),

        '.'

    );

};



$nombreTiendaAuditoria = trim(

    (string)($tiendas[$tienda]['nombre'] ?? '')

);



$zonaTiendaAuditoria = trim(

    (string)($tiendas[$tienda]['poblacion'] ?? '')

);



$tiendaAuditoria =

    $tienda

    . (

        $nombreTiendaAuditoria !== ''

            ? ' - ' . $nombreTiendaAuditoria

            : ''

    )

    . (

        $zonaTiendaAuditoria !== ''

            ? ' (' . $zonaTiendaAuditoria . ')'

            : ''

    );



$fechaAuditoria = static function ($fecha): string {

    if ($fecha instanceof DateTimeInterface) {

        return $fecha->format('d/m/Y');

    }



    if (is_string($fecha) && trim($fecha) !== '') {

        try {

            return (new DateTimeImmutable($fecha))->format('d/m/Y');

        } catch (Throwable $e) {

            return trim($fecha);

        }

    }



    return '';

};



$cambios = [];



try {

    foreach ($cambiosIdentidad as $codVendedorIdentidad => $cambioIdentidad) {

        $dniAnterior = (string)$cambioIdentidad['anterior'];

        $dniNuevo = (string)$cambioIdentidad['nuevo'];

        $nombreIdentidad = (string)$cambioIdentidad['nombre'];



        // Evitar trasladar días asociados también a otro código temporal.
        $compartida = false;
        foreach (($identidadesExistentes[$dniAnterior] ?? []) as $otroCodigo) {
            if ((string)$otroCodigo !== (string)$codVendedorIdentidad) {
                $compartida = true;
                break;
            }
        }

        if ($dniAnterior !== '' && !$compartida) {

            $sqlConflicto = "

                SELECT TOP 1 1 AS EXISTE

                FROM [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL] A

                INNER JOIN [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL] B

                    ON B.TIENDA=A.TIENDA AND B.ANIO=A.ANIO AND B.SEMANA=A.SEMANA

                WHERE A.TIENDA=? AND A.DNI=? AND B.DNI=?

            ";

            $stmtConflicto = sqlsrv_query($sqlsrv_conn_exhibicion, $sqlConflicto, [$tienda, $dniAnterior, $dniNuevo]);

            if ($stmtConflicto === false) throw new RuntimeException('No se pudo validar el cambio de identidad.');

            $hayConflicto = sqlsrv_fetch_array($stmtConflicto, SQLSRV_FETCH_ASSOC) !== null;

            sqlsrv_free_stmt($stmtConflicto);

            if ($hayConflicto) throw new RuntimeException('La nueva identidad ya tiene registros en una misma semana.');



            $stmtMover = sqlsrv_query(

                $sqlsrv_conn_exhibicion,

                "UPDATE [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL] SET DNI=? WHERE TIENDA=? AND DNI=?",

                [$dniNuevo, $tienda, $dniAnterior]

            );

            if ($stmtMover === false) throw new RuntimeException('No se pudo actualizar la identidad histórica.');

            sqlsrv_free_stmt($stmtMover);

        }



        $stmtGuardarIdentidad = $conn->prepare(

            "INSERT INTO dias_trabajados_identidades_manual

                (tienda, codvendedor, dni, actualizado_por)

             VALUES (?, ?, ?, ?)

             ON DUPLICATE KEY UPDATE

                dni=VALUES(dni),

                actualizado_por=VALUES(actualizado_por),

                fecha_actualizacion=CURRENT_TIMESTAMP"

        );

        if (!$stmtGuardarIdentidad) throw new RuntimeException('No se pudo preparar la identidad.');

        $stmtGuardarIdentidad->bind_param('sssi', $tienda, $codVendedorIdentidad, $dniNuevo, $usuarioId);

        if (!$stmtGuardarIdentidad->execute()) {

            $stmtGuardarIdentidad->close();

            throw new RuntimeException('No se pudo guardar la identidad.');

        }

        $stmtGuardarIdentidad->close();



        $cambios[] = [

            'accion' => 'DIAS_TRABAJADOS_ACTUALIZADOS',

            'detalle' =>

                "Se actualizó la identidad manual del vendedor.\n"

                . "• Tienda: {$tiendaAuditoria}\n"

                . "• Vendedor: {$nombreIdentidad} · Código: {$codVendedorIdentidad}\n"

                . "• Identidad: " . ($dniAnterior !== '' ? "{$dniAnterior} → {$dniNuevo}" : "registrada como {$dniNuevo}") . "."

        ];

    }



    foreach ($procesar as $item) {

        $anio = $item['anio'];

        $semana = $item['semana'];

        $dni = $item['dni'];

        $diasNuevos = $item['dias'];

        $nombre = $item['nombre'];

        $codVendedor = $item['codvendedor'];

        $fechaInicio = $fechaAuditoria($item['fecha_inicio'] ?? null);

        $fechaFin = $fechaAuditoria($item['fecha_fin'] ?? null);

        $rangoSemana = (

            $fechaInicio !== ''

            && $fechaFin !== ''

        )

            ? " ({$fechaInicio} al {$fechaFin})"

            : '';



        $sqlExiste = "

            SELECT DIAS_TRABAJADOS

            FROM [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]

            WITH (UPDLOCK, HOLDLOCK)

            WHERE TIENDA = ?

              AND ANIO = ?

              AND SEMANA = ?

              AND DNI = ?

        ";



        $stmt = sqlsrv_query(

            $sqlsrv_conn_exhibicion,

            $sqlExiste,

            [$tienda, $anio, $semana, $dni]

        );



        if ($stmt === false) {

            throw new RuntimeException('No se pudo validar el registro.');

        }



        $filas = [];



        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {

            $filas[] = $row;

        }



        sqlsrv_free_stmt($stmt);



        if (count($filas) > 1) {

            throw new RuntimeException('Duplicados detectados en la tabla semanal.');

        }



        if (count($filas) === 1) {

            $diasAnteriores = round((float)$filas[0]['DIAS_TRABAJADOS'], 2);



            if (abs($diasAnteriores - $diasNuevos) < 0.001) {

                continue;

            }



            $sqlUpdate = "

                UPDATE [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]

                SET DIAS_TRABAJADOS = ?

                WHERE TIENDA = ?

                  AND ANIO = ?

                  AND SEMANA = ?

                  AND DNI = ?

            ";



            $stmtUpdate = sqlsrv_query(

                $sqlsrv_conn_exhibicion,

                $sqlUpdate,

                [$diasNuevos, $tienda, $anio, $semana, $dni]

            );



            if ($stmtUpdate === false) {

                throw new RuntimeException('No se pudo actualizar.');

            }



            sqlsrv_free_stmt($stmtUpdate);



            $cambios[] = [

                'accion' => 'DIAS_TRABAJADOS_ACTUALIZADO',

                'detalle' =>

                    "Se actualizaron los días trabajados.\n"

                    . "• Tienda: {$tiendaAuditoria}\n"

                    . "• Vendedor: {$nombre} · Código: {$codVendedor} · DNI: {$dni}\n"

                    . "• Temporalidad: Semana Retail {$semana} del año {$anio}{$rangoSemana}\n"

                    . "• Cambio: {$formatearDias($diasAnteriores)} → {$formatearDias($diasNuevos)} días."

            ];

        } else {

            $sqlInsert = "

                INSERT INTO [vistasMCC].[dbo].[TB_SMF_DIAS_TRABAJADOS_SEMANAL]

                    (TIENDA, ANIO, SEMANA, DNI, DIAS_TRABAJADOS)

                VALUES (?, ?, ?, ?, ?)

            ";



            $stmtInsert = sqlsrv_query(

                $sqlsrv_conn_exhibicion,

                $sqlInsert,

                [$tienda, $anio, $semana, $dni, $diasNuevos]

            );



            if ($stmtInsert === false) {

                throw new RuntimeException('No se pudo insertar.');

            }



            sqlsrv_free_stmt($stmtInsert);



            $cambios[] = [

                'accion' => 'DIAS_TRABAJADOS_CREADO',

                'detalle' =>

                    "Se registraron los días trabajados.\n"

                    . "• Tienda: {$tiendaAuditoria}\n"

                    . "• Vendedor: {$nombre} · Código: {$codVendedor} · DNI: {$dni}\n"

                    . "• Temporalidad: Semana Retail {$semana} del año {$anio}{$rangoSemana}\n"

                    . "• Días registrados: {$formatearDias($diasNuevos)} días."

            ];

        }

    }



    // Aunque los días no hayan variado, puede cambiar el código temporal
    // asociado a esta semana. Se guarda más abajo en MySQL.
    if (empty($cambios)) {
        if (!sqlsrv_rollback($sqlsrv_conn_exhibicion)) {
            throw new RuntimeException('No se pudo cerrar la consulta sin cambios.');
        }
    } elseif (!sqlsrv_commit($sqlsrv_conn_exhibicion)) {
        throw new RuntimeException('No se pudo confirmar la transacción.');
    }



} catch (Throwable $e) {

    @sqlsrv_rollback($sqlsrv_conn_exhibicion);



    error_log(

        'DIAS: error guardando: '

        . $e->getMessage()

        . ' '

        . print_r(sqlsrv_errors(), true)

    );



    header("Location: {$volver}&error=guardar");

    exit();

}



/*
|--------------------------------------------------------------------------
| CÓDIGO DEL VENDEDOR POR TIENDA / AÑO / SEMANA EN MYSQL
|--------------------------------------------------------------------------
| La tabla SQL Server de días solo contiene DNI, no CODVENDEDOR.
| Se registra el código del formulario después de confirmar los días.
| Guardar los mismos días nuevamente permite corregir únicamente el código.
| Nunca se modifica el esquema de SQL Server.
*/
if (!empty($procesar) || !empty($migracionesCodigoSemanal)) {
    $transaccionMySql = false;
    $stmtCodigoSemanal = null;
    try {
        if (!$conn->begin_transaction()) {
            throw new RuntimeException('No se pudo iniciar el guardado del código semanal.');
        }
        $transaccionMySql = true;

        // Trasladar las claves DNI de MySQL cuando la misma identidad se
        // trasladó en la tabla semanal de SQL Server.
        if ($migracionesCodigoSemanal) {
            $stmtMoverCodigo = $conn->prepare(
                "UPDATE dias_trabajados_codigos_semanales
                 SET dni = ? WHERE tienda = ? AND dni = ?"
            );
            if (!$stmtMoverCodigo) {
                throw new RuntimeException('No se pudo preparar la vinculación semanal.');
            }
            foreach ($migracionesCodigoSemanal as [$dniViejo, $dniNuevo]) {
                $stmtMoverCodigo->bind_param('sss', $dniNuevo, $tienda, $dniViejo);
                if (!$stmtMoverCodigo->execute()) {
                    $stmtMoverCodigo->close();
                    throw new RuntimeException('No se pudo actualizar la vinculación semanal.');
                }
            }
            $stmtMoverCodigo->close();
        }

        $stmtCodigoSemanal = $conn->prepare(
            "INSERT INTO dias_trabajados_codigos_semanales
                 (tienda, anio, semana, dni, codvendedor, actualizado_por)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                 actualizado_por = IF(
                     codvendedor <> VALUES(codvendedor), VALUES(actualizado_por), actualizado_por
                 ),
                 codvendedor = VALUES(codvendedor)"
        );
        if (!$stmtCodigoSemanal) {
            throw new RuntimeException('Falta la tabla de vinculación de códigos semanales.');
        }

        foreach ($procesar as $itemCodigo) {
            $anioCodigo = (int)$itemCodigo['anio'];
            $semanaCodigo = (int)$itemCodigo['semana'];
            $dniCodigo = (string)$itemCodigo['dni'];
            $codigoElegido = (string)$itemCodigo['codvendedor'];
            if ($codigoElegido === '' || $codigoElegido === '3146') {
                throw new RuntimeException('Código semanal no válido.');
            }
            // Un código no puede corresponder a dos identidades en la misma semana.
            // Comprobar antes del UPSERT evita reasignaciones silenciosas por UNIQUE.
            $stmtVerificarCodigo = $conn->prepare(
                "SELECT dni FROM dias_trabajados_codigos_semanales
                 WHERE tienda = ? AND anio = ? AND semana = ?
                   AND codvendedor = ? LIMIT 1 FOR UPDATE"
            );
            if (!$stmtVerificarCodigo) {
                throw new RuntimeException('No se pudo verificar el código semanal.');
            }
            $stmtVerificarCodigo->bind_param('siis', $tienda, $anioCodigo, $semanaCodigo, $codigoElegido);
            if (!$stmtVerificarCodigo->execute()) {
                $stmtVerificarCodigo->close();
                throw new RuntimeException('No se pudo consultar el código semanal.');
            }
            $stmtVerificarCodigo->bind_result($dniDeCodigo);
            $existeCodigo = $stmtVerificarCodigo->fetch();
            $stmtVerificarCodigo->close();
            if ($existeCodigo && (string)$dniDeCodigo !== $dniCodigo) {
                throw new RuntimeException('El código ya está asociado a otro DNI en esta semana.');
            }
            $stmtCodigoSemanal->bind_param(
                'siissi',
                $tienda, $anioCodigo, $semanaCodigo,
                $dniCodigo, $codigoElegido, $usuarioId
            );
            if (!$stmtCodigoSemanal->execute()) {
                throw new RuntimeException('No se pudo guardar el código del vendedor.');
            }
            if ($stmtCodigoSemanal->affected_rows > 0) {
                $cambios[] = [
                    'accion' => 'DIAS_TRABAJADOS_ACTUALIZADO',
                    'detalle' => "Código de vendedor vinculado a días guardados. "
                        . "Tienda: {$tienda}; año: {$anioCodigo}; semana: {$semanaCodigo}; "
                        . "DNI: {$dniCodigo}; código: {$codigoElegido}."
                ];
            }
        }
        $stmtCodigoSemanal->close();
        $stmtCodigoSemanal = null;
        if (!$conn->commit()) {
            throw new RuntimeException('No se pudo confirmar el código semanal.');
        }
        $transaccionMySql = false;
    } catch (Throwable $e) {
        if ($stmtCodigoSemanal instanceof mysqli_stmt) {
            $stmtCodigoSemanal->close();
        }
        if ($transaccionMySql) {
            $conn->rollback();
        }
        error_log('DÍAS: no se pudo guardar código semanal en MySQL: ' . $e->getMessage());
        // Los días de SQL Server ya pueden haber sido confirmados.
        header("Location: {$volver}&error=guardar");
        exit();
    }
}

if (empty($cambios)) {
    header("Location: {$volver}&info=sin_cambios");
    exit();
}

/*
AUDITORÍA
*/

$auditoriaOk = true;



foreach ($cambios as $cambio) {

    if (!dias_registrar_auditoria(

        $conn,

        (string)$cambio['accion'],

        (string)$cambio['detalle']

    )) {

        $auditoriaOk = false;

    }

}



header(

    "Location: {$volver}"

    . "&ok=1"

    . "&cambios=" . count($cambios)

    . "&audit=" . ($auditoriaOk ? '1' : '0')

);

exit();
