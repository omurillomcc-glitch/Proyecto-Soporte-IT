<?php

require_once dirname(__DIR__) . '/user/auth.php';

require_login();

require_once dirname(__DIR__) . '/user/conexion.php';

require_once dirname(__DIR__) . '/resumen/db.php';

require_once dirname(__DIR__) . '/resumen/retail_helper.php';

require_once dirname(__DIR__) . '/vendedores/dias_helper.php';


$baseUrl = $baseUrl ?? '/SemafaroVen';


function smf_h($v): string {

    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');

}


function smf_num($v, int $d = 2): string {

    return number_format((float)$v, $d, '.', ',');

}


function smf_fecha($v, string $f = 'd/m'): string {

    return $v instanceof DateTimeInterface

        ? $v->format($f)

        : ($v ? date($f, strtotime((string)$v)) : '—');

}

function smf_url(array $s, string $t): string {

    return '?' . http_build_query([

        'semana' => (int)$s['semana'],

        'tienda' => $t

    ]);

}

function smf_iniciales(string $nombre): string {

    $p = preg_split('/\s+/u', trim($nombre)) ?: [];

    if (!$p) return '--';



    return mb_strtoupper(

        mb_substr($p[0], 0, 1, 'UTF-8') .

        mb_substr(

            $p[count($p) > 2 ? 2 : (count($p) > 1 ? 1 : 0)],

            0, 1, 'UTF-8'

        ),

        'UTF-8'

    );

}
/* Criterio MB automatico por nombre de tienda. */
function smf_modo_meta_mb(string $nombreTienda): string {
    $nombre = mb_strtolower(trim($nombreTienda), 'UTF-8');
    $nombre = strtr($nombre, [
        'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u',
    ]);

// Galerias: la Meta MB del Excel es la Meta con IVA por la tasa MB.
if (strpos($nombre, 'galerias') !== false) {
    return 'con_iva';
}

// Ceiba, Metromall y Dani: Excel divide la Meta con IVA entre 1.15.
if (strpos($nombre, 'ceiba') !== false || strpos($nombre, 'metromall') !== false || strpos($nombre, 'dani') !== false) {
    return 'sin_iva';
}

// Para tiendas sin Excel validado, se usa el criterio de la guia compartida.
return 'sin_iva';
}



function smf_meta_mb(float $meta, ?float $tasa, string $modo): ?float {
    if ($tasa === null) {
        return null;
    }
    $base = $modo === 'sin_iva' ? $meta / 1.15 : $meta;
    return round($base * $tasa, 2);
}

/* Repartir la meta de vendedores en centavos enteros, sin crear centavos de más.
 * Cada vendedor recibe su cuota proporcional a los días realmente registrados.
 * Los centavos restantes se asignan por mayor residuo (desempate por DNI).
 */
function smf_repartir_meta_dias(array $diasPorDni, float $metaVendedores): array {
    $reparto = [];
    $diasValidos = 0.0;
    foreach ($diasPorDni as $dni => $dias) {
        $dias = max(0.0, (float)$dias);
        $reparto[(string)$dni] = 0.0;
        $diasValidos += $dias;
    }
    $totalCentavos = (int)round($metaVendedores * 100);
    if ($diasValidos <= 0.0 || $totalCentavos <= 0) {
        return $reparto;
    }
    $restos = [];
    $usados = 0;
    foreach ($diasPorDni as $dni => $dias) {
        $dni = (string)$dni;
        $exactos = $totalCentavos * max(0.0, (float)$dias) / $diasValidos;
        $enteros = (int)floor($exactos);
        $reparto[$dni] = $enteros;
        $restos[] = ['dni' => $dni, 'fraccion' => $exactos - $enteros];
        $usados += $enteros;
    }
    usort($restos, static function (array $a, array $b): int {
        return ($b['fraccion'] <=> $a['fraccion'])
            ?: strcmp($a['dni'], $b['dni']);
    });
    $pendientes = $totalCentavos - $usados;
    $n = count($restos);
    for ($i = 0; $i < $pendientes && $n > 0; $i++) {
        $reparto[$restos[$i % $n]['dni']]++;
    }
    foreach ($reparto as &$centavos) {
        $centavos /= 100.0;
    }
    unset($centavos);
    return $reparto;
}

/* PERMISOS Y TIENDA AUTORIZADA */

$rol = (string)($_SESSION['rol'] ?? '');

$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);

if (

    $usuarioId <= 0 ||

    !in_array($rol, [

        'administrador',

        'gerente_comercial',

        'gerente_tienda'

    ], true)

) {

    header(

        'Location: ' . $baseUrl .

        '/index.php?error=no_autorizado'

    );

    exit;

}

$tiendas = retail_obtener_tiendas_permitidas(

    $conn,

    $sqlsrv_conn_exhibicion ?? false,

    $rol,

    $usuarioId

);

$codigoSeleccionado = smf_entrada_texto(

    $_GET['tienda'] ?? '',

    30

);



if (

    $codigoSeleccionado === '' ||

    !isset($tiendas[$codigoSeleccionado])

) {

    $codigoSeleccionado = $tiendas

        ? (string)array_key_first($tiendas)

        : '';

}



$tiendaSeleccionada = $tiendas[$codigoSeleccionado] ?? null;

$nombreTienda = (string)($tiendaSeleccionada['nombre'] ?? '');
$modoMetaMb = smf_modo_meta_mb($nombreTienda);

/* SEMANA RETAIL */
$tz = new DateTimeZone('America/Tegucigalpa');

$hoy = new DateTimeImmutable('today', $tz);

$anioVista = (int)$hoy->format('Y');

$semanasPorNumero = [];

for ($mes = 1; $mes <= 12; $mes++) {

    foreach (retail_obtener_semanas_mes($anioVista, $mes) as $s) {

        $n = (int)($s['semana'] ?? 0);



        if (

            (int)($s['anio'] ?? 0) === $anioVista &&

            $n >= 35 &&

            $n <= 53

        ) {

            $semanasPorNumero[$n] = $s;

        }

    }

}

ksort($semanasPorNumero);

$semanasDisponibles = array_values($semanasPorNumero);

$semanaActual = null;

foreach ($semanasDisponibles as $s) {

    if (

        $hoy >= $s['fecha_inicio'] &&

        $hoy <= $s['fecha_fin']

    ) {

        $semanaActual = $s;

        break;

    }

}

$solicitada = filter_input(

    INPUT_GET,

    'semana',

    FILTER_VALIDATE_INT

);

$semanaSeleccionada = (

    $solicitada !== false &&

    $solicitada !== null

)

    ? ($semanasPorNumero[$solicitada] ?? $semanaActual)

    : $semanaActual;



$numeroSemanaRetail = (int)(

    $semanaSeleccionada['semana'] ?? 0

);



$fechaDesde = $semanaSeleccionada

    ? $semanaSeleccionada['fecha_inicio']->format('Y-m-d')

    : '';



$fechaHasta = $semanaSeleccionada

    ? $semanaSeleccionada['fecha_fin']->format('Y-m-d')

    : '';



$indiceSemana = null;

foreach ($semanasDisponibles as $i => $s) {

    if ((int)$s['semana'] === $numeroSemanaRetail) {

        $indiceSemana = $i;

        break;

    }

}

$semanaAnterior = $indiceSemana === null

    ? null

    : ($semanasDisponibles[$indiceSemana - 1] ?? null);



$semanaSiguiente = $indiceSemana === null

    ? null

    : ($semanasDisponibles[$indiceSemana + 1] ?? null);



$meses = [

    1 => 'Enero',

    2 => 'Febrero',

    3 => 'Marzo',

    4 => 'Abril',

    5 => 'Mayo',

    6 => 'Junio',

    7 => 'Julio',

    8 => 'Agosto',

    9 => 'Septiembre',

    10 => 'Octubre',

    11 => 'Noviembre',

    12 => 'Diciembre'

];
$fechaCabecera = $fechaDesde

    ? new DateTimeImmutable($fechaDesde, $tz)

    : $hoy;



$mesEncabezado = $meses[

    (int)$fechaCabecera->format('n')

];



$anioEncabezado = $fechaCabecera->format('Y');

/*

 * META MB: referencia de la empresa, independiente del margen real.

 * Archivo privado fuera de htdocs; NO se crean ni alteran tablas SQL.

 * La tasa es registrada por un usuario autorizado para tienda y semana.

 * Si no se actualiza, puede heredarse de una semana anterior del mismo año.

 */

$archivoTasas = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR

    . 'privado_semaforo' . DIRECTORY_SEPARATOR . 'tasas_mb.json';

$directorioTasas = dirname($archivoTasas);

$puedeEditarTasa = in_array($rol, ['administrador', 'gerente_comercial'], true);

$mensajeTasa = '';

$errorTasa = '';

$clavePeriodo = $anioVista . '_' . $numeroSemanaRetail . '_' . $codigoSeleccionado;

$tasasGuardadas = [];



if (is_file($archivoTasas) && is_readable($archivoTasas)) {

    $datos = json_decode((string)file_get_contents($archivoTasas), true);

    if (is_array($datos)) {

        $tasasGuardadas = $datos;

    } else {

        $errorTasa = 'No fue posible leer las tasas MB guardadas.';

    }

}



if (empty($_SESSION['csrf_meta_mb'])) {

    $_SESSION['csrf_meta_mb'] = bin2hex(random_bytes(32));

}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['guardar_meta_mb'])) {

    $postTienda = smf_entrada_texto($_POST['tienda'] ?? '', 30);

    $postSemana = filter_var($_POST['semana'] ?? null, FILTER_VALIDATE_INT);

    $postTasa = trim((string)($_POST['porcentaje_mb'] ?? ''));

    $postTasa = str_replace(',', '.', $postTasa);

    $tokenValido = hash_equals(

        (string)$_SESSION['csrf_meta_mb'],

        (string)($_POST['csrf_meta_mb'] ?? '')

    );



    if (!$puedeEditarTasa || !$tokenValido || !isset($tiendas[$postTienda])

        || $postTienda !== $codigoSeleccionado || $postSemana !== $numeroSemanaRetail

        || !preg_match('/^\d{1,2}(?:\.\d{1,7})?$/', $postTasa)

        || (float)$postTasa <= 0 || (float)$postTasa >= 100) {

        $errorTasa = 'No se pudo guardar la tasa MB. Verifica el porcentaje y los permisos.';

    } elseif (!is_dir($directorioTasas) || !is_writable(

        is_file($archivoTasas) ? $archivoTasas : $directorioTasas

    )) {

        $errorTasa = 'El archivo privado de tasas (o su carpeta) no permite escritura desde Apache.';

    } else {

        $archivo = @fopen($archivoTasas, 'c+');

        if ($archivo !== false && flock($archivo, LOCK_EX)) {

            rewind($archivo);

            $original = stream_get_contents($archivo);

            $actual = json_decode((string)$original, true);

            if (trim((string)$original) !== '' && !is_array($actual)) {

                $errorTasa = 'El archivo privado de tasas tiene un formato inválido.';

            } else {

                $actual = is_array($actual) ? $actual : [];

                $actual[$clavePeriodo] = round((float)$postTasa, 4);

                $contenido = json_encode($actual, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

                if ($contenido === false) {

                    $errorTasa = 'No se pudo preparar el archivo de tasas.';

                } else {

                    rewind($archivo);

                    if (ftruncate($archivo, 0) && fwrite($archivo, $contenido . "\n") !== false) {

                        fflush($archivo);

                        $tasasGuardadas = $actual;

                        $mensajeTasa = 'Meta MB guardada para la tienda y semana seleccionadas.';

                    } else {

                        $errorTasa = 'No se pudo guardar la tasa MB en el archivo privado.';

                    }

                }

            }

            flock($archivo, LOCK_UN);

        } else {

            $errorTasa = 'No se pudo abrir el archivo privado de tasas MB.';

        }

        if ($archivo !== false) {

            fclose($archivo);

        }

    }

}

// Tasa exacta de la semana; si no existe, hereda la última anterior de la tienda.

$tasaPorcentaje = null;

$tasaOrigen = 'sin meta MB guardada';

if (isset($tasasGuardadas[$clavePeriodo]) && is_numeric($tasasGuardadas[$clavePeriodo])) {

    $tasaPorcentaje = (float)$tasasGuardadas[$clavePeriodo];

    $tasaOrigen = 'registrada para esta semana';

} else {

    for ($semanaAnteriorTasa = $numeroSemanaRetail - 1; $semanaAnteriorTasa >= 1; $semanaAnteriorTasa--) {

        $claveAnterior = $anioVista . '_' . $semanaAnteriorTasa . '_' . $codigoSeleccionado;

        if (isset($tasasGuardadas[$claveAnterior]) && is_numeric($tasasGuardadas[$claveAnterior])) {

            $tasaPorcentaje = (float)$tasasGuardadas[$claveAnterior];

            $tasaOrigen = 'última tasa de esta tienda (semana ' . $semanaAnteriorTasa . ')';

            break;

        }

    }

}

$tasaMetaMb = ($tasaPorcentaje !== null && $tasaPorcentaje > 0 && $tasaPorcentaje < 100)

    ? $tasaPorcentaje / 100.0

    : null;

/* PORCENTAJE DE AUTOSERVICIO DEFINIDO POR USUARIO (CON HERENCIA SEMANAL) */

$archivoAuto = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR

    . 'privado_semaforo' . DIRECTORY_SEPARATOR . 'porcentajes_auto.json';

$autosGuardados = [];
$errorLecturaAuto = false;

if (is_file($archivoAuto)) {
    if (!is_readable($archivoAuto)) {
        $errorLecturaAuto = true;
        $errorTasa = 'El archivo privado de Autoservicio no permite lectura.';
    } else {
        $contenidoAuto = (string)file_get_contents($archivoAuto);
        if (trim($contenidoAuto) !== '') {
            $datosAuto = json_decode($contenidoAuto, true);
            if (is_array($datosAuto)) {
                $autosGuardados = $datosAuto;
            } else {
                $errorLecturaAuto = true;
                $errorTasa = 'El JSON privado de Autoservicio no es válido; no se modificará.';
            }
        }
    }
}
/* Autoservicio se edita por porcentaje; se admiten configuraciones anteriores. */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['guardar_porc_auto'])) {
    $postTienda = smf_entrada_texto($_POST['tienda'] ?? '', 30);
    $postSemana = filter_var($_POST['semana'] ?? null, FILTER_VALIDATE_INT);
    $modoGuardado = (string)($_POST['modo_auto'] ?? 'porcentaje');
    $postPorcentaje = str_replace(',', '.', trim((string)($_POST['porcentaje_auto'] ?? '')));
    $postMetaVendedores = str_replace(',', '.', trim((string)($_POST['meta_vendedores_auto'] ?? '')));
    $tokenValido = hash_equals(
        (string)$_SESSION['csrf_meta_mb'],
        (string)($_POST['csrf_meta_mb'] ?? '')
    );

    if (!$puedeEditarTasa || !$tokenValido || !isset($tiendas[$postTienda])
        || $postTienda !== $codigoSeleccionado || $postSemana !== $numeroSemanaRetail
        || !in_array($modoGuardado, ['porcentaje', 'meta_vendedores'], true)) {
        $errorTasa = 'No se pudo guardar Autoservicio. Revisa la tienda, la semana y tus permisos.';
    } elseif ($errorLecturaAuto) {
        $errorTasa = 'No se guardó: verifica primero el JSON privado de Autoservicio.';
    } else {
        $nuevoAuto = null;
        if ($modoGuardado === 'porcentaje') {
            // Permite hasta 10 decimales: 20.5737691466 es válido.
            if (!preg_match('/^\d{1,2}(?:\.\d{1,10})?$/D', $postPorcentaje)
                || (float)$postPorcentaje < 0 || (float)$postPorcentaje >= 100) {
                $errorTasa = 'Indica un porcentaje de 0 a menos de 100, con hasta 10 decimales.';
            } else {
                $nuevoAuto = ['modo' => 'porcentaje', 'valor' => round((float)$postPorcentaje, 10)];
            }
        } else {
            if (!preg_match('/^\d+(?:\.\d{1,2})?$/D', $postMetaVendedores)
                || !is_finite((float)$postMetaVendedores) || (float)$postMetaVendedores > 100000000000) {
                $errorTasa = 'La meta de vendedores debe indicarse en lempiras, con máximo dos decimales.';
            } elseif (empty($sqlsrv_conn_exhibicion) || !$semanaSeleccionada) {
                $errorTasa = 'No hay conexión para verificar la meta de la tienda.';
            } else {
                // Solo lectura: validar contra la meta vigente antes de guardar.
                $qMetaAuto = sqlsrv_query($sqlsrv_conn_exhibicion, <<<'SQL'
SELECT MAX(META) AS META
FROM vistasMCC..TB_SMF_METAS_SEMANALES
WHERE TIENDA = ? AND ANIO = ? AND SEMANA = ?
SQL, [$codigoSeleccionado, (int)$semanaSeleccionada['anio'], $numeroSemanaRetail]);
                if ($qMetaAuto === false) {
                    $errorTasa = 'No se pudo verificar la meta semanal de la tienda.';
                } else {
                    $fMetaAuto = sqlsrv_fetch_array($qMetaAuto, SQLSRV_FETCH_ASSOC) ?: [];
                    sqlsrv_free_stmt($qMetaAuto);
                    $totalMetaVerificada = round((float)($fMetaAuto['META'] ?? 0), 2);
                    $importeVendedores = round((float)$postMetaVendedores, 2);
                    if ($totalMetaVerificada <= 0 || $importeVendedores > $totalMetaVerificada) {
                        $errorTasa = 'Meta vendedores no puede superar la meta semanal de la tienda.';
                    } else {
                        $nuevoAuto = [
                            'modo' => 'meta_vendedores',
                            'valor' => $importeVendedores,
                            'meta_tienda_referencia' => $totalMetaVerificada,
                            'porcentaje_auto' => round(
                                (($totalMetaVerificada - $importeVendedores) / $totalMetaVerificada) * 100.0, 10
                            )
                        ];
                    }
                }
            }
        }

        if ($nuevoAuto !== null && $errorTasa === '') {
            $carpetaAuto = dirname($archivoAuto);
            if (!is_dir($carpetaAuto)
                || !is_writable(is_file($archivoAuto) ? $archivoAuto : $carpetaAuto)) {
                $errorTasa = 'No se pudo guardar: verifica permisos de la carpeta privada.';
            } else {
                $fAuto = @fopen($archivoAuto, 'c+');
                if ($fAuto === false || !flock($fAuto, LOCK_EX)) {
                    $errorTasa = 'No se pudo bloquear el archivo privado de Autoservicio.';
                } else {
                    rewind($fAuto);
                    $textoPrevio = stream_get_contents($fAuto);
                    $guardadoPrevio = json_decode((string)$textoPrevio, true);
                    if (trim((string)$textoPrevio) !== '' && !is_array($guardadoPrevio)) {
                        $errorTasa = 'El archivo privado de Autoservicio contiene JSON inválido.';
                    } else {
                        $guardadoPrevio = is_array($guardadoPrevio) ? $guardadoPrevio : [];
                        $guardadoPrevio[$clavePeriodo] = $nuevoAuto;
                        $jsonAuto = json_encode($guardadoPrevio, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
                        if ($jsonAuto === false) {
                            $errorTasa = 'No se pudo preparar la configuración de Autoservicio.';
                        } else {
                            rewind($fAuto);
                            $textoNuevo = $jsonAuto . "\n";
                            $bytes = fwrite($fAuto, $textoNuevo);
                            if ($bytes !== strlen($textoNuevo) || !ftruncate($fAuto, ftell($fAuto))) {
                                $errorTasa = 'No se pudo terminar de guardar Autoservicio.';
                            } else {
                                fflush($fAuto);
                                $autosGuardados = $guardadoPrevio;
                                $mensajeTasa = $modoGuardado === 'meta_vendedores'
                                    ? 'Meta de vendedores guardada. Autoservicio se calcula por diferencia.'
                                    : 'Porcentaje exacto de Autoservicio guardado.';
                            }
                        }
                    }
                    flock($fAuto, LOCK_UN);
                }
                if (is_resource($fAuto)) fclose($fAuto);
            }
        }
    }
}

/* Compatibilidad: registros anteriores eran números; los nuevos incluyen modo. */
function smf_config_auto($dato): ?array {
    if (is_numeric($dato)) {
        $t = (float)$dato;
        return is_finite($t) && $t >= 0 && $t < 100
            ? ['modo' => 'porcentaje', 'valor' => $t, 'porcentaje' => $t] : null;
    }
    if (!is_array($dato)) return null;
    $modo = (string)($dato['modo'] ?? '');
    $porcentaje = isset($dato['porcentaje_auto']) && is_numeric($dato['porcentaje_auto'])
        ? (float)$dato['porcentaje_auto'] : null;
    // Formatos usados por versiones anteriores: meta_vendedores / porcentaje_auto.
    if (in_array($modo, ['meta_vendedores', 'meta_autoservicio'], true)) {
        $meta = isset($dato['valor']) && is_numeric($dato['valor'])
            ? (float)$dato['valor']
            : (isset($dato['meta_vendedores']) && is_numeric($dato['meta_vendedores'])
                ? (float)$dato['meta_vendedores'] : null);
        if ($meta === null || !is_finite($meta) || $meta < 0) return null;
        $ref = isset($dato['meta_tienda_referencia']) && is_numeric($dato['meta_tienda_referencia'])
            ? (float)$dato['meta_tienda_referencia'] : 0.0;
        if (($porcentaje === null || !is_finite($porcentaje)) && $ref > 0) {
            $porcentaje = (1.0 - $meta / $ref) * 100.0;
        }
        if ($porcentaje !== null && ($porcentaje < 0 || $porcentaje >= 100)) return null;
        return ['modo' => 'meta_vendedores', 'valor' => round($meta, 2), 'porcentaje' => $porcentaje];
    }
    if ($modo === 'porcentaje') {
        $valor = isset($dato['valor']) && is_numeric($dato['valor'])
            ? (float)$dato['valor']
            : (isset($dato['porcentaje']) && is_numeric($dato['porcentaje'])
                ? (float)$dato['porcentaje'] : $porcentaje);
        return $valor !== null && is_finite($valor) && $valor >= 0 && $valor < 100
            ? ['modo' => 'porcentaje', 'valor' => $valor, 'porcentaje' => $valor] : null;
    }
    return null;
}

$porcentajeAuto = null;
$metaVendedoresConfigurada = null;
$modoConfiguracionAuto = 'porcentaje';
$tienePorcGuardado = false;
$origenPorcentajeAuto = 'sin configuración';
$configAutoVigente = null;

if (array_key_exists($clavePeriodo, $autosGuardados)) {
    $configAutoVigente = smf_config_auto($autosGuardados[$clavePeriodo]);
    if ($configAutoVigente !== null) {
        $tienePorcGuardado = true;
        $origenPorcentajeAuto = 'Guardado para esta tienda y semana';
    }
}
if ($configAutoVigente === null) {
    for ($semAnt = $numeroSemanaRetail - 1; $semAnt >= 1; $semAnt--) {
        $claveAnt = $anioVista . '_' . $semAnt . '_' . $codigoSeleccionado;
        if (array_key_exists($claveAnt, $autosGuardados)) {
            $configAutoVigente = smf_config_auto($autosGuardados[$claveAnt]);
            if ($configAutoVigente !== null) {
                // Semanas futuras heredan el porcentaje, nunca un monto fijo de la semana pasada.
                $tasaHeredada = $configAutoVigente['porcentaje'];
                if ($tasaHeredada === null) {
                    $configAutoVigente = null;
                    continue;
                }
                $configAutoVigente = [
                    'modo' => 'porcentaje', 'valor' => round((float)$tasaHeredada, 10),
                    'porcentaje' => round((float)$tasaHeredada, 10)
                ];
                $tienePorcGuardado = true;
                $origenPorcentajeAuto = 'Heredado de la semana ' . $semAnt . ' de esta tienda';
                break;
            }
        }
    }
}
if ($configAutoVigente !== null) {
    $modoConfiguracionAuto = $configAutoVigente['modo'];
    if ($modoConfiguracionAuto === 'meta_vendedores') {
        $metaVendedoresConfigurada = round((float)$configAutoVigente['valor'], 2);
    } else {
        $porcentajeAuto = round((float)$configAutoVigente['valor'], 10);
    }
}

/* VARIABLES DEL REPORTE */
$registros = [];

$ventasPorCodigo = [];

$errorLocal = '';

$aviso = '';

$totalDiasPeriodo = 0.0;

$metaTotalTienda = 0.0;

$metaVendedoresGrupo = 0.0;

$metaAutoservicio = 0.0;

$diasSinVincular = 0.0;


/* CONEXION SQL SERVER */



if (empty($sqlsrv_conn_exhibicion)) {



    $errorLocal = 'No hay conexión disponible con SQL Server.';



} elseif (!$tiendaSeleccionada) {



    $errorLocal = 'No hay una tienda autorizada.';



} elseif (!$semanaSeleccionada) {



    $errorLocal = 'No hay una Semana Retail válida.';



} elseif ($porcentajeAuto === null && $metaVendedoresConfigurada === null) {

    $errorLocal = 'Configura el porcentaje de Autoservicio para esta tienda y semana.';

} else {



    $db = $sqlsrv_conn_exhibicion;



    $p = [

        $codigoSeleccionado,

        (int)$semanaSeleccionada['anio'],

        $numeroSemanaRetail

    ];

    /* DIAS REALMENTE GUARDADOS */
    $q = sqlsrv_query($db, <<<'SQL'

SELECT

    DNI,

    SUM(DIAS_TRABAJADOS) AS DIAS

FROM vistasMCC..TB_SMF_DIAS_TRABAJADOS_SEMANAL

WHERE TIENDA = ?

  AND ANIO = ?

  AND SEMANA = ?

GROUP BY DNI

SQL, $p);



    $diasPorDni = [];

    if ($q === false) {

        $errorLocal = 'No se pudieron consultar los días guardados.';

        error_log('Semáforo: fallo en consulta de días.');

    } else {

        while ($f = sqlsrv_fetch_array(

            $q, SQLSRV_FETCH_ASSOC

        )) {

            $dni = dias_normalizar_dni(

                (string)($f['DNI'] ?? '')

            );

            $diasPorDni[$dni] =

                ($diasPorDni[$dni] ?? 0.0) +

                (float)($f['DIAS'] ?? 0);

        }

        sqlsrv_free_stmt($q);

        $totalDiasPeriodo = array_sum($diasPorDni);

    }

    /* META SEMANAL */

    if ($errorLocal === '') {

        $q = sqlsrv_query($db, <<<'SQL'

SELECT MAX(META) AS META

FROM vistasMCC..TB_SMF_METAS_SEMANALES

WHERE TIENDA = ?

  AND ANIO = ?

  AND SEMANA = ?

SQL, $p);



        if ($q === false) {

            $errorLocal = 'No se pudo consultar la meta semanal.';

        } else {

            $f = sqlsrv_fetch_array($q, SQLSRV_FETCH_ASSOC) ?: [];


            // La tabla TB_SMF_METAS_SEMANALES guarda META en lempiras.

            // Usar exactamente el mismo valor que muestra resumen/meta_semanal.php.

            // Nunca dividir entre 100: ese ajuste reducía la meta y disparaba el logro.

            $metaCruda = (float)($f['META'] ?? 0);

            $metaTotalTienda = is_finite($metaCruda) && $metaCruda > 0

                ? round($metaCruda, 2)

                : 0.0;



            sqlsrv_free_stmt($q);

        }

    }

    // El porcentaje proviene de la configuración realizada por el usuario.
    // La meta de vendedores siempre es el total menos la de Autoservicio.
if ($metaVendedoresConfigurada !== null) {
    if ($metaVendedoresConfigurada > $metaTotalTienda) {
        $errorLocal = 'La meta de vendedores guardada supera la meta de la tienda. Corrige la configuración.';
        $metaVendedoresGrupo = 0.0;
        $metaAutoservicio = 0.0;
    } else {
        $metaVendedoresGrupo = round($metaVendedoresConfigurada, 2);
        $metaAutoservicio = round($metaTotalTienda - $metaVendedoresGrupo, 2);
    }
    // Solo para mostrar: Excel puede presentar 21% aunque la cuota sea 20.5737...%.
    $porcentajeAuto = $metaTotalTienda > 0 ? ($metaAutoservicio / $metaTotalTienda) * 100.0 : 0.0;
} else {
    $metaAutoservicio = round($metaTotalTienda * ($porcentajeAuto / 100.0), 2);
    $metaVendedoresGrupo = round($metaTotalTienda - $metaAutoservicio, 2);
}

    /* IDENTIDADES MANUALES */
    $dniManualPorCodigo = [];

    if ($errorLocal === '' && $conn instanceof mysqli) {

        try {

            $st = $conn->prepare(

                "SELECT codvendedor, dni, tienda

                 FROM dias_trabajados_identidades_manual

                 WHERE tienda = '*' OR tienda = ?

                 ORDER BY CASE

                    WHEN tienda = '*' THEN 0

                    ELSE 1

                 END"

            );

            if ($st) {

                $st->bind_param(

                    's',

                    $codigoSeleccionado

                );

                $st->execute();

                $st->bind_result(

                    $cod,

                    $dni,

                    $t

                );



                while ($st->fetch()) {

                    $cod = trim((string)$cod);

                    $dni = dias_normalizar_dni(

                        (string)$dni

                    );

                    if ($cod !== '' && $dni !== '') {

                        $dniManualPorCodigo[$cod] = $dni;

                    }

                }



                $st->close();

            }

        } catch (Throwable $e) {

            error_log(

                'Semáforo: error de lectura de equivalencias de DNI.'

            );

        }

    }

    /* CÓDIGO ASIGNADO AL REGISTRAR DÍAS EN ESTA TIENDA Y SEMANA.
     * MySQL guarda la relación DNI -> código; SQL Server mantiene su
     * tabla de días original, sin nuevas columnas ni cambios de esquema.
     */
    $codigoSemanalPorDni = [];
    if ($errorLocal === '' && $conn instanceof mysqli) {
        try {
            $stCodigo = $conn->prepare(
                "SELECT dni, codvendedor
                 FROM dias_trabajados_codigos_semanales
                 WHERE tienda = ? AND anio = ? AND semana = ?"
            );
            if (!$stCodigo) {
                throw new RuntimeException('Consulta de códigos semanales no disponible.');
            }
            $anioCodigo = (int)$semanaSeleccionada['anio'];
            $stCodigo->bind_param('sii', $codigoSeleccionado, $anioCodigo, $numeroSemanaRetail);
            if (!$stCodigo->execute()) {
                $stCodigo->close();
                throw new RuntimeException('No se pudo consultar el código semanal.');
            }
            $stCodigo->bind_result($dniVinculado, $codigoVinculado);
            while ($stCodigo->fetch()) {
                $dniNormalizado = dias_normalizar_dni((string)$dniVinculado);
                $codigoReal = trim((string)$codigoVinculado);
                if ($dniNormalizado !== '' && $codigoReal !== '' && $codigoReal !== '3146') {
                    $codigoSemanalPorDni[$dniNormalizado] = $codigoReal;
                }
            }
            $stCodigo->close();
        } catch (Throwable $e) {
            error_log('Semáforo: no se pudo leer la vinculación semanal de códigos: ' . $e->getMessage());
            $errorLocal = 'No se pudo consultar la vinculación semanal de códigos en MySQL. Instale primero el SQL incluido en el ZIP.';
        }
    }

    /* CATALOGO DE VENDEDORES */

    $catalogo = [];

    if ($errorLocal === '') {

        $q = sqlsrv_query($db, <<<'SQL'

SELECT

    CODVENDEDOR,

    NOMVENDEDOR,

    DNI,

    NUMSSOCIAL,

    TIPOUSUARIO,

    DESCATALOGADO

FROM MENDELS..VENDEDORES

-- La asociación de días se determina por el código guardado en MySQL.
-- El tipo de usuario es informativo: no excluir temporales (ej. 479).

SQL);

        if ($q === false) {

            $errorLocal =

                'No se pudo consultar el catálogo de vendedores.';

        } else {

            while ($f = sqlsrv_fetch_array(

                $q, SQLSRV_FETCH_ASSOC

            )) {

                $cod = trim(

                    (string)($f['CODVENDEDOR'] ?? '')

                );

                if ($cod === '') continue;

                $catalogo[$cod] = [

                    'codigo' => $cod,

                    'nombre' => trim(

                        (string)($f['NOMVENDEDOR'] ?? '')

                    ) ?: 'Vendedor',

                    'dni' => dias_normalizar_dni(

                        (string)($f['DNI'] ?? '')

                    ),

                    'ss' => dias_normalizar_dni(

                        (string)($f['NUMSSOCIAL'] ?? '')

                    ),

                    'tipo' => (int)(

                        $f['TIPOUSUARIO'] ?? 0

                    ),

                    'activo' => strtoupper(

                        trim(

                            (string)($f['DESCATALOGADO'] ?? '')

                        )

                    ) === 'F'

                ];

            }



            sqlsrv_free_stmt($q);

        }

    }

    /* IDENTIFICAR COLUMNAS DE IVA */

    $factorSQL = 'NULL';

    if ($errorLocal === '') {

        $q = sqlsrv_query($db, <<<'SQL'

SELECT

    COL_LENGTH(

        'MENDELS.dbo.ALBVENTALIN','PRECIO'

    ) AS P,

    COL_LENGTH(

        'MENDELS.dbo.ALBVENTALIN','PRECIOIVA'

    ) AS PI,

    COL_LENGTH(

        'MENDELS.dbo.ALBVENTALIN','IVA'

    ) AS I

SQL);

        $cols = $q === false

            ? []

            : (

                sqlsrv_fetch_array(

                    $q, SQLSRV_FETCH_ASSOC

                ) ?: []

            );

        if ($q !== false) {

            sqlsrv_free_stmt($q);

        }

        if (isset($cols['P'], $cols['PI'])) {

            $ratio = '(

                TRY_CONVERT(DECIMAL(18,6),L.PRECIOIVA)

                /NULLIF(

                    TRY_CONVERT(DECIMAL(18,6),L.PRECIO),0

                )

            )';



            $factorSQL =

                "CASE

                    WHEN $ratio BETWEEN 0.995 AND 1.005

                        THEN 1.00

                    WHEN $ratio BETWEEN 1.145 AND 1.155

                        THEN 1.15

                    WHEN $ratio BETWEEN 1.175 AND 1.185

                        THEN 1.18

                    ELSE NULL

                END";

        }

        if (isset($cols['I'])) {



            $iva = 'TRY_CONVERT(

                DECIMAL(18,4),L.IVA

            )';
            $factorPct =

                "CASE

                    WHEN $iva IN (0,15,18)

                        THEN 1.0+$iva/100.0

                    ELSE NULL

                END";



            $factorSQL = "COALESCE(

                $factorSQL,$factorPct

            )";

        }

    }
    /* VENTAS POR CODIGO Y TIENDA */

    $ventasPorCodigo = [];



    if ($errorLocal === '') {



       $sqlVentas = <<<'SQL'

SELECT

    L.CODVENDEDOR,

    CAST(ROUND(SUM(

        TRY_CONVERT(DECIMAL(18,4), L.TOTAL)

        * (1.0 - ISNULL(TRY_CONVERT(DECIMAL(18,4), C.DTOCOMERCIAL), 0.0) / 100.0)

    ), 2) AS DECIMAL(18,2)) AS BASE,

    CAST(SUM(

        (CASE 

            WHEN TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) IS NOT NULL 

                 AND TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) <> 0

            THEN TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) 

                 * TRY_CONVERT(DECIMAL(18,4), L.UNIDADESTOTAL)

                 * (1.0 - ISNULL(TRY_CONVERT(DECIMAL(18,4), L.DTO), 0.0) / 100.0)

            ELSE TRY_CONVERT(DECIMAL(18,4), L.TOTAL) 

                 * COALESCE(T.FACTOR_IVA, CAST(1.15 AS DECIMAL(18,6)))

        END)

        * (1.0 - ISNULL(TRY_CONVERT(DECIMAL(18,4), C.DTOCOMERCIAL), 0.0) / 100.0)

    ) AS DECIMAL(18,6)) AS CON_IVA,

    CAST(ROUND(

        SUM(

            (

                (CASE 

                    WHEN TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) IS NOT NULL 

                         AND TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) <> 0

                    THEN TRY_CONVERT(DECIMAL(18,4), L.PRECIOIVA) 

                         * TRY_CONVERT(DECIMAL(18,4), L.UNIDADESTOTAL)

                         * (1.0 - ISNULL(TRY_CONVERT(DECIMAL(18,4), L.DTO), 0.0) / 100.0)

                    ELSE TRY_CONVERT(DECIMAL(18,4), L.TOTAL) 

                         * COALESCE(T.FACTOR_IVA, CAST(1.00 AS DECIMAL(18,6)))

                END)

                * (1.0 - ISNULL(TRY_CONVERT(DECIMAL(18,4), C.DTOCOMERCIAL), 0.0) / 100.0)

            ) / COALESCE(T.FACTOR_IVA, CAST(1.15 AS DECIMAL(18,6)))

        )

        - SUM(

            TRY_CONVERT(DECIMAL(18,4), L.COSTE)

            * TRY_CONVERT(DECIMAL(18,4), L.UNIDADESTOTAL)

        ),

        2

    ) AS DECIMAL(18,2)) AS MB,

    SUM(CASE WHEN T.FACTOR_IVA IS NULL THEN 1 ELSE 0 END) AS SIN_TASA

FROM MENDELS..ALBVENTACAB C

INNER JOIN MENDELS..ALBVENTALIN L

    ON C.NUMSERIE = L.NUMSERIE

   AND C.NUMALBARAN = L.NUMALBARAN

CROSS APPLY (SELECT TRY_CONVERT(date, C.FECHA, 105) AS FECHA_DATE) F

CROSS APPLY (SELECT __FACTOR__ AS FACTOR_IVA) T

WHERE (C.NUMSERIE LIKE '%T' OR C.NUMSERIE LIKE '%N'
       OR C.NUMSERIE LIKE '%U' OR C.NUMSERIE LIKE '%W'
       OR C.NUMSERIE LIKE '%X' OR C.NUMSERIE LIKE '%F%')
  AND F.FECHA_DATE BETWEEN ? AND ?
  AND L.CODALMACEN = ?
  AND L.CODALMACEN NOT LIKE 'CD%'
  AND L.CODVENDEDOR NOT IN ('238')
GROUP BY L.CODVENDEDOR
SQL;




        $sqlVentas = str_replace(

            '__FACTOR__',

            $factorSQL,

            $sqlVentas

        );



        $q = sqlsrv_query(

            $db,

            $sqlVentas,

            [

                $fechaDesde,

                $fechaHasta,

                $codigoSeleccionado

            ]

        );



        if ($q === false) {



            $errorLocal = 'No se pudieron consultar las ventas.';

            error_log('Semáforo: error en consulta de ventas.');



        } else {



            $sinTasa = 0;



            while ($f = sqlsrv_fetch_array($q, SQLSRV_FETCH_ASSOC)) {



                $cod = trim((string)($f['CODVENDEDOR'] ?? ''));



                if ($cod === '') continue;



                $ventasPorCodigo[$cod] = [

                    'base' => (float)($f['BASE'] ?? 0),

                    'con_iva' => (float)($f['CON_IVA'] ?? 0),

                    'mb' => (float)($f['MB'] ?? 0)

                ];



                $sinTasa += (int)($f['SIN_TASA'] ?? 0);

            }



            sqlsrv_free_stmt($q);



            if ($sinTasa > 0) {

                $aviso = 'Hay ' . $sinTasa . ' líneas cuyo IVA no se pudo verificar.';

            }

        }

    }

    /* VINCULAR DNI GUARDADO CON CODIGO */

    if ($errorLocal === '') {

        $codigosDeTienda = [];
        $actuales = dias_obtener_vendedores_tienda(

            $db,

            $nombreTienda

        );

        foreach (array_keys($actuales) as $c) {

            $codigosDeTienda[(string)$c] = true;

        }

        $candidatos = [];

        foreach ($catalogo as $cod => $v) {

            $d = $dniManualPorCodigo[$cod] ?? '';

            $identidades = $d !== ''

                ? [$d]

                : array_unique(

                    array_filter([

                        $v['dni'],

                        $v['ss']

                    ])

                );



            foreach ($identidades as $id) {

                if (

                    $id !== '' &&

                    array_key_exists($id, $diasPorDni)

                ) {

                    $candidatos[$id][$cod] = $v;

                }

            }

        }

    /*

     * VINCULACIÓN CONSERVADORA DE CÓDIGOS DE VENTA A DNI.

     * Solo se asigna una venta si el código corresponde a una única identidad

     * que tiene días guardados. Nunca se envían ventas ajenas a Autoservicio.

     * Un DNI puede disponer de distintos códigos, pero aparece en una sola fila.

     */

    $propietariosPorCodigo = [];

    foreach ($catalogo as $codAlias => $vAlias) {

        if ((string)$codAlias === '3146') continue; // Autoservicio tiene su propio código.

        $manualAlias = $dniManualPorCodigo[$codAlias] ?? '';

        $idsAlias = $manualAlias !== '' ? [$manualAlias] : array_unique(array_filter([

            $vAlias['dni'], $vAlias['ss']

        ]));

        $idsConDias = [];

        foreach ($idsAlias as $idAlias) {

            if ($idAlias !== '' && preg_match('/[1-9]/', (string)$idAlias)

                && array_key_exists($idAlias, $diasPorDni)) {

                $idsConDias[$idAlias] = true;

            }

        }

        if (count($idsConDias) === 1) {

            $propietariosPorCodigo[(string)$codAlias] = (string)array_key_first($idsConDias);

        }

    }

    /* El código elegido en Días trabajados tiene prioridad sobre el catálogo.
     * Así un temporal puede ser el código visible sin perder sus ventas.
     */
    foreach ($codigoSemanalPorDni as $dniPrincipal => $codPrincipal) {
        $dniPrincipal = (string)$dniPrincipal;
        $codPrincipal = (string)$codPrincipal;
        if ($dniPrincipal !== '' && isset($diasPorDni[$dniPrincipal])
            && $codPrincipal !== '' && $codPrincipal !== '3146') {
            $propietariosPorCodigo[$codPrincipal] = $dniPrincipal;
        }
    }

    $metasPorDni = smf_repartir_meta_dias($diasPorDni, $metaVendedoresGrupo);

    /* PROCESAMIENTO DE REGISTROS Y DIAS */

    $usados = [];
    $codigosVentaVinculados = [];

    // Evitar que otro DNI tome primero un código reservado para el DNI que se guardó.
    $codigosReservadosSemana = array_fill_keys(array_values($codigoSemanalPorDni), true);

    $diasSinVincular = 0.0;

    foreach ($diasPorDni as $dni => $dias) {

        $opciones = array_values($candidatos[$dni] ?? []);

        usort($opciones, static function ($a, $b) use ($codigosDeTienda, $ventasPorCodigo) {

            $prioridad = static function ($x) use ($codigosDeTienda, $ventasPorCodigo) {

                $cod = (string)($x['codigo'] ?? '');

                $montoVenta = isset($ventasPorCodigo[$cod])

                    ? abs((float)$ventasPorCodigo[$cod]['con_iva'])

                    : 0.0;

                // Solo se utiliza este desempate para semanas antiguas sin
                // código principal guardado. Ningún tipo (111, 479, etc.)
                // recibe preferencia por su clasificación.
                return [

                    $montoVenta > 0 ? 0 : 1,

                    -$montoVenta,

                    isset($codigosDeTienda[$cod]) ? 0 : 1,

                    !empty($x['activo']) ? 0 : 1

                ];

            };



            return ($prioridad($a) <=> $prioridad($b)) ?: strnatcmp((string)$a['codigo'], (string)$b['codigo']);

        });

        // Siempre respetar el código que se guardó al registrar los días
        // de este DNI, tienda y semana, incluso si es un código temporal.
        $codigoGuardadoSemana = (string)($codigoSemanalPorDni[(string)$dni] ?? '');
        $v = null;
        if ($codigoGuardadoSemana !== '') {
            if (isset($candidatos[$dni][$codigoGuardadoSemana])) {
                $v = $candidatos[$dni][$codigoGuardadoSemana];
            } elseif (isset($catalogo[$codigoGuardadoSemana])) {
                // El código puede haber cambiado de tienda o tipo después del guardado.
                $v = $catalogo[$codigoGuardadoSemana];
            } else {
                // Conservar el código guardado aun si ya no aparece en el catálogo actual.
                $nombreAnterior = trim((string)($actuales[$codigoGuardadoSemana]['nombre'] ?? ''));
                $v = [
                    'codigo' => $codigoGuardadoSemana,
                    'nombre' => $nombreAnterior !== '' ? $nombreAnterior : 'Vendedor código ' . $codigoGuardadoSemana
                ];
            }
            if (isset($usados[$codigoGuardadoSemana])) {
                $v = null;
                $aviso .= ($aviso !== '' ? ' ' : '')
                    . 'Hay códigos semanales repetidos; revise la vinculación en MySQL.';
            }
        } else {
            // Registros antiguos sin vínculo semanal: comportamiento original.
            foreach ($opciones as $candidato) {
                $codCandidato = (string)$candidato['codigo'];
                if (!isset($usados[$codCandidato])
                    && !isset($codigosReservadosSemana[$codCandidato])) {
                    $v = $candidato;
                    break;
                }
            }
        }

        $codigo = $v['codigo'] ?? '';
        if ($codigo !== '') {

            $usados[$codigo] = true;

        } else {

            $diasSinVincular += (float)$dias;

        }
               // Agrupar una sola vez las ventas de los códigos que correspondan
        // inequívocamente a este DNI, bajo el código principal seleccionado.
        // Las ventas se consultaron ya para la tienda y semana seleccionadas.
             $venta = ['base' => 0.0, 'con_iva' => 0.0, 'mb' => 0.0];
        if ($codigo !== '' && $codigo !== '3146') {
            foreach ($ventasPorCodigo as $codigoFactura => $datosFactura) {
                $codigoFactura = (string)$codigoFactura;
                if ($codigoFactura === '3146' || isset($codigosVentaVinculados[$codigoFactura])) {
                    continue;
                }

                // Protección: los códigos _CTN van a Autoservicio, salvo que estén asignados en Días Trabajados.
                $nombreFact = strtoupper((string)($catalogo[$codigoFactura]['nombre'] ?? ''));
                if (strpos($nombreFact, '_CTN') !== false && $codigoFactura !== $codigo) {
                    continue;
                }

                // 1. Código principal guardado en Días Trabajados
                $esCodigoPrincipal = ($codigoFactura === $codigo);

                // 2. Código vinculado manualmente en MySQL (solo los que yo autorices)
                $esManual = (($dniManualPorCodigo[$codigoFactura] ?? '') === (string)$dni);

                if ($esCodigoPrincipal || $esManual) {
                    foreach (['base', 'con_iva', 'mb'] as $concepto) {
                        $venta[$concepto] += (float)($datosFactura[$concepto] ?? 0.0);
                    }
                    $codigosVentaVinculados[$codigoFactura] = true;
                }
            }
        }


        $esAuto = $codigo === '3146';

        $cuota = $totalDiasPeriodo > 0 ? (float)$dias / $totalDiasPeriodo : 0.0;



        $meta = $esAuto ? $metaAutoservicio : ($metasPorDni[$dni] ?? 0.0);

        $registros[] = [

            'VENDEDOR' => $v['nombre'] ?? ($dni === '' ? 'Registro sin DNI' : 'DNI sin código vinculado'),

            'CODVENDEDOR' => $codigo,

            'DNI' => $dni,

            'DIAS' => (float)$dias,

            'PORC_DIAS' => round($cuota * 100, 2),

            'META' => round($meta, 2),

            'VENTA_BASE' => round((float)$venta['base'], 2),

            'VENTA_CON_IVA' => (float)$venta['con_iva'],

            'MB' => round((float)$venta['mb'], 2),

            'META_MB' => 0.0,

            'LOGRO' => 0.0,

            'LOGRO_MB' => 0.0

        ];

    }

    // Estos códigos ya se contabilizaron en el vendedor principal.
    // El bloque original de Autoservicio queda sin modificar, pero no
    // volverá a contabilizar esas mismas ventas como no asignadas.
    foreach ($codigosVentaVinculados as $codigoFactura => $_asignado) {
        $usados[(string)$codigoFactura] = true;
    }

    /*
     * META MB INDIVIDUAL: criterio por tienda contrastado con el Excel.

     * El calculo de Logro MB permanece sin cambios.

     */

    foreach ($registros as &$reg) {

        $reg['META_MB'] = $tasaMetaMb === null ? null

            : smf_meta_mb((float)$reg['META'], $tasaMetaMb, $modoMetaMb);



        $reg['LOGRO'] = (float)$reg['META'] > 0

            ? round((float)$reg['VENTA_CON_IVA'] * 100.0 / (float)$reg['META'], 2) : 0.0;

        $reg['LOGRO_MB'] = $reg['META_MB'] !== null && $reg['META_MB'] > 0

            ? round((float)$reg['MB'] * 100.0 / $reg['META_MB'], 2) : null;

    }

    unset($reg);

    // Ventas sin DNI único permanecen sin asignar (no son Autoservicio).

    $ventaAutoTotal = ['base' => 0.0, 'con_iva' => 0.0, 'mb' => 0.0];

    foreach ($ventasPorCodigo as $codVenta => $datosVenta) {

        if ((string)$codVenta === '3146' || !isset($usados[(string)$codVenta])) {

            $ventaAutoTotal['base'] += (float)($datosVenta['base'] ?? 0);

            $ventaAutoTotal['con_iva'] += (float)($datosVenta['con_iva'] ?? 0);

            $ventaAutoTotal['mb'] += (float)($datosVenta['mb'] ?? 0);

        }

    }

    $autoPresente = false;



    foreach ($registros as &$f) {

        if ((string)$f['CODVENDEDOR'] === '3146') {

            $autoPresente = true;

            $f['VENTA_BASE'] = round($ventaAutoTotal['base'], 2);

            $f['VENTA_CON_IVA'] = round($ventaAutoTotal['con_iva'], 3);

            $f['MB'] = round($ventaAutoTotal['mb'], 2);

            $f['VENDEDOR'] = 'Autoservicio';

            $f['META'] = $metaAutoservicio;

            // Meta MB de Autoservicio sigue el criterio MB de la tienda.

            $f['META_MB'] = smf_meta_mb($metaAutoservicio, $tasaMetaMb, $modoMetaMb);

            $f['LOGRO'] = $metaAutoservicio > 0 ? round($f['VENTA_CON_IVA'] * 100 / $metaAutoservicio, 2) : 0;

            $f['LOGRO_MB'] = $f['META_MB'] > 0 ? round($f['MB'] * 100 / $f['META_MB'], 2) : null;

            break;

        }

    }

    unset($f);

    if (!$autoPresente && ($metaTotalTienda > 0 || $ventaAutoTotal['con_iva'] > 0)) {

        // Meta MB de Autoservicio sigue el criterio MB de la tienda.

        $mbMeta = smf_meta_mb($metaAutoservicio, $tasaMetaMb, $modoMetaMb);

        $autoConIvaFinal = round($ventaAutoTotal['con_iva'], 3);

        $registros[] = [

            'VENDEDOR' => 'Autoservicio',

            'CODVENDEDOR' => '3146',

            'DNI' => '',

            'DIAS' => 0,

            'PORC_DIAS' => 0,

            'META' => $metaAutoservicio,

            'VENTA_BASE' => round($ventaAutoTotal['base'], 2),

            'VENTA_CON_IVA' => $autoConIvaFinal,

            'MB' => round($ventaAutoTotal['mb'], 2),

            'META_MB' => $mbMeta,

            'LOGRO' => $metaAutoservicio > 0 ? round($autoConIvaFinal * 100 / $metaAutoservicio, 2) : 0,

            'LOGRO_MB' => ($mbMeta !== null && $mbMeta > 0) ? round($ventaAutoTotal['mb'] * 100 / $mbMeta, 2) : null

        ];

    }

    usort($registros, static function ($a, $b) {
        $aAuto = (string)($a['CODVENDEDOR'] ?? '') === '3146';
        $bAuto = (string)($b['CODVENDEDOR'] ?? '') === '3146';
        if ($aAuto !== $bAuto) return $aAuto ? 1 : -1;
        return ($b['VENTA_CON_IVA'] <=> $a['VENTA_CON_IVA']) ?: strcmp($a['VENDEDOR'], $b['VENDEDOR']);
    });


} // Cierra la vinculación y procesamiento de vendedores.

} // Cierra el procesamiento cuando no hay errores.



// Todos los renglones numerados, incluida la fila de Autoservicio.
$numeroRegistros = count($registros);

// TOTALES

$totalVentaConIvaVendedores = 0.0;

$totalVentaConIvaAuto = 0.0;

$totalVentaConIvaTienda = 0.0;

$totalMb = 0.0;

$totalMetaMbIndividual = 0.0;


foreach ($ventasPorCodigo as $cod => $ventaCod) {

    $totalVentaConIvaTienda += (float)($ventaCod['con_iva'] ?? 0);

    $totalMb += (float)($ventaCod['mb'] ?? 0);

}

foreach ($registros as $fila) {

    if ((string)($fila['CODVENDEDOR'] ?? '') === '3146') {

        $totalVentaConIvaAuto += (float)($fila['VENTA_CON_IVA'] ?? 0);

    } else {

        $totalVentaConIvaVendedores += (float)($fila['VENTA_CON_IVA'] ?? 0);

    }

    $totalMetaMbIndividual += (float)($fila['META_MB'] ?? 0);

}



$totalVentaConIvaVendedores = round($totalVentaConIvaVendedores, 3);

$totalVentaConIvaAuto = round($totalVentaConIvaAuto, 3);

$totalVentaConIva = round($totalVentaConIvaTienda, 3);

$totalVentaSinAsignar = 0.0;

$totalMb = round($totalMb, 2);

$tasaMbReal = $totalVentaConIva > 0 ? round($totalMb * 100.0 / ($totalVentaConIva / 1.15), 2) : null;

$totalMetaMbIndividual = round($totalMetaMbIndividual, 2);

$ventaVendedoresDividida115 = round($totalVentaConIvaVendedores / 1.15, 3);
$pctVentaVendedores = $totalVentaConIva > 0
    ? ($totalVentaConIvaVendedores / $totalVentaConIva) * 100.0 : 0.0;
$pctVentaAuto = $totalVentaConIva > 0
    ? ($totalVentaConIvaAuto / $totalVentaConIva) * 100.0 : 0.0;

$logroGeneral = $metaTotalTienda > 0

    ? round($totalVentaConIva * 100.0 / $metaTotalTienda, 2) 

    : 0.0;

// Meta MB global con el mismo criterio de la tienda que las metas individuales.

$metaMbGlobal = smf_meta_mb($metaTotalTienda, $tasaMetaMb, $modoMetaMb);

$logroGeneralMb = $metaMbGlobal !== null && $metaMbGlobal > 0

    ? round($totalMb * 100.0 / $metaMbGlobal, 2) 

    : null;

// Totales de las filas mostradas; no alteran los indicadores ni la lógica de ventas.
$svTotalesTabla = [
    'dias' => 0.0,
    'meta' => 0.0,
    'venta' => 0.0,
    'meta_mb' => 0.0,
    'mb' => 0.0,
];
$svMetaMbDisponible = false;
foreach ($registros as $svFila) {
    $svTotalesTabla['dias'] += (float)($svFila['DIAS'] ?? 0);
    $svTotalesTabla['meta'] += (float)($svFila['META'] ?? 0);
    $svTotalesTabla['venta'] += (float)($svFila['VENTA_CON_IVA'] ?? 0);
    $svTotalesTabla['mb'] += (float)($svFila['MB'] ?? 0);
    if (($svFila['META_MB'] ?? null) !== null) {
        $svMetaMbDisponible = true;
        $svTotalesTabla['meta_mb'] += (float)$svFila['META_MB'];
    }
}
// Los cumplimientos generales se calculan sobre los importes totales, no sumando porcentajes.
$svTotalPorcDias = $totalDiasPeriodo > 0
    ? $svTotalesTabla['dias'] * 100.0 / $totalDiasPeriodo
    : 0.0;
$svTotalPorcIva = $svTotalesTabla['meta'] > 0
    ? $svTotalesTabla['venta'] * 100.0 / $svTotalesTabla['meta']
    : null;
$svTotalPorcMb = $svMetaMbDisponible && $svTotalesTabla['meta_mb'] > 0
    ? $svTotalesTabla['mb'] * 100.0 / $svTotalesTabla['meta_mb']
    : null;

require_once dirname(__DIR__) . '/layout_menu.php';

?>

<link
    rel="stylesheet"
    href="<?= smf_h($baseUrl) ?>/Total/css/vendedores.css?v=27"
>

<!-- Panel semanal: presentación actualizada, cálculos preservados -->
<main class="sv-page sv-redesign">
<div class="sv-container">
   
    <?php if ($errorLocal !== ''): ?>
        <div class="sv-alert">
            <?= smf_h($errorLocal) ?>
        </div>
    <?php endif; ?>
    <?php if ($aviso !== ''): ?>
        <div class="sv-alert">
            <?= smf_h($aviso) ?>
        </div>
    <?php endif; ?>
    <?php if (
        !$errorLocal &&
        $diasSinVincular > 0
    ): ?>
        <div class="sv-alert">
            Existen
            <?= smf_num($diasSinVincular, 1) ?>
            días guardados sin código identificado.
            Se conservan en el total de días,
            sin asignar ventas de otra persona.
        </div>
    <?php endif; ?>
    <!-- Configuración de porcentajes: únicamente presentación. -->
    <?php if ($mensajeTasa !== ''): ?>
        <div class="sv-alert sv-alert-success" role="status"><i class="bi bi-check-circle"></i> <?= smf_h($mensajeTasa) ?></div>
    <?php endif; ?>
    <?php if ($errorTasa !== ''): ?>
        <div class="sv-alert" role="alert"><i class="bi bi-exclamation-circle"></i> <?= smf_h($errorTasa) ?></div>
    <?php endif; ?>

    <section class="sv-settings" aria-label="Configuración de porcentajes">
        <div class="sv-settings-head">
            <div>
                <span class="sv-section-kicker">CONFIGURACIÓN DE OBJETIVOS</span>
                <h2>Porcentajes de la semana</h2>
                <p>Se aplican a la tienda y semana seleccionadas.</p>
            </div>
            <span class="sv-settings-period"><i class="bi bi-calendar3"></i> Semana <?= (int)$numeroSemanaRetail ?></span>
        </div>
        <div class="sv-settings-grid">
            <div class="sv-setting sv-auto-setting">
                <div class="sv-setting-label">
                    <span class="sv-setting-icon"><i class="bi bi-pie-chart"></i></span>
                    <div><strong>Autoservicio</strong><small>Porcentaje semanal, con hasta 10 decimales.</small></div>
                </div>
                <?php if ($puedeEditarTasa && $tiendaSeleccionada && $semanaSeleccionada): ?>
                    <form id="sv-auto-form" class="sv-setting-form" method="post"
                          action="<?= smf_h(smf_url($semanaSeleccionada, $codigoSeleccionado)) ?>">
                        <input type="hidden" name="csrf_token" value="<?= smf_h(smf_csrf_token()) ?>">
                        <input type="hidden" name="csrf_meta_mb" value="<?= smf_h($_SESSION['csrf_meta_mb']) ?>">
                        <input type="hidden" name="tienda" value="<?= smf_h($codigoSeleccionado) ?>">
                        <input type="hidden" name="semana" value="<?= (int)$numeroSemanaRetail ?>">
                        <input type="hidden" name="modo_auto" value="porcentaje">
                        <div class="sv-number-wrap sv-number-long">
                            <input aria-label="Porcentaje de Autoservicio" id="porcentaje_auto" class="sv-control"
                                   type="text" inputmode="decimal" autocomplete="off" name="porcentaje_auto"
                                   placeholder="Ej. 20.573770" maxlength="14" required
                                   value="<?= $porcentajeAuto === null ? '' : smf_h(rtrim(rtrim(number_format((float)$porcentajeAuto, 10, '.', ''), '0'), '.')) ?>">
                            <span>%</span>
                        </div>
                        <button class="sv-btn sv-save-btn" type="submit" name="guardar_porc_auto" value="1">
                            <i class="bi bi-check2"></i> Guardar
                        </button>
                    </form>
                <?php else: ?>
                    <div class="sv-setting-value"><?= $porcentajeAuto === null ? 'Sin configurar' : smf_num($porcentajeAuto, 2) . '%' ?></div>
                <?php endif; ?>
                <p class="sv-setting-help">
                    <?= smf_h($origenPorcentajeAuto) ?>.
                    <?= $modoConfiguracionAuto === 'meta_vendedores'
                        ? 'El porcentaje se muestra redondeado como en Excel; se calcula con la meta exacta.'
                        : 'Se utiliza exactamente el porcentaje guardado, incluso con decimales largos.' ?>
                </p>
            </div>
            <div class="sv-setting">
                <div class="sv-setting-label"><span class="sv-setting-icon"><i class="bi bi-graph-up-arrow"></i></span><div><strong>Meta MB</strong><small>Objetivo de margen bruto</small></div></div>
                <?php if ($puedeEditarTasa && $tiendaSeleccionada && $semanaSeleccionada): ?>
                    <form class="sv-setting-form" method="post" action="<?= smf_h(smf_url($semanaSeleccionada, $codigoSeleccionado)) ?>">
                        <input type="hidden" name="guardar_meta_mb" value="1">
                        <input type="hidden" name="csrf_token" value="<?= smf_h(smf_csrf_token()) ?>">
                        <input type="hidden" name="csrf_meta_mb" value="<?= smf_h($_SESSION['csrf_meta_mb']) ?>">
                        <input type="hidden" name="tienda" value="<?= smf_h($codigoSeleccionado) ?>">
                        <input type="hidden" name="semana" value="<?= (int)$numeroSemanaRetail ?>">
                        <div class="sv-number-wrap">
                            <input aria-label="Porcentaje Meta MB" id="tasa-mb" class="sv-control" type="text" name="porcentaje_mb" min="0.01" max="99.99" step="0.0000001" placeholder="Ej. 51.50" value="<?= $tasaPorcentaje === null ? '' : smf_h((string)(float)$tasaPorcentaje) ?>" required>
                            <span>%</span>
                        </div>
                        <button class="sv-btn sv-save-btn" type="submit"><i class="bi bi-check2"></i> Guardar</button>
                    </form>
                <?php else: ?>
                    <div class="sv-setting-value"><?= $tasaMetaMb === null ? 'Sin configurar' : smf_num($tasaMetaMb * 100) . '%' ?></div>
                <?php endif; ?>
                <p class="sv-setting-help"><?= smf_h($tasaOrigen) ?>. El MB real proviene de ventas y costos.</p>
            </div>
        </div>
        <!-- Resumen según Excel; se alimenta de la tienda y la semana consultadas. -->
        <div class="sv-excel-summary" aria-label="Resumen semanal según Excel">
            <div class="sv-excel-item">
                <span class="sv-excel-label">Meta global</span>
                <strong>L <?= smf_num($metaTotalTienda, 3) ?></strong>
                <small>Meta semanal de tienda</small>
            </div>
            <div class="sv-excel-item">
                <span class="sv-excel-label">Meta vendedores</span>
                <strong>L <?= smf_num($metaVendedoresGrupo, 3) ?></strong>
                <small>Autoservicio: <?= $porcentajeAuto === null ? '—' : smf_num($porcentajeAuto, 2) . '%' ?> de la meta</small>
            </div>
            <div class="sv-excel-item sv-excel-item-venta">
                <span class="sv-excel-label">Venta global</span>
                <strong>L <?= smf_num($totalVentaConIva, 3) ?></strong>
                <small>Logro con IVA · Tienda</small>
            </div>
            <div class="sv-excel-item">
                <span class="sv-excel-label">Venta vendedores</span>
                <strong>L <?= smf_num($totalVentaConIvaVendedores, 3) ?></strong>
                <small><?= smf_num($pctVentaVendedores, 0) ?>% de venta global</small>
                <small>Sin IVA (/1.15): L <?= smf_num($ventaVendedoresDividida115, 3) ?></small>
            </div>
            <div class="sv-excel-item">
                <span class="sv-excel-label">Venta autoservicio</span>
                <strong>L <?= smf_num($totalVentaConIvaAuto, 3) ?></strong>
                <small><?= smf_num($pctVentaAuto, 0) ?>% de venta global</small>
            </div>
        </div>
    </section>

    <!-- FILTROS -->
    <section class="sv-toolbar">
        <form
            method="get"
            class="sv-store-form"
        >
            <input
                type="hidden"
                name="semana"
                value="<?= $numeroSemanaRetail ?>"
            >
            <div class="sv-field">
                <?php if (
                    $rol === 'gerente_tienda'
                ): ?>
                <div class="sv-field-label">
                    Tienda
                </div>
                    <input
                        type="hidden"
                        name="tienda"
                        value="<?= smf_h(
                            $codigoSeleccionado
                        ) ?>"
                    >
                    <div class="sv-control sv-static">
                        <i class="bi bi-shop"></i>
                        <?= smf_h($nombreTienda) ?>
                    </div>
                <?php else: ?>
                    <label for="sv-tienda">
                        Tienda
                    </label>
                    <div class="sv-select-wrap">
                        <i class="bi bi-shop"></i>
                        <select
                            id="sv-tienda"
                            name="tienda"
                            class="sv-control"
                        >
                            <?php foreach (
                                $tiendas as $codigo => $t
                            ): ?>
                                <option
                                    value="<?= smf_h($codigo) ?>"
                                    <?= (string)$codigo ===
                                        $codigoSeleccionado
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= smf_h(
                                        $codigo . ' - ' .
                                        ($t['nombre'] ?? '')
                                    ) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            <button
                class="sv-btn"
                type="submit"
            >
                <i class="bi bi-search"></i>
                Consultar
            </button>
        </form>
        <!-- NAVEGACION DE SEMANAS -->
        <div class="sv-field sv-week-field">
            <div class="sv-field-label">Semana Retail</div>
            <div class="sv-week-selector">
                <?php if ($semanaAnterior): ?>
                    <a
                        class="sv-week-arrow"
                        href="<?= smf_h(
                            smf_url(
                                $semanaAnterior,
                                $codigoSeleccionado
                            )
                        ) ?>"
                        aria-label="Semana anterior"
                    >
                        <i class="bi bi-chevron-left"></i>
                    </a>
                <?php else: ?>
                    <span class="sv-week-arrow is-disabled">
                        <i class="bi bi-chevron-left"></i>
                    </span>
                <?php endif; ?>
                <div class="sv-week-current">
                    <strong>
                        Semana <?= $numeroSemanaRetail ?>
                    </strong>
                    <span>
                        <?= smf_fecha($fechaDesde) ?>
                        –
                        <?= smf_fecha($fechaHasta) ?>
                    </span>
                </div>
                <?php if ($semanaSiguiente): ?>
                    <a
                        class="sv-week-arrow"
                        href="<?= smf_h(
                            smf_url(
                                $semanaSiguiente,
                                $codigoSeleccionado
                            )
                        ) ?>"
                        aria-label="Semana siguiente"
                    >
                        <i class="bi bi-chevron-right"></i>
                    </a>
                <?php else: ?>
                    <span class="sv-week-arrow is-disabled">
                        <i class="bi bi-chevron-right"></i>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Indicadores de cumplimiento: no duplican las cinco cifras del Excel. -->
    <section class="sv-summary" aria-label="Cumplimiento y registros de la semana">
        <div class="sv-stat">
            <div class="sv-stat-icon"><i class="bi bi-bar-chart"></i></div>
            <div class="sv-stat-info">
                <span>Cumplimiento con IVA</span>
                <strong><?= smf_num($logroGeneral, 0) ?>%</strong>
            </div>
        </div>
        <div class="sv-stat">
            <div class="sv-stat-icon"><i class="bi bi-graph-up-arrow"></i></div>
            <div class="sv-stat-info">
                <span>Cumplimiento MB</span>
                <strong><?= $logroGeneralMb === null ? '—' : smf_num($logroGeneralMb, 0) . '%' ?></strong>
            </div>
        </div>
        <div class="sv-stat">
            <div class="sv-stat-icon"><i class="bi bi-people"></i></div>
            <div class="sv-stat-info">
                <span>Registros del reporte</span>
                <strong><?= $numeroRegistros ?></strong>
                <small>Incluye Autoservicio</small>
            </div>
        </div>
    </section>
    <!-- TABLA DE VENDEDORES -->
    <section class="sv-panel" aria-label="Rendimiento por vendedor">
        <div class="sv-panel-head">
            <div class="sv-panel-title">
                <span class="sv-panel-icon">
                    <i class="bi bi-people"></i>
                </span>
                <div>
                    <h2>
                        Rendimiento por vendedor
                    </h2>
                    <p>
                        <?= smf_h($nombreTienda) ?>
                        · Semana
                        <?= $numeroSemanaRetail ?>
                        ·
                        <?= smf_fecha(
                            $fechaDesde,
                            'd/m/Y'
                        ) ?>
                        –
                        <?= smf_fecha(
                            $fechaHasta,
                            'd/m/Y'
                        ) ?>
                    </p>
                </div>
            </div>
            <div class="sv-panel-actions">
                <span class="sv-count">
                    <?= $numeroRegistros ?> registros · incluye Autoservicio
                </span>
                <button
                    type="button"
                    class="sv-icon-btn"
                    onclick="window.print()"
                    title="Imprimir reporte" aria-label="Imprimir reporte"
                >
                    <i class="bi bi-printer"></i>
                </button>
            </div>
        </div>
        <div class="sv-table-wrap">
            <table class="sv-table">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Vendedor</th>
                        <th>Código</th>
                        <th class="sv-right">
                            Días
                        </th>
                        <th class="sv-right">
                            % días
                        </th>
                        <th class="sv-right">
                            Meta con IVA
                        </th>
                        <th class="sv-right">
                            Logro con IVA
                        </th>
                        <th class="sv-right">
                            % con IVA
                        </th>
                        <th class="sv-right">
                            Meta MB
                        </th>
                        <th class="sv-right">
                            Logro MB
                        </th>
                        <th class="sv-right">
                            % MB
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$registros): ?>
                        <tr>
                            <td
                                colspan="11"
                                class="sv-empty"
                            >
                                No hay resultados para
                                esta tienda y semana.
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach (
                        $registros as $i => $f
                    ):
                        $logro = (float)$f['LOGRO'];
                        $estado = $logro >= 100
                            ? 'verde'
                            : (
                                $logro >= 80
                                ? 'amarillo'
                                : 'rojo'
                            );
                    ?>
                        <tr>
                            <td class="sv-muted">
                                <?= $i + 1 ?>
                            </td>
                            <td>
                                <div class="sv-person">
                                    <span class="sv-avatar">
                                        <?= smf_h(
                                            smf_iniciales(
                                                $f['VENDEDOR']
                                            )
                                        ) ?>
                                    </span>
                                    <span class="sv-person-info">
                                        <strong class="sv-person-name">
                                            <?= smf_h(
                                                $f['VENDEDOR']
                                            ) ?>
                                        </strong>
                                        <small>
                                            <?= (string)$f['CODVENDEDOR'] === '3146' ? 'Autoservicio' : 'Vendedor de tienda' ?>
                                        </small>
                                        <?php if (
                                            $f['DNI'] !== ''
                                        ): ?>
                                            <small>
                                                Identidad:
                                                <?= smf_h(
                                                    $f['DNI']
                                                ) ?>
                                            </small>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </td>
                            <td class="sv-muted"> <?= smf_h( $f['CODVENDEDOR'] ) ?>  </td>
                            <td class="sv-right"> <?= smf_num( $f['DIAS'],1 ) ?></td>
                            <td class="sv-right"> <?= smf_num( $f['PORC_DIAS'], 2 ) ?>% </td>
                            <td class="sv-right"> L <?= smf_num(  $f['META'], 3) ?> </td>
                            <td class="sv-right sv-emphasis"> L <?= smf_num(  $f['VENTA_CON_IVA'], 3) ?> </td>
                            <td class="sv-right">
                                <span class="sv-logro sv-<?= $estado ?>" ><span class="sv-dot"></span>
                                <?= smf_num($logro, 0) ?>%
                                </span>
                            </td>
                            <td class="sv-right">  <?= $f['META_MB'] === null  ? '—'  : 'L ' . smf_num(  $f['META_MB'], 3 ) ?> </td>
                            <td class="sv-right"> L <?= smf_num(    $f['MB'], 3  ) ?></td>
                            <td class="sv-right"> <?php if ($f['LOGRO_MB'] === null): ?>   —
                                <?php else: $estadoMb = (float)$f['LOGRO_MB'] >= 100 ? 'verde' : ((float)$f['LOGRO_MB'] >= 80 ? 'amarillo' : 'rojo');
                                ?>
                                    <span class="sv-mb-pill sv-<?= $estadoMb ?>"><?= smf_num($f['LOGRO_MB'], 0) ?>%</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <?php if ($registros): ?>
                <tfoot>
                    <tr class="sv-total-row">
                        <td colspan="3" class="sv-total-title">TOTALES</td>
                        <td class="sv-right"><?= smf_num($svTotalesTabla['dias'], 1) ?></td>
                        <td class="sv-right sv-total-pct"><?= smf_num($svTotalPorcDias, 2) ?>%</td>
                        <td class="sv-right">L <?= smf_num($svTotalesTabla['meta'], 3) ?></td>
                        <td class="sv-right">L <?= smf_num($svTotalesTabla['venta'], 3) ?></td>
                        <td class="sv-right sv-total-pct"><?= $svTotalPorcIva === null ? '—' : smf_num($svTotalPorcIva, 0) . '%' ?></td>
                        <td class="sv-right"><?= $svMetaMbDisponible ? 'L ' . smf_num($svTotalesTabla['meta_mb'], 3) : '—' ?></td>
                        <td class="sv-right">L <?= smf_num($svTotalesTabla['mb'], 3) ?></td>
                        <td class="sv-right sv-total-pct"><?= $svTotalPorcMb === null ? '—' : smf_num($svTotalPorcMb, 0) . '%' ?></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
        <div class="sv-panel-foot">
            <span><i class="bi bi-calendar3"></i>
            Semana Retail
            <?= $numeroSemanaRetail ?>
            ·
            <?= smf_fecha(
                $fechaDesde,
                'd/m/Y'
            ) ?>
            al
            <?= smf_fecha(
                $fechaHasta,
                'd/m/Y'
            ) ?></span>
            <span class="sv-total-note">La fila TOTALES suma los registros mostrados.</span>
        </div>
    </section>
</div>
</main>


