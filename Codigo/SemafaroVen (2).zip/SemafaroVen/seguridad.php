<?php
/* Acceso a las credenciales privadas del sistema. */

function smf_error_servicio(string $motivo): void
{
    error_log('Semaforo: ' . $motivo);
    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/plain; charset=UTF-8');
    }
    exit('Servicio temporalmente no disponible.');
}

function smf_credenciales(): array
{
    static $config = null;
    if (is_array($config)) {
        return $config;
    }

    // Desde C:/xampp2/htdocs/SemafaroVen, dos niveles arriba: C:/xampp2.
    $ruta = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR
          . 'privado_semaforo' . DIRECTORY_SEPARATOR . 'credenciales.php';

    if (!is_file($ruta) || !is_readable($ruta)) {
        smf_error_servicio('Falta el archivo privado de configuracion.');
    }

    try {
        $datos = require $ruta;
    } catch (Throwable $e) {
        smf_error_servicio('No se pudo leer la configuracion privada.');
    }

    if (!is_array($datos) || !isset($datos['mysql'], $datos['sqlserver'])
        || !is_array($datos['mysql']) || !is_array($datos['sqlserver'])) {
        smf_error_servicio('Formato de configuracion privada invalido.');
    }

    $config = $datos;
    return $config;
}

/**
 * Extrae texto simple de GET/POST sin aceptar arreglos ni objetos.
 * El valor se usa unicamente con consultas parametrizadas (no se inserta en SQL).
 */
function smf_entrada_texto($valor, int $longitudMaxima = 120): string
{
    if (!is_string($valor) && !is_int($valor)) {
        return '';
    }

    $texto = trim((string)$valor);
    if (strlen($texto) > $longitudMaxima) {
        return '';
    }

    return $texto;
}
