<?php
date_default_timezone_set('America/Tegucigalpa');

session_name('APP_INVENTARIO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


require_once __DIR__ . '/../usuarios/auth.php';
require_login();

/*
|--------------------------------------------------------------------------
| 2. CONFIGURACIÓN
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');


require_once __DIR__. '/../plan_inventario/conexion_sqlsrv.php';


$sqlsrvConn = null;

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion) {
    $sqlsrvConn = $sqlsrv_conn_exhibicion;
} elseif (isset($sqlsrv_conn) && $sqlsrv_conn) {
    $sqlsrvConn = $sqlsrv_conn;
} elseif (isset($conn_sqlsrv) && $conn_sqlsrv) {
    $sqlsrvConn = $conn_sqlsrv;
} elseif (isset($conn) && $conn) {
    $sqlsrvConn = $conn;
} elseif (isset($conexion) && $conexion) {
    $sqlsrvConn = $conexion;
}

if (!$sqlsrvConn) {
    die('No se encontró una conexión válida a SQL Server.');
}

/*
|--------------------------------------------------------------------------
| 4.1 CONEXIÓN MYSQL PARA META MÍNIMA
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../usuarios/db.php';

if (
    !isset($conn) ||
    $conn === null ||
    !($conn instanceof mysqli)
) {
    die('No se encontró una conexión válida a MySQL para consultar la Meta mínima.');
}

$mysqlConn = $conn;

/*
|--------------------------------------------------------------------------
| 5. FUNCIONES
|--------------------------------------------------------------------------
*/
function h($valor)
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function obtenerErroresSqlsrv()
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);

    if (!$errores) {
        return 'Ocurrió un error desconocido en SQL Server.';
    }

    $mensajes = array();

    foreach ($errores as $error) {
        $codigo  = isset($error['code']) ? $error['code'] : 'SIN CÓDIGO';
        $mensaje = isset($error['message']) ? $error['message'] : 'Error desconocido';
        $mensajes[] = '[' . $codigo . '] ' . $mensaje;
    }

    return implode(' | ', $mensajes);
}

function obtenerArchivoCache()
{
    $carpeta = __DIR__ . DIRECTORY_SEPARATOR . 'cache';

    if (!is_dir($carpeta)) {
        @mkdir($carpeta, 0777, true);
    }

    if (is_dir($carpeta) && is_writable($carpeta)) {
        return $carpeta . DIRECTORY_SEPARATOR . 'inventario_meta_mendels.cache';
    }

    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR
        . 'inventario_meta_mendels.cache';
}

/*
|--------------------------------------------------------------------------
| 5.1 CARGAR REGLAS ACTIVAS DE META POR TIENDA
|--------------------------------------------------------------------------
| Prioridad:
| 1) Familia
| 2) Sección
| 3) Departamento
|--------------------------------------------------------------------------
*/
function cargarReglasMetaMinima($mysqlConn)
{
    $reglas = array(
        'departamento' => array(),
        'seccion'      => array(),
        'familia'      => array()
    );

    $sqlReglas = "
        SELECT
            nombre_regla,
            numdpto,
            numseccion,
            numfamilia,
            tipo_regla,
            meta_minima
        FROM meta_minima_configuracion
        WHERE activo = 1
    ";

    $resultadoReglas =
        $mysqlConn->query($sqlReglas);

    if (!$resultadoReglas) {
        die(
            'No se pudieron consultar las reglas de meta por tienda: ' .
            h($mysqlConn->error)
        );
    }

    while ($regla = $resultadoReglas->fetch_assoc()) {
        $numDpto = (int)$regla['numdpto'];

        $datosRegla = array(
            'nombre_regla' =>
                trim((string)$regla['nombre_regla']),

            'tipo_regla' =>
                strtoupper((string)($regla['tipo_regla'] ?? 'MINIMO')) === 'MAXIMO'
                    ? 'MAXIMO'
                    : 'MINIMO',

            'valor_regla' =>
                (float)$regla['meta_minima']
        );

        if ($regla['numfamilia'] !== null) {
            $clave =
                $numDpto . '|' .
                (int)$regla['numseccion'] . '|' .
                (int)$regla['numfamilia'];

            $reglas['familia'][$clave] =
                $datosRegla;

            continue;
        }

        if ($regla['numseccion'] !== null) {
            $clave =
                $numDpto . '|' .
                (int)$regla['numseccion'];

            $reglas['seccion'][$clave] =
                $datosRegla;

            continue;
        }

        $reglas['departamento'][(string)$numDpto] =
            $datosRegla;
    }

    $resultadoReglas->free();

    return $reglas;
}

function obtenerReglaMetaMinima(
    $reglas,
    $numDpto,
    $numSeccion,
    $numFamilia
) {
    $claveFamilia =
        $numDpto . '|' .
        $numSeccion . '|' .
        $numFamilia;

    if (isset($reglas['familia'][$claveFamilia])) {
        return $reglas['familia'][$claveFamilia];
    }

    $claveSeccion =
        $numDpto . '|' .
        $numSeccion;

    if (isset($reglas['seccion'][$claveSeccion])) {
        return $reglas['seccion'][$claveSeccion];
    }

    $claveDpto = (string)$numDpto;

    if (isset($reglas['departamento'][$claveDpto])) {
        return $reglas['departamento'][$claveDpto];
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| 6. CONSULTA
|--------------------------------------------------------------------------
*/
$sql = <<<'SQL'
WITH ResumenVentas AS (
 SELECT 
 L.CODALMACEN,
 AA.NOMBREALMACEN,
 D.DESCRIPCION AS DEPARTAMENTOS,
 S.DESCRIPCION AS SECCIONES,
 F.DESCRIPCION AS FAMILIAS,
 A.DPTO,
 A.SECCION,
 A.FAMILIA,
 SUM(L.UNIDADESTOTAL) AS UNIDADES_ALMACEN,
 (SUM(L.UNIDADESTOTAL) * 100.0) / NULLIF(SUM(SUM(L.UNIDADESTOTAL)) OVER(), 0) AS SHARE_UNIDADES_PV
 FROM MENDELS..ALBVENTACAB C 
 INNER JOIN MENDELS..ALBVENTALIN L 
 ON C.NUMSERIE = L.NUMSERIE 
 AND C.NUMALBARAN = L.NUMALBARAN
 INNER JOIN MENDELS..ARTICULOS A 
 ON A.CODARTICULO = L.CODARTICULO
 INNER JOIN MENDELS..DEPARTAMENTO D 
 ON D.NUMDPTO = A.DPTO
 LEFT JOIN MENDELS..SECCIONES S 
 ON S.NUMDPTO = A.DPTO 
 AND S.NUMSECCION = A.SECCION 
 LEFT JOIN MENDELS..FAMILIAS F 
 ON F.NUMDPTO = A.DPTO 
 AND F.NUMSECCION = A.SECCION 
 AND F.NUMFAMILIA = A.FAMILIA
 LEFT JOIN MENDELS..ALMACEN AA
 ON AA.CODALMACEN = L.CODALMACEN
 WHERE
 C.FECHA >= DATEADD(year, DATEDIFF(year, 0, GETDATE()) - 1, 0)
 AND C.FECHA < DATEADD(year, DATEDIFF(year, 0, GETDATE()), 0)
 AND (
 C.NUMSERIE LIKE '%[TNU]%' 
 OR C.NUMSERIE LIKE '%W' 
 OR C.NUMSERIE LIKE '%F'
 )
 AND L.CODALMACEN IN ('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18')
 AND C.TIPODOC IN (13, 23, 27, 28, 29, 32, 42)
 GROUP BY 
 L.CODALMACEN, 
 AA.NOMBREALMACEN,
 D.DESCRIPCION, 
 S.DESCRIPCION, 
 F.DESCRIPCION,
 A.DPTO,
 A.SECCION,
 A.FAMILIA
 )
 SELECT 
 R.CODALMACEN,
 R.NOMBREALMACEN,
 R.DPTO,
 R.DEPARTAMENTOS,
 R.SECCION,
 R.SECCIONES,
 R.FAMILIA,
 R.FAMILIAS,
 R.UNIDADES_ALMACEN,
 ROUND(R.SHARE_UNIDADES_PV, 2) AS SHARE_UNIDADES_PV,
 ISNULL(M.MetaStock, 0) AS META_SHARE,
 ROUND((R.SHARE_UNIDADES_PV * NULLIF(M.METAstock, 0)) /100, 0) AS 'META INVENTARIO TIENDA'

FROM ResumenVentas R
 LEFT JOIN [vistasMCC].[dbo].[Tbl_PLAN_INVENTARIO_META] M 
 ON M.NUMDPTO = R.DPTO 
 AND M.NUMSECCION = R.SECCION 
 AND M.NUMFAMILIA = R.FAMILIA
 ORDER BY 
 R.UNIDADES_ALMACEN DESC;
SQL;

/*
|--------------------------------------------------------------------------
| 7. CACHÉ DE 1 HORA
|--------------------------------------------------------------------------
*/
$archivoCache = obtenerArchivoCache();
$duracionCache = 3600;
$forzarActualizacion = isset($_GET['actualizar']) && $_GET['actualizar'] === '1';
$resultados = array();
$desdeCache = false;
$fechaCache = null;

if (
    !$forzarActualizacion &&
    is_file($archivoCache) &&
    (time() - filemtime($archivoCache)) < $duracionCache
) {
    $contenidoCache = @file_get_contents($archivoCache);

    if ($contenidoCache !== false) {
        $datosCache = @unserialize($contenidoCache);

        if (is_array($datosCache)) {
            $resultados = $datosCache;
            $desdeCache = true;
            $fechaCache = filemtime($archivoCache);
        }
    }
}

if (!$desdeCache) {
    $stmt = sqlsrv_query(
        $sqlsrvConn,
        $sql,
        array(),
        array('QueryTimeout' => 0)
    );

    if ($stmt === false) {
        die('Error al consultar: ' . h(obtenerErroresSqlsrv()));
    }

    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $resultados[] = $fila;
    }

    sqlsrv_free_stmt($stmt);

    @file_put_contents(
        $archivoCache,
        serialize($resultados),
        LOCK_EX
    );

    if (is_file($archivoCache)) {
        $fechaCache = filemtime($archivoCache);
    } else {
        $fechaCache = time();
    }
}

/*
|--------------------------------------------------------------------------
| 8. APLICAR REGLA SOLO A "META INVENTARIO TIENDA"
|--------------------------------------------------------------------------
| MINIMO:
|   calculada 0, regla 12  => final 12
|   calculada 20, regla 12 => final 20
|
| MAXIMO:
|   calculada 3, regla 5   => final 3
|   calculada 8, regla 5   => final 5
|
| META_SHARE / MetaStock NO se modifica.
|--------------------------------------------------------------------------
*/
$reglasMetaMinima =
    cargarReglasMetaMinima($mysqlConn);

foreach ($resultados as &$filaResultado) {
    $numDpto =
        (int)($filaResultado['DPTO'] ?? 0);

    $numSeccion =
        (int)($filaResultado['SECCION'] ?? 0);

    $numFamilia =
        (int)($filaResultado['FAMILIA'] ?? 0);

    $metaCalculada =
        isset($filaResultado['META INVENTARIO TIENDA']) &&
        $filaResultado['META INVENTARIO TIENDA'] !== null
            ? (float)$filaResultado['META INVENTARIO TIENDA']
            : 0.0;

    $regla =
        obtenerReglaMetaMinima(
            $reglasMetaMinima,
            $numDpto,
            $numSeccion,
            $numFamilia
        );

    $tipoRegla = '';
    $valorRegla = 0.0;
    $nombreRegla = '';

    if (is_array($regla)) {
        $tipoRegla =
            ($regla['tipo_regla'] ?? 'MINIMO') === 'MAXIMO'
                ? 'MAXIMO'
                : 'MINIMO';

        $valorRegla =
            (float)($regla['valor_regla'] ?? 0);

        $nombreRegla =
            (string)($regla['nombre_regla'] ?? '');
    }

    if ($tipoRegla === 'MAXIMO') {
        $metaFinal =
            min(
                $metaCalculada,
                $valorRegla
            );
    } elseif ($tipoRegla === 'MINIMO') {
        $metaFinal =
            max(
                $metaCalculada,
                $valorRegla
            );
    } else {
        $metaFinal =
            $metaCalculada;
    }

    $filaResultado['META INVENTARIO TIENDA'] =
        $metaFinal;

    $filaResultado['META_INVENTARIO_CALCULADA'] =
        $metaCalculada;

    $filaResultado['TIPO_REGLA_META'] =
        $tipoRegla;

    $filaResultado['VALOR_REGLA_CONFIGURADA'] =
        $valorRegla;

    $filaResultado['REGLA_META_CONFIGURADA'] =
        $nombreRegla;
}
unset($filaResultado);

require_once __DIR__ . '/../layout_menu.php';

$datosJson = json_encode(
    $resultados,
    JSON_UNESCAPED_UNICODE |
    JSON_UNESCAPED_SLASHES |
    JSON_INVALID_UTF8_SUBSTITUTE
);

if ($datosJson === false) {
    $datosJson = '[]';
}

?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Calculo Inventario de Meta</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= $baseUrl ?>/Catalogo/inventariopormeta.css?v=<?= time() ?>">
  



</head>
<body>
<div class="contenedor-calculo">

    <div id="alertaSistema" class="alert d-none" role="alert"></div>

    <div class="acciones-superiores-meta">
        <div class="cache-info">
            
            <?php if ($desdeCache): ?>
                <i class="bi bi-lightning-charge"></i>
                Datos cargados desde caché
            <?php else: ?>
                <i class="bi bi-database-check"></i>
                Datos consultados desde SQL
            <?php endif; ?>
            <?php if ($fechaCache): ?>
                · <?= h(date('d/m/Y H:i:s', $fechaCache)) ?>
            <?php endif; ?>
        </div>

        <a href="?actualizar=1" class="btn btn-outline-primary">
            <i class="bi bi-arrow-clockwise"></i> Actualizar
        </a>

        <button type="button" id="btnExportar" class="btn btn-success">
            <i class="bi bi-file-earmark-excel"></i> Exportar
        </button>
    </div>

    <section class="resumen-tabla mb-3">
        <div class="resumen-registros">
            <span class="resumen-icono"><i class="bi bi-list-ul"></i></span>
            <div>
                <span class="resumen-label">Registros mostrados</span>
                <strong id="totalRegistros">0</strong>
            </div>
        </div>
        <div class="ayuda-filtros">
            <i class="bi bi-info-circle"></i>
            Use el icono <i class="bi bi-funnel-fill"></i> para filtrar.
                </div>
    </section>

    <section class="table-section">
        <div class="table-wrap">
            <table class="table metas-table table-hover align-middle">
                <thead>
                <tr>
                    <th>N°</th>
                    <!-- <th>Cod Almacén</th> -->
                    <th>
                        <div class="th-content">
                            <span>Nombre del almacén</span>
                            <button type="button" class="btn-filter-excel" data-campo="NOMBREALMACEN" data-label="Nombre del almacén" title="Filtrar Nombre del almacén">
                                <i class="bi bi-funnel"></i>
                            </button>
                        </div>
                    </th>
                    <!-- <th>DPTO</th> -->
                    <th>
                        <div class="th-content">
                            <span>Departamentos</span>
                            <button type="button" class="btn-filter-excel" data-campo="DEPARTAMENTOS" data-label="Departamento" title="Filtrar Departamento">
                                <i class="bi bi-funnel"></i>
                            </button>
                        </div>
                    </th>
                    <!-- <th>Sección</th> -->
                    <th>
                        <div class="th-content">
                            <span>Secciones</span>
                            <button type="button" class="btn-filter-excel" data-campo="SECCIONES" data-label="Sección" title="Filtrar Sección">
                                <i class="bi bi-funnel"></i>
                            </button>
                        </div>
                    </th>
                    <!-- <th>Familia</th> -->
                    <th>
                        <div class="th-content">
                            <span>Familias</span>
                            <button type="button" class="btn-filter-excel" data-campo="FAMILIAS" data-label="Familia" title="Filtrar Familia">
                                <i class="bi bi-funnel"></i>
                            </button>
                        </div>
                    </th>
                   <th class="numero" style="text-align: left;">Suma de Unidades</th>
                    <th class="numero"style="text-align: left;">Share Venta</th>
                    <th class="numero" style="text-align: left;" >Meta Inventario</th>
                    <th class="numero" style="text-align: left;">Meta por Tienda</th>
                </tr>
                </thead>
                <tbody id="tbodyResultados"></tbody>
            </table>
        </div>
    </section>

</div>

<!-- PANEL DE FILTRO TIPO EXCEL -->
<div id="excelFilterPanel" class="excel-filter-panel">
    <div class="excel-panel-header">
        <div>
            <span class="excel-panel-subtitulo">FILTRAR COLUMNA</span>
            <h6 id="excelPanelTitle" class="excel-panel-title">Filtro</h6>
        </div>
        <button type="button" id="btnCerrarPanel" class="btn-close-panel" aria-label="Cerrar filtro">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>

    <div class="excel-panel-body">
        <button type="button" id="btnOrdenAsc" class="excel-sort-btn">
            <i class="bi bi-sort-alpha-down"></i> Ordenar de A a Z
        </button>
        <button type="button" id="btnOrdenDesc" class="excel-sort-btn">
            <i class="bi bi-sort-alpha-up"></i> Ordenar de Z a A
        </button>

        <div class="separador-panel"></div>

        <div class="filter-search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="inputBuscarValores" class="form-control" placeholder="Buscar valor..." autocomplete="off">
        </div>

        <label class="check-row seleccionar-todos">
            <input type="checkbox" id="checkSelectAll" checked>
            <strong>Seleccionar todo</strong>
        </label>

        <div id="valueList" class="value-list"></div>
    </div>

    <div class="excel-panel-footer">
        <div class="acciones-panel">
            <button type="button" id="btnAplicarFiltro" class="btn btn-primary">
                <i class="bi bi-check2"></i> Aplicar
            </button>
            <button type="button" id="btnLimpiarFiltro" class="btn btn-outline-secondary">
                <i class="bi bi-eraser"></i> Limpiar
            </button>
        </div>
        <button type="button" id="btnLimpiarSoloFiltros" class="btn btn-outline-danger btn-quitar-filtros">
            <i class="bi bi-funnel"></i> Quitar filtros
        </button>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
window.DATOS_INVENTARIO_META = <?= $datosJson ?>;
</script>

<script src="<?= $baseUrl ?>/Catalogo/nmeta.js?v=<?= time() ?>" defer></script>


<?php require_once __DIR__ . '/../layout_footer.php'; ?>