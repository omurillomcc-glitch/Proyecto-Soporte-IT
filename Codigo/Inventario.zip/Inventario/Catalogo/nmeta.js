
'use strict';

const datosActuales = window.DATOS_INVENTARIO_META || [];
const tbodyResultados = document.getElementById('tbodyResultados');
const totalRegistros = document.getElementById('totalRegistros');
const btnExportar = document.getElementById('btnExportar');
const alertaSistema = document.getElementById('alertaSistema');

const excelFilterPanel = document.getElementById('excelFilterPanel');
const excelPanelTitle = document.getElementById('excelPanelTitle');
const btnCerrarPanel = document.getElementById('btnCerrarPanel');
const btnOrdenAsc = document.getElementById('btnOrdenAsc');
const btnOrdenDesc = document.getElementById('btnOrdenDesc');
const inputBuscarValores = document.getElementById('inputBuscarValores');
const checkSelectAll = document.getElementById('checkSelectAll');
const valueList = document.getElementById('valueList');
const btnAplicarFiltro = document.getElementById('btnAplicarFiltro');
const btnLimpiarFiltro = document.getElementById('btnLimpiarFiltro');
const btnLimpiarSoloFiltros = document.getElementById('btnLimpiarSoloFiltros');

let campoFiltroActivo = null;
let ordenActual = { campo: null, direccion: null };
const filtrosExcel = {};

let paginaActual = 1;
let registrosPorPagina = 500;
let contenedorPaginacion = null;
let botonesPaginas = null;
let selectRegistrosPagina = null;

function escaparHtml(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function normalizarTexto(valor) {
    return String(valor ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim()
        .toLowerCase();
}

function mostrarAlerta(tipo, mensaje) {
    alertaSistema.className = `alert alert-${tipo}`;
    alertaSistema.textContent = mensaje;
    alertaSistema.classList.remove('d-none');
}

function ocultarAlerta() {
    alertaSistema.classList.add('d-none');
    alertaSistema.textContent = '';
}

function valorCrudoFiltro(fila, campo) {
    return String(fila?.[campo] ?? '').trim();
}

function valorVisibleFiltro(valor) {
    const texto = String(valor ?? '').trim();
    return texto === '' ? '(Vacíos)' : texto;
}

function obtenerDatosSegunOtrosFiltros(campoExcluir = null) {
    return datosActuales.filter(fila => {
        return Object.entries(filtrosExcel).every(([campo, valoresSeleccionados]) => {
            if (campo === campoExcluir) return true;
            if (!(valoresSeleccionados instanceof Set)) return true;
            return valoresSeleccionados.has(valorCrudoFiltro(fila, campo));
        });
    });
}

function obtenerValoresDisponibles(campo) {
    const datosContextuales = obtenerDatosSegunOtrosFiltros(campo);
    const valores = [...new Set(datosContextuales.map(fila => valorCrudoFiltro(fila, campo)))];

    return valores.sort((a, b) => String(a).localeCompare(String(b), 'es', {
        numeric: true,
        sensitivity: 'base'
    }));
}

function obtenerDatosFiltradosYOrdenados() {
    let resultado = datosActuales.filter(fila => {
        return Object.entries(filtrosExcel).every(([campo, valoresSeleccionados]) => {
            if (!(valoresSeleccionados instanceof Set)) return true;
            return valoresSeleccionados.has(valorCrudoFiltro(fila, campo));
        });
    });

    resultado = [...resultado];

    if (ordenActual.campo && ordenActual.direccion) {
        resultado.sort((a, b) => {
            const valorA = String(a[ordenActual.campo] ?? '').trim();
            const valorB = String(b[ordenActual.campo] ?? '').trim();
            const comparacion = valorA.localeCompare(valorB, 'es', {
                numeric: true,
                sensitivity: 'base'
            });
            return ordenActual.direccion === 'asc' ? comparacion : -comparacion;
        });
    }

    return resultado;
}

function renderizarTabla(datos, totalFiltrado, inicioRegistro) {
    if (!Array.isArray(datos) || datos.length === 0) {
        tbodyResultados.innerHTML = '<tr><td colspan="9" class="estado-tabla">No hay resultados con los filtros seleccionados.</td></tr>';
        totalRegistros.textContent = datosActuales.length > 0 ? `0 de ${datosActuales.length}` : '0';
        actualizarControlesPaginacion(totalFiltrado);
        actualizarIconosFiltros();
        return;
    }

    tbodyResultados.innerHTML = datos.map((fila, i) => `
        <tr>
            <td>${inicioRegistro + i + 1}</td>
            <!-- <td>${escaparHtml(fila.CODALMACEN)}</td> -->
            <td>${escaparHtml(fila.NOMBREALMACEN)}</td>
            <!-- <td>${escaparHtml(fila.DPTO)}</td> -->
            <td>${escaparHtml(fila.DEPARTAMENTOS)}</td>
            <!-- <td>${escaparHtml(fila.SECCION)}</td> -->
            <td>${escaparHtml(fila.SECCIONES)}</td>
            <!-- <td>${escaparHtml(fila.FAMILIA)}</td> -->
            <td>${escaparHtml(fila.FAMILIAS)}</td>
            <td class="numero" style="text-align: right;">${Number(fila.UNIDADES_ALMACEN || 0).toLocaleString('es-HN', {maximumFractionDigits: 0})}</td>
            <td class="numero" style="text-align: right;"> ${fila.SHARE_UNIDADES_PV !== null && fila.SHARE_UNIDADES_PV !== undefined && fila.SHARE_UNIDADES_PV !== '' ? (Math.round(Number(fila.SHARE_UNIDADES_PV) * 100)) + '%' : '0%'}</td>
            <td class="numero" style="text-align: right;">${Number(fila.META_SHARE || 0).toLocaleString('es-HN', {maximumFractionDigits: 0})}</td>
            <td class="numero" style="text-align: right;">${fila['META INVENTARIO TIENDA'] ?? ''}</td>
        </tr>


    `).join('');

    const fin = inicioRegistro + datos.length;
    totalRegistros.textContent = `${inicioRegistro + 1}-${fin} de ${totalFiltrado}`;
    actualizarControlesPaginacion(totalFiltrado);
    actualizarIconosFiltros();
}

function aplicarFiltrosYOrden({ conservarPagina = false } = {}) {
    const filtrados = obtenerDatosFiltradosYOrdenados();

    if (!conservarPagina) paginaActual = 1;

    const totalPaginas = Math.max(1, Math.ceil(filtrados.length / registrosPorPagina));
    if (paginaActual > totalPaginas) paginaActual = totalPaginas;

    const inicio = (paginaActual - 1) * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    renderizarTabla(filtrados.slice(inicio, fin), filtrados.length, inicio);
}

function crearControlesPaginacion() {
    contenedorPaginacion = document.createElement('div');
    contenedorPaginacion.id = 'contenedorPaginacionMetas';
    contenedorPaginacion.className = 'paginacion-metas';
    contenedorPaginacion.innerHTML = `
        <div class="paginacion-cantidad">
            <label for="selectRegistrosPagina">Mostrar</label>
            <select id="selectRegistrosPagina" class="form-select form-select-sm">
                <option value="500"selected>500</option>
                <option value="1000">1000</option>
                <option value="2000">2000</option>
            </select>
            <span>registros</span>
        </div>
        <div class="paginacion-botones">
            <button type="button" id="btnPrimeraPagina" class="btn btn-sm btn-outline-secondary" title="Primera página"><i class="bi bi-chevron-bar-left"></i></button>
            <button type="button" id="btnPaginaAnterior" class="btn btn-sm btn-outline-secondary" title="Página anterior"><i class="bi bi-chevron-left"></i></button>
            <div id="botonesPaginas" class="numeros-paginacion"></div>
            <button type="button" id="btnPaginaSiguiente" class="btn btn-sm btn-outline-secondary" title="Página siguiente"><i class="bi bi-chevron-right"></i></button>
            <button type="button" id="btnUltimaPagina" class="btn btn-sm btn-outline-secondary" title="Última página"><i class="bi bi-chevron-bar-right"></i></button>
        </div>
    `;

    document.querySelector('.table-section').insertAdjacentElement('afterend', contenedorPaginacion);
    botonesPaginas = document.getElementById('botonesPaginas');
    selectRegistrosPagina = document.getElementById('selectRegistrosPagina');

    selectRegistrosPagina.addEventListener('change', () => {
        registrosPorPagina = Number(selectRegistrosPagina.value);
        paginaActual = 1;
        aplicarFiltrosYOrden();
    });

    document.getElementById('btnPrimeraPagina').addEventListener('click', () => cambiarPagina(1));
    document.getElementById('btnPaginaAnterior').addEventListener('click', () => cambiarPagina(paginaActual - 1));
    document.getElementById('btnPaginaSiguiente').addEventListener('click', () => cambiarPagina(paginaActual + 1));
    document.getElementById('btnUltimaPagina').addEventListener('click', () => {
        const totalPaginas = Math.max(1, Math.ceil(obtenerDatosFiltradosYOrdenados().length / registrosPorPagina));
        cambiarPagina(totalPaginas);
    });
}

function cambiarPagina(numero) {
    const total = obtenerDatosFiltradosYOrdenados().length;
    const totalPaginas = Math.max(1, Math.ceil(total / registrosPorPagina));
    const nueva = Math.min(Math.max(1, numero), totalPaginas);

    if (nueva === paginaActual) return;

    paginaActual = nueva;
    aplicarFiltrosYOrden({ conservarPagina: true });
    document.querySelector('.table-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function actualizarControlesPaginacion(totalFiltrado) {
    if (!contenedorPaginacion) return;

    const totalPaginas = Math.max(1, Math.ceil(totalFiltrado / registrosPorPagina));
    const primera = paginaActual <= 1 || totalFiltrado === 0;
    const ultima = paginaActual >= totalPaginas || totalFiltrado === 0;

    document.getElementById('btnPrimeraPagina').disabled = primera;
    document.getElementById('btnPaginaAnterior').disabled = primera;
    document.getElementById('btnPaginaSiguiente').disabled = ultima;
    document.getElementById('btnUltimaPagina').disabled = ultima;

    botonesPaginas.innerHTML = '';

    obtenerPaginasVisibles(paginaActual, totalPaginas).forEach(p => {
        if (p === '...') {
            const span = document.createElement('span');
            span.textContent = '...';
            span.className = 'px-1';
            botonesPaginas.appendChild(span);
            return;
        }

        const boton = document.createElement('button');
        boton.type = 'button';
        boton.textContent = p;
        boton.className = 'btn btn-sm ' + (p === paginaActual ? 'btn-primary' : 'btn-outline-secondary');
        boton.disabled = p === paginaActual;
        boton.addEventListener('click', () => cambiarPagina(p));
        botonesPaginas.appendChild(boton);
    });
}

function obtenerPaginasVisibles(pagina, total) {
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    if (pagina <= 4) return [1, 2, 3, 4, 5, '...', total];
    if (pagina >= total - 3) return [1, '...', total - 4, total - 3, total - 2, total - 1, total];
    return [1, '...', pagina - 1, pagina, pagina + 1, '...', total];
}

function abrirPanelFiltro(boton) {
    campoFiltroActivo = boton.dataset.campo;
    excelPanelTitle.textContent = boton.dataset.label || campoFiltroActivo;
    inputBuscarValores.value = '';
    crearListaValoresFiltro(
        obtenerValoresDisponibles(campoFiltroActivo),
        filtrosExcel[campoFiltroActivo]
    );

    excelFilterPanel.classList.add('show', 'active');
    posicionarPanelFiltro(boton);
    setTimeout(() => inputBuscarValores.focus(), 20);
}

function cerrarPanelFiltro() {
    excelFilterPanel.classList.remove('show', 'active');
    campoFiltroActivo = null;
}

function posicionarPanelFiltro(boton) {
    const rect = boton.getBoundingClientRect();
    const margen = 10;
    const ancho = Math.min(310, window.innerWidth - margen * 2);

    excelFilterPanel.style.width = `${ancho}px`;

    let izquierda = rect.right - ancho;
    if (izquierda < margen) izquierda = margen;
    if (izquierda + ancho > window.innerWidth - margen) {
        izquierda = window.innerWidth - ancho - margen;
    }

    const alto = Math.min(excelFilterPanel.scrollHeight, window.innerHeight - margen * 2);
    let arriba = rect.bottom + 6;

    if (arriba + alto > window.innerHeight - margen) {
        arriba = Math.max(margen, rect.top - alto - 6);
    }

    excelFilterPanel.style.left = `${izquierda}px`;
    excelFilterPanel.style.top = `${arriba}px`;
}

function crearListaValoresFiltro(valores, seleccionGuardada) {
    valueList.innerHTML = '';
    const tieneFiltro = seleccionGuardada instanceof Set;

    valores.forEach((valor, indice) => {
        const label = document.createElement('label');
        label.className = 'check-row value-filter-row';
        label.dataset.busqueda = normalizarTexto(valorVisibleFiltro(valor));

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'check-valor-filtro';
        checkbox.id = `filtro_${campoFiltroActivo}_${indice}`;
        checkbox.value = valor;
        checkbox.checked = tieneFiltro ? seleccionGuardada.has(valor) : true;

        const span = document.createElement('span');
        span.textContent = valorVisibleFiltro(valor);
        span.title = span.textContent;

        label.appendChild(checkbox);
        label.appendChild(span);
        valueList.appendChild(label);
    });

    actualizarSeleccionarTodo();
}

function actualizarSeleccionarTodo() {
    const visibles = [...valueList.querySelectorAll('.value-filter-row:not(.d-none) .check-valor-filtro')];

    if (!visibles.length) {
        checkSelectAll.checked = false;
        checkSelectAll.indeterminate = false;
        return;
    }

    const seleccionados = visibles.filter(c => c.checked).length;
    checkSelectAll.checked = seleccionados === visibles.length;
    checkSelectAll.indeterminate = seleccionados > 0 && seleccionados < visibles.length;
}

function aplicarFiltroColumna() {
    if (!campoFiltroActivo) return;

    const hayBusqueda = inputBuscarValores.value.trim() !== '';
    const selector = hayBusqueda
        ? '.value-filter-row:not(.d-none) .check-valor-filtro'
        : '.check-valor-filtro';

    const considerados = [...valueList.querySelectorAll(selector)];
    const seleccionados = considerados.filter(c => c.checked).map(c => c.value);
    filtrosExcel[campoFiltroActivo] = new Set(seleccionados);

    if (!hayBusqueda) {
        const todos = [...valueList.querySelectorAll('.check-valor-filtro')];
        if (todos.length > 0 && seleccionados.length === todos.length) {
            delete filtrosExcel[campoFiltroActivo];
        }
    }

    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function limpiarFiltroColumna() {
    if (!campoFiltroActivo) return;
    delete filtrosExcel[campoFiltroActivo];
    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function quitarTodosLosFiltros() {
    Object.keys(filtrosExcel).forEach(campo => delete filtrosExcel[campo]);
    ordenActual = { campo: null, direccion: null };
    cerrarPanelFiltro();
    paginaActual = 1;
    aplicarFiltrosYOrden();
}

function ordenarColumna(direccion) {
    if (!campoFiltroActivo) return;
    ordenActual = { campo: campoFiltroActivo, direccion };
    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function actualizarIconosFiltros() {
    document.querySelectorAll('.btn-filter-excel').forEach(boton => {
        const campo = boton.dataset.campo;
        const filtroActivo = filtrosExcel[campo] instanceof Set;
        const ordenActivo = ordenActual.campo === campo;

        boton.classList.toggle('filter-active', filtroActivo || ordenActivo);
        boton.classList.toggle('filtro-activo', filtroActivo || ordenActivo);

        const icono = boton.querySelector('i');
        if (!icono) return;

        if (filtroActivo) {
            icono.className = 'bi bi-funnel-fill';
        } else if (ordenActivo) {
            icono.className = ordenActual.direccion === 'asc' ? 'bi bi-sort-up' : 'bi bi-sort-down';
        } else {
            icono.className = 'bi bi-funnel';
        }
    });
}

function exportarExcel() {
    ocultarAlerta();
    const datos = obtenerDatosFiltradosYOrdenados();

    if (!datos.length) {
        mostrarAlerta('warning', 'No hay registros filtrados para exportar.');
        return;
    }

    const filas = datos.map((fila, i) => `
        <tr>
            <td>${i + 1}</td>
            <!--<td>${escaparHtml(fila.CODALMACEN)}</td>-->
            <td>${escaparHtml(fila.NOMBREALMACEN)}</td>
            <!--<td>${escaparHtml(fila.DPTO)}</td>-->
            <td>${escaparHtml(fila.DEPARTAMENTOS)}</td>
            <!--<td>${escaparHtml(fila.SECCION)}</td>-->
            <td>${escaparHtml(fila.SECCIONES)}</td>
            <!--<td>${escaparHtml(fila.FAMILIA)}</td>-->
            <td>${escaparHtml(fila.FAMILIAS)}</td>
            <td>${Number(fila.UNIDADES_ALMACEN || 0)}</td>
            <td style="vnd.ms-excel.numberformat:0%;">${Math.round(Number(fila.SHARE_UNIDADES_PV || 0) * 100)}%</td>
            <td>${Number(fila.META_SHARE || 0)}</td>
            <td>${Number(fila['META INVENTARIO TIENDA'] || 0)}</td>
        </tr>
    `).join('');

    const html = `<!doctype html>
    <html xmlns:x="urn:schemas-microsoft-com:office:excel">
    <head>
        <meta charset="UTF-8">
        <style>
            table{border-collapse:collapse;font-family:Calibri,Arial,sans-serif;font-size:11pt}
            th{background:#1e3a8a;color:white;font-weight:bold;border:1px solid #1e3a8a;padding:5px}
            td{border:1px solid #ddd;padding:4px}
        </style>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th>N°</th>
                     <!-- <th>COD ALMACÉN</th> -->
                    <th>NOMBRE ALMACÉN</th>
                    <!-- <th>DPTO</th> -->
                    <th>DEPARTAMENTO</th>
                    <!--<th>SECCIÓN</th> -->
                    <th>SECCIONES</th>
                     <!--<th>FAMILIA</th>-->
                    <th>FAMILIAS</th>
                    <th>SUMA DE UNIDADES</th>
                    <th>SHARE VENTA</th>
                    <th>META INVENTARIO</th>
                    <th>META INVENTARIO TIENDA</th>
                </tr>
            </thead>
            <tbody>${filas}</tbody>
        </table>
    </body>
    </html>`;

    const blob = new Blob(['\uFEFF' + html], {
        type: 'application/vnd.ms-excel;charset=utf-8;'
    });

    const url = URL.createObjectURL(blob);
    const enlace = document.createElement('a');
    enlace.href = url;
    enlace.download = `Calculo de inventario${new Date().toISOString().slice(0, 10)}.xls`;
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(url);

    mostrarAlerta('success', `Se exportaron ${datos.length.toLocaleString('es-HN')} registros filtrados.`);
}

document.querySelectorAll('.btn-filter-excel').forEach(boton => {
    boton.addEventListener('click', evento => {
        evento.preventDefault();
        evento.stopPropagation();
        abrirPanelFiltro(boton);
    });
});

btnCerrarPanel.addEventListener('click', cerrarPanelFiltro);
btnOrdenAsc.addEventListener('click', () => ordenarColumna('asc'));
btnOrdenDesc.addEventListener('click', () => ordenarColumna('desc'));
btnAplicarFiltro.addEventListener('click', aplicarFiltroColumna);
btnLimpiarFiltro.addEventListener('click', limpiarFiltroColumna);
btnLimpiarSoloFiltros.addEventListener('click', quitarTodosLosFiltros);

inputBuscarValores.addEventListener('input', () => {
    const busqueda = normalizarTexto(inputBuscarValores.value);

    valueList.querySelectorAll('.value-filter-row').forEach(fila => {
        fila.classList.toggle(
            'd-none',
            !(fila.dataset.busqueda || '').includes(busqueda)
        );
    });

    actualizarSeleccionarTodo();
});

checkSelectAll.addEventListener('change', () => {
    valueList
        .querySelectorAll('.value-filter-row:not(.d-none) .check-valor-filtro')
        .forEach(c => {
            c.checked = checkSelectAll.checked;
        });

    actualizarSeleccionarTodo();
});

valueList.addEventListener('change', evento => {
    if (evento.target.classList.contains('check-valor-filtro')) {
        actualizarSeleccionarTodo();
    }
});

excelFilterPanel.addEventListener('mousedown', e => e.stopPropagation());
excelFilterPanel.addEventListener('click', e => e.stopPropagation());

document.addEventListener('mousedown', e => {
    if (!excelFilterPanel.contains(e.target) && !e.target.closest('.btn-filter-excel')) {
        cerrarPanelFiltro();
    }
});

window.addEventListener('resize', cerrarPanelFiltro);
btnExportar.addEventListener('click', exportarExcel);

crearControlesPaginacion();
aplicarFiltrosYOrden();
actualizarIconosFiltros();
btnExportar.disabled = datosActuales.length === 0;
