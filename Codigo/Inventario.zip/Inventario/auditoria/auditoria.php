<?php
declare(strict_types=1);

require_once __DIR__ . '/../usuarios/auth.php';
require_login();
require_once __DIR__ . '/../usuarios/db.php';

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

function limpiar($valor): string
{
    return trim((string)$valor);
}

function h($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

/** @return array{tipo:'pdo'|'mysqli',db:PDO|mysqli} */
function detectar_conexion(): array
{
    global $pdo, $conn, $mysqli, $conexion;

    foreach ([$pdo ?? null, $conn ?? null, $mysqli ?? null, $conexion ?? null] as $db) {
        if ($db instanceof PDO) {
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return ['tipo' => 'pdo', 'db' => $db];
        }

        if ($db instanceof mysqli) {
            $db->set_charset('utf8mb4');
            return ['tipo' => 'mysqli', 'db' => $db];
        }
    }

    throw new RuntimeException('No se encontró la conexión MySQL. Carga tu archivo de conexión.');
}

/**
 * @param array<int,string|int|float|null> $params
 * @return array<int,array<string,mixed>>
 */
function db_fetch_all(array $conexionDb, string $sql, array $params = [], string $types = ''): array
{
    if ($conexionDb['tipo'] === 'pdo') {
        /** @var PDO $db */
        $db = $conexionDb['db'];
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** @var mysqli $db */
    $db = $conexionDb['db'];
    $stmt = $db->prepare($sql);

    if (!$stmt) {
        throw new RuntimeException($db->error);
    }

    if ($params !== []) {
        if ($types === '') {
            $types = str_repeat('s', count($params));
        }

        $argumentos = [$types];
        foreach ($params as $indice => $valor) {
            $argumentos[] = &$params[$indice];
        }
        $stmt->bind_param(...$argumentos);
    }

    if (!$stmt->execute()) {
        throw new RuntimeException($stmt->error);
    }

    $resultado = $stmt->get_result();
    $filas = $resultado ? $resultado->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();

    return $filas;
}

/** @param array<int,string|int|float|null> $params */
function db_fetch_value(array $conexionDb, string $sql, array $params = [], string $types = '')
{
    $filas = db_fetch_all($conexionDb, $sql, $params, $types);
    return $filas === [] ? null : (array_values($filas[0])[0] ?? null);
}

function url_pagina(int $pagina): string
{
    $parametros = $_GET;
    $parametros['pagina'] = $pagina;
    return '?' . http_build_query($parametros);
}

/** @return array{clase:string,icono:string,etiqueta:string} */
function datos_accion(string $accion): array
{
    $accion = limpiar($accion);

    switch ($accion) {
        /*
        |--------------------------------------------------------------------------
        | META STOCK
        |--------------------------------------------------------------------------
        */
        case 'META_CREADO':
            return [
                'clase' => 'create',
                'icono' => 'bi-plus-lg',
                'etiqueta' => 'Meta creada'
            ];

        case 'META_ACTUALIZADO':
            return [
                'clase' => 'update',
                'icono' => 'bi-pencil',
                'etiqueta' => 'Meta actualizada'
            ];

        /*
        |--------------------------------------------------------------------------
        | META MÍNIMA
        |--------------------------------------------------------------------------
        */
        case 'META_MINIMA_CREADA':
            return [
                'clase' => 'create',
                'icono' => 'bi-shield-plus',
                'etiqueta' => 'Regla de meta creada'
            ];

        case 'META_MINIMA_ACTUALIZADA':
            return [
                'clase' => 'update',
                'icono' => 'bi-pencil-square',
                'etiqueta' => 'Regla de meta actualizada'
            ];

        case 'META_MINIMA_ACTIVADA':
            return [
                'clase' => 'create',
                'icono' => 'bi-check-circle',
                'etiqueta' => 'Regla de meta activada'
            ];

        case 'META_MINIMA_DESACTIVADA':
            return [
                'clase' => 'danger',
                'icono' => 'bi-x-circle',
                'etiqueta' => 'Regla de meta desactivada'
            ];

        /*
        |--------------------------------------------------------------------------
        | USUARIOS
        |--------------------------------------------------------------------------
        */
        case 'USUARIO_CREADO':
            return [
                'clase' => 'create',
                'icono' => 'bi-person-plus',
                'etiqueta' => 'Usuario creado'
            ];

        case 'USUARIO_EDITADO':
            return [
                'clase' => 'update',
                'icono' => 'bi-person-gear',
                'etiqueta' => 'Usuario editado'
            ];

        case 'USUARIO_BLOQUEADO':
            return [
                'clase' => 'danger',
                'icono' => 'bi-person-lock',
                'etiqueta' => 'Usuario bloqueado'
            ];

        case 'USUARIO_DESBLOQUEADO':
            return [
                'clase' => 'create',
                'icono' => 'bi-unlock',
                'etiqueta' => 'Usuario desbloqueado'
            ];

        /*
        |--------------------------------------------------------------------------
        | SESIONES
        |--------------------------------------------------------------------------
        */
        case 'LOGIN':
        case 'LOGIN_EXITOSO':
            return [
                'clase' => 'session',
                'icono' => 'bi-box-arrow-in-right',
                'etiqueta' => 'Inicio de sesión'
            ];

        case 'LOGOUT':
        case 'CIERRE_SESION':
            return [
                'clase' => 'neutral',
                'icono' => 'bi-box-arrow-right',
                'etiqueta' => 'Cierre de sesión'
            ];

        default:
            return [
                'clase' => 'info',
                'icono' => 'bi-activity',
                'etiqueta' => $accion !== ''
                    ? str_replace('_', ' ', $accion)
                    : 'Sin acción'
            ];
    }
}

function fecha_legible(string $fecha): string
{
    $timestamp = strtotime($fecha);
    return $timestamp ? date('d/m/Y H:i:s', $timestamp) : $fecha;
}

try {
    $db = detectar_conexion();
} catch (Exception $error) {
    http_response_code(500);
    exit('<div style="padding:20px;font-family:Arial;color:#842029;background:#f8d7da">' . h($error->getMessage()) . '</div>');
}

$buscar = limpiar($_GET['buscar'] ?? '');
$accion = limpiar($_GET['accion'] ?? '');
$desde = limpiar($_GET['desde'] ?? '');
$hasta = limpiar($_GET['hasta'] ?? '');

$opcionesPermitidas = [100, 200, 500];
$porPagina = (int)($_GET['por_pagina'] ?? 100);
if (!in_array($porPagina, $opcionesPermitidas, true)) {
    $porPagina = 100;
}

$pagina = max(1, (int)($_GET['pagina'] ?? 1));

/*
|--------------------------------------------------------------------------
| OCULTAR TODOS LOS EVENTOS DE LOGIN EN LA AUDITORÍA
|--------------------------------------------------------------------------
| Los registros siguen guardados en la tabla auditoria, pero no se muestran
| en esta pantalla ni se incluyen en el total ni en el filtro de acciones.
*/
$where = [
    "UPPER(TRIM(accion)) NOT IN (
        'LOGIN',
        'LOGIN_EXITOSO',
        'LOGOUT',
        'CIERRE_SESION',
        'LOGIN_FALLIDO',
        'LOGIN_FAIL',
        'LOGIN_FAILED',
        'LOGIN_ERROR'
    )",
    "UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FAIL%'",
    "UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FALL%'"
];

$params = [];
$types = '';

if ($buscar !== '') {
    $where[] = '(usuario LIKE ? OR nombre_completo LIKE ? OR detalle LIKE ? OR ip LIKE ?)';
    $textoBuscar = '%' . $buscar . '%';
    array_push($params, $textoBuscar, $textoBuscar, $textoBuscar, $textoBuscar);
    $types .= 'ssss';
}

if ($accion !== '') {
    $where[] = 'accion = ?';
    $params[] = $accion;
    $types .= 's';
}

if ($desde !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) {
    $where[] = 'fecha >= ?';
    $params[] = $desde . ' 00:00:00';
    $types .= 's';
}

if ($hasta !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) {
    $where[] = 'fecha < DATE_ADD(?, INTERVAL 1 DAY)';
    $params[] = $hasta;
    $types .= 's';
}

$sqlWhere = $where !== [] ? ' WHERE ' . implode(' AND ', $where) : '';
$totalRegistros = (int)db_fetch_value($db, "SELECT COUNT(*) FROM auditoria {$sqlWhere}", $params, $types);
$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));
$pagina = min($pagina, $totalPaginas);
$offset = ($pagina - 1) * $porPagina;

$registros = db_fetch_all(
    $db,
    "SELECT usuario, nombre_completo, accion, detalle, ip, fecha
     FROM auditoria {$sqlWhere}
     ORDER BY fecha DESC, usuario ASC
     LIMIT {$porPagina} OFFSET {$offset}",
    $params,
    $types
);

$accionesDisponibles = db_fetch_all(
    $db,
    "SELECT DISTINCT accion
     FROM auditoria
     WHERE accion IS NOT NULL
       AND accion <> ''
       AND UPPER(TRIM(accion)) NOT IN (
           'LOGIN',
           'LOGIN_EXITOSO',
           'LOGOUT',
           'CIERRE_SESION',
           'LOGIN_FALLIDO',
           'LOGIN_FAIL',
           'LOGIN_FAILED',
           'LOGIN_ERROR'
       )
       AND UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FAIL%'
       AND UPPER(TRIM(accion)) NOT LIKE '%LOGIN%FALL%'
     ORDER BY accion ASC"
);

require_once __DIR__ . '/../layout_menu.php';
?>

<link rel="stylesheet" href="<?= htmlspecialchars(dirname($_SERVER['SCRIPT_NAME']), ENT_QUOTES, 'UTF-8') ?>/auditoria.css?v=<?= time() ?>">

<main class="ops-page">
    <header class="ops-heading">
        <div>
            <span class="ops-eyebrow"></span>
            <h1></h1>
            <p></p>
        </div>

       <a href="<?= h($_SERVER['REQUEST_URI'] ?? '?') ?>" class="ops-refresh-btn">
    <!-- SVG directo de bi-arrow-clockwise -->
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2z"/>
        <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/>
    </svg>
    <span></span>
</a>

    </header>

    <form method="get" class="ops-toolbar" autocomplete="off">
        <div class="ops-search-field">
            <i class="bi bi-search"></i>
            <input type="search" name="buscar" value="<?= h($buscar) ?>" placeholder="Buscar por usuario, detalle o dirección IP">
        </div>

        <div class="ops-filter-field">
            <label for="accion">Acción</label>
            <select name="accion" id="accion">
                <option value="">Todas</option>
                <?php foreach ($accionesDisponibles as $opcion): ?>
                    <?php $valorAccion = (string)($opcion['accion'] ?? ''); ?>
                    <option value="<?= h($valorAccion) ?>" <?= $accion === $valorAccion ? 'selected' : '' ?>>
                        <?= h(str_replace('_', ' ', $valorAccion)) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="ops-filter-field">
            <label for="desde">Desde</label>
            <input type="date" name="desde" id="desde" value="<?= h($desde) ?>">
        </div>

        <div class="ops-filter-field">
            <label for="hasta">Hasta</label>
            <input type="date" name="hasta" id="hasta" value="<?= h($hasta) ?>">
        </div>

        <div class="ops-filter-field ops-filter-small">
            <label for="por_pagina">Mostrar</label>
            <select name="por_pagina" id="por_pagina">
                <?php foreach ($opcionesPermitidas as $opcion): ?>
                    <option value="<?= $opcion ?>" <?= $porPagina === $opcion ? 'selected' : '' ?>><?= $opcion ?></option>
                <?php endforeach; ?>
            </select>
        </div>

      <button type="submit" class="ops-search-btn">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-square" viewBox="0 0 16 16">
        <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
        <path d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z"/>
    </svg>
    Aplicar
</button>


        <a href="?" class="ops-clear-btn" title="Limpiar filtros">
            <i class="bi bi-x-lg"></i>
        </a>
    </form>

    <section class="ops-workspace">
        <aside class="ops-events-panel">
            <div class="ops-panel-header">
                <div>
                    <span>Resumen</span>
                    <strong><?= number_format($totalRegistros) ?></strong>
                </div>
            <!--<small>
                    <?= $totalRegistros === 0 ? 0 : $offset + 1 ?>–<?= min($offset + $porPagina, $totalRegistros) ?>
                </small>-->
            </div>

            <div class="ops-event-list" id="auditEventList">
                <?php if ($registros === []): ?>
                    <div class="ops-empty-list">
                        <i class="bi bi-inbox"></i>
                        <strong>No hay resumen</strong>
                        <span>Cambia los filtros para realizar otra búsqueda.</span>
                    </div>
                <?php else: ?>
                    <?php foreach ($registros as $indice => $registro): ?>
                        <?php
                        $datosAccion = datos_accion((string)$registro['accion']);
                        $nombreVisible = limpiar($registro['nombre_completo'] ?? '') ?: limpiar($registro['usuario'] ?? '') ?: 'Usuario sin nombre';
                        $fechaCompleta = fecha_legible((string)$registro['fecha']);
                        $fechaPartes = explode(' ', $fechaCompleta, 2);
                        $detalle = limpiar($registro['detalle'] ?? '') ?: 'Sin detalle disponible.';
                        $payload = [
                            'accion' => (string)$registro['accion'],
                            'accionEtiqueta' => $datosAccion['etiqueta'],
                            'accionClase' => $datosAccion['clase'],
                            'usuario' => (string)$registro['usuario'],
                            'nombre' => (string)$registro['nombre_completo'],
                            'fecha' => $fechaCompleta,
                            'ip' => limpiar($registro['ip'] ?? '') ?: 'No registrada',
                            'detalle' => $detalle,
                        ];
                        ?>
                        <button
                            type="button"
                            class="ops-event <?= $indice === 0 ? 'is-active' : '' ?>"
                            data-event='<?= h(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'
                        >
                            <span class="ops-event-marker <?= h($datosAccion['clase']) ?>">
                                <i class="bi <?= h($datosAccion['icono']) ?>"></i>
                            </span>

                            <span class="ops-event-body">
                                <span class="ops-event-topline">
                                    <strong><?= h($datosAccion['etiqueta']) ?></strong>
                                    <time><?= h($fechaPartes[1] ?? '') ?></time>
                                </span>
                                <span class="ops-event-user"><?= h($nombreVisible) ?></span>
                                <span class="ops-event-detail"><?= h($detalle) ?></span>
                                <span class="ops-event-date"><?= h($fechaPartes[0] ?? $fechaCompleta) ?></span>
                            </span>

                            <i class="bi bi-chevron-right ops-event-arrow"></i>
                        </button>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <nav class="ops-pagination" aria-label="Paginación de auditoría">
                <?php if ($pagina > 1): ?>
                    <a href="<?= h(url_pagina($pagina - 1)) ?>" aria-label="Página anterior"><i class="bi bi-chevron-left"></i></a>
                <?php else: ?>
                    <span class="is-disabled"><i class="bi bi-chevron-left"></i></span>
                <?php endif; ?>

                <span class="ops-page-number">Página <?= $pagina ?> de <?= $totalPaginas ?></span>

                <?php if ($pagina < $totalPaginas): ?>
                    <a href="<?= h(url_pagina($pagina + 1)) ?>" aria-label="Página siguiente"><i class="bi bi-chevron-right"></i></a>
                <?php else: ?>
                    <span class="is-disabled"><i class="bi bi-chevron-right"></i></span>
                <?php endif; ?>
            </nav>
        </aside>

        <article class="ops-detail-panel" id="auditDetailPanel">
            <?php if ($registros === []): ?>
                <div class="ops-empty-detail">
                    <span><i class="bi bi-shield-check"></i></span>
                    <h2>Sin resumen para mostrar</h2>
                    <p>Los datos del  resumen seleccionado aparecerán en este espacio.</p>
                </div>
            <?php else: ?>
                <div class="ops-detail-heading">
                    <div>
                        <span class="ops-detail-label">Detalle del resumen</span>
                    
                    </div>
                    <span class="ops-status-badge info" id="detailBadge">—</span>
                </div>

                <div class="ops-detail-grid">
                    <div class="ops-detail-item">
                        <span><i class="bi bi-person"></i> Usuario</span>
                        <strong id="detailUser">—</strong>
                    </div>
                    <div class="ops-detail-item">
                        <span><i class="bi bi-person-badge"></i> Nombre completo</span>
                        <strong id="detailName">—</strong>
                    </div>
                    <div class="ops-detail-item">
                        <span><i class="bi bi-calendar3"></i> Fecha y hora</span>
                        <strong id="detailDate">—</strong>
                    </div>
                    <div class="ops-detail-item">
                        <span><i class="bi bi-router"></i> Dirección IP</span>
                        <strong class="ops-mono" id="detailIp">—</strong>
                    </div>
                </div>

                <div class="ops-description-card">
                    <span><i class="bi bi-card-text"></i> Descripción registrada</span>
                    <p id="detailDescription">—</p>
                </div>
            <?php endif; ?>
        </article>
    </section>
</main>

<script>
(() => {
    const events = Array.from(document.querySelectorAll('.ops-event'));
    if (!events.length) return;

    const fields = {
       
        badge: document.getElementById('detailBadge'),
        user: document.getElementById('detailUser'),
        name: document.getElementById('detailName'),
        date: document.getElementById('detailDate'),
        ip: document.getElementById('detailIp'),
        description: document.getElementById('detailDescription'),
        technicalAction: document.getElementById('detailTechnicalAction')
    };

    const renderEvent = (button) => {
        let data;
        try {
            data = JSON.parse(button.dataset.event || '{}');
        } catch (error) {
            console.error('No se pudo leer el evento de auditoría.', error);
            return;
        }

        events.forEach(item => item.classList.toggle('is-active', item === button));

        // Solo actualiza la etiqueta del lado derecho
        if (fields.badge) {
            fields.badge.textContent = data.accionEtiqueta || 'Evento';
            fields.badge.className = `ops-status-badge ${data.accionClase || 'info'}`;
        }
        
        if (fields.user) fields.user.textContent = data.usuario || 'No registrado';
        if (fields.name) fields.name.textContent = data.nombre || 'No registrado';
        if (fields.date) fields.date.textContent = data.fecha || 'No registrada';
        if (fields.ip) fields.ip.textContent = data.ip || 'No registrada';
        if (fields.description) fields.description.textContent = data.detalle || 'Sin detalle disponible.';
        if (fields.technicalAction) fields.technicalAction.textContent = data.accion || 'N/A';
    };

    events.forEach(button => button.addEventListener('click', () => renderEvent(button)));
    renderEvent(events[0]);
})();

</script>

<?php require_once __DIR__ . '/../layout_footer.php'; ?>
