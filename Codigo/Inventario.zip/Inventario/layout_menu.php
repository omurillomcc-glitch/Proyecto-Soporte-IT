<?php
require_once __DIR__ . '/usuarios/auth.php';

require_login();

$pagina_actual = basename($_SERVER['PHP_SELF']);
$esAdmin = es_admin();

/*
|--------------------------------------------------------------------------
| RUTA BASE DEL PROYECTO
|--------------------------------------------------------------------------
*/
$baseUrl = '/Inventario';

/*
|--------------------------------------------------------------------------
| EXTRAER DATOS DEL USUARIO LOGUEADO
|--------------------------------------------------------------------------
*/
$nombreUsuario = $_SESSION['nombre_completo'] ?? ($_SESSION['usuario'] ?? 'Usuario');
$rolUsuario    = $_SESSION['rol'] ?? 'Invitado';

// Generar iniciales automáticamente
$palabras  = explode(' ', trim($nombreUsuario));
$iniciales = '';

foreach ($palabras as $p) {
    if (!empty($p)) {
        $iniciales .= strtoupper(substr($p, 0, 1));
    }
}

$iniciales = substr($iniciales, 0, 2);

/*
|--------------------------------------------------------------------------
| AUTORIZADOS PARA USUARIOS Y META MINIMA
|--------------------------------------------------------------------------
|
*/
$admins_autorizados = ['lvalladares', 'jcruz'];

$usuarioSesion = $_SESSION['usuario'] ?? '';

$puede_ver_usuarios =
    $esAdmin &&
    in_array($usuarioSesion, $admins_autorizados, true);

$puede_configurar_metas =
    !empty($_SESSION['puede_configurar_metas']);
?>

<link rel="shortcut icon" type="image/png" href="/Inventario/img/plan.png">
<link rel="stylesheet" href="<?= $baseUrl ?>/menu.css?v=<?= time() ?>">

<div class="app">

<aside class="sidebar" id="sidebar">

    <div class="brand">
        <div class="brand-icon">
            <img src="<?= $baseUrl ?>/img/logo.png" alt="Grupo MCC">
        </div>
        <span class="brand-text"></span>
    </div>

    <div class="menu">

        <div class="menu-title">PRINCIPAL</div>

        <a href="<?= $baseUrl ?>/index.php"
           class="menu-link <?= $pagina_actual === 'index.php' ? 'active' : '' ?>">
            <span class="menu-icon">
                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round"
                     width="18"
                     height="18">
                    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                    <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
            </span>
            <span class="menu-text">Dashboard</span>
        </a>

        <div class="menu-title">CONTROL DE INVENTARIO</div>

        <a href="<?= $baseUrl ?>/plan_inventario/Plan_inventario.php"
           class="menu-link <?= $pagina_actual === 'Plan_inventario.php' ? 'active' : '' ?>">
            <span class="menu-icon">
                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round"
                     width="18"
                     height="18">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                    <line x1="16" y1="2" x2="16" y2="6" />
                    <line x1="8" y1="2" x2="8" y2="6" />
                    <line x1="3" y1="10" x2="21" y2="10" />
                    <polyline points="22 4 12 14.01 9 11.01" />
                </svg>
            </span>
            <span class="menu-text">Inventario por Fecha</span>
        </a>

        <a href="<?= $baseUrl ?>/plan_inventario2/inventario_por_mes.php"
           class="menu-link <?= $pagina_actual === 'inventario_por_mes.php' ? 'active' : '' ?>">
            <span class="menu-icon">
                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round"
                     width="18"
                     height="18">
                    <line x1="18" y1="20" x2="18" y2="10" />
                    <line x1="12" y1="20" x2="12" y2="4" />
                    <line x1="6" y1="20" x2="6" y2="14" />
                    <path d="M3 20h18" />
                </svg>
            </span>
            <span class="menu-text">Inventario por Mes</span>
        </a>

        <a href="<?= $baseUrl ?>/metasinventario/metas.php"
           class="menu-link <?= $pagina_actual === 'metas.php' ? 'active' : '' ?>">
            <span class="menu-icon">
                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round"
                     width="18"
                     height="18">
                    <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/>
                    <polyline points="16 7 22 7 22 13"/>
                </svg>
            </span>
            <span class="menu-text">Metas de Inventario</span>
        </a>

        <a href="<?= $baseUrl ?>/Catalogo/inventariopormeta.php"
           class="menu-link <?= $pagina_actual === 'inventariopormeta.php' ? 'active' : '' ?>">
            <span class="menu-icon">
                <svg viewBox="0 0 24 24"
                     fill="none"
                     stroke="currentColor"
                     stroke-width="2"
                     stroke-linecap="round"
                     stroke-linejoin="round"
                     width="18"
                     height="18">
                    <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
                    <line x1="8" y1="6" x2="16" y2="6"></line>
                    <line x1="16" y1="14" x2="16" y2="18"></line>
                    <path d="M16 10h.01M12 10h.01M8 10h.01M12 14h.01M8 14h.01M12 18h.01M8 18h.01"></path>
                </svg>
            </span>
            <span class="menu-text">Cálculo de Inventario</span>
        </a>

    <?php if ($puede_configurar_metas): ?>

    <div class="menu-title">
        CONFIGURAR METAS
    </div>

    <a
        href="<?= $baseUrl ?>/metasinventario/meta_minima.php"
        class="menu-link <?= $pagina_actual === 'meta_minima.php' ? 'active' : '' ?>"
    >
        <span class="menu-icon">
            <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                width="18"
                height="18"
            >
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3a2 2 0 1 1 4 0v.09A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9c.12.36.33.68.6 1 .3.27.7.4 1.1.4H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51.6z"></path>
            </svg>
        </span>

        <span class="menu-text">
            Meta mínima por tienda
        </span>
    </a>

<?php endif; ?>

        <?php if ($esAdmin): ?>

            <div class="menu-title">ADMINISTRACIÓN</div>

            <?php if ($puede_ver_usuarios): ?>

                <button type="button"
                        id="btnUsuarios"
                        class="menu-dropdown-btn <?= in_array($pagina_actual, ['vista_agregar_usuario.php', 'editar_usuario.php', 'bloquear_usuario.php'], true) ? 'active open' : '' ?>"
                        onclick="toggleSubmenu('submenuUsuarios', 'btnUsuarios')">

                    <span class="menu-icon">
                        <svg viewBox="0 0 16 16"
                             fill="currentColor"
                             width="18"
                             height="18">
                            <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7m.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0m-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4"/>
                            <path d="M8.256 14a4.5 4.5 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10q.39 0 .74.025c.226-.341.496-.65.804-.918Q8.844 9.002 8 9c-5 0-6 3-6 4s1 1 1 1z"/>
                        </svg>
                    </span>

                    <span class="menu-text">
                        Control de Usuarios
                    </span>

                    <span class="menu-arrow">
                        <svg viewBox="0 0 24 24"
                             fill="none"
                             stroke="currentColor"
                             stroke-width="2.5"
                             stroke-linecap="round"
                             stroke-linejoin="round">
                            <path d="m6 9 6 6 6-6"/>
                        </svg>
                    </span>

                </button>

                <div id="submenuUsuarios"
                     class="submenu <?= in_array($pagina_actual, ['vista_agregar_usuario.php', 'editar_usuario.php', 'bloquear_usuario.php'], true) ? 'show' : '' ?>">

                    <a href="<?= $baseUrl ?>/usuarios/vista_agregar_usuario.php"
                       class="submenu-link <?= $pagina_actual === 'vista_agregar_usuario.php' ? 'active-sub' : '' ?>">
                        Crear Usuarios
                    </a>

                    <a href="<?= $baseUrl ?>/usuarios/editar_usuario.php"
                       class="submenu-link <?= $pagina_actual === 'editar_usuario.php' ? 'active-sub' : '' ?>">
                        Editar Usuario
                    </a>

                    <a href="<?= $baseUrl ?>/usuarios/bloquear_usuario.php"
                       class="submenu-link <?= $pagina_actual === 'bloquear_usuario.php' ? 'active-sub' : '' ?>">
                        <p>Desbloquear</p>
                        <p>Bloquear</p>
                    </a>

                </div>

            <?php endif; ?>

            <a href="<?= $baseUrl ?>/auditoria/auditoria.php"
               class="menu-link <?= $pagina_actual === 'auditoria.php' ? 'active' : '' ?>">

                <span class="menu-icon">
                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor"
                         stroke-width="2"
                         stroke-linecap="round"
                         stroke-linejoin="round"
                         width="18"
                         height="18">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                        <polyline points="14 2 14 8 20 8" />
                        <line x1="16" y1="13" x2="8" y2="13" />
                        <line x1="16" y1="17" x2="8" y2="17" />
                        <line x1="10" y1="9" x2="8" y2="9" />
                    </svg>
                </span>

                <span class="menu-text">
                    Auditoría
                </span>

            </a>

        <?php endif; ?>

        <div class="menu-title menu-title-bordered">
            CUENTA
        </div>

        <a href="<?= $baseUrl ?>/usuarios/perfil.php"
           class="menu-link <?= $pagina_actual === 'perfil.php' ? 'active' : '' ?>">

            <span class="menu-icon">
                <svg viewBox="0 0 16 16"
                     fill="currentColor"
                     width="18"
                     height="18">
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
                </svg>
            </span>

            <span class="menu-text">
                Mi Perfil
            </span>

        </a>

        <a href="<?= $baseUrl ?>/usuarios/logout.php"
           class="menu-link logout">

            <span class="menu-icon">
                <svg viewBox="0 0 16 16"
                     fill="currentColor"
                     width="18"
                     height="18">
                    <path fill-rule="evenodd" d="M10 12.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v2a.5.5 0 0 0 1 0v-2A1.5 1.5 0 0 0 9.5 2h-8A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-2a.5.5 0 0 0-1 0z"/>
                    <path fill-rule="evenodd" d="M15.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L14.293 7.5H5.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708z"/>
                </svg>
            </span>

            <span class="menu-text">
                Salir
            </span>

        </a>

        <div class="sidebar-user">
            <div class="sidebar-avatar">
                <?= htmlspecialchars($iniciales) ?>
                <span class="status-dot"></span>
            </div>

            <div class="sidebar-user-info">
                <strong>
                    <?= htmlspecialchars($nombreUsuario) ?>
                </strong>

                <small>
                    <?= htmlspecialchars($rolUsuario) ?>
                </small>
            </div>
        </div>

    </div>

</aside>

<main class="main">

    <div class="topbar">
        <button class="menu-toggle"
                type="button"
                onclick="toggleMenu()">

            <svg viewBox="0 0 24 24"
                 fill="none"
                 stroke="currentColor"
                 stroke-width="2"
                 stroke-linecap="round"
                 stroke-linejoin="round">
                <line x1="4" x2="20" y1="12" y2="12"/>
                <line x1="4" x2="20" y1="6" y2="6"/>
                <line x1="4" x2="20" y1="18" y2="18"/>
            </svg>

        </button>
    </div>

    <div class="content">

<script>
// Manejar Submenús de la barra lateral de forma manual
function toggleSubmenu(submenuId, buttonId) {
    const submenu = document.getElementById(submenuId);
    const button = document.getElementById(buttonId);

    if (submenu && button) {
        submenu.classList.toggle('show');
        button.classList.toggle('open');

        if (submenu.classList.contains('show')) {
            localStorage.setItem('submenuStatus', 'show');
        } else {
            localStorage.setItem('submenuStatus', 'hide');
        }
    }
}

// Colapsar o expandir la barra lateral completa manualmente
function toggleMenu() {
    const sidebar = document.getElementById('sidebar');

    if (!sidebar) {
        return;
    }

    if (window.innerWidth <= 768) {
        sidebar.classList.toggle('open');
    } else {
        sidebar.classList.toggle('collapsed');

        if (sidebar.classList.contains('collapsed')) {
            localStorage.setItem('sidebarStatus', 'collapsed');
        } else {
            localStorage.setItem('sidebarStatus', 'expanded');
        }
    }
}

// Cierre, apertura automática y persistencia de todo el menú
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const submenu = document.getElementById('submenuUsuarios');
    const buttonSubmenu = document.getElementById('btnUsuarios');

    if (!sidebar) {
        return;
    }

    if (window.innerWidth > 768) {
        const savedSidebar = localStorage.getItem('sidebarStatus');
        const savedSubmenu = localStorage.getItem('submenuStatus');

        if (savedSidebar === 'collapsed') {
            sidebar.classList.add('collapsed');
        }

        if (
            savedSubmenu === 'show' &&
            savedSidebar !== 'collapsed' &&
            submenu &&
            buttonSubmenu
        ) {
            submenu.classList.add('show');
            buttonSubmenu.classList.add('open');
        }
    }

    const enlacesMenu =
        sidebar.querySelectorAll('.menu-link, .submenu-link');

    enlacesMenu.forEach(enlace => {
        enlace.addEventListener('click', (e) => {
            if (enlace.classList.contains('logout')) {
                return;
            }

            if (window.innerWidth <= 768) {
                e.preventDefault();

                const urlDestino =
                    enlace.getAttribute('href');

                sidebar.classList.remove('open');

                setTimeout(() => {
                    if (urlDestino) {
                        window.location.href = urlDestino;
                    }
                }, 250);

            } else {
                localStorage.setItem(
                    'sidebarStatus',
                    'collapsed'
                );

                if (
                    !enlace.classList.contains('submenu-link')
                ) {
                    localStorage.setItem(
                        'submenuStatus',
                        'hide'
                    );
                }
            }
        });
    });
});

// Bloquear el menú del clic derecho
document.addEventListener(
    'contextmenu',
    function(e) {
        e.preventDefault();
    }
);

// Bloquear atajos de teclado comunes
document.addEventListener(
    'keydown',
    function(e) {
        // F12
        if (e.keyCode === 123) {
            e.preventDefault();
        }

        // Ctrl + Shift + I / Ctrl + Shift + C
        if (
            e.ctrlKey &&
            e.shiftKey &&
            (
                e.keyCode === 73 ||
                e.keyCode === 67
            )
        ) {
            e.preventDefault();
        }

        // Ctrl + U
        if (
            e.ctrlKey &&
            e.keyCode === 85
        ) {
            e.preventDefault();
        }
    }
);
</script>