-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-09-2026 a las 19:48:15
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `plan_inventario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `usuario` varchar(50) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `accion` varchar(100) NOT NULL,
  `detalle` text NOT NULL,
  `ip` varchar(45) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `meta_minima_configuracion`
--

CREATE TABLE `meta_minima_configuracion` (
  `nombre_regla` varchar(150) NOT NULL,
  `numdpto` int(11) NOT NULL,
  `departamento` varchar(150) NOT NULL,
  `numseccion` int(11) DEFAULT NULL,
  `seccion` varchar(150) DEFAULT NULL,
  `numfamilia` int(11) DEFAULT NULL,
  `familia` varchar(150) DEFAULT NULL,
  `tipo_regla` varchar(10) NOT NULL DEFAULT 'MINIMO',
  `meta_minima` decimal(18,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `usuario_creacion` varchar(100) NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `usuario_modificacion` varchar(100) DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario` varchar(50) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('usuario','admin') NOT NULL DEFAULT 'usuario',
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `intentos` int(11) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_login` datetime DEFAULT NULL,
  `puede_configurar_metas` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario`, `nombre_completo`, `password`, `rol`, `estado`, `intentos`, `creado_en`, `ultimo_login`, `puede_configurar_metas`) VALUES
('jcruz', 'Jessica Cruz', '$2y$10$576r3G6kloKEYle6vWH.CelEuGN9z1qk/kLNAWp1a2x1KoGjZGOS6', 'admin', 1, 0, '2026-07-27 16:22:17', '2026-07-30 16:22:34', 1),
('lvalladares', 'Lina Valladares', '$2y$10$MfDSKx0ywex2dYrTIgpB3OhqBv7Um2nrbofUb2uZpVyt7alYbfBHG', 'admin', 1, 1, '2026-07-17 17:27:39', '2026-08-19 15:27:02', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD KEY `idx_auditoria_fecha` (`fecha`),
  ADD KEY `idx_auditoria_usuario` (`usuario`),
  ADD KEY `idx_auditoria_accion` (`accion`);

--
-- Indices de la tabla `meta_minima_configuracion`
--
ALTER TABLE `meta_minima_configuracion`
  ADD KEY `idx_meta_minima` (`numdpto`,`numseccion`,`numfamilia`,`activo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
