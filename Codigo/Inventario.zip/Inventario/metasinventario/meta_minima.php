<?php
declare(strict_types=1);


session_name('APP_INVENTARIO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../usuarios/auth.php';
require_login();

require_once __DIR__ . '/../usuarios/db.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';

if (
    !isset($conn) ||
    $conn === null ||
    !($conn instanceof mysqli)
) {
    die('No se encontró una conexión válida a MySQL.');
}

if (empty($_SESSION['puede_configurar_metas'])) {
    http_response_code(403);
    exit('No tiene permiso para administrar las metas mínimas.');
}

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| SQL SERVER
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../plan_inventario/conexion_sqlsrv.php';


$sqlsrvConn = null;

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion) {
    $sqlsrvConn = $sqlsrv_conn_exhibicion;
} elseif (isset($sqlsrv_conn) && $sqlsrv_conn) {
    $sqlsrvConn = $sqlsrv_conn;
} elseif (isset($conn_sqlsrv) && $conn_sqlsrv) {
    $sqlsrvConn = $conn_sqlsrv;
} elseif (isset($conexion) && $conexion) {
    $sqlsrvConn = $conexion;
}

if (!$sqlsrvConn) {
    die('No se encontró una conexión válida a SQL Server.');
}

function h($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function registrarAuditoriaMetaMinima(string $accion, string $detalle): void
{
    if (!function_exists('registrar_auditoria')) {
        return;
    }

    try {
        registrar_auditoria($accion, $detalle);
    } catch (Throwable $e) {
        error_log(
            'No se pudo registrar auditoría de Meta mínima: ' .
            $e->getMessage()
        );
    }
}

function obtenerErroresSqlsrv(): string
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);

    if (!$errores) {
        return 'Ocurrió un error desconocido en SQL Server.';
    }

    $mensajes = [];

    foreach ($errores as $error) {
        $mensajes[] =
            '[' . ($error['code'] ?? 'SIN CÓDIGO') . '] ' .
            ($error['message'] ?? 'Error desconocido');
    }

    return implode(' | ', $mensajes);
}

/*
|--------------------------------------------------------------------------
| CALCULO DE INVENTARIO POR TIENDA 
|--------------------------------------------------------------------------
*/
$sqlCatalogo = "
    SELECT
        D.NUMDPTO,
        ISNULL(D.DESCRIPCION, 'SIN DPTO') AS DEPARTAMENTO,
        S.NUMSECCION,
        ISNULL(S.DESCRIPCION, 'SIN SECCION') AS SECCION,
        F.NUMFAMILIA,
        ISNULL(F.DESCRIPCION, 'SIN FAMILIA') AS FAMILIA
    FROM MENDELS.dbo.DEPARTAMENTO AS D
    INNER JOIN MENDELS.dbo.SECCIONES AS S
        ON S.NUMDPTO = D.NUMDPTO
    INNER JOIN MENDELS.dbo.FAMILIAS AS F
        ON F.NUMDPTO = D.NUMDPTO
       AND F.NUMSECCION = S.NUMSECCION
    WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
      AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
      AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL
    ORDER BY
        D.NUMDPTO,
        S.NUMSECCION,
        F.NUMFAMILIA;
";

$stmtCatalogo = sqlsrv_query(
    $sqlsrvConn,
    $sqlCatalogo,
    [],
    ['QueryTimeout' => 0]
);

if ($stmtCatalogo === false) {
    die(obtenerErroresSqlsrv());
}

$catalogo = [];

while ($fila = sqlsrv_fetch_array($stmtCatalogo, SQLSRV_FETCH_ASSOC)) {
    $catalogo[] = [
        'NUMDPTO'      => (int)$fila['NUMDPTO'],
        'DEPARTAMENTO' => trim((string)$fila['DEPARTAMENTO']),
        'NUMSECCION'   => (int)$fila['NUMSECCION'],
        'SECCION'      => trim((string)$fila['SECCION']),
        'NUMFAMILIA'   => (int)$fila['NUMFAMILIA'],
        'FAMILIA'      => trim((string)$fila['FAMILIA']),
    ];
}

sqlsrv_free_stmt($stmtCatalogo);

/*
|--------------------------------------------------------------------------
| GUARDAR / ACTUALIZAR CONFIGURACIÓN EN BASE DE MYSQL
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    try {
        if (empty($_SESSION['puede_configurar_metas'])) {
            throw new Exception('No tiene permiso para modificar configuraciones.');
        }

        $action = trim((string)($_POST['action'] ?? ''));

        if (!in_array($action, ['guardar_configuracion', 'actualizar_configuracion', 'cambiar_estado_configuracion'], true)) {
            throw new Exception('Acción no válida.');
        }

        /*
        |--------------------------------------------------------------------------
        | ACTIVAR / DESACTIVAR CONFIGURACIÓN
        |--------------------------------------------------------------------------
        | No se elimina físicamente. Se conserva para historial y auditoría.
        */
        if ($action === 'cambiar_estado_configuracion') {
            $numDptoEstado = (int)($_POST['numdpto'] ?? 0);
            $numSeccionEstadoRaw = trim((string)($_POST['numseccion'] ?? ''));
            $numFamiliaEstadoRaw = trim((string)($_POST['numfamilia'] ?? ''));
            $nuevoEstado = ((int)($_POST['nuevo_estado'] ?? 0) === 1) ? 1 : 0;

            $numSeccionEstado =
                ($numSeccionEstadoRaw === '')
                    ? null
                    : (int)$numSeccionEstadoRaw;

            $numFamiliaEstado =
                ($numFamiliaEstadoRaw === '')
                    ? null
                    : (int)$numFamiliaEstadoRaw;

            if ($numDptoEstado <= 0) {
                throw new Exception(
                    'No se encontró la configuración seleccionada.'
                );
            }

            $usuarioSesion =
                (string)($_SESSION['usuario'] ?? 'DESCONOCIDO');

            $reglaEstado = 'Configuración';
            $tipoEstado = 'MINIMO';
            $metaEstado = null;
            $departamentoEstado = '';
            $seccionEstado = null;
            $familiaEstado = null;

            $stmtInfoEstado = $conn->prepare("
                SELECT
                    nombre_regla,
                    tipo_regla,
                    meta_minima,
                    departamento,
                    seccion,
                    familia
                FROM meta_minima_configuracion
                WHERE numdpto = ?
                  AND numseccion <=> ?
                  AND numfamilia <=> ?
                LIMIT 1
            ");

            if ($stmtInfoEstado) {
                $stmtInfoEstado->bind_param(
                    'iii',
                    $numDptoEstado,
                    $numSeccionEstado,
                    $numFamiliaEstado
                );

                $stmtInfoEstado->execute();
                $stmtInfoEstado->bind_result(
                    $reglaEstadoDb,
                    $tipoEstadoDb,
                    $metaEstadoDb,
                    $departamentoEstadoDb,
                    $seccionEstadoDb,
                    $familiaEstadoDb
                );

                if ($stmtInfoEstado->fetch()) {
                    $reglaEstado = (string)$reglaEstadoDb;
                    $tipoEstado = strtoupper((string)$tipoEstadoDb);
                    $metaEstado = (float)$metaEstadoDb;
                    $departamentoEstado = (string)$departamentoEstadoDb;
                    $seccionEstado = $seccionEstadoDb;
                    $familiaEstado = $familiaEstadoDb;
                }

                $stmtInfoEstado->close();
            }

            $stmtEstado = $conn->prepare("
                UPDATE meta_minima_configuracion
                SET
                    activo = ?,
                    usuario_modificacion = ?,
                    fecha_modificacion = NOW()
                WHERE numdpto = ?
                  AND numseccion <=> ?
                  AND numfamilia <=> ?
                LIMIT 1
            ");

            if (!$stmtEstado) {
                throw new Exception(
                    'Error preparando el cambio de estado: ' .
                    $conn->error
                );
            }

            $stmtEstado->bind_param(
                'isiii',
                $nuevoEstado,
                $usuarioSesion,
                $numDptoEstado,
                $numSeccionEstado,
                $numFamiliaEstado
            );

            if (!$stmtEstado->execute()) {
                $mensaje = $stmtEstado->error;
                $stmtEstado->close();

                throw new Exception(
                    'No se pudo cambiar el estado: ' .
                    $mensaje
                );
            }

            if ($stmtEstado->affected_rows < 1) {
                $stmtEstado->close();

                throw new Exception(
                    'No se encontró la configuración o ya tenía ese estado.'
                );
            }

            $stmtEstado->close();

            registrarAuditoriaMetaMinima(
                $nuevoEstado === 1
                    ? 'META_MINIMA_ACTIVADA'
                    : 'META_MINIMA_DESACTIVADA',
                sprintf(
                    "Regla: %s\n" .
                    "Departamento: %s\n" .
                    "Sección: %s\n" .
                    "Familia: %s\n" .
                    "Tipo de regla: %s\n" .
                    "Valor de regla: %s\n" .
                    "Usuario: %s\n" .
                    "Resultado: La regla fue %s.",
                    $reglaEstado,
                    $departamentoEstado !== '' ? $departamentoEstado : 'N/D',
                    $seccionEstado ?: 'Todas',
                    $familiaEstado ?: 'Todas',
                    $tipoEstado === 'MAXIMO' ? 'Máximo' : 'Mínimo',
                    $metaEstado === null ? 'N/D' : number_format($metaEstado, 2),
                    $usuarioSesion,
                    $nuevoEstado === 1 ? 'activada' : 'desactivada'
                )
            );

            echo json_encode([
                'ok' => true,
                'msg' => $nuevoEstado === 1
                    ? 'La configuración fue activada correctamente.'
                    : 'La configuración fue desactivada correctamente.'
            ], JSON_UNESCAPED_UNICODE);

            exit;
        }

        $nombreRegla   = trim((string)($_POST['nombre_regla'] ?? ''));
        $numDpto       = (int)($_POST['numdpto'] ?? 0);
        $numSeccionRaw = trim((string)($_POST['numseccion'] ?? ''));
        $numFamiliaRaw = trim((string)($_POST['numfamilia'] ?? ''));
        $tipoRegla     = strtoupper(trim((string)($_POST['tipo_regla'] ?? 'MINIMO')));
        $metaMinimaRaw = trim((string)($_POST['meta_minima'] ?? ''));
        $activo        = ((int)($_POST['activo'] ?? 1) === 1) ? 1 : 0;

        if ($nombreRegla === '') {
            throw new Exception('Debe ingresar el nombre de la regla.');
        }

        if ($numDpto <= 0) {
            throw new Exception('Debe seleccionar un departamento.');
        }

        if (!in_array($tipoRegla, ['MINIMO', 'MAXIMO'], true)) {
            throw new Exception('El tipo de regla seleccionado no es válido.');
        }

        if ($metaMinimaRaw === '' || !is_numeric($metaMinimaRaw)) {
            throw new Exception('Debe ingresar un valor de regla válido.');
        }

        $metaMinima = (float)$metaMinimaRaw;

        if ($metaMinima < 0) {
            throw new Exception('El valor de la regla no puede ser negativo.');
        }

        $numSeccion = ($numSeccionRaw === '') ? null : (int)$numSeccionRaw;
        $numFamilia = ($numFamiliaRaw === '') ? null : (int)$numFamiliaRaw;

        if ($numFamilia !== null && $numSeccion === null) {
            throw new Exception('Para seleccionar una familia primero debe seleccionar una sección.');
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDAR CÓDIGOS Y OBTENER DESCRIPCIONES DESDE ICG
        |--------------------------------------------------------------------------
        */
        $departamento = null;
        $seccion = null;
        $familia = null;

        foreach ($catalogo as $filaCatalogo) {
            if ((int)$filaCatalogo['NUMDPTO'] !== $numDpto) {
                continue;
            }

            if ($departamento === null) {
                $departamento = $filaCatalogo['DEPARTAMENTO'];
            }

            if (
                $numSeccion !== null &&
                (int)$filaCatalogo['NUMSECCION'] === $numSeccion
            ) {
                $seccion = $filaCatalogo['SECCION'];

                if (
                    $numFamilia !== null &&
                    (int)$filaCatalogo['NUMFAMILIA'] === $numFamilia
                ) {
                    $familia = $filaCatalogo['FAMILIA'];
                }
            }
        }

        if ($departamento === null) {
            throw new Exception('El departamento seleccionado no existe en ICG.');
        }

        if ($numSeccion !== null && $seccion === null) {
            throw new Exception('La sección seleccionada no pertenece al departamento.');
        }

        if ($numFamilia !== null && $familia === null) {
            throw new Exception('La familia seleccionada no pertenece a la sección.');
        }

        $usuarioSesion = (string)($_SESSION['usuario'] ?? 'DESCONOCIDO');

        /*
        |--------------------------------------------------------------------------
        | CREAR REGLA DE CONFIGURACION
        |--------------------------------------------------------------------------
        */
        if ($action === 'guardar_configuracion') {
            $stmtExiste = $conn->prepare("
                SELECT nombre_regla
                FROM meta_minima_configuracion
                WHERE numdpto = ?
                  AND numseccion <=> ?
                  AND numfamilia <=> ?
                LIMIT 1
            ");

            if (!$stmtExiste) {
                throw new Exception('Error preparando validación: ' . $conn->error);
            }

            $stmtExiste->bind_param('iii', $numDpto, $numSeccion, $numFamilia);
            $stmtExiste->execute();
            $stmtExiste->store_result();

            if ($stmtExiste->num_rows > 0) {
                $stmtExiste->close();
                throw new Exception(
                    'Ya existe una configuración para ese Departamento, Sección y Familia.'
                );
            }

            $stmtExiste->close();

            $stmt = $conn->prepare("
                INSERT INTO meta_minima_configuracion (
                    nombre_regla,
                    numdpto,
                    departamento,
                    numseccion,
                    seccion,
                    numfamilia,
                    familia,
                    tipo_regla,
                    meta_minima,
                    activo,
                    usuario_creacion,
                    fecha_creacion
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            if (!$stmt) {
                throw new Exception('Error preparando el guardado: ' . $conn->error);
            }

            $stmt->bind_param(
                'sisissssdis',
                $nombreRegla,
                $numDpto,
                $departamento,
                $numSeccion,
                $seccion,
                $numFamilia,
                $familia,
                $tipoRegla,
                $metaMinima,
                $activo,
                $usuarioSesion
            );

            if (!$stmt->execute()) {
                $mensaje = $stmt->error;
                $stmt->close();
                throw new Exception('No se pudo guardar: ' . $mensaje);
            }

            $stmt->close();

            registrarAuditoriaMetaMinima(
                'META_MINIMA_CREADA',
                sprintf(
                    "Regla: %s\n" .
                    "Departamento: %s\n" .
                    "Sección: %s\n" .
                    "Familia: %s\n" .
                    "Tipo de regla: %s\n" .
                    "Valor de regla: %s\n" .
                    "Estado: %s\n" .
                    "Creada por: %s\n" .
                    "Resultado: La regla de meta por tienda fue creada correctamente.",
                    $nombreRegla,
                    $departamento,
                    $seccion ?: 'Todas',
                    $familia ?: 'Todas',
                    $tipoRegla === 'MAXIMO' ? 'Máximo' : 'Mínimo',
                    number_format($metaMinima, 2),
                    $activo === 1 ? 'Activo' : 'Inactivo',
                    $usuarioSesion
                )
            );

            echo json_encode([
                'ok' => true,
                'msg' => 'La configuración se guardó correctamente.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

       
        $origDpto = (int)($_POST['original_numdpto'] ?? 0);
        $origSeccionRaw = trim((string)($_POST['original_numseccion'] ?? ''));
        $origFamiliaRaw = trim((string)($_POST['original_numfamilia'] ?? ''));

        $origSeccion = ($origSeccionRaw === '') ? null : (int)$origSeccionRaw;
        $origFamilia = ($origFamiliaRaw === '') ? null : (int)$origFamiliaRaw;

        if ($origDpto <= 0) {
            throw new Exception('No se encontró la configuración original para editar.');
        }

        $stmtDuplicado = $conn->prepare("
            SELECT nombre_regla
            FROM meta_minima_configuracion
            WHERE numdpto = ?
              AND numseccion <=> ?
              AND numfamilia <=> ?
              AND NOT (
                    numdpto = ?
                AND numseccion <=> ?
                AND numfamilia <=> ?
              )
            LIMIT 1
        ");

        if (!$stmtDuplicado) {
            throw new Exception('Error validando la actualización: ' . $conn->error);
        }

        $stmtDuplicado->bind_param(
            'iiiiii',
            $numDpto,
            $numSeccion,
            $numFamilia,
            $origDpto,
            $origSeccion,
            $origFamilia
        );

        $stmtDuplicado->execute();
        $stmtDuplicado->store_result();

        if ($stmtDuplicado->num_rows > 0) {
            $stmtDuplicado->close();
            throw new Exception(
                'Ya existe otra configuración con ese Departamento, Sección y Familia.'
            );
        }

        $stmtDuplicado->close();

        $reglaAnterior = '';
        $tipoAnterior = null;
        $metaAnterior = null;
        $estadoAnterior = null;

        $stmtAnterior = $conn->prepare("
            SELECT
                nombre_regla,
                tipo_regla,
                meta_minima,
                activo
            FROM meta_minima_configuracion
            WHERE numdpto = ?
              AND numseccion <=> ?
              AND numfamilia <=> ?
            LIMIT 1
        ");

        if ($stmtAnterior) {
            $stmtAnterior->bind_param(
                'iii',
                $origDpto,
                $origSeccion,
                $origFamilia
            );

            $stmtAnterior->execute();
            $stmtAnterior->bind_result(
                $reglaAnteriorDb,
                $tipoAnteriorDb,
                $metaAnteriorDb,
                $estadoAnteriorDb
            );

            if ($stmtAnterior->fetch()) {
                $reglaAnterior = (string)$reglaAnteriorDb;
                $tipoAnterior = strtoupper((string)$tipoAnteriorDb);
                $metaAnterior = (float)$metaAnteriorDb;
                $estadoAnterior = (int)$estadoAnteriorDb;
            }

            $stmtAnterior->close();
        }

        $stmt = $conn->prepare("
            UPDATE meta_minima_configuracion
            SET
                nombre_regla = ?,
                numdpto = ?,
                departamento = ?,
                numseccion = ?,
                seccion = ?,
                numfamilia = ?,
                familia = ?,
                tipo_regla = ?,
                meta_minima = ?,
                activo = ?,
                usuario_modificacion = ?,
                fecha_modificacion = NOW()
            WHERE numdpto = ?
              AND numseccion <=> ?
              AND numfamilia <=> ?
            LIMIT 1
        ");

        if (!$stmt) {
            throw new Exception('Error preparando la actualización: ' . $conn->error);
        }

        $stmt->bind_param(
            'sisissssdisiii',
            $nombreRegla,
            $numDpto,
            $departamento,
            $numSeccion,
            $seccion,
            $numFamilia,
            $familia,
            $tipoRegla,
            $metaMinima,
            $activo,
            $usuarioSesion,
            $origDpto,
            $origSeccion,
            $origFamilia
        );

        if (!$stmt->execute()) {
            $mensaje = $stmt->error;
            $stmt->close();
            throw new Exception('No se pudo actualizar: ' . $mensaje);
        }

        if ($stmt->affected_rows < 1) {
            $stmt->close();
            throw new Exception('No se encontró la configuración que intenta actualizar.');
        }

        $stmt->close();

        registrarAuditoriaMetaMinima(
            'META_MINIMA_ACTUALIZADA',
            sprintf(
                "Regla anterior: %s\n" .
                "Regla actual: %s\n" .
                "Departamento: %s\n" .
                "Sección: %s\n" .
                "Familia: %s\n" .
                "Tipo anterior: %s\n" .
                "Tipo actual: %s\n" .
                "Valor anterior: %s\n" .
                "Valor actual: %s\n" .
                "Estado anterior: %s\n" .
                "Estado actual: %s\n" .
                "Modificada por: %s\n" .
                "Resultado: La regla de meta por tienda fue actualizada correctamente.",
                $reglaAnterior !== '' ? $reglaAnterior : $nombreRegla,
                $nombreRegla,
                $departamento,
                $seccion ?: 'Todas',
                $familia ?: 'Todas',
                $tipoAnterior === null
                    ? 'N/D'
                    : ($tipoAnterior === 'MAXIMO' ? 'Máximo' : 'Mínimo'),
                $tipoRegla === 'MAXIMO' ? 'Máximo' : 'Mínimo',
                $metaAnterior === null ? 'N/D' : number_format($metaAnterior, 2),
                number_format($metaMinima, 2),
                $estadoAnterior === null
                    ? 'N/D'
                    : ($estadoAnterior === 1 ? 'Activo' : 'Inactivo'),
                $activo === 1 ? 'Activo' : 'Inactivo',
                $usuarioSesion
            )
        );

        echo json_encode([
            'ok' => true,
            'msg' => 'La configuración se actualizó correctamente.'
        ], JSON_UNESCAPED_UNICODE);

    } catch (Throwable $e) {
        http_response_code(400);

        echo json_encode([
            'ok' => false,
            'msg' => $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| PAGINACIÓN DE CONFIGURACIONES GUARDADAS
|--------------------------------------------------------------------------
| Diseño por tarjetas:
|  6 = 2 filas
|  9 = 3 filas (predeterminado)
| 12 = 4 filas
|--------------------------------------------------------------------------
*/
$opcionesPorPagina = [100, 200, 500];

$porPagina = (int)($_GET['por_pagina'] ?? 100);

if (!in_array($porPagina, $opcionesPorPagina, true)) {
    $porPagina = 100;
}

$pagina = max(
    1,
    (int)($_GET['pagina'] ?? 1)
);

/*
|--------------------------------------------------------------------------
| TOTAL DE REGLAS
|--------------------------------------------------------------------------
*/
$totalConfiguraciones = 0;

$resultadoTotal = $conn->query("
    SELECT COUNT(*) AS total
    FROM meta_minima_configuracion
");

if ($resultadoTotal) {
    $filaTotal = $resultadoTotal->fetch_assoc();

    $totalConfiguraciones =
        (int)($filaTotal['total'] ?? 0);

    $resultadoTotal->free();
}

$totalPaginas = max(
    1,
    (int)ceil(
        $totalConfiguraciones /
        $porPagina
    )
);

if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}

$offset =
    ($pagina - 1) *
    $porPagina;

/*
|--------------------------------------------------------------------------
| LISTAR SOLO LA PÁGINA ACTUAL
|--------------------------------------------------------------------------
*/
$configuraciones = [];

$sqlConfiguraciones = "
    SELECT
        nombre_regla,
        numdpto,
        departamento,
        numseccion,
        seccion,
        numfamilia,
        familia,
        tipo_regla,
        meta_minima,
        activo,
        usuario_creacion,
        fecha_creacion,
        usuario_modificacion,
        fecha_modificacion
    FROM meta_minima_configuracion
    ORDER BY
        numdpto,
        CASE
            WHEN numseccion IS NULL
            THEN -1
            ELSE numseccion
        END,
        CASE
            WHEN numfamilia IS NULL
            THEN -1
            ELSE numfamilia
        END,
        nombre_regla
    LIMIT {$porPagina}
    OFFSET {$offset}
";

$resultadoConfig =
    $conn->query(
        $sqlConfiguraciones
    );

if ($resultadoConfig) {
    while (
        $filaConfig =
            $resultadoConfig->fetch_assoc()
    ) {
        $configuraciones[] =
            $filaConfig;
    }

    $resultadoConfig->free();
}

/*
|--------------------------------------------------------------------------
| RANGO MOSTRADO
|--------------------------------------------------------------------------
*/
$registroDesde =
    $totalConfiguraciones > 0
        ? $offset + 1
        : 0;

$registroHasta =
    min(
        $offset + count($configuraciones),
        $totalConfiguraciones
    );

/*
|--------------------------------------------------------------------------
| URL DE PAGINACIÓN
|--------------------------------------------------------------------------
*/
function urlMetaMinimaPagina(
    int $paginaDestino,
    int $porPaginaDestino
): string {
    $parametros = $_GET;

    $parametros['pagina'] =
        max(1, $paginaDestino);

    $parametros['por_pagina'] =
        $porPaginaDestino;

    return '?' .
        http_build_query(
            $parametros
        );
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">

    <title>Reglas de meta por tienda</title>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

	<link rel="shortcut icon" type="image/png" href="/Inventario/img/plan.png">
    <link
        rel="stylesheet"
        href="/Inventario/metasinventario/minima.css?v=<?= time() ?>"
    >
</head>

<body>

<?php
require_once __DIR__ . '/../layout_menu.php';
?>

<div class="minmeta-page">

    <section
        id="panelNuevaRegla"
        class="rule-panel"
    >

        <header class="rule-panel-head">
            <h2>
                <i class=""></i>
                
            </h2>

            <span class="rule-panel-note">
                Configuración.
            </span>
        </header>

        <div class="rule-panel-body">

            <div
                id="alertaLocal"
                class="alert alerta-local"
                role="alert"
            ></div>

            <form
                id="formMetaMinima"
                autocomplete="off"
            >

                <input
                    type="hidden"
                    id="modoFormulario"
                    value="crear"
                >

                <input
                    type="hidden"
                    id="originalNumDpto"
                    name="original_numdpto"
                    value=""
                >

                <input
                    type="hidden"
                    id="originalNumSeccion"
                    name="original_numseccion"
                    value=""
                >

                <input
                    type="hidden"
                    id="originalNumFamilia"
                    name="original_numfamilia"
                    value=""
                >

                <div class="row g-3">

                    <!-- Nombre -->
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="nombreRegla"
                            class="field-label"
                        >
                            Nombre de la regla
                        </label>

                        <input
                            type="text"
                            id="nombreRegla"
                            name="nombre_regla"
                            class="form-control minmeta-control"
                            maxlength="150"
                            placeholder="Ej. Vestuario completo"
                            required
                        >

                        <small class="field-caption">
                            Identifique el nombre de la regla a guardar.
                        </small>
                    </div>

                    <!-- Departamento -->
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="departamento"
                            class="field-label"
                        >
                            Departamento
                        </label>

                        <select
                            id="departamento"
                            name="numdpto"
                            class="form-select minmeta-control"
                            required
                        >
                            <option value="">
                                Seleccione un departamento
                            </option>
                        </select>

                        <small class="field-caption">
                            Código y nombre.
                        </small>
                    </div>

                    <!-- Sección -->
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="seccion"
                            class="field-label"
                        >
                            Sección
                        </label>

                        <select
                            id="seccion"
                            name="numseccion"
                            class="form-select minmeta-control"
                            disabled
                        >
                            <option value="">
                                Todas las secciones
                            </option>
                        </select>

                        <small class="field-caption">
                            “Todas” aplica al departamento completo.
                        </small>
                    </div>

                    
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="familia"
                            class="field-label"
                        >
                            Familia
                        </label>

                        <select
                            id="familia"
                            name="numfamilia"
                            class="form-select minmeta-control"
                            disabled
                        >
                            <option value="">
                                Todas las familias
                            </option>
                        </select>

                        <small class="field-caption">
                            “Todas” aplica a la sección completa.
                        </small>
                    </div>

                    <!-- Tipo de regla -->
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label for="tipoRegla" class="field-label">
                            Tipo de regla
                        </label>

                        <select
                            id="tipoRegla"
                            name="tipo_regla"
                            class="form-select minmeta-control"
                            required
                        >
                            <option value="MINIMO" selected>Mínimo</option>
                            <option value="MAXIMO">Máximo</option>
                        </select>

                        <small class="field-caption">
                            Mínimo sube valores bajos; máximo limita valores altos.
                        </small>
                    </div>

                    <!-- Valor de la regla -->
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="metaMinima"
                            id="labelValorRegla"
                            class="field-label"
                        >
                            Meta mínima
                        </label>

                        <input
                            type="number"
                            id="metaMinima"
                            name="meta_minima"
                            class="form-control minmeta-control"
                            min="0"
                            step="0.01"
                            placeholder="0.00"
                            required
                        >

                        <small id="captionValorRegla" class="field-caption">
                           Valor mínimo que se guardará si ingresan menos.
                        </small>
                    </div>

                
                    <div class="col-12 col-md-6 col-xl-4 col-xxl-2">
                        <label
                            for="estado"
                            class="field-label"
                        >
                            Estado
                        </label>

                        <select
                            id="estado"
                            name="activo"
                            class="form-select minmeta-control"
                        >
                            <option value="1" selected>
                                Activo
                            </option>

                            <option value="0">
                                Inactivo
                            </option>
                        </select>

                        <small class="field-caption">
                            Una regla inactiva no afecta el cálculo de inventario.
                        </small>
                    </div>

                </div>


                <!-- Alcance -->
                <div class="rule-scope">

                    <div class="scope-icon">
                        <i class="bi bi-info-lg"></i>
                    </div>

                    <div class="scope-copy">
                        <strong>Alcance de la regla</strong>

                        <p id="textoAlcance">
                            Seleccione un departamento para visualizar el alcance.
                        </p>
                    </div>

                    <div class="scope-value">
                        <small id="labelResumenRegla">Meta mínima</small>

                        <strong id="valorMinimoResumen">
                            —
                        </strong>
                    </div>

                </div>

                <div class="rule-priority">
                    <!--<i class="bi bi-diagram-3"></i>-->

                   <!-- <span>
                        Prioridad:
                        Familia específica →
                        Sección completa →
                        Departamento completo.
                        La regla más específica reemplaza a la general.
                    </span>-->
                </div>


                <!-- Acciones -->
                <div class="rule-actions">

                    <button
                        type="button"
                        id="btnLimpiar"
                        class="btn-rule-clear"
                    >
                        <i class="bi bi-eraser"></i>
                        Limpiar
                    </button>

                    <button
                        type="submit"
                        id="btnGuardar"
                        class="btn-rule-save"
                    >
                        <i class="bi bi-floppy"></i>
                        Guardar
                    </button>

                </div>

            </form>

        </div>

    </section>

    <section>

        <div class="saved-header">

            <div>
                <h2>
                    Historial
                </h2>

                <p>
                    Los cambios de creación, edición, activación y desactivación se registran en Auditoría.
                </p>
            </div>

            <div class="saved-count">
                <i class="bi bi-collection"></i>

                <?= number_format($totalConfiguraciones) ?>
                <?= $totalConfiguraciones === 1 ? 'regla' : 'reglas' ?>
            </div>

        </div>


        <div class="rules-grid">

            <?php if (empty($configuraciones)): ?>

                <div class="rules-empty">
                    <i class="bi bi-inbox"></i>

                    <strong>
                        No hay configuraciones guardadas
                    </strong>

                    <span>
                        Cree la primera regla utilizando el formulario superior.
                    </span>
                </div>

            <?php else: ?>

                <?php foreach ($configuraciones as $config): ?>

                    <?php
                        $datosEditar = [
                            'nombre_regla' => $config['nombre_regla'],

                            'numdpto' =>
                                (string)$config['numdpto'],

                            'numseccion' =>
                                $config['numseccion'] === null
                                    ? ''
                                    : (string)$config['numseccion'],

                            'numfamilia' =>
                                $config['numfamilia'] === null
                                    ? ''
                                    : (string)$config['numfamilia'],

                            'tipo_regla' =>
                                strtoupper((string)($config['tipo_regla'] ?? 'MINIMO')),

                            'meta_minima' =>
                                (string)$config['meta_minima'],

                            'activo' =>
                                (string)$config['activo'],
                        ];

                        $jsonEditar = htmlspecialchars(
                            json_encode(
                                $datosEditar,
                                JSON_UNESCAPED_UNICODE |
                                JSON_UNESCAPED_SLASHES
                            ),
                            ENT_QUOTES,
                            'UTF-8'
                        );

                        $estaActiva =
                            (int)$config['activo'] === 1;

                        $tipoReglaConfig =
                            strtoupper((string)($config['tipo_regla'] ?? 'MINIMO'));

                        $esMaximo =
                            $tipoReglaConfig === 'MAXIMO';
                    ?>

                    <article
                        class="rule-card <?= $estaActiva ? '' : 'is-inactive' ?>"
                    >

                        <div class="rule-card-head">

                            <div class="rule-card-title">
                                <h3>
                                    <?= h($config['nombre_regla']) ?>
                                </h3>

                                <span>
                                    Regla de <?= $esMaximo ? 'máximo' : 'mínimo' ?> por tienda
                                </span>
                            </div>

                            <span class="rule-card-menu">
                                <i class="bi bi-three-dots-vertical"></i>
                            </span>

                        </div>


                        <div class="rule-card-body">

                            <dl class="rule-detail-grid">

                                <dt>Departamento</dt>
                                <dd>
                                    <?= h($config['numdpto']) ?>
                                    <?= h($config['departamento']) ?>
                                </dd>

                                <dt>Sección</dt>
                                <dd>
                                    <?php if ($config['numseccion'] === null): ?>
                                        Todas las secciones
                                    <?php else: ?>
                                        <?= h($config['numseccion']) ?>
                                        <?= h($config['seccion']) ?>
                                    <?php endif; ?>
                                </dd>

                                <dt>Familia</dt>
                                <dd>
                                    <?php if ($config['numfamilia'] === null): ?>
                                        Todas las familias
                                    <?php else: ?>
                                        <?= h($config['numfamilia']) ?>
                                        <?= h($config['familia']) ?>
                                    <?php endif; ?>
                                </dd>

                                <dt>Tipo de regla</dt>
                                <dd>
                                    <span class="rule-type-badge <?= $esMaximo ? 'maximum' : 'minimum' ?>">
                                        <i class="bi <?= $esMaximo ? 'bi-arrow-down-circle' : 'bi-arrow-up-circle' ?>"></i>
                                        <?= $esMaximo ? 'Máximo' : 'Mínimo' ?>
                                    </span>
                                </dd>

                            </dl>


                            <div class="rule-meta-row">

                                <div class="rule-meta-value">
                                    <small>
                                        <?= $esMaximo ? 'Meta máxima' : 'Meta mínima' ?>
                                    </small>

                                    <strong>
                                        <?= h(
                                            number_format(
                                                (float)$config['meta_minima'],
                                                2
                                            )
                                        ) ?>
                                    </strong>
                                </div>


                                <?php if ($estaActiva): ?>

                                    <span class="rule-status active">
                                        <i class="bi bi-check-circle-fill"></i>
                                        Activo
                                    </span>

                                <?php else: ?>

                                    <span class="rule-status inactive">
                                        <i class="bi bi-pause-circle-fill"></i>
                                        Inactivo
                                    </span>

                                <?php endif; ?>

                            </div>

                        </div>


                        <div class="rule-card-actions">

                            <button
                                type="button"
                                class="card-action edit btn-editar-config"
                                data-config="<?= $jsonEditar ?>"
                                title="Editar configuración"
                            >
                                <i class="bi bi-pencil-square"></i>
                                Editar
                            </button>


                            <button
                                type="button"
                                class="card-action <?= $estaActiva ? 'deactivate' : 'activate' ?> btn-estado-config"
                                data-numdpto="<?= h($config['numdpto']) ?>"
                                data-numseccion="<?= h(
                                    $config['numseccion'] === null
                                        ? ''
                                        : $config['numseccion']
                                ) ?>"
                                data-numfamilia="<?= h(
                                    $config['numfamilia'] === null
                                        ? ''
                                        : $config['numfamilia']
                                ) ?>"
                                data-nuevo-estado="<?= $estaActiva ? '0' : '1' ?>"
                                data-nombre="<?= h($config['nombre_regla']) ?>"
                                title="<?= $estaActiva
                                    ? 'Desactivar configuración'
                                    : 'Activar configuración'
                                ?>"
                            >
                                <i class="bi <?= $estaActiva
                                    ? 'bi-power'
                                    : 'bi-play-circle'
                                ?>"></i>

                                <?= $estaActiva
                                    ? 'Desactivar'
                                    : 'Activar'
                                ?>
                            </button>

                        </div>

                    </article>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

        <?php if ($totalConfiguraciones > 0): ?>

            <div class="rules-pagination">

                <div class="pagination-summary">
                    Mostrando
                    <strong>
                        <?= number_format($registroDesde) ?>
                    </strong>
                    –
                    <strong>
                        <?= number_format($registroHasta) ?>
                    </strong>
                    de
                    <strong>
                        <?= number_format($totalConfiguraciones) ?>
                    </strong>
                    reglas
                </div>


                <div class="pagination-controls">

                    <form
                        method="get"
                        id="formPorPagina"
                    >
                        <input
                            type="hidden"
                            name="pagina"
                            value="1"
                        >

                        <select
                            name="por_pagina"
                            id="selectPorPagina"
                            class="form-select per-page-control"
                            aria-label="Reglas por página"
                        >
                            <?php foreach ($opcionesPorPagina as $opcionPagina): ?>

                                <option
                                    value="<?= $opcionPagina ?>"
                                    <?= $porPagina === $opcionPagina ? 'selected' : '' ?>
                                >
                                    <?= $opcionPagina ?> por página
                                </option>

                            <?php endforeach; ?>
                        </select>
                    </form>


                    <div class="page-buttons">

                        <!-- Primera página -->
                        <a
                            href="<?= h(urlMetaMinimaPagina(1, $porPagina)) ?>"
                            class="page-link-corp <?= $pagina <= 1 ? 'is-disabled' : '' ?>"
                            title="Primera página"
                        >
                            <i class="bi bi-chevron-double-left"></i>
                        </a>

                        <!-- Anterior -->
                        <a
                            href="<?= h(urlMetaMinimaPagina($pagina - 1, $porPagina)) ?>"
                            class="page-link-corp <?= $pagina <= 1 ? 'is-disabled' : '' ?>"
                            title="Página anterior"
                        >
                            <i class="bi bi-chevron-left"></i>
                        </a>


                        <?php
                            $inicioPaginacion =
                                max(
                                    1,
                                    $pagina - 2
                                );

                            $finPaginacion =
                                min(
                                    $totalPaginas,
                                    $pagina + 2
                                );

                            if (
                                ($finPaginacion - $inicioPaginacion) < 4
                            ) {
                                if ($inicioPaginacion === 1) {
                                    $finPaginacion =
                                        min(
                                            $totalPaginas,
                                            5
                                        );
                                } elseif (
                                    $finPaginacion === $totalPaginas
                                ) {
                                    $inicioPaginacion =
                                        max(
                                            1,
                                            $totalPaginas - 4
                                        );
                                }
                            }
                        ?>

                        <?php for (
                            $numeroPagina = $inicioPaginacion;
                            $numeroPagina <= $finPaginacion;
                            $numeroPagina++
                        ): ?>

                            <?php if ($numeroPagina === $pagina): ?>

                                <span class="page-current-corp">
                                    <?= $numeroPagina ?>
                                </span>

                            <?php else: ?>

                                <a
                                    href="<?= h(urlMetaMinimaPagina($numeroPagina, $porPagina)) ?>"
                                    class="page-link-corp"
                                >
                                    <?= $numeroPagina ?>
                                </a>

                            <?php endif; ?>

                        <?php endfor; ?>


                        <!-- Siguiente -->
                        <a
                            href="<?= h(urlMetaMinimaPagina($pagina + 1, $porPagina)) ?>"
                            class="page-link-corp <?= $pagina >= $totalPaginas ? 'is-disabled' : '' ?>"
                            title="Página siguiente"
                        >
                            <i class="bi bi-chevron-right"></i>
                        </a>

                        <!-- Última -->
                        <a
                            href="<?= h(urlMetaMinimaPagina($totalPaginas, $porPagina)) ?>"
                            class="page-link-corp <?= $pagina >= $totalPaginas ? 'is-disabled' : '' ?>"
                            title="Última página"
                        >
                            <i class="bi bi-chevron-double-right"></i>
                        </a>

                    </div>

                </div>

            </div>

        <?php endif; ?>

    </section>

</div>

<script>
window.META_MINIMA_CATALOGO = <?= json_encode(
    $catalogo,
    JSON_UNESCAPED_UNICODE |
    JSON_UNESCAPED_SLASHES |
    JSON_INVALID_UTF8_SUBSTITUTE
) ?>;
</script>

<script
    src="/Inventario/metasinventario/minima.js?v=<?= time() ?>"
></script>

<?php
require_once __DIR__ . '/../layout_footer.php';
?>

</body>
</html>