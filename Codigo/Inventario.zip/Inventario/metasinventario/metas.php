<?php
declare(strict_types=1);


session_name('APP_INVENTARIO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../usuarios/auth.php';

require_login();

/*
|--------------------------------------------------------------------------
| 2. CONFIGURACIÓN
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');


require_once __DIR__ . '/../plan_inventario/conexion_sqlsrv.php';

require_once  __DIR__  . '/../auditoria/auditoria_helper.php';


/*
|--------------------------------------------------------------------------
| 4. DETECTAR VARIABLE DE CONEXIÓN
|--------------------------------------------------------------------------
*/
$sqlsrvConn = null;

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion) {
    $sqlsrvConn = $sqlsrv_conn_exhibicion;
} elseif (isset($sqlsrv_conn) && $sqlsrv_conn) {
    $sqlsrvConn = $sqlsrv_conn;
} elseif (isset($conn_sqlsrv) && $conn_sqlsrv) {
    $sqlsrvConn = $conn_sqlsrv;
} elseif (isset($conn) && $conn) {
    $sqlsrvConn = $conn;
} elseif (isset($conexion) && $conexion) {
    $sqlsrvConn = $conexion;
}


require_once __DIR__ . '/../usuarios/db.php';

if (
    !isset($conn) ||
    $conn === null ||
    !($conn instanceof mysqli)
) {
    die('No se encontró una conexión válida a MySQL.');
}

$mysqlConn = $conn;

/*
|--------------------------------------------------------------------------
| 5. CONSTANTES
|--------------------------------------------------------------------------
*/
const NEGOCIO_ICG = 'MENDELS HN';

/*
|--------------------------------------------------------------------------
| 6. FUNCIONES
|--------------------------------------------------------------------------
*/
function h(mixed $valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        'UTF-8'
    );
}

function responderJson(array $respuesta, int $codigoHttp = 200): never
{
    if (ob_get_length()) {
        ob_clean();
    }

    http_response_code($codigoHttp);
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        $respuesta,
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES |
        JSON_INVALID_UTF8_SUBSTITUTE
    );

    exit;
}

function obtenerErroresSqlsrv(): string
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);

    if (!$errores) {
        return 'Ocurrió un error desconocido en SQL Server.';
    }

    $mensajes = [];

    foreach ($errores as $error) {
        $codigo  = $error['code'] ?? 'SIN CÓDIGO';
        $mensaje = $error['message'] ?? 'Error desconocido';

        $mensajes[] = '[' . $codigo . '] ' . $mensaje;
    }

    return implode(' | ', $mensajes);
}

function validarAnio(mixed $anio): ?int
{
    if (
        !is_numeric($anio) ||
        filter_var($anio, FILTER_VALIDATE_INT) === false
    ) {
        return null;
    }

    $anioValidado = (int)$anio;

    if ($anioValidado < 2000 || $anioValidado > 2100) {
        return null;
    }

    return $anioValidado;
}

/*
|--------------------------------------------------------------------------
| 7. PETICIONES AJAX
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string)($_POST['action'] ?? ''));

    if (!$sqlsrvConn) {
        responderJson([
            'ok'  => false,
            'msg' => 'No se encontró una conexión válida a SQL Server.'
        ], 500);
    }

    /*
    |--------------------------------------------------------------------------
    | ACCIÓN: BUSCAR
    |--------------------------------------------------------------------------
    */
    if ($action === 'buscar') {
        $anio = validarAnio($_POST['anio'] ?? null);

        if ($anio === null) {
            responderJson([
                'ok'  => false,
                'msg' => 'Seleccione un año válido.'
            ], 422);
        }

      
        $sql = "
            SELECT
                CAST(? AS VARCHAR(100)) AS NOMNEGOCIOICG,

                D.NUMDPTO,
                ISNULL(D.DESCRIPCION, 'SIN DPTO') AS DEPARTAMENTO,

                S.NUMSECCION,
                ISNULL(S.DESCRIPCION, 'SIN SECCION') AS SECCION,

                F.NUMFAMILIA,
                ISNULL(F.DESCRIPCION, 'SIN FAMILIA') AS FAMILIA,

                M.MetaStock

            FROM MENDELS.dbo.DEPARTAMENTO AS D

            INNER JOIN MENDELS.dbo.SECCIONES AS S
                ON S.NUMDPTO = D.NUMDPTO

            INNER JOIN MENDELS.dbo.FAMILIAS AS F
                ON F.NUMDPTO = D.NUMDPTO
               AND F.NUMSECCION = S.NUMSECCION

            LEFT JOIN vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
                ON M.NOMNEGOCIOICG = ?
               AND M.NUMDPTO = D.NUMDPTO
               AND M.NUMSECCION = S.NUMSECCION
               AND M.NUMFAMILIA = F.NUMFAMILIA
               AND M.ANIO = ?

            WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
              AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
              AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL

            ORDER BY
                D.NUMDPTO,
                S.NUMSECCION,
                F.NUMFAMILIA;
        ";

        $params = [
            NEGOCIO_ICG,
            NEGOCIO_ICG,
            $anio
        ];

        $stmt = sqlsrv_query(
            $sqlsrvConn,
            $sql,
            $params,
            [
                'QueryTimeout' => 0
            ]
        );

        if ($stmt === false) {
            responderJson([
                'ok'  => false,
                'msg' => obtenerErroresSqlsrv()
            ], 500);
        }

        $datos = [];

        while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $metaStock = $fila['MetaStock'];

            $datos[] = [
                'NOMNEGOCIOICG' => NEGOCIO_ICG,
                'NUMDPTO'       => (int)$fila['NUMDPTO'],
                'DEPARTAMENTO'  => trim((string)$fila['DEPARTAMENTO']),
                'NUMSECCION'    => (int)$fila['NUMSECCION'],
                'SECCION'       => trim((string)$fila['SECCION']),
                'NUMFAMILIA'    => (int)$fila['NUMFAMILIA'],
                'FAMILIA'       => trim((string)$fila['FAMILIA']),
                'MetaStock'     => $metaStock === null
                    ? ''
                    : (string)$metaStock
            ];
        }

        sqlsrv_free_stmt($stmt);

        responderJson([
            'ok'      => true,
            'msg'     => 'Información cargada correctamente.',
            'negocio' => NEGOCIO_ICG,
            'anio'    => $anio,
            'total'   => count($datos),
            'datos'   => $datos
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | ACCIÓN: GUARDAR
    |--------------------------------------------------------------------------
    */
        /*
    |--------------------------------------------------------------------------
    | ACCIÓN: GUARDAR DIVIDIDO EN META_CREADO Y META_ACTUALIZADO
    |--------------------------------------------------------------------------
    */
    if ($action === 'guardar') {
        $anio = validarAnio($_POST['anio'] ?? null);

        if ($anio === null) {
            responderJson([
                'ok'  => false,
                'msg' => 'Seleccione un año válido.'
            ], 422);
        }

        $filasJson = trim((string)($_POST['filas'] ?? ''));

        if ($filasJson === '') {
            responderJson([
                'ok'  => false,
                'msg' => 'No se recibieron registros para guardar.'
            ], 422);
        }

        try {
            $filas = json_decode($filasJson, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            responderJson([
                'ok'  => false,
                'msg' => 'El formato de la información recibida no es válido.'
            ], 422);
        }

        if (!is_array($filas) || count($filas) === 0) {
            responderJson([
                'ok'  => false,
                'msg' => 'No hay metas para guardar.'
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Obtiene la Meta Stock actual antes del MERGE. Esto permite saber:
        | - Si el registro es nuevo       => META_CREADO
        | - Si el registro ya existía     => META_ACTUALIZADO
        | - Cuál era el valor anterior para mostrarlo en Auditoría.
        |--------------------------------------------------------------------------
        */
        $sqlVerificar = "
            SELECT TOP 1
                MetaStock
            FROM vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META
            WHERE NOMNEGOCIOICG = ?
              AND NUMDPTO = ?
              AND NUMSECCION = ?
              AND NUMFAMILIA = ?
              AND ANIO = ?
        ";

        $sqlMerge = "
            MERGE vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META
                WITH (HOLDLOCK) AS destino
            USING (
                SELECT
                    CAST(? AS VARCHAR(100)) AS NOMNEGOCIOICG,
                    CAST(? AS INT) AS NUMDPTO,
                    CAST(? AS INT) AS NUMSECCION,
                    CAST(? AS INT) AS NUMFAMILIA,
                    CAST(? AS DECIMAL(18,2)) AS MetaStock,
                    CAST(? AS INT) AS ANIO
            ) AS origen
            ON destino.NOMNEGOCIOICG = origen.NOMNEGOCIOICG
               AND destino.NUMDPTO = origen.NUMDPTO
               AND destino.NUMSECCION = origen.NUMSECCION
               AND destino.NUMFAMILIA = origen.NUMFAMILIA
               AND destino.ANIO = origen.ANIO
            WHEN MATCHED THEN
                UPDATE SET destino.MetaStock = origen.MetaStock
            WHEN NOT MATCHED THEN
                INSERT (NOMNEGOCIOICG, NUMDPTO, NUMSECCION, NUMFAMILIA, MetaStock, ANIO)
                VALUES (origen.NOMNEGOCIOICG, origen.NUMDPTO, origen.NUMSECCION, origen.NUMFAMILIA, origen.MetaStock, origen.ANIO);
        ";

        if (!sqlsrv_begin_transaction($sqlsrvConn)) {
            responderJson([
                'ok'  => false,
                'msg' => 'No se pudo iniciar la transacción: ' . obtenerErroresSqlsrv()
            ], 500);
        }

        $guardados = 0;
        $omitidos  = 0;
        $historialAuditoria = []; 
        $resultadosGuardados = [];

        try {
            foreach ($filas as $indice => $fila) {
                if (!is_array($fila)) {
                    throw new RuntimeException('La fila ' . ($indice + 1) . ' no tiene un formato válido.');
                }

                $numDpto = filter_var($fila['NUMDPTO'] ?? null, FILTER_VALIDATE_INT);
                $numSeccion = filter_var($fila['NUMSECCION'] ?? null, FILTER_VALIDATE_INT);
                $numFamilia = filter_var($fila['NUMFAMILIA'] ?? null, FILTER_VALIDATE_INT);

                $nombreDpto = trim((string)($fila['DEPARTAMENTO'] ?? "Dpto {$numDpto}"));
                $nombreSeccion = trim((string)($fila['SECCION'] ?? "Secc {$numSeccion}"));
                $nombreFamilia = trim((string)($fila['FAMILIA'] ?? "Fam {$numFamilia}"));

                if ($numDpto === false || $numSeccion === false || $numFamilia === false) {
                    throw new RuntimeException('Los códigos de la fila ' . ($indice + 1) . ' no son válidos.');
                }

                $metaRaw = trim((string)($fila['MetaStock'] ?? ''));

                if ($metaRaw === '') {
                    $omitidos++;
                    continue;
                }

                $metaNormalizada = str_replace(
                    [',', 'L', 'l', 'HNL', 'hnl', ' '],
                    ['', '', '', '', '', ''],
                    $metaRaw
                );

                if ($metaNormalizada === '' || !is_numeric($metaNormalizada)) {
                    throw new RuntimeException('La Meta Stock de la fila ' . ($indice + 1) . ' no es válida.');
                }

                $metaStock = round((float)$metaNormalizada, 2);

                if ($metaStock < 0) {
                    throw new RuntimeException('La Meta Stock de la fila ' . ($indice + 1) . ' debe ser mayor o igual a cero.');
                }

                /*
                |--------------------------------------------------------------------------
                | META STOCK
                |--------------------------------------------------------------------------
                | Se guarda exactamente el valor ingresado.
                |--------------------------------------------------------------------------
                */
                $metaIngresada = $metaStock;

                /*
                |--------------------------------------------------------------------------
                | VERIFICACIÓN DE EXISTENCIA ANTES DEL MERGE
                |--------------------------------------------------------------------------
                */
                $paramsVerificar = [
                    NEGOCIO_ICG,
                    $numDpto,
                    $numSeccion,
                    $numFamilia,
                    $anio
                ];

                $stmtVerificar = sqlsrv_query(
                    $sqlsrvConn,
                    $sqlVerificar,
                    $paramsVerificar,
                    ['QueryTimeout' => 0]
                );

                if ($stmtVerificar === false) {
                    throw new RuntimeException(
                        'No se pudo consultar la Meta Stock anterior: ' .
                        obtenerErroresSqlsrv()
                    );
                }

                /*
                |------------------------------------------------------------------
                | LEER EL VALOR ANTERIOR
                |------------------------------------------------------------------
                */
                $registroAnterior = sqlsrv_fetch_array(
                    $stmtVerificar,
                    SQLSRV_FETCH_ASSOC
                );

                sqlsrv_free_stmt($stmtVerificar);

                $yaExiste = is_array($registroAnterior);

                $metaAnterior = $yaExiste
                    ? round((float)($registroAnterior['MetaStock'] ?? 0), 2)
                    : null;

                $tipoAccion = $yaExiste
                    ? 'META_ACTUALIZADO'
                    : 'META_CREADO';

                /*
                |------------------------------------------------------------------
                | Se usan saltos de línea (\n). La pantalla de Auditoría debe
                | tener white-space: pre-line para mostrarlos correctamente.
                |------------------------------------------------------------------
                */
                if ($yaExiste) {
                    $textoDetalle = sprintf(
                        "Departamento: %s\n" .
                        "Sección: %s\n" .
                        "Familia: %s\n" .
                        "Año de la meta: %d\n" .
                        "Meta anterior: %s\n" .
                        "Meta guardada: %s\n" .
                        "Resultado: La Meta Stock fue actualizada correctamente en producción.",
                        $nombreDpto,
                        $nombreSeccion,
                        $nombreFamilia,
                        $anio,
                        number_format($metaAnterior, 2),
                        number_format($metaStock, 2)
                    );
                } else {
                    $textoDetalle = sprintf(
                        "Departamento: %s\n" .
                        "Sección: %s\n" .
                        "Familia: %s\n" .
                        "Año de la meta: %d\n" .
                        "Meta guardada: %s\n" .
                        "Resultado: La Meta Stock fue creada correctamente en producción.",
                        $nombreDpto,
                        $nombreSeccion,
                        $nombreFamilia,
                        $anio,
                        number_format($metaStock, 2)
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | EJECUTAR EL MERGE
                |--------------------------------------------------------------------------
                */
                $paramsMerge = [
                    NEGOCIO_ICG,
                    $numDpto,
                    $numSeccion,
                    $numFamilia,
                    $metaStock,
                    $anio
                ];

                $stmtMerge = sqlsrv_query($sqlsrvConn, $sqlMerge, $paramsMerge, ['QueryTimeout' => 0]);

                if ($stmtMerge === false) {
                    throw new RuntimeException(obtenerErroresSqlsrv());
                }

                sqlsrv_free_stmt($stmtMerge);

                // Guardamos en memoria para procesar tras el commit exitoso
                $historialAuditoria[] = [
                    'accion'  => $tipoAccion,
                    'detalle' => $textoDetalle
                ];

                $resultadosGuardados[] = [
                    'NUMDPTO'       => $numDpto,
                    'NUMSECCION'    => $numSeccion,
                    'NUMFAMILIA'    => $numFamilia,
                    'metaIngresada' => $metaIngresada,
                    'metaGuardada'  => $metaStock
                ];

                $guardados++;
            }

            if (!sqlsrv_commit($sqlsrvConn)) {
                throw new RuntimeException('No se pudo confirmar la transacción: ' . obtenerErroresSqlsrv());
            }

            /*
            |--------------------------------------------------------------------------
            | GUARDAR EN AUDITORÍA (FILA POR FILA CON ACCIÓN INDEPENDIENTE)
            |--------------------------------------------------------------------------
            */
            if ($guardados > 0 && function_exists('registrar_auditoria')) {
                foreach ($historialAuditoria as $registro) {
                    registrar_auditoria($registro['accion'], $registro['detalle']);
                }
            }

            responderJson([
                'ok'         => true,
                'msg'        => 'Las metas se guardaron correctamente.',
                'guardados'  => $guardados,
                'omitidos'   => $omitidos,
                'anio'       => $anio,
                'resultados' => $resultadosGuardados
            ]);
        } catch (Throwable $e) {
            sqlsrv_rollback($sqlsrvConn);

            responderJson([
                'ok'  => false,
                'msg' => $e->getMessage()
            ], 500);
        }
    }

    responderJson([
        'ok'  => false,
        'msg' => 'La acción solicitada no es válida.'
    ], 400);
}

/*
|--------------------------------------------------------------------------
| 8. VALIDAR CONEXIÓN EN CARGA NORMAL
|--------------------------------------------------------------------------
*/
if (!$sqlsrvConn) {
    die('No se encontró una conexión válida a SQL Server.');
}

/*
|--------------------------------------------------------------------------
| 9. CARGAR MENÚ PRINCIPAL
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../layout_menu.php';

$anioActual = (int)date('Y');
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">

    <title>Metas de Inventario</title>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="<?= $baseUrl ?>/metasinventario/metas.css?v=<?= time() ?>"
    >
</head>

<body>

<div class="contenedor-meta">

    <div class="card tarjeta-principal">
        <div class="card-body">

            <!-- ALERTAS -->
            <div
                id="alertaSistema"
                class="alert d-none"
                role="alert"
            ></div>

            <section class="barra-superior">

                <div class="grupo-periodo">

                    <div class="campo-anio">
                        <label
                            for="anio"
                            class="form-label"
                        >
                            Año
                        </label>

                        <div class="select-con-icono">
                            <i class="bi bi-calendar3"></i>

                            <select
                                id="anio"
                                class="form-select"
                            >
                                <option value="">
                                    Seleccione
                                </option>

                                <?php
for ($anio = 2028; $anio >= 2026; $anio--):
?>
    <option
        value="<?= h($anio) ?>"
        <?= $anio == 2026 ? 'selected' : '' ?>
    >
        <?= h($anio) ?>
    </option>
<?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <div class="acciones-superiores">

                        <button
                            type="button"
                            id="btnBuscar"
                            class="btn btn-cargar"
                        >
                            <i class="bi bi-search"></i>

                            <span>
                                Cargar
                            </span>
                        </button>

                        <button
                            type="button"
                            id="btnExportar"
                            class="btn btn-exportar"
                            disabled
                        >
                            <i class="bi bi-file-earmark-excel"></i>

                            <span>
                                Exportar
                            </span>
                        </button>
            
                    </div>

                </div>

            </section>

           
            <section class="resumen-tabla">

                <div class="resumen-registros">
                    <span class="resumen-icono">
                        <i class="bi bi-list-ul"></i>
                    </span>

                    <div>
                        <span class="resumen-label">
                            Registros mostrados
                        </span>

                        <strong id="totalRegistros">
                            0
                        </strong>
                    </div>
                </div>

                <div class="ayuda-filtros">
                    <i class="bi bi-info-circle"></i>

                    <span>
                        Use el icono
                        <i class="bi bi-funnel-fill"></i>
                        para filtrar y ordenar cada columna.
                    </span>
                </div>

            </section>

        
            <section class="encabezado-detalle">

                 <!--<div>
                    <h1 class="titulo-detalle">
                        Detalle de metas
                    </h1>

                    <p class="descripcion-detalle">
                        El único campo editable es Meta Stock.
                    </p>
                </div>-->

                <span class="badge-editable">
                    <i class="bi bi-pencil-square"></i>
                    Meta Stock editable
                </span>

            </section>

            <!-- MENSAJES ADICIONALES -->
            <div id="msgBox"></div>

            <!-- =========================================================
                 TABLA
            ========================================================== -->
            <section class="table-section">

                <div class="table-wrap">

                    <table class="table metas-table align-middle">

                        <thead>
                            <tr>
                                <th class="numero-fila">
                                    N°
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Cod. Departamento
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="NUMDPTO"
                                            data-label="Código de departamento"
                                            title="Filtrar código de departamento"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Departamento
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="DEPARTAMENTO"
                                            data-label="Departamento"
                                            title="Filtrar departamento"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Cod. Sección
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="NUMSECCION"
                                            data-label="Código de sección"
                                            title="Filtrar código de sección"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Sección
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="SECCION"
                                            data-label="Sección"
                                            title="Filtrar sección"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Cod. Familia
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="NUMFAMILIA"
                                            data-label="Código de familia"
                                            title="Filtrar código de familia"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th>
                                    <div class="th-content">
                                        <span>
                                            Familia
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="FAMILIA"
                                            data-label="Familia"
                                            title="Filtrar familia"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th class="columna-meta">
                                    <div class="th-content">
                                        <span>
                                            Meta Stock
                                        </span>

                                        <button
                                            type="button"
                                            class="btn-filter-excel"
                                            data-campo="MetaStock"
                                            data-label="Meta Stock"
                                            title="Filtrar Meta Stock"
                                        >
                                            <i class="bi bi-funnel"></i>
                                        </button>
                                    </div>
                                </th>

                                <th class="columna-guardar">
                                    Guardar
                                </th>
                            </tr>
                        </thead>

                        <tbody id="tbodyResultados">
                            <tr>
                                <td
                                    colspan="9"
                                    class="empty-box"
                                >
                                    <div class="empty-state">
                                        <span class="empty-icon">
                                            <i class="bi bi-calendar2-check"></i>
                                        </span>

                                        <h2>
                                            No hay información cargada
                                        </h2>

                                        <p>
                                            Seleccione un año y presione
                                            “Cargar”.
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        </tbody>

                    </table>

                </div>

            </section>

        </div>
    </div>

</div>

<!-- =========================================================
     PANEL DE FILTROS TIPO EXCEL
========================================================== -->
<div
    id="excelFilterPanel"
    class="excel-filter-panel"
>
    <div class="excel-panel-header">

        <div>
            <!--<span class="excel-panel-subtitulo">
                FILTRAR COLUMNA
            </span>-->

            <h6
                id="excelPanelTitle"
                class="excel-panel-title"
            >
                Filtro
            </h6>
        </div>

        <button
            type="button"
            id="btnCerrarPanel"
            class="btn-close-panel"
            aria-label="Cerrar filtro"
        >
            <i class="bi bi-x-lg"></i>
        </button>

    </div>

    <div class="excel-panel-body">

        <button
            type="button"
            id="btnOrdenAsc"
            class="excel-sort-btn"
        >
            <i class="bi bi-sort-alpha-down"></i>
            Ordenar de A a Z
        </button>

        <button
            type="button"
            id="btnOrdenDesc"
            class="excel-sort-btn"
        >
            <i class="bi bi-sort-alpha-up"></i>
            Ordenar de Z a A
        </button>

        <div class="separador-panel"></div>

        <div class="filter-search-box">
            <i class="bi bi-search"></i>

            <input
                type="text"
                id="inputBuscarValores"
                class="form-control"
                placeholder="Buscar valor..."
                autocomplete="off"
            >
        </div>

        <label class="check-row seleccionar-todos">
            <input
                type="checkbox"
                id="checkSelectAll"
                checked
            >

            <strong>
                Seleccionar todo
            </strong>
        </label>

        <div
            id="valueList"
            class="value-list"
        ></div>

    </div>

    <div class="excel-panel-footer">

        <div class="acciones-panel">

            <button
                type="button"
                id="btnAplicarFiltro"
                class="btn btn-aplicar-filtro"
            >
                <i class="bi bi-check2"></i>
                Aplicar
            </button>

            <button
                type="button"
                id="btnLimpiarFiltro"
                class="btn btn-limpiar-columna"
            >
                <i class="bi bi-eraser"></i>
                Limpiar
            </button>

        </div>

        <button
            type="button"
            id="btnLimpiarSoloFiltros"
            class="btn btn-quitar-filtros"
        >
            <i class="bi bi-funnel"></i>
            Quitar todos los filtros
        </button>

    </div>
</div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

<script
    src="<?= $baseUrl ?>/metasinventario/metas.js?v=<?= time() ?>"
    defer
></script>

<?php
require_once __DIR__ . '/../layout_footer.php';
?>