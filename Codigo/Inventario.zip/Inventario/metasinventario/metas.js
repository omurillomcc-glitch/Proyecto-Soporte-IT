'use strict';



const btnBuscar = document.getElementById('btnBuscar');
const btnExportar = document.getElementById('btnExportar');
const selectAnio = document.getElementById('anio');

const tbodyResultados = document.getElementById('tbodyResultados');
const totalRegistros = document.getElementById('totalRegistros');
const alertaSistema = document.getElementById('alertaSistema');
const msgBox = document.getElementById('msgBox');

const excelFilterPanel = document.getElementById('excelFilterPanel');
const excelPanelTitle = document.getElementById('excelPanelTitle');
const btnCerrarPanel = document.getElementById('btnCerrarPanel');
const btnOrdenAsc = document.getElementById('btnOrdenAsc');
const btnOrdenDesc = document.getElementById('btnOrdenDesc');
const inputBuscarValores = document.getElementById('inputBuscarValores');
const checkSelectAll = document.getElementById('checkSelectAll');
const valueList = document.getElementById('valueList');
const btnAplicarFiltro = document.getElementById('btnAplicarFiltro');
const btnLimpiarFiltro = document.getElementById('btnLimpiarFiltro');
const btnLimpiarSoloFiltros = document.getElementById('btnLimpiarSoloFiltros');


let datosOriginales = [];
let datosActuales = [];

let campoFiltroActivo = null;
let botonFiltroActivo = null;

let ordenActual = {
    campo: null,
    direccion: null
};

const filtrosExcel = {};



let paginaActual = 1;
let registrosPorPagina = 500;

let contenedorPaginacion = null;
let selectRegistrosPagina = null;
let textoPaginacion = null;
let botonesPaginas = null;


/* ==========================================================================
   UTILIDADES
============================================================================ */

function escaparHtml(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function normalizarTexto(valor) {
    return String(valor ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim()
        .toLowerCase();
}

function clonarDatos(datos) {
    return datos.map(fila => ({ ...fila }));
}

function mostrarAlerta(tipo, mensaje) {
    if (!alertaSistema) {
        return;
    }

    alertaSistema.className = `alert alert-${tipo}`;
    alertaSistema.textContent = mensaje;
    alertaSistema.classList.remove('d-none');
}

function ocultarAlerta() {
    if (!alertaSistema) {
        return;
    }

    alertaSistema.classList.add('d-none');
    alertaSistema.textContent = '';
}

function limpiarMensajeTabla() {
    if (msgBox) {
        msgBox.innerHTML = '';
    }
}

function obtenerMensajeError(error) {
    return error instanceof Error && error.message
        ? error.message
        : 'Ocurrió un error inesperado.';
}

async function leerRespuestaJson(respuesta) {
    const texto = await respuesta.text();

    let resultado;

    try {
        resultado = JSON.parse(texto);
    } catch (error) {
        throw new Error(
            'El servidor devolvió una respuesta inválida: ' +
            texto.substring(0, 300)
        );
    }

    if (!respuesta.ok || !resultado.ok) {
        throw new Error(
            resultado.msg ||
            'No se pudo completar la operación.'
        );
    }

    return resultado;
}

function establecerCargaBoton(
    boton,
    cargando,
    htmlNormal,
    textoCarga
) {
    if (!boton) {
        return;
    }

    boton.disabled = cargando;

    boton.innerHTML = cargando
        ? `
            <span
                class="spinner-border spinner-border-sm"
                aria-hidden="true"
            ></span>
            <span>${escaparHtml(textoCarga)}</span>
        `
        : htmlNormal;
}


function convertirMetaANumero(valor) {
    let texto = String(valor ?? '')
        .trim()
        .replace(/\s/g, '')
        .replace(/HNL/gi, '')
        .replace(/L/gi, '');

    if (texto === '') {
        return '';
    }

    if (texto.includes('.') && texto.includes(',')) {
        const ultimoPunto = texto.lastIndexOf('.');
        const ultimaComa = texto.lastIndexOf(',');

        if (ultimaComa > ultimoPunto) {
            texto = texto
                .replace(/\./g, '')
                .replace(',', '.');
        } else {
            texto = texto.replace(/,/g, '');
        }
    } else if (texto.includes(',')) {
        const partes = texto.split(',');

        if (
            partes.length === 2 &&
            partes[1].length > 0 &&
            partes[1].length <= 2
        ) {
            texto = `${partes[0]}.${partes[1]}`;
        } else {
            texto = texto.replace(/,/g, '');
        }
    }

    texto = texto.replace(/[^0-9.-]/g, '');

    if (
        texto === '' ||
        texto === '-' ||
        !Number.isFinite(Number(texto))
    ) {
        return '';
    }

    return Number(texto);
}

function formatearMeta(valor) {
    const numero = convertirMetaANumero(valor);

    if (numero === '') {
        return '';
    }

    return new Intl.NumberFormat('es-HN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(numero);
}

function valorCrudoFiltro(fila, campo) {
    const valor = fila?.[campo] ?? '';

    if (campo === 'MetaStock') {
        const numero = convertirMetaANumero(valor);

        return numero === ''
            ? ''
            : String(Number(numero.toFixed(2)));
    }

    return String(valor).trim();
}

function valorVisibleFiltro(valor, campo) {
    const texto = String(valor ?? '').trim();

    if (texto === '') {
        return '(Vacíos)';
    }

    if (campo === 'MetaStock') {
        return formatearMeta(texto);
    }

    return texto;
}

/* ==========================================================================
   FILTROS CONTEXTUALES
============================================================================ */

function obtenerDatosSegunOtrosFiltros(campoExcluir = null) {
    return datosActuales.filter(fila => {
        return Object.entries(filtrosExcel).every(
            ([campo, valoresSeleccionados]) => {
                if (campo === campoExcluir) {
                    return true;
                }

                if (!(valoresSeleccionados instanceof Set)) {
                    return true;
                }

                return valoresSeleccionados.has(
                    valorCrudoFiltro(fila, campo)
                );
            }
        );
    });
}

function obtenerValoresDisponibles(campo) {
    const datosContextuales =
        obtenerDatosSegunOtrosFiltros(campo);

    const valores = [
        ...new Set(
            datosContextuales.map(
                fila => valorCrudoFiltro(fila, campo)
            )
        )
    ];

    const camposNumericos = [
        'NUMDPTO',
        'NUMSECCION',
        'NUMFAMILIA',
        'MetaStock'
    ];

    return valores.sort((valorA, valorB) => {
        if (camposNumericos.includes(campo)) {
            const numeroA = convertirMetaANumero(valorA);
            const numeroB = convertirMetaANumero(valorB);

            if (numeroA === '' && numeroB !== '') {
                return 1;
            }

            if (numeroA !== '' && numeroB === '') {
                return -1;
            }

            if (numeroA !== '' && numeroB !== '') {
                return numeroA - numeroB;
            }
        }

        return String(valorA).localeCompare(
            String(valorB),
            'es',
            {
                numeric: true,
                sensitivity: 'base'
            }
        );
    });
}

function obtenerDatosFiltradosYOrdenados() {
    let resultado = datosActuales.filter(fila => {
        return Object.entries(filtrosExcel).every(
            ([campo, valoresSeleccionados]) => {
                if (!(valoresSeleccionados instanceof Set)) {
                    return true;
                }

                return valoresSeleccionados.has(
                    valorCrudoFiltro(fila, campo)
                );
            }
        );
    });

    resultado = [...resultado];

    if (ordenActual.campo && ordenActual.direccion) {
        const camposNumericos = [
            'NUMDPTO',
            'NUMSECCION',
            'NUMFAMILIA',
            'MetaStock'
        ];

        resultado.sort((filaA, filaB) => {
            const campo = ordenActual.campo;
            const valorA = filaA[campo] ?? '';
            const valorB = filaB[campo] ?? '';

            let comparacion;

            if (camposNumericos.includes(campo)) {
                const numeroA = convertirMetaANumero(valorA);
                const numeroB = convertirMetaANumero(valorB);

                if (numeroA === '' && numeroB === '') {
                    comparacion = 0;
                } else if (numeroA === '') {
                    comparacion = 1;
                } else if (numeroB === '') {
                    comparacion = -1;
                } else {
                    comparacion = numeroA - numeroB;
                }
            } else {
                comparacion = String(valorA)
                    .trim()
                    .localeCompare(
                        String(valorB).trim(),
                        'es',
                        {
                            numeric: true,
                            sensitivity: 'base'
                        }
                    );
            }

            return ordenActual.direccion === 'asc'
                ? comparacion
                : -comparacion;
        });
    }

    return resultado;
}

/* ==========================================================================
   ESTADOS DE TABLA
============================================================================ */

function mostrarEstadoInicial() {
    tbodyResultados.innerHTML = `
        <tr>
            <td colspan="9" class="empty-box">
                <div class="empty-state">
                    <span class="empty-icon">
                        <i class="bi bi-calendar2-check"></i>
                    </span>

                    <h2>No hay información cargada</h2>

                    <p>
                        Seleccione un año y presione
                        “Cargar”.
                    </p>
                </div>
            </td>
        </tr>
    `;
}

function mostrarEstadoCargando() {
    tbodyResultados.innerHTML = `
        <tr>
            <td colspan="9" class="empty-box">
                <div class="empty-state">
                    <span
                        class="spinner-border text-primary"
                        role="status"
                        aria-hidden="true"
                    ></span>

                    <h2 class="mt-3">
                        Cargando información
                    </h2>

                    <p>
                        Consultando las metas de inventario...
                    </p>
                </div>
            </td>
        </tr>
    `;
}

function mostrarEstadoSinResultados() {
    tbodyResultados.innerHTML = `
        <tr>
            <td colspan="9" class="empty-box">
                <div class="empty-state">
                    <span class="empty-icon">
                        <i class="bi bi-funnel"></i>
                    </span>

                    <h2>No hay resultados</h2>

                    <p>
                        No existen registros con los filtros seleccionados.
                    </p>
                </div>
            </td>
        </tr>
    `;
}

/* ==========================================================================
   RENDERIZAR TABLA
============================================================================ */

function renderizarTabla(
    datos,
    totalFiltrado = datos.length,
    inicioRegistro = 0
) {
    if (!Array.isArray(datos) || datos.length === 0) {
        mostrarEstadoSinResultados();

        totalRegistros.textContent = datosActuales.length > 0
            ? `0 de ${datosActuales.length}`
            : '0';

        actualizarEstadoBotones();
        actualizarIconosFiltros();
        actualizarControlesPaginacion(totalFiltrado);

        return;
    }

    tbodyResultados.innerHTML = datos
        .map((fila, posicionVisible) => {
            const indiceOriginal = fila._indiceOriginal;
            const metaActual = fila.MetaStock ?? '';

            const metaOriginal =
                datosOriginales[indiceOriginal]?.MetaStock ?? '';

            const actualNumero =
                convertirMetaANumero(metaActual);

            const originalNumero =
                convertirMetaANumero(metaOriginal);

            const modificada =
                String(actualNumero) !==
                String(originalNumero);

            const metaVisible = metaActual === ''
                ? ''
                : formatearMeta(metaActual);

            return `
                <tr data-indice-original="${indiceOriginal}">
                    <td class="numero-fila">
                        ${inicioRegistro + posicionVisible + 1}
                    </td>

                    <td class="campo-codigo">
                        ${escaparHtml(fila.NUMDPTO)}
                    </td>

                    <td>
                        ${escaparHtml(fila.DEPARTAMENTO)}
                    </td>

                    <td class="campo-codigo">
                        ${escaparHtml(fila.NUMSECCION)}
                    </td>

                    <td>
                        ${escaparHtml(fila.SECCION)}
                    </td>

                    <td class="campo-codigo">
                        ${escaparHtml(fila.NUMFAMILIA)}
                    </td>

                    <td>
                        ${escaparHtml(fila.FAMILIA)}
                    </td>

                    <td>
                        <input
                            type="text"
                            class="
                                form-control
                                input-meta
                                ${modificada
                                    ? 'input-meta-modificado'
                                    : ''
                                }
                            "
                            data-indice-original="${indiceOriginal}"
                            value="${escaparHtml(metaVisible)}"
                            placeholder="0.00"
                            inputmode="decimal"
                            autocomplete="off"
                        >
                    </td>

                    <td class="text-center">
                        <button
                            type="button"
                            class="btn btn-guardar-meta"
                            data-indice-original="${indiceOriginal}"
                            ${modificada ? '' : 'disabled'}
                        >
                            <i class="bi bi-floppy"></i>
                            
                        </button>
                    </td>
                </tr>
            `;
        })
        .join('');

    const finRegistro = inicioRegistro + datos.length;

    totalRegistros.textContent =
        `${inicioRegistro + 1}-${finRegistro} de ${totalFiltrado}`;

    registrarEventosFilas();
    actualizarEstadoBotones();
    actualizarIconosFiltros();
    actualizarControlesPaginacion(totalFiltrado);
}


function aplicarFiltrosYOrden({
    conservarPagina = false
} = {}) {
    const datosFiltrados =
        obtenerDatosFiltradosYOrdenados();

    if (!conservarPagina) {
        paginaActual = 1;
    }

    const totalPaginas = Math.max(
        1,
        Math.ceil(
            datosFiltrados.length /
            registrosPorPagina
        )
    );

    if (paginaActual > totalPaginas) {
        paginaActual = totalPaginas;
    }

    const inicio =
        (paginaActual - 1) *
        registrosPorPagina;

    const fin =
        inicio + registrosPorPagina;

    const datosPagina =
        datosFiltrados.slice(inicio, fin);

    renderizarTabla(
        datosPagina,
        datosFiltrados.length,
        inicio
    );
}

/* ==========================================================================
   CONTROLES DE PAGINACIÓN
============================================================================ */

function crearControlesPaginacion() {
    if (document.getElementById('contenedorPaginacionMetas')) {
        contenedorPaginacion =
            document.getElementById(
                'contenedorPaginacionMetas'
            );

        return;
    }

    contenedorPaginacion =
        document.createElement('div');

    contenedorPaginacion.id =
        'contenedorPaginacionMetas';

    contenedorPaginacion.className =
        'paginacion-metas';

    contenedorPaginacion.innerHTML = `
        <div class="paginacion-cantidad">
            <label for="selectRegistrosPagina">
                Mostrar
            </label>

            <select
                id="selectRegistrosPagina"
                class="form-select form-select-sm"
            >
                <option value="500">500</option>
                <option value="1000" selected>1000</option>
                <option value="1500">1500</option>
            </select>

            <span>registros</span>
        </div>

        <div class="paginacion-botones">
            <button
                type="button"
                id="btnPrimeraPagina"
                class="btn btn-sm btn-outline-secondary"
                title="Primera página"
            >
                <i class="bi bi-chevron-bar-left"></i>
            </button>

            <button
                type="button"
                id="btnPaginaAnterior"
                class="btn btn-sm btn-outline-secondary"
                title="Página anterior"
            >
                <i class="bi bi-chevron-left"></i>
            </button>

            <div
                id="botonesPaginas"
                class="numeros-paginacion"
            ></div>

            <button
                type="button"
                id="btnPaginaSiguiente"
                class="btn btn-sm btn-outline-secondary"
                title="Página siguiente"
            >
                <i class="bi bi-chevron-right"></i>
            </button>

            <button
                type="button"
                id="btnUltimaPagina"
                class="btn btn-sm btn-outline-secondary"
                title="Última página"
            >
                <i class="bi bi-chevron-bar-right"></i>
            </button>
        </div>
    `;

    const tabla =
        tbodyResultados.closest('table');

    const contenedorTabla =
        tabla?.parentElement;

    if (contenedorTabla) {
        contenedorTabla.insertAdjacentElement(
            'afterend',
            contenedorPaginacion
        );
    } else {
        tbodyResultados.parentElement
            ?.insertAdjacentElement(
                'afterend',
                contenedorPaginacion
            );
    }

   selectRegistrosPagina =
    document.getElementById(
        'selectRegistrosPagina'
    );

selectRegistrosPagina.value = String(registrosPorPagina);

selectRegistrosPagina.addEventListener(
    'change',
    () => {
        registrosPorPagina =
            Number(selectRegistrosPagina.value);

        paginaActual = 1;
        aplicarFiltrosYOrden();
    }
);
    textoPaginacion =
        document.getElementById(
            'textoPaginacion'
        );

    botonesPaginas =
        document.getElementById(
            'botonesPaginas'
        );

    selectRegistrosPagina.addEventListener(
        'change',
        () => {
            registrosPorPagina =
                Number(selectRegistrosPagina.value);

            paginaActual = 1;
            aplicarFiltrosYOrden();
        }
    );

    document
        .getElementById('btnPrimeraPagina')
        .addEventListener('click', () => {
            cambiarPagina(1);
        });

    document
        .getElementById('btnPaginaAnterior')
        .addEventListener('click', () => {
            cambiarPagina(paginaActual - 1);
        });

    document
        .getElementById('btnPaginaSiguiente')
        .addEventListener('click', () => {
            cambiarPagina(paginaActual + 1);
        });

    document
        .getElementById('btnUltimaPagina')
        .addEventListener('click', () => {
            const total =
                obtenerDatosFiltradosYOrdenados()
                    .length;

            const totalPaginas = Math.max(
                1,
                Math.ceil(
                    total /
                    registrosPorPagina
                )
            );

            cambiarPagina(totalPaginas);
        });

    actualizarControlesPaginacion(0);
}

function cambiarPagina(numeroPagina) {
    const totalRegistrosFiltrados =
        obtenerDatosFiltradosYOrdenados()
            .length;

    const totalPaginas = Math.max(
        1,
        Math.ceil(
            totalRegistrosFiltrados /
            registrosPorPagina
        )
    );

    const nuevaPagina = Math.min(
        Math.max(1, numeroPagina),
        totalPaginas
    );

    if (nuevaPagina === paginaActual) {
        return;
    }

    paginaActual = nuevaPagina;

    aplicarFiltrosYOrden({
        conservarPagina: true
    });

    tbodyResultados
        .closest('table')
        ?.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
}

function actualizarControlesPaginacion(
    totalFiltrado
) {
    if (!contenedorPaginacion) {
        return;
    }

    const totalPaginas = Math.max(
        1,
        Math.ceil(
            totalFiltrado /
            registrosPorPagina
        )
    );

    if (paginaActual > totalPaginas) {
        paginaActual = totalPaginas;
    }

    const inicio = totalFiltrado === 0
        ? 0
        : (
            (paginaActual - 1) *
            registrosPorPagina
        ) + 1;

    const fin = Math.min(
        paginaActual *
        registrosPorPagina,
        totalFiltrado
    );
// No mostrar el texto porque ya existe el contador superior
if (textoPaginacion) {
    textoPaginacion.style.display = 'none';
}

    const btnPrimera =
        document.getElementById(
            'btnPrimeraPagina'
        );

    const btnAnterior =
        document.getElementById(
            'btnPaginaAnterior'
        );

    const btnSiguiente =
        document.getElementById(
            'btnPaginaSiguiente'
        );

    const btnUltima =
        document.getElementById(
            'btnUltimaPagina'
        );

    const estaEnPrimera =
        paginaActual <= 1 ||
        totalFiltrado === 0;

    const estaEnUltima =
        paginaActual >= totalPaginas ||
        totalFiltrado === 0;

    btnPrimera.disabled = estaEnPrimera;
    btnAnterior.disabled = estaEnPrimera;
    btnSiguiente.disabled = estaEnUltima;
    btnUltima.disabled = estaEnUltima;

    crearBotonesNumerados(totalPaginas);
}

function crearBotonesNumerados(totalPaginas) {
    if (!botonesPaginas) {
        return;
    }

    botonesPaginas.innerHTML = '';

    if (totalPaginas <= 1) {
        const boton = crearBotonPagina(1);
        boton.disabled = true;
        botonesPaginas.appendChild(boton);
        return;
    }

    const paginas = obtenerPaginasVisibles(
        paginaActual,
        totalPaginas
    );

    paginas.forEach(pagina => {
        if (pagina === '...') {
            const puntos =
                document.createElement('span');

            puntos.className =
                'paginacion-puntos';

            puntos.textContent = '...';

            botonesPaginas.appendChild(
                puntos
            );

            return;
        }

        botonesPaginas.appendChild(
            crearBotonPagina(pagina)
        );
    });
}

function crearBotonPagina(numero) {
    const boton =
        document.createElement('button');

    boton.type = 'button';

    boton.className =
        'btn btn-sm btn-outline-secondary btn-numero-pagina';

    boton.textContent = numero;

    if (numero === paginaActual) {
        boton.classList.remove(
            'btn-outline-secondary'
        );

        boton.classList.add(
            'btn-primary',
            'pagina-activa'
        );

        boton.disabled = true;
    }

    boton.addEventListener(
        'click',
        () => cambiarPagina(numero)
    );

    return boton;
}

function obtenerPaginasVisibles(
    pagina,
    totalPaginas
) {
    if (totalPaginas <= 7) {
        return Array.from(
            { length: totalPaginas },
            (_, indice) => indice + 1
        );
    }

    if (pagina <= 4) {
        return [
            1,
            2,
            3,
            4,
            5,
            '...',
            totalPaginas
        ];
    }

    if (pagina >= totalPaginas - 3) {
        return [
            1,
            '...',
            totalPaginas - 4,
            totalPaginas - 3,
            totalPaginas - 2,
            totalPaginas - 1,
            totalPaginas
        ];
    }

    return [
        1,
        '...',
        pagina - 1,
        pagina,
        pagina + 1,
        '...',
        totalPaginas
    ];
}


/* ==========================================================================
   EDICIÓN DE META STOCK
============================================================================ */

function registrarEventosFilas() {
    document
        .querySelectorAll('.input-meta')
        .forEach(input => {
            input.addEventListener('focus', manejarFocusMeta);
            input.addEventListener('input', manejarCambioMeta);
            input.addEventListener('blur', manejarBlurMeta);
            input.addEventListener('keydown', bloquearTeclasMeta);
        });

    document
        .querySelectorAll('.btn-guardar-meta')
        .forEach(boton => {
            boton.addEventListener('click', guardarMetaFila);
        });
}

function manejarFocusMeta(evento) {
    const input = evento.currentTarget;
    const numero = convertirMetaANumero(input.value);

    input.value = numero === ''
        ? ''
        : String(numero);

    input.select();
}

function manejarCambioMeta(evento) {
    const input = evento.currentTarget;
    const indiceOriginal = Number(
        input.dataset.indiceOriginal
    );

    let valor = input.value.replace(/[^0-9.,]/g, '');

    const cantidadComas = (valor.match(/,/g) || []).length;
    const cantidadPuntos = (valor.match(/\./g) || []).length;

    if (cantidadComas > 1) {
        const primera = valor.indexOf(',');

        valor =
            valor.substring(0, primera + 1) +
            valor.substring(primera + 1).replace(/,/g, '');
    }

    if (cantidadPuntos > 1) {
        const primero = valor.indexOf('.');

        valor =
            valor.substring(0, primero + 1) +
            valor.substring(primero + 1).replace(/\./g, '');
    }

    input.value = valor;

    const numero = convertirMetaANumero(valor);

    datosActuales[indiceOriginal].MetaStock =
        valor.trim() === ''
            ? ''
            : numero;

    actualizarEstadoFila(indiceOriginal);
}

function manejarBlurMeta(evento) {
    const input = evento.currentTarget;
    const indiceOriginal = Number(
        input.dataset.indiceOriginal
    );

    const texto = input.value.trim();
    const numero = convertirMetaANumero(texto);

    if (texto !== '' && numero === '') {
        input.value = '';
        datosActuales[indiceOriginal].MetaStock = '';

        mostrarAlerta(
            'warning',
            'La Meta Stock ingresada no es válida.'
        );

        actualizarEstadoFila(indiceOriginal);
        return;
    }

    if (numero !== '' && numero < 0) {
        input.value = '';
        datosActuales[indiceOriginal].MetaStock = '';

        mostrarAlerta(
            'warning',
            'La Meta Stock no puede ser negativa.'
        );

        actualizarEstadoFila(indiceOriginal);
        return;
    }

    datosActuales[indiceOriginal].MetaStock =
        numero === ''
            ? ''
            : Number(numero.toFixed(2));

    input.value = numero === ''
        ? ''
        : formatearMeta(numero);

    actualizarEstadoFila(indiceOriginal);

    if (
        filtrosExcel.MetaStock instanceof Set ||
        ordenActual.campo === 'MetaStock'
    ) {
        aplicarFiltrosYOrden();
    }
}

function bloquearTeclasMeta(evento) {
    const permitidas = [
        'Backspace',
        'Delete',
        'Tab',
        'Enter',
        'Escape',
        'ArrowLeft',
        'ArrowRight',
        'ArrowUp',
        'ArrowDown',
        'Home',
        'End'
    ];

    if (
        permitidas.includes(evento.key) ||
        evento.ctrlKey ||
        evento.metaKey
    ) {
        return;
    }

    if (!/[0-9.,]/.test(evento.key)) {
        evento.preventDefault();
    }
}

function actualizarEstadoFila(indiceOriginal) {
    const filaActual = datosActuales[indiceOriginal];
    const filaOriginal = datosOriginales[indiceOriginal];

    if (!filaActual || !filaOriginal) {
        return;
    }

    const actual =
        convertirMetaANumero(filaActual.MetaStock);

    const original =
        convertirMetaANumero(filaOriginal.MetaStock);

    const modificada =
        String(actual) !== String(original);

    const input = document.querySelector(
        `.input-meta[data-indice-original="${indiceOriginal}"]`
    );

    const boton = document.querySelector(
        `.btn-guardar-meta[data-indice-original="${indiceOriginal}"]`
    );

    input?.classList.toggle(
        'input-meta-modificado',
        modificada
    );

    if (boton) {
        boton.disabled = !modificada;
    }
}

/* ==========================================================================
   CARGAR DATOS
============================================================================ */

async function buscarDatos({
    mostrarMensajeExito = true
} = {}) {
    ocultarAlerta();
    limpiarMensajeTabla();

    const anio = selectAnio.value;

    if (!anio) {
        mostrarAlerta(
            'warning',
            'Debe seleccionar el año de la meta.'
        );

        selectAnio.focus();
        return false;
    }

    const htmlNormalBuscar = `
        <i class="bi bi-search"></i>
        <span>Información cargada</span>
    `;

    establecerCargaBoton(
        btnBuscar,
        true,
        htmlNormalBuscar,
        'Cargando...'
    );

    btnExportar.disabled = true;
    mostrarEstadoCargando();

    try {
        const formulario = new FormData();

        formulario.append('action', 'buscar');
        formulario.append('anio', anio);

        const respuesta = await fetch(
            window.location.href,
            {
                method: 'POST',
                body: formulario,
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        );

        const resultado =
            await leerRespuestaJson(respuesta);

        const datosRecibidos = Array.isArray(resultado.datos)
            ? resultado.datos
            : [];

        datosActuales = datosRecibidos.map(
            (fila, indice) => ({
                ...fila,
                _indiceOriginal: indice,
                MetaStock:
                    fila.MetaStock === null ||
                    fila.MetaStock === undefined
                        ? ''
                        : fila.MetaStock
            })
        );

        datosOriginales = clonarDatos(datosActuales);
        limpiarFiltrosInternos();

        if (datosActuales.length === 0) {
            mostrarEstadoSinResultados();
            totalRegistros.textContent = '0';
        } else {
            paginaActual = 1;
aplicarFiltrosYOrden();
 restaurarUltimaFilaGuardada();
        }

        /*if (mostrarMensajeExito) {
            mostrarAlerta(
                'success',
                `Se cargaron ${datosActuales.length} registros ` +
                `para el año ${anio}.`
            );
        }*/

        return true;
    } catch (error) {
        datosActuales = [];
        datosOriginales = [];

        limpiarFiltrosInternos();
        mostrarEstadoInicial();

        totalRegistros.textContent = '0';

        mostrarAlerta(
            'danger',
            obtenerMensajeError(error)
        );

        return false;
    } finally {
        establecerCargaBoton(
            btnBuscar,
            false,
            htmlNormalBuscar,
            'Cargando...'
        );

        actualizarEstadoBotones();
    }
}

/* ==========================================================================
   GUARDAR UNA FILA
============================================================================ */
async function guardarMetaFila(evento) {
    const boton = evento.currentTarget;

    const indiceOriginal = Number(
        boton.dataset.indiceOriginal
    );

    const fila = datosActuales[indiceOriginal];
    const anio = selectAnio.value;

    if (!fila) {
        mostrarAlerta(
            'danger',
            'No se encontró la fila seleccionada.'
        );

        return;
    }

    if (!anio) {
        mostrarAlerta(
            'warning',
            'Debe seleccionar el año.'
        );

        return;
    }

    const metaNumero =
        convertirMetaANumero(fila.MetaStock);

    if (
        metaNumero === '' ||
        !Number.isFinite(metaNumero)
    ) {
        mostrarAlerta(
            'warning',
            'Debe ingresar una Meta Stock válida.'
        );

        document.querySelector(
            `.input-meta[data-indice-original="${indiceOriginal}"]`
        )?.focus();

        return;
    }

    if (metaNumero < 0) {
        mostrarAlerta(
            'warning',
            'La Meta Stock no puede ser negativa.'
        );

        return;
    }

    const htmlNormal = `
        <i class="bi bi-floppy"></i>
        Guardar
    `;

    establecerCargaBoton(
        boton,
        true,
        htmlNormal,
        'Guardando...'
    );

    ocultarAlerta();

    /*
     * Guardar la ubicación de la fila.
     * Esto permitirá regresar a ella después de recargar.
     */
    const posicionGuardada = {
        anio: anio,
        pagina: paginaActual,
        scrollY: window.scrollY,

        NUMDPTO: String(fila.NUMDPTO ?? ''),
        NUMSECCION: String(fila.NUMSECCION ?? ''),
        NUMFAMILIA: String(fila.NUMFAMILIA ?? '')
    };

    try {
        const formulario = new FormData();

        formulario.append('action', 'guardar');
        formulario.append('anio', anio);

        formulario.append(
            'filas',
            JSON.stringify([
                {
                    NUMDPTO: fila.NUMDPTO,
                    DEPARTAMENTO: fila.DEPARTAMENTO,

                    NUMSECCION: fila.NUMSECCION,
                    SECCION: fila.SECCION,

                    NUMFAMILIA: fila.NUMFAMILIA,
                    FAMILIA: fila.FAMILIA,

                    MetaStock: Number(
                        metaNumero.toFixed(2)
                    )
                }
            ])
        );

        const respuesta = await fetch(
            window.location.href,
            {
                method: 'POST',
                body: formulario,
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        );

        const resultado =
            await leerRespuestaJson(respuesta);

        /*
         * MetaStock se guarda exactamente con el valor ingresado.
         * La Meta mínima no modifica este campo.
         */
        const detalleGuardado =
            Array.isArray(resultado.resultados)
                ? resultado.resultados[0]
                : null;

        const valorGuardado =
            detalleGuardado &&
            Number.isFinite(
                Number(detalleGuardado.metaGuardada)
            )
                ? Number(detalleGuardado.metaGuardada)
                : Number(metaNumero.toFixed(2));

        datosActuales[indiceOriginal].MetaStock =
            valorGuardado;

        datosOriginales[indiceOriginal].MetaStock =
            valorGuardado;

        const input = document.querySelector(
            `.input-meta[data-indice-original="${indiceOriginal}"]`
        );

        if (input) {
            input.value =
                formatearMeta(valorGuardado);

            input.classList.remove(
                'input-meta-modificado'
            );
        }

        sessionStorage.setItem(
            'ultimaFilaMetaInventario',
            JSON.stringify(posicionGuardada)
        );

        mostrarAlerta(
            'success',
            resultado.msg ||
            'La Meta Stock se guardó correctamente.'
        );

        /*
         * Mantener la posición también cuando no
         * se recarga la página.
         */
        window.requestAnimationFrame(() => {
            window.scrollTo({
                top: posicionGuardada.scrollY,
                behavior: 'auto'
            });
        });
    } catch (error) {
        mostrarAlerta(
            'danger',
            obtenerMensajeError(error)
        );
    } finally {
        boton.innerHTML = htmlNormal;

        actualizarEstadoFila(
            indiceOriginal
        );
    }
}

function restaurarUltimaFilaGuardada() {
    const contenido = sessionStorage.getItem(
        'ultimaFilaMetaInventario'
    );

    if (!contenido) {
        return;
    }

    let posicion;

    try {
        posicion = JSON.parse(contenido);
    } catch (error) {
        sessionStorage.removeItem(
            'ultimaFilaMetaInventario'
        );

        return;
    }

    if (
        String(posicion.anio) !==
        String(selectAnio.value)
    ) {
        return;
    }

    const datosFiltrados =
        obtenerDatosFiltradosYOrdenados();

    const posicionEnDatos =
        datosFiltrados.findIndex(fila => {
            return (
                String(fila.NUMDPTO ?? '') ===
                    String(posicion.NUMDPTO ?? '') &&

                String(fila.NUMSECCION ?? '') ===
                    String(posicion.NUMSECCION ?? '') &&

                String(fila.NUMFAMILIA ?? '') ===
                    String(posicion.NUMFAMILIA ?? '')
            );
        });

    if (posicionEnDatos < 0) {
        return;
    }

    paginaActual = Math.floor(
        posicionEnDatos / registrosPorPagina
    ) + 1;

    aplicarFiltrosYOrden({
        conservarPagina: true
    });

    window.requestAnimationFrame(() => {
        const filaEncontrada =
            [...tbodyResultados.querySelectorAll('tr')]
                .find(filaTabla => {
                    const indice = Number(
                        filaTabla.dataset.indiceOriginal
                    );

                    const registro =
                        datosActuales[indice];

                    if (!registro) {
                        return false;
                    }

                    return (
                        String(registro.NUMDPTO ?? '') ===
                            String(posicion.NUMDPTO ?? '') &&

                        String(registro.NUMSECCION ?? '') ===
                            String(posicion.NUMSECCION ?? '') &&

                        String(registro.NUMFAMILIA ?? '') ===
                            String(posicion.NUMFAMILIA ?? '')
                    );
                });

        if (filaEncontrada) {
            filaEncontrada.scrollIntoView({
                behavior: 'auto',
                block: 'center'
            });

            filaEncontrada.classList.add(
                'fila-ultima-guardada'
            );

            const input =
                filaEncontrada.querySelector(
                    '.input-meta'
                );

            input?.focus({
                preventScroll: true
            });

            window.setTimeout(() => {
                filaEncontrada.classList.remove(
                    'fila-ultima-guardada'
                );
            }, 2500);
        } else {
            window.scrollTo({
                top: Number(posicion.scrollY) || 0,
                behavior: 'auto'
            });
        }

        sessionStorage.removeItem(
            'ultimaFilaMetaInventario'
        );
    });
}

/* ==========================================================================
   PANEL DE FILTROS
============================================================================ */

function abrirPanelFiltro(boton) {
    const campo = boton.dataset.campo;
    const label = boton.dataset.label || campo;

    campoFiltroActivo = campo;
    botonFiltroActivo = boton;

    excelPanelTitle.textContent = label;
    inputBuscarValores.value = '';

    crearListaValoresFiltro(
        obtenerValoresDisponibles(campo),
        filtrosExcel[campo],
        campo
    );

    excelFilterPanel.classList.add('show', 'active');
    posicionarPanelFiltro(boton);

    window.setTimeout(() => {
        inputBuscarValores.disabled = false;
        inputBuscarValores.readOnly = false;
        inputBuscarValores.focus();
    }, 20);
}

function cerrarPanelFiltro() {
    excelFilterPanel.classList.remove('show', 'active');

    campoFiltroActivo = null;
    botonFiltroActivo = null;
}

function posicionarPanelFiltro(boton) {
    const rect = boton.getBoundingClientRect();
    const margen = 10;
    const separacion = 6;

    const anchoPanel = Math.min(
        310,
        window.innerWidth - (margen * 2)
    );

    excelFilterPanel.style.width = `${anchoPanel}px`;
    excelFilterPanel.style.maxHeight =
        `${window.innerHeight - (margen * 2)}px`;

    const alturaPanel = Math.min(
        excelFilterPanel.scrollHeight,
        window.innerHeight - (margen * 2)
    );

    const espacioAbajo =
        window.innerHeight - rect.bottom - margen;

    const espacioArriba =
        rect.top - margen;

    let arriba;

    if (espacioAbajo >= alturaPanel) {
        arriba = rect.bottom + separacion;
    } else if (espacioArriba >= alturaPanel) {
        arriba = rect.top - alturaPanel - separacion;
    } else {
        arriba = margen;
    }

    let izquierda =
        rect.right - anchoPanel;

    if (izquierda < margen) {
        izquierda = margen;
    }

    if (
        izquierda + anchoPanel >
        window.innerWidth - margen
    ) {
        izquierda =
            window.innerWidth -
            anchoPanel -
            margen;
    }

    excelFilterPanel.style.top =
        `${Math.max(margen, arriba)}px`;

    excelFilterPanel.style.left =
        `${izquierda}px`;
}

function crearListaValoresFiltro(
    valores,
    seleccionGuardada,
    campo
) {
    valueList.innerHTML = '';

    const tieneFiltro =
        seleccionGuardada instanceof Set;

    valores.forEach((valor, indice) => {
        const id = `filtro_${campo}_${indice}`;

        const seleccionado = tieneFiltro
            ? seleccionGuardada.has(valor)
            : true;

        const textoVisible =
            valorVisibleFiltro(valor, campo);

        const fila = document.createElement('label');

        fila.className =
            'check-row value-filter-row';

        fila.dataset.busqueda =
            normalizarTexto(textoVisible);

        const checkbox =
            document.createElement('input');

        checkbox.type = 'checkbox';
        checkbox.className = 'check-valor-filtro';
        checkbox.id = id;
        checkbox.value = valor;
        checkbox.checked = seleccionado;

        const texto =
            document.createElement('span');

        texto.textContent = textoVisible;
        texto.title = textoVisible;

        fila.appendChild(checkbox);
        fila.appendChild(texto);
        valueList.appendChild(fila);
    });

    actualizarSeleccionarTodo();
}

function actualizarSeleccionarTodo() {
    const visibles = [
        ...valueList.querySelectorAll(
            '.value-filter-row:not(.d-none) ' +
            '.check-valor-filtro'
        )
    ];

    if (visibles.length === 0) {
        checkSelectAll.checked = false;
        checkSelectAll.indeterminate = false;
        return;
    }

    const seleccionados = visibles.filter(
        checkbox => checkbox.checked
    ).length;

    checkSelectAll.checked =
        seleccionados === visibles.length;

    checkSelectAll.indeterminate =
        seleccionados > 0 &&
        seleccionados < visibles.length;
}

function aplicarFiltroColumna() {
    if (!campoFiltroActivo) {
        return;
    }

    const hayBusqueda =
        inputBuscarValores.value.trim() !== '';

    const selector = hayBusqueda
        ? '.value-filter-row:not(.d-none) .check-valor-filtro'
        : '.check-valor-filtro';

    const checkboxesConsiderados = [
        ...valueList.querySelectorAll(selector)
    ];

    const valoresSeleccionados =
        checkboxesConsiderados
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);

    /*
    Si hay texto escrito en el buscador, solo se aplican los
    valores visibles encontrados. Los valores ocultos no se incluyen.
    */
    filtrosExcel[campoFiltroActivo] =
        new Set(valoresSeleccionados);

    /*
    Solo se elimina el filtro cuando no hay búsqueda y todos
    los valores de la columna están seleccionados.
    */
    if (!hayBusqueda) {
        const todos = [
            ...valueList.querySelectorAll(
                '.check-valor-filtro'
            )
        ];

        if (
            todos.length > 0 &&
            valoresSeleccionados.length === todos.length
        ) {
            delete filtrosExcel[campoFiltroActivo];
        }
    }

    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function limpiarFiltroColumna() {
    if (!campoFiltroActivo) {
        return;
    }

    delete filtrosExcel[campoFiltroActivo];

    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function quitarTodosLosFiltros() {
    Object.keys(filtrosExcel).forEach(campo => {
        delete filtrosExcel[campo];
    });

    ordenActual = {
        campo: null,
        direccion: null
    };

    cerrarPanelFiltro();

    paginaActual = 1;
    aplicarFiltrosYOrden();
}

function limpiarFiltrosInternos() {
    Object.keys(filtrosExcel).forEach(campo => {
        delete filtrosExcel[campo];
    });

    ordenActual = {
        campo: null,
        direccion: null
    };

    cerrarPanelFiltro();
    actualizarIconosFiltros();
}

function ordenarColumna(direccion) {
    if (!campoFiltroActivo) {
        return;
    }

    ordenActual = {
        campo: campoFiltroActivo,
        direccion
    };

    cerrarPanelFiltro();
    aplicarFiltrosYOrden();
}

function actualizarIconosFiltros() {
    document
        .querySelectorAll('.btn-filter-excel')
        .forEach(boton => {
            const campo = boton.dataset.campo;

            const filtroActivo =
                filtrosExcel[campo] instanceof Set;

            const ordenActivo =
                ordenActual.campo === campo;

            boton.classList.toggle(
                'filter-active',
                filtroActivo || ordenActivo
            );

            boton.classList.toggle(
                'filtro-activo',
                filtroActivo || ordenActivo
            );

            const icono = boton.querySelector('i');

            if (!icono) {
                return;
            }

            if (filtroActivo) {
                icono.className =
                    'bi bi-funnel-fill';
            } else if (ordenActivo) {
                icono.className =
                    ordenActual.direccion === 'asc'
                        ? 'bi bi-sort-up'
                        : 'bi bi-sort-down';
            } else {
                icono.className =
                    'bi bi-funnel';
            }
        });
}

/* ==========================================================================
   EXPORTAR
============================================================================ */

function escaparCsv(valor) {
    const texto = String(valor ?? '')
        .replace(/"/g, '""');

    return `"${texto}"`;
}

function exportarExcel() {
    ocultarAlerta();

    // Exporta únicamente los registros que cumplen los filtros activos
    const datos = obtenerDatosFiltradosYOrdenados();

    if (datos.length === 0) {
        mostrarAlerta(
            'warning',
            'No hay registros filtrados para exportar.'
        );
        return;
    }

    const anio = selectAnio.value;

    const fechaExportacion = new Intl.DateTimeFormat('es-HN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date());

    let filasHtml = '';

    datos.forEach((fila, indice) => {
        const metaNumero = convertirMetaANumero(fila.MetaStock);

        const metaExportar =
            metaNumero === ''
                ? ''
                : Number(metaNumero).toFixed(2);

        filasHtml += `
            <tr>
                <td class="centrado">${indice + 1}</td>

                <td class="texto">
                    ${escaparHtml(fila.NOMNEGOCIOICG || 'MENDELS HN')}
                </td>

                <!-- Usamos 'centrado' para pasarlos como números enteros nativos y remover el triángulo verde -->
                <td class="centrado">
                    ${escaparHtml(fila.NUMDPTO)}
                </td>

                <td class="texto">
                    ${escaparHtml(fila.DEPARTAMENTO)}
                </td>

                <td class="centrado">
                    ${escaparHtml(fila.NUMSECCION)}
                </td>

                <td class="texto">
                    ${escaparHtml(fila.SECCION)}
                </td>

                <td class="centrado">
                    ${escaparHtml(fila.NUMFAMILIA)}
                </td>

                <td class="texto">
                    ${escaparHtml(fila.FAMILIA)}
                </td>

                <td class="numero">
                    ${escaparHtml(metaExportar)}
                </td>

                <td class="centrado">
                    ${escaparHtml(anio)}
                </td>
            </tr>
        `;
    });

    const contenidoExcel = `
        <!DOCTYPE html>
        <html
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns="http://www.w3.org/TR/REC-html40"
        >
        <head>
            <meta charset="UTF-8">

            <!--[if gte mso 9]>
            <xml>
                <x:ExcelWorkbook>
                    <x:ExcelWorksheets>
                        <x:ExcelWorksheet>
                            <x:Name>Metas Inventario</x:Name>

                            <x:WorksheetOptions>
                                <x:DisplayGridlines>False</x:DisplayGridlines>
                                <x:FreezePanes/>
                                <x:FrozenNoSplit/>
                                <x:SplitHorizontal>5</x:SplitHorizontal>
                                <x:TopRowBottomPane>5</x:TopRowBottomPane>
                            </x:WorksheetOptions>
                        </x:ExcelWorksheet>
                    </x:ExcelWorksheets>
                </x:ExcelWorkbook>
            </xml>
            <![endif]-->

            <style>
                body {
                    font-family: Calibri, Arial, sans-serif;
                    font-size: 18px;
                    color: #333333;
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                }

                .titulo-principal {
                    height: 35px;
                    color: #1e3a8a;
                    font-size: 18px;
                    font-weight: bold;
                    text-align: left;
                    vertical-align: middle;
                }

                .informacion {
                    height: 20px;
                    color: #555555;
                    font-size: 18px;
                    text-align: left;
                    vertical-align: middle;
                }

                thead th {
                    height: 26px;
                    padding: 4px;
                    color: #ffffff;
                    background: #1e3a8a;
                    border: 1px solid #1e3a8a;
                    font-size: 18px;
                    font-weight: bold;
                    text-align: center;
                    vertical-align: middle;
                }

                tbody td {
                    height: 22px;
                    padding: 4px;
                    background: #ffffff;
                    border: 1px solid #e5e7eb;
                    font-size: 18px;
                    vertical-align: middle;
                }

                tbody tr:nth-child(even) td {
                    background: #f9fafb;
                }

                .centrado {
                    text-align: center;
                }

                .texto {
                    text-align: left;
                }

                .numero {
                    text-align: right;
                    mso-number-format: "0.00";
                }

                .pie {
                    height: 24px;
                    color: #333333;
                    border-top: 2px solid #1e3a8a;
                    font-size: 18px;
                    font-weight: bold;
                    text-align: left;
                    vertical-align: middle;
                }
            </style>
        </head>

        <!-- color de fondo blanco explícito para forzar la eliminación de las líneas de cuadrícula -->
        <body style="background-color: #ffffff;">
            <table>
                <colgroup>
                    <col style="width:50px">
                    <col style="width:140px">
                    <col style="width:85px">
                    <col style="width:180px">
                    <col style="width:95px">
                    <col style="width:190px">
                    <col style="width:95px">
                    <col style="width:220px">
                    <col style="width:110px">
                    <col style="width:75px">
                </colgroup>

                <tr>
                    <td colspan="10" class="titulo-principal">
                        METAS DE INVENTARIO
                    </td>
                </tr>

                <tr>
                    <td colspan="5" class="informacion">
                        Año de la meta: ${escaparHtml(anio)}
                    </td>

                    <td colspan="5" class="informacion" style="text-align: right;">
                        Fecha de exportación: ${escaparHtml(fechaExportacion)}
                    </td>
                </tr>

                <tr>
                    <td colspan="10" class="informacion" style="border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">
                        Registros exportados: ${datos.length}
                    </td>
                </tr>

                <tr><td colspan="10" style="height: 10px;"></td></tr>

                <thead>
                    <tr>
                        <th>No.</th>
                        <th>NEGOCIO ICG</th>
                        <th>NUMDPTO</th>
                        <th>DEPARTAMENTO</th>
                        <th>NUMSECCION</th>
                        <th>SECCIÓN</th>
                        <th>NUMFAMILIA</th>
                        <th>FAMILIA</th>
                        <th>META STOCK</th>
                        <th>AÑO</th>
                    </tr>
                </thead>

                <tbody>
                    ${filasHtml}
                </tbody>
            </table>
        </body>
        </html>
    `;

    const blob = new Blob(
        ['\uFEFF' + contenidoExcel],
        {
            type: 'application/vnd.ms-excel;charset=utf-8;'
        }
    );

    const url = URL.createObjectURL(blob);
    const enlace = document.createElement('a');
    enlace.href = url;
    enlace.download = `metas_inventario${anio}.xls`;
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(url);

    mostrarAlerta(
        'success',
        `Se exportaron ${datos.length} registros en formato Excel.`
    );
}


/* ==========================================================================
   ESTADO DE BOTONES
============================================================================ */

function actualizarEstadoBotones() {
    btnExportar.disabled =
        datosActuales.length === 0;
}

/* ==========================================================================
   EVENTOS
============================================================================ */

document
    .querySelectorAll('.btn-filter-excel')
    .forEach(boton => {
        boton.addEventListener('click', evento => {
            evento.preventDefault();
            evento.stopPropagation();
            abrirPanelFiltro(boton);
        });
    });

btnCerrarPanel.addEventListener(
    'click',
    cerrarPanelFiltro
);

btnOrdenAsc.addEventListener(
    'click',
    () => ordenarColumna('asc')
);

btnOrdenDesc.addEventListener(
    'click',
    () => ordenarColumna('desc')
);

btnAplicarFiltro.addEventListener(
    'click',
    aplicarFiltroColumna
);

btnLimpiarFiltro.addEventListener(
    'click',
    limpiarFiltroColumna
);

btnLimpiarSoloFiltros.addEventListener(
    'click',
    quitarTodosLosFiltros
);

/*
El buscador solo muestra u oculta opciones.
No borra selecciones ni cierra el panel.
Al aplicar con texto escrito, se usan únicamente
los valores visibles encontrados.
*/
inputBuscarValores.addEventListener('input', () => {
    const busqueda = normalizarTexto(
        inputBuscarValores.value
    );

    valueList
        .querySelectorAll('.value-filter-row')
        .forEach(fila => {
            const coincide =
                (fila.dataset.busqueda || '')
                    .includes(busqueda);

            fila.classList.toggle(
                'd-none',
                !coincide
            );
        });

    actualizarSeleccionarTodo();
});

checkSelectAll.addEventListener('change', () => {
    const marcar = checkSelectAll.checked;

    valueList
        .querySelectorAll(
            '.value-filter-row:not(.d-none) ' +
            '.check-valor-filtro'
        )
        .forEach(checkbox => {
            checkbox.checked = marcar;
        });

    actualizarSeleccionarTodo();
});

valueList.addEventListener('change', evento => {
    if (
        evento.target.classList.contains(
            'check-valor-filtro'
        )
    ) {
        actualizarSeleccionarTodo();
    }
});

/*
Evitar que el panel se cierre al hacer clic o escribir.
*/
excelFilterPanel.addEventListener(
    'mousedown',
    evento => evento.stopPropagation()
);

excelFilterPanel.addEventListener(
    'click',
    evento => evento.stopPropagation()
);

inputBuscarValores.addEventListener(
    'mousedown',
    evento => evento.stopPropagation()
);

inputBuscarValores.addEventListener(
    'click',
    evento => evento.stopPropagation()
);

inputBuscarValores.addEventListener(
    'keydown',
    evento => evento.stopPropagation()
);

/*
Cerrar únicamente al hacer clic fuera del panel.
*/
document.addEventListener('mousedown', evento => {
    const enPanel =
        excelFilterPanel.contains(evento.target);

    const enBotonFiltro =
        evento.target.closest('.btn-filter-excel');

    if (!enPanel && !enBotonFiltro) {
        cerrarPanelFiltro();
    }
});

window.addEventListener(
    'resize',
    cerrarPanelFiltro
);

window.addEventListener(
    'scroll',
    evento => {
        // No cerrar cuando se desplaza la lista dentro del filtro
        if (excelFilterPanel.contains(evento.target)) {
            return;
        }

        cerrarPanelFiltro();
    },
    true
);

btnBuscar.addEventListener(
    'click',
    () => buscarDatos()
);

btnExportar.addEventListener(
    'click',
    exportarExcel
);

selectAnio.addEventListener('change', () => {
    datosActuales = [];
    datosOriginales = [];
    paginaActual = 1;

    limpiarFiltrosInternos();
    limpiarMensajeTabla();
    ocultarAlerta();

    totalRegistros.textContent = '0';
    btnExportar.disabled = true;

    mostrarEstadoInicial();
});

/* ==========================================================================
   INICIO
============================================================================ */

crearControlesPaginacion();
actualizarEstadoBotones();
actualizarIconosFiltros();

const ultimaFilaPendiente =
    sessionStorage.getItem(
        'ultimaFilaMetaInventario'
    );

if (ultimaFilaPendiente) {
    try {
        const posicion =
            JSON.parse(ultimaFilaPendiente);

        if (posicion.anio) {
            selectAnio.value =
                String(posicion.anio);

            buscarDatos({
                mostrarMensajeExito: false
            });
        }
    } catch (error) {
        sessionStorage.removeItem(
            'ultimaFilaMetaInventario'
        );
    }
}
