'use strict';

const catalogo = window.META_MINIMA_CATALOGO || [];

const form = document.getElementById('formMetaMinima');
const nombreRegla = document.getElementById('nombreRegla');
const selectDepartamento = document.getElementById('departamento');
const selectSeccion = document.getElementById('seccion');
const selectFamilia = document.getElementById('familia');
const selectTipoRegla = document.getElementById('tipoRegla');
const inputMetaMinima = document.getElementById('metaMinima');
const selectEstado = document.getElementById('estado');
const textoAlcance = document.getElementById('textoAlcance');
const valorMinimoResumen = document.getElementById('valorMinimoResumen');
const labelValorRegla = document.getElementById('labelValorRegla');
const captionValorRegla = document.getElementById('captionValorRegla');
const labelResumenRegla = document.getElementById('labelResumenRegla');
const alertaLocal = document.getElementById('alertaLocal');
const btnLimpiar = document.getElementById('btnLimpiar');
const btnGuardar = document.getElementById('btnGuardar');
const modoFormulario = document.getElementById('modoFormulario');
const originalNumDpto = document.getElementById('originalNumDpto');
const originalNumSeccion = document.getElementById('originalNumSeccion');
const originalNumFamilia = document.getElementById('originalNumFamilia');

function escaparHtml(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function mostrarAlerta(tipo, mensaje) {
    alertaLocal.className =
        `alert alert-${tipo} alerta-local`;

    alertaLocal.textContent = mensaje;
    alertaLocal.style.display = 'block';
}

function ocultarAlerta() {
    alertaLocal.style.display = 'none';
    alertaLocal.textContent = '';
}

function obtenerDepartamentos() {
    const mapa = new Map();

    catalogo.forEach(fila => {
        const clave = String(fila.NUMDPTO);

        if (!mapa.has(clave)) {
            mapa.set(clave, {
                codigo: fila.NUMDPTO,
                descripcion: fila.DEPARTAMENTO
            });
        }
    });

    return [...mapa.values()].sort(
        (a, b) =>
            Number(a.codigo) -
            Number(b.codigo)
    );
}

function cargarDepartamentos() {
    selectDepartamento.innerHTML = `
        <option value="">
            Seleccione un departamento
        </option>
    `;

    obtenerDepartamentos().forEach(item => {
        const option =
            document.createElement('option');

        option.value = item.codigo;

        option.textContent =
            `${item.codigo} - ${item.descripcion}`;

        selectDepartamento.appendChild(option);
    });
}

function cargarSecciones() {
    const numDpto =
        Number(selectDepartamento.value);

    selectSeccion.innerHTML = `
        <option value="">
            Todas las secciones
        </option>
    `;

    selectFamilia.innerHTML = `
        <option value="">
            Todas las familias
        </option>
    `;

    selectFamilia.disabled = true;

    if (!selectDepartamento.value) {
        selectSeccion.disabled = true;
        actualizarResumen();
        return;
    }

    const mapa = new Map();

    catalogo
        .filter(
            fila =>
                fila.NUMDPTO === numDpto
        )
        .forEach(fila => {
            const clave =
                String(fila.NUMSECCION);

            if (!mapa.has(clave)) {
                mapa.set(clave, {
                    codigo: fila.NUMSECCION,
                    descripcion: fila.SECCION
                });
            }
        });

    [...mapa.values()]
        .sort(
            (a, b) =>
                Number(a.codigo) -
                Number(b.codigo)
        )
        .forEach(item => {
            const option =
                document.createElement('option');

            option.value = item.codigo;

            option.textContent =
                `${item.codigo} - ${item.descripcion}`;

            selectSeccion.appendChild(option);
        });

    selectSeccion.disabled = false;
    actualizarResumen();
}

function cargarFamilias() {
    const numDpto =
        Number(selectDepartamento.value);

    const numSeccion =
        Number(selectSeccion.value);

    selectFamilia.innerHTML = `
        <option value="">
            Todas las familias
        </option>
    `;

    if (!selectSeccion.value) {
        selectFamilia.disabled = true;
        actualizarResumen();
        return;
    }

    catalogo
        .filter(
            fila =>
                fila.NUMDPTO === numDpto &&
                fila.NUMSECCION === numSeccion
        )
        .sort(
            (a, b) =>
                Number(a.NUMFAMILIA) -
                Number(b.NUMFAMILIA)
        )
        .forEach(fila => {
            const option =
                document.createElement('option');

            option.value = fila.NUMFAMILIA;

            option.textContent =
                `${fila.NUMFAMILIA} - ${fila.FAMILIA}`;

            selectFamilia.appendChild(option);
        });

    selectFamilia.disabled = false;
    actualizarResumen();
}

function textoSeleccion(select, textoDefault) {
    if (!select.value) {
        return textoDefault;
    }

    return (
        select.options[select.selectedIndex]
            ?.textContent
            ?.trim()
        || textoDefault
    );
}

function formatearMetaMinima(valor) {
    const numero = Number(valor);

    if (!Number.isFinite(numero)) {
        return '—';
    }

    return numero.toLocaleString(
        'es-HN',
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }
    );
}

function obtenerTipoRegla() {
    return selectTipoRegla?.value === 'MAXIMO'
        ? 'MAXIMO'
        : 'MINIMO';
}

function actualizarTextosTipoRegla() {
    const esMaximo =
        obtenerTipoRegla() === 'MAXIMO';

    if (labelValorRegla) {
        labelValorRegla.textContent =
            esMaximo ? 'Meta máxima' : 'Meta mínima';
    }

    if (captionValorRegla) {
        captionValorRegla.textContent =
            esMaximo
                ? 'Si el cálculo supera este valor, se limitará a este máximo.'
                : 'Si el cálculo queda por debajo, se elevará a este mínimo.';
    }

    if (labelResumenRegla) {
        labelResumenRegla.textContent =
            esMaximo ? 'Meta máxima' : 'Meta mínima';
    }
}

function actualizarResumen() {
    actualizarTextosTipoRegla();

    const valorRegla =
        inputMetaMinima.value.trim() === ''
            ? '—'
            : formatearMetaMinima(
                inputMetaMinima.value
            );

    valorMinimoResumen.textContent = valorRegla;

    if (!selectDepartamento.value) {
        textoAlcance.textContent =
            'Seleccione un departamento para visualizar el alcance.';
        return;
    }

    const departamento =
        textoSeleccion(
            selectDepartamento,
            'Sin departamento'
        );

    const seccion =
        textoSeleccion(
            selectSeccion,
            'Todas las secciones'
        );

    const familia =
        textoSeleccion(
            selectFamilia,
            'Todas las familias'
        );

    if (!selectSeccion.value) {
        textoAlcance.innerHTML =
            `Aplicará a <strong>todo el departamento</strong> ` +
            `${escaparHtml(departamento)}.`;

        return;
    }

    if (!selectFamilia.value) {
        textoAlcance.innerHTML =
            `Aplicará a <strong>toda la sección</strong> ` +
            `${escaparHtml(seccion)}.`;

        return;
    }

    textoAlcance.innerHTML =
        `Aplicará únicamente a la familia ` +
        `<strong>${escaparHtml(familia)}</strong>.`;
}

function limpiarFormulario() {
    form.reset();

    modoFormulario.value = 'crear';
    originalNumDpto.value = '';
    originalNumSeccion.value = '';
    originalNumFamilia.value = '';

    btnGuardar.innerHTML = `
        <i class="bi bi-floppy me-1"></i>
        Guardar 
    `;

    selectSeccion.innerHTML = `
        <option value="">
            Todas las secciones
        </option>
    `;

    selectFamilia.innerHTML = `
        <option value="">
            Todas las familias
        </option>
    `;

    selectSeccion.disabled = true;
    selectFamilia.disabled = true;

    ocultarAlerta();
    actualizarResumen();

    nombreRegla.focus();
}


async function cargarConfiguracionParaEditar(config) {
    modoFormulario.value = 'editar';

    originalNumDpto.value = config.numdpto ?? '';
    originalNumSeccion.value = config.numseccion ?? '';
    originalNumFamilia.value = config.numfamilia ?? '';

    nombreRegla.value = config.nombre_regla ?? '';
    selectTipoRegla.value =
        String(config.tipo_regla ?? 'MINIMO').toUpperCase() === 'MAXIMO'
            ? 'MAXIMO'
            : 'MINIMO';
    inputMetaMinima.value = config.meta_minima ?? '';
    selectEstado.value = String(config.activo ?? '1');

    selectDepartamento.value = String(config.numdpto ?? '');
    cargarSecciones();

    if (config.numseccion !== '') {
        selectSeccion.value = String(config.numseccion);
        cargarFamilias();
    }

    if (config.numfamilia !== '') {
        selectFamilia.value = String(config.numfamilia);
    }

    btnGuardar.innerHTML = `
        <i class="bi bi-check2-circle me-1"></i>
        Actualizar configuración
    `;

    actualizarResumen();

    form.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });

    nombreRegla.focus();
}

document
    .querySelectorAll('.btn-editar-config')
    .forEach(boton => {
        boton.addEventListener('click', () => {
            try {
                const config = JSON.parse(
                    boton.dataset.config || '{}'
                );

                cargarConfiguracionParaEditar(config);
            } catch (error) {
                mostrarAlerta(
                    'danger',
                    'No se pudo cargar la configuración seleccionada.'
                );
            }
        });
    });


document
    .querySelectorAll('.btn-estado-config')
    .forEach(boton => {
        boton.addEventListener('click', async () => {
            const nuevoEstado =
                Number(boton.dataset.nuevoEstado);

            const nombre =
                boton.dataset.nombre ||
                'esta configuración';

            const accionTexto =
                nuevoEstado === 1
                    ? 'activar'
                    : 'desactivar';

            const confirmado = window.confirm(
                `¿Desea ${accionTexto} "${nombre}"?`
            );

            if (!confirmado) {
                return;
            }

            const htmlOriginal =
                boton.innerHTML;

            boton.disabled = true;
            boton.innerHTML = `
                <span
                    class="spinner-border spinner-border-sm"
                    aria-hidden="true"
                ></span>
            `;

            try {
                const datos = new FormData();

                datos.append(
                    'action',
                    'cambiar_estado_configuracion'
                );

                datos.append(
                    'numdpto',
                    boton.dataset.numdpto || ''
                );

                datos.append(
                    'numseccion',
                    boton.dataset.numseccion || ''
                );

                datos.append(
                    'numfamilia',
                    boton.dataset.numfamilia || ''
                );

                datos.append(
                    'nuevo_estado',
                    String(nuevoEstado)
                );

                const respuesta = await fetch(
                    window.location.href,
                    {
                        method: 'POST',
                        body: datos,
                        credentials: 'same-origin',
                        headers: {
                            'X-Requested-With':
                                'XMLHttpRequest'
                        }
                    }
                );

                const texto = await respuesta.text();

                let resultado;

                try {
                    resultado = JSON.parse(texto);
                } catch (error) {
                    throw new Error(
                        'El servidor devolvió una respuesta inválida: ' +
                        texto.substring(0, 300)
                    );
                }

                if (
                    !respuesta.ok ||
                    !resultado.ok
                ) {
                    throw new Error(
                        resultado.msg ||
                        'No se pudo cambiar el estado.'
                    );
                }

                mostrarAlerta(
                    'success',
                    resultado.msg
                );

                window.setTimeout(() => {
                    window.location.reload();
                }, 500);

            } catch (error) {
                mostrarAlerta(
                    'danger',
                    error.message ||
                    'Ocurrió un error al cambiar el estado.'
                );

                boton.disabled = false;
                boton.innerHTML =
                    htmlOriginal;
            }
        });
    });

selectDepartamento.addEventListener(
    'change',
    cargarSecciones
);

selectSeccion.addEventListener(
    'change',
    cargarFamilias
);

selectFamilia.addEventListener(
    'change',
    actualizarResumen
);

selectTipoRegla.addEventListener(
    'change',
    actualizarResumen
);

inputMetaMinima.addEventListener(
    'input',
    actualizarResumen
);

btnLimpiar.addEventListener(
    'click',
    limpiarFormulario
);

form.addEventListener(
    'submit',
    async evento => {
        evento.preventDefault();
        ocultarAlerta();

        if (!nombreRegla.value.trim()) {
            mostrarAlerta(
                'warning',
                'Debe ingresar el nombre de la regla.'
            );
            nombreRegla.focus();
            return;
        }

        if (!selectDepartamento.value) {
            mostrarAlerta(
                'warning',
                'Debe seleccionar un departamento.'
            );
            selectDepartamento.focus();
            return;
        }

        const meta = Number(inputMetaMinima.value);

        if (
            inputMetaMinima.value.trim() === '' ||
            !Number.isFinite(meta) ||
            meta < 0
        ) {
            mostrarAlerta(
                'warning',
                obtenerTipoRegla() === 'MAXIMO'
                    ? 'Debe ingresar una meta máxima válida.'
                    : 'Debe ingresar una meta mínima válida.'
            );
            inputMetaMinima.focus();
            return;
        }

        const btnGuardar =
            document.getElementById('btnGuardar');

        const htmlOriginal =
            btnGuardar.innerHTML;

        btnGuardar.disabled = true;
        btnGuardar.innerHTML = `
            <span
                class="spinner-border spinner-border-sm me-1"
                aria-hidden="true"
            ></span>
            Guardando...
        `;

        try {
            const datos = new FormData(form);
            datos.append(
                'action',
                modoFormulario.value === 'editar'
                    ? 'actualizar_configuracion'
                    : 'guardar_configuracion'
            );

            /*
             * Los SELECT deshabilitados no viajan en FormData.
             * Si no se eligió sección/familia, se envían vacíos
             * para que PHP los guarde como NULL.
             */
            if (selectSeccion.disabled) {
                datos.set('numseccion', '');
            }

            if (selectFamilia.disabled) {
                datos.set('numfamilia', '');
            }

            const respuesta = await fetch(
                window.location.href,
                {
                    method: 'POST',
                    body: datos,
                    credentials: 'same-origin',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                }
            );

            const texto = await respuesta.text();

            let resultado;

            try {
                resultado = JSON.parse(texto);
            } catch (error) {
                throw new Error(
                    'El servidor devolvió una respuesta inválida: ' +
                    texto.substring(0, 300)
                );
            }

            if (!respuesta.ok || !resultado.ok) {
                throw new Error(
                    resultado.msg ||
                    'No se pudo guardar la configuración.'
                );
            }

            /*
             * Limpiar primero y luego mostrar éxito,
             * porque limpiarFormulario() oculta las alertas.
             */
            mostrarAlerta(
                'success',
                resultado.msg
            );

            window.setTimeout(() => {
                window.location.reload();
            }, 600);

        } catch (error) {
            mostrarAlerta(
                'danger',
                error.message ||
                'Ocurrió un error al guardar.'
            );

        } finally {
            btnGuardar.disabled = false;
            btnGuardar.innerHTML = htmlOriginal;
        }
    }
);

cargarDepartamentos();
actualizarResumen();

/*
|--------------------------------------------------------------------------
| BOTÓN NUEVA CONFIGURACIÓN
|--------------------------------------------------------------------------
*/
const btnNuevaConfiguracion =
    document.getElementById('btnNuevaConfiguracion');

if (btnNuevaConfiguracion) {
    btnNuevaConfiguracion.addEventListener(
        'click',
        () => {
            limpiarFormulario();

            const panelFormulario =
                document.getElementById('panelNuevaRegla');

            if (panelFormulario) {
                panelFormulario.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    );
}

/*
|--------------------------------------------------------------------------
| CAMBIAR CANTIDAD DE REGLAS POR PÁGINA
|--------------------------------------------------------------------------
*/
const selectPorPagina =
    document.getElementById(
        'selectPorPagina'
    );

const formPorPagina =
    document.getElementById(
        'formPorPagina'
    );

if (
    selectPorPagina &&
    formPorPagina
) {
    selectPorPagina.addEventListener(
        'change',
        () => {
            formPorPagina.submit();
        }
    );
}
