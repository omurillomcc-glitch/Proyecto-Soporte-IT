<?php

declare(strict_types=1);

// Si alguien entra directo desde el navegador, se detiene el código
if (basename($_SERVER['PHP_SELF']) === 'conexion_sqlsrv.php') {
    header('HTTP/1.0 403 Forbidden');
    exit('Acceso denegado.');
}

$serverName = "10.0.1.157";

$connectionOptions = [
    "Database"                 => "vistasMCC", 
    "UID"                      => "icgadmin",
    "PWD"                      => "masterkey",
    "CharacterSet"             => "UTF-8",
    "TrustServerCertificate"   => true,
    "MultipleActiveResultSets" => true, // Permite múltiples consultas consecutivas
    "ConnectionPooling"        => true, // Reutiliza conexiones y reduce carga al servidor
    "LoginTimeout"             => 60    //Evita caídas por consultas pesadas por fechas
];

$sqlsrv_conn_exhibicion = sqlsrv_connect($serverName, $connectionOptions);

if ($sqlsrv_conn_exhibicion === false) {
    // Si la petición viene por AJAX, responde en JSON de forma limpia
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode([
            'ok' => false,
            'msg' => 'Error de conexión con la base de datos.',
            'error' => sqlsrv_errors()
        ]);
        exit;
    }

    die('<pre>Error al conectar con SQL Server: ' . print_r(sqlsrv_errors(), true) . '</pre>');
}
