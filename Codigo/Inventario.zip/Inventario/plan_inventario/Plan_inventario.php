<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PASO 1: INICIAR SESIÓN DEL SISTEMA
|--------------------------------------------------------------------------
*/
session_name('APP_INVENTARIO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| PASO 1: CARGAR AUTENTICACIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__. '/../usuarios/auth.php';

require_login();

/*
|--------------------------------------------------------------------------
| PASO 2: AUMENTAR TIEMPO DE EJECUCIÓN
|--------------------------------------------------------------------------
*/
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR CONEXIÓN SQL SERVER
|--------------------------------------------------------------------------
*/
require_once __DIR__. '/conexion_sqlsrv.php';

/*
|--------------------------------------------------------------------------
| PASO 4: DETECTAR VARIABLE DE CONEXIÓN
|--------------------------------------------------------------------------
*/
$sqlsrvConn = null;

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion) {
    $sqlsrvConn = $sqlsrv_conn_exhibicion;
} elseif (isset($sqlsrv_conn) && $sqlsrv_conn) {
    $sqlsrvConn = $sqlsrv_conn;
} elseif (isset($conn_sqlsrv) && $conn_sqlsrv) {
    $sqlsrvConn = $conn_sqlsrv;
} elseif (isset($conn) && $conn) {
    $sqlsrvConn = $conn;
} elseif (isset($conexion) && $conexion) {
    $sqlsrvConn = $conexion;
}

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIÓN PARA LIMPIAR HTML
|--------------------------------------------------------------------------
*/
function h($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}


/* Fechas predeterminadas para el formulario */
$fechaHoy = date('Y-m-d');
$fechaInicioMes = date('Y-m-01');

/*
|--------------------------------------------------------------------------
| PASO 6: CONSULTA AJAX
|--------------------------------------------------------------------------
| IMPORTANTE:
| Esto va ANTES del layout_menu.php para no romper el JSON.
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'buscar') {

    header('Content-Type: application/json; charset=utf-8');

    if (!$sqlsrvConn) {
        echo json_encode([
            'ok' => false,
            'msg' => 'No se encontró la conexión SQL Server.'
        ]);
        exit;
    }

    $startDate = trim($_POST['start_date'] ?? '');
    $endDate   = trim($_POST['end_date'] ?? '');

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
        echo json_encode([
            'ok' => false,
            'msg' => 'Seleccione una fecha inicial válida.'
        ]);
        exit;
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
        echo json_encode([
            'ok' => false,
            'msg' => 'Seleccione una fecha final válida.'
        ]);
        exit;
    }

    if ($startDate > $endDate) {
        echo json_encode([
            'ok' => false,
            'msg' => 'La fecha inicial no puede ser mayor que la fecha final.'
        ]);
        exit;
    }

        /*
    |--------------------------------------------------------------------------
    | PASO 6.1: PROCEDIMIENTO SQL SERVER (POR FECHAS OPTIMIZADO)
    |--------------------------------------------------------------------------
    */
    $sql = "
        SET NOCOUNT ON;
        EXEC [vistasMCC].[dbo].[UPS_PLAN_INVENTARIO_FECHA]
            @StartDate = ?,
            @EndDate = ?
    ";

    // Pasamos las variables directamente limpias, el driver las infiere de forma nativa
    $params = [$startDate, $endDate];

    $stmt = sqlsrv_query($sqlsrvConn, $sql, $params, [
        'QueryTimeout' => 0 // Clave para rangos de fechas largos que toman tiempo
    ]);

    if ($stmt === false) {
        // Capturamos el error real interno de SQL Server por si el rango de fechas rompe algo
        $errores_sql = sqlsrv_errors();
        $msg_sql = '';
        if ($errores_sql !== null) {
            foreach ($errores_sql as $err) {
                $msg_sql .= " [Código " . $err['code'] . "]: " . $err['message'];
            }
        }

        echo json_encode([
            'ok' => false,
            'msg' => 'Error al ejecutar el procedimiento UPS_PLAN_INVENTARIO_FECHA.',
            'error' => $msg_sql
        ]);
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | PASO 6.2: LEER RESULTADOS
    |--------------------------------------------------------------------------
    */
    $data = [];

    do {
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            $data[] = [
                'CODALMACEN'           => (string)($row['CODALMACEN'] ?? ''),
                'NOMBREALMACEN'        => (string)($row['NOMBREALMACEN'] ?? ''),
                'DEPARTAMENTO'         => (string)($row['DEPARTAMENTO'] ?? ''),
                'SECCION'              => (string)($row['SECCION'] ?? ''),
                'FAMILIA'              => (string)($row['FAMILIA'] ?? ''),
                'STOCK_ACTUAL_TIENDAS' => (string)($row['STOCK_ACTUAL_TIENDAS'] ?? 0),
                'ENTRANSITO_TIENDAS'   => (string)($row['ENTRANSITO_TIENDAS'] ?? 0),
                'STOCK_ACTUAL_CD'      => (string)($row['STOCK_ACTUAL_CD'] ?? 0),
                'PROMEDIO_UNIDADES'    => (string)($row['PROMEDIO_UNIDADES'] ?? 0),
                'VALOR_MAXIMO'         => (string)($row['VALOR_MAXIMO'] ?? 0),
                'MB_MAXIMO'            => (string)($row['MB_MAXIMO'] ?? 0),
                'SUGERIDO_INVENTARIO'  => (string)($row['SUGERIDO_INVENTARIO'] ?? 0),
            ];
        }
    } while (sqlsrv_next_result($stmt));

    /*
    |--------------------------------------------------------------------------
    | LIBERACIÓN DEL CANAL (CRÍTICO)
    |--------------------------------------------------------------------------
    | Limpia los buffers de comunicación antes de enviar el JSON. Esto permite
    | que el usuario pueda volver a dar clic al botón de buscar inmediatamente.
    */
    sqlsrv_free_stmt($stmt);

    echo json_encode([
        'ok' => true,
        'total' => count($data),
        'data' => $data
    ]);
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 8: CARGAR MENÚ PRINCIPAL
|--------------------------------------------------------------------------
*/
require_once __DIR__. '/../layout_menu.php';

?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Plan de Inventario por Fecha</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

<!-- PASO 9: LIBRERÍAS DE DISEÑO -->
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Iconos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<!-- Fuente Inter -->
<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<!--  CSS -->
<link rel="stylesheet" href="<?= $baseUrl ?>/plan_inventario/plan.css?v=<?= time() ?>">
</head>
<body>

<div class="page-wrapper">

    <div class="main-card">

        <!-- PASO 11: FORMULARIO -->
        <div class="top-filter">
            <form id="formPlanInventario" class="row g-3 align-items-end">

                <div class="col-12 col-md-3">
                    <label class="form-label">Fecha inicial</label>
                    <input
                        type="date"
                        name="start_date"
                        id="start_date"
                        class="form-control"
                        value="<?= h($fechaInicioMes) ?>"
                        required
                    >
                </div>

                <div class="col-12 col-md-3">
                    <label class="form-label">Fecha final</label>
                    <input
                        type="date"
                        name="end_date"
                        id="end_date"
                        class="form-control"
                        value="<?= h($fechaHoy) ?>"
                        required
                    >
                </div>

                <div class="col-12 col-md-3">
                    <button type="submit" class="btn btn-main w-100">
                        <i class="bi bi-search"></i>
                        Consultar
                    </button>
                </div>

                <div class="col-12 col-md-3">
                    <button type="button" id="btnLimpiarTodo" class="btn btn-light-custom w-100">
                        <i class="bi bi-arrow-clockwise"></i>
                        Limpiar
                    </button>
                </div>

            </form>
        </div>

        <!-- PASO 12: CARGANDO -->
        <div id="loadingBox" class="loading-box" style="display:none;">
            <div class="spinner-border spinner-border-sm" role="status"></div>
            Consultando información...
        </div>

        <!-- PASO 13: TABLA -->
        <div class="table-section">

            <div id="msgBox"></div>

            <div class="table-wrap">
                <table class="table table-bordered table-hover align-middle">
                    <thead>
                        <tr>
                            <th><div class="th-content">Codigo<button type="button" class="btn-filter-excel" data-campo="CODALMACEN" data-label="Código"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Tienda <button type="button" class="btn-filter-excel" data-campo="NOMBREALMACEN" data-label="Tienda"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Departamento <button type="button" class="btn-filter-excel" data-campo="DEPARTAMENTO" data-label="Departamento"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Sección <button type="button" class="btn-filter-excel" data-campo="SECCION" data-label="Sección"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Familia <button type="button" class="btn-filter-excel" data-campo="FAMILIA" data-label="Familia"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Stock<br>tienda <button type="button" class="btn-filter-excel" data-campo="STOCK_ACTUAL_TIENDAS" data-label="Stock tienda"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">En<br>tránsito <button type="button" class="btn-filter-excel" data-campo="ENTRANSITO_TIENDAS" data-label="En tránsito"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Stock<br>CD<button type="button" class="btn-filter-excel" data-campo="STOCK_ACTUAL_CD" data-label="Stock CD"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Promedio <button type="button" class="btn-filter-excel" data-campo="PROMEDIO_UNIDADES" data-label="Promedio"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Valor<br>máximo <button type="button" class="btn-filter-excel" data-campo="VALOR_MAXIMO" data-label="Valor máximo"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">MB<br>máximo <button type="button" class="btn-filter-excel" data-campo="MB_MAXIMO" data-label="MB máximo"><i class="bi bi-funnel"></i></button></div></th>
                            <th><div class="th-content">Sugerido <button type="button" class="btn-filter-excel" data-campo="SUGERIDO_INVENTARIO" data-label="Sugerido"><i class="bi bi-funnel"></i></button></div></th>
                        </tr>
                    </thead>

                    <tbody id="tbodyResultados">
                        <tr>
                            <td colspan="12" class="empty-box">
                                Seleccione fechas y luego presione Consultar.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- PASO 14: PIE DE TABLA -->
            <div class="footer-table">
                <div class="summary-text" id="summaryText">
                    Mostrando 0 registros
                </div>

                <div class="pagination-custom" id="paginationBox"></div>

                <button type="button" id="btnExportExcel" class="btn btn-excel">
                    <i class="bi bi-file-earmark-excel-fill"></i>
                    Exportar
                </button>
            </div>

        </div>

    </div>

</div>

<!-- PASO 15: PANEL DE FILTRO TIPO EXCEL -->
<div id="excelFilterPanel" class="excel-filter-panel">

    <div class="excel-panel-header">
        <h6 id="excelPanelTitle" class="excel-panel-title">Filtro</h6>

        <button type="button" id="btnCerrarPanel" class="btn-close-panel">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>

    <div class="excel-panel-body">

        <button type="button" id="btnOrdenAsc" class="excel-sort-btn">
            <i class="bi bi-sort-alpha-down"></i>
            Ordenar de A a Z
        </button>

        <button type="button" id="btnOrdenDesc" class="excel-sort-btn">
            <i class="bi bi-sort-alpha-up"></i>
            Ordenar de Z a A
        </button>

        <hr>

        <div class="filter-search-box">
            <input type="text" id="inputBuscarValores" class="form-control" placeholder="Buscar...">
            <i class="bi bi-search"></i>
        </div>

        <label class="check-row mt-3">
            <input type="checkbox" id="checkSelectAll" checked>
            <strong>Seleccionar todo</strong>
        </label>

        <div id="valueList" class="value-list"></div>

    </div>

  <div class="excel-panel-footer d-flex flex-column gap-2 p-2">
    <!-- Fila superior: Aplicar y Limpiar lado a lado de forma compacta -->
    <div class="d-flex gap-2 w-100">
        <button type="button" id="btnAplicarFiltro" class="btn btn-primary btn-sm flex-fill">
            <i class="bi bi-check2"></i> Aplicar
        </button>

        <button type="button" id="btnLimpiarFiltro" class="btn btn-light btn-sm flex-fill">
            <i class="bi bi-eraser"></i> Limpiar
        </button>
    </div>

  
    <button type="button" id="btnLimpiarSoloFiltros" class="btn btn-success btn-sm w-100">
        <i class="bi bi-funnel-fill"></i> Quitar Filtros
    </button>

</div>
</div>

<script>
/*
|--------------------------------------------------------------------------
| PASO 16: VARIABLES GLOBALES
|--------------------------------------------------------------------------
*/
const formPlanInventario = document.getElementById('formPlanInventario');
const tbodyResultados = document.getElementById('tbodyResultados');
const loadingBox = document.getElementById('loadingBox');
const msgBox = document.getElementById('msgBox');
const summaryText = document.getElementById('summaryText');
const paginationBox = document.getElementById('paginationBox');

const excelFilterPanel = document.getElementById('excelFilterPanel');
const excelPanelTitle = document.getElementById('excelPanelTitle');
const btnCerrarPanel = document.getElementById('btnCerrarPanel');
const inputBuscarValores = document.getElementById('inputBuscarValores');
const checkSelectAll = document.getElementById('checkSelectAll');
const valueList = document.getElementById('valueList');
const btnAplicarFiltro = document.getElementById('btnAplicarFiltro');
const btnLimpiarFiltro = document.getElementById('btnLimpiarFiltro');
const btnLimpiarSoloFiltros = document.getElementById('btnLimpiarSoloFiltros');
const btnOrdenAsc = document.getElementById('btnOrdenAsc');
const btnOrdenDesc = document.getElementById('btnOrdenDesc');
const btnLimpiarTodo = document.getElementById('btnLimpiarTodo');
const btnExportExcel = document.getElementById('btnExportExcel');

let datosOriginales = [];
let datosFiltrados = [];

let filtrosActivos = {};
let campoActualFiltro = null;

let ordenCampo = null;
let ordenDireccion = 'ASC';

let paginaActual = 1;
let registrosPorPagina = 500;

/*
|--------------------------------------------------------------------------
| PASO 17: CONFIGURACIÓN DE COLUMNAS
|--------------------------------------------------------------------------
*/
const columnas = [
    { campo: 'CODALMACEN', tipo: 'numero' },
    { campo: 'NOMBREALMACEN', tipo: 'texto' },
    { campo: 'DEPARTAMENTO', tipo: 'texto' },
    { campo: 'SECCION', tipo: 'texto' },
    { campo: 'FAMILIA', tipo: 'texto' },
    { campo: 'STOCK_ACTUAL_TIENDAS', tipo: 'numero' },
    { campo: 'ENTRANSITO_TIENDAS', tipo: 'numero' },
    { campo: 'STOCK_ACTUAL_CD', tipo: 'numero' },
    { campo: 'PROMEDIO_UNIDADES', tipo: 'numero' },
    { campo: 'VALOR_MAXIMO', tipo: 'numero' },
    { campo: 'MB_MAXIMO', tipo: 'numero' },
    { campo: 'SUGERIDO_INVENTARIO', tipo: 'numero' }
];

/*
|--------------------------------------------------------------------------
| PASO 18: FUNCIONES AUXILIARES
|--------------------------------------------------------------------------
*/
function escapeHtml(texto) {
    return String(texto ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function normalizar(valor) {
    return String(valor ?? '').toLowerCase().trim();
}

function numero(valor) {
    return parseFloat(String(valor ?? '0').replaceAll(',', '')) || 0;
}

function getColumna(campo) {
    return columnas.find(col => col.campo === campo);
}

/*
|--------------------------------------------------------------------------
| PASO 19: CONSULTAR POR AJAX
|--------------------------------------------------------------------------
*/
formPlanInventario.addEventListener('submit', async function(e) {
    e.preventDefault();

    msgBox.innerHTML = '';
    loadingBox.style.display = 'block';

    tbodyResultados.innerHTML = `
        <tr>
            <td colspan="12" class="empty-box"></td>
        </tr>
    `;

    const formData = new FormData(formPlanInventario);
    formData.append('action', 'buscar');

    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        loadingBox.style.display = 'none';

        if (!result.ok) {
            msgBox.innerHTML = `
                <div class="alert alert-danger">
                    ${escapeHtml(result.msg || 'Ocurrió un error al consultar.')}
                </div>
            `;

            console.log(result.error || '');

            tbodyResultados.innerHTML = `
                <tr>
                    <td colspan="12" class="empty-box">No se pudo cargar la información.</td>
                </tr>
            `;
            return;
        }

        datosOriginales = result.data || [];
        filtrosActivos = {};
        ordenCampo = null;
        ordenDireccion = 'ASC';
        paginaActual = 1;

        cerrarPanelFiltro();
        aplicarFiltrosOrdenYPaginacion();

    } catch (error) {
        loadingBox.style.display = 'none';

        msgBox.innerHTML = `
            <div class="alert alert-danger">
                Error de conexión o respuesta inválida del servidor.
            </div>
        `;

        tbodyResultados.innerHTML = `
            <tr>
                <td colspan="12" class="empty-box">Error al cargar información.</td>
            </tr>
        `;

        console.error(error);
    }
});

/*
|--------------------------------------------------------------------------
| PASO 20: APLICAR FILTROS Y ORDENAMIENTO
|--------------------------------------------------------------------------
*/
function aplicarFiltrosOrdenYPaginacion() {

    datosFiltrados = datosOriginales.filter(row => {
        for (const campo in filtrosActivos) {
            const seleccionados = filtrosActivos[campo];

            if (!seleccionados || seleccionados.length === 0) {
                return false;
            }

            const valorFila = String(row[campo] ?? '');

            if (!seleccionados.includes(valorFila)) {
                return false;
            }
        }

        return true;
    });

    if (ordenCampo) {
        const columna = getColumna(ordenCampo);

        datosFiltrados.sort((a, b) => {
            let valorA;
            let valorB;

            if (columna && columna.tipo === 'numero') {
                valorA = numero(a[ordenCampo]);
                valorB = numero(b[ordenCampo]);
            } else {
                valorA = normalizar(a[ordenCampo]);
                valorB = normalizar(b[ordenCampo]);
            }

            if (valorA < valorB) return ordenDireccion === 'ASC' ? -1 : 1;
            if (valorA > valorB) return ordenDireccion === 'ASC' ? 1 : -1;

            return 0;
        });
    }

    pintarTablaPaginada();
    actualizarBotonesFiltro();
}

/*
|--------------------------------------------------------------------------
| PASO 21: PINTAR TABLA
|--------------------------------------------------------------------------
*/
function pintarTablaPaginada() {

    if (datosFiltrados.length === 0) {
        tbodyResultados.innerHTML = `
            <tr>
                <td colspan="12" class="empty-box">No hay resultados con los filtros seleccionados.</td>
            </tr>
        `;

        summaryText.textContent = 'Mostrando 0 registros';
        paginationBox.innerHTML = '';
        return;
    }

    const totalPaginas = Math.ceil(datosFiltrados.length / registrosPorPagina);

    if (paginaActual > totalPaginas) {
        paginaActual = totalPaginas;
    }

    const inicio = (paginaActual - 1) * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    const datosPagina = datosFiltrados.slice(inicio, fin);

    let html = '';

    datosPagina.forEach(row => {
        html += `
            <tr>
                <td data-label="Código">${escapeHtml(row.CODALMACEN)}</td>
                <td data-label="Tienda">${escapeHtml(row.NOMBREALMACEN)}</td>
                <td data-label="Departamento">${escapeHtml(row.DEPARTAMENTO)}</td>
                <td data-label="Sección">${escapeHtml(row.SECCION)}</td>
                <td data-label="Familia">${escapeHtml(row.FAMILIA)}</td>
                <td data-label="Stock tienda">${escapeHtml(row.STOCK_ACTUAL_TIENDAS)}</td>
                <td data-label="En tránsito">${escapeHtml(row.ENTRANSITO_TIENDAS)}</td>
                <td data-label="Stock CD">${escapeHtml(row.STOCK_ACTUAL_CD)}</td>
                <td data-label="Promedio">${escapeHtml(row.PROMEDIO_UNIDADES)}</td>
                <td data-label="Valor máximo">${escapeHtml(row.VALOR_MAXIMO)}</td>
                <td data-label="MB máximo">${escapeHtml(row.MB_MAXIMO)}</td>
                <td data-label="Sugerido">
                    <span class="sugerido-value">${escapeHtml(row.SUGERIDO_INVENTARIO)}</span>
                </td>
            </tr>
        `;
    });

    tbodyResultados.innerHTML = html;

    summaryText.textContent =
       `Mostrando ${inicio + 1} a ${Math.min(fin, datosFiltrados.length)} de ${datosFiltrados.length} registros`;

    pintarPaginacion(totalPaginas);
}

/*
|--------------------------------------------------------------------------
| PASO 22: PAGINACIÓN
|--------------------------------------------------------------------------
*/
function pintarPaginacion(totalPaginas) {

    let html = '';

    html += `
        <button type="button" ${paginaActual === 1 ? 'disabled' : ''} onclick="cambiarPagina(${paginaActual - 1})">
            <i class="bi bi-chevron-left"></i>
        </button>
    `;

    const maxBotones = 5;
    let inicio = Math.max(1, paginaActual - 2);
    let fin = Math.min(totalPaginas, inicio + maxBotones - 1);

    if (fin - inicio < maxBotones - 1) {
        inicio = Math.max(1, fin - maxBotones + 1);
    }

    for (let i = inicio; i <= fin; i++) {
        html += `
            <button type="button" class="${i === paginaActual ? 'active' : ''}" onclick="cambiarPagina(${i})">
                ${i}
            </button>
        `;
    }

    html += `
        <button type="button" ${paginaActual === totalPaginas ? 'disabled' : ''} onclick="cambiarPagina(${paginaActual + 1})">
            <i class="bi bi-chevron-right"></i>
        </button>
    `;

    paginationBox.innerHTML = html;
}

function cambiarPagina(pagina) {
    paginaActual = pagina;
    pintarTablaPaginada();
}

/*
|--------------------------------------------------------------------------
| PASO 23: FILTRO TIPO EXCEL (UNIFICADO)
|--------------------------------------------------------------------------
*/
document.querySelectorAll('.btn-filter-excel').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();

        campoActualFiltro = this.dataset.campo;
        const label = this.dataset.label;

        abrirPanelFiltro(campoActualFiltro, label, this);
    });
});

function abrirPanelFiltro(campo, label, boton) {
    excelPanelTitle.textContent = label;
    inputBuscarValores.value = '';
    cargarValoresDelFiltro(campo);
    excelFilterPanel.classList.add('show');

    // Ubicar el panel junto al embudo sin permitir que salga de la pantalla.
    requestAnimationFrame(() => {
        if (!boton) return;

        const rectBoton = boton.getBoundingClientRect();
        const anchoPanel = excelFilterPanel.offsetWidth || 310;
        const altoPanel = excelFilterPanel.offsetHeight || 450;

        let izquierda = rectBoton.right - anchoPanel;
        let arriba = rectBoton.bottom + 6;

        if (izquierda < 10) izquierda = 10;
        if (izquierda + anchoPanel > window.innerWidth - 10) {
            izquierda = Math.max(10, window.innerWidth - anchoPanel - 10);
        }

        if (arriba + altoPanel > window.innerHeight - 10) {
            arriba = rectBoton.top - altoPanel - 6;
        }
        if (arriba < 10) arriba = 10;

        excelFilterPanel.style.top = `${arriba}px`;
        excelFilterPanel.style.left = `${izquierda}px`;
        excelFilterPanel.style.right = 'auto';
    });
}

function cerrarPanelFiltro() {
    excelFilterPanel.classList.remove('show');
    campoActualFiltro = null;
}

btnCerrarPanel.addEventListener('click', cerrarPanelFiltro);

function cargarValoresDelFiltro(campo) {
    const conteo = {};
    const valores = [];

    if (!datosOriginales || datosOriginales.length === 0) {
        valueList.innerHTML = '<div class="p-2 text-muted text-center">No hay datos para filtrar</div>';
        if (typeof checkSelectAll !== 'undefined' && checkSelectAll) checkSelectAll.checked = false;
        return;
    }

    /*
     * Respetar los demás filtros activos. Por ejemplo, después de seleccionar
     * un Departamento, los embudos de Sección y Familia solo muestran valores
     * relacionados con ese Departamento.
     */
    const datosDisponibles = datosOriginales.filter(row => {
        for (const campoFiltro in filtrosActivos) {
            if (campoFiltro === campo) continue;

            const seleccionados = filtrosActivos[campoFiltro];

            if (!seleccionados || seleccionados.length === 0) {
                return false;
            }

            const valorFila = String(row[campoFiltro] ?? '');

            if (!seleccionados.includes(valorFila)) {
                return false;
            }
        }

        return true;
    });

    datosDisponibles.forEach(row => {
        const valor = String(row[campo] ?? '');

        if (!Object.prototype.hasOwnProperty.call(conteo, valor)) {
            conteo[valor] = 0;
            valores.push(valor);
        }

        conteo[valor]++;
    });

    valores.sort((a, b) => normalizar(a).localeCompare(normalizar(b)));

    const filtroExistente = filtrosActivos[campo];
    let html = '';

    valores.forEach(valor => {
        const checked = !filtroExistente || filtroExistente.includes(valor);

        html += `
            <label class="check-row item-filtro" data-texto="${escapeHtml(normalizar(valor))}">
                <input type="checkbox" class="checkFiltroValor" value="${escapeHtml(valor)}" ${checked ? 'checked' : ''}>
                <span>${escapeHtml(valor === '' ? '(Vacío)' : valor)}</span>
                <span class="value-count">${conteo[valor]}</span>
            </label>
        `;
    });

    valueList.innerHTML = html || '<div class="p-2 text-muted text-center">No hay valores disponibles</div>';
    actualizarCheckSelectAll();
}

inputBuscarValores.addEventListener('input', function() {
    const texto = normalizar(this.value);

    document.querySelectorAll('.item-filtro').forEach(item => {
        const itemTexto = item.dataset.texto || '';
        item.style.display = itemTexto.includes(texto) ? 'flex' : 'none';
    });

    actualizarCheckSelectAll();
});

checkSelectAll.addEventListener('change', function() {
    document.querySelectorAll('.checkFiltroValor').forEach(check => {
        const item = check.closest('.item-filtro');

        if (item && item.style.display !== 'none') {
            check.checked = checkSelectAll.checked;
        }
    });
});

valueList.addEventListener('change', function(e) {
    if (e.target.classList.contains('checkFiltroValor')) {
        actualizarCheckSelectAll();
    }
});

function actualizarCheckSelectAll() {
    const checks = Array.from(document.querySelectorAll('.checkFiltroValor'));

    const visibles = checks.filter(check => {
        const item = check.closest('.item-filtro');
        return item && item.style.display !== 'none';
    });

    checkSelectAll.checked = visibles.length > 0 && visibles.every(check => check.checked);
}

btnAplicarFiltro.addEventListener('click', function() {
    if (!campoActualFiltro) return;

    const hayBusqueda = normalizar(inputBuscarValores.value) !== '';

    const seleccionados = Array.from(document.querySelectorAll('.checkFiltroValor'))
        .filter(check => {
            if (!check.checked) return false;

            // Cuando se escribió en Buscar, aplicar únicamente los valores visibles.
            if (hayBusqueda) {
                const item = check.closest('.item-filtro');
                return item && item.style.display !== 'none';
            }

            return true;
        })
        .map(check => check.value);

    filtrosActivos[campoActualFiltro] = seleccionados;
    paginaActual = 1;

    cerrarPanelFiltro();
    aplicarFiltrosOrdenYPaginacion();
});

/*
|--------------------------------------------------------------------------
| ACCIÓN: LIMPIAR EL FILTRO DE LA COLUMNA ACTUAL DESDE EL PANEL DE EXCEL
|--------------------------------------------------------------------------
*/
if (btnLimpiarFiltro) {
    btnLimpiarFiltro.addEventListener('click', function() {
        if (!campoActualFiltro) return;

        delete filtrosActivos[campoActualFiltro];
        paginaActual = 1;

        cerrarPanelFiltro();
        aplicarFiltrosOrdenYPaginacion();
    });
}

/*
|--------------------------------------------------------------------------
| ACCIÓN: LIMPIAR TODOS LOS FILTROS DE EXCEL DESDE EL BOTÓN DE LA PANTALLA
|--------------------------------------------------------------------------
*/
if (typeof btnLimpiarSoloFiltros !== 'undefined' && btnLimpiarSoloFiltros) {
    btnLimpiarSoloFiltros.addEventListener('click', function() {
        if (!datosOriginales || datosOriginales.length === 0) return; 

        // Resetea todas las columnas de golpe sin tocar la base de datos
        filtrosActivos = {};
        ordenCampo = null;
        ordenDireccion = 'ASC';
        paginaActual = 1;

        if (typeof actualizarBotonesFiltro === 'function') actualizarBotonesFiltro();
        cerrarPanelFiltro();
        
        if (typeof aplicarFiltrosOrdenYPaginacion === 'function') aplicarFiltrosOrdenYPaginacion();
    });
}

btnOrdenAsc.addEventListener('click', function() {
    if (!campoActualFiltro) return;

    ordenCampo = campoActualFiltro;
    ordenDireccion = 'ASC';
    paginaActual = 1;

    cerrarPanelFiltro();
    aplicarFiltrosOrdenYPaginacion();
});

btnOrdenDesc.addEventListener('click', function() {
    if (!campoActualFiltro) return;

    ordenCampo = campoActualFiltro;
    ordenDireccion = 'DESC';
    paginaActual = 1;

    cerrarPanelFiltro();
    aplicarFiltrosOrdenYPaginacion();
});

function actualizarBotonesFiltro() {
    document.querySelectorAll('.btn-filter-excel').forEach(btn => {
        const campo = btn.dataset.campo;

        if (filtrosActivos[campo] || ordenCampo === campo) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

/*
|--------------------------------------------------------------------------
| PASO 24: LIMPIAR TODO (POR FECHAS - DETALLE DE EMBUTOS INCLUIDO)
|--------------------------------------------------------------------------
*/
if (btnLimpiarTodo) {
    btnLimpiarTodo.addEventListener('click', function() {
        // 1. Limpiar estados internos de filtros y paginación
        filtrosActivos = {};
        ordenCampo = null;
        ordenDireccion = 'ASC';
        paginaActual = 1;
        datosOriginales = [];
        datosFiltrados = [];

        // 2. Limpiar automáticamente todos los campos de fecha del formulario
        document.querySelectorAll('input[type="date"]').forEach(input => {
            input.value = '';
        });

        // 3. Cerrar el panel de filtros si está abierto
        if (typeof cerrarPanelFiltro === 'function') {
            cerrarPanelFiltro();
        }

        // 4. NUEVO: Apagar el color activo de todos los embudos de las columnas
        if (typeof actualizarBotonesFiltro === 'function') {
            actualizarBotonesFiltro();
        }

        // 5. Reiniciar la tabla visual a su estado inicial vacío (12 columnas)
        if (tbodyResultados) {
            tbodyResultados.innerHTML = `
                <tr>
                    <td colspan="12" class="empty-box">Seleccione fechas y luego presione Consultar.</td>
                </tr>
            `;
        }

        // 6. Reiniciar contadores de paginación de la interfaz
        if (typeof summaryText !== 'undefined' && summaryText) {
            summaryText.textContent = 'Mostrando 0 registros';
        }
        if (typeof paginationBox !== 'undefined' && paginationBox) {
            paginationBox.innerHTML = '';
        }
    });
}


/*
|--------------------------------------------------------------------------
| PASO 25: EXPORTAR A EXCEL
|--------------------------------------------------------------------------
*/
btnExportExcel.addEventListener('click', function() {

    if (datosFiltrados.length === 0) {
        alert('No hay datos para exportar.');
        return;
    }

    let html = `
        <meta charset="utf-8">
        <table border="1">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Tienda</th>
                    <th>Departamento</th>
                    <th>Sección</th>
                    <th>Familia</th>
                    <th>Stock tienda</th>
                    <th>En tránsito</th>
                    <th>Stock CD</th>
                    <th>Promedio</th>
                    <th>Valor máximo</th>
                    <th>MB máximo</th>
                    <th>Sugerido</th>
                </tr>
            </thead>
            <tbody>
    `;

    datosFiltrados.forEach(row => {
        html += `
            <tr>
                <td>${escapeHtml(row.CODALMACEN)}</td>
                <td>${escapeHtml(row.NOMBREALMACEN)}</td>
                <td>${escapeHtml(row.DEPARTAMENTO)}</td>
                <td>${escapeHtml(row.SECCION)}</td>
                <td>${escapeHtml(row.FAMILIA)}</td>
                <td>${escapeHtml(row.STOCK_ACTUAL_TIENDAS)}</td>
                <td>${escapeHtml(row.ENTRANSITO_TIENDAS)}</td>
                <td>${escapeHtml(row.STOCK_ACTUAL_CD)}</td>
                <td>${escapeHtml(row.PROMEDIO_UNIDADES)}</td>
                <td>${escapeHtml(row.VALOR_MAXIMO)}</td>
                <td>${escapeHtml(row.MB_MAXIMO)}</td>
                <td>${escapeHtml(row.SUGERIDO_INVENTARIO)}</td>
            </tr>
        `;
    });

    html += `
            </tbody>
        </table>
    `;

    const blob = new Blob(['\uFEFF' + html], {
        type: 'application/vnd.ms-excel;charset=utf-8;'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    link.href = url;
    link.download = 'plan de inventario.xls';
    link.click();

    URL.revokeObjectURL(url);
});

/*
|--------------------------------------------------------------------------
| PASO 26: CERRAR PANEL AL HACER CLIC FUERA
|--------------------------------------------------------------------------
*/
document.addEventListener('click', function(e) {
    const clickDentroPanel = excelFilterPanel.contains(e.target);
    const clickBotonFiltro = e.target.closest('.btn-filter-excel');

    if (!clickDentroPanel && !clickBotonFiltro) {
        cerrarPanelFiltro();
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php
/*
|--------------------------------------------------------------------------
| PASO 27: CERRAR LAYOUT
|--------------------------------------------------------------------------
*/
require_once __DIR__. '/../layout_footer.php';
?>