<?php
declare(strict_types=1);

session_name('APP_INVENTARIO');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/usuarios/auth.php';
require_login();

ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('memory_limit', '1024M');

require_once __DIR__ . '/plan_inventario/conexion_sqlsrv.php';


const NEGOCIO_ICG = 'MENDELS HN';

function h(mixed $valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function errores_sqlsrv(): string
{
    $errores = sqlsrv_errors(SQLSRV_ERR_ERRORS);

    if (!$errores) {
        return 'Ocurrió un error desconocido en SQL Server.';
    }

    $mensajes = [];

    foreach ($errores as $error) {
        $mensajes[] = '[' . ($error['code'] ?? 'SIN CÓDIGO') . '] '
            . ($error['message'] ?? 'Error desconocido');
    }

    return implode(' | ', $mensajes);
}

function validar_anio(mixed $anio): int
{
    $anioActual = (int)date('Y');

    if (!is_numeric($anio)) {
        return $anioActual;
    }

    $anio = (int)$anio;

    return ($anio >= 2000 && $anio <= 2100)
        ? $anio
        : $anioActual;
}

/**
 * @return array<int,array<string,mixed>>
 */
function sqlsrv_fetch_all_assoc($conexion, string $sql, array $params = []): array
{
    $stmt = sqlsrv_query(
        $conexion,
        $sql,
        $params,
        ['QueryTimeout' => 0]
    );

    if ($stmt === false) {
        throw new RuntimeException(errores_sqlsrv());
    }

    $filas = [];

    while ($fila = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $filas[] = $fila;
    }

    sqlsrv_free_stmt($stmt);

    return $filas;
}

/**
 * @return array<string,mixed>
 */
function sqlsrv_fetch_one_assoc($conexion, string $sql, array $params = []): array
{
    $filas = sqlsrv_fetch_all_assoc($conexion, $sql, $params);

    return $filas[0] ?? [];
}

$sqlsrvConn = null;

if (isset($sqlsrv_conn_exhibicion) && $sqlsrv_conn_exhibicion) {
    $sqlsrvConn = $sqlsrv_conn_exhibicion;
} elseif (isset($sqlsrv_conn) && $sqlsrv_conn) {
    $sqlsrvConn = $sqlsrv_conn;
} elseif (isset($conn_sqlsrv) && $conn_sqlsrv) {
    $sqlsrvConn = $conn_sqlsrv;
} elseif (isset($conn) && $conn) {
    $sqlsrvConn = $conn;
} elseif (isset($conexion) && $conexion) {
    $sqlsrvConn = $conexion;
}

if (!$sqlsrvConn) {
    die('No se encontró una conexión válida a SQL Server.');
}

$anio = validar_anio($_GET['anio'] ?? date('Y'));
$errorDashboard = '';

$resumen = [
    'total_catalogo'    => 0,
    'metas_registradas' => 0,
    'con_meta'          => 0,
    'metas_en_cero'     => 0,
    'sin_registrar'  => 0,
    'promedio_meta'  => 0,
    'meta_maxima'    => 0,
    'meta_minima'    => 0,
];

$departamentos = [];
$rangos = [];
$comparacionAnios = [];
$detalleMaximo = [];
$detalleMinimo = [];
$aniosDisponibles = [];

try {
    $sqlResumen = "
        WITH Catalogo AS (
            SELECT
                D.NUMDPTO,
                ISNULL(D.DESCRIPCION, 'SIN DPTO') AS DEPARTAMENTO,
                S.NUMSECCION,
                ISNULL(S.DESCRIPCION, 'SIN SECCION') AS SECCION,
                F.NUMFAMILIA,
                ISNULL(F.DESCRIPCION, 'SIN FAMILIA') AS FAMILIA,
                M.MetaStock
            FROM MENDELS.dbo.DEPARTAMENTO AS D
            INNER JOIN MENDELS.dbo.SECCIONES AS S
                ON S.NUMDPTO = D.NUMDPTO
            INNER JOIN MENDELS.dbo.FAMILIAS AS F
                ON F.NUMDPTO = D.NUMDPTO
               AND F.NUMSECCION = S.NUMSECCION
            LEFT JOIN vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
                ON M.NOMNEGOCIOICG = ?
               AND M.NUMDPTO = D.NUMDPTO
               AND M.NUMSECCION = S.NUMSECCION
               AND M.NUMFAMILIA = F.NUMFAMILIA
               AND M.ANIO = ?
            WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
              AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
              AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL
        )
        SELECT
            COUNT(*) AS total_catalogo,

            SUM(
                CASE
                    WHEN ISNULL(MetaStock, 0) > 0 THEN 1
                    ELSE 0
                END
            ) AS con_meta,

            SUM(
                CASE
                    WHEN MetaStock = 0 THEN 1
                    ELSE 0
                END
            ) AS metas_en_cero,

            SUM(
                CASE
                    WHEN MetaStock IS NULL THEN 1
                    ELSE 0
                END
            ) AS sin_registrar,

            ISNULL(
                AVG(
                    CASE
                        WHEN MetaStock > 0
                        THEN CAST(MetaStock AS DECIMAL(18,2))
                    END
                ),
                0
            ) AS promedio_meta,

            ISNULL(
                MAX(
                    CASE
                        WHEN MetaStock > 0 THEN MetaStock
                    END
                ),
                0
            ) AS meta_maxima,

            ISNULL(
                MIN(
                    CASE
                        WHEN MetaStock > 0 THEN MetaStock
                    END
                ),
                0
            ) AS meta_minima

        FROM Catalogo;
    ";

    $resumenDb = sqlsrv_fetch_one_assoc(
        $sqlsrvConn,
        $sqlResumen,
        [NEGOCIO_ICG, $anio]
    );

    $metasMayoresCero = (int)($resumenDb['con_meta'] ?? 0);
    $metasEnCero = (int)($resumenDb['metas_en_cero'] ?? 0);

    $resumen = [
        'total_catalogo'    => (int)($resumenDb['total_catalogo'] ?? 0),
        'metas_registradas' => $metasMayoresCero + $metasEnCero,
        'con_meta'          => $metasMayoresCero,
        'metas_en_cero'     => $metasEnCero,
        'sin_registrar'     => (int)($resumenDb['sin_registrar'] ?? 0),
        'promedio_meta'     => (float)($resumenDb['promedio_meta'] ?? 0),
        'meta_maxima'       => (float)($resumenDb['meta_maxima'] ?? 0),
        'meta_minima'       => (float)($resumenDb['meta_minima'] ?? 0),
    ];

    $sqlDepartamentos = "
        WITH Catalogo AS (
            SELECT
                D.NUMDPTO,
                ISNULL(D.DESCRIPCION, 'SIN DPTO') AS DEPARTAMENTO,
                ISNULL(M.MetaStock, 0) AS MetaStock
            FROM MENDELS.dbo.DEPARTAMENTO AS D
            INNER JOIN MENDELS.dbo.SECCIONES AS S
                ON S.NUMDPTO = D.NUMDPTO
            INNER JOIN MENDELS.dbo.FAMILIAS AS F
                ON F.NUMDPTO = D.NUMDPTO
               AND F.NUMSECCION = S.NUMSECCION
            LEFT JOIN vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
                ON M.NOMNEGOCIOICG = ?
               AND M.NUMDPTO = D.NUMDPTO
               AND M.NUMSECCION = S.NUMSECCION
               AND M.NUMFAMILIA = F.NUMFAMILIA
               AND M.ANIO = ?
            WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
              AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
              AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL
        )
        SELECT
            NUMDPTO,
            DEPARTAMENTO,
            SUM(MetaStock) AS META_TOTAL
        FROM Catalogo
        GROUP BY NUMDPTO, DEPARTAMENTO
        ORDER BY META_TOTAL DESC, DEPARTAMENTO ASC;
    ";

    $departamentos = sqlsrv_fetch_all_assoc(
        $sqlsrvConn,
        $sqlDepartamentos,
        [NEGOCIO_ICG, $anio]
    );

    $sqlRangos = "
        WITH Catalogo AS (
            SELECT
                M.MetaStock
            FROM MENDELS.dbo.DEPARTAMENTO AS D
            INNER JOIN MENDELS.dbo.SECCIONES AS S
                ON S.NUMDPTO = D.NUMDPTO
            INNER JOIN MENDELS.dbo.FAMILIAS AS F
                ON F.NUMDPTO = D.NUMDPTO
               AND F.NUMSECCION = S.NUMSECCION
            LEFT JOIN vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
                ON M.NOMNEGOCIOICG = ?
               AND M.NUMDPTO = D.NUMDPTO
               AND M.NUMSECCION = S.NUMSECCION
               AND M.NUMFAMILIA = F.NUMFAMILIA
               AND M.ANIO = ?
            WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
              AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
              AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL
        )

        SELECT
            'Meta en 0' AS rango,
            COUNT(*) AS total,
            1 AS orden
        FROM Catalogo
        WHERE MetaStock = 0

        UNION ALL

        SELECT
            'De 1 a 2,000' AS rango,
            COUNT(*) AS total,
            2 AS orden
        FROM Catalogo
        WHERE MetaStock BETWEEN 1 AND 2000

        UNION ALL

        SELECT
            'De 2,001 a 3,000' AS rango,
            COUNT(*) AS total,
            3 AS orden
        FROM Catalogo
        WHERE MetaStock BETWEEN 2001 AND 3000

        UNION ALL

        SELECT
            'De 3,001 a 4,000' AS rango,
            COUNT(*) AS total,
            4 AS orden
        FROM Catalogo
        WHERE MetaStock BETWEEN 3001 AND 4000

        UNION ALL

        SELECT
            'De 4,001 a 5,000' AS rango,
            COUNT(*) AS total,
            5 AS orden
        FROM Catalogo
        WHERE MetaStock BETWEEN 4001 AND 5000

        UNION ALL

        SELECT
            'Mayor a 5,000' AS rango,
            COUNT(*) AS total,
            6 AS orden
        FROM Catalogo
        WHERE MetaStock > 5000

        ORDER BY orden;
    ";

    $rangos = sqlsrv_fetch_all_assoc(
        $sqlsrvConn,
        $sqlRangos,
        [NEGOCIO_ICG, $anio]
    );

    $sqlExtremo = "
        SELECT TOP 1
            D.NUMDPTO,
            ISNULL(D.DESCRIPCION, 'SIN DPTO') AS DEPARTAMENTO,
            S.NUMSECCION,
            ISNULL(S.DESCRIPCION, 'SIN SECCION') AS SECCION,
            F.NUMFAMILIA,
            ISNULL(F.DESCRIPCION, 'SIN FAMILIA') AS FAMILIA,
            M.MetaStock
        FROM vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
        INNER JOIN MENDELS.dbo.DEPARTAMENTO AS D
            ON D.NUMDPTO = M.NUMDPTO
        INNER JOIN MENDELS.dbo.SECCIONES AS S
            ON S.NUMDPTO = M.NUMDPTO
           AND S.NUMSECCION = M.NUMSECCION
        INNER JOIN MENDELS.dbo.FAMILIAS AS F
            ON F.NUMDPTO = M.NUMDPTO
           AND F.NUMSECCION = M.NUMSECCION
           AND F.NUMFAMILIA = M.NUMFAMILIA
        WHERE M.NOMNEGOCIOICG = ?
          AND M.ANIO = ?
          AND M.MetaStock > 0
          AND D.NUMDPTO NOT IN (0, 6, 10, 20)
        ORDER BY M.MetaStock %s, D.NUMDPTO, S.NUMSECCION, F.NUMFAMILIA;
    ";

    $detalleMaximo = sqlsrv_fetch_one_assoc(
        $sqlsrvConn,
        sprintf($sqlExtremo, 'DESC'),
        [NEGOCIO_ICG, $anio]
    );

    $detalleMinimo = sqlsrv_fetch_one_assoc(
        $sqlsrvConn,
        sprintf($sqlExtremo, 'ASC'),
        [NEGOCIO_ICG, $anio]
    );

    $sqlComparacion = "
        DECLARE @TotalCatalogo INT;

        SELECT @TotalCatalogo = COUNT(*)
        FROM MENDELS.dbo.DEPARTAMENTO AS D
        INNER JOIN MENDELS.dbo.SECCIONES AS S
            ON S.NUMDPTO = D.NUMDPTO
        INNER JOIN MENDELS.dbo.FAMILIAS AS F
            ON F.NUMDPTO = D.NUMDPTO
           AND F.NUMSECCION = S.NUMSECCION
        WHERE D.NUMDPTO NOT IN (0, 6, 10, 20)
          AND NULLIF(LTRIM(RTRIM(S.DESCRIPCION)), '') IS NOT NULL
          AND NULLIF(LTRIM(RTRIM(F.DESCRIPCION)), '') IS NOT NULL;

        SELECT TOP 5
            M.ANIO,
            COUNT(*) AS registros_guardados,
            SUM(CASE WHEN M.MetaStock > 0 THEN 1 ELSE 0 END) AS con_meta,
            CAST(
                100.0 * COUNT(*)
                / NULLIF(@TotalCatalogo, 0)
                AS DECIMAL(6,2)
            ) AS cobertura,
            ISNULL(AVG(CASE WHEN M.MetaStock > 0 THEN CAST(M.MetaStock AS DECIMAL(18,2)) END), 0) AS promedio
        FROM vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META AS M
        WHERE M.NOMNEGOCIOICG = ?
        GROUP BY M.ANIO
        ORDER BY M.ANIO DESC;
    ";

    $comparacionAnios = sqlsrv_fetch_all_assoc(
        $sqlsrvConn,
        $sqlComparacion,
        [NEGOCIO_ICG]
    );

    $sqlAnios = "
        SELECT DISTINCT ANIO
        FROM vistasMCC.dbo.Tbl_PLAN_INVENTARIO_META
        WHERE NOMNEGOCIOICG = ?
          AND ANIO IS NOT NULL
        ORDER BY ANIO DESC;
    ";

    $aniosDisponibles = sqlsrv_fetch_all_assoc(
        $sqlsrvConn,
        $sqlAnios,
        [NEGOCIO_ICG]
    );
} catch (Throwable $error) {
    $errorDashboard = $error->getMessage();
}

$porcentajeCobertura = $resumen['total_catalogo'] > 0
    ? round(($resumen['metas_registradas'] / $resumen['total_catalogo']) * 100, 1)
    : 0;

$maxRango = 1;
foreach ($rangos as $rango) {
    $maxRango = max($maxRango, (int)($rango['total'] ?? 0));
}

$maxMetaDepartamento = 0.0;
foreach ($departamentos as $departamento) {
    $maxMetaDepartamento = max(
        $maxMetaDepartamento,
        (float)($departamento['META_TOTAL'] ?? 0)
    );
}

require_once __DIR__ . '/layout_menu.php';
?>
   
   <link rel="stylesheet" href="/Inventario/index.css?v=<?= time() ?>">

<main class="meta-dashboard">
    <header class="meta-topbar">
        <div>
           
        </div>

        <form method="get" class="meta-filter">
            <div>
                <label for="anio">Año</label>
                <select name="anio" id="anio">
                    <?php
                    $aniosSelect = [];
                    foreach ($aniosDisponibles as $filaAnio) {
                        $valorAnio = (int)($filaAnio['ANIO'] ?? 0);
                        if ($valorAnio > 0) {
                            $aniosSelect[$valorAnio] = $valorAnio;
                        }
                    }
                    $aniosSelect[$anio] = $anio;
                    krsort($aniosSelect);
                    ?>
                    <?php foreach ($aniosSelect as $valorAnio): ?>
                        <option value="<?= $valorAnio ?>" <?= $valorAnio === $anio ? 'selected' : '' ?>>
                            <?= $valorAnio ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit">Consultar</button>
        </form>
    </header>

    <?php if ($errorDashboard !== ''): ?>
        <div class="meta-alert">
            <strong>No fue posible cargar todos los indicadores.</strong><br>
            <?= h($errorDashboard) ?>
        </div>
    <?php endif; ?>

    <section class="meta-kpis">
        
        <article class="meta-kpi">
            <span>Metas registradas</span>
            <strong><?= number_format($resumen['metas_registradas']) ?></strong>
            <small>Metas mayores a cero más metas en cero</small>
        </article>
        <article class="meta-kpi">
            <span>Metas mayores a 0</span>
            <strong><?= number_format($resumen['con_meta']) ?></strong>
            <small>Registros guardados</small>
        </article>
        <article class="meta-kpi">
            <span>Metas en 0</span>
            <strong><?= number_format($resumen['metas_en_cero']) ?></strong>
            <small>Registros guardados</small>
        </article>
        <article class="meta-kpi">
            <span>Promedio</span>
            <strong><?= number_format($resumen['promedio_meta'], 2) ?></strong>
            <small>Solo metas positivas</small>
        </article>
        <article class="meta-kpi">
            <span>Meta máxima</span>
            <strong><?= number_format($resumen['meta_maxima'], 2) ?></strong>
            <small>Valor más alto</small>
        </article>
        <article class="meta-kpi">
            <span>Meta mínima</span>
            <strong><?= number_format($resumen['meta_minima'], 2) ?></strong>
            <small>Valor bajo</small>
        </article>

    </section>



    <section class="meta-grid">
        <article class="meta-card">
            <div class="meta-card-header">
                <div>
                    <h2>Meta total por departamento</h2>
                    <p>Suma de Meta Stock registrada.</p>
                </div>
            </div>
            <div class="meta-card-body">
                <?php if ($departamentos === []): ?>
                    <div class="meta-empty">No hay departamentos para mostrar.</div>
                <?php else: ?>
                    <div class="dept-list">
                        <?php foreach ($departamentos as $departamento): ?>
                            <?php
                            $metaTotalDepartamento = (float)($departamento['META_TOTAL'] ?? 0);
                            $anchoDepartamento = $maxMetaDepartamento > 0
                                ? ($metaTotalDepartamento / $maxMetaDepartamento) * 100
                                : 0;
                            ?>
                            <div class="dept-row">
                                <span class="dept-name" title="<?= h($departamento['DEPARTAMENTO'] ?? '') ?>">
                                    <?= h($departamento['DEPARTAMENTO'] ?? 'Sin departamento') ?>
                                </span>
                                <div class="dept-track">
                                    <span
                                        class="dept-fill"
                                        style="width: <?= h(number_format($anchoDepartamento, 2, '.', '')) ?>%;"
                                    ></span>
                                </div>
                                <span class="dept-value"><?= number_format($metaTotalDepartamento, 2) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </article>

        <article class="meta-card">
            <div class="meta-card-header">
                <div>
                    <h2>Resumen general</h2>
                    <p>Avance total del año <?= $anio ?>.</p>
                </div>
            </div>
            <div class="meta-card-body">
                <div class="coverage-wrap">
                    <div class="coverage-donut" style="--coverage: <?= h((string)$porcentajeCobertura) ?>%;">
                        <div class="coverage-center">
                            <strong><?= number_format($porcentajeCobertura, 1) ?>%</strong>
                            <span>Registrado</span>
                        </div>
                    </div>
                    <div class="coverage-data">
                        <div class="coverage-item"><span>Sin registrar</span><strong><?= number_format($resumen['sin_registrar']) ?></strong></div>
                        <div class="coverage-item"><span>Total catálogo</span><strong><?= number_format($resumen['total_catalogo']) ?></strong></div>
                    </div>
                </div>
            </div>
        </article>
    </section>

    <section class="meta-grid">
        <article class="meta-card">
            <div class="meta-card-header">
                <div>
                    <h2>Distribución por rangos</h2>
                    <p>Metas guardadas agrupadas por valor.</p>
                </div>
            </div>
            <div class="meta-card-body">
                <div class="range-list">
                    <?php foreach ($rangos as $rango): ?>
                        <?php
                        $totalRango = (int)($rango['total'] ?? 0);
                        $anchoRango = ($totalRango / $maxRango) * 100;
                        ?>
                        <div class="range-row">
                            <div class="range-meta">
                                <span><?= h($rango['rango'] ?? '') ?></span>
                                <strong><?= number_format($totalRango) ?></strong>
                            </div>
                            <div class="range-track">
                                <span class="range-fill" style="width: <?= h(number_format($anchoRango, 2, '.', '')) ?>%;"></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </article>

        <article class="meta-card">
            <div class="meta-card-header">
                <div>
                    <h2>Comparación por año</h2>
                    <p>Porcentaje de registros guardados en los últimos años.</p>
                </div>
            </div>
            <div class="meta-card-body">
                <?php if ($comparacionAnios === []): ?>
                    <div class="meta-empty">No hay años registrados para comparar.</div>
                <?php else: ?>
                    <div class="year-list">
                        <?php foreach ($comparacionAnios as $filaAnio): ?>
                            <?php $coberturaAnio = (float)($filaAnio['cobertura'] ?? 0); ?>
                            <div class="year-row">
                                <div class="year-meta">
                                    <span><?= (int)($filaAnio['ANIO'] ?? 0) ?></span>
                                    <strong><?= number_format($coberturaAnio, 1) ?>%</strong>
                                </div>
                                <div class="year-track">
                                    <span class="year-fill" style="width: <?= h(number_format($coberturaAnio, 2, '.', '')) ?>%;"></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section class="meta-card">
        <div class="meta-card-header">
            <div>
                <h2>Mayor y menor Meta Stock</h2>
                <p>Detalle del año <?= $anio ?>.</p>
            </div>
        </div>
        <div class="meta-card-body">
            <div class="extreme-grid">
                <article class="extreme-box">
                    <span>Meta máxima</span>
                    <strong><?= number_format((float)($detalleMaximo['MetaStock'] ?? 0), 2) ?></strong>
                    <dl>
                        <div><dt>Departamento</dt><dd><?= h($detalleMaximo['DEPARTAMENTO'] ?? 'Sin registro') ?></dd></div>
                        <div><dt>Sección</dt><dd><?= h($detalleMaximo['SECCION'] ?? 'Sin registro') ?></dd></div>
                        <div><dt>Familia</dt><dd><?= h($detalleMaximo['FAMILIA'] ?? 'Sin registro') ?></dd></div>
                    </dl>
                </article>
                <article class="extreme-box">
                    <span>Meta mínima positiva</span>
                    <strong><?= number_format((float)($detalleMinimo['MetaStock'] ?? 0), 2) ?></strong>
                    <dl>
                        <div><dt>Departamento</dt><dd><?= h($detalleMinimo['DEPARTAMENTO'] ?? 'Sin registro') ?></dd></div>
                        <div><dt>Sección</dt><dd><?= h($detalleMinimo['SECCION'] ?? 'Sin registro') ?></dd></div>
                        <div><dt>Familia</dt><dd><?= h($detalleMinimo['FAMILIA'] ?? 'Sin registro') ?></dd></div>
                    </dl>
                </article>
            </div>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/layout_footer.php'; ?>