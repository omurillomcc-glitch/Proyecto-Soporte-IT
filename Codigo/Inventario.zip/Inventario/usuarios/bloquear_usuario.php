<?php
require_once __DIR__ . '/auth.php';
require_admin();

// Si ya hay una sesión activa, la cerramos para poder cambiar el nombre
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); 
}

session_name('APP_INVENTARIO');

// Iniciamos la sesión de nuevo
session_start();


// 2. CORRECCIÓN CRÍTICA: Declarar la lista de administradores permitidos
$admins_autorizados = ['lvalladares','jcruz'];

// 3. Validar de inmediato. Si no es 'lvalladares', redirigir ANTES de abrir buffers de datos o cargar la BD
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario'], $admins_autorizados)) {
    header("Location: " . $baseUrl . "/dashboard.php?error=no_autorizado");
    exit();
}

require_once __DIR__ . '/db.php';

/*
|--------------------------------------------------------------------------
| PASO 1: CONFIGURAR PAGINACIÓN
|--------------------------------------------------------------------------
*/
$porPaginaPermitidos = [100, 200,500];

$porPagina = (int)($_GET['por_pagina'] ?? 100);

if (!in_array($porPagina, $porPaginaPermitidos, true)) {
    $porPagina = 100;
}

$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$offset = ($pagina - 1) * $porPagina;

/*
|--------------------------------------------------------------------------
| PASO 2: BUSCADOR
|--------------------------------------------------------------------------
*/
$buscar = trim($_GET['buscar'] ?? '');

$where = "";
$params = [];
$types  = "";

if ($buscar !== '') {
    $where = "
        WHERE 
            usuario LIKE ?
            OR nombre_completo LIKE ?
            OR rol LIKE ?
            OR estado LIKE ?
    ";

    $like = "%{$buscar}%";

    $params = [$like, $like, $like, $like];
    $types  = "ssss";
}

/*
|--------------------------------------------------------------------------
| PASO 3: CONTAR TOTAL
|--------------------------------------------------------------------------
*/
$sqlCount = "
    SELECT COUNT(*) AS total
    FROM usuarios
    {$where}
";

$stmtCount = $conn->prepare($sqlCount);

if ($types !== "") {
    $stmtCount->bind_param($types, ...$params);
}

$stmtCount->execute();

$totalRegistros = (int)($stmtCount->get_result()->fetch_assoc()['total'] ?? 0);

$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));

if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
    $offset = ($pagina - 1) * $porPagina;
}

/*
|--------------------------------------------------------------------------
| PASO 4: CONSULTAR USUARIOS
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT 
        usuario,
        nombre_completo,
        rol,
        estado,
        creado_en
    FROM usuarios
    {$where}
    ORDER BY nombre_completo ASC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

if ($types !== "") {
    $typesFinal = $types . "ii";
    $paramsFinal = array_merge($params, [$porPagina, $offset]);

    $stmt->bind_param($typesFinal, ...$paramsFinal);
} else {
    $stmt->bind_param("ii", $porPagina, $offset);
}

$stmt->execute();

$res = $stmt->get_result();

$usuarios = [];

while ($row = $res->fetch_assoc()) {
    $usuarios[] = $row;
}

require_once dirname(__DIR__) . '/layout_menu.php';

/*
|--------------------------------------------------------------------------
| PASO 5: FUNCIÓN PARA PAGINACIÓN
|--------------------------------------------------------------------------
*/
function urlBloquear(array $extra = []): string
{
    $query = array_merge($_GET, $extra);

    return '/Inventario/usuarios/bloquear_usuario.php?' . http_build_query($query);
}
?>

<link rel="stylesheet" href="<?= $baseUrl ?>/usuarios/bloquear.css?v=<?= time() ?>">

<div class="user-page">

    <div class="page-head">
        <div>
            <h2></h2>
            <p></p>
        </div>
    </div>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert success">
            Actualizado correctamente.
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>

        <?php
        $mensajeError = "No se pudo actualizar el estado.";

        if ($_GET['error'] === 'no_bloquearse') {
            $mensajeError = "Eres administrador. No puedes bloquear tu propio usuario.";
        }
        ?>

        <div class="alert danger">
            <?= htmlspecialchars($mensajeError) ?>
        </div>

    <?php endif; ?>

    <div class="user-card">

        <div class="card-title">
            <div>
                <h3></h3>
                <p>
            
                </p>
            </div>

            <span><?= $totalRegistros ?> usuarios</span>
        </div>

        <form method="GET" class="filter-bar">
    
            <input
                type="text"
                name="buscar"
                value="<?= htmlspecialchars($buscar) ?>"
                placeholder="Buscar usuario, nombre, rol o estado">
        
            <select name="por_pagina">
                <option value="100" <?= $porPagina === 100 ? 'selected' : '' ?>>100</option>
                <option value="200" <?= $porPagina === 200 ? 'selected' : '' ?>>200</option>
                <option value="500" <?= $porPagina === 500 ? 'selected' : '' ?>>500</option>
            </select>

            
           <button type="submit" class="btn-submit" style="display: inline-flex; align-items: center;">
    <!-- Icono bi-search (Lupa) -->
    <svg xmlns="http://w3.org" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16" style="margin-right: 8px; vertical-align: middle;">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
    </svg>
    Buscar
</button>

<a href="/Inventario/usuarios/bloquear_usuario.php" class="btn-clear" style="display: inline-flex; align-items: center; text-decoration: none;">
    <!-- Icono bi-arrow-clockwise (Limpiar/Recargar) -->
    <svg xmlns="http://w3.org" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16" style="margin-right: 8px; vertical-align: middle;">
        <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2z"/>
        <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466"/>
    </svg>
    Limpiar
</a>

        </form>

        <div class="table-wrap">

            <table>
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Nombre completo</th>
                        <th>Rol</th>
                        <th>Estado actual</th>
                        <th>Acción</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($usuarios as $u): ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($u['usuario']) ?></strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($u['nombre_completo']) ?>
                        </td>

                        <td>
                            <?= $u['rol'] === 'admin' ? 'Administrador' : 'Usuario' ?>
                        </td>

                        <td>
                            <span class="<?= (int)$u['estado'] === 1 ? 'badge-active' : 'badge-blocked' ?>">
                                <?= (int)$u['estado'] === 1 ? 'Activo' : 'Bloqueado' ?>
                            </span>
                        </td>

                        <td>
                            <form method="POST" action="/Inventario/usuarios/guardar_bloquear_usuario.php">
                                <input type="hidden" name="usuario" value="<?= htmlspecialchars($u['usuario']) ?>">
                                <input type="hidden" name="estado_actual" value="<?= (int)$u['estado'] ?>">

                                <?php if ((int)$u['estado'] === 1): ?>
                                    <button type="submit" class="btn-block">
                                        Bloquear
                                    </button>
                                <?php else: ?>
                                    <button type="submit" class="btn-unblock">
                                        Desbloquear
                                    </button>
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (!$usuarios): ?>
                    <tr>
                        <td colspan="5" class="empty-table">
                            No hay usuarios registrados.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

        </div>

        <div class="pagination-wrap">

            <div class="pagination-info">
                Página <?= $pagina ?> de <?= $totalPaginas ?>
            </div>

            <div class="pagination">

                <?php if ($pagina > 1): ?>
                    <a href="<?= urlBloquear(['pagina' => $pagina - 1]) ?>">
                        Anterior
                    </a>
                <?php endif; ?>

                <?php for ($p = 1; $p <= $totalPaginas; $p++): ?>
                    <a
                        href="<?= urlBloquear(['pagina' => $p]) ?>"
                        class="<?= $p === $pagina ? 'active' : '' ?>">
                        <?= $p ?>
                    </a>
                <?php endfor; ?>

                <?php if ($pagina < $totalPaginas): ?>
                    <a href="<?= urlBloquear(['pagina' => $pagina + 1]) ?>">
                        Siguiente
                    </a>
                <?php endif; ?>

            </div>

        </div>

    </div>

</div>
<?php
require_once dirname(__DIR__) . '/layout_footer.php';
?>