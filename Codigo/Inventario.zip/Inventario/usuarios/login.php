<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PASO 1: CONFIGURAR E INICIAR SESIÓN SEGURA
|--------------------------------------------------------------------------
| Todo debe ejecutarse antes de session_start().
|--------------------------------------------------------------------------
*/
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.use_trans_sid', '0');

$usaHttps = (
    !empty($_SERVER['HTTPS'])
    && strtolower((string)$_SERVER['HTTPS']) !== 'off'
);

session_name('APP_INVENTARIO');

session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'domain'   => '',
    'secure'   => $usaHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| PASO 2: CARGAR CONEXIÓN MYSQL
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/db.php';

/*
|--------------------------------------------------------------------------
| PASO 3: FUNCIÓN PARA GUARDAR AUDITORÍA
|--------------------------------------------------------------------------
| La auditoría no debe impedir el funcionamiento del login.
*/
function registrarAuditoriaLogin(
    mysqli $conn,
    string $nombreCompleto,
    string $usuario,
    string $accion,
    string $detalle
): void {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'DESCONOCIDA';

        $stmtAuditoria = $conn->prepare("
            INSERT INTO auditoria (
                nombre_completo,
                usuario,
                accion,
                ip,
                fecha,
                detalle
            )
            VALUES (?, ?, ?, ?, NOW(), ?)
        ");

        if (!$stmtAuditoria) {
            return;
        }

        $stmtAuditoria->bind_param(
            'sssss',
            $nombreCompleto,
            $usuario,
            $accion,
            $ip,
            $detalle
        );

        $stmtAuditoria->execute();
        $stmtAuditoria->close();

    } catch (Throwable $errorAuditoria) {
        /*
        |----------------------------------------------------------------------
        | No se muestra este error al usuario para no bloquear el login.
        | Se puede registrar en el log de PHP si lo necesitas.
        |----------------------------------------------------------------------
        */
        error_log(
            'Error al registrar auditoría de login: '
            . $errorAuditoria->getMessage()
        );
    }
}

/*
|--------------------------------------------------------------------------
| PASO 4: VARIABLE PARA MOSTRAR ERRORES
|--------------------------------------------------------------------------
*/
$error = '';

/*
|--------------------------------------------------------------------------
| PASO 5: VALIDAR LOGIN CUANDO ENVÍAN EL FORMULARIO
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario = trim((string)($_POST['usuario'] ?? ''));
    $password = trim((string)($_POST['password'] ?? ''));

    /*
    |--------------------------------------------------------------------------
    | PASO 5.1: VALIDAR USUARIO
    |--------------------------------------------------------------------------
    */
    if (!preg_match(
        '/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,50}$/u',
        $usuario
    )) {
        $error = 'El usuario solo permite letras y espacios.';

    /*
    |--------------------------------------------------------------------------
    | PASO 5.2: VALIDAR CONTRASEÑA
    |--------------------------------------------------------------------------
    */
    } elseif (!preg_match('/^[A-Za-z0-9.]{6,30}$/', $password)) {
        $error = 'La contraseña solo permite letras, números y punto.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | PASO 5.3: BUSCAR USUARIO
        |--------------------------------------------------------------------------
        */
        $stmtUsuario = $conn->prepare("
            SELECT
                usuario,
                nombre_completo,
                password,
                rol,
                estado,
                puede_configurar_metas,
                COALESCE(intentos, 0) AS intentos
            FROM usuarios
            WHERE usuario = ?
            LIMIT 1
        ");

        if (!$stmtUsuario) {
            $error = 'No fue posible validar el usuario.';
        } else {
            $stmtUsuario->bind_param('s', $usuario);
            $stmtUsuario->execute();

            $resultadoUsuario = $stmtUsuario->get_result();
            $user = $resultadoUsuario
                ? $resultadoUsuario->fetch_assoc()
                : null;

            $stmtUsuario->close();

            /*
            |--------------------------------------------------------------------------
            | PASO 5.4: VALIDAR EXISTENCIA, ESTADO E INTENTOS
            |--------------------------------------------------------------------------
            */
            if (!$user) {
                /*
                | No se puede incrementar intentos porque el usuario no existe.
                */
                $error = 'Usuario o contraseña incorrectos.';

            } elseif ((int)$user['estado'] !== 1) {
                $error = 'Usuario bloqueado.';

            } elseif ((int)$user['intentos'] >= 5) {
                /*
                | Seguridad adicional: si tiene 5 intentos, se asegura el bloqueo.
                */
                $stmtBloqueo = $conn->prepare("
                    UPDATE usuarios
                    SET estado = 0
                    WHERE usuario = ?
                ");

                if ($stmtBloqueo) {
                    $stmtBloqueo->bind_param('s', $user['usuario']);
                    $stmtBloqueo->execute();
                    $stmtBloqueo->close();
                }

                $error = 'Usuario bloqueado por superar los 5 intentos.';

            } elseif (
                $user['usuario'] !== $usuario ||
                !password_verify($password, $user['password'])
            ) {
                /*
                |--------------------------------------------------------------------------
                | PASO 5.5: CONTRASEÑA INCORRECTA
                |--------------------------------------------------------------------------
                */
                $nuevosIntentos = (int)$user['intentos'] + 1;
                $nombreCompleto = trim(
                    (string)($user['nombre_completo'] ?? '')
                );

                if ($nuevosIntentos >= 5) {
                    $stmtIntentos = $conn->prepare("
                        UPDATE usuarios
                        SET
                            intentos = ?,
                            estado = 0
                        WHERE usuario = ?
                    ");

                    $error = 'Usuario bloqueado tras 5 intentos incorrectos.';
                } else {
                    $stmtIntentos = $conn->prepare("
                        UPDATE usuarios
                        SET intentos = ?
                        WHERE usuario = ?
                    ");

                    $intentosRestantes = 5 - $nuevosIntentos;

                    $error = 'Usuario o contraseña incorrectos. '
                           . "Le quedan {$intentosRestantes} intentos.";
                }

                if ($stmtIntentos) {
                    $stmtIntentos->bind_param(
                        'is',
                        $nuevosIntentos,
                        $user['usuario']
                    );

                    $stmtIntentos->execute();
                    $stmtIntentos->close();
                }

                /*
                |--------------------------------------------------------------------------
                | PASO 5.6: GUARDAR EL FALLO EN AUDITORÍA
                |--------------------------------------------------------------------------
                | Aunque después el usuario ingrese correctamente y sus intentos
                | vuelvan a cero, este registro seguirá guardado.
                */
                $detalleAuditoria = $nuevosIntentos >= 5
                    ? 'Intento fallido 5 de 5. El usuario fue bloqueado.'
                    : "Intento fallido {$nuevosIntentos} de 5.";

                registrarAuditoriaLogin(
                    $conn,
                    $nombreCompleto,
                    (string)$user['usuario'],
                    'LOGIN_FALLIDO',
                    $detalleAuditoria
                );

            } else {

                /*
                |--------------------------------------------------------------------------
                | PASO 5.7: LOGIN EXITOSO
                |--------------------------------------------------------------------------
                | Se reinician los intentos consecutivos y se actualiza el último
                | acceso. Esto debe mantenerse por seguridad.
                */
                $updateLogin = $conn->prepare("
                    UPDATE usuarios
                    SET
                        ultimo_login = NOW(),
                        intentos = 0
                    WHERE usuario = ?
                ");

                if (!$updateLogin) {
                    $error = 'No fue posible actualizar el acceso.';
                } else {
                    $updateLogin->bind_param('s', $user['usuario']);
                    $updateLogin->execute();
                    $updateLogin->close();

                    /*
                    |--------------------------------------------------------------------------
                    | PASO 5.8: CREAR SESIÓN
                    |--------------------------------------------------------------------------
                    */
                    session_regenerate_id(true);

                    $_SESSION['usuario'] = $user['usuario'];
                    $_SESSION['nombre_completo'] = $user['nombre_completo'];
                    $_SESSION['rol'] = $user['rol'];

                    $_SESSION['puede_configurar_metas'] =
                        (int)($user['puede_configurar_metas'] ?? 0);

                    $_SESSION['login_time'] = time();

                    header('Location: ../index.php');
                    exit;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login - Inventario</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- PASO 5: FUENTE INTER -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="login.css">
<link rel="shortcut icon" type="image/png" href="/Inventario/img/plan.png">



</head>

<body>


<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login - Inventario</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- PASO 5: FUENTE INTER -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="login.css">
<link rel="shortcut icon" type="image/png" href="/Inventario/img/plan.png">



</head>

<body>

<!-- Envuelta general para el diseño de dos columnas -->
<div class="login-wrapper">

    <!-- TU TARJETA DE LOGIN -->
    <div class="login-card">
        <!-- ENCABEZADO -->
        <div class="logo">
            <div class="logo-image-container">
                <!--<img src="/Inventario/img/logomcc.png" alt="Grupo MCC" class="brand-logo"> -->
            </div>
        </div>

        <!-- CUERPO DEL FORMULARIO -->
        <div class="form-body">
            <div class="login-title">
                <h1>Bienvenidos</h1>
                <p>Ingresa tus credenciales para continuar</p>
            </div>

            <?php if (isset($error) && $error): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" autocomplete="off">
                
                <div class="form-group">
                    <div class="input-box">
                        <span class="field-icon">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        </span>
                        <input type="text" name="usuario" id="usuario" placeholder="admin" required maxlength="50">
                    </div>
                </div>

               
                <div class="form-group password-group">
                    <div class="input-box">
                        <span class="field-icon">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        </span>
                        <input type="password" name="password" id="password" placeholder="••••••••••••" required maxlength="30">
                        <button type="button" id="togglePassword" class="toggle-pass" title="Ver contraseña">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        </button>
                    </div>
                </div>

             
                <button type="submit" class="btn-submit">Ingresar</button>
            </form>
        </div>

   
        <div class="footer">
            © <?= date('Y') ?> GRUPO MCC
        </div>
    </div>

    <!-- PANEL DERECHO: EL LOGO GRANDE VISUAL -->
    <div class="login-visual">
        <img src="/Inventario/img/logo.png" alt="Grupo MCC Grande" class="visual-logo">
        <div class="deco-dots"></div>
    </div>

</div>


<script>
/*
|--------------------------------------------------------------------------
| PASO 27: BLOQUEAR CARACTERES NO PERMITIDOS EN USUARIO
|--------------------------------------------------------------------------
*/
const usuario = document.getElementById('usuario');

usuario.addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
});

/*
|--------------------------------------------------------------------------
| PASO 28: BLOQUEAR CARACTERES NO PERMITIDOS EN CONTRASEÑA
|--------------------------------------------------------------------------
*/
const password = document.getElementById('password');

password.addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-z0-9.]/g, '');
});

/*
|--------------------------------------------------------------------------
| PASO 29: MOSTRAR / OCULTAR CONTRASEÑA
|--------------------------------------------------------------------------
*/
const togglePassword = document.getElementById('togglePassword');
const eyeIcon = document.getElementById('eyeIcon');

togglePassword.addEventListener('click', function () {
    if (password.type === 'password') {
        password.type = 'text';
        togglePassword.title = 'Ocultar contraseña';

        eyeIcon.innerHTML = `
            <path d="M3 3L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M10.6 10.6A3 3 0 0 0 13.4 13.4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M9.8 5.8A8.5 8.5 0 0 1 12 5.5C18.5 5.5 22.5 12 22.5 12A18.6 18.6 0 0 1 19.2 15.8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M6.2 6.9C3.3 8.8 1.5 12 1.5 12S5.5 18.5 12 18.5C13.7 18.5 15.2 18.1 16.5 17.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        `;
    } else {
        password.type = 'password';
        togglePassword.title = 'Ver contraseña';

        eyeIcon.innerHTML = `
            <path d="M1.5 12S5.5 5.5 12 5.5 22.5 12 22.5 12 18.5 18.5 12 18.5 1.5 12 1.5 12Z"
                  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3"
                    stroke="currentColor" stroke-width="2"/>
        `;
    }
});
</script>

</body>
</html>