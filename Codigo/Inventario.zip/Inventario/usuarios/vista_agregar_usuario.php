<?php
require_once __DIR__ . '/auth.php';
require_admin();

// Si ya hay una sesión activa, la cerramos para poder cambiar el nombre
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); 
}
session_name('APP_INVENTARIO');

// Iniciamos la sesión de nuevo
session_start();



// 2. CORRECCIÓN CRÍTICA: Declarar la lista de administradores permitidos
$admins_autorizados = ['lvalladares','jcruz'];

// 3. Validar de inmediato. Si no es 'lvalladares', redirigir ANTES de abrir buffers de datos o cargar la BD
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario'], $admins_autorizados)) {
    header("Location: " . $baseUrl . "/dashboard.php?error=no_autorizado");
    exit();
}
require_once __DIR__ . '/db.php';

require_once dirname(__DIR__) . '/layout_menu.php';

?>


<link rel="stylesheet" href="<?= $baseUrl ?>/usuarios/agregar.css?v=<?= time() ?>">

<div class="user-page">

    <div class="page-head">
        <div>
            <h2></h2>
            <p></p>
        </div>
    </div>

    <?php if (isset($_GET['ok'])): ?>
        <div class="alert success">Usuario creado correctamente.</div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert danger">No se pudo crear el usuario.</div>
    <?php endif; ?>

    <div class="user-card">

        <div class="card-title">
            <h3></h3>
            <span>Configuración</span>
        </div>

        <form method="POST" action="guardar_usuario.php" autocomplete="off">

            <div class="form-grid">

                <div class="form-group">
                    <label>Usuario</label>
                    <input type="text" name="usuario" id="usuario" maxlength="50" required>
                    <small>Solo letras y espacios.</small>
                </div>

                <div class="form-group">
                    <label>Nombre completo</label>
                    <input type="text" name="nombre_completo" id="nombre_completo" maxlength="100" required>
                    <small>Nombre visible dentro del sistema.</small>
                </div>

                <div class="form-group">
                    <label>Contraseña</label>

                    <div class="password-box">
                        <input type="password" name="password" id="password" maxlength="30" required>

                        <button type="button" id="togglePass" title="Ver contraseña">
                            Ver
                        </button>
                    </div>

                    <small>Letras, números y punto. Mínimo 6 caracteres.</small>
                </div>

                <div class="form-group">
                    <label>Rol</label>
                    <select name="rol" required>
                        <option value="usuario">Usuario normal</option>
                        <option value="admin">Administrador</option>
                    </select>
                    <small>El administrador ve usuarios y auditoría.</small>
                </div>

               

           <div class="actions">
    <button type="submit" class="btn-primary">
        <!-- Icono de guardar lineal -->
        <svg xmlns="http://w3.org" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-save" viewBox="0 0 24 24" style="margin-right: 8px; vertical-align: middle;">
            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
            <polyline points="17 21 17 13 7 13 7 21"></polyline>
            <polyline points="7 3 7 8 15 8"></polyline>
        </svg>
        Guardar
    </button>

    <button type="reset" class="btn-secondary">
  <!-- Icono bi-x-circle de Bootstrap Icons -->
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16" style="margin-right: 8px; vertical-align: middle;">
    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
    <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
  </svg>
  Cancelar
</button>

</div>


        </form>

    </div>

</div>
<script>
document.getElementById('usuario').addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
});

document.getElementById('nombre_completo').addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
});

document.getElementById('password').addEventListener('input', function () {
    this.value = this.value.replace(/[^A-Za-z0-9.]/g, '');
});

document.getElementById('togglePass').addEventListener('click', function () {
    const pass = document.getElementById('password');

    if (pass.type === 'password') {
        pass.type = 'text';
        this.textContent = 'Ocultar';
    } else {
        pass.type = 'password';
        this.textContent = 'Ver';
    }
});
</script>

<?php
require_once dirname(__DIR__) . '/layout_footer.php';
?>