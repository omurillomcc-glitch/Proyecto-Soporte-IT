<?php
// Si ya hay una sesión activa, la cerramos para poder cambiar el nombre
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); 
}
session_name('APP_INVENTARIO');

// Iniciamos la sesión de nuevo
session_start();


require_once __DIR__ . '/auth.php';
require_admin();

// Declarar la lista de permitidos antes de evaluarla
$admins_autorizados = ['lvalladares', 'jcruz'];

// Si el usuario en sesión NO es un administrador autorizado, se le deniega el acceso automáticamente
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario'], $admins_autorizados, true)) {
    header("Location: " . $baseUrl . "/dashboard.php?error=no_autorizado");
    exit();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';

$usuario = trim($_POST['usuario'] ?? '');
$nombre  = trim($_POST['nombre_completo'] ?? '');
$pass    = trim($_POST['password'] ?? '');
$rol     = trim($_POST['rol'] ?? 'usuario');
$estado  = (int)($_POST['estado'] ?? 1);

/*
|--------------------------------------------------------------------------
| VALIDACIONES MEJORADAS (Redireccionan en lugar de matar el script con die)
|--------------------------------------------------------------------------
*/
// Permite letras, números y guiones bajos (ideal para nombres de usuario como lvalladares)
if (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $usuario)) {
    header("Location: vista_agregar_usuario.php?error=usuario_invalido");
    exit();
}

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/u', $nombre)) {
    header("Location: vista_agregar_usuario.php?error=nombre_invalido");
    exit();
}

// Permite letras, números, puntos y caracteres especiales comunes en contraseñas
if (!preg_match('/^[A-Za-z0-9.@$!%*?&]{6,30}$/', $pass)) {
    header("Location: vista_agregar_usuario.php?error=password_invalido");
    exit();
}

if (!in_array($rol, ['usuario', 'admin'], true)) {
    header("Location: vista_agregar_usuario.php?error=rol_invalido");
    exit();
}

$estado = $estado === 1 ? 1 : 0;
$intentos = 0; // Inicia con 0 intentos fallidos de forma explícita.

$hash = password_hash($pass, PASSWORD_DEFAULT);

/*
|--------------------------------------------------------------------------
| PASO 1: INSERTAR EL NUEVO USUARIO
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    INSERT INTO usuarios (
        usuario,
        nombre_completo,
        password,
        rol,
        estado,
        intentos
    )
    VALUES (?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    header("Location: vista_agregar_usuario.php?error=error_conexion");
    exit();
}

$stmt->bind_param(
    "ssssii",
    $usuario,
    $nombre,
    $hash,
    $rol,
    $estado,
    $intentos
);

if ($stmt->execute()) {
    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | REGISTRO DE AUDITORÍA
    |--------------------------------------------------------------------------
    */
    $rolTexto = $rol === 'admin' ? 'Administrador' : 'Usuario';
    $estadoTexto = $estado === 1 ? 'Activo' : 'Bloqueado';

    $detalleUsuario = sprintf(
        "Creación administrativa de usuario\n" .
        "Usuario creado: %s\n" .
        "Nombre completo: %s\n" .
        "Rol asignado: %s\n" .
        "Estado inicial: %s\n" .
        "Intentos iniciales: %d\n" .
        "Seguridad: La contraseña fue registrada de forma cifrada.\n" .
        "Resultado: El usuario fue creado correctamente y ya puede acceder al sistema.",
        $usuario,
        $nombre,
        $rolTexto,
        $estadoTexto,
        $intentos
    );

    registrar_auditoria(
        'USUARIO_CREADO',
        $detalleUsuario
    );

    header("Location: vista_agregar_usuario.php?ok=1");
    exit();
}

// Manejo final si la base de datos rechaza la inserción (ej: usuario duplicado)
if ($stmt) {
    $stmt->close();
}
header("Location: vista_agregar_usuario.php?error=guardar_fallo");
exit();
