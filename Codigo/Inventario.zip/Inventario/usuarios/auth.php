<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| INICIAR CONFIGURACIÓN SOLO SI NO HAY SESIÓN ACTIVA
|--------------------------------------------------------------------------
| Ponemos el escudo arriba del todo. Si la sesión ya viene activa, se saltará
| todo este bloque evitando que aparezcan los molestos Warnings en la pantalla.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) {

    /*
    |--------------------------------------------------------------------------
    | CONFIGURACIÓN SEGURA DE LA SESIÓN
    |--------------------------------------------------------------------------
    */
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');

    /*
    |--------------------------------------------------------------------------
    | ACTIVAR COOKIE SECURE SOLO CUANDO HAYA HTTPS
    |--------------------------------------------------------------------------
    */
    $usaHttps = (
        !empty($_SERVER['HTTPS'])
        && $_SERVER['HTTPS'] !== 'off'
    );

    if ($usaHttps) {
        ini_set('session.cookie_secure', '1');
    }

    /*
    |--------------------------------------------------------------------------
    | INICIAR SESIÓN DEL SISTEMA
    |--------------------------------------------------------------------------
    */
    session_name('APP_INVENTARIO');
    session_start();
}

/*
|--------------------------------------------------------------------------
| CERRAR SESIÓN DE FORMA SEGURA
|--------------------------------------------------------------------------
*/
function destruir_sesion(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $parametros = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $parametros['path'],
            $parametros['domain'],
            $parametros['secure'],
            $parametros['httponly']
        );
    }

    session_destroy();
}

/*
|--------------------------------------------------------------------------
| VALIDAR QUE EL USUARIO ESTÉ LOGUEADO
|--------------------------------------------------------------------------
*/
function require_login(): void
{
    if (empty($_SESSION['usuario'])) {
        header('Location: login.php');
        exit;
    }

    $tiempoMaximo = 86400; // 24 horas

    if (!isset($_SESSION['login_time'])) {
        $_SESSION['login_time'] = time();
    }

    if ((time() - (int)$_SESSION['login_time']) > $tiempoMaximo) {
        destruir_sesion();

        header('Location: login.php?sesion=expirada');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| SABER SI EL USUARIO ES ADMINISTRADOR
|--------------------------------------------------------------------------
*/
function es_admin(): bool
{
    return ($_SESSION['rol'] ?? '') === 'admin';
}

/*
|--------------------------------------------------------------------------
| VALIDAR SOLO ADMIN
|--------------------------------------------------------------------------
*/
function require_admin(): void
{
    require_login();

    if (!es_admin()) {
        http_response_code(403);

        header('Location: index.php');
        exit;
    }
}
