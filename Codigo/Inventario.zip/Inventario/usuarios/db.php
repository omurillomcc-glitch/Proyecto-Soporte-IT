<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "plan_inventario";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    // ❌ NO usamos die()
    // Solo dejamos $conn como null para que el sistema no rompa el JSON
    $conn = null;
    return;
}

$conn->set_charset("utf8mb4");