<?php

require_once __DIR__ . '/auth.php';
require_admin();

// Si ya hay una sesión activa, la cerramos para poder cambiar el nombre
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); 
}

session_name('APP_INVENTARIO');

// Iniciamos la sesión de nuevo
session_start();


// 2. CORRECCIÓN CRÍTICA: Declarar la lista de administradores permitidos
$admins_autorizados = ['lvalladares','jcruz'];

// 3. Validar de inmediato. Si no es 'lvalladares', redirigir ANTES de abrir buffers de datos o cargar la BD
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario'], $admins_autorizados)) {
    header("Location: " . $baseUrl . "/dashboard.php?error=no_autorizado");
    exit();
}


require_once __DIR__ . '/db.php';


/*
|--------------------------------------------------------------------------
| PASO 3: CONFIGURAR PAGINACIÓN
|--------------------------------------------------------------------------
*/
$porPaginaPermitidos = [100, 200, 500];

$porPagina = (int)($_GET['por_pagina'] ?? 100);

if (!in_array($porPagina, $porPaginaPermitidos, true)) {
    $porPagina = 100;
}

$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$offset = ($pagina - 1) * $porPagina;

/*
|--------------------------------------------------------------------------
| PASO 4: BUSCADOR
|--------------------------------------------------------------------------
*/
$buscar = trim($_GET['buscar'] ?? '');

$where = "";
$params = [];
$types  = "";

if ($buscar !== '') {
    $where = "
        WHERE 
            usuario LIKE ?
            OR nombre_completo LIKE ?
            OR rol LIKE ?
    ";

    $like = "%{$buscar}%";

    $params = [$like, $like, $like];
    $types  = "sss";
}

/*
|--------------------------------------------------------------------------
| PASO 5: CONTAR TOTAL DE USUARIOS
|--------------------------------------------------------------------------
*/
$sqlCount = "
    SELECT COUNT(*) AS total
    FROM usuarios
    {$where}
";

$stmtCount = $conn->prepare($sqlCount);

if ($types !== "") {
    $stmtCount->bind_param($types, ...$params);
}

$stmtCount->execute();

$totalRegistros = (int)($stmtCount->get_result()->fetch_assoc()['total'] ?? 0);

$totalPaginas = max(1, (int)ceil($totalRegistros / $porPagina));

if ($pagina > $totalPaginas) {
    $pagina = $totalPaginas;
    $offset = ($pagina - 1) * $porPagina;
}

/*
|--------------------------------------------------------------------------
| PASO 6: CONSULTAR USUARIOS DE LA PÁGINA ACTUAL
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT 
        usuario,
        nombre_completo,
        rol,
        estado,
        creado_en
    FROM usuarios
    {$where}
    ORDER BY nombre_completo ASC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);

if ($types !== "") {
    $typesFinal = $types . "ii";
    $paramsFinal = array_merge($params, [$porPagina, $offset]);

    $stmt->bind_param($typesFinal, ...$paramsFinal);
} else {
    $stmt->bind_param("ii", $porPagina, $offset);
}

$stmt->execute();

$res = $stmt->get_result();

$usuarios = [];

while ($row = $res->fetch_assoc()) {
    $usuarios[] = $row;
}

/*
|--------------------------------------------------------------------------
| PASO 7: CARGAR MENÚ PRINCIPAL
|--------------------------------------------------------------------------
*/
require_once dirname(__DIR__) . '/layout_menu.php';

/*
|--------------------------------------------------------------------------
| PASO 8: FUNCIÓN PARA MANTENER QUERY STRING
|--------------------------------------------------------------------------
*/
function urlEditar(array $extra = []): string
{
    $query = array_merge($_GET, $extra);

    return '/Inventario/usuarios/editar_usuario.php?' . http_build_query($query);
}
?>


<link rel="stylesheet" href="<?= $baseUrl ?>/usuarios/editar.css?v=<?= time() ?>">
<div class="user-page">

    <!-- PASO 9: ENCABEZADO -->
    <div class="page-head">
        <div>
            <h2></h2>
            <p></p>
        </div>
    </div>

    <!-- PASO 10: MENSAJES -->
    <?php if (isset($_GET['ok'])): ?>
        <div class="alert success">
            Usuario actualizado correctamente.
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>

        <?php
        $mensajeError = "No se pudo actualizar el usuario.";

        if ($_GET['error'] === 'no_quitar_admin') {
            $mensajeError = "Eres administrador. No puedes quitarte tu propio permiso de administrador.";
        } elseif ($_GET['error'] === 'password_invalido') {
            $mensajeError = "La contraseña debe tener mínimo 6 caracteres y solo puede incluir letras, números y punto.";
        } elseif ($_GET['error'] === 'nombre_invalido') {
            $mensajeError = "El nombre completo solo permite letras y espacios.";
        }
        ?>

        <div class="alert danger">
            <?= htmlspecialchars($mensajeError) ?>
        </div>

    <?php endif; ?>

    <!-- PASO 11: CARD PRINCIPAL -->
    <div class="user-card">

        <div class="card-title">
            <div>
                <h3></h3>
                <p>
                
                </p>
            </div>

            <span><?= $totalRegistros ?> usuarios</span>
        </div>

        <!-- PASO 12: FILTROS -->
        <form method="GET" class="filter-bar">

            <input
                type="text"
                name="buscar"
                value="<?= htmlspecialchars($buscar) ?>"
                placeholder="Buscar usuario, nombre o rol">

            <select name="por_pagina">
                <option value="100" <?= $porPagina === 100 ? 'selected' : '' ?>>100</option>
                <option value="200" <?= $porPagina === 200 ? 'selected' : '' ?>>200</option>
                <option value="500" <?= $porPagina === 500 ? 'selected' : '' ?>>500</option>
                
            </select>

           <button type="submit" class="btn-submit" style="display: inline-flex; align-items: center;">
    <!-- Icono bi-search (Lupa) -->
    <svg xmlns="http://w3.org" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16" style="margin-right: 8px; vertical-align: middle;">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
    </svg>
    Buscar
</button>

<a href="/Inventario/usuarios/editar_usuario.php" class="btn-clear" style="display: inline-flex; align-items: center; text-decoration: none;">
    <!-- Icono bi-arrow-clockwise (Limpiar/Recargar) -->
    <svg xmlns="http://w3.org" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16" style="margin-right: 8px; vertical-align: middle;">
        <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2z"/>
        <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466"/>
    </svg>
    Limpiar
</a>


        </form>

        <!-- PASO 13: TABLA -->
        <div class="table-wrap">

            <table>
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Nombre completo</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th>Contraseña / Acción</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($usuarios as $i => $u): ?>

                    <?php $formId = 'formEditar_' . $i; ?>

                    <tr>

                        <td>
                            <strong><?= htmlspecialchars($u['usuario']) ?></strong>

                            <form
                                id="<?= $formId ?>"
                                method="POST"
                                action="/Inventario/usuarios/guardar_editar_usuario.php"
                                autocomplete="off">

                                <input
                                    type="hidden"
                                    name="usuario_original"
                                    value="<?= htmlspecialchars($u['usuario']) ?>">
                            </form>
                        </td>

                        <td>
                            <input
                                form="<?= $formId ?>"
                                type="text"
                                name="nombre_completo"
                                class="input-table solo-letras"
                                value="<?= htmlspecialchars($u['nombre_completo']) ?>"
                                maxlength="100"
                                required>
                        </td>

                        <td>
                            <select
                                form="<?= $formId ?>"
                                name="rol"
                                class="input-table">

                                <option value="usuario" <?= $u['rol'] === 'usuario' ? 'selected' : '' ?>>
                                    Usuario
                                </option>

                                <option value="admin" <?= $u['rol'] === 'admin' ? 'selected' : '' ?>>
                                    Administrador
                                </option>

                            </select>
                        </td>

                        <td>
                            <span class="<?= (int)$u['estado'] === 1 ? 'badge-active' : 'badge-blocked' ?>">
                                <?= (int)$u['estado'] === 1 ? 'Activo' : 'Bloqueado' ?>
                            </span>
                        </td>

                        <td>
                            <input
                                form="<?= $formId ?>"
                                type="password"
                                name="password"
                                class="input-table password-edit"
                                placeholder="Nueva contraseña"
                                maxlength="30">

                            <button
                                form="<?= $formId ?>"
                                type="submit"
                                class="btn-save">
                                Guardar
                            </button>
                        </td>

                    </tr>

                <?php endforeach; ?>

                <?php if (!$usuarios): ?>
                    <tr>
                        <td colspan="5" class="empty-table">
                            No hay usuarios registrados.
                        </td>
                    </tr>
                <?php endif; ?>

                </tbody>
            </table>

        </div>

        <!-- PASO 14: PAGINACIÓN -->
        <div class="pagination-wrap">

            <div class="pagination-info">
                Página <?= $pagina ?> de <?= $totalPaginas ?>
            </div>

            <div class="pagination">

                <?php if ($pagina > 1): ?>
                    <a href="<?= urlEditar(['pagina' => $pagina - 1]) ?>">
                        Anterior
                    </a>
                <?php endif; ?>

                <?php for ($p = 1; $p <= $totalPaginas; $p++): ?>
                    <a
                        href="<?= urlEditar(['pagina' => $p]) ?>"
                        class="<?= $p === $pagina ? 'active' : '' ?>">
                        <?= $p ?>
                    </a>
                <?php endfor; ?>

                <?php if ($pagina < $totalPaginas): ?>
                    <a href="<?= urlEditar(['pagina' => $pagina + 1]) ?>">
                        Siguiente
                    </a>
                <?php endif; ?>

            </div>

        </div>

    </div>

</div>
<script>
document.querySelectorAll('.solo-letras').forEach(input => {
    input.addEventListener('input', function () {
        this.value = this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]/g, '');
    });
});

document.querySelectorAll('.password-edit').forEach(input => {
    input.addEventListener('input', function () {
        this.value = this.value.replace(/[^A-Za-z0-9.]/g, '');
    });
});
</script>

<?php
require_once dirname(__DIR__) . '/layout_footer.php';
?>