<?php

ob_start();

// 1. Cargar la autenticación de tu sistema primero
require_once __DIR__ . '/auth.php';
require_admin(); // Valida si es 'admin'

// 2. EXCEPCIÓN: Validar de forma estricta que el usuario sea 'lvalladares' o 'jcruz'
$admins_autorizados = ['lvalladares', 'jcruz'];

if (
    !isset($_SESSION['usuario']) ||
    !in_array($_SESSION['usuario'], $admins_autorizados)
) {
    header(
        "Location: "
        . $baseUrl
        . "/dashboard.php?error=no_autorizado"
    );
    exit();
}

// 3. Cargar el resto de dependencias si la validación es exitosa
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php';

$volver = '/Inventario/usuarios/bloquear_usuario.php';

function volver_bloqueo(string $error = ''): void
{
    global $volver;

    if ($error !== '') {
        header("Location: {$volver}?error={$error}");
    } else {
        header("Location: {$volver}?ok=1");
    }

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    volver_bloqueo('metodo_invalido');
}

$usuario = trim($_POST['usuario'] ?? '');
$estadoActual = (int)($_POST['estado_actual'] ?? 1);

// Validación corregida para aceptar letras, números, guiones
// y caracteres comunes de nombres de usuario
if (
    !preg_match(
        '/^[A-Za-z0-9_ÁÉÍÓÚáéíóúÑñ ]{3,50}$/u',
        $usuario
    )
) {
    volver_bloqueo('usuario_invalido');
}

$nuevoEstado = $estadoActual === 1 ? 0 : 1;

/*
|--------------------------------------------------------------------------
| CORRECCIÓN
|--------------------------------------------------------------------------
| Al bloquear o desbloquear manualmente, los intentos quedan en cero.
| Los intentos fallidos solamente deben aumentarse desde el login.
*/
$nuevosIntentos = 0;

/*
|--------------------------------------------------------------------------
| NO PERMITIR QUE EL ADMIN SE BLOQUEE A SÍ MISMO
|--------------------------------------------------------------------------
*/
if (
    $usuario === ($_SESSION['usuario'] ?? '') &&
    $nuevoEstado === 0
) {
    volver_bloqueo('no_bloquearse');
}

// Obtener también el nombre completo del usuario afectado
$stmtExiste = $conn->prepare("
    SELECT usuario, nombre_completo
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

if (!$stmtExiste) {
    volver_bloqueo('prepare_existe');
}

$stmtExiste->bind_param("s", $usuario);
$stmtExiste->execute();

$resExiste = $stmtExiste->get_result();

if (!$resExiste || $resExiste->num_rows === 0) {
    $stmtExiste->close();
    volver_bloqueo('no_existe');
}

$datosUsuario = $resExiste->fetch_assoc();

$nombreCompletoAfectado =
    $datosUsuario['nombre_completo'] ?? '';

$stmtExiste->close();

/*
|--------------------------------------------------------------------------
| ACTUALIZACIÓN DEL ESTADO DEL USUARIO
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    UPDATE usuarios
    SET estado = ?,
        intentos = ?
    WHERE usuario = ?
");

if (!$stmt) {
    volver_bloqueo('prepare_update');
}

$stmt->bind_param(
    "iis",
    $nuevoEstado,
    $nuevosIntentos,
    $usuario
);

if ($stmt->execute()) {
    $stmt->close();

    /*
    |--------------------------------------------------------------------------
    | REGISTRO DE AUDITORÍA
    |--------------------------------------------------------------------------
    */
    $accionAuditoria = $nuevoEstado === 0
        ? 'USUARIO_BLOQUEADO'
        : 'USUARIO_DESBLOQUEADO';

    $estadoAnteriorTexto = $estadoActual === 1
        ? 'Activo'
        : 'Bloqueado';

    $estadoNuevoTexto = $nuevoEstado === 1
        ? 'Activo'
        : 'Bloqueado';

    $accionTexto = $nuevoEstado === 0
        ? 'Bloqueo administrativo de usuario'
        : 'Desbloqueo administrativo de usuario';

    $motivoTexto = $nuevoEstado === 0
        ? 'El acceso del usuario fue suspendido por decisión administrativa.'
        : 'El acceso del usuario fue restablecido por decisión administrativa.';

    $detalleAuditoria = sprintf(
        "%s\n"
        . "Usuario afectado: %s\n"
        . "Nombre completo: %s\n"
        . "Estado anterior: %s\n"
        . "Estado actual: %s\n"
        . "Intentos configurados: %d\n"
        . "Resultado: %s",
        $accionTexto,
        $usuario,
        $nombreCompletoAfectado !== ''
            ? $nombreCompletoAfectado
            : 'No disponible',
        $estadoAnteriorTexto,
        $estadoNuevoTexto,
        $nuevosIntentos,
        $motivoTexto
    );

    registrar_auditoria(
        $accionAuditoria,
        $detalleAuditoria
    );

    volver_bloqueo();

} else {
    $stmt->close();
    volver_bloqueo('guardar');
}