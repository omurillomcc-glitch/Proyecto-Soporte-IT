<?php
/*
|--------------------------------------------------------------------------
| PASO 1: CARGAR AUTENTICACIÓN
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/auth.php';
require_login();

/*
|--------------------------------------------------------------------------
| PASO 2: CARGAR CONEXIÓN MYSQL
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/db.php';

/*
|--------------------------------------------------------------------------
| PASO 3: CARGAR MENÚ PRINCIPAL
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../layout_menu.php';

/*
|--------------------------------------------------------------------------
| PASO 4: OBTENER USUARIO DE LA SESIÓN
|--------------------------------------------------------------------------
*/
$usuarioSesion = $_SESSION['usuario'] ?? '';

/*
|--------------------------------------------------------------------------
| PASO 5: CONSULTAR PERFIL DEL USUARIO LOGUEADO
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT 
        usuario,
        nombre_completo,
        rol,
        estado,
        creado_en,
        ultimo_login
    FROM usuarios
    WHERE usuario = ?
    LIMIT 1
");

if (!$stmt) {
    die("Error en prepare: " . $conn->error);
}

$stmt->bind_param("s", $usuarioSesion);
$stmt->execute();

$resultado = $stmt->get_result();
$perfil = $resultado->fetch_assoc();

if (!$perfil) {
    echo "<div class='alert alert-danger'>No se encontró la información del perfil.</div>";
    require_once __DIR__ . '/../layout_footer.php';
    exit;
}

/*
|--------------------------------------------------------------------------
| PASO 6: FUNCIÓN PARA EVITAR HTML INSEGURO
|--------------------------------------------------------------------------
*/
function h($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| PASO 7: FORMATEAR DATOS
|--------------------------------------------------------------------------
*/
$nombre = $perfil['nombre_completo'] ?: $perfil['usuario'];

// Extraer únicamente la 1ª letra del primer nombre y la 1ª letra del primer apellido
$partesNombre = array_filter(explode(' ', trim($nombre)));
if (count($partesNombre) >= 2) {
    $primerNombre = array_shift($partesNombre);
    $primerApellido = array_shift($partesNombre);
    $iniciales = mb_strtoupper(mb_substr($primerNombre, 0, 1) . mb_substr($primerApellido, 0, 1), 'UTF-8');
} else {
    // Si solo hay una palabra, toma las 2 primeras letras
    $iniciales = mb_strtoupper(mb_substr($nombre, 0, 2), 'UTF-8');
}

$rolTexto = $perfil['rol'] === 'admin' ? 'Administrador' : 'Usuario';
$estadoTexto = ((int)$perfil['estado'] === 1) ? 'Cuenta Activa' : 'Cuenta Bloqueada';

$fechaCreacion = !empty($perfil['creado_en'])
    ? date('d/m/Y h:i A', strtotime($perfil['creado_en']))
    : 'No disponible';

$ultimoLogin = !empty($perfil['ultimo_login'])
    ? date('d/m/Y h:i A', strtotime($perfil['ultimo_login']))
    : 'No disponible';
?>

<link rel="stylesheet" href="<?= $baseUrl ?>/usuarios/perfil.css?v=<?= time() ?>">

<div class="perfil-wrapper">

    <div class="perfil-card">

        <!-- ==========================================
             SIDEBAR: PANEL LATERAL DE RESUMEN
             ========================================== -->
        <aside class="perfil-sidebar">
            <div class="perfil-avatar-wrapper">
                <div class="perfil-avatar"><?= h($iniciales) ?></div>
                <span class="status-indicator <?= ((int)$perfil['estado'] === 1) ? 'active' : '' ?>"></span>
            </div>

            <p class="sidebar-role"><?= h($rolTexto) ?></p>

            <div class="sidebar-status-box">
                <div class="estado-pill <?= ((int)$perfil['estado'] === 1) ? 'estado-activo' : 'estado-bloqueado' ?>">
                    <span class="estado-dot"></span>
                    <span><?= h($estadoTexto) ?></span>
                </div>
            </div>

            
        </aside>

        <!-- ==========================================
             CUERPO PRINCIPAL: DATOS Y SECCIONES
             ========================================== -->
        <main class="perfil-body">

            <!-- SECCIÓN 1: INFORMACIÓN PERSONAL -->
            <section class="perfil-section">
                <div class="perfil-section-head">
                    <div class="section-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </div>
                    <div class="section-title">
                        <h1>Información Personal</h1>
                        <p>Datos de identificación de la cuenta</p>
                    </div>
                </div>

                <div class="perfil-data-list">
                    <div class="perfil-item">
                        <div class="perfil-item-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </div>
                        <div class="perfil-item-info">
                            <label>Nombre Completo</label>
                            <span><?= h($perfil['nombre_completo']) ?></span>
                        </div>
                    </div>

                    <div class="perfil-item">
                        <div class="perfil-item-icon">
                            <svg viewBox="0 0 24 24" fill="none">
                                <circle cx="8" cy="15" r="4" stroke="currentColor" stroke-width="2"/>
                                <path d="M11 12L18 5M20 7L18 5M16 11L19 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="perfil-item-info">
                            <label>Usuario</label>
                            <span><?= h($perfil['usuario']) ?></span>
                        </div>
                    </div>

                    <div class="perfil-item">
                        <div class="perfil-item-icon">
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M2 4L5 12H19L22 4L16 8L12 3L8 8L2 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M5 16H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M5 20H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                        </div>
                        <div class="perfil-item-info">
                            <label>Rol de Sistema</label>
                            <span><?= h($rolTexto) ?></span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- SECCIÓN 2: DETALLES DE LA CUENTA -->
            <section class="perfil-section">
                <div class="perfil-section-head">
                    <div class="section-icon">
                        <svg viewBox="0 0 24 24" fill="none">
                            <rect x="5" y="10" width="14" height="10" rx="2" stroke="currentColor" stroke-width="2"/>
                            <path d="M8 10V7C8 4.8 9.8 3 12 3C14.2 3 16 4.8 16 7V10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <div class="section-title">
                        <h1>Seguridad y Registro</h1>
                        <p>Marcas de tiempo e historial de acceso</p>
                    </div>
                </div>

                <div class="perfil-data-list">
                    <div class="perfil-item">
                        <div class="perfil-item-icon">
                            <svg viewBox="0 0 24 24" fill="none">
                                <rect x="2" y="4" width="14" height="10" rx="1" stroke="currentColor" stroke-width="2"/>
                                <path d="M6 14V17H12V14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <path d="M2 17H16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                                <rect x="16" y="9" width="6" height="11" rx="1" stroke="currentColor" stroke-width="2"/>
                            </svg>
                        </div>
                        <div class="perfil-item-info">
                            <label>Fecha de Creación</label>
                            <span><?= h($fechaCreacion) ?></span>
                        </div>
                    </div>

                    <div class="perfil-item">
                        <div class="perfil-item-icon">
                            <svg viewBox="0 0 24 24" fill="none">
                                <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/>
                                <path d="M12 7V12L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            </svg>
                        </div>
                        <div class="perfil-item-info">
                            <label>Último Inicio de Sesión</label>
                            <span><?= h($ultimoLogin) ?></span>
                        </div>
                    </div>
                </div>
            </section>

        </main>

    </div>

</div>

<?php
/*
|--------------------------------------------------------------------------
| PASO 19: CERRAR LAYOUT
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/../layout_footer.php';
?>