<?php
// Si ya hay una sesión activa, la cerramos para poder cambiar el nombre
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); 
}
session_name('APP_INVENTARIO');

// Iniciamos la sesión de nuevo
session_start();


// 1. Cargar la autenticación primero para tener acceso a $baseUrl y require_admin()
require_once __DIR__ . '/auth.php';
require_admin();

// 2. Declarar la lista de administradores permitidos
$admins_autorizados = ['lvalladares', 'jcruz'];

// 3. Validar de inmediato. Si no es un administrador autorizado, redirigir
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario'], $admins_autorizados, true)) {
    header("Location: " . $baseUrl . "/dashboard.php?error=no_autorizado");
    exit();
}

// 4. Si pasó la validación, ahora sí iniciamos buffer y cargamos el resto de dependencias
ob_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../auditoria/auditoria_helper.php'; 

$volver = '/Inventario/usuarios/editar_usuario.php';

function volver(string $error = ''): void {
    global $volver;
    if ($error !== '') {
        header("Location: {$volver}?error={$error}");
    } else {
        header("Location: {$volver}?ok=1");
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    volver('metodo_invalido');
}

$usuarioOriginal = trim($_POST['usuario_original'] ?? '');
$nombreCompleto  = trim($_POST['nombre_completo'] ?? '');
$rol             = trim($_POST['rol'] ?? 'usuario');
$password        = trim($_POST['password'] ?? '');

// Regex corregida para aceptar letras, números y guiones bajos (ej: lvalladares)
if (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $usuarioOriginal)) {
    volver('usuario_invalido');
}

if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,100}$/u', $nombreCompleto)) {
    volver('nombre_invalido');
}

if (!in_array($rol, ['usuario', 'admin'], true)) {
    volver('rol_invalido');
}

if ($usuarioOriginal === ($_SESSION['usuario'] ?? '') && $rol !== 'admin') {
    volver('no_quitar_admin');
}

try {
    /*
    |--------------------------------------------------------------------------
    | OBTENER EL ESTADO E INTENTOS ACTUALES
    |--------------------------------------------------------------------------
    */
    $stmtExiste = $conn->prepare("
        SELECT usuario, estado, intentos
        FROM usuarios
        WHERE usuario = ?
        LIMIT 1
    ");

    if (!$stmtExiste) {
        volver('prepare_existe');
    }

    $stmtExiste->bind_param("s", $usuarioOriginal);
    $stmtExiste->execute();

    $resExiste = $stmtExiste->get_result();
    $userActual = $resExiste->fetch_assoc();
    $stmtExiste->close();

    if (!$userActual) {
        volver('no_existe');
    }

    $estadoActual   = (int)$userActual['estado'];
    $intentosActual = (int)$userActual['intentos'];
    $cambioPassword = false;

    /*
    |--------------------------------------------------------------------------
    | PASO 2: EJECUTAR ACTUALIZACIÓN RESPETANDO LOS VALORES ORIGINALES
    |--------------------------------------------------------------------------
    */
    if ($password !== '') {
        // Regex de contraseña ampliada para admitir caracteres especiales comunes
        if (!preg_match('/^[A-Za-z0-9.@$!%*?&]{6,30}$/', $password)) {
            volver('password_invalido');
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $cambioPassword = true;

        $stmt = $conn->prepare("
            UPDATE usuarios
            SET 
                nombre_completo = ?,
                rol = ?,
                password = ?,
                estado = ?,
                intentos = ?
            WHERE usuario = ?
        ");

        if (!$stmt) {
            volver('prepare_update_pass');
        }

        $stmt->bind_param(
            "sssiis",
            $nombreCompleto,
            $rol,
            $hash,
            $estadoActual,
            $intentosActual,
            $usuarioOriginal
        );
    } else {
        $stmt = $conn->prepare("
            UPDATE usuarios
            SET 
                nombre_completo = ?,
                rol = ?,
                estado = ?,
                intentos = ?
            WHERE usuario = ?
        ");

        if (!$stmt) {
            volver('prepare_update');
        }

        $stmt->bind_param(
            "ssiis",
            $nombreCompleto,
            $rol,
            $estadoActual,
            $intentosActual,
            $usuarioOriginal
        );
    }

    if ($stmt->execute()) {
        $stmt->close();

        /*
        |--------------------------------------------------------------------------
        | REGISTRO DE AUDITORÍA
        |--------------------------------------------------------------------------
        */
        $rolTexto = $rol === 'admin' ? 'Administrador' : 'Usuario';
        $estadoTexto = $estadoActual === 1 ? 'Activo' : 'Bloqueado';
        $passwordTexto = $cambioPassword ? 'La contraseña de acceso fue actualizada.' : 'La contraseña de acceso no fue modificada.';

        $detalle = sprintf(
            "Actualización administrativa de usuario\n" .
            "Usuario afectado: %s\n" .
            "Nombre completo actualizado: %s\n" .
            "Rol asignado: %s\n" .
            "Estado conservado: %s\n" .
            "Intentos conservados: %d\n" .
            "Seguridad: %s\n" .
            "Resultado: Los datos del usuario fueron actualizados correctamente.",
            $usuarioOriginal,
            $nombreCompleto,
            $rolTexto,
            $estadoTexto,
            $intentosActual,
            $passwordTexto
        );

        registrar_auditoria(
            'USUARIO_EDITADO',
            $detalle
        );

        volver();
    } else {
        $stmt->close();
        volver('error_guardar');
    }

} catch (Throwable $e) {
    volver('error_servidor');
} // <-- Llave del bloque try añadida correctamente
